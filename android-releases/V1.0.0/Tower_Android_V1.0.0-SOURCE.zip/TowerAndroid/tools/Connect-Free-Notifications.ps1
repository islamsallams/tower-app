﻿param(
 [string]$GoogleServicesJson,
 [string]$ServiceAccountJson,
 [string]$WorkerName='tower-app'
)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
function Select-JsonFile([string]$Title){
 $dialog=New-Object System.Windows.Forms.OpenFileDialog
 $dialog.Title=$Title
 $dialog.Filter='JSON files (*.json)|*.json'
 if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0}
 return $dialog.FileName
}
if(-not $GoogleServicesJson){$GoogleServicesJson=Select-JsonFile 'اختار ملف إعداد التطبيق google-services.json'}
if(-not $ServiceAccountJson){$ServiceAccountJson=Select-JsonFile 'اختار ملف الربط الخاص من Firebase'}
if(-not (Get-Command npx -ErrorAction SilentlyContinue)){throw 'Node.js LTS المجاني مطلوب. هو نفس البرنامج المستخدم مع الـUpdater.'}
$packageName='com.islamsallams.towerapp'
$publicData=Get-Content -LiteralPath $GoogleServicesJson -Raw | ConvertFrom-Json
$privateData=Get-Content -LiteralPath $ServiceAccountJson -Raw | ConvertFrom-Json
$client=@($publicData.client | Where-Object { $_.client_info.android_client_info.package_name -eq $packageName })
if($client.Count -ne 1){throw 'The Android package must be com.islamsallams.towerapp.'}
if($privateData.project_id -ne $publicData.project_info.project_id){throw 'The two files must belong to the same Firebase project.'}
if(-not $privateData.private_key -or -not $privateData.client_email){throw 'Invalid private service-account file.'}
$config=@{
 projectId=$publicData.project_info.project_id
 senderId=[string]$publicData.project_info.project_number
 appId=$client[0].client_info.mobilesdk_app_id
 apiKey=$client[0].api_key[0].current_key
} | ConvertTo-Json -Compress
Write-Host 'Connecting the free messaging service to your existing Worker. No paid Firebase products are used.'
$config | & npx --yes wrangler@latest secret put TOWER_ANDROID_PUBLIC_CONFIG --name $WorkerName
if($LASTEXITCODE -ne 0){throw 'Public configuration was not installed.'}
(Get-Content -LiteralPath $ServiceAccountJson -Raw) | & npx --yes wrangler@latest secret put TOWER_ANDROID_SERVICE_ACCOUNT --name $WorkerName
if($LASTEXITCODE -ne 0){throw 'Private configuration was not installed.'}
Write-Host 'Done. Open the Android app, sign in, then enable Android app notifications.'
