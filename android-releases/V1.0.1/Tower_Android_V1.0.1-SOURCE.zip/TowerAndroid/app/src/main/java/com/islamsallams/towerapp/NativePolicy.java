package com.islamsallams.towerapp;
import java.net.URI;
final class NativePolicy {
 static boolean trusted(String value){try{URI u=new URI(value);return "https".equalsIgnoreCase(u.getScheme())&&"tower-app.islamsallams.workers.dev".equalsIgnoreCase(u.getHost())&&(u.getPort()==-1||u.getPort()==443)&&u.getRawUserInfo()==null;}catch(Exception e){return false;}}
 static boolean uuid(String value){return value!=null&&value.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");}
 static boolean receive(boolean enabled,String session,String owner,String incoming){return enabled&&session!=null&&!session.isEmpty()&&owner!=null&&!owner.isEmpty()&&owner.equals(incoming);}
 static boolean bind(String session,String epoch,String currentSession,String currentEpoch){return session!=null&&!session.isEmpty()&&session.equals(currentSession)&&epoch!=null&&!epoch.isEmpty()&&epoch.equals(currentEpoch);}
 static String fileName(String value){String s=value==null?"":value.replaceAll("[\\\\/\\p{Cntrl}]","_");return s.isEmpty()?"Tower_Export.bin":s.length()>160?s.substring(s.length()-160):s;}
}
