package com.islamsallams.towerapp;
import android.content.Context;import android.app.NotificationManager;import android.app.NotificationChannel;import android.os.Build;import android.content.pm.PackageManager;import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.FirebaseApp;import com.google.firebase.FirebaseOptions;import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;import java.util.UUID;import java.util.concurrent.*;
final class NativePush {
 static final ExecutorService IO=Executors.newSingleThreadExecutor();
 private final Context context;private final SecureState state;
 NativePush(Context c){context=c.getApplicationContext();state=new SecureState(context);}
 JSONObject localStatus(){JSONObject data=state.read(),out=new JSONObject();try{out.put("enabled",data.optBoolean("pushEnabled",false)&&!data.optString("owner").isEmpty());out.put("permission",Build.VERSION.SDK_INT<33||context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==PackageManager.PERMISSION_GRANTED);NotificationChannel channel=context.getSystemService(NotificationManager.class).getNotificationChannel(TowerApplication.CHANNEL);out.put("systemAllowed",NotificationManagerCompat.from(context).areNotificationsEnabled()&&(channel==null||channel.getImportance()!=NotificationManager.IMPORTANCE_NONE));out.put("configured",data.optBoolean("firebaseConfigured",false));out.put("version",BuildConfig.VERSION_NAME);out.put("enabled",out.optBoolean("enabled")&&out.optBoolean("permission")&&out.optBoolean("systemAllowed"));}catch(Exception ignored){}return out;}
 String installation(){JSONObject d=state.read();String id=d.optString("installation");if(id.isEmpty()){id=UUID.randomUUID().toString();state.update("installation",id);state.update("installationSecret",UUID.randomUUID().toString()+UUID.randomUUID());}return id;}
 static void initializeStored(Context context){try{JSONObject data=new SecureState(context).read().optJSONObject("firebaseOptions");if(data!=null&&FirebaseApp.getApps(context).isEmpty())FirebaseApp.initializeApp(context,options(data));}catch(Exception ignored){}}
 private static FirebaseOptions options(JSONObject cfg) throws Exception{return new FirebaseOptions.Builder().setApplicationId(cfg.getString("appId")).setApiKey(cfg.getString("apiKey")).setProjectId(cfg.getString("projectId")).setGcmSenderId(cfg.getString("senderId")).build();}
 synchronized void configure() throws Exception {
  if(!FirebaseApp.getApps(context).isEmpty())return;
  JSONObject cfg=TowerApi.request("/api/android/config",null);if(!cfg.optBoolean("configured"))throw new IllegalStateException("إشعارات التطبيق تحتاج ربط خدمة Google المجانية أولًا.");
  FirebaseApp.initializeApp(context,options(cfg));state.update("firebaseOptions",cfg);state.update("firebaseConfigured",true);
 }
 JSONObject enable() throws Exception {
  JSONObject d=state.read();if(d.optString("session").isEmpty())throw new IllegalStateException("سجّل دخولك في السيستم أولًا.");
  if(!localStatus().optBoolean("permission")||!localStatus().optBoolean("systemAllowed"))throw new IllegalStateException("اسمح بإشعارات التطبيق من إعدادات الهاتف.");
  state.update("bindingEpoch",UUID.randomUUID().toString());configure();FirebaseMessaging messaging=FirebaseMessaging.getInstance();messaging.setAutoInitEnabled(true);String token=com.google.android.gms.tasks.Tasks.await(messaging.getToken(),20,TimeUnit.SECONDS);return bind(token);
 }
 JSONObject bind(String fcmToken) throws Exception {
  installation();JSONObject d=state.read();String session=d.optString("session");if(session.isEmpty())throw new IllegalStateException("سجّل دخولك أولًا.");
  JSONObject result=TowerApi.action(session,"subscribe",new JSONObject().put("installationId",d.getString("installation")).put("secret",d.getString("installationSecret")).put("fcmToken",fcmToken));
  if(!state.bindOwner(session,d.optString("bindingEpoch"),result.getString("userId")))throw new IllegalStateException("الحساب اتغيّر أثناء التفعيل؛ جرّب من حسابك الحالي.");
  return localStatus();
 }
 JSONObject disable() throws Exception {
  JSONObject d=state.disableNotifications();
  if(!d.optString("session").isEmpty()&&!d.optString("installation").isEmpty())TowerApi.action(d.getString("session"),"unsubscribe",new JSONObject().put("installationId",d.getString("installation")).put("secret",d.getString("installationSecret")));
  return localStatus();
 }
 void session(String token,String actor){JSONObject old=state.changeSession(token,actor);if(old==null)return;String previous=old.optString("session");if(!previous.isEmpty()&&!old.optString("installation").isEmpty())IO.execute(()->{try{TowerApi.action(previous,"unsubscribe",new JSONObject().put("installationId",old.getString("installation")).put("secret",old.getString("installationSecret")));}catch(Exception ignored){}});}
 JSONObject refreshStatus() throws Exception {JSONObject d=state.read();if(d.optBoolean("pushEnabled")&&!d.optString("session").isEmpty()&&!d.optString("installation").isEmpty()){JSONObject result=TowerApi.action(d.getString("session"),"status",new JSONObject().put("installationId",d.getString("installation")).put("secret",d.getString("installationSecret")));if(!result.optBoolean("enabled"))state.disableNotifications();}return localStatus();}
 JSONObject test() throws Exception {JSONObject d=state.read();if(!d.optBoolean("pushEnabled"))throw new IllegalStateException("فعّل إشعارات التطبيق أولًا.");return TowerApi.action(d.getString("session"),"test",new JSONObject().put("installationId",d.getString("installation")).put("secret",d.getString("installationSecret")));}
 void tokenRefreshed(String token){IO.execute(()->{if(state.read().optBoolean("pushEnabled")){try{bind(token);}catch(Exception ignored){}}});}
}
