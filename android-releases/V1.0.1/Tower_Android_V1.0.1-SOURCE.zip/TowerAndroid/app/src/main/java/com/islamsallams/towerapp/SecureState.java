package com.islamsallams.towerapp;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;
final class SecureState {
 private static final Object LOCK=new Object();
 private final SharedPreferences prefs;
 SecureState(Context context){prefs=context.getSharedPreferences("tower_native",Context.MODE_PRIVATE);}
 private SecretKey key() throws Exception {
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(store.containsAlias("tower.session.v1"))return (SecretKey)store.getKey("tower.session.v1",null);
  KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  gen.init(new KeyGenParameterSpec.Builder("tower.session.v1",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return gen.generateKey();
 }
 JSONObject read(){synchronized(LOCK){try{String data=prefs.getString("state","");if(data.isEmpty())return new JSONObject();String[] parts=data.split("\\.",2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));return new JSONObject(new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8));}catch(Exception e){return new JSONObject();}}}
 private void write(JSONObject state){try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());String data=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+"."+Base64.encodeToString(c.doFinal(state.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP);if(!prefs.edit().putString("state",data).commit())throw new IllegalStateException("STORE_FAILED");}catch(Exception e){throw new IllegalStateException("تعذر حفظ إعدادات التطبيق بأمان.");}}
 void update(String name,Object value){synchronized(LOCK){try{JSONObject state=read();if(value==null)state.remove(name);else state.put(name,value);write(state);}catch(org.json.JSONException e){throw new IllegalStateException("STORE_FAILED");}}}
 boolean bindOwner(String session,String epoch,String owner){synchronized(LOCK){JSONObject state=read();if(!NativePolicy.bind(session,epoch,state.optString("session"),state.optString("bindingEpoch")))return false;try{state.put("owner",owner);state.put("pushEnabled",true);write(state);return true;}catch(org.json.JSONException e){return false;}}}
 JSONObject disableNotifications(){synchronized(LOCK){JSONObject old=read();try{JSONObject state=new JSONObject(old.toString());state.remove("owner");state.remove("bindingEpoch");state.put("pushEnabled",false);write(state);return old;}catch(org.json.JSONException e){throw new IllegalStateException("STORE_FAILED");}}}
 JSONObject changeSession(String token,String actor){synchronized(LOCK){JSONObject old=read();if(old.optString("session").equals(token)&&(actor.isEmpty()||old.optString("owner").isEmpty()||actor.equals(old.optString("owner"))))return null;try{JSONObject state=new JSONObject(old.toString());state.remove("owner");state.remove("bindingEpoch");state.put("pushEnabled",false);if(token.isEmpty())state.remove("session");else state.put("session",token);write(state);return old;}catch(org.json.JSONException e){throw new IllegalStateException("STORE_FAILED");}}}
}
