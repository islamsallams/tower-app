package com.islamsallams.towerapp;
import java.net.*;import java.io.*;import java.nio.charset.StandardCharsets;import org.json.*;
final class TowerApi {
 static final String ORIGIN="https://tower-app.islamsallams.workers.dev";
 static JSONObject request(String path,JSONObject body) throws Exception {
  HttpURLConnection c=(HttpURLConnection)new URL(ORIGIN+path).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");
  if(body!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
  try{int code=c.getResponseCode();if(code<200||code>=300){String message="تعذر الاتصال بالخدمة ("+code+").";try(InputStream error=c.getErrorStream()){if(error!=null){ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] bytes=new byte[4096];int n;while((n=error.read(bytes))!=-1&&data.size()<32768)data.write(bytes,0,n);JSONObject failure=new JSONObject(data.toString("UTF-8"));String text=failure.optString("error");if(text.length()>0&&text.length()<300&&text.matches("(?s).*[\\u0600-\\u06ff].*"))message=text;String ref=failure.optString("reference");if(ref.matches("[A-Fa-f0-9]{8}"))message+=" (مرجع: "+ref+")";}}catch(Exception ignored){}throw new IOException(message);}try(InputStream in=c.getInputStream()){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>1048576)throw new IOException("RESPONSE_TOO_LARGE");out.write(buffer,0,n);}return new JSONObject(out.toString("UTF-8"));}}finally{c.disconnect();}
 }
 static JSONObject action(String token,String action,JSONObject payload) throws Exception {
  JSONObject inner=new JSONObject().put("name","android390").put("token",token).put("args",new JSONArray().put(action).put(payload));
  JSONObject response=request("/api/tower",new JSONObject().put("method","apiCall").put("args",new JSONArray().put(inner)));
  if(response.has("error"))throw new IOException(response.optString("error","تعذر تنفيذ الطلب."));return response.getJSONObject("result");
 }
}
