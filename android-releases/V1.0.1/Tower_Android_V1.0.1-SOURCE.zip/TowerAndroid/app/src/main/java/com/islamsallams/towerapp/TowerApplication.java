package com.islamsallams.towerapp;
import android.app.Application;import android.app.NotificationChannel;import android.app.NotificationManager;import android.media.AudioAttributes;import android.net.Uri;
public final class TowerApplication extends Application {
 public static final String CHANNEL="tower_ding_dong_v1";
 @Override public void onCreate(){super.onCreate();NativePush.initializeStored(this);NotificationChannel channel=new NotificationChannel(CHANNEL,"تنبيهات برج العائلة",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("طلبات وتنبيهات حسابك بنغمة تين تان");channel.setSound(Uri.parse("android.resource://"+getPackageName()+"/raw/"+getResources().getResourceEntryName(R.raw.tower_chime)),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());channel.enableVibration(true);getSystemService(NotificationManager.class).createNotificationChannel(channel);}
}
