package com.islamsallams.towerapp;
import android.Manifest;import android.app.PendingIntent;import android.content.Intent;import android.content.pm.PackageManager;import android.os.Build;
import androidx.core.app.NotificationCompat;import androidx.core.app.NotificationManagerCompat;import com.google.firebase.messaging.FirebaseMessagingService;import com.google.firebase.messaging.RemoteMessage;import org.json.JSONObject;import java.util.Map;
public final class TowerMessagingService extends FirebaseMessagingService {
 @Override public void onNewToken(String token){new NativePush(this).tokenRefreshed(token);}
 @Override public void onMessageReceived(RemoteMessage message){JSONObject state=new SecureState(this).read();Map<String,String> data=message.getData();String owner=data.get("ownerId");if(!NativePolicy.receive(state.optBoolean("pushEnabled"),state.optString("session"),state.optString("owner"),owner))return;
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
  String title=limit(data.get("title"),120),body=limit(data.get("body"),500),job=data.get("jobId");if(!NativePolicy.uuid(job))return;
  Intent open=new Intent(this,MainActivity.class).setAction("tower.notification."+job).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("pushOwner",owner);String trip=data.get("tripId");if(NativePolicy.uuid(trip))open.putExtra("pushTrip",trip);
  PendingIntent action=PendingIntent.getActivity(this,job.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  NotificationCompat.Builder note=new NotificationCompat.Builder(this,TowerApplication.CHANNEL).setSmallIcon(R.drawable.ic_notice).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(action).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setOnlyAlertOnce(true);
  if(MainActivity.isAccountVisible(owner))note.setSilent(true);
  NotificationManagerCompat.from(this).notify(job,1,note.build());
 }
 private static String limit(String value,int n){if(value==null)return "";return value.length()>n?value.substring(0,n):value;}
}
