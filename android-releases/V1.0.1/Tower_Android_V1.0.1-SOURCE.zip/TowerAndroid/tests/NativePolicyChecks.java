package com.islamsallams.towerapp;
public class NativePolicyChecks {
 private static void yes(boolean value){if(!value)throw new AssertionError();}
 private static void pass(String text){System.out.println("PASS "+text);}
 public static void main(String[] args){
  yes(NativePolicy.trusted("https://tower-app.islamsallams.workers.dev/#trips"));yes(NativePolicy.trusted("https://tower-app.islamsallams.workers.dev:443/api/tower"));
  for(String bad:new String[]{"http://tower-app.islamsallams.workers.dev","https://tower-app.islamsallams.workers.dev.evil.invalid","https://user@tower-app.islamsallams.workers.dev/","https://tower-app.islamsallams.workers.dev:444/","file:///private","javascript:alert(1)","https://evil.invalid/"})yes(!NativePolicy.trusted(bad));pass("native bridge accepts exact HTTPS first-party origin only");
  yes(NativePolicy.receive(true,"session","operator","operator"));yes(!NativePolicy.receive(true,"session","operator","resident"));yes(!NativePolicy.receive(false,"session","operator","operator"));yes(!NativePolicy.receive(true,"","operator","operator"));yes(!NativePolicy.receive(true,"session","",""));pass("notification display requires enabled device and matching signed-in owner");
  yes(NativePolicy.bind("session","epoch","session","epoch"));yes(!NativePolicy.bind("session","old","session","new"));yes(!NativePolicy.bind("old","epoch","new","epoch"));yes(!NativePolicy.bind("session","","session",""));pass("late subscription replies cannot bind after logout or changed activation epoch");
  yes(NativePolicy.uuid("11111111-2222-4333-8444-555555555555"));for(String s:new String[]{"https://evil.invalid/","------------------------------------","11111111-2222-4333-8444-55555555555Z",""})yes(!NativePolicy.uuid(s));pass("native notification trip and job identifiers require complete UUIDs");
  yes(NativePolicy.fileName("../../secret\n.pdf").equals(".._.._secret_.pdf"));yes(NativePolicy.fileName("").equals("Tower_Export.bin"));yes(NativePolicy.fileName("x".repeat(180)+".pdf").length()==160);yes(NativePolicy.fileName("Tower_Report.pdf").equals("Tower_Report.pdf"));pass("native export filenames cannot traverse paths and preserve valid names");
 }
}
