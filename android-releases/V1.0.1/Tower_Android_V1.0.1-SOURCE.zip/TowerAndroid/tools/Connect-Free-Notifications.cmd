@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Connect-Free-Notifications.ps1"
pause
