# Tower Supabase Updater V2.2.1.
# ___________________________

import os
import re
import sys
import json
import time
import shutil
import zipfile
import subprocess
import webbrowser
import ctypes
if os.name == "nt":
    import winsound
    import winreg
import threading
import queue
import types
import tempfile
import urllib.request
import urllib.error
import socket
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
from urllib.parse import urlsplit, urlunsplit, quote
from backup_tools import combine_connection_credentials, create_backup, inspect_backup, BackupError, tool_path
from updater_support import (center_window, work_area, centered_geometry, validate_release, latest_release, version_notice, version_key, error_report, sanitize, STAGES)
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DragDropRoot = TkinterDnD.Tk
    DND_AVAILABLE = True
except ImportError:
    DragDropRoot = tk.Tk
    DND_AVAILABLE = False

APP_NAME = "Tower Supabase Updater"
UPDATER_VERSION = "2.2.1"
CONFIG_PATH = Path.home() / ".tower_supabase_updater.json"
DEFAULT_PORT = 5500

# ---------- Windows DPI ----------
if os.name == "nt":
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    try:
        # Gives the frozen EXE its own stable Windows identity so Taskbar/Alt+Tab
        # use the Tower icon rather than Python's icon.
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "IslamSallam.TowerSupabaseUpdater"
        )
    except Exception:
        pass

# ---------- Theme ----------
BG = "#0F1724"
PANEL = "#172235"
PANEL_2 = "#1E2B40"
BORDER = "#2B3B52"
TEXT = "#F5F7FB"
MUTED = "#96A4B8"
ACCENT = "#4E8DF8"
ACCENT_HOVER = "#6A9FF9"
GOOD = "#28B879"
WARN = "#F2A93B"
BAD = "#E85D68"

FONT = ("Segoe UI", 10)
FONT_B = ("Segoe UI Semibold", 10)
FONT_H1 = ("Segoe UI Semibold", 17)
FONT_H2 = ("Segoe UI Semibold", 12)

def resource_path(name: str) -> Path:
    """Return bundled resource path both in source and PyInstaller one-file mode."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / name

def install_source_path() -> Path:
    """Return the running EXE when frozen, otherwise the source directory."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve()
    return Path(__file__).resolve().parent

def load_config():
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "app_folder": "",
        "port": DEFAULT_PORT,
        "online_url": "",
        "cloudflare_worker_name": "tower-app",
        "supabase_cli_ready": False
    }

def save_config(cfg):
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False

def backup_summary(record):
    """Summarize saved non-secret metadata; existence alone is not re-verification."""
    if not isinstance(record, dict) or not record.get("path"):
        return "No successful backup recorded yet."
    path = Path(record["path"])
    stamp = str(record.get("created_at", "Unknown time"))
    if not path.is_file():
        return "Last backup: " + stamp + "\nFile moved or missing. Choose its new folder manually."
    size = path.stat().st_size
    return ("Last verified backup: " + stamp + "\n"
            + "Archive: " + path.name + " | " + format(size, ",") + " bytes\n"
            + "Verification: passed at creation (not rechecked this session)")

def safe_backup_uri(value):
    """Save only the location, accepting Supabase's literal password placeholder."""
    v = (value or "").strip()
    if not v:
        return ""
    # urlsplit treats [YOUR-PASSWORD] as an invalid IPv6 literal in userinfo.
    v = v.replace("[YOUR-PASSWORD]", "")
    try:
        parts = urlsplit(v)
        host = parts.hostname
        port = parts.port
        username = parts.username
        if parts.scheme not in ("postgres", "postgresql") or not host or not username:
            raise ValueError()
        # An @ copied with the hostname can silently change the parsed username.
        if "@" in username or any(ch.isspace() for ch in host) or host.startswith("@"):
            raise ValueError()
        host_str = "[" + host + "]" if ":" in host else host
        return urlunsplit((parts.scheme, username + "@" + host_str + ((":" + str(port)) if port else ""), parts.path, "", ""))
    except (ValueError, AttributeError) as exc:
        raise ValueError("Invalid PostgreSQL connection location. Paste the full URI from Supabase Connect (not the host alone).") from exc


def protect_windows_secret(value):
    """Windows DPAPI current-user encryption; returns hex text safe for config storage."""
    if os.name != "nt":
        raise RuntimeError("Password storage is only available on Windows.")
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
    buf = ctypes.create_string_buffer(value.encode("utf-8"))
    source = Blob(len(value.encode("utf-8")), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.windll.crypt32
    if not crypt.CryptProtectData(ctypes.byref(source), None, None, None, None, 0x01, ctypes.byref(result)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(result.pbData, result.cbData).hex()
    finally:
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result.pbData, ctypes.c_void_p))


def unprotect_windows_secret(encrypted):
    if os.name != "nt": return ""
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
    data = bytes.fromhex(encrypted)
    buf = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 0x01, ctypes.byref(result)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(result.pbData, result.cbData).decode("utf-8")
    finally:
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result.pbData, ctypes.c_void_p))


def diagnostic_logs():
    paths = [Path.home()/'tower-cloudflare-deploy.log', Path(__file__).resolve().parent/'updater_startup.log']
    parts = []
    for path in paths:
        try:
            if path.is_file():
                with path.open('rb') as stream:
                    stream.seek(0, 2);stream.seek(max(0, stream.tell()-30000))
                    parts.append('السجل: '+path.name+'\n'+stream.read().decode('utf-8', errors='replace'))
        except OSError:
            parts.append('تعذر قراءة السجل: '+path.name)
    return sanitize('\n\n'.join(parts)) or 'لا يوجد سجل محفوظ حتى الآن.'

def show_error(title, detail, parent=None, completed=()):
    """Arabic summary and next step, separate selectable technical details, sanitized copying."""
    root = parent or tk._default_root
    summary, report, technical = error_report(title, detail, completed)
    win = tk.Toplevel(root)
    win.withdraw();win.title('تعذر إتمام العملية — Tower Updater');win.configure(bg=BG)
    win.minsize(480, 430)
    if root:
        win.transient(root)
    tk.Label(win, text='⚠ '+summary, bg=BG, fg=BAD, font=FONT_H2, anchor='e', justify='right', wraplength=660).pack(fill='x', padx=18, pady=(14, 8))
    body = tk.Text(win, bg=PANEL, fg=TEXT, wrap='word', relief='flat', font=FONT, height=12, padx=10, pady=8)
    body.pack(fill='both', expand=True, padx=18)
    body.tag_configure('rtl', justify='right');body.insert('1.0', '\u200f'+report, 'rtl');body.configure(state='disabled')
    tk.Label(win, text='التفاصيل التقنية:', bg=BG, fg=MUTED, font=FONT_B, anchor='e').pack(fill='x', padx=18, pady=(8, 3))
    box = tk.Text(win, bg=PANEL_2, fg=TEXT, wrap='word', relief='flat', font=('Consolas', 9), height=6)
    box.pack(fill='both', expand=True, padx=18)
    box.insert('1.0', technical);box.configure(state='disabled')
    message = f'تقرير خطأ الـUpdater — الإصدار {UPDATER_VERSION}\n\n{report}\n\nالتفاصيل التقنية:\n{technical}'
    def copy(value):
        win.clipboard_clear();win.clipboard_append(sanitize(value))
    def logs():
        log_win = tk.Toplevel(win);log_win.title('سجل التشخيص — Tower Updater');log_win.configure(bg=BG)
        content = diagnostic_logs()
        text = tk.Text(log_win, bg=PANEL, fg=TEXT, wrap='word', relief='flat', font=('Consolas', 9))
        text.pack(fill='both', expand=True, padx=14, pady=14);text.insert('1.0', content);text.configure(state='disabled')
        ModernButton(log_win, text='نسخ الـLog', command=lambda:copy(content), primary=True).pack(pady=(0, 12))
        center_window(log_win, 760, 520, win)
    actions = tk.Frame(win, bg=BG);actions.pack(fill='x', padx=18, pady=12)
    for label, command in [('نسخ الخطأ', lambda:copy(message)), ('عرض الـLog', logs), ('نسخ الـLog', lambda:copy(diagnostic_logs()))]:
        ModernButton(actions, text=label, command=command).pack(side='right', padx=3)
    ModernButton(actions, text='إغلاق', command=win.destroy).pack(side='left')
    center_window(win, 740, 630, root);win.deiconify();win.grab_set();win.focus_force()
    return win


def normalize_version(value):
    """Parse ordinary SemVer and prereleases; retain legacy concatenated version support."""
    raw = str(value or "").strip()
    # Use the final dotted triplet only for legacy strings such as V1.13.0.2.2.1.
    matches = list(re.finditer(r"(?<!\d)(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?![\d.])", raw))
    if not matches:
        return "Unknown"
    m = matches[-1]
    return "V" + ".".join(m.group(i) for i in (1, 2, 3)) + (("-" + m.group(4)) if m.group(4) else "")


def safe_extract_zip(archive, destination):
    """Extract only regular ZIP files under destination; reject traversal and links."""
    dest_root = Path(destination).resolve()
    dest_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "r") as z:
        files = z.infolist()
        if len(files) > 20000:
            raise RuntimeError("ZIP contains an unusually large number of files.")
        total = sum(m.file_size for m in files)
        if total > 1_000_000_000:
            raise RuntimeError("ZIP exceeds the safe extraction limit.")
        seen = set()
        for item in files:
            name = item.filename.replace("\\", "/")
            path = Path(name)
            if (not name or name.startswith("/") or re.match(r"^[A-Za-z]:", name)
                    or ".." in path.parts or "\x00" in name):
                raise RuntimeError("ZIP contains an unsafe path.")
            key = str(path).lower()
            if key in seen:
                raise RuntimeError("ZIP contains duplicate filenames.")
            seen.add(key)
            # Unix symlinks should never be followed while extracting an update.
            mode = (item.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise RuntimeError("ZIP contains a forbidden symlink.")
            if not item.is_dir() and item.file_size > 250_000_000:
                raise RuntimeError("ZIP contains an unusually large file.")
            target = (dest_root / path).resolve()
            if target != dest_root and dest_root not in target.parents:
                raise RuntimeError("ZIP contains a path traversal attempt.")
        z.extractall(dest_root)


def read_version(folder: Path):
    app = folder / "app.js"
    if app.is_file():
        try:
            content = app.read_text(encoding="utf-8", errors="ignore")
            match = re.search(r"APP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", content)
            if match:
                version = normalize_version(match.group(1))
                if version != "Unknown": return version
        except OSError: pass
    marker = folder / "tower-version.json"
    if marker.is_file():
        try:
            return normalize_version(json.loads(marker.read_text(encoding="utf-8")).get("version", ""))
        except (ValueError, OSError, TypeError): pass
    return "Unknown"

def semver_tuple(v):
    normalized = normalize_version(v)
    m = re.fullmatch(r"V(\d+)\.(\d+)\.(\d+)(?:-[0-9A-Za-z.-]+)?", normalized)
    return tuple(map(int, m.groups())) if m else None

def find_app_root(folder: Path):
    folder = folder.resolve()
    if (folder / "index.html").exists() and (folder / "app.js").exists():
        return folder

    candidates = []
    max_depth = len(folder.parts) + 3
    try:
        for p in folder.rglob("index.html"):
            if len(p.parts) > max_depth:
                continue
            candidate = p.parent
            if (candidate / "app.js").exists():
                candidates.append(candidate)
    except Exception:
        pass

    if not candidates:
        return folder
    candidates.sort(key=lambda p: (len(p.parts), str(p).lower()))
    return candidates[0]

def inspect_zip(zip_path: Path):
    if not re.fullmatch(r"Tower_App_[vV]\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?\.zip", zip_path.name, re.IGNORECASE):
        raise RuntimeError("Select a release ZIP named Tower_App_Vx.y.z.zip. SOURCE/development ZIPs are not deployable.")
    with zipfile.ZipFile(zip_path, "r") as z:
        members = [m for m in z.namelist() if not m.endswith("/")]
        if not members:
            raise RuntimeError("ZIP is empty.")
        bad = [m for m in members if ".." in Path(m).parts or Path(m).is_absolute()]
        if bad:
            raise RuntimeError("ZIP contains unsafe paths.")

        # Choose the shallowest matching app/index pair, preferring package root.
        # Never let public/app.js override root app.js: that hides root worker.js.
        apps = [m for m in members if Path(m).name == "app.js"]
        indexes = [m for m in members if Path(m).name == "index.html"]
        apps.sort(key=lambda name: (len(Path(name).parts), name))
        indexes.sort(key=lambda name: (len(Path(name).parts), name))
        app_member = next((m for m in apps if any(m[:-len("app.js")] == n[:-len("index.html")] for n in indexes)), None)
        index_member = next((n for n in indexes if app_member and n[:-len("index.html")] == app_member[:-len("app.js")]), None)

        if not app_member or not index_member:
            raise RuntimeError("Invalid Tower App update: index.html or app.js missing.")

        # A verified package name is a more reliable release identifier than
        # original V1.13.0 headers retained in migrated HTML files.
        package_match = re.fullmatch(r"Tower_App_[vV](\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)\.zip", zip_path.name, re.IGNORECASE)
        package_version = normalize_version(package_match.group(1)) if package_match else "Unknown"
        app_txt = z.read(app_member).decode("utf-8", errors="ignore")
        vm = re.search(r"APP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", app_txt)
        version = normalize_version(vm.group(1)) if vm else "Unknown"
        if version == "Unknown":
            for source in ("worker.js", "index.html", "README_AR.md"):
                match = next((m for m in members if Path(m).name == source and len(Path(m).parts) == 1), None)
                if not match: continue
                body = z.read(match).decode("utf-8", errors="ignore")
                guessed = re.search(r"(?:version\s*:\s*['\"]|[vV])((?:2|3)\.\d+\.\d+)", body)
                if guessed:
                    version = normalize_version(guessed.group(1))
                    break

        # Fail closed rather than silently trusting an incorrectly named archive.
        if package_version != "Unknown" and version != "Unknown" and semver_tuple(package_version) != semver_tuple(version):
            raise RuntimeError(f"ZIP filename says {package_version}, but app.js declares {version}. Refusing ambiguous release.")
        if package_version != "Unknown":
            version = package_version
        if version == "Unknown":
            raise RuntimeError("No reliable Tower App version found in ZIP.")

        # V2.1.10: validate the backend version BEFORE any local file changes.
        # A successful Wrangler deployment of a stale worker was the V2.5.14 incident.
        package_root = Path(app_member).parent
        worker_member = (package_root / "worker.js").as_posix()
        if worker_member in members:
            worker_txt = z.read(worker_member).decode("utf-8", errors="replace")
            worker_match = re.search(r"\bAPP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", worker_txt)
            if not worker_match:
                raise RuntimeError("Deployment blocked: worker.js has no APP_VERSION declaration.")
            worker_version = normalize_version(worker_match.group(1))
            if semver_tuple(worker_version) != semver_tuple(version):
                raise RuntimeError(
                    f"Deployment blocked BEFORE local update: ZIP/app.js is {version}, "
                    f"but worker.js is {worker_version}. Obtain a corrected Release ZIP."
                )
            public_app_member = (package_root / "public" / "app.js").as_posix()
            if public_app_member in members:
                public_txt = z.read(public_app_member).decode("utf-8", errors="replace")
                public_match = re.search(r"\bAPP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", public_txt)
                if not public_match or semver_tuple(public_match.group(1)) != semver_tuple(version):
                    raise RuntimeError("Deployment blocked: public/app.js release version differs from ZIP version.")

        app_parts = Path(app_member).parts[:-1]
        index_parts = Path(index_member).parts[:-1]
        common_prefix = ()
        for a, b in zip(app_parts, index_parts):
            if a == b:
                common_prefix += (a,)
            else:
                break

        return {
            "version": version,
            "members": members,
            "root_parts": common_prefix,
        }

class ModernButton(tk.Button):
    def __init__(self, master, text="", command=None, primary=False, danger=False, **kwargs):
        bg = ACCENT if primary else (BAD if danger else PANEL_2)
        fg = "#FFFFFF" if primary or danger else TEXT
        active = ACCENT_HOVER if primary else ("#F17680" if danger else "#29384F")
        super().__init__(
            master,
            text=text,
            command=command,
            bg=bg,
            fg=fg,
            activebackground=active,
            activeforeground="#FFFFFF",
            relief="flat",
            bd=0,
            padx=16,
            pady=10,
            cursor="hand2",
            font=FONT_B,
            highlightthickness=0,
            anchor="center",
            justify="center",
            **kwargs,
        )

class SnapshotValue:
    """A worker-owned value; setting it queues a main-thread UI update."""
    def __init__(self, value, setter, post):
        self.value, self.setter, self.post = value, setter, post
    def get(self):
        return self.value
    def set(self, value):
        self.value = value
        self.post(lambda v=value: self.setter(v))

class UpdateJob:
    """Snapshot the selected package and settings; deployment cores never read Tk in the worker."""
    METHODS = ('_apply_local_update_core', '_sync_public_supabase_config', '_public_supabase_values',
               '_deploy_cloudflare_core', '_npx_path', '_prepare_cloudflare_assets', '_ensure_health_kv_binding',
               '_preflight_worker_bundle', '_verify_worker_online', '_extract_supabase_functions',
               '_deploy_supabase_functions_core', '_supabase_npx', '_project_ref', '_read_supabase_config',
               '_online_version_probe', '_port_available', '_choose_server_port', '_server_health')
    def __init__(self, app):
        self.selected_zip = Path(app.selected_zip)
        self.target_folder = Path(app.target_folder)
        self.cfg = dict(app.cfg)
        self.cloudflare_uploaded = False
        self.expected_version = app.new_version_var.get()
        self._post = app._post_ui
        self.old_server = app.httpd
        self.preferred_port = app._port()
        for name in ('online_url_var', 'worker_name_var', 'update_progress_var', 'supabase_cli_status_var'):
            variable = getattr(app, name)
            setattr(self, name, SnapshotValue(variable.get(), variable.set, self._post))
        self._refresh_target = lambda: None
        self.save_online_settings = lambda silent=True: True
        self.after = lambda delay, callback: self._post(callback)
        for name in self.METHODS:
            setattr(self, name, types.MethodType(getattr(App, name), self))
    def _mark_cloudflare_uploaded(self):
        self.cloudflare_uploaded = True
    def restart_local_server(self):
        if self.old_server is not None:
            self.old_server.shutdown();self.old_server.server_close()
        port = self._choose_server_port(self.preferred_port)
        root = str(self.target_folder)
        class QuietHandler(SimpleHTTPRequestHandler):
            def log_message(self, *args):
                pass
        handler = lambda *args, **kwargs: QuietHandler(*args, directory=root, **kwargs)
        server = ThreadingHTTPServer(('127.0.0.1', port), handler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, daemon=True, name='TowerLocalServer')
        thread.start()
        ok, _, detail = self._server_health(port)
        if not ok:
            server.shutdown();server.server_close()
            raise RuntimeError('Local server started but did not serve index.html. '+detail)
        return server, thread, port

class App(DragDropRoot):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title(f"{APP_NAME} v{UPDATER_VERSION}")
        rect = work_area(self)
        win_w, win_h, _, _ = centered_geometry(rect, 750, 760)
        self.geometry(f'{win_w}x{win_h}')
        self._compact = win_h < 730
        self.minsize(min(620, win_w), min(660, win_h))
        self._ui_queue = queue.Queue()
        self._closing = False
        self._selecting = False
        self._selection_id = 0
        self.configure(bg=BG)
        try:
            icon_path = resource_path("Tower_Supabase_Updater.ico")
            if icon_path.exists():
                self.iconbitmap(default=str(icon_path))
        except Exception:
            pass

        self.proc = None
        self.httpd = None
        self.server_thread = None
        self.cfg = load_config()
        self.selected_zip = None
        self.target_folder = None

        self.folder_var = tk.StringVar(value=self.cfg.get("app_folder", ""))
        self.port_var = tk.StringVar(value=str(self.cfg.get("port", DEFAULT_PORT)))
        self.current_version_var = tk.StringVar(value="—")
        self.new_version_var = tk.StringVar(value="—")
        self.status_var = tk.StringVar(value="جاهز لاختيار حزمة التحديث.")
        self.target_var = tk.StringVar(value="—")
        self.supabase_project_var = tk.StringVar(value="Not checked")
        self.supabase_status_var = tk.StringVar(value="Run Supabase diagnostics to verify the project connection.")
        self.last_health_result = ""
        self.online_url_var = tk.StringVar(value=self.cfg.get("online_url", ""))
        self.worker_name_var = tk.StringVar(value=self.cfg.get("cloudflare_worker_name", "tower-app"))
        self.online_version_var = tk.StringVar(value="—")
        self.cloudflare_status_var = tk.StringVar(value="Set the Worker URL and name, then connect Cloudflare.")
        self.supabase_cli_status_var = tk.StringVar(value="Edge Functions: Detected automatically from the update ZIP.")
        self.update_progress_var = tk.StringVar(value="اختر حزمة التحديث أولًا.")
        self.deploy_stage_var = tk.StringVar(value="التحديث التلقائي يستورد ويرفع؛ الكارت والسحب للتجهيز اليدوي.")
        self._ui_state = "ready"
        self._normal_geometry = None
        self.server_port = None
        self.settings_window = None
        self.health_rows = {}
        self.sound_choice = tk.StringVar(value=self.cfg.get("finish_sound", ""))
        self._busy = False
        self._backup_busy = False
        self.pg_bin_dir = self.cfg.get("postgresql_bin_dir", "")
        self.backup_status_var = tk.StringVar(value="No backup created in this session.")
        self.last_backup_var = tk.StringVar(value=backup_summary(self.cfg.get("last_verified_backup")))

        self.release_file_var = tk.StringVar(value='Click this card or drag a ZIP here')
        self.comparison_var = tk.StringVar(value='اختر حزمة تحديث لعرض الإصدار.')
        folder = self.cfg.get('release_zip_folder', '')
        self.release_folder_label = tk.StringVar(value=Path(folder).name if folder else 'Choose a folder once')
        self.release_folder_path_var = tk.StringVar(value=folder or 'No folder selected')
        self._build()
        self._set_dark_titlebar(self)
        for variable in (self.new_version_var, self.online_version_var, self.current_version_var):
            variable.trace_add('write', self._refresh_comparison)
        self.after(50, self._drain_ui)
        self.after_idle(lambda: (center_window(self, win_w, win_h), self.deiconify()))
        self.after(500, self.check_online)
        self._refresh_target()
        self.after(150, self._enable_safe_drop)
        self.after(900, self._auto_promote_self)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _set_dark_titlebar(self, window):
        if os.name != "nt": return
        try:
            window.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
            value = ctypes.c_int(1)
            for attr in (20, 19):
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)) == 0: break
        except Exception:
            pass

    # ---------- UI ----------
    def _build(self):
        footer = tk.Frame(self, bg=BG)
        footer.pack(side='bottom', fill='x', pady=(4, 10))
        tk.Label(footer, text='© Islam Sallam. All rights reserved.', bg=BG, fg=MUTED, font=('Segoe UI', 9)).pack()
        tk.Button(footer, text='01095851719', command=self.copy_copyright_phone, bg=BG, fg=MUTED,
                  activebackground=BG, activeforeground=ACCENT, bd=0, cursor='hand2', font=('Segoe UI', 10)).pack()
        outer = tk.Frame(self, bg=BG);outer.pack(fill='both', expand=True, padx=22, pady=(14, 0))
        header = tk.Frame(outer, bg=BG);header.pack(fill='x', pady=(0, 10))
        brand = tk.Frame(header, bg=BG);brand.pack(side='left')
        try:
            img = tk.PhotoImage(file=str(resource_path('Tower_Supabase_Updater.png')))
            factor = max(1, int(max(img.width(), img.height())/38))
            self.header_logo_image = img.subsample(factor, factor)
            tk.Label(brand, image=self.header_logo_image, bg=BG).pack(side='left', padx=(0, 9))
        except Exception:
            tk.Label(brand, text='◆', bg=BG, fg=ACCENT, font=FONT_H1).pack(side='left', padx=(0, 9))
        heading = tk.Frame(brand, bg=BG);heading.pack(side='left')
        tk.Label(heading, text='Tower Updater', bg=BG, fg=TEXT, font=FONT_H1).pack(anchor='w')
        tk.Label(heading, text='v'+UPDATER_VERSION, bg=BG, fg=MUTED, font=('Segoe UI', 9)).pack(anchor='w')
        self.settings_btn = ModernButton(header, text='⚙ Settings', command=self.open_settings)
        self.settings_btn.pack(side='right')
        versions = tk.Frame(outer, bg=BG);versions.pack(fill='x', pady=(0, 9))
        for i, (title, value) in enumerate((('LOCAL VERSION', self.current_version_var), ('ONLINE VERSION', self.online_version_var))):
            versions.columnconfigure(i, weight=1, uniform='version')
            card = tk.Frame(versions, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
            card.grid(row=0, column=i, sticky='nsew', padx=(0, 5) if not i else (5, 0))
            tk.Label(card, text=title, bg=PANEL, fg=MUTED, font=('Segoe UI', 8)).pack(anchor='w', padx=12, pady=(8, 2))
            tk.Label(card, textvariable=value, bg=PANEL, fg=TEXT, font=FONT_H2).pack(anchor='w', padx=12, pady=(0, 8))
            if i:
                self.refresh_btn = tk.Button(card, text='↻', command=self.check_online, bg=PANEL, fg=ACCENT,
                                             activebackground=PANEL, activeforeground=TEXT, bd=0, font=('Segoe UI', 16), cursor='hand2')
                self.refresh_btn.place(relx=1, x=-8, y=6, anchor='ne')
        self.drop = tk.Frame(outer, bg=PANEL_2, highlightbackground=BORDER, highlightthickness=2, takefocus=True)
        self.drop.pack(fill='x', pady=(0, 8))
        self.drop_title = tk.Label(self.drop, text='Choose a release ZIP', bg=PANEL_2, fg=TEXT, font=FONT_B)
        self.drop_title.pack(pady=(10, 0))
        self.drop_version = tk.Label(self.drop, textvariable=self.new_version_var, bg=PANEL_2, fg=ACCENT, font=('Segoe UI Semibold', 23 if self._compact else 27))
        self.drop_version.pack(pady=1)
        self.drop_sub = tk.Label(self.drop, textvariable=self.release_file_var, bg=PANEL_2, fg=MUTED, font=('Segoe UI', 9), height=1, wraplength=650)
        self.drop_sub.pack(fill='x', padx=10, pady=(0, 4))
        manual_actions = tk.Frame(self.drop, bg=PANEL_2)
        manual_actions.pack(fill='x', padx=10, pady=(0, 8))
        self.update_btn = ModernButton(manual_actions, text='↑ Manual Update', command=self.update_project_all)
        self.update_btn.config(pady=6)
        self.update_btn.pack(side='right')
        self.update_btn.config(state='disabled')
        for widget in (self.drop, self.drop_title, self.drop_version, self.drop_sub):
            widget.bind('<Button-1>', lambda event: self.choose_zip())
        self.comparison_label = tk.Label(outer, textvariable=self.comparison_var, bg=PANEL, fg=MUTED,
                                         font=('Segoe UI', 9), justify='right', anchor='e', wraplength=650, padx=10, pady=7)
        self.comparison_label.pack(fill='x', pady=(0, 8))
        imports = tk.Frame(outer, bg=BG);imports.pack(fill='x', pady=(0, 7))
        self.import_folder_btn = ModernButton(imports, text='Folder…', command=self.choose_release_folder)
        self.import_folder_btn.pack(side='left', padx=7)
        tk.Label(imports, textvariable=self.release_folder_label, bg=BG, fg=MUTED, font=('Segoe UI', 9), anchor='e').pack(side='right', fill='x', expand=True)
        self.drop.bind('<Return>', lambda event: self.choose_zip())
        self.drop.bind('<space>', lambda event: self.choose_zip())
        action = tk.Frame(outer, bg=BG);action.pack(fill='x', pady=(0, 6))
        self.auto_import_btn = ModernButton(action, text='↑ Auto Update', command=self.auto_update_project, primary=True)
        self.auto_import_btn.config(font=('Segoe UI Semibold', 14))
        self.auto_import_btn.pack(anchor='center', ipadx=34, ipady=2)
        self.progress_area = tk.Frame(outer, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        top = tk.Frame(self.progress_area, bg=PANEL);top.pack(fill='x', padx=10, pady=(7, 4))
        self.progress_ring = tk.Canvas(top, width=24, height=24, bg=PANEL, highlightthickness=0)
        self.progress_ring.pack(side='left')
        self.progress_label = tk.Label(top, textvariable=self.update_progress_var, bg=PANEL, fg=TEXT, font=('Segoe UI', 9), anchor='e')
        self.progress_label.pack(side='right', expand=True, fill='x', padx=5)
        self.elapsed_label = tk.Label(top, text='00:00', bg=PANEL, fg=MUTED, font=('Segoe UI', 9))
        self.elapsed_label.pack(side='left', padx=5)
        row = tk.Frame(self.progress_area, bg=PANEL);row.pack(fill='x', padx=8, pady=(0, 8))
        self.stage_cells = []
        for i, label in enumerate(('Package', 'Local', 'Cloudflare', 'Supabase', 'Verify')):
            row.columnconfigure(i, weight=1, uniform='phase')
            cell = tk.Label(row, text='○ '+label, bg=PANEL_2, fg=MUTED, font=('Segoe UI', 8), padx=4, pady=7)
            cell.grid(row=0, column=i, sticky='ew', padx=2)
            self.stage_cells.append(cell)
        self.progress_area.pack(fill='x', pady=(0, 7));self.progress_area.pack_forget()
        self.stage_label = tk.Label(outer, textvariable=self.deploy_stage_var, bg=BG, fg=MUTED, font=('Segoe UI', 9), height=1)
        if not self._compact:
            self.stage_label.pack(fill='x')
        self.main_status = tk.Label(outer, textvariable=self.status_var, bg=BG, fg=MUTED, font=('Segoe UI', 9), anchor='e', justify='right', wraplength=650, height=1 if self._compact else 2)
        self.main_status.pack(fill='x', pady=3)
        tk.Button(outer, text='نسخ الـLog', command=self.copy_log, bg=BG, fg=ACCENT, activebackground=BG, activeforeground=TEXT, bd=0, font=('Segoe UI', 9), cursor='hand2').pack(anchor='e')
        if self._compact:
            for button in (self.settings_btn, self.auto_import_btn, self.import_folder_btn, self.update_btn):
                button.config(pady=6)
        self._progress_tick_id = None
        self._deploy_steps = []
        self._stage_index = 0
        self._stage_failed = False
        self._progress_angle = 0

    def _animate_progress(self):
        if self._ui_state != 'updating':
            return
        elapsed = max(0, int(time.monotonic()-self._started_at))
        self.elapsed_label.config(text=f'{elapsed//60:02d}:{elapsed%60:02d}')
        self._progress_angle = (self._progress_angle+24)%360
        self.progress_ring.delete('all')
        self.progress_ring.create_oval(3, 3, 21, 21, outline=BORDER, width=3)
        self.progress_ring.create_arc(3, 3, 21, 21, start=self._progress_angle, extent=250, outline=ACCENT, width=3, style='arc')
        self._progress_tick_id = self.after(100, self._animate_progress)

    def _set_update_state(self, state, detail=''):
        self._ui_state = state
        if self._progress_tick_id is not None:
            self.after_cancel(self._progress_tick_id);self._progress_tick_id = None
        busy = state == 'updating'
        for control in (self.update_btn, self.settings_btn, self.refresh_btn, self.auto_import_btn, self.import_folder_btn):
            control.config(state='disabled' if busy else 'normal')
        if not busy and not self.selected_zip:
            self.update_btn.config(state='disabled')
        self.progress_area.pack(before=self.auto_import_btn.master, fill='x', pady=(0, 7))
        if busy:
            self._started_at = time.monotonic()
            self.drop_title.config(text='Updating project…', fg=ACCENT)
            self._animate_progress()
        else:
            self.progress_ring.delete('all')
            self.progress_ring.create_text(12, 12, text='✓' if state=='done' else '!' if state=='pending' else '×', fill=GOOD if state=='done' else WARN if state=='pending' else BAD, font=FONT_H2)
            self.drop_title.config(text={'done':'✓ Update verified', 'pending':'⚠ Verification pending', 'failed':'✕ Update incomplete'}.get(state, 'Selected release'), fg=GOOD if state=='done' else WARN if state=='pending' else BAD)
        self.drop.config(highlightbackground=ACCENT if busy else GOOD if state=='done' else WARN if state=='pending' else BAD)
        if detail:
            self.status_var.set(detail)
        self._paint_stages()

    def _adopt_job_server(self, server, thread, port):
        self.httpd, self.server_thread, self.server_port = server, thread, port
        self.port_var.set(str(port))
        self.cfg['port'] = port
        save_config(self.cfg)

    def _run_full_update_job(self, job):
        completed = []
        stage = 0
        staging = None
        try:
            staging = Path(tempfile.mkdtemp(prefix='tower_selected_release_'))
            frozen = staging/job.selected_zip.name
            shutil.copy2(job.selected_zip, frozen)
            info = validate_release(frozen, inspect_zip)
            job.selected_zip = frozen
            new_version = info['version']
            if version_key(new_version) != version_key(job.expected_version):
                raise ValueError('Selected ZIP changed after validation. Select the release ZIP again.')
            completed.append('تم فحص الحزمة '+new_version)
            stage = 1
            self._post_ui(lambda done=completed[:]: self._set_phase(1, done))
            old_version, actual = job._apply_local_update_core()
            completed.append('تم تحديث الملفات المحلية إلى '+actual)
            server, thread, port = job.restart_local_server()
            self._post_ui(lambda: self._adopt_job_server(server, thread, port))
            self._post_ui(lambda: self.current_version_var.set(actual))
            stage = 2
            self._post_ui(lambda done=completed[:]: self._set_phase(2, done))
            deployed_version = job._deploy_cloudflare_core()
            completed.append('تم رفع Cloudflare والتحقق من واجهته: '+str(deployed_version))
            stage = 3
            self._post_ui(lambda done=completed[:]: self._set_phase(3, done))
            deployed = job._deploy_supabase_functions_core()
            completed.append('تم تحديث دوال Supabase' if deployed else 'لا توجد دوال Supabase جديدة في الحزمة')
            stage = 4
            self._post_ui(lambda done=completed[:]: self._set_phase(4, done))
            verified, seen = False, '—'
            for attempt in range(6):
                ok, value, _ = job._online_version_probe(job.online_url_var.get())
                if ok:
                    seen = value
                    if version_key(value) == version_key(new_version):
                        verified = True
                        break
                if attempt < 5:
                    self._post_ui(lambda n=attempt+2: self.update_progress_var.set(f'التحقق الأونلاين — محاولة {n}/6'))
                    time.sleep(3)
            if verified:
                completed.append('تم تأكيد الإصدار الأونلاين '+new_version)
            def finish():
                self._busy = False
                self._deploy_steps = completed[:]
                if seen != '—':
                    self.online_version_var.set(seen)
                self.cloudflare_status_var.set('تم رفع Cloudflare: '+str(deployed_version))
                self.supabase_cli_status_var.set('دوال Supabase: '+(', '.join(deployed) if deployed else 'لا تحتاج تحديثًا'))
                self.deploy_stage_var.set('اكتملت جميع المراحل.' if verified else 'الرفع اكتمل؛ التحقق الأونلاين لم يُحسم بعد.')
                self.update_progress_var.set('تم تأكيد الإصدار '+new_version if verified else 'انتظار تأكيد الإصدار الأونلاين')
                self._set_update_state('done' if verified else 'pending', 'تم التحديث والتحقق بنجاح.' if verified else 'تم الرفع. لا تعِد الرفع الآن؛ انتظر ثم حدّث الإصدار الأونلاين.')
                self._refresh_comparison()
                if verified:
                    self._play_completion_sound()
            self._post_ui(finish)
        except Exception as exc:
            detail = str(exc)
            if job.cloudflare_uploaded and stage==2:
                completed.append('نجح أمر رفع Cloudflare؛ لم يكتمل التحقق اللاحق.')
            def failure():
                self._busy = False
                self._stage_index = stage
                self._deploy_steps = completed[:]
                self.deploy_stage_var.set('توقف التنفيذ عند: '+STAGES[stage])
                self.update_progress_var.set('المرحلة المتوقفة: '+STAGES[stage])
                self._set_update_state('pending' if job.cloudflare_uploaded and stage==2 else 'failed', 'التحديث غير مكتمل. افتح التفاصيل لمعرفة ما اكتمل والخطوة التالية.')
                show_error(STAGES[stage], detail, parent=self, completed=completed)
            self._post_ui(failure)
        finally:
            if staging:
                shutil.rmtree(staging, ignore_errors=True)

    def auto_update_project(self):
        # Only this explicit button opts into deployment after a successful import.
        if self._busy or self._backup_busy or self._selecting:
            return
        if not self.cfg.get('release_zip_folder'):
            self.choose_release_folder()
        if self.cfg.get('release_zip_folder'):
            self.stage_zip(None, auto=True, start_update=True)

    def auto_import_zip(self):
        if self._busy or self._backup_busy or self._selecting:
            return
        if not self.cfg.get('release_zip_folder'):
            self.choose_release_folder()
        if self.cfg.get('release_zip_folder'):
            self.stage_zip(None, auto=True)

    def choose_release_folder(self):
        if self._busy or self._backup_busy or self._selecting:
            return
        selected = filedialog.askdirectory(parent=self, title='Choose release ZIP folder', initialdir=self.cfg.get('release_zip_folder') or None)
        if selected:
            previous = self.cfg.get('release_zip_folder')
            self.cfg['release_zip_folder'] = selected
            if not save_config(self.cfg):
                if previous is None:
                    self.cfg.pop('release_zip_folder', None)
                else:
                    self.cfg['release_zip_folder'] = previous
                show_error('حفظ مجلد الاستيراد', 'تعذر حفظ الإعدادات؛ راجع صلاحية الكتابة في ملف إعدادات المستخدم.', parent=self)
                return
            self.release_folder_label.set(Path(selected).name or selected)
            self.release_folder_path_var.set(selected)
            self.status_var.set('تم حفظ مجلد الاستيراد. اضغط Auto Update لاستيراد أحدث إصدار متوافق وتحديث المشروع مباشرة.')

    def _paint_stages(self):
        for i, (label, widget) in enumerate(zip(('Package', 'Local', 'Cloudflare', 'Supabase', 'Verify'), self.stage_cells)):
            done = i < self._stage_index or self._ui_state == 'done'
            current = i == self._stage_index
            icon = '✓' if done else ('!' if current and self._ui_state in ('failed', 'pending') else '◉' if current else '○')
            color = GOOD if done else BAD if current and self._ui_state=='failed' else WARN if current and self._ui_state=='pending' else ACCENT if current else MUTED
            widget.config(text=icon+' '+label, fg=color)

    def _set_phase(self, index, completed=None):
        self._stage_index = index
        if completed is not None:
            self._deploy_steps = list(completed)
        self.update_progress_var.set('المرحلة '+str(index+1)+'/5 — '+STAGES[index])
        self.deploy_stage_var.set('جاري التنفيذ — '+STAGES[index])
        self._paint_stages()

    def _refresh_comparison(self, *_):
        kind, text = version_notice(self.new_version_var.get(), self.online_version_var.get(), self.current_version_var.get())
        colors = {'same': ACCENT, 'older': WARN, 'newer': GOOD, 'neutral': MUTED}
        self.comparison_var.set(text)
        self.comparison_label.config(fg=colors[kind], bg='#30291F' if kind=='older' else PANEL)

    def _post_ui(self, callback):
        self._ui_queue.put(callback)

    def _drain_ui(self):
        if self._closing:
            return
        for _ in range(150):
            try:
                callback = self._ui_queue.get_nowait()
            except queue.Empty:
                break
            try:
                callback()
            except Exception as exc:
                show_error('تحديث الواجهة', str(exc), parent=self)
        self.after(50, self._drain_ui)

    def copy_copyright_phone(self):
        self.clipboard_clear();self.clipboard_append('01095851719')
        self.status_var.set('تم نسخ رقم التليفون.')

    def _route_mousewheel(self, event):
        if self.settings_window is not None and self.settings_window.winfo_exists():
            try:
                widget=self.winfo_containing(event.x_root,event.y_root)
                if widget is not None and str(widget).startswith(str(self.settings_window)):
                    canvas=getattr(self,"_settings_canvas",None)
                    if canvas is not None and canvas.winfo_exists():
                        canvas.yview_scroll(-1 if event.delta>0 else 1,"units")
                    return "break"
            except tk.TclError: pass
        return None

    def open_settings(self):
        if self.settings_window is not None and self.settings_window.winfo_exists():
            self.settings_window.lift()
            self.settings_window.focus_force()
            return
        win = tk.Toplevel(self)
        self.settings_window = win
        win.title("Tower Updater — Settings")
        win.configure(bg=BG)
        win.geometry("830x585")
        win.minsize(650, 460)
        self._set_dark_titlebar(win)
        head = tk.Frame(win, bg=BG)
        head.pack(fill="x", padx=22, pady=(18, 10))
        tk.Label(head, text="Settings", bg=BG, fg=TEXT, font=FONT_H1).pack(side="left")
        tk.Label(head, text="v" + UPDATER_VERSION, bg=BG, fg=MUTED, font=FONT).pack(side="right")
        tabs = tk.Frame(win, bg=BG)
        tabs.pack(fill="x", padx=22, pady=(0, 12))
        pane = tk.Frame(win, bg=BG)
        pane.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        self._settings_pages = {}
        self._settings_scroll = {}
        self._settings_tabs = {}
        self._settings_tab = "General"
        for label in ("General", "Cloudflare", "Supabase", "Backup", "Diagnostics"):
            button = tk.Button(tabs, text=label, font=FONT_B, bg=PANEL, fg=MUTED,
                               activebackground=PANEL_2, activeforeground=TEXT, bd=0,
                               relief="flat", padx=18, pady=10, cursor="hand2",
                               command=lambda name=label: self._switch_settings_tab(name))
            button.pack(side="left", padx=(0, 8))
            self._settings_tabs[label] = button
            page = tk.Frame(pane, bg=BG)
            self._settings_pages[label] = page
            canvas = tk.Canvas(page, bg=BG, highlightthickness=0, bd=0)
            # The dark scrollbar is inside each page and only shown when necessary.
            scroll = tk.Canvas(page, width=7, bg=BG, highlightthickness=0, bd=0)
            canvas.pack(side="left", fill="both", expand=True)
            holder = tk.Frame(canvas, bg=BG)
            window_id = canvas.create_window((0, 0), window=holder, anchor="nw")
            holder.bind("<Configure>", lambda event, c=canvas: self._update_settings_scroll(c))
            canvas.bind("<Configure>", lambda event, c=canvas, wid=window_id: (c.itemconfigure(wid, width=event.width), self._update_settings_scroll(c)))
            canvas._scroll_indicator = scroll
            canvas._scroll_page = page
            self._settings_scroll[label] = canvas
            getattr(self, "_build_tab_" + label.lower())(holder)
        self._switch_settings_tab("General")
        self.bind_all("<MouseWheel>", self._route_mousewheel, add="+")
        def close_settings():
            if self._backup_busy:
                show_error("النسخ الاحتياطي", "انتظر انتهاء النسخ الاحتياطي قبل إغلاق الإعدادات.", parent=win)
                return
            if hasattr(self, "_backup_uri") and self._backup_uri.winfo_exists():
                self._backup_uri.delete(0, "end")
            if hasattr(self, "_backup_password") and self._backup_password.winfo_exists():
                self._backup_password.delete(0, "end")
            self.save_online_settings(silent=True)
            self.settings_window = None
            self._settings_canvas = None
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", close_settings)
        self._register_drop_tree(win)
        win.after_idle(lambda: center_window(win, 830, 585, self))

    def _update_settings_scroll(self, canvas):
        try:
            canvas.configure(scrollregion=canvas.bbox("all"))
            def redraw():
                if not canvas.winfo_exists(): return
                top, bottom = canvas.yview()
                bar = canvas._scroll_indicator
                if bottom - top >= .995:
                    if bar.winfo_manager(): bar.pack_forget()
                    return
                if not bar.winfo_manager(): bar.pack(side="right", fill="y")
                bar.delete("all")
                height = max(bar.winfo_height(), 50)
                bar.create_rectangle(2, int(top*height), 6, max(int(bottom*height), int(top*height)+22), fill="#435873", outline="")
            canvas.after_idle(redraw)
        except tk.TclError: pass

    def _switch_settings_tab(self, name):
        self._settings_tab = name
        for title, page in self._settings_pages.items():
            page.pack_forget()
            self._settings_tabs[title].configure(bg=ACCENT if title == name else PANEL,
                                                fg="#FFFFFF" if title == name else MUTED)
        self._settings_pages[name].pack(fill="both", expand=True)
        self._settings_canvas = self._settings_scroll[name]
        self._update_settings_scroll(self._settings_canvas)

    def _settings_card(self, parent, title):
        card = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        card.pack(fill="x", pady=(0, 12))
        tk.Label(card, text=title, font=FONT_H2, bg=PANEL, fg=TEXT, anchor="w").pack(fill="x", padx=16, pady=(13, 8))
        body = tk.Frame(card, bg=PANEL)
        body.pack(fill="x", padx=16, pady=(0, 14))
        return body

    def _paste_into_entry(self, entry):
        """Paste only into the selected Entry; never log or persist credentials."""
        try:
            value = entry.clipboard_get()
            if not isinstance(value, str):
                return "break"
            if entry.selection_present():
                entry.delete("sel.first", "sel.last")
            entry.insert("insert", value)
        except tk.TclError:
            pass
        return "break"

    def _entry_context_menu(self, entry):
        menu = tk.Menu(entry, tearoff=False, bg=PANEL_2, fg=TEXT,
                       activebackground=ACCENT, activeforeground="#ffffff")
        menu.add_command(label="Cut", command=lambda: entry.event_generate("<<Cut>>"))
        menu.add_command(label="Copy", command=lambda: entry.event_generate("<<Copy>>"))
        menu.add_command(label="Paste", command=lambda: self._paste_into_entry(entry))
        menu.add_separator()
        menu.add_command(label="Select All", command=lambda: (entry.select_range(0, "end"), entry.icursor("end")))
        def popup(event):
            entry.focus_set()
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
            return "break"
        entry.bind("<Button-3>", popup, add="+")
        entry.bind("<Control-v>", lambda event: self._paste_into_entry(entry), add="+")
        entry.bind("<Control-V>", lambda event: self._paste_into_entry(entry), add="+")
        entry.bind("<Control-a>", lambda event: (entry.select_range(0, "end"), entry.icursor("end"), "break")[-1], add="+")
        entry.bind("<Control-A>", lambda event: (entry.select_range(0, "end"), entry.icursor("end"), "break")[-1], add="+")
        # Keep menu alive for the lifetime of the Entry.
        entry._context_menu = menu

    def _settings_field(self, frame, label, value, row, width=None):
        tk.Label(frame, text=label, font=FONT, bg=PANEL, fg=MUTED, anchor="w").grid(row=row, column=0, sticky="w", pady=(0, 6))
        entry = tk.Entry(frame, textvariable=value, bg=PANEL_2, fg=TEXT,
                         insertbackground=TEXT, relief="flat", font=FONT, justify="left")
        entry.grid(row=row+1, column=0, sticky="ew", ipady=8, pady=(0, 12), padx=(0, 8))
        frame.columnconfigure(0, weight=1)
        self._entry_context_menu(entry)
        return entry

    def _build_tab_general(self, parent):
        body = self._settings_card(parent, "Application")
        self._settings_field(body, "App folder", self.folder_var, 0)
        ModernButton(body, text="Browse", command=self.pick_folder).grid(row=1, column=1, sticky="e", pady=(0,12))
        tk.Label(body, text="Resolved folder", font=FONT, bg=PANEL, fg=MUTED).grid(row=2, column=0, sticky="w")
        tk.Label(body, textvariable=self.target_var, font=FONT, bg=PANEL, fg=TEXT,
                 anchor="w", wraplength=680).grid(row=3, column=0, columnspan=2, sticky="w", pady=(3,4))
        body = self._settings_card(parent, 'Release import folder')
        tk.Label(body, textvariable=self.release_folder_path_var, bg=PANEL, fg=TEXT, font=FONT, anchor='w', wraplength=650).pack(fill='x')
        ModernButton(body, text='Choose Folder', command=self.choose_release_folder).pack(anchor='w', pady=(8, 0))
        body = self._settings_card(parent, "Completion sound")
        tk.Label(body, text="Selecting a sound plays a preview immediately.", bg=PANEL, fg=MUTED, font=FONT).pack(anchor="w")
        self._build_sound_settings(body)

    def _build_tab_cloudflare(self, parent):
        body = self._settings_card(parent, "Cloudflare Deployment")
        self._settings_field(body, "Worker name", self.worker_name_var, 0)
        self._settings_field(body, "Online URL", self.online_url_var, 2)
        actions = tk.Frame(body, bg=PANEL)
        actions.grid(row=4, column=0, sticky="w", pady=(3,0))
        for label, callback in (("Connect Cloudflare", self.cloudflare_login), ("Check online", self.check_online), ("Open online", self.open_online), ("Copy log", self.copy_log)):
            ModernButton(actions, text=label, command=callback).pack(side="left", padx=(0,8))
        body = self._settings_card(parent, "Connection status")
        tk.Label(body, textvariable=self.online_version_var, bg=PANEL, fg=ACCENT, font=FONT_B).pack(anchor="w")
        tk.Label(body, textvariable=self.cloudflare_status_var, bg=PANEL, fg=MUTED,
                 font=FONT, justify="left", wraplength=660).pack(anchor="w", pady=(5,0))

    def _build_tab_supabase(self, parent):
        body = self._settings_card(parent, "Supabase Diagnostics")
        tk.Label(body, textvariable=self.supabase_project_var, bg=PANEL, fg=ACCENT,
                 font=FONT_B, anchor="w").pack(fill="x", pady=(0,10))
        self.health_rows = {}
        for name in ("Auth", "Database", "login-with-id", "activate-user"):
            line = tk.Frame(body, bg=PANEL_2)
            line.pack(fill="x", pady=2)
            tk.Label(line, text=name, bg=PANEL_2, fg=TEXT, font=FONT_B).pack(side="left", padx=10, pady=8)
            value = tk.Label(line, text="Not checked", bg=PANEL_2, fg=MUTED, font=FONT)
            value.pack(side="right", padx=10)
            self.health_rows[name] = value
        for var in (self.supabase_status_var, self.supabase_cli_status_var):
            tk.Label(body, textvariable=var, bg=PANEL, fg=MUTED, font=FONT,
                     justify="left", wraplength=650).pack(anchor="w", pady=(6,0))
        actions = tk.Frame(body, bg=PANEL)
        actions.pack(fill="x", pady=(12,0))
        for label, cmd in (("Check Supabase", self.check_supabase), ("Change project", self.configure_supabase_project),
                           ("Open project", self.open_supabase_project), ("Copy diagnostics", self.copy_health_result)):
            ModernButton(actions, text=label, command=cmd).pack(side="left", padx=(0,7))

    def _build_tab_backup(self, parent):
        body = self._settings_card(parent, "Database Backup — PostgreSQL")
        tk.Label(body, text="Create a verified database archive without changing production data.",
                 bg=PANEL, fg=TEXT, font=FONT, anchor="w", wraplength=630).pack(anchor="w")
        tk.Label(body, text="Connection URI (temporary; never saved to updater settings)",
                 bg=PANEL, fg=MUTED, font=FONT).pack(anchor="w", pady=(12, 4))
        # The entry must be a child of its row to be visible on Windows.
        uri_row = tk.Frame(body, bg=PANEL)
        uri_row.pack(fill="x", pady=(0, 2))
        self._backup_uri = tk.Entry(uri_row, bg=PANEL_2, fg=TEXT, insertbackground=TEXT,
                                    font=FONT, relief="solid", bd=1,
                                    highlightthickness=1, highlightbackground=BORDER,
                                    highlightcolor=ACCENT, show="*")
        self._backup_uri.pack(side="left", fill="x", expand=True, ipady=9)
        ModernButton(uri_row, text="Paste", command=lambda: self._paste_into_entry(self._backup_uri)).pack(side="left", padx=(8, 0))
        self._entry_context_menu(self._backup_uri)
        self._backup_uri_visible = False
        def toggle_uri():
            self._backup_uri_visible = not self._backup_uri_visible
            self._backup_uri.configure(show="" if self._backup_uri_visible else "*")
            self._backup_uri_toggle.configure(text="Hide" if self._backup_uri_visible else "Show")
        self._backup_uri_toggle = ModernButton(uri_row, text="Show", command=toggle_uri)
        self._backup_uri_toggle.pack(side="left", padx=(8, 0))
        tk.Label(body, text="Database Password (temporary; never saved)",
                 bg=PANEL, fg=MUTED, font=FONT).pack(anchor="w", pady=(12, 4))
        password_row = tk.Frame(body, bg=PANEL)
        password_row.pack(fill="x", pady=(0, 2))
        self._backup_password = tk.Entry(password_row, bg=PANEL_2, fg=TEXT,
                        insertbackground=TEXT, font=FONT, relief="solid", bd=1,
                        highlightthickness=1, highlightbackground=BORDER,
                        highlightcolor=ACCENT, show="*")
        self._backup_password.pack(side="left", fill="x", expand=True, ipady=9)
        self._entry_context_menu(self._backup_password)
        self._backup_password_visible = False
        def toggle_password():
            self._backup_password_visible = not self._backup_password_visible
            self._backup_password.configure(show="" if self._backup_password_visible else "*")
            self._backup_password_toggle.configure(text="Hide" if self._backup_password_visible else "Show")
        self._backup_password_toggle = ModernButton(password_row, text="Show", command=toggle_password)
        self._backup_password_toggle.pack(side="left", padx=(8, 0))
        self._backup_uri.insert(0, self.cfg.get("backup_safe_uri", ""))
        try:
            encrypted = self.cfg.get("backup_password_dpapi", "")
            if encrypted and os.name == "nt":
                self._backup_password.insert(0, unprotect_windows_secret(encrypted))
        except Exception:
            self.backup_status_var.set("Saved password could not be unlocked; please enter it again.")
        tk.Label(body, text="Connection location can be saved without a password. Optional password storage uses Windows DPAPI for this user only.",
                 bg=PANEL, fg=MUTED, font=FONT, anchor="w", wraplength=650).pack(anchor="w", pady=(5, 0))
        credentials_row = tk.Frame(body, bg=PANEL)
        credentials_row.pack(fill="x", pady=(9, 0))
        ModernButton(credentials_row, text="Save connection", command=self.save_backup_connection).pack(side="left", padx=(0, 8))
        ModernButton(credentials_row, text="Save password securely", command=self.save_backup_password).pack(side="left", padx=(0, 8))
        ModernButton(credentials_row, text="Clear saved", command=self.clear_backup_credentials).pack(side="left")
        actions = tk.Frame(body, bg=PANEL)
        actions.pack(fill="x", pady=(12, 8))
        self._backup_button = ModernButton(actions, text="Create Backup", command=self.create_database_backup, primary=True)
        self._backup_button.pack(side="left", padx=(0, 8))
        ModernButton(actions, text="Verify Backup", command=self.verify_database_backup).pack(side="left", padx=(0, 8))
        ModernButton(actions, text="Locate tools", command=self._choose_postgres_tools).pack(side="left", padx=(0, 8))
        ModernButton(actions, text="Refresh", command=self._refresh_postgres_tools).pack(side="left", padx=(0, 8))
        ModernButton(actions, text="Get tools", command=lambda: webbrowser.open("https://www.postgresql.org/download/windows/")).pack(side="left")
        self._backup_tools_var = tk.StringVar(value=self._backup_tools_status())
        tk.Label(body, textvariable=self._backup_tools_var, bg=PANEL, fg=MUTED,
                 font=FONT, anchor="w").pack(fill="x", pady=(5, 6))
        tk.Label(body, textvariable=self.backup_status_var, bg=PANEL, fg=TEXT,
                 font=FONT, justify="left", wraplength=630).pack(anchor="w")
        last_body = self._settings_card(parent, "Last Backup")
        tk.Label(last_body, textvariable=self.last_backup_var, bg=PANEL, fg=TEXT,
                 font=FONT, justify="left", anchor="w", wraplength=650).pack(fill="x")
        ModernButton(last_body, text="Open Backup Folder", command=self.open_backup_folder).pack(anchor="w", pady=(10, 0))
        body = self._settings_card(parent, "Restore safety")
        tk.Label(body, text="Verification checks the archive and optional SHA-256 manifest. It does not restore data.\n"
                 "For recovery, use a separate target database and a reviewed pg_restore plan. "
                 "Restoring over production is intentionally unavailable in the updater.",
                 bg=PANEL, fg=MUTED, font=FONT, justify="left", wraplength=630).pack(anchor="w")
        tk.Label(body, text="Database archives may include sensitive resident and financial information. "
                 "Store them encrypted and separately from this computer. "
                 "Supabase Storage files and Cloudflare secrets are NOT included.",
                 bg=PANEL, fg=WARN, font=FONT, justify="left", wraplength=630).pack(anchor="w", pady=(12,0))

    def _postgres_tool(self, name):
        return tool_path(name, self.pg_bin_dir or None)

    def _backup_tools_status(self):
        dumper = self._postgres_tool("pg_dump")
        restore = self._postgres_tool("pg_restore")
        status = "PostgreSQL tools: " + ("pg_dump ready" if dumper else "pg_dump missing") + " / " + ("pg_restore ready" if restore else "pg_restore missing")
        if dumper and restore:
            status += "\nFolder: " + str(Path(dumper).parent)
        elif self.pg_bin_dir:
            status += "\nSelected folder is missing required executables. Select the bin folder."
        return status

    def _refresh_postgres_tools(self):
        self._backup_tools_var.set(self._backup_tools_status())

    def _choose_postgres_tools(self):
        folder = filedialog.askdirectory(parent=self.settings_window, title="Select PostgreSQL bin folder containing pg_dump.exe and pg_restore.exe")
        if not folder:
            return
        if not tool_path("pg_dump", folder) or not tool_path("pg_restore", folder):
            show_error("PostgreSQL tools", "This folder must contain both pg_dump and pg_restore executables. Choose the PostgreSQL bin folder.", parent=self.settings_window)
            return
        self.pg_bin_dir = folder
        self.cfg["postgresql_bin_dir"] = folder
        save_config(self.cfg)
        self._refresh_postgres_tools()
        messagebox.showinfo("PostgreSQL tools", "Tools found. Only their folder path was saved, not any database credentials.", parent=self.settings_window)

    def save_backup_connection(self):
        try:
            uri = safe_backup_uri(self._backup_uri.get())
        except (ValueError, OverflowError) as exc:
            show_error("Backup connection", str(exc), parent=self.settings_window)
            return
        self.cfg["backup_safe_uri"] = uri
        save_config(self.cfg)
        self.backup_status_var.set("Connection location saved without password or URL query parameters.")

    def save_backup_password(self):
        if os.name != "nt":
            show_error("Backup credentials", "Secure password storage requires Windows.", parent=self.settings_window)
            return
        password = self._backup_password.get()
        if not password:
            show_error("Backup credentials", "Enter a password to save first.", parent=self.settings_window)
            return
        try:
            self.cfg["backup_password_dpapi"] = protect_windows_secret(password)
            save_config(self.cfg)
            self.backup_status_var.set("Password protected for the current Windows account.")
        except Exception:
            show_error("Backup credentials", "Windows could not protect the credential. It was not saved.", parent=self.settings_window)

    def clear_backup_credentials(self):
        self.cfg.pop("backup_safe_uri", None)
        self.cfg.pop("backup_password_dpapi", None)
        save_config(self.cfg)
        self._backup_uri.delete(0, "end")
        self._backup_password.delete(0, "end")
        self.backup_status_var.set("Saved connection and password cleared.")

    def create_database_backup(self):
        if self._backup_busy or self._busy:
            show_error("النسخ الاحتياطي", "توجد عملية أخرى جارية؛ انتظر انتهائها أولًا.", parent=self.settings_window)
            return
        if not self._postgres_tool("pg_dump") or not self._postgres_tool("pg_restore"):
            show_error("Database Backup", "Install PostgreSQL client tools (pg_dump and pg_restore) first.", parent=self.settings_window)
            return
        raw_uri = self._backup_uri.get().strip()
        password = self._backup_password.get()
        try:
            uri = combine_connection_credentials(raw_uri, password)
        except BackupError as exc:
            show_error("النسخ الاحتياطي", str(exc), parent=self.settings_window)
            return
        import datetime
        suggested = "tower_database_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + ".dump"
        output = filedialog.asksaveasfilename(parent=self.settings_window, title="Save database backup",
                   initialfile=suggested, defaultextension=".dump", filetypes=[("PostgreSQL custom backup", "*.dump")])
        if not output: return
        if Path(output).exists():
            show_error("Database Backup", "Choose a new filename. Existing backups cannot be overwritten.", parent=self.settings_window)
            return
        self._backup_busy = True
        self._backup_button.configure(state="disabled")
        self.backup_status_var.set("Backup running... do not close the updater. No percentage is available.")
        self._backup_uri.delete(0, "end")
        self._backup_password.delete(0, "end")
        def run():
            try:
                info = create_backup(uri, output, pg_dump=self._postgres_tool("pg_dump"), pg_restore=self._postgres_tool("pg_restore"))
                result = "Backup verified. Size: {:,} bytes. SHA-256: {}\nSaved: {}".format(info['size_bytes'], info['sha256'], output)
                self.after(0, lambda path=output, details=info, msg=result: self._backup_complete(msg, True, path, details))
            except Exception as exc:
                msg = str(exc) if isinstance(exc, BackupError) else "Backup failed. Check disk space and database client tools."
                self.after(0, lambda m=msg: self._backup_complete(m, False))
        threading.Thread(target=run, daemon=True, name="TowerDatabaseBackup").start()

    def _backup_complete(self, result, success, path=None, details=None):
        self._backup_busy = False
        self.backup_status_var.set(result)
        if getattr(self, "_backup_button", None) and self._backup_button.winfo_exists():
            self._backup_button.configure(state="normal")
        if success:
            if path and details:
                from datetime import datetime
                self.cfg["last_verified_backup"] = {
                    "path": str(Path(path).resolve()),
                    "created_at": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z"),
                }
                save_config(self.cfg)
                self.last_backup_var.set(backup_summary(self.cfg["last_verified_backup"]))
            messagebox.showinfo("Database Backup", "Backup created and verified. Keep it in encrypted storage.", parent=self.settings_window)
        else:
            show_error("Database Backup", result, parent=self.settings_window)

    def open_backup_folder(self):
        record = self.cfg.get("last_verified_backup") or {}
        raw = record.get("path", "") if isinstance(record, dict) else ""
        target = Path(raw) if raw else None
        if target and target.is_file():
            if os.name == "nt":
                try:
                    subprocess.Popen(["explorer.exe", "/select," + str(target)])
                    return
                except OSError:
                    pass
            folder = target.parent
        elif target and target.parent.is_dir():
            folder = target.parent
            self.backup_status_var.set("The last backup file is missing; opening its saved folder.")
        else:
            folder = None
        if folder and folder.is_dir():
            try:
                if os.name == "nt":
                    os.startfile(str(folder))
                else:
                    raise OSError("Windows Explorer unavailable")
                return
            except OSError:
                pass
        messagebox.showinfo("Backup folder", "Last backup folder is not available. Choose the folder to open.", parent=self.settings_window)
        selected = filedialog.askdirectory(parent=self.settings_window, title="Locate backup folder")
        if selected and os.name == "nt":
            try:
                os.startfile(selected)
            except OSError:
                show_error("Backup folder", "Could not open the selected folder.", parent=self.settings_window)

    def verify_database_backup(self):
        path = filedialog.askopenfilename(parent=self.settings_window, title="Verify PostgreSQL backup",
                    filetypes=[("PostgreSQL backup", "*.dump"), ("All files", "*.*")])
        if not path: return
        def run():
            try:
                detail = inspect_backup(path, pg_restore=self._postgres_tool("pg_restore"))
                result = "Verified archive: {:,} bytes / SHA-256: {} / {} TOC entries".format(detail['bytes'], detail['sha256'], detail['toc_entries'])
            except Exception as exc:
                result = str(exc) if isinstance(exc, BackupError) else "Verification failed."
            self.after(0, lambda r=result: self.backup_status_var.set(r))
        self.backup_status_var.set("Verifying archive...")
        threading.Thread(target=run, daemon=True, name="TowerBackupVerify").start()

    def _build_tab_diagnostics(self, parent):
        body = self._settings_card(parent, "Deployment status")
        tk.Label(body, textvariable=self.status_var, bg=PANEL, fg=MUTED,
                 font=FONT, justify="left", wraplength=660).pack(anchor="w")
        body = self._settings_card(parent, "Tools")
        tools = (("Open app folder", self.open_folder), ("Restart local server", self.restart_server),
                 ("Install in Start Menu", self.install_start_menu), ("Copy deployment log", self.copy_log),
                 ("Copy diagnostics", self.copy_health_result))
        for i, (label, cmd) in enumerate(tools):
            ModernButton(body, text=label, command=cmd).grid(row=i//2, column=i%2, padx=(0,10), pady=5, sticky="ew")
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)

    def _windows_sounds(self):
        """Read event sounds from current Windows event schema without writing registry."""
        if os.name != "nt": return []
        found = []
        root = r"AppEvents\Schemes\Apps"
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, root) as apps:
                ai = 0
                while True:
                    try: app = winreg.EnumKey(apps, ai); ai += 1
                    except OSError: break
                    with winreg.OpenKey(apps, app) as events:
                        ei = 0
                        while True:
                            try: event = winreg.EnumKey(events, ei); ei += 1
                            except OSError: break
                            for branch in (".Current", ".Default"):
                                try:
                                    with winreg.OpenKey(events, event + "\\" + branch) as key:
                                        path = os.path.expandvars(str(winreg.QueryValueEx(key, "")[0])).strip()
                                        if path and Path(path).is_file() and path.lower().endswith(".wav"):
                                            item = (event.replace("_", " "), path)
                                            if item not in found: found.append(item)
                                            break
                                except OSError: pass
        except OSError: pass
        return found

    def _build_sound_settings(self, outer):
        card = outer
        self._sound_map = {}
        self._sound_labels = ["No sound"]
        self._sound_map["No sound"] = ""
        for title, path in self._windows_sounds():
            if path.lower().endswith("silent.wav") or not path or path in self._sound_map.values():
                continue
            label = f"{title} — {Path(path).stem}"
            if label in self._sound_map: continue
            self._sound_map[label] = path
            self._sound_labels.append(label)
        selected_path = self.sound_choice.get()
        chosen = next((label for label,path in self._sound_map.items() if path == selected_path), "No sound")
        self.sound_label = tk.StringVar(value=chosen)
        line = tk.Frame(card, bg=PANEL)
        line.pack(fill="x", pady=(10, 2))
        picker = tk.OptionMenu(line, self.sound_label, *self._sound_labels, command=self._select_sound_label)
        picker.config(font=FONT, bg=PANEL_2, fg=TEXT, activebackground=ACCENT, activeforeground="white", relief="flat", highlightthickness=0)
        picker["menu"].config(font=FONT, bg=PANEL_2, fg=TEXT, activebackground=ACCENT, activeforeground="white")
        picker.pack(side="left", fill="x", expand=True, padx=(0,8))
        ModernButton(line, text="▶ Preview", command=lambda: self.preview_sound(self._sound_map.get(self.sound_label.get(), ""))).pack(side="right")
        if len(self._sound_labels) == 1:
            tk.Label(card, text="No Windows sounds detected.", bg=PANEL, fg=WARN, font=FONT).pack(anchor="w", pady=(0,10))

    def _select_sound_label(self, label):
        self.select_sound(self._sound_map.get(label, ""))

    def preview_sound(self, path):
        if not path: return
        try:
            winsound.PlaySound(str(path), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
        except Exception as exc:
            show_error("معاينة الصوت", str(exc), parent=self)

    def select_sound(self, path):
        self.cfg["finish_sound"] = path
        save_config(self.cfg)
        self.preview_sound(path)

    def _play_completion_sound(self):
        path = self.cfg.get("finish_sound", "")
        if path and Path(path).is_file():
            self.preview_sound(path)

    def _register_drop_tree(self, widget):
        if not DND_AVAILABLE: return
        try:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", self._on_file_drop)
        except Exception: pass
        for child in widget.winfo_children():
            self._register_drop_tree(child)

    # ---------- Target ----------
    def pick_folder(self):
        p = filedialog.askdirectory(title="Select Tower App folder")
        if not p:
            return
        self.folder_var.set(p)
        self.cfg["app_folder"] = p
        save_config(self.cfg)
        self._refresh_target()

    def _refresh_target(self):
        raw = Path(self.folder_var.get().strip()) if self.folder_var.get().strip() else None
        if not raw or not raw.exists():
            self.target_folder = None
            self.target_var.set("—")
            self.current_version_var.set("—")
            return
        target = find_app_root(raw)
        self.target_folder = target
        self.target_var.set(str(target))
        self.current_version_var.set(read_version(target))
        # Always display the resolved folder to help diagnose multiple local installations.
        self.local_folder_hint = str(target)

    # ---------- New Supabase project connection (public values only) ----------
    def _public_supabase_values(self):
        url = (self.cfg.get("supabase_url") or "").strip().rstrip("/")
        key = (self.cfg.get("supabase_publishable_key") or "").strip()
        if not url and not key:
            return None
        if not re.fullmatch(r"https://[a-z0-9]{20}\.supabase\.co", url):
            raise RuntimeError("Invalid Supabase project URL. Exclude /rest/v1/.")
        if not (key.startswith("sb_publishable_") or (key.startswith("eyJ") and len(key) > 50)):
            raise RuntimeError("Enter the public publishable key (not a secret or service_role).")
        return url, key

    def _sync_public_supabase_config(self, file_path):
        credentials = self._public_supabase_values()
        if not credentials or not file_path.exists():
            return
        url, key = credentials
        content = file_path.read_text(encoding="utf-8")
        url_pattern = r"(?m)^\s*const\s+URL\s*=\s*\"[^\"]*\"\s*;?"
        key_pattern = r"(?m)^\s*const\s+KEY\s*=\s*\"[^\"]*\"\s*;?"
        url_line = 'const URL = ' + json.dumps(url) + ';'
        key_line = 'const KEY = ' + json.dumps(key) + ';'
        if re.search(url_pattern, content):
            content = re.sub(url_pattern, lambda _: url_line, content, count=1)
        else:
            content = url_line + "\n" + content
        if re.search(key_pattern, content):
            content = re.sub(key_pattern, lambda _: key_line, content, count=1)
        else:
            content = key_line + "\n" + content
        file_path.write_text(content, encoding="utf-8")

    def configure_supabase_project(self):
        popup = tk.Toplevel(self)
        popup.title("Change Supabase project")
        popup.configure(bg=BG)
        popup.geometry("660x280")
        popup.transient(self)
        popup.grab_set()
        tk.Label(popup, text="New project URL", bg=BG, fg=TEXT, font=FONT_B).pack(anchor="e", padx=22, pady=(16, 4))
        url_var = tk.StringVar(value=self.cfg.get("supabase_url") or "https://kytxiisylwubyrxpbxal.supabase.co")
        url_entry = tk.Entry(popup, textvariable=url_var, bg=PANEL_2, fg=TEXT, insertbackground=TEXT, font=FONT)
        url_entry.pack(fill="x", padx=22, ipady=6)
        tk.Label(popup, text="Public publishable key from Supabase → Project Settings → API Keys", bg=BG, fg=TEXT, font=FONT_B).pack(anchor="e", padx=22, pady=(12, 4))
        key_var = tk.StringVar(value=self.cfg.get("supabase_publishable_key", ""))
        key_entry = tk.Entry(popup, textvariable=key_var, bg=PANEL_2, fg=TEXT, insertbackground=TEXT, font=FONT)
        key_entry.pack(fill="x", padx=22, ipady=6)
        tk.Label(popup, text="Never enter service_role or secret keys here; Worker secrets stay in Cloudflare.", bg=BG, fg=MUTED, font=FONT).pack(anchor="e", padx=22, pady=(12, 8))
        def submit():
            old_url = self.cfg.get("supabase_url")
            old_key = self.cfg.get("supabase_publishable_key")
            self.cfg["supabase_url"] = url_var.get().strip().rstrip("/")
            self.cfg["supabase_publishable_key"] = key_var.get().strip()
            try:
                self._public_supabase_values()
                self._refresh_target()
                if self.target_folder and (self.target_folder / "app.js").exists():
                    self._sync_public_supabase_config(self.target_folder / "app.js")
            except Exception as exc:
                if old_url is None: self.cfg.pop("supabase_url", None)
                else: self.cfg["supabase_url"] = old_url
                if old_key is None: self.cfg.pop("supabase_publishable_key", None)
                else: self.cfg["supabase_publishable_key"] = old_key
                show_error("Supabase", str(exc), parent=popup)
                return
            save_config(self.cfg)
            self.supabase_status_var.set("Local folder linked to the new Supabase project. Run Supabase diagnostics.")
            popup.destroy()
        tk.Button(popup, text="Save and connect new project", command=submit, bg=ACCENT, fg="white", font=FONT_B).pack(pady=8)
        url_entry.focus_set()

    # ---------- Supabase connection check ----------
    def _read_supabase_config(self):
        self._refresh_target()
        if not self.target_folder:
            raise RuntimeError("Select a Tower App folder first.")
        app_file = self.target_folder / "app.js"
        if not app_file.exists():
            raise RuntimeError("app.js is missing from the resolved folder.")
        self._sync_public_supabase_config(app_file)
        txt = app_file.read_text(encoding="utf-8", errors="ignore")
        um = re.search(r'const\s+URL\s*=\s*[\'\"](https://[^\'\"]+)[\'\"]', txt)
        km = re.search(r'const\s+KEY\s*=\s*[\'\"]([^\'\"]+)[\'\"]', txt)
        if not um or not km:
            raise RuntimeError("Supabase URL / publishable key not found in app.js.")
        url = um.group(1).rstrip('/')
        key = km.group(1).strip()
        return url, key

    def _http_probe(self, url, key, path, method="GET", body=None, ok_under_500=False):
        data = None
        headers = {"apikey": key, "Authorization": f"Bearer {key}", "Accept": "application/json"}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=9) as res:
                code = int(res.getcode() or 0)
                return (code < 500 if ok_under_500 else 200 <= code < 300), code
        except urllib.error.HTTPError as e:
            code = int(e.code or 0)
            return (code < 500 if ok_under_500 else False), code
        except Exception:
            return False, 0

    def _set_health_row(self, name, ok, code, detail=""):
        widget = getattr(self, "health_rows", {}).get(name)
        if not widget:
            return
        color = GOOD if ok else BAD
        prefix = "✓" if ok else "✕"
        text_value = detail or ("Healthy" if ok else "Issue")
        if code:
            text_value += f" · {code}"
        widget.config(text=f"{prefix} {text_value}", fg=color)

    def copy_health_result(self):
        text_value = (self.last_health_result or "").strip()
        if not text_value:
            messagebox.showinfo("Check Supabase", "Run Supabase diagnostics first.")
            return
        try:
            self.clipboard_clear()
            self.clipboard_append(text_value)
            self.update()
            self.status_var.set("Diagnostics copied without credentials.")
        except Exception as e:
            show_error("Copy result", str(e))

    def check_supabase(self):
        try:
            url, key = self._read_supabase_config()
        except Exception as e:
            self.supabase_project_var.set("Not connected")
            self.supabase_status_var.set(str(e))
            for name in ["Auth", "Database", "login-with-id", "activate-user"]:
                self._set_health_row(name, False, 0, "Not reachable")
            self.last_health_result = f"Tower Supabase Updater v{UPDATER_VERSION}\nSupabase: CONFIG ERROR\nDetails: {e}"
            show_error("Check Supabase", str(e))
            return

        project_ref = re.sub(r'^https://|\.supabase\.co.*$', '', url)
        self.supabase_project_var.set(f"Project Ref: {project_ref}")
        self.supabase_status_var.set("Checking Auth / Database / Edge Functions…")
        self.status_var.set("Checking Supabase connection…")
        for name in ["Auth", "Database", "login-with-id", "activate-user"]:
            widget = self.health_rows.get(name)
            if widget:
                widget.config(text="Running checks…", fg=WARN)

        def worker():
            auth_ok, auth_code = self._http_probe(url, key, "/auth/v1/settings", ok_under_500=True)
            db_ok, db_code = self._http_probe(url, key, "/rest/v1/units?select=id&limit=1", ok_under_500=True)
            login_ok, login_code = self._http_probe(url, key, "/functions/v1/login-with-id", method="POST", body={"login_id":"__tower_updater_healthcheck__","pin":"000000"}, ok_under_500=True)
            activate_ok, activate_code = self._http_probe(url, key, "/functions/v1/activate-user", method="POST", body={}, ok_under_500=True)

            def describe(code, ok):
                if not ok:
                    return "Network/Server error"
                if code in (401, 403):
                    return "Connected · authentication required"
                if code == 400:
                    return "Connected · expected probe response"
                if 200 <= code < 300:
                    return "Healthy"
                return "Endpoint reachable"

            results = {
                "Auth": (auth_ok, auth_code),
                "Database": (db_ok, db_code),
                "login-with-id": (login_ok, login_code),
                "activate-user": (activate_ok, activate_code),
            }
            all_reachable = all(ok for ok, _ in results.values())
            sanitized = [
                f"Tower Supabase Updater v{UPDATER_VERSION}",
                f"Tower App: {self.current_version_var.get()}",
                f"Project Ref: {project_ref}",
            ]
            for name, (ok, code) in results.items():
                sanitized.append(f"{name}: {'OK' if ok else 'FAIL'} ({code or 'network'}) - {describe(code, ok)}")
            sanitized.append(f"Overall: {'CONNECTED' if all_reachable else 'NEEDS REVIEW'}")

            def finish():
                for name, (ok, code) in results.items():
                    self._set_health_row(name, ok, code, describe(code, ok))
                self.last_health_result = "\n".join(sanitized)
                if all_reachable:
                    self.supabase_status_var.set("All Supabase endpoints reachable. HTTP 400/401/403 may be expected without login.")
                    self.status_var.set(f"✓ Local folder linked to Supabase project\nProject: {project_ref}\nChecks send no sensitive data and make no changes.")
                else:
                    self.supabase_status_var.set("An endpoint was unreachable. Copy diagnostics for review.")
                    self.status_var.set("Supabase connection needs review.")
            self.after(0, finish)

        threading.Thread(target=worker, name="SupabaseHealth", daemon=True).start()

    def open_supabase_project(self):
        try:
            url, _ = self._read_supabase_config()
            project_ref = re.sub(r'^https://|\.supabase\.co.*$', '', url)
            webbrowser.open(f"https://supabase.com/dashboard/project/{project_ref}")
        except Exception as e:
            show_error("Supabase", str(e))

    # ---------- ZIP ----------
    def choose_zip(self):
        if self._busy or self._backup_busy or self._selecting:
            return
        path = filedialog.askopenfilename(parent=self, title='Select Tower App release ZIP', initialdir=self.cfg.get('release_zip_folder') or None, filetypes=[('Release ZIP', '*.zip')])
        if path:
            self.stage_zip(Path(path))

    def stage_zip(self, zip_path, auto=False, start_update=False):
        if self._busy or self._backup_busy:
            return
        self._selection_id += 1
        selection_id = self._selection_id
        self._selecting = True
        self.selected_zip = None
        self.new_version_var.set('—')
        self.update_btn.config(state='disabled')
        self.auto_import_btn.config(state='disabled')
        self.release_file_var.set('جاري فحص الحزمة…')
        self.drop_title.config(text='Checking release…', fg=ACCENT)
        self.progress_area.pack_forget()
        self.status_var.set('جاري البحث عن أحدث إصدار متوافق…' if auto else 'جاري فحص سلامة الحزمة وتوافقها…')
        folder = self.cfg.get('release_zip_folder')
        def worker():
            try:
                if auto:
                    path, info, skipped = latest_release(folder, lambda p: validate_release(p, inspect_zip))
                else:
                    path = Path(zip_path)
                    info = validate_release(path, inspect_zip)
                    skipped = 0
                size = path.stat().st_size
                def success():
                    if selection_id != self._selection_id:
                        return
                    self._selecting = False
                    self.selected_zip = path
                    self.new_version_var.set(info['version'])
                    self.release_file_var.set(path.name+'  ·  '+f'{size/1024:,.0f} KB')
                    self.drop_title.config(text='✓ Selected release', fg=GOOD)
                    self.drop.config(highlightbackground=GOOD)
                    self.deploy_stage_var.set('الحزمة جاهزة — يبدأ Auto Update الآن.' if start_update else 'الحزمة جاهزة — اضغط Manual Update للرفع.')
                    self.status_var.set('تم تجهيز الحزمة.'+(f' تم تجاهل {skipped} حزمة غير صالحة.' if skipped else ''))
                    self.auto_import_btn.config(state='normal')
                    self.update_btn.config(state='normal')
                    self._refresh_comparison()
                    if start_update:
                        if self._busy or self._backup_busy:
                            self.status_var.set('الحزمة جاهزة، لكن توجد عملية أخرى جارية؛ انتظر ثم اضغط Manual Update.')
                            return
                        self.update_project_all()
                self._post_ui(success)
            except Exception as exc:
                detail = str(exc)
                def failure():
                    if selection_id != self._selection_id:
                        return
                    self._selecting = False
                    self.auto_import_btn.config(state='normal')
                    self.selected_zip = None
                    self.new_version_var.set('—')
                    self.drop_title.config(text='✕ Invalid release', fg=BAD)
                    self.release_file_var.set('اختَر حزمة تشغيل متوافقة.')
                    self.drop.config(highlightbackground=BAD)
                    self.status_var.set('تعذر تجهيز الملف؛ لم يبدأ أي تحديث.')
                    show_error('استيراد الحزمة', detail, parent=self)
                self._post_ui(failure)
        threading.Thread(target=worker, daemon=True, name='TowerReleaseSelection').start()

    def apply_selected_update(self):
        if not self.selected_zip:
            self.choose_zip()
            if not self.selected_zip:
                return

        self._refresh_target()
        if not self.target_folder or not (self.target_folder / "index.html").exists() or not (self.target_folder / "app.js").exists():
            show_error("Invalid folder", "Select folder containing index.html and app.js.")
            return

        try:
            info = inspect_zip(self.selected_zip)
            old_v = read_version(self.target_folder)
            new_v = info["version"]

            old_t = semver_tuple(old_v)
            new_t = semver_tuple(new_v)
            # Explicitly selected older versions are allowed; no version-only confirmation.

            self.status_var.set(f"Updating: {old_v} → {new_v} ...")
            self.update_idletasks()

            tmp = self.target_folder.parent / "_tower_update_tmp"
            if tmp.exists():
                shutil.rmtree(tmp)
            tmp.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(self.selected_zip, "r") as z:
                safe_extract_zip(self.selected_zip, tmp)

            # Locate extracted app root using known ZIP structure.
            src = tmp
            if info["root_parts"]:
                candidate = tmp.joinpath(*info["root_parts"])
                if candidate.exists():
                    src = candidate
            else:
                src = find_app_root(tmp)

            if not (src / "index.html").exists() or not (src / "app.js").exists():
                src = find_app_root(tmp)

            if not (src / "index.html").exists() or not (src / "app.js").exists():
                raise RuntimeError("Could not locate update root inside ZIP.")

            # Copy files atomically-ish: temp per file then replace.
            copied = []
            for item in src.iterdir():
                dest = self.target_folder / item.name
                if item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                else:
                    temp_dest = dest.with_suffix(dest.suffix + ".update_tmp")
                    shutil.copy2(item, temp_dest)
                    os.replace(temp_dest, dest)
                copied.append(item.name)

            shutil.rmtree(tmp, ignore_errors=True)

            # Record installed release explicitly: do not infer it from
            # old HTML comments or from embedded V1.13.0 reference content.
            if new_v != "Unknown":
                marker = self.target_folder / "tower-version.json"
                temp_marker = marker.with_suffix(".json.update_tmp")
                temp_marker.write_text(json.dumps({"version": new_v}, ensure_ascii=False), encoding="utf-8")
                os.replace(temp_marker, marker)
            actual_v = read_version(self.target_folder)
            if semver_tuple(actual_v) != semver_tuple(new_v) and new_v != "Unknown":
                raise RuntimeError(
                    f"Files copied, but resulting version is {actual_v} instead of {new_v}.\n"
                    "Check resolved folder shown in the app."
                )

            # Restart server automatically.
            self.stop_server(silent=True)
            time.sleep(0.25)
            self.start_server(open_browser=False)

            self.current_version_var.set(actual_v)
            self.status_var.set(
                f"Update completed ✓\n{old_v} → {actual_v}\n"
                f"Folder: {self.target_folder}"
            )
            self.drop.config(highlightbackground=GOOD)
            self.drop_title.config(text="Update completed")
            self.drop_sub.config(text="You can drop another update ZIP.")
            self.new_version_var.set(actual_v)

            self.after(450, self.open_browser_cache_bust)

        except Exception as e:
            self.status_var.set(f"Update failed:\n{e}")
            self.drop.config(highlightbackground=BAD)
            show_error("Update failed", str(e))

    # ---------- Server ----------
    def _port(self):
        try:
            p = int(self.port_var.get())
            if not 1 <= p <= 65535:
                raise ValueError
            return p
        except Exception:
            return DEFAULT_PORT

    def _port_available(self, port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("127.0.0.1", int(port)))
            return True
        except OSError:
            return False

    def _choose_server_port(self, preferred):
        preferred = int(preferred)
        if self._port_available(preferred):
            return preferred
        for p in range(preferred + 1, min(preferred + 51, 65535)):
            if self._port_available(p):
                return p
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])

    def _server_health(self, port, attempts=12):
        url = f"http://127.0.0.1:{port}/index.html?health={int(time.time())}"
        last_error = ""
        for _ in range(attempts):
            try:
                req = urllib.request.Request(url, headers={"Cache-Control":"no-cache"})
                with urllib.request.urlopen(req, timeout=1.5) as res:
                    code = int(res.getcode() or 0)
                    body = res.read(128)
                    if 200 <= code < 400 and body:
                        return True, code, ""
            except Exception as e:
                last_error = str(e)
            time.sleep(0.18)
        return False, 0, last_error

    def start_server(self, open_browser=True):
        self._refresh_target()
        if not self.target_folder:
            show_error("Invalid folder", "Select a Tower App folder first.")
            return

        if self.httpd is not None and self.server_port:
            ok, _, _ = self._server_health(self.server_port, attempts=2)
            if ok:
                if open_browser:
                    self.open_browser_cache_bust()
                return
            self.stop_server(silent=True)

        preferred = self._port()
        port = self._choose_server_port(preferred)
        try:
            root = str(self.target_folder)

            class QuietHandler(SimpleHTTPRequestHandler):
                def log_message(self, format, *args):
                    return

            handler = lambda *args, **kwargs: QuietHandler(*args, directory=root, **kwargs)
            self.httpd = ThreadingHTTPServer(("127.0.0.1", port), handler)
            self.httpd.daemon_threads = True
            self.server_port = port
            self.server_thread = threading.Thread(target=self.httpd.serve_forever, name="TowerLocalServer", daemon=True)
            self.server_thread.start()

            ok, code, error = self._server_health(port)
            if not ok:
                try:
                    self.httpd.shutdown(); self.httpd.server_close()
                except Exception:
                    pass
                self.httpd = None
                self.server_thread = None
                self.server_port = None
                raise RuntimeError(f"Server started but did not serve index.html. {error or 'No response'}")

            self.port_var.set(str(port))
            self.cfg["app_folder"] = str(self.target_folder)
            self.cfg["port"] = port
            save_config(self.cfg)
            port_note = "" if port == preferred else f"\nPort {preferred} was busy; opened browser {port} automatically."
            self.status_var.set(f"✓ Local server responding ({code})\nhttp://127.0.0.1:{port}/index.html\n{self.target_folder}{port_note}")
            if open_browser:
                self.after(120, self.open_browser_cache_bust)
        except Exception as e:
            self.httpd = None
            self.server_thread = None
            self.server_port = None
            self.status_var.set(f"✕ Could not start local server\n{e}")
            show_error("Could not start server", str(e))

    def stop_server(self, silent=False):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None
            self.server_thread = None
            self.server_port = None
            if not silent:
                self.status_var.set("Server stopped.")

    def restart_server(self):
        self.stop_server(silent=True)
        self.after(250, self.start_server)

    def open_browser_cache_bust(self):
        port = self.server_port or self._port()
        if self.httpd is None:
            self.start_server(open_browser=True)
            return
        ok, _, _ = self._server_health(port, attempts=2)
        if not ok:
            self.stop_server(silent=True)
            self.start_server(open_browser=True)
            return
        webbrowser.open(f"http://127.0.0.1:{port}/index.html?v={int(time.time())}")

    def open_folder(self):
        self._refresh_target()
        if not self.target_folder:
            return
        if os.name == "nt":
            os.startfile(str(self.target_folder))

    # ---------- Unified Local + Online + Supabase update ----------
    def _project_ref(self):
        url, _ = self._read_supabase_config()
        return re.sub(r'^https://|\.supabase\.co.*$', '', url)

    def _supabase_npx(self):
        return shutil.which("npx.cmd") or shutil.which("npx")

    def supabase_login(self):
        npx = self._supabase_npx()
        if not npx:
            show_error(
                "Supabase CLI",
                "Node.js / npx is not installed.\n\nInstall Node.js LTS and restart the updater."
            )
            return
        try:
            flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen([npx, "--yes", "supabase@latest", "login"], creationflags=flags)
            self.supabase_cli_status_var.set("Supabase CLI login opened. Finish login in the browser and return.")
        except Exception as e:
            show_error("Supabase CLI", str(e))

    def _apply_local_update_core(self):
        if not self.selected_zip:
            raise RuntimeError("Select an update ZIP first.")
        self._refresh_target()
        if not self.target_folder or not (self.target_folder / "index.html").exists() or not (self.target_folder / "app.js").exists():
            raise RuntimeError("Select folder containing index.html and app.js.")

        info = inspect_zip(self.selected_zip)
        old_v = read_version(self.target_folder)
        new_v = info["version"]
        old_t, new_t = semver_tuple(old_v), semver_tuple(new_v)
        # V1.5.2: intentional downgrade is allowed.
        # The confirmation/warning is handled by the caller; never reject the ZIP only
        # because its Tower App version is lower than the currently installed version.

        tmp = self.target_folder.parent / "_tower_update_tmp"
        if tmp.exists(): shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(self.selected_zip, "r") as z:
            safe_extract_zip(self.selected_zip, tmp)

        src = tmp
        if info["root_parts"]:
            candidate = tmp.joinpath(*info["root_parts"])
            if candidate.exists(): src = candidate
        else:
            src = find_app_root(tmp)
        if not (src / "index.html").exists() or not (src / "app.js").exists():
            src = find_app_root(tmp)
        if not (src / "index.html").exists() or not (src / "app.js").exists():
            shutil.rmtree(tmp, ignore_errors=True)
            raise RuntimeError("Could not locate update root inside ZIP.")

        for item in src.iterdir():
            dest = self.target_folder / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                temp_dest = dest.with_suffix(dest.suffix + ".update_tmp")
                shutil.copy2(item, temp_dest)
                os.replace(temp_dest, dest)
        shutil.rmtree(tmp, ignore_errors=True)
        self._sync_public_supabase_config(self.target_folder / "app.js")
        # Full-project updates must persist the package version just like Local updates.
        # Reading embedded legacy V1.13.0 comments is not a valid post-copy check.
        if new_v != "Unknown":
            marker = self.target_folder / "tower-version.json"
            temp_marker = marker.with_suffix(".json.update_tmp")
            temp_marker.write_text(json.dumps({"version": new_v}, ensure_ascii=False), encoding="utf-8")
            os.replace(temp_marker, marker)
        actual_v = read_version(self.target_folder)
        if semver_tuple(actual_v) != semver_tuple(new_v) and new_v != "Unknown":
            raise RuntimeError(f"Local version after copying is {actual_v} instead of {new_v}.")
        return old_v, actual_v

    def _verify_worker_online(self, url, expected_version=None):
        if not url or not url.startswith("https://"):
            raise RuntimeError("HTTPS online URL required for post-deploy checks.")
        endpoint = url.rstrip("/") + "/api/health"
        detail = ""
        for attempt in range(12):
            try:
                # Verify the same path with a unique cache-busting query on each poll.
                check_url = endpoint + "?verify=" + str(time.time_ns()) + "-" + str(attempt)
                req = urllib.request.Request(check_url, headers={"Accept": "application/json", "Cache-Control": "no-store, no-cache", "Pragma": "no-cache", "User-Agent": "TowerUpdater/1.7.0"})
                with urllib.request.urlopen(req, timeout=12) as res:
                    code = res.getcode()
                    raw = res.read(8192).decode("utf-8", errors="replace")
                    try:
                        payload = json.loads(raw)
                    except (ValueError, TypeError):
                        payload = None
                    if code == 200 and isinstance(payload, dict) and payload.get("ok") is True:
                        actual = str(payload.get("version", ""))
                        if expected_version and actual and actual.lstrip("vV") != str(expected_version).lstrip("vV"):
                            detail = f"Deployed API version {actual} does not match ZIP version {expected_version}"
                        else:
                            return actual or "OK"
                    else:
                        detail = f"HTTP {code}; Content-Type={res.headers.get('Content-Type','?')}; Body={raw[:320]!r}"
            except urllib.error.HTTPError as exc:
                raw = exc.read(4096).decode("utf-8", errors="replace")
                detail = (f"HTTP {exc.code}; Server={exc.headers.get('Server','?')}; "
                          f"Content-Type={exc.headers.get('Content-Type','?')}; "
                          f"CF-Ray={exc.headers.get('CF-Ray','?')}; Body={raw[:320]!r}")
            except Exception as exc:
                detail = f"{type(exc).__name__}: {str(exc)[:240]}"
            if attempt < 11:
                time.sleep(3)
        raise RuntimeError("Backend post-deploy check failed. " + endpoint + " — " + detail + ". Deployment command succeeded but propagation was not confirmed. Check online version later; do not retry upload automatically.")

    def _preflight_worker_bundle(self, npx, deploy_root):
        """Reject Wrangler builds without executable Worker source before touching production."""
        output_dir = deploy_root / "_wrangler_preflight"
        cmd = [npx, "--yes", "wrangler@latest", "deploy", "--dry-run",
               "--outdir", str(output_dir), "--config", str(deploy_root / "wrangler.jsonc")]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(cmd, cwd=str(deploy_root), capture_output=True,
                                text=True, timeout=180, creationflags=flags)
        output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        if result.returncode != 0:
            raise RuntimeError("Cloudflare Worker build failed before deployment: " + output[-1600:])
        bundles = [f for f in output_dir.rglob("*.js") if f.is_file()]
        # The generated Worker must carry both API endpoints, not just an asset manifest.
        valid = any("/api/health" in f.read_text(encoding="utf-8", errors="replace")
                    and "/api/tower" in f.read_text(encoding="utf-8", errors="replace")
                    for f in bundles)
        if not valid:
            raise RuntimeError("Deployment blocked: Wrangler produced static assets without a backend. "
                               "No files were uploaded to Cloudflare. "
                               "Build output: " + output[-1000:])
        return output

    def _deploy_cloudflare_core(self):
        if not self.save_online_settings(silent=True):
            raise RuntimeError("Check online URL and Worker name.")
        npx = self._npx_path()
        if not npx:
            raise RuntimeError("Node.js / npx missing. Install Node.js LTS, then connect Cloudflare.")
        deploy_root, source_version, _ = self._prepare_cloudflare_assets()
        try:
            self._ensure_health_kv_binding(npx, deploy_root)
            self._preflight_worker_bundle(npx, deploy_root)
            cmd = [npx, "--yes", "wrangler@latest", "deploy", "--config", str(deploy_root / "wrangler.jsonc")]
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            result = subprocess.run(cmd, cwd=str(deploy_root), capture_output=True, text=True, timeout=300, creationflags=flags)
            output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
            diagnostics_file = Path.home() / "tower-cloudflare-deploy.log"
            diagnostics_file.write_text(
                "Tower Supabase Updater " + UPDATER_VERSION + "\n" +
                "Worker: " + self.worker_name_var.get().strip() + "\n" +
                "Package version: " + str(source_version) + "\n" +
                "Wrangler exit code: " + str(result.returncode) + "\n" + sanitize(output[-12000:]),
                encoding="utf-8"
            )
            if result.returncode != 0:
                raise RuntimeError(output[-1800:] or "Cloudflare deploy failed")
            if hasattr(self, '_mark_cloudflare_uploaded'):
                self._mark_cloudflare_uploaded()
            try:
                self._verify_worker_online(self.online_url_var.get().strip(), source_version)
            except Exception as exc:
                with diagnostics_file.open("a", encoding="utf-8") as fp:
                    fp.write("\nHealth check failed: " + str(exc) + "\n")
                raise RuntimeError(str(exc) + "\nDiagnostic log: " + str(diagnostics_file))
            return source_version
        finally:
            shutil.rmtree(deploy_root, ignore_errors=True)

    def _extract_supabase_functions(self):
        if not self.selected_zip:
            return None, []
        temp_root = Path(tempfile.gettempdir()) / f"tower_supabase_functions_{os.getpid()}"
        if temp_root.exists(): shutil.rmtree(temp_root, ignore_errors=True)
        functions_root = temp_root / "supabase" / "functions"
        functions_root.mkdir(parents=True, exist_ok=True)
        found = []
        with zipfile.ZipFile(self.selected_zip, "r") as z:
            for member in z.namelist():
                if member.endswith("/"): continue
                parts = Path(member).parts
                try:
                    idx = parts.index("supabase")
                except ValueError:
                    continue
                rel = Path(*parts[idx:])
                if len(rel.parts) >= 4 and rel.parts[1] == "functions":
                    fn_name = rel.parts[2]
                    dest = temp_root / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(z.read(member))
                    if fn_name not in found: found.append(fn_name)
        if not found:
            shutil.rmtree(temp_root, ignore_errors=True)
            return None, []
        (temp_root / "supabase" / "config.toml").write_text(
            '[functions.login-with-id]\nverify_jwt = false\n\n[functions.activate-user]\nverify_jwt = true\n',
            encoding="utf-8"
        )
        return temp_root, found

    def _deploy_supabase_functions_core(self):
        root, functions = self._extract_supabase_functions()
        if not functions:
            return []
        npx = self._supabase_npx()
        if not npx:
            if root: shutil.rmtree(root, ignore_errors=True)
            raise RuntimeError("Node.js / npx missing for Supabase CLI.")
        project_ref = self._project_ref()
        deployed = []
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            ordered = [x for x in ["activate-user", "login-with-id"] if x in functions] + [x for x in functions if x not in ("activate-user", "login-with-id")]
            total = len(ordered)
            for idx, name in enumerate(ordered, start=1):
                self.after(0, lambda i=idx,n=name,t=total: self.update_progress_var.set(f"دوال Supabase · {i}/{t}: {n}…"))
                self.after(0, lambda n=name: self.supabase_cli_status_var.set(f"Edge Functions: Working Deploy {n}…"))
                cmd = [npx, "--yes", "supabase@latest", "functions", "deploy", name, "--project-ref", project_ref, "--use-api"]
                if name == "login-with-id":
                    cmd.append("--no-verify-jwt")
                try:
                    result = subprocess.run(
                        cmd, cwd=str(root), capture_output=True, text=True,
                        timeout=120, creationflags=flags
                    )
                except subprocess.TimeoutExpired:
                    raise RuntimeError(
                        f"{name}: Deployment timed out after 2 minutes. "
                        "Check Supabase CLI login before retrying."
                    )
                output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
                if result.returncode != 0:
                    raise RuntimeError(f"{name}: {output[-2200:] or 'Supabase deploy failed'}")
                deployed.append(name)
                self.after(0, lambda n=name: self.supabase_cli_status_var.set(f"✓ Done Deploy {n}"))
            return deployed
        finally:
            if root: shutil.rmtree(root, ignore_errors=True)

    def update_project_all(self):
        if self._busy or self._selecting or self._backup_busy:
            return
        if not self.selected_zip:
            self.choose_zip()
            return
        try:
            self._refresh_target()
            if not self.target_folder or not (self.target_folder/'app.js').is_file() or not (self.target_folder/'index.html').is_file():
                raise ValueError('Select folder containing index.html and app.js.')
            if not self.save_online_settings(silent=True):
                raise ValueError('Check online URL and Worker name in Settings.')
            if not self.online_url_var.get().strip().startswith('https://'):
                raise ValueError('Check online URL: HTTPS URL is required for verification.')
            if not self._npx_path():
                raise ValueError('Node.js / npx missing. Install Node.js LTS first.')
        except Exception as exc:
            show_error('تجهيز التحديث', str(exc), parent=self)
            return
        job = UpdateJob(self)
        self._busy = True
        self._deploy_steps = []
        self._set_update_state('updating', 'بدأ التحديث. اترك النافذة مفتوحة حتى تظهر النتيجة.')
        self._set_phase(0)
        threading.Thread(target=self._run_full_update_job, args=(job,), daemon=True, name='TowerFullUpdate').start()

    def save_online_settings(self, silent=False):
        url = self.online_url_var.get().strip().rstrip("/")
        worker = self.worker_name_var.get().strip().lower()
        if url and not re.match(r"^https?://", url, re.I):
            if not silent:
                show_error("Online URL", "URL must start with https:// or http://")
            return False
        if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?", worker or ""):
            if not silent:
                show_error("Worker name", "Use lowercase letters, numbers, and hyphens only.")
            return False
        self.cfg["online_url"] = url
        self.cfg["cloudflare_worker_name"] = worker
        save_config(self.cfg)
        if not silent:
            self.cloudflare_status_var.set("Project URL and Worker name saved.")
        return True

    def _npx_path(self):
        return shutil.which("npx.cmd") or shutil.which("npx")

    def cloudflare_login(self):
        npx = self._npx_path()
        if not npx:
            show_error(
                "Cloudflare",
                "Node.js / npx is not installed.\n\n"
                "Install Node.js LTS and restart the updater.\n"
                "Updater does not store Cloudflare API tokens."
            )
            return
        try:
            self.cloudflare_status_var.set("Cloudflare login opened. Authorize in browser, then return.")
            flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen([npx, "--yes", "wrangler@latest", "login"], creationflags=flags)
        except Exception as e:
            show_error("Cloudflare Login", str(e))

    def open_online(self):
        url = self.online_url_var.get().strip()
        if not url:
            self.status_var.set("حدّد رابط الأونلاين من الإعدادات لعرض الإصدار الحالي.")
            return
        if not re.match(r"^https?://", url, re.I):
            show_error("Online", "URL must start with https://")
            return
        webbrowser.open(url)

    def copy_log(self):
        """Copy useful diagnostics without copying configuration files or credentials."""
        lines = [f"Tower Supabase Updater {UPDATER_VERSION}",
                 f"Worker: {self.worker_name_var.get().strip()}",
                 f"Online: {self.online_url_var.get().strip()}",
                 f"Online Version: {self.online_version_var.get()}",
                 f"Local Version: {self.current_version_var.get()}",
                 f"Status: {self.status_var.get()}",
                 f"Cloudflare: {self.cloudflare_status_var.get()}",
                 f"Supabase: {self.supabase_status_var.get()}"]
        if self.last_health_result:
            lines.extend(["", "Supabase health:", self.last_health_result])
        for label, path in [
            ("Cloudflare deployment", Path.home() / "tower-cloudflare-deploy.log"),
            ("Startup", Path(__file__).resolve().parent / "updater_startup.log"),
        ]:
            try:
                if path.is_file():
                    # Read only a bounded tail, not arbitrary project/config files.
                    with path.open("rb") as fh:
                        fh.seek(0, 2)
                        fh.seek(max(0, fh.tell()-30000))
                        content = fh.read().decode("utf-8", errors="replace")
                    lines.extend(["", label + ":", content[-18000:]])
            except OSError as exc:
                lines.extend(["", label + f": Could not read log ({type(exc).__name__})"])
        content = sanitize("سجل تشخيص الـUpdater\n"+"\n".join(lines))
        # Best-effort scrub; avoid asking users to share raw credentials.
        content = re.sub(r"(?im)((?:service_role_key|supabase_service_role_key|api[_-]?key|authorization|access[_-]?token|refresh[_-]?token|password|secret|pin)\s*[:=]\s*)[^\s,;]+", r"\1[REDACTED]", content)
        content = re.sub(r"(?i)Bearer\s+[A-Za-z0-9._~+/-]+", "Bearer [REDACTED]", content)
        content = re.sub(r"\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}\b", "[JWT REDACTED]", content)
        try:
            self.clipboard_clear()
            self.clipboard_append(content)
            self.update()
            self.status_var.set("تم نسخ السجل بعد إخفاء المفاتيح وكلمات المرور المعروفة.")
        except Exception as exc:
            show_error("Copy log", str(exc))

    def _online_version_probe(self, url):
        """Worker health is authoritative; never infer deployment version from legacy app.js."""
        base = url.rstrip("/")
        endpoint = base + "/api/health?updater=" + str(time.time_ns())
        try:
            request = urllib.request.Request(endpoint, headers={
                "Accept": "application/json", "Cache-Control": "no-store, no-cache",
                "Pragma": "no-cache", "User-Agent": f"TowerSupabaseUpdater/{UPDATER_VERSION}"})
            with urllib.request.urlopen(request, timeout=12) as response:
                code = int(response.getcode() or 0)
                payload = json.loads(response.read(8192).decode("utf-8", errors="replace"))
                if code == 200 and isinstance(payload, dict) and payload.get("ok") is True and payload.get("version"):
                    return True, "V" + str(payload["version"]).lstrip("vV"), code
                return False, "Unable to verify", code
        except Exception:
            return False, "Unable to verify", 0

    def check_online(self):
        if not self.save_online_settings(silent=True):
            return
        url = self.online_url_var.get().strip()
        if not url:
            messagebox.showinfo("Online", "Set the online URL first.")
            return
        self.cloudflare_status_var.set("Checking online version…")

        def worker():
            ok, version, code = self._online_version_probe(url)
            def finish():
                self.online_version_var.set(version)
                if ok:
                    local_v = self.current_version_var.get()
                    color_note = "Matches local" if semver_tuple(version) == semver_tuple(local_v) else f"Local: {local_v}"
                    self.cloudflare_status_var.set(f"✓ Site reachable · HTTP {code} · {color_note}")
                else:
                    self.cloudflare_status_var.set("✕ Could not read the deployed version.")
            self.after(0, finish)

        threading.Thread(target=worker, name="OnlineHealth", daemon=True).start()

    def _prepare_cloudflare_assets(self):
        temp_root = Path(tempfile.gettempdir()) / f"tower_cloudflare_deploy_{os.getpid()}"
        if temp_root.exists():
            shutil.rmtree(temp_root, ignore_errors=True)
        public = temp_root / "public"
        public.mkdir(parents=True, exist_ok=True)

        allowed_ext = {
            ".html", ".js", ".css", ".json", ".webmanifest",
            ".png", ".ico", ".svg", ".webp", ".jpg", ".jpeg", ".gif"
        }
        copied = []

        if self.selected_zip:
            info = inspect_zip(self.selected_zip)
            prefix = tuple(info.get("root_parts") or ())
            with zipfile.ZipFile(self.selected_zip, "r") as z:
                for member in info["members"]:
                    parts = Path(member).parts
                    if prefix and tuple(parts[:len(prefix)]) != prefix:
                        continue
                    rel_parts = parts[len(prefix):] if prefix else parts
                    if not rel_parts:
                        continue
                    rel = Path(*rel_parts)
                    if len(rel.parts) != 1:
                        continue
                    if rel.suffix.lower() not in allowed_ext:
                        continue
                    if rel.name.lower().startswith("migration_") or rel.name.lower().startswith("readme"):
                        continue
                    (public / rel.name).write_bytes(z.read(member))
                    copied.append(rel.name)
            source_version = info["version"]
        else:
            self._refresh_target()
            if not self.target_folder:
                raise RuntimeError("Select Tower App folder or choose a release ZIP first.")
            for p in self.target_folder.iterdir():
                if not p.is_file() or p.suffix.lower() not in allowed_ext:
                    continue
                if p.name.lower().startswith("migration_") or p.name.lower().startswith("readme"):
                    continue
                shutil.copy2(p, public / p.name)
                copied.append(p.name)
            source_version = read_version(self.target_folder)

        self._sync_public_supabase_config(public / "app.js")
        required = {"index.html", "app.js", "styles.css"}
        if not required.issubset(set(copied)):
            missing = ", ".join(sorted(required - set(copied)))
            raise RuntimeError(f"Required startup files missing: {missing}")

        # Worker-aware deploy: preserve backend modules instead of dropping them.
        # Previous versions produced static-only deployments, which disabled Secrets.
        if self.selected_zip:
            with zipfile.ZipFile(self.selected_zip, "r") as z:
                names = set(z.namelist())
                prefix = tuple(info.get("root_parts") or ())
                root = "/".join(prefix).rstrip("/")
                def member_path(rel):
                    return (root + "/" if root else "") + rel
                main_member = member_path("worker.js")
                if main_member in names:
                    (temp_root / "worker.js").write_bytes(z.read(main_member))
                    backend_files = [n for n in names if n.startswith(member_path("functions/") ) and not n.endswith("/")]
                    for n in backend_files:
                        rel = n[len(root)+1:] if root else n
                        dest = temp_root / rel
                        if ".." in Path(rel).parts or Path(rel).is_absolute():
                            raise RuntimeError("Unsafe Worker path inside ZIP.")
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_bytes(z.read(n))
                    # Prefer the public/ assets when present (Worker package format).
                    for file_name in ("index.html", "app.js", "styles.css", "bridge.js"):
                        name = member_path("public/" + file_name)
                        if name in names:
                            (public / file_name).write_bytes(z.read(name))
                    self._sync_public_supabase_config(public / "app.js")
        else:
            self._refresh_target()
            root_dir = self.target_folder
            if root_dir and (root_dir / "worker.js").is_file():
                shutil.copy2(root_dir / "worker.js", temp_root / "worker.js")
                if (root_dir / "functions").is_dir():
                    shutil.copytree(root_dir / "functions", temp_root / "functions", dirs_exist_ok=True)

        # A Tower App deployment must have its API backend. Never downgrade to assets-only.
        worker_file = temp_root / "worker.js"
        if not worker_file.is_file() or worker_file.stat().st_size < 100:
            raise RuntimeError("Deployment blocked: worker.js missing or invalid; frontend cannot deploy without API.")
        source = worker_file.read_text(encoding="utf-8", errors="replace")
        # Check both ZIP and already-installed-folder deployments after copying sources.
        worker_match = re.search(r"\bAPP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", source)
        if not worker_match or semver_tuple(worker_match.group(1)) != semver_tuple(source_version):
            raise RuntimeError(
                f"Deployment blocked: worker.js version "
                f"{worker_match.group(1) if worker_match else 'missing'} differs from {source_version}."
            )
        if "/api/tower" not in source or "/api/health" not in source:
            raise RuntimeError("Deployment blocked: worker.js lacks required /api/tower and /api/health paths.")

        # Never publish backend source as a public static asset.
        (public / "worker.js").unlink(missing_ok=True)
        copied = [name for name in copied if name != "worker.js"]

        worker_name = self.worker_name_var.get().strip().lower()
        cfg = {
            "name": worker_name,
            "keep_vars": True,
            "compatibility_date": "2026-10-09",
            "assets": {"directory": "./public"}
        }
        # Preserve cron triggers declared in the application bundle. Previous updater
        # rebuilt Wrangler config without triggers and silently removed scheduled jobs.
        cron_expressions = []
        if self.selected_zip:
            with zipfile.ZipFile(self.selected_zip, "r") as source_archive:
                members = source_archive.namelist()
                candidate = next((n for n in members if n.endswith("wrangler.toml") and n.count("/") <= 2), None)
                if candidate:
                    wrangler_text = source_archive.read(candidate).decode("utf-8", errors="replace")
                    trigger_section = re.search(r"(?ms)^\[triggers\]\s*\n(.*?)(?=^\[|\Z)", wrangler_text)
                    if trigger_section:
                        cron_line = re.search(r'^crons\s*=\s*\[(.*?)\]', trigger_section.group(1), re.M | re.S)
                        if cron_line:
                            cron_expressions = re.findall(r'"([^"\n]{1,64})"', cron_line.group(1))
                            if any(not re.fullmatch(r"[0-9*,/\- A-Za-z]+", c) or len(c.split()) != 5 for c in cron_expressions):
                                raise RuntimeError("Invalid Cron expression in release; deployment blocked.")
        if cron_expressions:
            cfg["triggers"] = {"crons": cron_expressions}
        cfg["observability"] = {"enabled": True, "logs": {"enabled": True, "head_sampling_rate": 1}}
        cfg["main"] = "./worker.js"
        cfg["assets"]["binding"] = "ASSETS"
        cfg["assets"]["run_worker_first"] = True
        (temp_root / "wrangler.jsonc").write_text(
            json.dumps(cfg, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        return temp_root, source_version, copied

    def _ensure_health_kv_binding(self, npx, deploy_root):
        """Resolve EXISTING Cloudflare KV ID and add binding to generated Wrangler config.

        Fail closed when Health Monitor exists but its KV resource cannot be resolved.
        Never create a namespace, delete data, or permit publishing without the binding.
        """
        worker_path = deploy_root / "worker.js"
        if not worker_path.is_file() or "HEALTH_MONITOR_KV" not in worker_path.read_text(encoding="utf-8", errors="replace"):
            return
        cmd = [npx, "--yes", "wrangler@latest", "kv", "namespace", "list"]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(cmd, cwd=str(deploy_root), capture_output=True,
                                text=True, timeout=120, creationflags=flags)
        if result.returncode != 0:
            raise RuntimeError("Could not read Cloudflare KV namespaces. Deployment blocked to protect HEALTH_MONITOR_KV binding. " + (result.stderr or "")[-400:])
        text_output = result.stdout or ""
        try:
            # Wrangler may emit user-facing notes before the JSON list.
            start = text_output.find("[")
            namespaces = json.JSONDecoder().raw_decode(text_output[start:])[0] if start >= 0 else None
        except (ValueError, TypeError):
            namespaces = None
        if not isinstance(namespaces, list):
            raise RuntimeError("Unable to parse Cloudflare KV namespace list. Deployment blocked (not a binding reset).")
        matching = [entry for entry in namespaces if isinstance(entry, dict)
                    and entry.get("title") == "tower-health-monitor"
                    and re.fullmatch(r"[a-fA-F0-9]{32}", str(entry.get("id", "")))]
        if len(matching) != 1:
            raise RuntimeError("Expected exactly one existing tower-health-monitor KV namespace. Deployment blocked to preserve the binding.")
        config_path = deploy_root / "wrangler.jsonc"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        config["kv_namespaces"] = [{"binding": "HEALTH_MONITOR_KV", "id": matching[0]["id"]}]
        config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    def deploy_online(self):
        if not self.save_online_settings(silent=True):
            return
        npx = self._npx_path()
        if not npx:
            show_error(
                "Refresh Online",
                "Node.js / npx was not found.\n\n"
                "Install Node.js LTS and reconnect Cloudflare."
            )
            return

        try:
            deploy_root, source_version, copied = self._prepare_cloudflare_assets()
        except Exception as e:
            show_error("Refresh Online", str(e))
            return

        worker_name = self.worker_name_var.get().strip().lower()
        url = self.online_url_var.get().strip()
        source_label = self.selected_zip.name if self.selected_zip else str(self.target_folder)

        self.cloudflare_status_var.set(f"Deploying {source_version} to Cloudflare…")
        self.status_var.set("Updating online project. Do not close until the result appears.")

        def worker():
            try:
                self._ensure_health_kv_binding(npx, deploy_root)
                self._preflight_worker_bundle(npx, deploy_root)
                cmd = [
                    npx, "--yes", "wrangler@latest", "deploy",
                    "--config", str(deploy_root / "wrangler.jsonc")
                ]
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                result = subprocess.run(
                    cmd, cwd=str(deploy_root), capture_output=True, text=True,
                    timeout=300, creationflags=flags
                )
                output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
                ok = result.returncode == 0
                diagnostics_file = Path.home() / "tower-cloudflare-deploy.log"
                diagnostics_file.write_text(
                    "Tower Supabase Updater " + UPDATER_VERSION + "\n" +
                    "Worker: " + worker_name + "\n" +
                    "Package version: " + str(source_version) + "\n" +
                    "Wrangler exit code: " + str(result.returncode) + "\n" + sanitize(output[-12000:]),
                    encoding="utf-8"
                )
                if ok:
                    try:
                        self._verify_worker_online(url, source_version)
                    except Exception as exc:
                        with diagnostics_file.open("a", encoding="utf-8") as fp:
                            fp.write("\nHealth check failed: " + str(exc) + "\n")
                        raise RuntimeError(str(exc) + "\nDiagnostic log: " + str(diagnostics_file))
            except subprocess.TimeoutExpired:
                ok = False
                output = "Deployment timed out after 5 minutes."
            except Exception as e:
                ok = False
                output = str(e)
            finally:
                shutil.rmtree(deploy_root, ignore_errors=True)

            def finish():
                if ok:
                    self.cloudflare_status_var.set(f"✓ Deployed {source_version} and verified Worker API: {worker_name}")
                    self.status_var.set(
                        f"✓ Online project updated successfully\n"
                        f"Worker: {worker_name}\n"
                        f"Version: {source_version}"
                    )
                    if url:
                        self.after(1200, self.check_online)
                else:
                    safe = output[-1800:] if output else "Unknown Wrangler error"
                    self.cloudflare_status_var.set("✕ Deployment failed. Connect Cloudflare first if needed.")
                    self.status_var.set("Could not update online project.")
                    show_error(
                        "Failed Cloudflare Deploy",
                        safe + "\n\nIf login is required, connect Cloudflare and retry."
                    )
            self.after(0, finish)

        threading.Thread(target=worker, name="CloudflareDeploy", daemon=True).start()

    # ---------- Self update / canonical install ----------
    def _installed_dir(self):
        local_appdata = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
        return local_appdata / "Programs" / "Tower Supabase Updater"

    def _installed_exe_path(self):
        return self._installed_dir() / "Tower Supabase Updater.exe"

    def _auto_promote_self(self):
        if self._busy or self._backup_busy or self._selecting:
            self.after(1000, self._auto_promote_self)
            return
        if os.name != "nt" or not getattr(sys, "frozen", False):
            return
        try:
            current_exe = Path(sys.executable).resolve()
            current_dir = current_exe.parent
            target_dir = self._installed_dir()
            target_exe = self._installed_exe_path()
            if current_exe == target_exe or not target_exe.exists():
                return
            helper = Path(os.environ.get("TEMP", str(Path.home()))) / "tower_updater_promote.cmd"
            cmd_text = (
                "@echo off\r\n"
                "timeout /t 2 /nobreak >nul\r\n"
                + f'if exist "{target_dir}" rmdir /s /q "{target_dir}"\r\n'
                + f'mkdir "{target_dir}"\r\n'
                + f'xcopy /E /I /Y "{current_dir}\\*" "{target_dir}\\" >nul\r\n'
                + f'start "" "{target_exe}"\r\n'
                + 'del "%~f0"\r\n'
            )
            helper.write_text(cmd_text, encoding="utf-8")
            subprocess.Popen(["cmd.exe", "/c", str(helper)], creationflags=0x08000000)
            self.status_var.set("New updater version detected. Installing and restarting.")
            self.after(550, self.destroy)
        except Exception:
            pass

    # ---------- Install as a Start Menu app ----------
    def install_start_menu(self):
        if os.name != "nt":
            messagebox.showinfo("Start Menu", "This feature requires Windows.")
            return
        try:
            local_appdata = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
            install_dir = local_appdata / "Programs" / "Tower Supabase Updater"
            install_dir.mkdir(parents=True, exist_ok=True)

            if getattr(sys, "frozen", False):
                # Stable onedir build: install the entire runtime folder, not only the EXE.
                src_exe = Path(sys.executable).resolve()
                src_dir = src_exe.parent
                target_exe = install_dir / "Tower Supabase Updater.exe"
                if src_exe != target_exe:
                    for item in src_dir.iterdir():
                        dest = install_dir / item.name
                        if item.is_dir():
                            shutil.copytree(item, dest, dirs_exist_ok=True)
                        else:
                            shutil.copy2(item, dest)
                shortcut_target = target_exe
                icon = target_exe
            else:
                # Source-mode fallback kept for developers.
                source = Path(__file__).resolve().parent
                names = [
                    "updater.py", "updater_support.py", "backup_tools.py", "launcher.py", "Tower Supabase Updater.vbs",
                    "Start Updater - Diagnostic.bat", "README_AR.txt",
                    "Tower_Supabase_Updater.ico", "Tower_Supabase_Updater.png"
                ]
                for name in names:
                    src = source / name
                    if src.exists():
                        shutil.copy2(src, install_dir / name)
                if (source / "vendor").exists():
                    shutil.copytree(source / "vendor", install_dir / "vendor", dirs_exist_ok=True)
                shortcut_target = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "wscript.exe"
                icon = install_dir / "Tower_Supabase_Updater.ico"

            start_menu = Path(os.environ.get("APPDATA", str(Path.home()))) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
            start_menu.mkdir(parents=True, exist_ok=True)
            shortcut = start_menu / "Tower Supabase Updater.lnk"

            vbs = install_dir / "_create_shortcut.vbs"
            lines = [
                'Set sh = CreateObject("WScript.Shell")',
                f'Set sc = sh.CreateShortcut("{str(shortcut)}")',
                f'sc.TargetPath = "{str(shortcut_target)}"',
                f'sc.WorkingDirectory = "{str(install_dir)}"',
                f'sc.IconLocation = "{str(icon)},0"',
                'sc.Description = "Tower Supabase Updater"'
            ]
            if not getattr(sys, "frozen", False):
                target_vbs = install_dir / "Tower Supabase Updater.vbs"
                lines.append(f'sc.Arguments = Chr(34) & "{str(target_vbs)}" & Chr(34)')
            lines.append('sc.Save')
            vbs.write_text("\n".join(lines)+"\n", encoding="utf-8")

            flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
            result = subprocess.run(["cscript.exe", "//nologo", str(vbs)], capture_output=True, text=True, creationflags=flags)
            try:
                vbs.unlink()
            except Exception:
                pass
            if result.returncode != 0 or not shortcut.exists():
                raise RuntimeError((result.stderr or result.stdout or "Could not create Start Menu shortcut").strip())

            self.status_var.set(f"Installed into Start Menu ✓\n{install_dir}")
            messagebox.showinfo(
                "Installation complete",
                "Tower Supabase Updater installed successfully.\n\n"
                "Open Start and search for Tower Supabase Updater\n"
                "It will appear as a standalone Windows program."
            )
        except Exception as e:
            self.status_var.set(f"Start Menu installation failed:\n{e}")
            show_error("Installation failed", str(e))

    # ---------- Safe native Tk drag & drop via tkdnd ----------
    def _enable_safe_drop(self):
        if not DND_AVAILABLE:
            self.status_var.set("السحب والإفلات غير متاح؛ استخدم الكارت أو Auto Update، أو شغّل Diagnostic لإكمال تثبيت الدعم.")
            return
        try:
            self._register_drop_tree(self)
            self.status_var.set('جاهز — اضغط الكارت، أو اسحب ZIP، أو استخدم Auto Update.')
        except Exception as exc:
            self.status_var.set('تعذر تفعيل السحب؛ استخدم الكارت أو Auto Update.')

    def _on_file_drop(self, event):
        if self._busy or self._backup_busy or self._selecting:
            return 'copy'
        try:
            paths = self.tk.splitlist(event.data)
            matches = [Path(str(p).strip().strip('\"')) for p in paths if str(p).strip().lower().endswith('.zip') and Path(str(p).strip().strip('\"')).is_file()]
            if len(matches)==1:
                self.after_idle(lambda path=matches[0]: self.stage_zip(path))
            else:
                self.after_idle(lambda: show_error('سحب الملف', 'اختر ملف ZIP واحدًا فقط في كل مرة.', parent=self))
        except Exception as exc:
            message = str(exc)
            self.after_idle(lambda msg=message: show_error('Drag & Drop', msg))
        return 'copy'

    def on_close(self):
        if self._busy or self._backup_busy:
            show_error("إغلاق البرنامج", "انتظر انتهاء التحديث أو النسخ الاحتياطي قبل الإغلاق.", parent=self)
            return
        self._closing = True
        self._selection_id += 1
        self.stop_server(silent=True)
        self.destroy()

if __name__ == "__main__":
    App().mainloop()

# ___________________________
# Tower Supabase Updater V2.2.1.
# Code End
