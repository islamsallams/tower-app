"""Compact view of an existing update session; no update engine, network or worker thread."""
import ctypes
import os
import time
import tkinter as tk
from updater_support import work_area


def saved_position(value):
    if not isinstance(value, dict):
        return None
    x, y = value.get('x'), value.get('y')
    if type(x) is int and type(y) is int and abs(x) < 100000 and abs(y) < 100000:
        return x, y
    return None


def mini_bounds(rect, saved=None, width=384, height=274):
    left, top, right, bottom = rect
    width = min(width, max(1, right-left-16))
    height = min(height, max(1, bottom-top-16))
    position = saved_position(saved)
    x, y = position if position else (right-width-12, top+12)
    return width, height, max(left, min(x, right-width)), max(top, min(y, bottom-height))


def monitor_area(window, saved=None):
    position = saved_position(saved)
    if os.name == 'nt' and position:
        try:
            from ctypes import wintypes
            class Info(ctypes.Structure):
                _fields_ = [('size', wintypes.DWORD), ('monitor', wintypes.RECT), ('work', wintypes.RECT), ('flags', wintypes.DWORD)]
            user = ctypes.windll.user32
            user.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
            user.MonitorFromPoint.restype = wintypes.HANDLE
            user.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(Info)]
            monitor = user.MonitorFromPoint(wintypes.POINT(*position), 2)
            info = Info();info.size = ctypes.sizeof(info)
            if user.GetMonitorInfoW(monitor, ctypes.byref(info)):
                r = info.work
                return r.left, r.top, r.right, r.bottom
        except (OSError, AttributeError, ValueError):
            pass
    return work_area(window)


def place_window(window, bounds):
    """Win32 absolute placement also supports monitors left/above the primary screen."""
    w, h, x, y = bounds
    window.geometry(f'{w}x{h}{x:+d}{y:+d}')
    window.update_idletasks()
    if os.name == 'nt':
        try:
            from ctypes import wintypes
            user = ctypes.windll.user32
            user.GetParent.argtypes = [wintypes.HWND];user.GetParent.restype = wintypes.HWND
            user.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
            handle = user.GetParent(window.winfo_id()) or window.winfo_id()
            user.SetWindowPos(handle, None, x, y, w, h, 0x0014)
        except (OSError, AttributeError):
            pass


def soft_corners(window):
    """Optional Windows 11 treatment; older Windows keeps its normal rectangular frame."""
    if os.name != 'nt':
        return
    try:
        from ctypes import wintypes
        user = ctypes.windll.user32
        user.GetParent.argtypes = [wintypes.HWND];user.GetParent.restype = wintypes.HWND
        handle = user.GetParent(window.winfo_id()) or window.winfo_id()
        dwm = ctypes.windll.dwmapi
        dwm.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
        choice = ctypes.c_int(2)
        dwm.DwmSetWindowAttribute(handle, 33, ctypes.byref(choice), ctypes.sizeof(choice))
    except (OSError, AttributeError):
        pass


def mini_status(app):
    """Read the current shared model. Pending verification never invites a duplicate deploy."""
    if app._backup_busy:
        return True, 'النسخ الاحتياطي جارٍ', 'انتظر انتهاء النسخ الاحتياطي.', 'busy'
    if app._selecting:
        return True, 'جاري فحص الإصدار…', 'اختيار أحدث حزمة متوافقة وفحصها.', 'busy'
    state = app._ui_state
    if app._busy or state == 'updating':
        return True, 'جاري التحديث…', app.update_progress_var.get(), 'busy'
    if state == 'pending':
        return True, 'التحقق معلّق', 'افتح التفاصيل للتحقق؛ لا تعِد الرفع الآن.', 'pending'
    if state == 'failed':
        return False, 'Retry Update', app.update_progress_var.get(), 'failed'
    if state == 'done':
        return False, 'Auto Update', 'تم التحديث والتحقق بنجاح.', 'done'
    return False, 'Auto Update', 'جاهز — التحديث يبدأ عند الضغط فقط.', 'ready'


class FloatingController:
    def __init__(self, root, header, save, colors, version):
        self.root, self.save, self.colors, self.version = root, save, colors, version
        self.window = None
        self.visible = False
        self.tick_id = None
        self.drag = None
        self.closed = False
        self.normal_minimize = False
        self.angle = 0
        saved = root.cfg.get('mini_window', {})
        self.topmost = saved.get('topmost', True) if isinstance(saved, dict) else True
        self.topmost = self.topmost if type(self.topmost) is bool else True
        self.save_failed = False
        self.button = tk.Button(header, text='▣ Mini', command=self.show,
                                bg=colors['panel'], fg=colors['text'], activebackground=colors['border'],
                                activeforeground=colors['text'], bd=0, padx=10, pady=9,
                                font=('Segoe UI', 9), cursor='hand2')
        self.button.pack(side='right', padx=(0, 7))
        root.bind('<Unmap>', self._on_unmap, add='+')
        root.bind('<Map>', self._on_map, add='+')
        root.bind('<Destroy>', self._on_destroy, add='+')

    def _build(self):
        c = self.colors
        win = self.window = tk.Toplevel(self.root)
        win.withdraw();win.overrideredirect(True);win.resizable(False, False)
        win.configure(bg=c['border']);win.attributes('-topmost', self.topmost)
        win.protocol('WM_DELETE_WINDOW', self.restore_full)
        win.bind('<Escape>', lambda _: self.restore_full())
        frame = tk.Frame(win, bg=c['bg']);frame.pack(fill='both', expand=True, padx=1, pady=1)
        bar = tk.Frame(frame, bg=c['panel']);bar.pack(fill='x')
        brand = tk.Label(bar, text='◆ Tower Updater', bg=c['panel'], fg=c['text'],
                         font=('Segoe UI Semibold', 10), padx=10, pady=10, cursor='fleur')
        brand.pack(side='left')
        for target in (bar, brand):
            target.bind('<ButtonPress-1>', self._drag_start)
            target.bind('<B1-Motion>', self._drag_move)
            target.bind('<ButtonRelease-1>', self._drag_end)
            target.bind('<Double-Button-1>', lambda _: self.restore_full())
        for text, action in [('—', self.minimize_taskbar), ('↗', self.restore_full)]:
            tk.Button(bar, text=text, command=action, bg=c['panel'], fg=c['text'], bd=0,
                      font=('Segoe UI', 12), padx=9, pady=4, cursor='hand2', takefocus=True).pack(side='right')
        self.pin = tk.Button(bar, command=self.toggle_pin, bg=c['panel'], fg=c['accent'], bd=0,
                             font=('Segoe UI', 9), padx=6, pady=7, cursor='hand2')
        self.pin.pack(side='right');self._paint_pin()
        versions = tk.Frame(frame, bg=c['bg']);versions.pack(fill='x', padx=10, pady=(10, 6))
        self.version_labels = []
        for i, (label, var, color) in enumerate((('NEW', self.root.new_version_var, c['accent']),
                                                 ('LOCAL', self.root.current_version_var, c['text']),
                                                 ('ONLINE', self.root.online_version_var, c['good']))):
            versions.columnconfigure(i, weight=1, uniform='mini')
            card = tk.Frame(versions, bg=c['panel']);card.grid(row=0, column=i, sticky='nsew', padx=3)
            tk.Label(card, text=label, bg=c['panel'], fg=c['muted'], font=('Segoe UI', 8)).pack(pady=(5, 1))
            value = tk.Label(card, textvariable=var, bg=c['panel'], fg=color,
                             font=('Segoe UI Semibold', 10), wraplength=106)
            value.pack(fill='x', padx=3, pady=(0, 5));self.version_labels.append(value)
        self.auto = tk.Button(frame, text='Auto Update', command=self.start_update, bg=c['accent'],
                              fg='white', activebackground=c['accent'], activeforeground='white',
                              disabledforeground='#d7e5ff', bd=0, font=('Segoe UI Semibold', 11),
                              pady=8, cursor='hand2')
        self.auto.pack(fill='x', padx=13, pady=3)
        status = tk.Frame(frame, bg=c['bg']);status.pack(fill='x', padx=13, pady=(5, 0))
        self.spinner = tk.Canvas(status, width=22, height=22, bg=c['bg'], highlightthickness=0)
        self.spinner.pack(side='left')
        self.status = tk.Label(status, bg=c['bg'], fg=c['muted'], font=('Segoe UI', 9),
                               anchor='e', justify='right', wraplength=316)
        self.status.pack(side='right', fill='x', expand=True, padx=(5, 0))
        self.elapsed = tk.Label(frame, bg=c['bg'], fg=c['muted'], font=('Segoe UI', 8), text='')
        self.elapsed.pack(anchor='e', padx=13)
        tk.Button(frame, text='التفاصيل والـLog ↗', command=self.restore_full, bg=c['bg'], fg=c['accent'],
                  activebackground=c['bg'], activeforeground=c['text'], bd=0,
                  font=('Segoe UI', 9), cursor='hand2').pack(anchor='e', padx=11, pady=(0, 5))

    def show(self):
        if self.closed or self.root._closing:
            return
        settings = getattr(self.root, 'settings_window', None)
        modal = self.root.grab_current()
        if modal is not None or (settings is not None and settings.winfo_exists() and settings.state() != 'withdrawn'):
            self.root.deiconify()
            (modal or settings).deiconify()
            (modal or settings).lift()
            return
        if self.visible:
            self.window.lift();return
        if self.window is None or not self.window.winfo_exists():
            self._build()
        saved = self.root.cfg.get('mini_window', {})
        self.window.update_idletasks()
        bounds = mini_bounds(monitor_area(self.window, saved), saved,
                             max(384, self.window.winfo_reqwidth()), max(274, self.window.winfo_reqheight()))
        self.visible = True;self.normal_minimize = False
        place_window(self.window, bounds)
        self.window.deiconify();self.window.lift();self.window.attributes('-topmost', self.topmost)
        soft_corners(self.window)
        self.root.withdraw()
        self._tick()

    def restore_full(self):
        if self.closed:
            return
        if self.visible:
            self._persist()
        self.visible = False
        self._cancel_tick()
        if self.window is not None:
            self.window.withdraw()
        self.root.deiconify();self.root.lift()

    def minimize_taskbar(self):
        self.restore_full()
        self.normal_minimize = True
        self.root.iconify()

    def _on_unmap(self, event):
        if event.widget is self.root and not self.closed:
            self.root.after_idle(self._check_minimize)

    def _check_minimize(self):
        if not self.closed and not self.visible and not self.normal_minimize and not self.root._closing and self.root.state() == 'iconic':
            self.show()

    def _on_map(self, event):
        if event.widget is self.root and self.root.state() in ('normal', 'zoomed'):
            self.normal_minimize = False

    def _paint_pin(self):
        self.pin.config(text='● Top' if self.topmost else '○ Top')

    def toggle_pin(self):
        self.topmost = not self.topmost
        self.window.attributes('-topmost', self.topmost);self._paint_pin();self._persist()

    def start_update(self):
        blocked, _, _, _ = mini_status(self.root)
        if blocked or self.root._closing:
            return
        if not self.root.cfg.get('release_zip_folder'):
            self.restore_full()
        self.root.auto_update_project()
        # Selection/deployment mutates the same shared model; never create another job.
        if self.visible:
            self._paint_status()

    def _paint_status(self):
        busy, label, detail, state = mini_status(self.root)
        self.auto.config(text=label, state='disabled' if busy else 'normal')
        if self.save_failed:
            detail += ' — تعذر حفظ موضع النافذة.'
        self.status.config(text=detail, fg=self.colors['good'] if state=='done' else self.colors['bad'] if state=='failed' else self.colors['warn'] if state=='pending' else self.colors['muted'])
        self.spinner.delete('all')
        if state == 'busy':
            self.angle = (self.angle+30) % 360
            self.spinner.create_arc(3, 3, 19, 19, start=self.angle, extent=250,
                                    outline=self.colors['accent'], width=2, style='arc')
        else:
            self.spinner.create_text(11, 11, text={'done':'✓', 'failed':'×', 'pending':'!'}.get(state, '•'),
                                     fill=self.colors['good'] if state=='done' else self.colors['warn'] if state=='pending' else self.colors['bad'] if state=='failed' else self.colors['muted'])
        started = getattr(self.root, '_started_at', None)
        seconds = max(0, int(time.monotonic()-started)) if started and self.root._ui_state == 'updating' else None
        self.elapsed.config(text=f'{seconds//60:02d}:{seconds%60:02d}' if seconds is not None else '')

    def _tick(self):
        self.tick_id = None
        if self.closed or not self.visible or self.root._closing:
            return
        self._paint_status()
        self.tick_id = self.root.after(150, self._tick)

    def _cancel_tick(self):
        if self.tick_id is not None:
            try:
                self.root.after_cancel(self.tick_id)
            except tk.TclError:
                pass
            self.tick_id = None

    def _drag_start(self, event):
        self.drag = (event.x_root, event.y_root, self.window.winfo_x(), self.window.winfo_y())

    def _drag_move(self, event):
        if self.drag:
            mx, my, x, y = self.drag
            place_window(self.window, (self.window.winfo_width(), self.window.winfo_height(), x+event.x_root-mx, y+event.y_root-my))

    def _drag_end(self, event):
        if not self.drag:
            return
        self.drag = None
        position = {'x': self.window.winfo_x(), 'y': self.window.winfo_y()}
        bounds = mini_bounds(monitor_area(self.window, position), position, self.window.winfo_width(), self.window.winfo_height())
        place_window(self.window, bounds);self._persist()

    def _persist(self):
        if self.window is not None and self.window.winfo_exists():
            self.root.cfg['mini_window'] = {'x': self.window.winfo_x(), 'y': self.window.winfo_y(), 'topmost': self.topmost}
            self.save_failed = not self.save(self.root.cfg)

    def _on_destroy(self, event):
        if event.widget is self.root:
            self.closed = True;self.visible = False;self._cancel_tick()
