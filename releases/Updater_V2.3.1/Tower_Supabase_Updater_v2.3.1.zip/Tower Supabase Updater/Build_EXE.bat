﻿@echo off
setlocal
cd /d "%~dp0"
title Build Tower Supabase Updater v2.2.0

echo ============================================================
echo  Tower Supabase Updater v2.2.0 - Stable Windows Builder
echo ============================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python is not installed or not in PATH.
    echo Install Python 3.11+ from python.org, then run this file again.
    pause
    exit /b 1
  )
  set "PY=python"
)

%PY% -m pip install --disable-pip-version-check --upgrade pyinstaller tkinterdnd2
if errorlevel 1 (
  echo Failed to install build dependencies.
  pause
  exit /b 1
)

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Tower Supabase Updater.spec" del /q "Tower Supabase Updater.spec"
if exist "Tower Supabase Updater" rmdir /s /q "Tower Supabase Updater"

%PY% -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --name "Tower Supabase Updater" ^
  --icon "Tower_Supabase_Updater.ico" ^
  --add-data "Tower_Supabase_Updater.ico;." ^
  --add-data "Tower_Supabase_Updater.png;." ^
  --collect-all tkinterdnd2 ^
  updater.py

if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)

xcopy /E /I /Y "dist\Tower Supabase Updater" ".\Tower Supabase Updater" >nul

echo.
echo ============================================================
echo DONE
echo App folder: %~dp0Tower Supabase Updater
echo ============================================================
start "" "%~dp0Tower Supabase Updater\Tower Supabase Updater.exe"
pause
