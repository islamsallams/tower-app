Tower Supabase Updater v1.5.4 (source + EXE builder)

الجديد:
- رفع worker.js و functions/ من نفس ZIP التطبيق إلى Cloudflare Worker.
- wrangler config يحتوي main + assets binding + run_worker_first عند وجود Worker.
- حزم HTML/CSS/JS القديمة التي بلا Worker ما زالت قابلة للنشر بالمنطق القديم.
- يحافظ على اسم Worker المحفوظ وإعدادات Cloudflare/Supabase المحلية.
- لا يشغّل SQL migrations تلقائيًا، ولا ينشئ Supabase backend غير موجود.

لإنشاء EXE على ويندوز:
1. فك الضغط في مجلد جديد.
2. شغّل Build_EXE.bat (بعد توافر Python ومتطلبات البناء).
3. استخدم EXE الناتج بدل الإصدار السابق بعد إغلاقه.

لا تستخدم «تحديث المشروع بالكامل» لحزمة V2.1.1 Foundation قبل تجهيز قاعدة البيانات وSecret لأن المصادقة والمالية غير مكتملتين.

V1.7.2: الحفاظ على Cron Triggers من wrangler.toml المرفق بالتطبيق عند النشر.
