﻿@echo off
cd /d "%~dp0"
py -3 launcher.py
if errorlevel 1 (
  echo.
  echo Failed to start Tower Supabase Updater.
  pause
)
