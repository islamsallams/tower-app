"""Local-only PostgreSQL backup utilities. No credentials are persisted."""
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, unquote, quote, urlunsplit

class BackupError(RuntimeError):
    pass

def combine_connection_credentials(raw_uri, database_password):
    """Combine Supabase URI and separately entered password without persisting either."""
    uri = (raw_uri or '').strip()
    password = database_password or ''
    if not uri.startswith(('postgresql://', 'postgres://')):
        raise BackupError('Paste a PostgreSQL connection URI first.')
    try:
        # Supabase's literal [YOUR-PASSWORD] placeholder is invalid in urlsplit netloc.
        # Substitute it before parsing, then replace any prefilled password below.
        prepared_uri = uri.replace('[YOUR-PASSWORD]', quote(password, safe=''))
        parsed = urlsplit(prepared_uri)
        if not parsed.hostname or not parsed.username or '@' in parsed.username:
            raise ValueError('Missing host or username')
        if not password:
            raise BackupError('Enter the database password in the separate Password field.')
        username = parsed.username  # Preserve percent-encoding from Supabase URI.
        host = parsed.netloc.rsplit('@', 1)[-1]
        encoded_password = quote(password, safe='')
        combined = urlunsplit((parsed.scheme, username + ':' + encoded_password + '@' + host,
                               parsed.path, parsed.query, parsed.fragment))
        parse_connection_uri(combined)
        return combined
    except (ValueError, AttributeError) as exc:
        raise BackupError('The connection URI is invalid. Copy it again from Supabase.') from exc


def parse_connection_uri(raw):
    uri = (raw or '').strip()
    if not uri.startswith(('postgresql://', 'postgres://')):
        raise BackupError('Use a PostgreSQL connection URI starting with postgresql://.')
    try:
        parsed = urlsplit(uri)
        host, port = parsed.hostname, parsed.port or 5432
        username, password = unquote(parsed.username or ''), unquote(parsed.password or '')
        dbname = unquote((parsed.path or '').lstrip('/'))
    except (ValueError, AttributeError) as exc:
        raise BackupError('The connection URI is not valid.') from exc
    if not host or not username or not password or not dbname or not (1 <= port <= 65535):
        raise BackupError('The connection URI must include host, port, database, username and password.')
    if any('\x00' in part or '\n' in part for part in (host, username, password, dbname)) or '@' in username or host.startswith('@') or any(c.isspace() for c in host):
        raise BackupError('The connection URI includes an invalid character.')
    return dict(host=host, port=str(port), user=username, password=password, dbname=dbname)

def discover_postgresql_bin_dirs():
    """Look for installed PostgreSQL client binaries without modifying PATH."""
    candidates = []
    if os.name == 'nt':
        for envvar in ('ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432'):
            root = os.environ.get(envvar)
            if root:
                base = Path(root) / 'PostgreSQL'
                if base.is_dir():
                    candidates.extend(p / 'bin' for p in base.iterdir() if p.is_dir())
        for envvar in ('LOCALAPPDATA', 'APPDATA'):
            root = os.environ.get(envvar)
            if root:
                candidates.append(Path(root) / 'Programs' / 'PostgreSQL' / 'bin')
    return [p for p in candidates if p.is_dir()]

def tool_path(name, bin_dir=None):
    """Resolve official client executables from chosen folder, PATH or install roots."""
    executable = name + ('.exe' if os.name == 'nt' else '')
    if bin_dir:
        selected = Path(bin_dir).expanduser()
        candidate = selected / executable
        return str(candidate.resolve()) if candidate.is_file() else None
    from_path = shutil.which(name) or (shutil.which(name + '.exe') if os.name == 'nt' else None)
    if from_path:
        return from_path
    for directory in discover_postgresql_bin_dirs():
        candidate = directory / executable
        if candidate.is_file():
            return str(candidate.resolve())
    return None


def sanitized_error(stderr):
    # Never echo process stderr: it can include passwords or connection URI details.
    text = (stderr or '').lower()
    if 'server version mismatch' in text or 'aborting because of server version mismatch' in text:
        return 'Installed pg_dump is older than the database server. Install a matching/newer PostgreSQL client.'
    if 'password authentication failed' in text or 'no password supplied' in text:
        return 'Database authentication failed. Check the connection URI and database password.'
    if 'could not translate host' in text or 'name or service not known' in text:
        return 'pg_dump could not resolve its configured database host. Check the saved Connection URI (not just a separately tested hostname).'
    if 'permission denied' in text or 'insufficient privilege' in text:
        return 'This database account cannot read all required objects. Backup was not completed.'
    if 'connection refused' in text or 'timeout expired' in text:
        return 'Could not connect to the database. Check network and the direct/pooler endpoint.'
    return 'Database backup failed. No finished backup was saved. Review your connection and PostgreSQL client.'

def _run(cmd, env, timeout=1800):
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    return subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=timeout, creationflags=flags)

def verify_archive(path, pg_restore=None):
    path = Path(path)
    if not path.is_file() or path.stat().st_size < 128:
        raise BackupError('Backup file is missing or too small.')
    with path.open('rb') as handle:
        if handle.read(5) != b'PGDMP':
            raise BackupError('Not a PostgreSQL custom-format backup (.dump).')
    restore = pg_restore or tool_path('pg_restore')
    if not restore:
        raise BackupError('pg_restore is required for archive verification. Install PostgreSQL client tools.')
    result = _run([restore, '--list', str(path)], os.environ.copy(), timeout=120)
    if result.returncode != 0 or not result.stdout.strip():
        raise BackupError('pg_restore could not read the backup archive.')
    hashobj = hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk: break
            hashobj.update(chunk)
    return dict(bytes=path.stat().st_size, sha256=hashobj.hexdigest(), toc_entries=sum(bool(re.match(r'^\d+;', line)) for line in result.stdout.splitlines()))

def create_backup(connection_uri, destination, pg_dump=None, pg_restore=None):
    info = parse_connection_uri(connection_uri)
    dumper = pg_dump or tool_path('pg_dump')
    if not dumper:
        raise BackupError('pg_dump not found. Install PostgreSQL client tools and restart the updater.')
    dest = Path(destination).expanduser().resolve()
    if dest.suffix.lower() != '.dump':
        raise BackupError('Choose a .dump file for the backup.')
    if dest.exists():
        raise BackupError('Backup file already exists. Choose a different filename to avoid overwriting it.')
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.with_name(dest.name + '.incomplete')
    if temp.exists():
        raise BackupError('A previous incomplete backup exists next to this filename. Remove it after checking.')
    # Resolve exactly the host parsed from the saved URI before pg_dump.
    # This distinguishes malformed/stale saved connection locations from
    # PostgreSQL authentication or network errors without exposing credentials.
    try:
        socket.getaddrinfo(info['host'], int(info['port']), type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError, ValueError) as exc:
        raise BackupError('The database host in the saved Connection URI cannot be resolved. Recopy the full Session Pooler URI from Supabase Connect and save it again. DNS tests of a different host do not validate the saved URI.') from exc
    env = os.environ.copy()
    env.update(PGPASSWORD=info['password'], PGSSLMODE='require', PGCONNECT_TIMEOUT='20')
    args = [dumper, '--format=custom', '--no-owner', '--no-acl', '--host', info['host'],
            '--port', info['port'], '--username', info['user'], '--dbname', info['dbname'],
            '--file', str(temp), '--verbose']
    try:
        try:
            result = _run(args, env)
        except subprocess.TimeoutExpired as exc:
            raise BackupError('Backup exceeded the 30-minute timeout. No finished backup was saved.') from exc
        if result.returncode != 0:
            raise BackupError(sanitized_error(result.stderr))
        verified = verify_archive(temp, pg_restore)
        os.replace(temp, dest)
        manifest = {'format': 'PostgreSQL custom archive', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                    'host': info['host'], 'database': info['dbname'], 'size_bytes': verified['bytes'],
                    'sha256': verified['sha256'], 'toc_entries': verified['toc_entries'],
                    'limitations': 'Does not back up Storage object bytes, Cloudflare secrets, or all managed Supabase platform settings.'}
        dest.with_suffix('.manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        return manifest
    finally:
        if temp.exists():
            try: temp.unlink()
            except OSError: pass

def inspect_backup(path, pg_restore=None):
    detail = verify_archive(path, pg_restore)
    manifest_file = Path(path).with_suffix('.manifest.json')
    if manifest_file.is_file():
        try:
            manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
            if manifest.get('sha256') != detail['sha256']:
                raise BackupError('Backup checksum differs from the saved manifest.')
            detail['manifest'] = manifest
        except (OSError, ValueError) as exc:
            raise BackupError('Backup manifest is not readable.') from exc
    return detail
