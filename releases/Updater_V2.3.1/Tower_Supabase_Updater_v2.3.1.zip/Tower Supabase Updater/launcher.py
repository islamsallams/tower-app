import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
VENDOR = BASE / "vendor"
LOG = BASE / "updater_startup.log"

def log(line):
    with LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")

if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))
try:
    import tkinterdnd2
except ImportError:
    log("Installing tkinterdnd2 into local vendor folder...")
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--retries", "1", "--timeout", "12", "--target", str(VENDOR), "tkinterdnd2"], capture_output=True, text=True, timeout=100)
        log("pip exit code: " + str(result.returncode))
        if result.returncode:
            log((result.stderr or result.stdout)[-3000:])
    except Exception as exc:
        log("Unable to install drag-drop: " + repr(exc))

try:
    import updater
    updater.App().mainloop()
except Exception:
    import traceback
    log(traceback.format_exc())
    raise
