"""Run with: python test_v216.py (requires updater dependencies)."""
import tempfile
import zipfile
from pathlib import Path
from updater import normalize_version, inspect_zip, read_version

for version in ('V2.4.90', 'V2.4.100', '2.4.90', 'V2.4.9'):
    assert normalize_version(version) == ('V' + version.lstrip('vV')), version
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    (root / 'app.js').write_text("const APP_VERSION = '2.4.90';", encoding='utf-8')
    assert read_version(root) == 'V2.4.90'
    archive = root / 'Tower_App_V2.4.90.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('index.html', '<html></html>')
        z.writestr('app.js', "const APP_VERSION = '2.4.90';")
    assert inspect_zip(archive)['version'] == 'V2.4.90'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('index.html', '<html></html>')
        z.writestr('app.js', "const APP_VERSION = '2.4.80';")
    try:
        inspect_zip(archive)
    except RuntimeError as e:
        assert 'Refusing ambiguous release' in str(e)
    else:
        raise AssertionError('Mismatched ZIP not rejected')
print('V2.1.6 regression checks: PASS')
