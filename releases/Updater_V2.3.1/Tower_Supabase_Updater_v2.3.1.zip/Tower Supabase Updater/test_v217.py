"""Non-Windows regression tests; Windows UI/DPAPI must be verified on Windows."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from updater import inspect_zip, read_version, safe_backup_uri, normalize_version
assert normalize_version('V2.4.100') == 'V2.4.100'
assert safe_backup_uri('postgresql://alice:supersecret@db.example.com:5432/postgres?sslmode=require') == 'postgresql://alice@db.example.com:5432/postgres'
assert 'supersecret' not in safe_backup_uri('postgresql://alice:supersecret@db.example.com:5432/postgres')
with TemporaryDirectory() as root:
    folder = Path(root)
    (folder/'app.js').write_text("const APP_VERSION = '2.4.90';", encoding='utf8')
    (folder/'tower-version.json').write_text('{"version":"V2.4.0"}', encoding='utf8')
    assert read_version(folder) == 'V2.4.90', 'app.js takes priority over stale marker'
    src = folder/'Tower_App_2.4.90_SOURCE.zip'
    with ZipFile(src,'w') as archive:
        archive.writestr('index.html','ok')
        archive.writestr('app.js',"const APP_VERSION = '2.4.0';")
    try: inspect_zip(src)
    except RuntimeError as e: assert 'SOURCE' in str(e)
    else: raise AssertionError('Source archive allowed')
    rel = folder/'Tower_App_V2.4.90.zip'
    with ZipFile(rel,'w') as archive:
        archive.writestr('index.html','ok')
        archive.writestr('app.js',"const APP_VERSION = '2.4.90';")
    assert inspect_zip(rel)['version'] == 'V2.4.90'
print('V2.1.7 tests: PASS')
