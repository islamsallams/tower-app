"""Local regression only; Windows DPAPI and live PostgreSQL still require Windows."""
from updater import safe_backup_uri
from backup_tools import combine_connection_credentials, parse_connection_uri, create_backup, BackupError
from unittest.mock import patch
assert safe_backup_uri('postgresql://postgres.project:[YOUR-PASSWORD]@aws-0-eu-west-1.pooler.supabase.com:5432/postgres?sslmode=require') == 'postgresql://postgres.project@aws-0-eu-west-1.pooler.supabase.com:5432/postgres'
assert safe_backup_uri('postgresql://postgres.project@aws-0-eu-west-1.pooler.supabase.com:5432/postgres') == 'postgresql://postgres.project@aws-0-eu-west-1.pooler.supabase.com:5432/postgres'
for invalid in ['postgresql://postgres.project@@aws-0-eu-west-1.pooler.supabase.com/postgres', 'postgresql://@aws-0-eu-west-1.pooler.supabase.com/postgres']:
    try: safe_backup_uri(invalid)
    except ValueError: pass
    else: raise AssertionError('Accepted malformed connection location')
combined=combine_connection_credentials('postgresql://postgres.project:[YOUR-PASSWORD]@aws-0-eu-west-1.pooler.supabase.com:5432/postgres', 'sample@not-real:pw')
info=parse_connection_uri(combined)
assert info['host']=='aws-0-eu-west-1.pooler.supabase.com' and info['password']=='sample@not-real:pw'
with patch('backup_tools.socket.getaddrinfo', side_effect=__import__('socket').gaierror('failed')):
    try: create_backup(combined, '/tmp/nonexistent-backup-for-test.dump', pg_dump='mock-pg-dump')
    except BackupError as exc:
        assert 'saved Connection URI' in str(exc)
        assert 'sample@not-real:pw' not in str(exc)
    else: raise AssertionError('DNS preflight not enforced')
print('V2.1.8 URI, error privacy and DNS regression: PASS')
