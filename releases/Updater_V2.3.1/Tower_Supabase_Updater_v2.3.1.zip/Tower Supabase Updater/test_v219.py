"""Non-Windows tests for persistent backup metadata and path handling."""
from unittest.mock import patch
from pathlib import Path
from tempfile import TemporaryDirectory
from updater import backup_summary, UPDATER_VERSION
assert UPDATER_VERSION == '2.2.0'
assert 'No successful' in backup_summary(None)
with TemporaryDirectory() as temp:
    file = Path(temp) / 'tower_database_20261015.dump'
    file.write_bytes(b'abcde')
    record = {'path': str(file), 'created_at': '2026-10-15 19:56:00 +0300'}
    message = backup_summary(record)
    assert file.name in message and '5 bytes' in message and 'not rechecked' in message
    file.unlink()
    assert 'missing' in backup_summary(record)
print('V2.1.9 backup metadata regression: PASS')
