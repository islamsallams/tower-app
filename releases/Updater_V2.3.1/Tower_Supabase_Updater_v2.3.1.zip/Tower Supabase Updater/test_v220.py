"""Local unit tests only. No Tk root, window, browser, CLI deploy or live database."""
import json
import queue
import shutil
import tempfile
import threading
import time
import types
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import updater as u
import updater_support as s

class Value:
    def __init__(self, value=''):
        self.value=value
    def get(self): return self.value
    def set(self, value): self.value=value
class Widget:
    def __init__(self): self.options={}
    def config(self, **kw): self.options.update(kw)
    def pack_forget(self): pass

def release(folder, version='2.5.189', **changes):
    path=Path(folder)/f'Tower_App_V{version}.zip'
    files={'app.js':f"const APP_VERSION='{version}';", 'index.html':'<html>fixture</html>',
           'worker.js':f"const APP_VERSION='{version}'; // /api/health /api/tower "+'x'*150,
           'styles.css':'body{}', 'wrangler.toml':'name="fixture"\n[triggers]\ncrons=["*/15 * * * *"]'}
    files.update(changes)
    with zipfile.ZipFile(path,'w') as z:
        for name, text in files.items():
            if text is not None: z.writestr(name,text)
    return path

class PureTests(unittest.TestCase):
    def test_version_order_numeric(self):
        self.assertGreater(s.version_key('V2.5.100'),s.version_key('V2.5.99'))
    def test_semver_prereleases(self):
        versions=['2.0.0-alpha','2.0.0-alpha.2','2.0.0-alpha.10','2.0.0-beta','2.0.0']
        self.assertEqual(versions,sorted(versions,key=s.version_key))
    def test_equal_is_info_not_block(self):
        kind,text=s.version_notice('V2.5.189','V2.5.189','V2.5.188')
        self.assertEqual(kind,'same');self.assertIn('الرفع متاح',text)
    def test_older_is_warning_not_block(self):
        kind,text=s.version_notice('V2.5.180','V2.5.189','V2.5.170')
        self.assertEqual(kind,'older');self.assertIn('⚠',text);self.assertIn('V2.5.189',text)
    def test_local_fallback(self):
        kind,text=s.version_notice('V2.5.180','Unable to verify','V2.5.189')
        self.assertEqual(kind,'older');self.assertIn('المحلية',text)
    def test_unknown_no_invented_comparison(self):
        self.assertEqual(s.version_notice('V2.5.189','—','—')[0],'neutral')
    def test_center_uses_work_area(self):
        self.assertEqual(s.centered_geometry((0,0,1920,1040),750,760),(750,760,585,140))
    def test_center_secondary_negative_monitor(self):
        self.assertEqual(s.centered_geometry((-1920,0,0,1040),750,760),(750,760,-1335,140))
    def test_small_display_clamps_size(self):
        w,h,x,y=s.centered_geometry((100,50,700,500),750,760)
        self.assertGreaterEqual(x,100);self.assertGreaterEqual(y,50);self.assertLessEqual(x+w,700);self.assertLessEqual(y+h,500)
    def test_ansi_and_credentials_scrubbed(self):
        sample='\x1b[31m401\x1b[0m\nAuthorization: Bearer fake-sensitive-token\n{"password": "two words secret"}\npostgresql://alice:fake-password@db.invalid/postgres\n--token fake-cli-token\nsb_secret_FAKESECRET'
        result=s.sanitize(sample)
        for token in ['\x1b','fake-sensitive-token','two words secret','fake-password','fake-cli-token','FAKESECRET']:
            self.assertNotIn(token,result)
        self.assertIn('401',result)
    def test_error_report_arabic_structure_and_401_action(self):
        title,body,tech=s.error_report('رفع Cloudflare','401 Unauthorized', ['تم تحديث الملفات المحلية'])
        self.assertTrue('\u0600'<=title[0]<='\u06ff');self.assertIn('ما الذي اكتمل',body);self.assertIn('تسجيل الدخول',body);self.assertIn('تم تحديث الملفات',body);self.assertIn('401',tech)
    def test_timeout_does_not_claim_upload_failed(self):
        _,body,_=s.error_report('التحقق','Deployment timed out')
        self.assertIn('لا يثبت أن الرفع لم يتم',body)
    def test_propagation_advises_no_reupload(self):
        _,body,_=s.error_report('رفع','Deployment command succeeded but propagation was not confirmed')
        self.assertIn('لا تعِد الرفع',body)
    def test_latest_prefers_version_not_modification_time(self):
        with tempfile.TemporaryDirectory() as d:
            high=release(d,'2.5.189');low=release(d,'2.5.99')
            import os
            os.utime(low,ns=(time.time_ns()+10**12,)*2)
            path,info,skipped=s.latest_release(d,lambda p:s.validate_release(p,u.inspect_zip))
            self.assertEqual(path,high);self.assertEqual(info['version'],'V2.5.189');self.assertEqual(skipped,0)
    def test_latest_skips_invalid_highest_and_source(self):
        with tempfile.TemporaryDirectory() as d:
            good=release(d,'2.5.188');bad=Path(d)/'Tower_App_V9.0.0.zip';bad.write_bytes(b'broken')
            (Path(d)/'Tower_App_V99.0.0-SOURCE.zip').write_bytes(b'source')
            path,_,skipped=s.latest_release(d,lambda p:s.validate_release(p,u.inspect_zip))
            self.assertEqual(path,good);self.assertEqual(skipped,1)
    def test_latest_no_recursive_surprise(self):
        with tempfile.TemporaryDirectory() as d:
            nested=Path(d)/'nested';nested.mkdir();release(nested)
            with self.assertRaisesRegex(ValueError,'No compatible'): s.latest_release(d,lambda p:s.validate_release(p,u.inspect_zip))
    def test_missing_folder(self):
        with self.assertRaisesRegex(ValueError,'missing'):s.latest_release('/tmp/definitely-missing-tower-release-folder',lambda p:None)
    def test_worker_is_required(self):
        with tempfile.TemporaryDirectory() as d:
            p=release(d,**{'worker.js':None})
            with self.assertRaisesRegex(ValueError,'worker.js'):s.validate_release(p,u.inspect_zip)
    def test_stale_worker_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=release(d,**{'worker.js':"const APP_VERSION='2.5.188';"})
            with self.assertRaisesRegex(RuntimeError,'BEFORE local update'):s.validate_release(p,u.inspect_zip)
    def test_zip_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=release(d,**{'..\\escape.txt':'bad'})
            with self.assertRaisesRegex(ValueError,'unsafe'):s.validate_release(p,u.inspect_zip)
    def test_duplicate_members_rejected(self):
        import warnings
        with tempfile.TemporaryDirectory() as d:
            p=release(d)
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                with zipfile.ZipFile(p,'a') as z:z.writestr('app.js','bad')
            with self.assertRaisesRegex(ValueError,'duplicate'):s.validate_release(p,u.inspect_zip)
    def test_snapshot_value_posts_set_on_main_queue(self):
        pending=[];seen=[];v=u.SnapshotValue('old',seen.append,pending.append)
        thread=threading.Thread(target=lambda:v.set('new'));thread.start();thread.join()
        self.assertEqual(v.get(),'new');self.assertEqual(seen,[]);pending.pop()();self.assertEqual(seen,['new'])
    def test_real_runtime_189_compatible(self):
        path=Path('/workspace/tower-app/releases/V2.5.189/Tower_App_V2.5.189.zip')
        if not path.exists(): self.skipTest('release fixture not present')
        self.assertEqual(s.validate_release(path,u.inspect_zip)['version'],'V2.5.189')

class PipelineTests(unittest.TestCase):
    def fixture(self, folder, fail=None, verify=True):
        path=release(folder)
        pending=[];states=[];phases=[];errors=[];events=[]
        app=types.SimpleNamespace(_post_ui=pending.append,_busy=True,_deploy_steps=[],current_version_var=Value('V2.5.180'),online_version_var=Value(),cloudflare_status_var=Value(),supabase_cli_status_var=Value(),deploy_stage_var=Value(),update_progress_var=Value(),_set_phase=lambda index,done:phases.append((index,len(done))),_set_update_state=lambda state,detail:states.append(state),_refresh_comparison=lambda:None,_play_completion_sound=lambda:events.append('sound'),_adopt_job_server=lambda *args:events.append('server'))
        def step(name,result):
            events.append(name)
            if fail==name:raise RuntimeError('401 Unauthorized' if name=='cloud' else name+' failed')
            return result
        job=types.SimpleNamespace(selected_zip=path,expected_version='V2.5.189',cloudflare_uploaded=False,online_url_var=Value('https://example.invalid'),_apply_local_update_core=lambda:step('local',('V2.5.180','V2.5.189')),restart_local_server=lambda:step('server-start',(None,None,5500)),_deploy_cloudflare_core=lambda:step('cloud','V2.5.189'),_deploy_supabase_functions_core=lambda:step('functions',[]),_online_version_probe=lambda _:step('verify',(verify,'V2.5.189' if verify else 'V2.5.188',200)))
        return app,job,pending,states,phases,errors,events
    def run_job(self, app,job,pending,errors):
        with patch.object(u,'show_error',side_effect=lambda *a,**kw:errors.append((a,kw))),patch.object(u.time,'sleep'):
            thread=threading.Thread(target=u.App._run_full_update_job,args=(app,job));thread.start();thread.join(timeout=5)
            self.assertFalse(thread.is_alive());self.assertTrue(app._busy)
            for callback in pending:callback()
    def test_full_success_no_real_deployment(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d);self.run_job(a,j,p,errors)
            self.assertEqual(states,['done']);self.assertFalse(errors);self.assertEqual([i for i,n in phases],[1,2,3,4]);self.assertEqual([n for i,n in phases],[1,2,3,4]);self.assertEqual(a.current_version_var.get(),'V2.5.189');self.assertFalse(a._busy)
    def test_partial_cloud_failure_keeps_local_success(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d,fail='cloud');self.run_job(a,j,p,errors)
            self.assertEqual(states,['failed']);self.assertNotIn('functions',events);self.assertTrue(any('الملفات المحلية' in x for x in a._deploy_steps));self.assertEqual(a._stage_index,2);self.assertTrue(errors)
    def test_verification_pending_is_not_failed_or_auto_retry(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d,verify=False);self.run_job(a,j,p,errors)
            self.assertEqual(states,['pending']);self.assertEqual(events.count('cloud'),1);self.assertEqual(events.count('verify'),6);self.assertFalse(errors);self.assertNotIn('sound',events)
    def test_supabase_failure_keeps_confirmed_cloudflare_stage(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d,fail='functions')
            original=j._deploy_cloudflare_core
            def uploaded():
                j.cloudflare_uploaded=True
                return original()
            j._deploy_cloudflare_core=uploaded
            self.run_job(a,j,p,errors)
            self.assertEqual(a._stage_index,3)
            self.assertTrue(any('التحقق من واجهته' in x for x in a._deploy_steps))
            self.assertFalse(any('لم يكتمل التحقق اللاحق' in x for x in a._deploy_steps))
            self.assertEqual(states,['failed'])
    def test_local_failure_stops_remote(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d,fail='local');self.run_job(a,j,p,errors)
            self.assertNotIn('cloud',events);self.assertEqual(a._stage_index,1);self.assertEqual(len(a._deploy_steps),1)
    def test_selection_changed_since_validation_aborts_before_copy(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d);j.expected_version='V2.5.188';self.run_job(a,j,p,errors)
            self.assertNotIn('local',events);self.assertEqual(a._stage_index,0)
    def test_older_selection_runs_without_version_block(self):
        with tempfile.TemporaryDirectory() as d:
            a,j,p,states,phases,errors,events=self.fixture(d);a.current_version_var.set('V9.0.0');self.run_job(a,j,p,errors)
            self.assertIn('cloud',events);self.assertEqual(states,['done'])
    def test_actual_local_core_preserves_settings_and_downgrade(self):
        with tempfile.TemporaryDirectory() as d:
            local=Path(d)/'app';local.mkdir();(local/'app.js').write_text("const APP_VERSION='9.0.0';");(local/'index.html').write_text('old')
            path=release(d)
            fake=types.SimpleNamespace(selected_zip=path,target_folder=local,cfg={},_refresh_target=lambda:None)
            fake._public_supabase_values=types.MethodType(u.App._public_supabase_values,fake)
            fake._sync_public_supabase_config=types.MethodType(u.App._sync_public_supabase_config,fake)
            old,new=u.App._apply_local_update_core(fake)
            self.assertEqual((old,new),('V9.0.0','V2.5.189'));self.assertEqual(json.loads((local/'tower-version.json').read_text())['version'],'V2.5.189')

class SelectionAndThreadTests(unittest.TestCase):
    def test_folder_choice_persists_and_failed_save_restores_previous(self):
        app=types.SimpleNamespace(_busy=False,_backup_busy=False,_selecting=False,cfg={'release_zip_folder':'old'},release_folder_label=Value(),release_folder_path_var=Value(),status_var=Value())
        with patch.object(u.filedialog,'askdirectory',return_value='/tmp/fixture-downloads'),patch.object(u,'save_config',return_value=True) as save:
            u.App.choose_release_folder(app)
            self.assertEqual(app.cfg['release_zip_folder'],'/tmp/fixture-downloads');save.assert_called_once()
        with patch.object(u.filedialog,'askdirectory',return_value='/tmp/another'),patch.object(u,'save_config',return_value=False),patch.object(u,'show_error') as error:
            u.App.choose_release_folder(app)
            self.assertEqual(app.cfg['release_zip_folder'],'/tmp/fixture-downloads');error.assert_called_once()

    def test_auto_import_only_stages_never_deploys(self):
        events=[]
        app=types.SimpleNamespace(_busy=False,_backup_busy=False,_selecting=False,cfg={'release_zip_folder':'fixture'},stage_zip=lambda path,auto=False:events.append(('stage',auto)),choose_release_folder=lambda:events.append('choose'),update_project_all=lambda:events.append('deploy'))
        u.App.auto_import_zip(app)
        self.assertEqual(events,[('stage',True)])
    def test_busy_drop_and_selection_leave_package_unchanged(self):
        app=types.SimpleNamespace(_busy=True,_backup_busy=False,selected_zip='keep')
        self.assertEqual(u.App._on_file_drop(app,object()),'copy')
        u.App.stage_zip(app,Path('ignored.zip'))
        self.assertEqual(app.selected_zip,'keep')
    def test_stale_selection_callback_cannot_replace_newer_choice(self):
        with tempfile.TemporaryDirectory() as d:
            first=release(d,'2.5.188');second=release(d,'2.5.189');pending=queue.Queue();gate=threading.Event()
            app=types.SimpleNamespace(_busy=False,_backup_busy=False,_selecting=False,_selection_id=0,cfg={},selected_zip=None,_post_ui=pending.put,_refresh_comparison=lambda:None)
            for name in ('new_version_var','release_file_var','status_var','deploy_stage_var'):setattr(app,name,Value())
            for name in ('update_btn','auto_import_btn','drop_title','drop','progress_area'):setattr(app,name,Widget())
            validate=u.validate_release
            def delayed(path,inspector):
                if Path(path)==first:gate.wait(timeout=2)
                return validate(path,inspector)
            with patch.object(u,'validate_release',side_effect=delayed):
                u.App.stage_zip(app,first);u.App.stage_zip(app,second)
                pending.get(timeout=2)()
                self.assertEqual(app.selected_zip,second)
                gate.set();pending.get(timeout=2)()
                self.assertEqual(app.selected_zip,second)
    def test_snapshot_backend_preparation_never_reads_live_tk_values(self):
        with tempfile.TemporaryDirectory() as d:
            path=release(d);local=Path(d)/'local';local.mkdir()
            main_id=threading.get_ident();pending=[]
            class MainOnly(Value):
                def get(self):
                    if threading.get_ident()!=main_id:raise AssertionError('Tk get in worker')
                    return super().get()
                def set(self,value):
                    if threading.get_ident()!=main_id:raise AssertionError('Tk set in worker')
                    super().set(value)
            app=types.SimpleNamespace(selected_zip=path,target_folder=local,cfg={},httpd=None,_port=lambda:5500,_post_ui=pending.append,new_version_var=MainOnly('V2.5.189'))
            for name,value in [('online_url_var','https://example.invalid'),('worker_name_var','fixture'),('update_progress_var',''),('supabase_cli_status_var','')]:setattr(app,name,MainOnly(value))
            job=u.UpdateJob(app);app.worker_name_var.value='changed-after-start';result=[];errors=[]
            def worker():
                try:result.append(job._prepare_cloudflare_assets())
                except Exception as exc:errors.append(exc)
            thread=threading.Thread(target=worker);thread.start();thread.join(timeout=3)
            self.assertFalse(errors);self.assertTrue(result)
            root,version,copied=result[0]
            try:
                cfg=json.loads((root/'wrangler.jsonc').read_text())
                self.assertEqual(cfg['name'],'fixture');self.assertEqual(version,'V2.5.189')
                self.assertFalse((root/'public'/'worker.js').exists());self.assertTrue(cfg['keep_vars'])
                self.assertEqual(cfg['triggers']['crons'],['*/15 * * * *'])
            finally:shutil.rmtree(root)
    def test_crc_failure_rejected_before_selection(self):
        with tempfile.TemporaryDirectory() as d:
            path=release(d,**{'payload.txt':'UNIQUE_CRC_FIXTURE_TEXT'})
            path.write_bytes(path.read_bytes().replace(b'UNIQUE_CRC_FIXTURE_TEXT',b'ALTERED_CRC_FIXTURE_TXT',1))
            with self.assertRaisesRegex(ValueError,'integrity'):s.validate_release(path,u.inspect_zip)
    def test_copyright_and_phone_are_exact_english_without_contact_label(self):
        source=Path(u.__file__).read_text()
        self.assertIn('© Islam Sallam. All rights reserved.',source)
        self.assertIn("text='01095851719'",source)
        self.assertNotIn('Contact:',source)
    def test_no_duplicate_app_method_or_missing_snapshot_method(self):
        import ast
        tree=ast.parse(Path(u.__file__).read_text());app=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='App')
        names=[n.name for n in app.body if isinstance(n,ast.FunctionDef)]
        self.assertEqual(len(names),len(set(names)))
        for name in u.UpdateJob.METHODS:self.assertTrue(hasattr(u.App,name),name)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    Path('TEST_RESULTS_V2_2_0.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'guiTestsExecuted':False,'liveDeploymentExecuted':False},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
