"""Auto Update contracts. No Tk root, GUI, browser, real CLI deploy or live database."""
import ast
import queue
import tempfile
import threading
import types
import unittest
from pathlib import Path
from unittest.mock import patch
import updater as u
import updater_support as support
from test_v220 import Value, release

class Widget:
    def __init__(self, master=None, **kw):self.master=master;self.options=kw;self.packs=[];self.bindings={}
    def config(self, **kw):self.options.update(kw)
    def pack(self, **kw):self.packs.append(kw)
    def pack_forget(self):pass
    def grid(self, **kw):self.grid_options=kw
    def place(self, **kw):self.place_options=kw
    def columnconfigure(self,*a,**kw):pass
    def bind(self,event,handler):self.bindings[event]=handler
    def delete(self,*a):pass
    def create_text(self,*a,**kw):pass

class AutoUpdateTests(unittest.TestCase):
    def app(self, folder=''):
        pending=queue.Queue();events=[]
        a=types.SimpleNamespace(_busy=False,_backup_busy=False,_selecting=False,_selection_id=0,cfg={'release_zip_folder':folder} if folder else {},selected_zip=None,_post_ui=pending.put)
        for n in ('new_version_var','release_file_var','status_var','deploy_stage_var'):setattr(a,n,Value())
        for n in ('update_btn','auto_import_btn','drop_title','drop','progress_area'):setattr(a,n,Widget())
        a.stage_zip=types.MethodType(u.App.stage_zip,a)
        a.choose_release_folder=lambda:events.append('choose-folder')
        a._refresh_comparison=lambda:events.append('comparison')
        def update():
            events.append(('update',a.selected_zip,a.new_version_var.get()));a._busy=True
        a.update_project_all=update
        return a,pending,events
    def complete(self,pending):pending.get(timeout=3)()

    def test_auto_click_selects_highest_valid_and_deploys_once_after_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            high=release(folder,'2.5.197');release(folder,'2.5.99');(Path(folder)/'Tower_App_V9.0.0.zip').write_bytes(b'broken')
            a,p,e=self.app(folder);u.App.auto_update_project(a)
            self.assertTrue(a._selecting);self.assertFalse(e);self.complete(p)
            self.assertEqual([x for x in e if isinstance(x,tuple)],[('update',high,'V2.5.197')]);self.assertLess(e.index('comparison'),1)

    def test_repeated_auto_clicks_during_selection_and_deploy_do_not_duplicate(self):
        with tempfile.TemporaryDirectory() as folder:
            release(folder);a,p,e=self.app(folder)
            u.App.auto_update_project(a);u.App.auto_update_project(a);self.complete(p);u.App.auto_update_project(a)
            self.assertEqual(len([x for x in e if isinstance(x,tuple)]),1)

    def test_manual_file_and_drop_default_only_stage(self):
        with tempfile.TemporaryDirectory() as folder:
            path=release(folder);a,p,e=self.app(folder)
            a.stage_zip(path);self.complete(p)
            self.assertEqual(a.selected_zip,path);self.assertEqual(e,['comparison']);self.assertIn('Manual Update',a.deploy_stage_var.get())

    def test_folder_cancel_never_stages_or_deploys_old_selection(self):
        a,p,e=self.app();a.selected_zip=Path('previous.zip');u.App.auto_update_project(a)
        self.assertEqual(e,['choose-folder']);self.assertFalse(a._selecting);self.assertTrue(p.empty())

    def test_first_folder_choice_continues_same_click(self):
        with tempfile.TemporaryDirectory() as folder:
            path=release(folder);a,p,e=self.app()
            a.choose_release_folder=lambda:a.cfg.update(release_zip_folder=folder)
            u.App.auto_update_project(a);self.complete(p)
            self.assertEqual([x[1] for x in e if isinstance(x,tuple)],[path])

    def test_invalid_or_source_only_folder_never_deploys_previous_package(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder)/'Tower_App_V99.0.0-SOURCE.zip').write_bytes(b'not-runtime')
            a,p,e=self.app(folder);a.selected_zip=Path('previous.zip')
            with patch.object(u,'show_error') as error:
                u.App.auto_update_project(a);self.complete(p)
                self.assertIsNone(a.selected_zip);self.assertFalse(a._selecting);self.assertFalse(e);error.assert_called_once()
                self.assertEqual(a.update_btn.options['state'],'disabled')

    def test_failed_validation_does_not_schedule_automatic_retry(self):
        with tempfile.TemporaryDirectory() as folder:
            release(folder);a,p,e=self.app(folder)
            with patch.object(u,'latest_release',side_effect=ValueError('fixture validation failure')),patch.object(u,'show_error'):
                u.App.auto_update_project(a);self.complete(p)
            self.assertFalse(e);self.assertTrue(p.empty());self.assertEqual(a.auto_import_btn.options['state'],'normal')

    def test_same_and_older_warnings_do_not_block_auto_update(self):
        with tempfile.TemporaryDirectory() as folder:
            release(folder,'2.5.189')
            for current in ('V2.5.189','V9.0.0'):
                a,p,e=self.app(folder);notices=[]
                a._refresh_comparison=lambda:notices.append(support.version_notice(a.new_version_var.get(),current,current)[0])
                u.App.auto_update_project(a);self.complete(p)
                self.assertEqual(notices,['same' if current=='V2.5.189' else 'older']);self.assertEqual(len(e),1)

    def test_superseded_auto_import_cannot_deploy_manually_selected_package(self):
        with tempfile.TemporaryDirectory() as folder:
            first=release(folder,'2.5.188');second=release(folder,'2.5.197');a,p,e=self.app(folder);gate=threading.Event()
            def latest(*args):gate.wait(timeout=3);return first,u.validate_release(first,u.inspect_zip),0
            with patch.object(u,'latest_release',side_effect=latest):
                u.App.auto_update_project(a);a.stage_zip(second);self.complete(p)
                self.assertEqual(a.selected_zip,second);gate.set();self.complete(p)
            self.assertEqual(e,['comparison'])

    def test_closing_invalidates_pending_auto_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            release(folder);a,p,e=self.app(folder);u.App.auto_update_project(a);a._selection_id+=1;self.complete(p)
            self.assertFalse(e);self.assertIsNone(a.selected_zip)

    def test_backup_busy_blocks_auto_and_backup_started_during_selection_does_not_deploy(self):
        a,p,e=self.app('unused');a._backup_busy=True;u.App.auto_update_project(a);self.assertFalse(e);self.assertTrue(p.empty())
        with tempfile.TemporaryDirectory() as folder:
            release(folder);a,p,e=self.app(folder);u.App.auto_update_project(a);a._backup_busy=True;self.complete(p)
            self.assertEqual(e,['comparison']);self.assertIn('عملية أخرى',a.status_var.get());self.assertIn('Manual Update',a.status_var.get())

    def test_auto_button_is_primary_centered_manual_is_secondary_inside_card_and_loader_sibling_valid(self):
        a=types.SimpleNamespace(_compact=False,copy_copyright_phone=lambda:None,copy_log=lambda:None,open_settings=lambda:None,check_online=lambda:None,choose_zip=lambda:None,choose_release_folder=lambda:None,auto_update_project=lambda:None,update_project_all=lambda:None)
        for n in ('current_version_var','online_version_var','new_version_var','release_file_var','comparison_var','release_folder_label','update_progress_var','deploy_stage_var','status_var'):setattr(a,n,Value())
        with patch.object(u.tk,'Frame',Widget),patch.object(u.tk,'Label',Widget),patch.object(u.tk,'Button',Widget),patch.object(u.tk,'Canvas',Widget),patch.object(u.tk,'PhotoImage',side_effect=RuntimeError('no image in mock')),patch.object(u,'ModernButton',Widget):
            u.App._build(a)
        self.assertEqual(a.auto_import_btn.options['text'],'↑ Auto Update');self.assertTrue(a.auto_import_btn.options['primary']);self.assertEqual(a.auto_import_btn.packs[-1]['anchor'],'center')
        self.assertIs(a.update_btn.master.master,a.drop);self.assertEqual(a.update_btn.options['text'],'↑ Manual Update');self.assertFalse(a.update_btn.options.get('primary',False));self.assertIs(a.progress_area.master,a.auto_import_btn.master.master)
        self.assertNotIn('<Button-1>',a.update_btn.bindings)

    def test_manual_picker_and_drop_are_ignored_during_validation(self):
        a,p,e=self.app();a._selecting=True
        with patch.object(u.filedialog,'askopenfilename') as choose:
            u.App.choose_zip(a);choose.assert_not_called()
        self.assertEqual(u.App._on_file_drop(a,object()),'copy');self.assertFalse(e)

    def test_loading_anchor_uses_auto_container_not_nested_manual_card(self):
        src=Path(u.__file__).read_text();tree=ast.parse(src);app=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='App')
        state=next(n for n in app.body if isinstance(n,ast.FunctionDef) and n.name=='_set_update_state');body=ast.get_source_segment(src,state)
        self.assertIn('before=self.auto_import_btn.master',body);self.assertNotIn('before=self.update_btn.master',body)

if __name__=='__main__':unittest.main(verbosity=2)
