"""Floating-window model contracts. No Tk root, real GUI, network or deployment."""
import types
import unittest
from unittest.mock import patch, MagicMock
import updater as u
import floating_updater as f
from test_v220 import Value


class Widget:
    def __init__(self, master=None, **options):
        self.master=master;self.options=options;self.bindings={};self.exists=True
        self.x,self.y,self.width,self.height=10,20,384,274
    def pack(self, **kw):pass
    def grid(self, **kw):pass
    def columnconfigure(self, *a, **kw):pass
    def config(self, **kw):self.options.update(kw)
    configure=config
    def bind(self, name, callback, **kw):self.bindings[name]=callback
    def withdraw(self):self.hidden=True
    def deiconify(self):self.hidden=False
    def lift(self):self.lifted=True
    def attributes(self, key, value):self.options[key]=value
    def protocol(self, *args):pass
    def overrideredirect(self, value):pass
    def resizable(self, *args):pass
    def update_idletasks(self):pass
    def winfo_exists(self):return self.exists
    def winfo_x(self):return self.x
    def winfo_y(self):return self.y
    def winfo_width(self):return self.width
    def winfo_height(self):return self.height
    def winfo_reqwidth(self):return self.width
    def winfo_reqheight(self):return self.height
    def winfo_id(self):return 42
    def geometry(self, value):self.geometry_text=value
    def delete(self, *a):pass
    def create_arc(self, *a, **kw):self.arc=kw
    def create_text(self, *a, **kw):self.symbol=kw


class Root(Widget):
    def __init__(self):
        super().__init__();self.cfg={'release_zip_folder':'fixture-folder','existing-setting':'keep'}
        self._busy=False;self._backup_busy=False;self._selecting=False;self._closing=False
        self._ui_state='ready';self.settings_window=None;self.modal=None;self._state='normal'
        self.timers={};self.sequence=0;self.updates=0
        for name in ['new_version_var','current_version_var','online_version_var','update_progress_var']:
            setattr(self,name,Value('fixture'))
    def grab_current(self):return self.modal
    def state(self):return self._state
    def withdraw(self):self._state='withdrawn'
    def deiconify(self):self._state='normal'
    def iconify(self):self._state='iconic'
    def after(self, delay, action):
        self.sequence+=1;key=str(self.sequence);self.timers[key]=action;return key
    def after_idle(self, action):return self.after(0,action)
    def after_cancel(self, key):self.timers.pop(key,None)
    def auto_update_project(self):self.updates+=1;self._selecting=True


class FloatingTests(unittest.TestCase):
    def setUp(self):
        self.patches=[patch.object(f.tk,n,Widget) for n in ['Toplevel','Frame','Label','Button','Canvas']]
        self.patches += [patch.object(f,'monitor_area',return_value=(0,0,1920,1040)),patch.object(f,'place_window',side_effect=self.place)]
        for p in self.patches:p.start();self.addCleanup(p.stop)
        self.root=Root();self.saved=[]
        self.colors=dict(bg='#111111',panel='#222222',border='#333333',text='white',muted='gray',accent='blue',good='green',warn='orange',bad='red')
        self.c=f.FloatingController(self.root,Widget(),lambda cfg:self.saved.append(dict(cfg)) or True,self.colors,'2.3.0')
    @staticmethod
    def place(window,bounds):window.width,window.height,window.x,window.y=bounds
    def test_open_is_display_only_and_three_version_labels_share_original_variables(self):
        self.c.show();self.assertEqual(self.root.updates,0);self.assertEqual(self.root.state(),'withdrawn')
        for i,name in enumerate(['new_version_var','current_version_var','online_version_var']):
            self.assertIs(self.c.version_labels[i].options['textvariable'],getattr(self.root,name))
    def test_one_widget_and_one_animation_timer_across_repeated_open_and_restore(self):
        self.c.show();win=self.c.window;self.c.show();self.assertIs(self.c.window,win);self.assertEqual(len(self.root.timers),1)
        self.c.restore_full();self.assertFalse(self.c.visible);self.assertEqual(len(self.root.timers),0);self.assertEqual(self.root.state(),'normal')
        self.c.show();self.assertIs(self.c.window,win);self.assertEqual(len(self.root.timers),1)
    def test_auto_calls_existing_entry_point_once_and_selection_blocks_repeated_click(self):
        self.c.show();self.c.start_update();self.c.start_update();self.assertEqual(self.root.updates,1)
        self.assertEqual(self.c.auto.options['state'],'disabled');self.assertIn('فحص',self.c.auto.options['text'])
    def test_first_folder_choice_expands_before_calling_existing_auto(self):
        self.root.cfg.pop('release_zip_folder');self.c.show()
        def auto():self.assertEqual(self.root.state(),'normal');self.assertFalse(self.c.visible);self.root.updates+=1
        self.root.auto_update_project=auto;self.c.start_update();self.assertEqual(self.root.updates,1)
    def test_update_and_backup_busy_block_any_new_job(self):
        for name in ['_busy','_backup_busy','_selecting']:
            setattr(self.root,name,True);self.c.start_update();setattr(self.root,name,False)
        self.assertEqual(self.root.updates,0)
    def test_pending_verification_disables_retry_and_failed_state_allows_explicit_retry(self):
        self.c.show();self.root._ui_state='pending';self.c._paint_status();self.c.start_update()
        self.assertEqual(self.root.updates,0);self.assertEqual(self.c.auto.options['state'],'disabled');self.assertIn('لا تعِد',self.c.status.options['text'])
        self.root._ui_state='failed';self.c._paint_status();self.assertEqual(self.c.auto.options['state'],'normal');self.c.start_update();self.assertEqual(self.root.updates,1)
    def test_poll_reads_same_stage_and_result_without_fabricated_percentage(self):
        self.c.show();self.root._busy=True;self.root._ui_state='updating';self.root.update_progress_var.set('رفع Cloudflare')
        self.c._paint_status();self.assertEqual(self.c.status.options['text'],'رفع Cloudflare');self.assertTrue(hasattr(self.c.spinner,'arc'))
        self.root._busy=False;self.root._ui_state='done';self.c._paint_status();self.assertIn('بنجاح',self.c.status.options['text']);self.assertEqual(self.c.spinner.symbol['text'],'✓')
    def test_pin_toggle_updates_native_attribute_and_saves_only_extra_ui_metadata(self):
        self.c.show();self.c.toggle_pin();self.assertFalse(self.c.topmost);self.assertFalse(self.c.window.options['-topmost'])
        self.assertFalse(self.root.cfg['mini_window']['topmost']);self.assertEqual(self.root.cfg['existing-setting'],'keep')
    def test_saved_position_and_pin_restore_without_running_update(self):
        self.root.cfg['mini_window']={'x':200,'y':300,'topmost':False}
        other=f.FloatingController(self.root,Widget(),lambda _:True,self.colors,'2.3.0');other.show()
        self.assertEqual((other.window.x,other.window.y),(200,300));self.assertFalse(other.topmost);self.assertEqual(self.root.updates,0)
    def test_drag_does_not_deploy_and_release_saves_visible_position(self):
        self.c.show();x,y=self.c.window.x,self.c.window.y
        self.c._drag_start(types.SimpleNamespace(x_root=100,y_root=100));self.c._drag_move(types.SimpleNamespace(x_root=130,y_root=120))
        self.assertEqual((self.c.window.x,self.c.window.y),(x+30,y+20));self.c._drag_end(None)
        self.assertTrue(self.saved);self.assertIsNone(self.c.drag);self.assertEqual(self.root.updates,0)
    def test_normal_windows_minimize_opens_widget_but_explicit_taskbar_minimize_does_not_loop(self):
        self.root._state='iconic';self.c._check_minimize();self.assertTrue(self.c.visible)
        self.c.minimize_taskbar();self.assertEqual(self.root.state(),'iconic');self.assertFalse(self.c.visible)
        self.c._on_map(types.SimpleNamespace(widget=self.root));self.c._check_minimize();self.assertFalse(self.c.visible)
        self.root._state='normal';self.c._on_map(types.SimpleNamespace(widget=self.root));self.root._state='iconic'
        self.c._check_minimize();self.assertTrue(self.c.visible)
    def test_modal_or_settings_stays_visible_instead_of_hidden_with_root(self):
        self.root.modal=Widget();self.c.show();self.assertEqual(self.root.state(),'normal');self.assertTrue(self.root.modal.lifted);self.assertFalse(self.c.visible)
        self.root.modal=None;self.root.settings_window=Widget();self.root.settings_window.state=lambda:'normal'
        self.c.show();self.assertTrue(self.root.settings_window.lifted);self.assertFalse(self.c.visible)
    def test_root_shutdown_cancels_timer_and_prevents_reopening(self):
        self.c.show();self.c._on_destroy(types.SimpleNamespace(widget=self.root))
        self.assertTrue(self.c.closed);self.assertFalse(self.root.timers);self.c.show();self.assertFalse(self.c.visible)
    def test_failed_position_save_does_not_start_job_or_crash_progress(self):
        self.c.show();self.c.save=lambda _:False;self.c._persist();self.c._paint_status()
        self.assertIn('تعذر حفظ',self.c.status.options['text']);self.assertEqual(self.root.updates,0)
    def test_error_handler_restores_full_window_before_creating_modal(self):
        self.root._floating=self.c;self.c.show()
        with patch.object(u,'error_report',side_effect=ValueError('stop before GUI')):
            with self.assertRaisesRegex(ValueError,'stop before GUI'):u.show_error('fixture','fixture',parent=self.root)
        self.assertFalse(self.c.visible);self.assertEqual(self.root.state(),'normal')
    def test_requested_font_layout_can_grow_within_work_area(self):
        self.c._build();self.c.window.height=450;self.c.show();self.assertEqual(self.c.window.height,450)


class BoundsTests(unittest.TestCase):
    def test_offscreen_or_disconnected_monitor_is_clamped(self):
        self.assertEqual(f.mini_bounds((0,0,1280,720),{'x':5000,'y':-200})[2:],(896,0))
    def test_left_and_above_primary_monitors_preserve_negative_absolute_coordinates(self):
        self.assertEqual(f.mini_bounds((-1920,-1080,0,0),{'x':-1500,'y':-900})[2:],(-1500,-900))
    def test_small_display_never_places_the_card_outside_work_area(self):
        w,h,x,y=f.mini_bounds((20,30,300,250),{'x':-100,'y':900})
        self.assertGreaterEqual(x,20);self.assertGreaterEqual(y,30);self.assertLessEqual(x+w,300);self.assertLessEqual(y+h,250)
    def test_invalid_saved_settings_have_safe_defaults(self):
        for saved in [None,[],{'x':True,'y':20},{'x':'200','y':20},{'x':10**9,'y':0}]:self.assertIsNone(f.saved_position(saved))
    def test_win32_uses_absolute_coordinates_after_tk_geometry(self):
        user=MagicMock();user.GetParent.return_value=77;win=Widget()
        with patch.object(f.os,'name','nt'),patch.object(f.ctypes,'windll',types.SimpleNamespace(user32=user),create=True):
            f.place_window(win,(384,274,-1500,-900))
        user.SetWindowPos.assert_called_once_with(77,None,-1500,-900,384,274,0x0014)


if __name__=='__main__':unittest.main()
