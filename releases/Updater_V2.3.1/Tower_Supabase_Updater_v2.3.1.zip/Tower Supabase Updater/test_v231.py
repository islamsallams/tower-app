"""Compact action-slot contracts; no Tk root, GUI, real deployment or database."""
import types
from unittest.mock import patch
import unittest
import test_v230 as base
import floating_updater as f
from test_v220 import Value


class CompactTests(base.FloatingTests):
    def setUp(self):
        super().setUp()
        self.root.status_var=Value()
        def place(widget, **kw):widget.placed=kw
        def forget(widget):widget.placed=None
        for name,method in [('place',place),('place_forget',forget)]:
            p=patch.object(base.Widget,name,method,create=True);p.start();self.addCleanup(p.stop)

    def test_pending_verification_disables_retry_and_failed_state_allows_explicit_retry(self):
        self.c.show();self.root._ui_state='pending';self.c._paint_status();self.c.start_update()
        self.assertEqual(self.root.updates,0);self.assertEqual(self.c.auto.options['state'],'disabled')
        self.assertIn('التحقق معلّق',self.c.auto.options['text']);self.assertEqual(self.c.auto.options['bg'],self.colors['warn'])
        self.root._ui_state='failed';self.c._paint_status();self.assertEqual(self.c.auto.options['state'],'normal')
        self.assertIn('إعادة المحاولة',self.c.auto.options['text']);self.c.start_update();self.assertEqual(self.root.updates,1)

    def test_poll_reads_same_stage_and_result_without_fabricated_percentage(self):
        self.c.show();self.root._busy=True;self.root._ui_state='updating';self.root._stage_index=2
        self.c._paint_status();self.assertEqual(self.c.auto.options['text'],'رفع Cloudflare')
        self.assertEqual(self.c.auto.options['state'],'disabled');self.assertTrue(self.c.spinner.placed)
        self.assertIs(self.c.spinner.master,self.c.auto.master)
        self.root._busy=False;self.root._ui_state='done';self.c._paint_status()
        self.assertIn('تم التحديث',self.c.auto.options['text']);self.assertEqual(self.c.auto.options['bg'],self.colors['good'])
        self.assertIsNone(self.c.spinner.placed)

    def test_failed_position_save_does_not_start_job_or_crash_progress(self):
        self.c.show();self.c.save=lambda _:False;self.c._persist();self.c._paint_status()
        self.assertIn('تعذر حفظ',self.root.status_var.get());self.assertEqual(self.root.updates,0)

    def test_layout_has_no_separate_status_elapsed_or_log_row(self):
        self.c.show();self.assertFalse(hasattr(self.c,'status'));self.assertFalse(hasattr(self.c,'elapsed'))
        self.assertIs(self.c.auto.master,self.c._action_frame);self.assertIs(self.c.spinner.master,self.c._action_frame)

    def test_short_success_then_returns_to_auto_without_running_a_job(self):
        self.c.show();self.root._ui_state='done'
        with patch.object(f.time,'monotonic',return_value=100):
            self.c._paint_status();self.c.start_update();self.assertEqual(self.root.updates,0)
            self.assertEqual(self.c.auto.options['state'],'disabled')
        with patch.object(f.time,'monotonic',return_value=106):
            self.c._paint_status();self.assertEqual(self.c.auto.options['text'],'Auto Update')
            self.assertEqual(self.root.updates,0);self.c.start_update();self.assertEqual(self.root.updates,1)

    def test_compact_target_is_half_previous_minimum_but_still_honors_larger_font_requests(self):
        self.c._build();self.c.window.winfo_reqwidth=lambda:300;self.c.window.winfo_reqheight=lambda:110
        self.c.show();self.assertEqual((self.c.window.width,self.c.window.height),(336,136))
        self.c.restore_full();self.c.window.winfo_reqheight=lambda:220;self.c.show()
        self.assertEqual(self.c.window.height,220)

    def test_each_shared_phase_gets_short_label_and_busy_stays_disabled(self):
        self.c.show();self.root._busy=True;self.root._ui_state='updating'
        labels=['فحص الحزمة','تحديث المحلي','رفع Cloudflare','دوال Supabase','التحقق الأونلاين']
        for index,label in enumerate(labels):
            self.root._stage_index=index;self.c._paint_status()
            self.assertEqual(self.c.auto.options['text'],label);self.assertEqual(self.c.auto.options['state'],'disabled')
        self.root._stage_index=90;self.c._paint_status();self.assertIn('جاري التحديث',self.c.auto.options['text'])


class BoundsTests(base.BoundsTests):
    pass


if __name__=='__main__':unittest.main()
