"""Tower Supabase Updater V2.2.0 — pure selection, geometry and diagnostic helpers.
___________________________
No GUI is created and no network request is sent on import.
"""
import ctypes
import os
import re
import zipfile
from pathlib import Path

RELEASE_NAME = re.compile(r'Tower_App_[vV](\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)\.zip', re.I)
STAGES = ('فحص الحزمة', 'الملفات المحلية', 'رفع Cloudflare', 'دوال Supabase', 'التحقق الأونلاين')

def version_key(value):
    m = re.fullmatch(r'[vV]?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?', str(value).strip())
    if not m:
        return None
    pre = tuple((0, int(p)) if p.isdigit() else (1, p) for p in (m[4] or '').split('.'))
    return tuple(int(m[i]) for i in (1, 2, 3)) + (0 if m[4] else 1, pre if m[4] else ())

def version_notice(selected, online, local):
    chosen = version_key(selected)
    current, scope = (online, 'الأونلاين') if version_key(online) else (local, 'المحلية')
    old = version_key(current)
    if not chosen:
        return 'neutral', 'اختر حزمة تحديث لعرض الإصدار.'
    if old is None:
        return 'neutral', 'الإصدار الحالي غير متاح للمقارنة؛ يمكنك متابعة التحديث.'
    if chosen == old:
        return 'same', f'ⓘ نفس الإصدار — المختار {selected} مطابق للنسخة {scope} {current}. الرفع متاح.'
    if chosen < old:
        return 'older', f'⚠ إصدار أقدم — المختار {selected}، والنسخة {scope} {current}. المتابعة ترجع التطبيق للإصدار المختار.'
    return 'newer', f'↑ إصدار أحدث — من النسخة {scope} {current} إلى {selected}.'

def centered_geometry(rect, desired_width, desired_height):
    left, top, right, bottom = rect
    width = min(desired_width, max(1, right-left-24))
    height = min(desired_height, max(1, bottom-top-24))
    return width, height, left+(right-left-width)//2, top+(bottom-top-height)//2

def work_area(window=None, parent=None):
    if os.name == 'nt':
        try:
            from ctypes import wintypes
            class Info(ctypes.Structure):
                _fields_ = [('size', wintypes.DWORD), ('monitor', wintypes.RECT), ('work', wintypes.RECT), ('flags', wintypes.DWORD)]
            user = ctypes.windll.user32
            user.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
            user.MonitorFromWindow.restype = wintypes.HANDLE
            user.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
            user.MonitorFromPoint.restype = wintypes.HANDLE
            user.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(Info)]
            if parent is not None:
                monitor = user.MonitorFromWindow(parent.winfo_id(), 2)
            else:
                point = wintypes.POINT()
                user.GetCursorPos(ctypes.byref(point))
                monitor = user.MonitorFromPoint(point, 2)
            info = Info();info.size = ctypes.sizeof(info)
            if user.GetMonitorInfoW(monitor, ctypes.byref(info)):
                r = info.work
                return r.left, r.top, r.right, r.bottom
        except (OSError, AttributeError, ValueError):
            pass
    return (0, 0, window.winfo_screenwidth(), window.winfo_screenheight()) if window else (0, 0, 1280, 800)

def center_window(window, width, height, parent=None):
    """Use physical Win32 coordinates even for a monitor left of the primary one."""
    window.update_idletasks()
    w, h, x, y = centered_geometry(work_area(window, parent), width, height)
    window.geometry(f'{w}x{h}{x:+d}{y:+d}')
    window.update_idletasks()
    if os.name == 'nt':
        try:
            from ctypes import wintypes
            user = ctypes.windll.user32
            user.GetParent.argtypes = [wintypes.HWND];user.GetParent.restype = wintypes.HWND
            user.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
            handle = user.GetParent(window.winfo_id()) or window.winfo_id()
            if user.SetWindowPos(handle, None, x, y, w, h, 0x0014):
                return w, h
        except (OSError, AttributeError):
            pass
    window.geometry(f'{w}x{h}{x:+d}{y:+d}')
    return w, h

def validate_release(path, inspector):
    path = Path(path)
    if re.search(r'(?i)[-_]SOURCE(?:[._-]|$)', path.name):
        raise ValueError('SOURCE ZIPs are not deployable; choose a runtime release.')
    with zipfile.ZipFile(path) as z:
        members = z.infolist()
        if len(members) > 20000 or sum(m.file_size for m in members) > 1_000_000_000:
            raise ValueError('ZIP exceeds the safe extraction limit.')
        seen = set()
        for item in members:
            name = item.filename.replace('\\', '/')
            if '..' in name.split('/') or name.startswith('/') or re.match(r'^[A-Za-z]:', name) or '\x00' in name:
                raise ValueError('ZIP contains an unsafe path.')
            key = name.casefold().rstrip('/')
            if key in seen:
                raise ValueError('ZIP contains duplicate filenames.')
            seen.add(key)
            if ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('ZIP contains a symbolic link.')
        info = inspector(path)
        if z.testzip() is not None:
            raise ValueError('ZIP integrity check failed. Download the release again.')
        root = '/'.join(info.get('root_parts') or ())
        backend = (root+'/' if root else '')+'worker.js'
        if backend not in z.namelist():
            raise ValueError('Deployment blocked: worker.js missing; choose a full runtime release.')
        text = z.read(backend).decode('utf-8', errors='replace')
        match = re.search(r'''APP_VERSION\s*=\s*['"]([^'"]+)['"]''', text)
        if not match or version_key(match[1]) != version_key(info['version']):
            raise ValueError('Deployment blocked: worker.js release version differs from ZIP version.')
        if len(text) < 100 or '/api/health' not in text or '/api/tower' not in text:
            raise ValueError('Deployment blocked: worker.js lacks required API paths.')
    return info

def latest_release(folder, validator):
    """Inspect direct children only; ignore invalid/source packages and never deploy."""
    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError('Release folder is missing or unavailable.')
    candidates = []
    for path in folder.iterdir():
        match = RELEASE_NAME.fullmatch(path.name)
        if not match or re.search(r'(?i)[-_]SOURCE(?:[._-]|$)', path.name) or not path.is_file():
            continue
        try:
            candidates.append((version_key(match[1]), path.stat().st_mtime_ns, path.name.casefold(), path))
        except OSError:
            continue
    skipped = 0
    for _, _, _, path in sorted(candidates, reverse=True):
        try:
            return path, validator(path), skipped
        except (OSError, ValueError, RuntimeError, zipfile.BadZipFile, EOFError):
            skipped += 1
    raise ValueError('No compatible release ZIP found in the selected folder. SOURCE ZIPs are not deployable.')

def sanitize(value):
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', str(value))
    text = re.sub(r'(?i)(postgres(?:ql)?://[^\s:/@]+:)[^\s@]+@', r'\1[REDACTED]@', text)
    text = re.sub(r'(?i)Bearer\s+[A-Za-z0-9._~+/-]+', 'Bearer [REDACTED]', text)
    text = re.sub(r'(?i)(--(?:api-token|token|password|secret)\s+)[^\s]+', r'\1[REDACTED]', text)
    pattern = r'''(?im)(["']?(?:service_role_key|supabase_service_role_key|api[_-]?key|authorization|access[_-]?token|refresh[_-]?token|password|secret|pin)["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,;]+)'''
    text = re.sub(pattern, r'\1[REDACTED]', text)
    text = re.sub(r'(?i)Bearer\s+[A-Za-z0-9._~+/-]+', 'Bearer [REDACTED]', text)
    text = re.sub(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{8,}\b', '[JWT REDACTED]', text)
    text = re.sub(r'\bsb_(?:secret|publishable)_[A-Za-z0-9_-]+', '[KEY REDACTED]', text)
    return text

def error_report(stage, detail, completed=()):
    raw = sanitize(detail)
    low = raw.lower()
    summary = 'تعذر إتمام العملية.'
    action = 'انسخ تفاصيل الخطأ والسجل، وراجع المرحلة التي توقفت قبل إعادة المحاولة.'
    if re.match(r'^[\u0600-\u06ff]', raw) and len(raw)<220:
        summary = raw
        action = 'صحّح الاختيار أو انتظر انتهاء العملية الجارية، ثم جرّب مرة أخرى.'
    elif 'pg_dump' in low or 'pg_restore' in low:
        summary = 'أدوات PostgreSQL المطلوبة للنسخ الاحتياطي غير جاهزة.'
        action = 'ثبّت أدوات PostgreSQL client واختر مجلد bin الذي يحتوي pg_dump وpg_restore من إعدادات النسخ الاحتياطي.'
    elif 'secure password storage requires windows' in low or 'password storage is only available' in low:
        summary = 'الحفظ الآمن لكلمة المرور متاح على Windows فقط.'
        action = 'أدخل كلمة المرور عند الحاجة دون حفظها، أو استخدم النسخة على Windows.'
    elif 'enter a password' in low:
        summary = 'لم تُدخل كلمة مرور لحفظها.'
        action = 'أدخل كلمة مرور قاعدة البيانات في خانتها المخصصة؛ لا تضعها في السجل أو رسائل الدعم.'
    elif 'could not protect' in low:
        summary = 'تعذر تشفير كلمة المرور على حساب Windows الحالي؛ لم تُحفظ.'
        action = 'استخدم الإدخال المؤقت لكلمة المرور وراجع حساب Windows قبل محاولة حفظها مجددًا.'
    elif 'postgresql connection' in low or 'connection uri' in low:
        summary = 'بيانات موقع الاتصال بقاعدة البيانات غير مكتملة أو غير صحيحة.'
        action = 'انسخ عنوان الاتصال الكامل من Supabase Connect، وضع كلمة المرور في خانتها المنفصلة.'
    elif 'permission' in low or 'access is denied' in low:
        summary = 'تعذر الوصول إلى ملف أو مجلد بسبب الصلاحيات أو استخدامه بواسطة برنامج آخر.'
        action = 'أغلق البرنامج الذي يستخدم الملفات وتأكد من صلاحية الكتابة في المجلد المحدد.'
    elif 'no space left' in low or 'disk full' in low:
        summary = 'المساحة المتاحة لا تكفي لإكمال تجهيز الملفات.'
        action = 'وفّر مساحة على قرص التطبيق ومجلد الملفات المؤقتة ثم أعد المحاولة.'
    elif 'post-deploy check failed' in low:
        summary = 'أمر الرفع نجح، لكن فحص واجهة التطبيق لم يؤكد الإصدار المطلوب.'
        action = 'لا تعِد الرفع الآن. راجع استجابة /api/health والإصدار الأونلاين والسجل لمعرفة سبب فشل الفحص.'
    elif '401' in low or 'unauthorized' in low or 'login required' in low:
        summary = 'الخدمة رفضت الاتصال أو انتهت صلاحية تسجيل الدخول.'
        action = 'افتح الإعدادات وسجّل الدخول إلى Cloudflare أو Supabase بحسب المرحلة، وتأكد من الحساب الصحيح ثم أعد المحاولة.'
    elif '403' in low or 'forbidden' in low:
        summary = 'الحساب الحالي لا يملك صلاحية تنفيذ العملية.'
        action = 'راجع حساب الخدمة وصلاحيات المشروع المحدد من الإعدادات.'
    elif 'propagation' in low or 'deployment command succeeded' in low:
        summary = 'أمر الرفع نجح، لكن التحقق من ظهور الإصدار الأونلاين لم يكتمل.'
        action = 'لا تعِد الرفع الآن. انتظر قليلًا واضغط تحديث الإصدار الأونلاين من الواجهة.'
    elif 'timed out' in low or 'timeout' in low:
        summary = 'انتهت مهلة الانتظار قبل وصول نتيجة مؤكدة.'
        action = 'راجع الاتصال والسجل، ثم افحص الإصدار الأونلاين قبل تكرار الرفع؛ انتهاء المهلة لا يثبت أن الرفع لم يتم.'
    elif 'npx' in low or 'node.js' in low:
        summary = 'أداة Node.js أو npx المطلوبة غير متاحة.'
        action = 'ثبّت Node.js LTS ثم أغلق الـUpdater وافتحه من جديد.'
    elif 'no compatible release' in low or 'release folder' in low:
        summary = 'لم يتم العثور على حزمة تشغيل متوافقة في المجلد المختار.'
        action = 'راجع المجلد من زر Folder، وضع فيه حزمة Tower_App_Vx.y.z.zip ثم اضغط Auto Import.'
    elif 'select folder' in low or 'app folder' in low:
        summary = 'مجلد التطبيق المحلي غير محدد أو لا يحتوي ملفات التطبيق المطلوبة.'
        action = 'افتح Settings ثم General واختر مجلد التطبيق الذي يحتوي app.js وindex.html.'
    elif 'check online url' in low:
        summary = 'رابط الأونلاين أو اسم Worker غير صحيح.'
        action = 'افتح Settings ثم Cloudflare وراجع رابط المشروع واسم Worker واحفظهما.'
    elif 'worker.js' in low or 'zip' in low or 'package' in low or 'release' in low:
        summary = 'حزمة التحديث غير صالحة أو غير متوافقة مع طريقة التشغيل.'
        action = 'اختر حزمة التشغيل Tower_App_Vx.y.z.zip؛ تجنب SOURCE، ونزّل الحزمة من جديد لو كانت تالفة.'
    elif 'kv namespace' in low or 'binding' in low:
        summary = 'تعذر التحقق من ربط Cloudflare KV المطلوب للتطبيق.'
        action = 'راجع الحساب الصحيح ووجود tower-health-monitor. أوقف الرفع لحين التأكد من الربط من السجل.'
    elif 'network' in low or 'connection' in low or 'urlopen' in low or 'resolve' in low:
        summary = 'تعذر الاتصال بالخدمة المطلوبة.'
        action = 'راجع الإنترنت وعنوان المشروع ثم جرّب فحص الاتصال من الإعدادات.'
    completed_text = '\n'.join('• '+sanitize(x) for x in completed) if completed else 'لا توجد مرحلة مؤكدة في هذه العملية حتى الآن؛ راجع السجل للتفاصيل.'
    body = f'ما الذي حدث؟\n{summary}\n\nالمرحلة: {stage}\n\nما الذي اكتمل؟\n{completed_text}\n\nما الخطوة التالية؟\n{action}'
    return summary, body, raw

# ___________________________
# Tower Supabase Updater V2.2.0 — Code End
