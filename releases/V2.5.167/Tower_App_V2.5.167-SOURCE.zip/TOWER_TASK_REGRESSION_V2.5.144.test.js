// node TOWER_TASK_REGRESSION_V2.5.144.test.js
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/app.js','utf8');
function fn(name){const start=src.indexOf('function '+name+'(');assert(start>=0,name);let depth=0,begin=src.indexOf('{',start);for(let i=begin;i<src.length;i++){if(src[i]==='{')depth++;if(src[i]==='}'&&!--depth)return src.slice(start,i+1);}throw Error('missing end '+name);}
const ctx={Date,Math,Number,String};vm.createContext(ctx);vm.runInContext(['towerTaskInstallmentProjection','towerLocalDate','towerTaskFinancialSnapshot','towerTaskReadiness'].map(fn).join('\n'),ctx);
function check(name,cond){assert(cond,name);console.log('PASS',name);}
const rows=ctx.towerTaskInstallmentProjection({approvedDues:1900,installmentCount:7,firstDueDate:'2026-01-31'});
check('seven-installments',rows.length===7);check('exact-cents',Math.round(rows.reduce((a,b)=>a+b.amount,0)*100)===190000);
check('month-end-clamping',rows[1].dueDate==='2026-02-28');
check('invalid-date-rejected',ctx.towerTaskInstallmentProjection({approvedDues:100,installmentCount:2,firstDueDate:'2026-02-31'}).length===0);
const service={enrollmentStatus:'FINALIZED',totalBudget:1900};
const meta={collected:700,fundContributionPosted:500,collectionThreshold:50,startRule:'COLLECTION'};
check('fund-net-cost-ready',ctx.towerTaskReadiness(meta,service).ready===true);
check('threshold-not-met',ctx.towerTaskReadiness({...meta,collected:699.99},service).ready===false);
check('not-finalized',ctx.towerTaskReadiness(meta,{...service,enrollmentStatus:'OPEN'}).ready===false);
check('manual-remains-manual',ctx.towerTaskReadiness({...meta,startRule:'MANUAL'},service).ready===false);
check('date-formats',/^\d{4}-\d{2}-\d{2}$/.test(ctx.towerLocalDate()));
check('version-markers',src.includes("APP_VERSION='2.5.167'"));
check('public-mirror',fs.readFileSync(__dirname+'/public/app.js','utf8')===src);
