"""Render actual subscriber PDF in Chromium. Uses npm copies of the same pinned CDN libraries."""
import base64, json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
LIBS=Path(os.environ.get('TOWER_PDF_NODE_MODULES','/tmp/tower-browser-tools/node_modules'))
OUT=Path(os.environ.get('TOWER_QA_OUTPUT','/tmp/tower-pdf-qa'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1366,'height':900})
 def route(req):
  name=req.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
  if req.request.url.startswith('http://tower.test/'):
   if name in ['index.html','app.js','styles.css']:req.fulfill(path=str(ROOT/name))
   else:req.fulfill(json={'ok':True,'result':{'configured':False}})
  else:req.abort()
 page.route('**/*',route);page.goto('http://tower.test/')
 page.add_script_tag(path=str(LIBS/'html2canvas/dist/html2canvas.min.js'))
 page.add_script_tag(path=str(LIBS/'jspdf/dist/jspdf.umd.min.js'))
 page.evaluate("APP.ctx={user:{role:'ADMIN',displayName:'اختبار معزول'},building:{name:'عمارة تجريبية'}}; window.TOWER_REPORT_FIXTURE=true")
 for count in [11,75]:
  result=page.evaluate("""async count=>{
    TASK_WORKFLOW_META.qa={fundContributionProposed:500,fundContributionPosted:300};
    const d=serviceSubscriberSnapshot({service:{serviceId:'qa',serviceKind:'ONE_TIME',pricingMode:'SHARED_TOTAL',totalBudget:1900,enrollmentStatus:'FINALIZED',name:'تقرير تجريبي'},subscriptions:Array.from({length:count},(_,i)=>({subscriptionId:'s'+i,unitId:'u'+i,unitNumber:String(i+1),floor:String(Math.floor(i/4)+1),managerName:'السيد أحمد محمد '+(i+1),quantity:1,status:'ACTIVE'}))});
    const r=serviceSubscribersReport(d);
    const host=document.createElement('div');host.className='pdf-capture-host';host.innerHTML=reportDocumentHtml(r);document.body.appendChild(host);
    const source=host.querySelector('.report-paper'); const pages=reportPdfPages(source,host);
    const rows=pages.reduce((n,p)=>n+p.querySelectorAll('tbody tr').length,0);
    const tableHeaders=pages.filter(p=>p.querySelector('tbody tr')).every(p=>p.querySelector('thead'));
    const fits=pages.every(p=>p.getBoundingClientRect().height<=Math.floor(718*262/194));
    host.remove();
    const blob=await buildCurrentPdfBlob(r);
    const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(blob)});
    return {rows,tableHeaders,fits,pages:pages.length,data};
  }""",count)
  data=base64.b64decode(result.pop('data').split(',',1)[1]);pdf=OUT/f'subscribers-{count}.pdf';pdf.write_bytes(data)
  assert data.startswith(b'%PDF-'), 'invalid PDF'
  assert result['rows']==count and result['tableHeaders'] and result['fits'],result
  if count==75:assert result['pages']>1
  results.append({'count':count,'status':'PASS',**result,'pdf_bytes':len(data)})
 # Test real print popup: noopener must not destroy the reference needed to write its document.
 page.evaluate("REPORT_UI.current={title:'اختبار طباعة',sections:[],building:{name:'عمارة تجريبية'}}")
 with page.expect_popup() as pop:page.evaluate('printCurrentReport()')
 popup=pop.value;popup.wait_for_load_state('domcontentloaded')
 assert popup.locator('.report-title h2').inner_text()=='اختبار طباعة'
 assert popup.evaluate('window.opener===null')
 results.append({'check':'print popup document and detached opener','status':'PASS'})
 browser.close()
(OUT/'pdf-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
