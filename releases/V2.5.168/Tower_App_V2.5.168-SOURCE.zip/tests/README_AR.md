# تشغيل اختبارات V2.5.167

- اختبارات المصدر: `python tests/run_source_tests.py`، تحتاج Node.js وPython 3.
- اختبارات الواجهة: تثبيت `playwright==1.62.0` في بيئة Python، وتوفير Chromium في `/usr/bin/chromium`، ثم `python tests/browser_regression.py`.
- اختبارات PDF: تثبيت المكتبات الأصلية المطابقة لإصدارات روابط CDN عبر `npm install --cache /tmp/tower-npm-cache --prefix /tmp/tower-browser-tools --no-audit --no-fund html2canvas@1.4.1 jspdf@2.5.1` ثم `python tests/pdf_regression.py`.
- يمكن تغيير موقع مكتبات PDF بمتغير TOWER_PDF_NODE_MODULES ومخرجات PDF بمتغير TOWER_QA_OUTPUT.
- نتائج المتصفح تكتب افتراضيًا في /tmp/tower-browser-results.json، ونتائج PDF وملفاته في /tmp/tower-pdf-qa.
- الاختبارات تحمل ملفات التطبيق الفعلية في Chromium؛ لا ترسل أي طلب إلى Supabase أو Telegram، وتستخدم استجابات وبيانات اختبار معزولة.
- الاختبارات المحلية ليست Browser E2E للنسخة المنشورة أو Supabase E2E أو اختبار Android فعلي.
- اختبارات المصدر 18 ملفًا، منها ملف وسيط يعيد تشغيل اختبار آخر. لا تعتبر 18 سيناريو مستقلًا.
- مجلد qa يحتفظ بنتائج التسليم. ملفات baseline-v2.5.166 تغطي 24 حالة أولية، بينما الاختبار النهائي الموسع يغطي 32 حالة.


## اختبارات عقد البيانات V2.5.168

- `python tests/run_source_tests.py` يشغّل ملفات المصدر الـ18 ثم 13 حالة Worker HTTP، مع الحفاظ على رمز خروج الفشل.
- `python tests/worker_context_browser.py` يشغّل Worker HTTP أولًا ويكتب الردود المصطنعة الناتجة في /tmp/tower-v168-contract، ثم يختبر استهلاك الواجهة لها في 18 حالة على مقاسي الموبايل والديسكتوب.
- شغّل الاختبار السابق قبل `python tests/pdf_regression.py`؛ الأخير يختبر أيضًا PDF لحالتي OPEN وFINALIZED من رد Worker الفعلي داخل الاختبار، بجانب أمثلة الصفوف والطباعة.
- كلمة «فعلي» هنا تعني كود Worker HTTP الحقيقي داخل الاختبار، بينما Supabase خلفه محاكاة صريحة. هذه ليست نتيجة للنسخة المنشورة أو قاعدة Supabase الحية.
- الإضافة وحفظها عبر Supabase في V2.5.168 لا تعتبر ناجحة قبل رفع الإصدار وتشغيلها هناك.
