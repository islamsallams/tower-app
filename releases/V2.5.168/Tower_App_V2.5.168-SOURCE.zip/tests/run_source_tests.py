"""Run every source test and preserve failures as a nonzero exit code."""
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parents[1]
failed=0
for p in sorted(root.glob('*.test.js')):
    result=subprocess.run(['node',str(p)],cwd=root,capture_output=True,text=True)
    print(('PASS' if result.returncode==0 else 'FAIL'),p.name)
    if result.returncode:
        print(result.stdout,result.stderr)
        failed+=1
for name in ['app.js','worker.js']:
    result=subprocess.run(['node','--check',name],cwd=root)
    failed+=result.returncode!=0
for name in ['app.js','index.html','styles.css']:
    match=(root/name).read_bytes()==(root/'public'/name).read_bytes()
    print('MIRROR',name,'PASS' if match else 'FAIL')
    failed+=not match
result=subprocess.run(['node','tests/worker_context_contract.mjs'],cwd=root)
failed+=result.returncode!=0
sys.exit(bool(failed))
