# تشغيل اختبارات V2.5.167

- اختبارات المصدر: `python tests/run_source_tests.py`، تحتاج Node.js وPython 3.
- اختبارات الواجهة: تثبيت `playwright==1.62.0` في بيئة Python، وتوفير Chromium في `/usr/bin/chromium`، ثم `python tests/browser_regression.py`.
- اختبارات PDF: تثبيت المكتبات الأصلية المطابقة لإصدارات روابط CDN عبر `npm install --cache /tmp/tower-npm-cache --prefix /tmp/tower-browser-tools --no-audit --no-fund html2canvas@1.4.1 jspdf@2.5.1` ثم `python tests/pdf_regression.py`.
- يمكن تغيير موقع مكتبات PDF بمتغير TOWER_PDF_NODE_MODULES ومخرجات PDF بمتغير TOWER_QA_OUTPUT.
- نتائج المتصفح تكتب افتراضيًا في /tmp/tower-browser-results.json، ونتائج PDF وملفاته في /tmp/tower-pdf-qa.
- الاختبارات تحمل ملفات التطبيق الفعلية في Chromium؛ لا ترسل أي طلب إلى Supabase أو Telegram، وتستخدم استجابات وبيانات اختبار معزولة.
- الاختبارات المحلية ليست Browser E2E للنسخة المنشورة أو Supabase E2E أو اختبار Android فعلي.
- اختبارات المصدر 18 ملفًا، منها ملف وسيط يعيد تشغيل اختبار آخر. لا تعتبر 18 سيناريو مستقلًا.
- مجلد qa يحتفظ بنتائج التسليم. ملفات baseline-v2.5.166 تغطي 24 حالة أولية، بينما الاختبار النهائي الموسع يغطي 32 حالة.


## اختبارات عقد البيانات V2.5.168

- `python tests/run_source_tests.py` يشغّل ملفات المصدر الـ18 ثم 13 حالة Worker HTTP، مع الحفاظ على رمز خروج الفشل.
- `python tests/worker_context_browser.py` يشغّل Worker HTTP أولًا ويكتب الردود المصطنعة الناتجة في /tmp/tower-v168-contract، ثم يختبر استهلاك الواجهة لها في 18 حالة على مقاسي الموبايل والديسكتوب.
- شغّل الاختبار السابق قبل `python tests/pdf_regression.py`؛ الأخير يختبر أيضًا PDF لحالتي OPEN وFINALIZED من رد Worker الفعلي داخل الاختبار، بجانب أمثلة الصفوف والطباعة.
- كلمة «فعلي» هنا تعني كود Worker HTTP الحقيقي داخل الاختبار، بينما Supabase خلفه محاكاة صريحة. هذه ليست نتيجة للنسخة المنشورة أو قاعدة Supabase الحية.
- الإضافة وحفظها عبر Supabase في V2.5.168 لا تعتبر ناجحة قبل رفع الإصدار وتشغيلها هناك.


## اختبارات V2.5.169

- `python tests/resident_service_workflow.py`: 18 حالة متصفح لطلبات الساكن من صفحة الوحدة وتحديث الموافقات وتغيير الكمية وحماية تبديل الوحدة/الصفحة. API مصطنعة صراحةً.
- `python tests/guard_notes_browser.py`: يشغّل 9 اختبارات Worker HTTP للملاحظات، ثم 8 حالات متصفح لعرضها وتهريب HTML والحفاظ على الإجراءات عند الخطأ.
- `python tests/worker_context_browser.py`: يشغّل عقد الخدمة ثم 18 حالة لاستهلاك رد Worker؛ ملفاته الافتراضية الآن /tmp/tower-v169-contract.
- `python tests/pdf_regression.py`: يشغّل بعد اختبار العقد السابق. 9/10/11/75 صفًا على عرضي 390 و1366، مع فحص تساوي توزيع الصفوف وحجم خط الجدول والأعمدة، وتوليد PDF فعلي. يضيف فحوص تقارير Worker والطباعة. 11 حالة إجمالًا.
- `python tests/run_source_tests.py`: ملفات المصدر الـ18، ثم 13 حالة Worker لسياق الخدمة و9 لملاحظات الحارس.
- مخرجات resident/guard الافتراضية /tmp/tower-v169-qa وPDF في /tmp/tower-pdf-qa. بيانات هذه الاختبارات مصطنعة وليست الأسماء أو الحسابات الحية.
- qa/v2.5.169/trip-preservation-results.json يوثق مقارنة دوال المشاوير مع SOURCE 168؛ لا يمثل اختبار Supabase أو كل الأدوار.


## اختبارات V2.5.170

- `node tests/unit_task_balances_contract.mjs`: 13 حالة Worker HTTP بمصدر Supabase مصطنع، تشمل العزل والفشل والبيانات غير الصالحة.
- `python tests/unit_task_balances_browser.py`: 12 حالة Chromium على 390 و1366، للكارت والتفاصيل وحالات عدم الإتاحة وغياب القيد والصفر الصحيح وعدم تجاوز العرض.
- اختبار SQL يستخدم PGlite (PostgreSQL محلي): ثبّت `@electric-sql/pglite@0.5.11` أو إصدارًا متوافقًا، ثم `TOWER_PGLITE_MODULE=/path/to/pglite/dist/index.js node tests/unit_task_balances_sql.mjs`. كتالوج الاختبار مصطنع ولا يتصل بـSupabase.
- اختبار SQL يغطي العضوية والدور والوحدة غير النشطة والقروش الدقيقة والتحصيل الجزئي والكامل وتعدد المستحقات وعكس الإيصال والمقدم والعزل والصلاحيات ومعاملة القراءة فقط.
- ملفات SQL لا تُشغَّل تلقائيًا أثناء رفع التطبيق؛ SQL227 مستقل للتشغيل في Supabase قبل ZIP.
