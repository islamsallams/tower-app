"""Render actual subscriber PDF in Chromium. Uses npm copies of the same pinned CDN libraries."""
import base64, json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
LIBS=Path(os.environ.get('TOWER_PDF_NODE_MODULES','/tmp/tower-browser-tools/node_modules'))
OUT=Path(os.environ.get('TOWER_QA_OUTPUT','/tmp/tower-pdf-qa'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1366,'height':900})
 def route(req):
  name=req.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
  if req.request.url.startswith('http://tower.test/'):
   if name in ['index.html','app.js','styles.css']:req.fulfill(path=str(ROOT/name))
   else:req.fulfill(json={'ok':True,'result':{'configured':False}})
  else:req.abort()
 page.route('**/*',route);page.goto('http://tower.test/')
 page.add_script_tag(path=str(LIBS/'html2canvas/dist/html2canvas.min.js'))
 page.add_script_tag(path=str(LIBS/'jspdf/dist/jspdf.umd.min.js'))
 page.evaluate("APP.ctx={user:{role:'ADMIN',displayName:'اختبار معزول'},building:{name:'عمارة تجريبية'}}; window.TOWER_REPORT_FIXTURE=true")
 for width,count in [(w,n) for w in [390,1366] for n in [9,10,11,75]]:
  page.set_viewport_size({'width':width,'height':900})
  result=page.evaluate("""async count=>{
    TASK_WORKFLOW_META.qa={fundContributionProposed:500,fundContributionPosted:300};
    const d=serviceSubscriberSnapshot({service:{serviceId:'qa',serviceKind:'ONE_TIME',pricingMode:'SHARED_TOTAL',totalBudget:1900,enrollmentStatus:'FINALIZED',name:'تقرير تجريبي'},subscriptions:Array.from({length:count},(_,i)=>({subscriptionId:'s'+i,unitId:'u'+i,unitNumber:String(i+1),floor:String(Math.floor(i/4)+1),managerName:'السيد أحمد محمد '+(i+1),quantity:1,status:'ACTIVE'}))});
    const r=serviceSubscribersReport(d);
    const host=document.createElement('div');host.className='pdf-capture-host';host.innerHTML=reportDocumentHtml(r);document.body.appendChild(host);
    const source=host.querySelector('.report-paper'); const pages=reportPdfPages(source,host);
    const rows=pages.reduce((n,p)=>n+p.querySelectorAll('tbody tr').length,0);
    const tableHeaders=pages.filter(p=>p.querySelector('tbody tr')).every(p=>p.querySelector('thead'));
    const fits=pages.every(p=>p.getBoundingClientRect().height<=Math.floor(718*262/194));
    const layout={rowCounts:pages.map(p=>p.querySelectorAll('tbody tr').length),tableFont:getComputedStyle(pages[0].querySelector('table')).fontSize,statColumns:getComputedStyle(pages[0].querySelector('.report-stats')).gridTemplateColumns.split(' ').length};
    host.remove();
    const blob=await buildCurrentPdfBlob(r);
    const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(blob)});
    return {rows,tableHeaders,fits,pages:pages.length,...layout,data};
  }""",count)
  data=base64.b64decode(result.pop('data').split(',',1)[1]);pdf=OUT/f'subscribers-{count}-{width}.pdf';pdf.write_bytes(data)
  assert data.startswith(b'%PDF-'), 'invalid PDF'
  assert result['rows']==count and result['tableHeaders'] and result['fits'],result
  if count==75:assert result['pages']>1
  if count<=11:assert result['pages']==1,result
  assert result['tableFont']=='11px' and result['statColumns']==4,result
  results.append({'count':count,'viewport':width,'status':'PASS',**result,'pdf_bytes':len(data)})
 for count in [9,10,11,75]:
  pair=[r for r in results if r.get('count')==count];assert pair[0]['rowCounts']==pair[1]['rowCounts'],pair
 # Render reports from the real Worker's HTTP response contract, not hand-enriched service metadata.
 contract_dir=Path(os.environ.get('TOWER_CONTRACT_OUTPUT','/tmp/tower-v169-contract'))
 fixtures=json.loads((contract_dir/'worker-context-fixtures.json').read_text())
 for stage in ['OPEN','FINALIZED']:
  data=page.evaluate("""async context=>{
    const id=context.service.serviceId;
    TASK_WORKFLOW_META[id]={fundContributionProposed:500,fundContributionPosted:300};
    const report=serviceSubscribersReport(serviceSubscriberSnapshot(context));
    const stats=report.sections[0].items;
    if(!report.subtitle.includes('حساب شخصي')||!report.subtitle.includes('مهمة لمرة واحدة'))throw Error('wrong report classification');
    const budget=stats.find(x=>x.label==='تكلفة المهمة الإجمالية');
    const net=stats.find(x=>x.label.includes('الصافي'));
    const expected=context.service.enrollmentStatus==='FINALIZED'?'1,600':'1,400';
    if(!budget.value.includes('1,900')||!net.value.includes(expected))throw Error('wrong budget or fund basis');
    const blob=await buildCurrentPdfBlob(report);
    return await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.readAsDataURL(blob)});
  }""",fixtures[stage])
  pdf_data=base64.b64decode(data.split(',',1)[1]);assert pdf_data.startswith(b'%PDF-')
  (OUT/f'worker-context-{stage.lower()}.pdf').write_bytes(pdf_data)
  results.append({'check':'subscriber PDF from Worker '+stage+' context','status':'PASS','pdf_bytes':len(pdf_data)})
 # Test real print popup: noopener must not destroy the reference needed to write its document.
 page.evaluate("REPORT_UI.current={title:'اختبار طباعة',sections:[],building:{name:'عمارة تجريبية'}}")
 with page.expect_popup() as pop:page.evaluate('printCurrentReport()')
 popup=pop.value;popup.wait_for_load_state('domcontentloaded')
 assert popup.locator('.report-title h2').inner_text()=='اختبار طباعة'
 assert popup.evaluate('window.opener===null')
 results.append({'check':'print popup document and detached opener','status':'PASS'})
 browser.close()
(OUT/'pdf-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
