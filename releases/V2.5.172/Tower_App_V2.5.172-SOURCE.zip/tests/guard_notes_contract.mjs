import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {pathToFileURL,fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const {default:worker}=await import(pathToFileURL(path.join(root,'worker.js')));
const originalFetch=globalThis.fetch;
const base={units:[],trips:[{tripId:'trip-a',unitId:'u1',unitNumber:'01',items:[{name:'طلب تجريبي',price:12.5}],purchasesTotal:12.5},{tripId:'trip-b',unitId:'u2',unitNumber:'02',items:[{name:'طلب ثان',price:0}],purchasesTotal:0}]};
export async function requestGuard({role='OPERATOR',empty=false,fail=false,invalid=false,missing=false,notes='ملاحظة الساكن\nتجربة'}={}){
 const calls=[];globalThis.fetch=async(url,opts={})=>{
  const resource=new URL(url).pathname.split('/').pop();calls.push(resource);const p=JSON.parse(opts.body||'{}');let data;
  if(resource==='tower_session_user')data=[{user_id:'u',role}];
  else if(resource==='tower_guard_trip_context')data=empty?{...base,trips:[]}:base;
  else if(resource==='tower_trip_action'){
   assert.equal(p.p_action,'list');assert.deepEqual(p.p_payload,{});
   if(fail)return Response.json({code:'P0001',message:'fixture'},{status:500});
   data=invalid?{}:[{tripId:'trip-a',notes,unitId:'u1',distanceFee:999,totalDue:999,distance:'FAR'},...(missing?[]:[{tripId:'trip-b',notes:''}]),{tripId:'outside-context',notes:'must not be added'}];
  }else throw Error('Unexpected '+resource);
  return Response.json(data);
 };
 try{const response=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{name:'getGuardTripContext',token:'fixture',args:[]}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture'});return {status:response.status,body:await response.json(),calls}}
 finally{globalThis.fetch=originalFetch}
}
export async function run(){
 const results=[],fixtures={};async function check(name,fn){try{await fn();results.push({check:name,status:'PASS'});console.log('PASS',name)}catch(e){results.push({check:name,status:'FAIL',details:e.message});console.error('FAIL',name,e.message)}}
 await check('notes enrich current open IDs without distance fees or other trips',async()=>{const r=await requestGuard();assert.equal(r.status,200);assert.equal(r.body.result.trips.length,2);const t=r.body.result.trips[0];assert.equal(t.notes,'ملاحظة الساكن\nتجربة');assert.equal(t.purchasesTotal,12.5);for(const key of ['distanceFee','totalDue','distance'])assert(!Object.hasOwn(t,key));fixtures.normal=r.body.result});
 await check('empty open trips skip additional read',async()=>{const r=await requestGuard({empty:true});assert.equal(r.status,200);assert(!r.calls.includes('tower_trip_action'))});
 for(const role of ['ADMIN','UNION','RESIDENT'])await check(role+' remains forbidden',async()=>{const r=await requestGuard({role});assert(r.status>=400);assert.deepEqual(r.calls,['tower_session_user'])});
 await check('notes read failure retains trips with explicit unavailable state',async()=>{const r=await requestGuard({fail:true});assert.equal(r.status,200);assert.equal(r.body.result.trips.length,2);assert(r.body.result.trips.every(t=>t.notesUnavailable));fixtures.unavailable=r.body.result});
 await check('invalid notes response does not break guard screen data',async()=>{const r=await requestGuard({invalid:true});assert.equal(r.status,200);assert(r.body.result.trips.every(t=>t.notesUnavailable))});
 await check('missing trip notes flag only unmatched current trip',async()=>{const r=await requestGuard({missing:true});assert.equal(r.body.result.trips[0].notesUnavailable,false);assert.equal(r.body.result.trips[1].notesUnavailable,true)});
 await check('notes are plain unmodified text in transport',async()=>{const notes='<img src=x onerror="window.badNotes=1">';const r=await requestGuard({notes});assert.equal(r.body.result.trips[0].notes,notes);fixtures.unsafe=r.body.result});
 const out=process.env.TOWER_QA_OUTPUT||'/tmp/tower-v169-qa';fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'guard-notes-contract-results.json'),JSON.stringify(results,null,2));fs.writeFileSync(path.join(out,'guard-notes-fixtures.json'),JSON.stringify(fixtures,null,2));return results;
}
if(path.resolve(process.argv[1]||'')===fileURLToPath(import.meta.url)){const results=await run();process.exitCode=results.some(r=>r.status==='FAIL')?1:0}
