const fs=require('fs'),assert=require('node:assert/strict');
const get=x=>fs.readFileSync(__dirname+'/'+x,'utf8');
const tests=[['version app',get('app.js').includes("APP_VERSION='2.5.175'")],['version worker',get('worker.js').includes("APP_VERSION='2.5.175'")],['version html',get('index.html').includes('styles.css?v=2.5.175')],['app mirror',get('app.js')===get('public/app.js')],['html mirror',get('index.html')===get('public/index.html')],['css mirror',get('styles.css')===get('public/styles.css')],['hidden CSS rule',get('styles.css').includes('.service-admin-list>[data-tower-service-kind][hidden]{display:none!important}')]];
for(const [k,v] of tests){assert.ok(v,k);console.log('PASS',k)}console.log(`${tests.length}/${tests.length} PASS`)
