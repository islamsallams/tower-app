// Original developer attribution: Islam Sallam. Copyright signature retained unchanged by explicit user instruction.
const APP_VERSION='2.5.175'; // Tower App V2.5.175
const RELEASE_DETAILS={version:'2.5.175'};
// Cloudflare JSON adapter for original google.script.run client calls.
const google={script:{run:new Proxy({}, {get(_unused,property){
 if(property==='withSuccessHandler')return callback=>new Proxy({}, {get(_u,name){
 if(name==='withFailureHandler')return errback=>new Proxy({}, {get(_v,fn){return (...args)=>towerCall(String(fn),args).then(callback).catch(errback);}});
 return (...args)=>towerCall(String(name),args).then(callback);
 }});
 return undefined;
 }})}};
async function towerCall(method,args){
 const payload=method==='apiCall'?{method:'apiCall',args}:{method,args,token:typeof APP!=='undefined'?APP.token:''};
 const response=await fetch('/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)});
 const bodyText=await response.text();
 let data=null;
 if(bodyText.trim()){
   try{data=JSON.parse(bodyText);}catch(_){
     throw new Error('API_INVALID_JSON (HTTP '+response.status+'): '+bodyText.slice(0,160).replace(/\s+/g,' '));
   }
 }
 if(!data||typeof data!=='object'){
   throw new Error('API_EMPTY_RESPONSE (HTTP '+response.status+')');
 }
 if(!response.ok||data.ok===false){
   const op=method==='apiCall'?String(args?.[0]?.name||'apiCall'):String(method);
   const e=new Error(String(data.error||'تعذر إتمام العملية.'));
   e.operation=op;e.reference=String(data.reference||'');e.dbCode=String(data.code||'');e.httpStatus=response.status;
   throw e;
 }
 return data.result;
}



function openIndependentTab(){window.open(location.origin+location.pathname,'_blank','noopener,noreferrer');}
const APP={ctx:null,home:null,titles:[],token:sessionStorage.getItem('tower-app-session')||'',theme:localStorage.getItem('tower-app-theme')||'light',page:'home'};
const PAGE_CACHE=new Map();let PAGE_CACHE_OBSERVER=null,PAGE_CACHE_TIMER=null;
const RPC_CACHE=new Map(),RPC_INFLIGHT=new Map(),PERF_LOG=[];
const RPC_TTL={listTitles:300000,listUnitTypes:300000,listCollectionCategories:180000,getUiPreferences:600000,getCoreHomeData:45000,listServices:120000,getMyServices:0,getFinanceDashboard:30000,getFinanceContext:30000,getCollectionContext:30000,listMyNotifications:30000,adminGetSystemSettings:300000};
const RPC_MUTATION=/^(admin|save|set|create|update|delete|cancel|close|undo|add|record|submit|return|approve|reject|review|request|transfer|change|mark|generate|repair|restore|finalize|install|postTaskFundContribution|confirmTaskFundReceipt|reopenSharedServiceEnrollment)/i;
function rpcKey(name,args){let a='';try{a=JSON.stringify(args||[]);}catch(_){a=String(args||'');}return name+'|'+a;}
function perfRecord(kind,name,ms,extra){PERF_LOG.push({at:Date.now(),kind,name,ms:Math.round(ms),extra:extra||''});if(PERF_LOG.length>120)PERF_LOG.splice(0,PERF_LOG.length-120);if(ms>900)console.info('[TowerPerf]',kind,name,Math.round(ms)+'ms',extra||'');}
function invalidateRpcCache(){RPC_CACHE.clear();}
function hydratePageCache(){try{const raw=sessionStorage.getItem('tower-page-cache-v2');if(!raw)return;const obj=JSON.parse(raw),uid=obj&&obj.uid;if(!APP.ctx||!APP.ctx.user||uid!==APP.ctx.user.userId)return;Object.keys(obj.pages||{}).forEach(k=>{const x=obj.pages[k];if(x&&x.html&&Date.now()-Number(x.at||0)<20*60*1000)PAGE_CACHE.set(k,x);});}catch(_){}}
function persistPageCache(){try{if(!APP.ctx||!APP.ctx.user)return;const pages={};PAGE_CACHE.forEach((v,k)=>{if(v&&v.html)pages[k]=v;});sessionStorage.setItem('tower-page-cache-v2',JSON.stringify({uid:APP.ctx.user.userId,pages}));}catch(_){}}
function clearClientCaches(){PAGE_CACHE.clear();RPC_CACHE.clear();RPC_INFLIGHT.clear();try{sessionStorage.removeItem('tower-page-cache-v2');}catch(_){}}

const $=id=>document.getElementById(id);
function activeTitles(){return (APP.titles&&APP.titles.length?APP.titles:(APP.ctx&&Array.isArray(APP.ctx.titles)?APP.ctx.titles:[])).filter(x=>x.status==='ACTIVE'||!x.status);}
function titleOptions(selected='أ.',selectedId='',customTitle=''){const list=activeTitles().slice();const inactive=(USER_UI?.titles||[]).find(x=>x.status!=='ACTIVE'&&(x.titleId===selectedId||(!selectedId&&x.label===selected)));if(inactive){selectedId='__OTHER__';customTitle=customTitle||inactive.label;}let html=list.map(x=>`<option value="${esc(x.titleId)}" ${x.titleId===selectedId||(!selectedId&&x.label===selected)?'selected':''}>${esc(x.label)}${x.status!=='ACTIVE'?' (غير نشط)':''}</option>`).join('');const customSelected=selectedId==='__OTHER__'||(selected&&!list.some(x=>x.label===selected));html+=`<option value="__OTHER__" ${customSelected?'selected':''}>أخرى...</option>`;return html;}
function titleFields(prefix,selected='أ.',selectedId='',customTitle=''){if((USER_UI?.titles||[]).some(x=>x.status!=='ACTIVE'&&x.titleId===selectedId)){selectedId='__OTHER__';customTitle=customTitle||selected;}return `<select id="${prefix}Title" onchange="syncCustomTitle('${prefix}')">${titleOptions(selected,selectedId,customTitle)}</select><input id="${prefix}CustomTitle" class="${selectedId==='__OTHER__'||customTitle||((USER_UI?.titles||[]).some(x=>x.status!=='ACTIVE'&&x.titleId===selectedId))?'':'hidden'}" value="${esc(customTitle||((selectedId==='__OTHER__')?selected:''))}" placeholder="اكتب اللقب" maxlength="40">`;}
function syncCustomTitle(prefix){const s=$(prefix+'Title'),i=$(prefix+'CustomTitle');if(i)i.classList.toggle('hidden',!s||s.value!=='__OTHER__');}
function readTitle(prefix){const s=$(prefix+'Title'),i=$(prefix+'CustomTitle');return{titleId:s?s.value:'',customTitle:s&&s.value==='__OTHER__'&&i?i.value.trim():''};}
const RELATION_OPTIONS=['زوج','زوجة','ابن','ابنة','أب','أم','أخ','أخت','قريب','مستأجر','مالك'];
function relationOptionsHtml(selected=''){const other=selected&&!RELATION_OPTIONS.includes(selected);return `<option value="">اختر صلة القرابة</option>${RELATION_OPTIONS.map(x=>`<option ${selected===x?'selected':''}>${esc(x)}</option>`).join('')}<option value="__OTHER__" ${other?'selected':''}>أخرى</option>`;}
function relationFields(prefix,selected=''){const other=selected&&!RELATION_OPTIONS.includes(selected);return `<select id="${prefix}Relation" onchange="syncRelationOther('${prefix}')">${relationOptionsHtml(selected)}</select><input id="${prefix}RelationOther" class="${other?'':'hidden'}" value="${esc(other?selected:'')}" placeholder="اكتب صلة القرابة الأخرى">`;}
function syncRelationOther(prefix){const s=$(prefix+'Relation'),i=$(prefix+'RelationOther');if(i)i.classList.toggle('hidden',!s||s.value!=='__OTHER__');}
function readRelation(prefix){const s=$(prefix+'Relation'),i=$(prefix+'RelationOther');return s&&s.value==='__OTHER__'?(i?i.value.trim():''):(s?s.value:'');}
function ltrId(v){return `<bdi class="ltr-id">${esc(v)}</bdi>`;}
function ltrNumber(v){return `<bdi class="ltr-number" dir="ltr">${esc(v)}</bdi>`;}
function code2(v){const x=westernDigits(v).trim();return /^\d$/.test(x)?'0'+x:x;}
function unitNo(v){return code2(v);}
function floorNo(v){return code2(v);}
function phoneDisplay(v){const x=westernDigits(v).replace(/\s+/g,'');return x?`<bdi class="ltr-number phone-number" dir="ltr">${esc(x)}</bdi>`:'—';}

function westernDigits(v){return String(v==null?'':v).replace(/[٠-٩]/g,d=>'0123456789'[d.charCodeAt(0)-1632]).replace(/[۰-۹]/g,d=>'0123456789'[d.charCodeAt(0)-1776]);}
// Presentation-only digit normalization: keeps stored identifiers, form values and numeric arithmetic untouched.
function normalizeVisibleDigits(root){
 if(!root)return;
 const skip='SCRIPT,STYLE,TEXTAREA,INPUT,OPTION,CODE,PRE,[contenteditable="true"]';
 const update=node=>{
  if(!node||node.nodeType!==3)return;
  if(node.parentElement&&node.parentElement.closest(skip))return;
  const original=node.nodeValue||'';
  const normalized=westernDigits(original).replace(/(^|[\s،(])([01]?\d|2[0-3]):([0-5]\d)(?![\d:]|\s*[صم])/g,(_m,p,h,min)=>p+String(Number(h)%12||12).padStart(2,'0')+':'+min+(Number(h)<12?' ص':' م'));
  if(normalized!==original)node.nodeValue=normalized;
 };
 if(root.nodeType===3){update(root);return;}
 if(root.nodeType!==1&&root.nodeType!==9&&root.nodeType!==11)return;
 if(root.nodeType===1&&root.matches(skip))return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);while(walker.nextNode())update(walker.currentNode);
}
function installWesternDigitObserver(){
 if(!document.body||window.__towerWesternDigitsObserver)return;
 const observer=new MutationObserver(changes=>{for(const change of changes){
  if(change.type==='characterData')normalizeVisibleDigits(change.target);
  else for(const node of change.addedNodes)normalizeVisibleDigits(node);
 }});
 normalizeVisibleDigits(document.body);
 observer.observe(document.body,{subtree:true,childList:true,characterData:true});
 window.__towerWesternDigitsObserver=observer;
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installWesternDigitObserver,{once:true});
else installWesternDigitObserver();
const esc=v=>westernDigits(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const OPERATION_LABELS={updateGuardTrip:'حفظ مشتريات المشوار',createGuardTrip:'تسجيل مشوار',updateMyTrip:'تعديل المشوار',createResidentTrip:'طلب مشوار',adminUpdateUser:'حفظ المستخدم',adminBrandAsset:'حفظ الصورة',recordBuildingPayment:'تسجيل دفعة',addFinanceEntry:'تسجيل حركة مالية',cancelFinanceEntry:'إلغاء حركة مالية',addResidentPayment:'تسجيل دفعة الساكن',createBuildingCharge:'إنشاء تحصيل',recordBuildingExpense:'تسجيل مصروف',addBuildingExpense:'إضافة مصروف',cancelResidentPayment:'إلغاء دفعة',recordCollection:'تسجيل تحصيل',createBuildingExpense:'إضافة مصروف',saveTaskWorkflow:'حفظ خطة المهمة',submitSettlement:'اعتماد تسوية',telegramUserAction:'إعدادات Telegram'};
function errText(e){
 const raw=e&&e.message?e.message:String(e||'حدث خطأ غير متوقع.');
 const COMMON_ERRORS={FORBIDDEN:'ليس لديك صلاحية لتنفيذ هذا الإجراء.',SESSION_REQUIRED:'انتهت جلسة الدخول. سجّل الدخول مرة أخرى.',PIN_CHANGE_REQUIRED:'يجب تغيير الرقم السري أولًا.',INVALID_OPERATION:'الإجراء غير متاح.',INVALID_AMOUNT:'أدخل مبلغًا صحيحًا وأكبر من الصفر.'};
 const USER_ERRORS={INVALID_REGISTRATION:'راجع الاسم وبيانات الاتصال ثم حاول مرة أخرى.',INVALID_UNIT:'الوحدة المختارة غير متاحة؛ اختر وحدة أخرى.',INVALID_PROFILE:'الاسم أو اللقب غير صالح؛ راجع البيانات المكتوبة.',PHONE_REQUIRED_FOR_MANAGER:'لا يمكن تولي إدارة الوحدة بدون رقم موبايل؛ أضف الرقم من الإعدادات أولًا.',INVALID_PHONE:'رقم الموبايل غير صحيح؛ اكتبه بأرقام صحيحة أو اتركه فارغًا إن كان اختياريًا.',INVALID_EMAIL:'البريد الإلكتروني غير صحيح؛ راجع الصيغة أو اتركه فارغًا.',CONTACTS_NOT_CONFIGURED:'تعديل بيانات الاتصال لم يُجهّز بعد في قاعدة البيانات. تواصل مع الإدارة.',REQUEST_NOT_PENDING:'تمت مراجعة الطلب بالفعل؛ حدّث القائمة.',TARGET_MUST_BE_ACTIVE_UNIT_MEMBER:'العضو المختار غير نشط أو ليس عضوًا في الوحدة.',TITLE_NOT_FOUND:'اللقب المختار لم يعد متاحًا؛ اختر لقبًا آخر.',INVALID_OR_EXPIRED_CODE:'الكود غير صحيح أو انتهت صلاحيته؛ اطلب كودًا جديدًا.',NETWORK_ERROR:'تعذر الاتصال بالخادم؛ تأكد من الإنترنت وحاول مجددًا.',UNKNOWN:'تعذّر إتمام العملية، والسبب التفصيلي غير متاح حاليًا. انسخ التفاصيل للدعم.'};
 const TASK_WORKFLOW_ERRORS={ENROLLMENT_NOT_OPEN:'باب الاشتراك مقفول؛ لا يمكن الرجوع إلى تجميع المشتركين.',ALLOCATION_NOT_FINALIZED:'اعتمد توزيع المستحقات أولًا قبل تغيير المهمة إلى مرحلة التنفيذ.',CONTRIBUTION_LOCKED_AFTER_FINALIZATION:'مساهمة الصندوق لا يمكن تغييرها بعد اعتماد التوزيع.',INVALID_TASK:'المهمة غير موجودة أو ليست من نوع المهمة المشتركة.',INVALID_SERVICE_ID:'معرّف المهمة غير صحيح؛ حدّث الصفحة.',INVALID_STAGE:'المرحلة المختارة غير صالحة.',INVALID_START_RULE:'شرط بدء التنفيذ غير صحيح.',INVALID_EXECUTION_PERCENT:'نسبة الإنجاز يجب أن تكون بين 0 و100%.',INVALID_INSTALLMENTS:'عدد الأقساط يجب أن يكون من 1 إلى 36.',INVALID_THRESHOLD:'نسبة التحصيل المطلوبة يجب أن تكون بين 1 و100%.',INVALID_FUND_CONTRIBUTION:'المساهمة المقترحة يجب ألا تتجاوز تكلفة المهمة.',INVALID_ACTION:'إجراء حفظ المهمة غير متاح.',INVALID_DATE:'موعد التنفيذ غير صالح.'};
 const EXTRA_ERRORS={INVALID_ITEMS:'أضف بندًا واحدًا على الأقل للمشوار.',INVALID_ITEM:'راجع اسم البند وسعره؛ يمكن ترك السعر فارغًا حتى يحدده الحارس.',UNIT_ACCESS_DENIED:'الوحدة المختارة ليست ضمن وحداتك النشطة.',UNIT_REQUIRED:'اختر الوحدة قبل تسجيل المشوار.',REQUEST_ID_REQUIRED:'تعذر بدء الطلب؛ حدّث الصفحة وحاول مرة أخرى.',REQUEST_ID_CONFLICT:'تم استخدام معرف الطلب من قبل؛ حدّث قائمة المشاوير.',TRIP_NOT_EDITABLE:'لا يمكن تعديل هذا المشوار بعد إلغائه أو تسويته.',INVALID_DISTANCE:'اختر مسافة مشوار صحيحة.',INVALID_TRIP_ITEMS:'راجع أسماء البنود وأسعارها؛ السعر رقم غير سالب أو يُترك فارغًا.',INVALID_TRIP_PRICE:'السعر لازم يكون رقمًا غير سالب، أو اتركه فارغًا لتحديده لاحقًا.',INVALID_INPUT:'راجع الحقول المميزة وصحح القيم قبل الحفظ.',REQUEST_TOO_LARGE:'حجم الملف أو البيانات أكبر من المسموح. قلل الحجم وحاول مجددًا.',TRIP_ALREADY_SETTLED:'المشوار تمت تسويته ولا يمكن تعديله.',TRIP_NOT_FOUND:'المشوار غير موجود أو لم يعد متاحًا. حدّث القائمة.',UNAUTHORIZED:'انتهت صلاحية الدخول؛ سجّل الدخول من جديد.'};
 const code=String(e?.code||e?.dbCode||'');
 const DB_CODES={'23505':'البيانات مسجلة بالفعل. راجع السجل قبل المحاولة مجددًا.','23502':'أكمل الحقول المطلوبة ثم حاول مجددًا.','23503':'لا يمكن تنفيذ الإجراء لأن هناك بيانات مرتبطة به.','23514':'هناك قيمة غير مقبولة. راجع الحقول المدخلة.','22P02':'صيغة إحدى القيم غير صحيحة. راجع الأرقام والحقول.','22003':'الرقم خارج المدى المسموح به.','22007':'راجع التاريخ أو الوقت المدخل.','42501':'ليس لديك صلاحية لتنفيذ الإجراء.'};
 const message=Object.hasOwn(COMMON_ERRORS,raw)?COMMON_ERRORS[raw]:Object.hasOwn(USER_ERRORS,raw)?USER_ERRORS[raw]:Object.hasOwn(EXTRA_ERRORS,raw)?EXTRA_ERRORS[raw]:Object.hasOwn(TASK_WORKFLOW_ERRORS,raw)?TASK_WORKFLOW_ERRORS[raw]:Object.hasOwn(EXTRA_ERRORS,code)?EXTRA_ERRORS[code]:Object.hasOwn(DB_CODES,code)?DB_CODES[code]:raw;
 if(!e||(!e.operation&&!e.reference))return message;
 const label=OPERATION_LABELS[e.operation]||'تنفيذ '+String(e.operation||'عملية').replace(/[^a-zA-Z0-9_]/g,'').slice(0,48);
 return 'تعذر '+label+': '+message+(e.reference?' (مرجع: '+e.reference+')':'');
}
let LAST_ERROR_DETAILS='';
function copyLastErrorDetails(){const s=LAST_ERROR_DETAILS||'لا توجد تفاصيل خطأ حاليًا.';if(navigator.clipboard?.writeText){navigator.clipboard.writeText(s).then(()=>toast('تم نسخ تفاصيل الخطأ.')).catch(()=>fallbackCopyError(s));}else fallbackCopyError(s);}
function fallbackCopyError(s){const el=document.createElement('textarea');el.value=s;el.style.position='fixed';el.style.opacity='0';document.body.appendChild(el);el.select();try{document.execCommand('copy');toast('تم نسخ تفاصيل الخطأ.');}catch(_){toast('تعذر النسخ التلقائي؛ انسخ الرسالة يدويًا.','error');}el.remove();}

function setTheme(v){APP.theme=v==='dark'?'dark':'light';document.documentElement.dataset.theme=APP.theme;localStorage.setItem('tower-app-theme',APP.theme);}
function applyBranding(b){b=b||{};const r=document.documentElement.style;if(b.primaryColor)r.setProperty('--brand-blue',b.primaryColor);if(b.accentColor)r.setProperty('--brand-green',b.accentColor);if(b.logoUrl){const src=String(b.logoUrl);const image=new Image();image.onload=()=>{r.setProperty('--ft-brand-logo',`url("${src.replace(/"/g,'')}")`);document.documentElement.classList.add('custom-brand-logo');};image.onerror=()=>{r.removeProperty('--ft-brand-logo');document.documentElement.classList.remove('custom-brand-logo');const fav=document.querySelector('link[rel="icon"]');if(fav?.dataset.towerDefaultIcon)fav.href=fav.dataset.towerDefaultIcon;};image.src=src+'?t='+Date.now();}else{r.removeProperty('--ft-brand-logo');document.documentElement.classList.remove('custom-brand-logo');}{const bg=String(b.loginBackgroundUrl||'').trim();const requestId=(applyBranding.loginBgRequestId||0)+1;applyBranding.loginBgRequestId=requestId;r.removeProperty('--ft-login-bg');if(bg&&/^https?:\/\/|^\//i.test(bg)){const preview=new Image();preview.onload=()=>{if(applyBranding.loginBgRequestId!==requestId)return;r.setProperty('--ft-login-bg',`url("${bg.replace(/"/g,'')}")`);};preview.onerror=()=>{if(applyBranding.loginBgRequestId===requestId)r.removeProperty('--ft-login-bg');};preview.src=bg;}}{let l=document.querySelector('link[rel="icon"]');if(l){if(!l.dataset.towerDefaultIcon)l.dataset.towerDefaultIcon=l.href;l.href=b.logoUrl?('/api/brand/logo?t='+Date.now()):(b.faviconUrl||l.dataset.towerDefaultIcon);}}updateDocumentTitle();}
function applyUiPreferences(p){p=p||{};const r=document.documentElement.style,f=p.fontFamily||'Cairo';r.setProperty('--font',`'${f}',sans-serif`);['helper','body','label','title'].forEach(k=>{const cap=k[0].toUpperCase()+k.slice(1);if(p['desktop'+cap])r.setProperty('--fs-'+k,String(p['desktop'+cap])+'px');if(p['mobile'+cap])r.setProperty('--m-fs-'+k,String(p['mobile'+cap])+'px');});}
function themeIcon(){return '<svg class="theme-half-icon" viewBox="0 0 48 48" width="26" height="26" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.8"/><path d="M24 7 A17 17 0 0 0 24 41 Z" fill="currentColor"/></svg>';}
const TOOL_ICONS={edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4Z"/>',copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',refresh:'<path d="M20 7v5h-5"/><path d="M4 17v-5h5"/><path d="M5 9a8 8 0 0 1 13-3l2 2M4 16l2 2a8 8 0 0 0 13-3"/>',download:'<path d="M12 3v12m-5-5 5 5 5-5"/><path d="M5 17v4h14v-4"/>',share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.7 6.6-4.4m-6.6 7 6.6 4.4"/>'};
function toolIcon(name){return `<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${TOOL_ICONS[name]||''}</svg>`;}
function toolButton(name,label,action,extra=''){return `<button type="button" class="tower-tool-button ${extra}" title="${esc(label)}" aria-label="${esc(label)}" onclick="${action}">${toolIcon(name)}</button>`;}
function goTripSection(id){const section=document.getElementById(id);if(!section)return;section.scrollIntoView({behavior:window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});section.focus({preventScroll:true});}
function themeButton(extra=''){return `<button type="button" class="icon-btn theme-icon-btn ${extra}" aria-label="تغيير المظهر" title="تغيير المظهر" onclick="toggleTheme()"><span class="theme-glyph" aria-hidden="true">${themeIcon()}</span></button>`;}
function toggleTheme(){setTheme(APP.theme==='dark'?'light':'dark');document.querySelectorAll('.theme-glyph').forEach(el=>el.innerHTML=themeIcon());}
function saveToken(v){APP.token=v||'';if(APP.token)sessionStorage.setItem('tower-app-session',APP.token);else sessionStorage.removeItem('tower-app-session');}
function systemName(){return (APP.ctx&&APP.ctx.building&&APP.ctx.building.name)||'Tower App';}
function updateDocumentTitle(){const name=APP.ctx&&APP.ctx.user&&(APP.ctx.user.displayName||APP.ctx.user.roleLabel);document.title=name?`${name} | ${systemName()}`:systemName();}
function clearSession(){try{sessionStorage.removeItem(LAST_PAGE_KEY);}catch(_){}saveToken('');APP.ctx=null;APP.home=null;APP.activeUnitId='';APP.unitChoices=[];window.clearTaskProjectSession?.();window.clearServiceWorkspaceSession?.();clearClientCaches();document.title=systemName();}
function direct(name,...args){return new Promise((resolve,reject)=>google.script.run.withSuccessHandler(resolve).withFailureHandler(reject)[name](...args));}

function pinInputHtml(id,autocomplete,value){const v=value==null?'':` value="${esc(value)}"`;return `<div class="pin-field"><input id="${esc(id)}" type="password" autocomplete="${esc(autocomplete||'off')}" inputmode="numeric" pattern="[0-9]*" maxlength="8"${v} required><button type="button" class="pin-eye" onclick="togglePinVisibility('${esc(id)}',this)" aria-label="إظهار PIN" title="إظهار PIN">◉</button></div>`;}
function togglePinVisibility(id,btn){const input=$(id);if(!input)return;const show=input.type==='password';input.type=show?'text':'password';if(btn){btn.setAttribute('aria-label',show?'إخفاء PIN':'إظهار PIN');btn.setAttribute('title',show?'إخفاء PIN':'إظهار PIN');btn.textContent=show?'◌':'◉';}input.focus();try{const n=input.value.length;input.setSelectionRange(n,n);}catch(_){}}

function rpcFetch(name,args,key){const started=performance.now();const promise=new Promise((resolve,reject)=>google.script.run.withSuccessHandler(v=>{perfRecord('rpc',name,performance.now()-started);resolve(v);}).withFailureHandler(e=>{perfRecord('rpc-error',name,performance.now()-started,errText(e));const m=errText(e);if(m.includes('SESSION_REQUIRED')){clearSession();showLogin('انتهت جلسة الدخول. سجل الدخول مرة أخرى.');return reject(e);}if(m.includes('PIN_CHANGE_REQUIRED')){showForcedPinChange();return reject(e);}reject(e);}).apiCall({name,args,token:APP.token}));RPC_INFLIGHT.set(key,promise);return promise.finally(()=>RPC_INFLIGHT.delete(key));}
function run(name,...args){
 if(APP.ctx?.user?.role==='RESIDENT'&&APP.activeUnitId){
  if(name==='getResidentDuesPage')args=[{...(args[0]||{}),unitId:APP.activeUnitId}];
  else if(name==='getMyUnitGovernance')args=[APP.activeUnitId];
  else if(name==='getMyServices')args=[{__activeUnitId:APP.activeUnitId}];
  else if(['getTaskProject','taskProjectAction','listTaskInstallments','getServiceWorkspace'].includes(name)&&APP.ctx?.user?.role==='RESIDENT')args=[...args,{__activeUnitId:APP.activeUnitId}];
  else if(['requestServiceSubscription','cancelMyServiceSubscription','updatePendingServiceSubscription','requestServiceChange'].includes(name))args.push({__activeUnitId:APP.activeUnitId});
  else if(['getResidentAccountData','addResidentPayment','cancelResidentPayment','closeMyAccount','undoMyLastSettlement','getSettlementDetails','getMyTripSettings','updateMyTripSettings'].includes(name))args.push({__activeUnitId:APP.activeUnitId});
  else if(name==='createResidentTrip')args=[{...(args[0]||{}),unitId:APP.activeUnitId}];
  else if(name==='listTrips')args=[APP.activeUnitId];
 }
 const key=rpcKey(name,args),ttl=Number(RPC_TTL[name]||0),mutation=RPC_MUTATION.test(name)||['taskProjectAction','editManagedService','collectPersonalDue'].includes(name)||name==='managerRegistrationOpinion'||name==='managerMemberOpinion'||(name==='welcomeProgress'&&args[0]==='save');if(mutation){invalidateRpcCache();return rpcFetch(name,args,key).then(v=>{invalidateRpcCache();return v;});}const hit=RPC_CACHE.get(key);if(hit&&ttl&&Date.now()-hit.at<ttl){if(!RPC_INFLIGHT.has(key)&&Date.now()-hit.at>Math.min(ttl*.55,30000)){rpcFetch(name,args,key).then(v=>RPC_CACHE.set(key,{at:Date.now(),value:v})).catch(()=>{});}return Promise.resolve(hit.value);}if(RPC_INFLIGHT.has(key))return RPC_INFLIGHT.get(key);return rpcFetch(name,args,key).then(v=>{if(ttl&&(!(APP.ctx?.user?.role==='RESIDENT')||!APP.activeUnitId||!key.includes('unitId')||key.includes(APP.activeUnitId)))RPC_CACHE.set(key,{at:Date.now(),value:v});return v;});}
function prefetchApi(name,...args){const key=rpcKey(name,args),ttl=Number(RPC_TTL[name]||45000),hit=RPC_CACHE.get(key);if(hit&&Date.now()-hit.at<ttl)return;run(name,...args).catch(()=>{});}
function scheduleRolePrefetch(){const job=()=>{if(!APP.ctx||!APP.ctx.user)return;const r=APP.ctx.user.role;prefetchApi('getCoreHomeData');if(r==='RESIDENT'){prefetchApi('getResidentAccountData');prefetchApi('getMyUnitGovernance');prefetchApi('getMyServices');}else if(r==='OPERATOR'){prefetchApi('getGuardTripContext');prefetchApi('getCollectionContext');}else if(r==='UNION'){prefetchApi('getFinanceDashboard');prefetchApi('getCollectionContext');prefetchApi('listServices');}else if(r==='ADMIN'){prefetchApi('listUnits');prefetchApi('adminGetSystemSettings');prefetchApi('getCollectionContext');}};if('requestIdleCallback'in window)requestIdleCallback(job,{timeout:1600});else setTimeout(job,900);}

function toast(text,type='info',options={}){
 const e=$('toast');if(!e)return;
 e.replaceChildren();const span=document.createElement('span');span.textContent=westernDigits(text);e.appendChild(span);
 const persistent=type==='error'||!!options.persistent;
 if(type==='error'){
  LAST_ERROR_DETAILS='Tower App error\n'+String(text||'')+'\nRole: '+String(APP.ctx?.user?.role||'UNKNOWN')+'\nPage: '+String(APP.page||'unknown')+'\nTime: '+new Date().toISOString();
  const copy=document.createElement('button');copy.type='button';copy.textContent='نسخ تفاصيل الخطأ';copy.onclick=copyLastErrorDetails;e.appendChild(copy);
 }
 if(persistent){const close=document.createElement('button');close.type='button';close.textContent='إغلاق';close.setAttribute('aria-label','إغلاق الرسالة');close.onclick=()=>e.classList.add('hidden');e.appendChild(close);}
 e.dataset.type=type;e.classList.remove('hidden');clearTimeout(e._t);
 if(!persistent)e._t=setTimeout(()=>e.classList.add('hidden'),4000);
}

let ACTIVE_SAVES=0;
function syncOperationIndicator(){const e=$('operationIndicator');if(!e)return;e.classList.toggle('hidden',ACTIVE_SAVES<=0);}
function beginBackgroundSave(){ACTIVE_SAVES++;syncOperationIndicator();}
function endBackgroundSave(){ACTIVE_SAVES=Math.max(0,ACTIVE_SAVES-1);syncOperationIndicator();}
async function withBackgroundSave(fn){beginBackgroundSave();try{return await fn();}finally{endBackgroundSave();}}
window.addEventListener('beforeunload',e=>{if(ACTIVE_SAVES>0||towerTaskFormChanged()||towerOtherFormChanged()){e.preventDefault();e.returnValue='';}});
function setButtonBusy(btn,busy,label){if(!btn)return;if(busy){btn.dataset.oldText=btn.textContent;btn.disabled=true;btn.classList.add('is-busy');btn.textContent=label||'جاري الحفظ…';}else{btn.disabled=false;btn.classList.remove('is-busy');if(btn.dataset.oldText)btn.textContent=btn.dataset.oldText;}}


function confirmAction(opts){opts=typeof opts==='string'?{message:opts}:opts||{};return new Promise(resolve=>{window.__confirmResolve=resolve;const rows=(opts.rows||[]).map(x=>`<div class="confirm-data-row"><span>${esc(x.label)}</span><strong>${esc(x.value)}</strong></div>`).join('');openModal(`<div class="modal-head"><div><h3>${esc(opts.title||'تأكيد الإجراء')}</h3><p>${esc(opts.message||'راجع البيانات قبل المتابعة.')}</p></div><button class="icon-btn" onclick="resolveConfirm(false)">×</button></div>${rows?`<div class="confirm-data">${rows}</div>`:''}${opts.warning?`<div class="state-card warning-state"><span>${esc(opts.warning)}</span></div>`:''}<div class="form-actions"><button class="btn-sm ${opts.danger?'danger':'primary'}" onclick="resolveConfirm(true)">${esc(opts.confirmLabel||'تأكيد')}</button><button class="btn-sm" onclick="resolveConfirm(false)">إلغاء</button></div>`);});}
function resolveConfirm(v){const r=window.__confirmResolve;window.__confirmResolve=null;closeModal();if(r)r(!!v);}
function promptAction(opts){opts=opts||{};return new Promise(resolve=>{window.__promptResolve=resolve;openModal(`<div class="modal-head"><div><h3>${esc(opts.title||'إدخال البيانات')}</h3><p>${esc(opts.message||'')}</p></div><button class="icon-btn" onclick="resolvePrompt(null)">×</button></div><label class="field"><span>${esc(opts.label||'القيمة')}</span><input id="sharedPromptInput" value="${esc(opts.value||'')}" ${opts.type==='number'?'type="number" inputmode="decimal"':''}></label><div class="form-actions"><button class="btn-sm primary" onclick="resolvePrompt(($('sharedPromptInput')||{}).value)">${esc(opts.confirmLabel||'حفظ')}</button><button class="btn-sm" onclick="resolvePrompt(null)">إلغاء</button></div>`);setTimeout(()=>{const i=$('sharedPromptInput');if(i){i.focus();i.select();}},20);});}
function resolvePrompt(v){const r=window.__promptResolve;window.__promptResolve=null;closeModal();if(r)r(v);}
async function copyTextValue(v,msg){try{await navigator.clipboard.writeText(String(v||''));toast(msg||'تم النسخ.');return true;}catch(_){const t=document.createElement('textarea');t.value=String(v||'');document.body.appendChild(t);t.select();document.execCommand('copy');t.remove();toast(msg||'تم النسخ.');return true;}}
async function shareTextValue(title,text){if(navigator.share){try{await navigator.share({title:title||'Tower App',text:String(text||'')});return;}catch(e){if(e&&e.name==='AbortError')return;}}await copyTextValue(text,'المشاركة غير متاحة؛ تم نسخ البيانات بدلًا منها.');}

// Keep open dialogs above the mobile virtual keyboard (iOS/Android visual viewport).
function syncModalVisualViewport(){
 const m=$('modal');if(!m||m.classList.contains('hidden'))return;
 const v=window.visualViewport;
 const height=v?Math.max(120,Math.round(v.height)):window.innerHeight;
 const top=v?Math.max(0,Math.round(v.offsetTop)):0;
 m.style.setProperty('--tower-modal-height',height+'px');
 m.style.setProperty('--tower-modal-top',top+'px');
}
function bringModalFieldIntoView(element){
 const sheet=$('modalSheet');if(!sheet||!sheet.contains(element))return;
 const sr=sheet.getBoundingClientRect(),r=element.getBoundingClientRect();
 const lower=sr.bottom-20,upper=sr.top+16;
 if(r.bottom>lower)sheet.scrollTop+=r.bottom-lower;
 else if(r.top<upper)sheet.scrollTop-=upper-r.top;
}
if(window.visualViewport){
 window.visualViewport.addEventListener('resize',()=>{syncModalVisualViewport();const a=document.activeElement;if(a&&$('modalSheet')?.contains(a))requestAnimationFrame(()=>bringModalFieldIntoView(a));});
 window.visualViewport.addEventListener('scroll',syncModalVisualViewport);
}
document.addEventListener('focusin',e=>{
 const a=e.target;if(!$('modalSheet')?.contains(a))return;
 syncModalVisualViewport();
 setTimeout(()=>{syncModalVisualViewport();bringModalFieldIntoView(a);},180);
});

// Nested modal stack: preserve the actual DOM nodes of the parent form, including
// search inputs, selections and event listeners. Never throw away the parent on confirm.
// Preserve user input in the task plan when closing with X, Cancel, Escape or Back.
// A success path explicitly accepts the saved values before dismissing the dialog.
let TOWER_TASK_FORM_BASELINE=null;
let TOWER_TASK_FORM_ACCEPTED=false;
function towerTaskFormSnapshot(){
 const sh=$('modalSheet');if(!sh||!sh.querySelector('#taskStageInput'))return null;
 return Array.from(sh.querySelectorAll('input,select,textarea'))
  .filter(el=>el.type!=='button'&&el.type!=='submit')
  .map(el=>[el.id||el.name||'',el.type==='file'?Array.from(el.files||[]).map(f=>[f.name,f.size,f.lastModified]):el.type==='checkbox'||el.type==='radio'?el.checked:el.value]);
}
function towerTaskFormChanged(){
 const current=towerTaskFormSnapshot();
 return !!current&&!!TOWER_TASK_FORM_BASELINE&&!TOWER_TASK_FORM_ACCEPTED&&JSON.stringify(current)!==JSON.stringify(TOWER_TASK_FORM_BASELINE);
}
function towerAcceptTaskFormChanges(){TOWER_TASK_FORM_ACCEPTED=true;}
function towerTrackTaskForm(){
 if(!$('modalSheet')?.querySelector('#taskStageInput'))return;
 TOWER_TASK_FORM_ACCEPTED=false;
 TOWER_TASK_FORM_BASELINE=towerTaskFormSnapshot();
}
// Shared unsaved form protection for editable modal forms (task plans retain their own rules).
let TOWER_OTHER_FORM_BASELINE=null;
function towerOtherFormSnapshot(){
 const sh=$('modalSheet');
 if(!sh||sh.querySelector('#taskStageInput')||!sh.querySelector('form'))return null;
 const form=sh;
 if(!form||!form.querySelector('input:not([type=hidden]),select,textarea'))return null;
 return Array.from(form.querySelectorAll('form input,form select,form textarea'))
  .filter(el=>!['hidden','button','submit','reset'].includes(el.type))
  .map(el=>[el.id||el.name||'',el.type==='file'?Array.from(el.files||[]).map(f=>[f.name,f.size,f.lastModified]):el.type==='checkbox'||el.type==='radio'?el.checked:el.value]);
}
function towerOtherFormChanged(){
 const v=towerOtherFormSnapshot();
 return !!v&&!!TOWER_OTHER_FORM_BASELINE&&JSON.stringify(v)!==JSON.stringify(TOWER_OTHER_FORM_BASELINE);
}
function towerTrackOtherForm(){TOWER_OTHER_FORM_BASELINE=towerOtherFormSnapshot();}
let TOWER_ESCAPE_DISMISS=false;
let TOWER_BACKDROP_DISMISS=false;
function towerDismissBackdrop(event){
 if(event.target!==event.currentTarget)return;
 TOWER_BACKDROP_DISMISS=true;
 try{closeModal();}finally{TOWER_BACKDROP_DISMISS=false;}
}
function towerExplicitDismiss(fromHistory){
 if(fromHistory||TOWER_ESCAPE_DISMISS||TOWER_BACKDROP_DISMISS)return true;
 const e=window.event;
 if(!e||e.type!=='click')return false;
 const b=e.target?.closest?.('button');
 if(!b)return false;
 const code=b.getAttribute('onclick')||'';
 return /closeModal\s*\(/.test(code)||/إلغاء|إغلاق/.test(b.textContent||'')&&/closeModal/.test(code);
}
const TOWER_MODAL_STACK=[];
function towerModalDepth(){return $('modal')?.classList.contains('hidden')?0:TOWER_MODAL_STACK.length+1;}
function towerSetModalHistory(depth){
 if(history.state?.towerPage)history.pushState({...history.state,towerModal:depth>0,towerModalDepth:depth},'');
}
function openModal(html,wide,replace=false){
 const sh=$('modalSheet');
 const replacing=!!replace&&towerModalDepth()>0;
 if(towerModalDepth()&&!replacing){
  const scrollTop=sh.scrollTop,focus=sh.contains(document.activeElement)?document.activeElement:null;
  const preserved=document.createDocumentFragment();
  while(sh.firstChild)preserved.appendChild(sh.firstChild);
  TOWER_MODAL_STACK.push({content:preserved,wide:sh.classList.contains('modal-wide'),bulk:sh.classList.contains('bulk-create-sheet'),taskFormBaseline:TOWER_TASK_FORM_BASELINE,taskFormAccepted:TOWER_TASK_FORM_ACCEPTED,otherFormBaseline:TOWER_OTHER_FORM_BASELINE,scrollTop,focus,sharedMembers:window.TOWER_SHARED_MEMBERS,servicePick:window.SERVICE_PICK});
 }
 sh.innerHTML=html;
 sh.scrollTop=0;
 TOWER_TASK_FORM_BASELINE=null;TOWER_TASK_FORM_ACCEPTED=false;TOWER_OTHER_FORM_BASELINE=null;
 sh.classList.toggle('modal-wide',!!wide);
 sh.classList.remove('bulk-create-sheet');
 $('modal').classList.remove('hidden');
 document.documentElement.classList.add('modal-open');
 if(!replacing)towerSetModalHistory(towerModalDepth());
 syncModalVisualViewport();
 towerTrackTaskForm();
 towerTrackOtherForm();
}
function closeModal(fromHistory=false){
 const modal=$('modal'),sh=$('modalSheet');
 if(!modal||modal.classList.contains('hidden'))return;
 if(towerTaskFormChanged()&&!window.confirm('فيه تعديلات في خطة المهمة لم يتم حفظها. هل تريد تجاهل التعديلات والخروج؟')){
  if(fromHistory&&history.state?.towerPage)history.pushState({...history.state,towerModal:true,towerModalDepth:towerModalDepth()},'');
  return;
 }
 if(towerOtherFormChanged()&&towerExplicitDismiss(fromHistory)&&!window.confirm('فيه تعديلات لم يتم حفظها. هل تريد تجاهلها والخروج؟')){
  if(fromHistory&&history.state?.towerPage)history.pushState({...history.state,towerModal:true,towerModalDepth:towerModalDepth()},'');
  return;
 }
 if(!fromHistory&&history.state?.towerModal)history.back();
 if(TOWER_MODAL_STACK.length){
  const parent=TOWER_MODAL_STACK.pop();
  sh.replaceChildren(parent.content);
  sh.classList.toggle('modal-wide',parent.wide);
  sh.classList.toggle('bulk-create-sheet',parent.bulk);
  TOWER_TASK_FORM_BASELINE=parent.taskFormBaseline;TOWER_TASK_FORM_ACCEPTED=parent.taskFormAccepted;TOWER_OTHER_FORM_BASELINE=parent.otherFormBaseline;
  window.TOWER_SHARED_MEMBERS=parent.sharedMembers;window.SERVICE_PICK=parent.servicePick;
  syncModalVisualViewport();
  sh.scrollTop=parent.scrollTop||0;
  if(parent.focus?.isConnected)parent.focus.focus({preventScroll:true});
 }else{
  modal.classList.add('hidden');sh.replaceChildren();
  TOWER_TASK_FORM_BASELINE=null;TOWER_TASK_FORM_ACCEPTED=false;TOWER_OTHER_FORM_BASELINE=null;
  document.documentElement.classList.remove('modal-open');
  modal.style.removeProperty('--tower-modal-height');modal.style.removeProperty('--tower-modal-top');
 }
 // A canceled confirmation/prompt must always resolve, even on backdrop/Back.
 if(window.__confirmResolve){const done=window.__confirmResolve;window.__confirmResolve=null;done(false);}
 if(window.__promptResolve){const done=window.__promptResolve;window.__promptResolve=null;done(null);}
}
function towerResetModalStack(){TOWER_MODAL_STACK.length=0;TOWER_TASK_FORM_ACCEPTED=true;const modal=$('modal');if(modal&&!modal.classList.contains('hidden'))closeModal(true);}
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&towerModalDepth()){event.preventDefault();TOWER_ESCAPE_DISMISS=true;try{closeModal();}finally{TOWER_ESCAPE_DISMISS=false;}}});

function cacheCurrentPage(){const c=$('content');if(!c||!APP.page)return;const html=c.innerHTML||'';if(!html||c.querySelector('.page-skeleton,.page-refresh-note,.loading-state,.error-state'))return;PAGE_CACHE.set(APP.page,{html,at:Date.now()});persistPageCache();}
function bindPageCacheObserver(){const c=$('content');if(!c)return;if(PAGE_CACHE_OBSERVER)PAGE_CACHE_OBSERVER.disconnect();PAGE_CACHE_OBSERVER=new MutationObserver(()=>{clearTimeout(PAGE_CACHE_TIMER);PAGE_CACHE_TIMER=setTimeout(cacheCurrentPage,80);});PAGE_CACHE_OBSERVER.observe(c,{childList:true,subtree:true,characterData:true});}
function invalidatePageCache(...keys){(keys.length?keys:[APP.page]).forEach(k=>PAGE_CACHE.delete(k));persistPageCache();}
function pageSkeleton(text='جاري التحميل…'){return `<div class="page-skeleton" aria-live="polite"><div class="page-refresh-note"><span class="spinner tiny"></span><span>${esc(text)}</span></div><section class="panel skeleton-panel"><div class="skeleton-line wide"></div><div class="skeleton-line mid"></div><div class="skeleton-grid"><i></i><i></i><i></i></div></section><section class="panel skeleton-panel"><div class="skeleton-line short"></div><div class="skeleton-line wide"></div><div class="skeleton-line mid"></div></section></div>`;}
function pageLoading(text='جاري التحميل…'){const hit=PAGE_CACHE.get(APP.page);if(hit&&hit.html)return `<div class="page-refresh-note"><span class="spinner tiny"></span><span>جاري تحديث البيانات في الخلفية…</span></div>${hit.html}`;return pageSkeleton(text);}
function showRoot(html){$('boot').classList.add('hidden');if(html.includes('login-wrap')&&!html.includes('class="login-footer"'))html=html.replace('</div></section>',`<div class="login-footer">${appCopyright()}</div></div></section>`);$('root').innerHTML=html;$('root').classList.remove('hidden');}
function publicError(text){showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>Tower App</strong><small>Core Foundation · V${esc(APP.ctx&&APP.ctx.version?APP.ctx.version:'')}</small></div></div><div class="state-card error-state"><strong>تعذر تشغيل النظام</strong><span>${esc(text)}</span></div></div></section>`);}
setTheme(APP.theme);
window.addEventListener('load',function(){
  if(typeof bootApp==='function'){bootApp();return;}
  publicError('تعذر بدء التطبيق: لم يتم تحميل وحدة المصادقة.');
});





async function bootApp(){
  try{const ctx=await direct('getBootstrapContext',APP.token);APP.ctx=ctx;applyUiPreferences(ctx.uiPreferences);applyBranding(ctx.branding);if(!ctx.configured){showSetupNeeded();return;}if(ctx.upgradeRequired){publicError('شغّل setupFoundation_() من محرر Apps Script لإكمال ترقية Core Foundation.');return;}if(!ctx.user||!ctx.user.authenticated){if(APP.token)clearSession();showLogin();return;}if(ctx.user.mustChangePin){showForcedPinChange();return;}await enterApp();}catch(e){publicError(errText(e));}
}
function showSetupNeeded(){showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>Tower App</strong><small>Core Foundation · V${esc((APP.ctx&&APP.ctx.version)||'')}</small></div></div><div class="state-card warning-state"><strong>النظام غير مهيأ</strong><span>ارفع النسخة ثم شغّل <bdi>setupFoundation_()</bdi> مرة واحدة من محرر Apps Script وبعدها افتح رابط الـWeb App.</span></div></div></section>`);}
function showLogin(message=''){
  const building=APP.ctx&&APP.ctx.building?APP.ctx.building.name:'Tower App';showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>${esc(building||'Tower App')}</strong><small>Tower App · V${esc((APP.ctx&&APP.ctx.version)||'')}</small></div></div>${message?`<div class="login-message">${esc(message)}</div>`:''}<form class="login-form" onsubmit="submitLogin(event)"><label class="field"><span>معرف الدخول</span><input id="loginId" class="ltr-id" dir="ltr" autocomplete="username" inputmode="latin" maxlength="32" required></label><label class="field"><span>PIN</span>${pinInputHtml("loginPin","current-password")}</label><button id="loginBtn" class="primary-btn wide" type="submit">تسجيل الدخول</button></form><div class="public-auth-actions"><button class="text-action" type="button" onclick="showRegistrationRequest()">طلب انضمام</button><button class="text-action" type="button" onclick="showPinRecovery()">نسيت PIN؟</button><button class="text-action" type="button" onclick="showActivationForm()">تفعيل الحساب</button></div><div class="login-theme-control">${themeButton('login-theme-button')}</div><div class="login-footer">${appCopyright()}</div></div></section>`);setTimeout(()=>$('loginId')&&$('loginId').focus(),30);
}
async function submitLogin(ev){ev.preventDefault();const btn=$('loginBtn'),id=$('loginId').value,pin=$('loginPin').value;btn.disabled=true;btn.textContent='جاري التحقق…';try{const r=await direct('loginWithCredentials',id,pin);if(!r||!r.token)throw new Error('تعذر إنشاء جلسة دخول آمنة.');saveToken(r.token);APP.ctx=r.context||await direct('getBootstrapContext',APP.token);applyUiPreferences(APP.ctx.uiPreferences);applyBranding(APP.ctx.branding);if(APP.ctx.user.mustChangePin){showForcedPinChange(pin);return;}await enterApp();}catch(e){showLogin('تعذر تسجيل الدخول: '+errText(e));}finally{if(btn){btn.disabled=false;btn.textContent='تسجيل الدخول';}}}
function showForcedPinChange(prefillCurrent=''){
  const u=APP.ctx&&APP.ctx.user?APP.ctx.user:{};showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>تأمين الحساب</strong><small>${esc(u.displayName||u.roleLabel||'Tower App')}</small></div></div><div class="login-message">لازم تغيّر الـPIN المؤقت قبل فتح النظام.</div><form class="login-form" onsubmit="submitForcedPin(event)"><label class="field"><span>PIN الحالي</span>${pinInputHtml("currentPin","current-password",prefillCurrent)}</label><label class="field"><span>PIN الجديد</span>${pinInputHtml("newPin","new-password")}</label><label class="field"><span>تأكيد PIN الجديد</span>${pinInputHtml("confirmPin","new-password")}</label><button id="pinBtn" class="primary-btn wide" type="submit">حفظ PIN الجديد</button></form></div></section>`);
}
async function submitForcedPin(ev){ev.preventDefault();const a=$('currentPin').value,b=$('newPin').value,c=$('confirmPin').value,btn=$('pinBtn');if(b!==c){toast('تأكيد PIN غير مطابق.','error');return;}btn.disabled=true;try{await run('changeMyPin',a,b);const publicCtx={version:APP.ctx&&APP.ctx.version,building:APP.ctx&&APP.ctx.building,uiPreferences:APP.ctx&&APP.ctx.uiPreferences};clearSession();APP.ctx=publicCtx;showLogin('تم تغيير PIN. سجل الدخول بالـPIN الجديد.');}catch(e){toast(errText(e),'error');}finally{if(btn)btn.disabled=false;}}
async function logoutApp(){const token=APP.token,publicCtx={version:APP.ctx&&APP.ctx.version,building:APP.ctx&&APP.ctx.building,uiPreferences:APP.ctx&&APP.ctx.uiPreferences};clearSession();try{if(token)await direct('logoutCurrentSession',token);}catch(_){}APP.ctx=publicCtx;showLogin('تم تسجيل الخروج.');}

async function showRegistrationRequest(){try{const x=await direct('getPublicRegistrationContext');const titles=x.titles||[],units=x.units||[];showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>طلب انضمام</strong><small>اختر وحدتك وأرسل الطلب للإدارة.</small></div></div><form class="login-form registration-two-column" onsubmit="submitPublicRegistration(event)"><label class="field"><span>اللقب</span><select id="pubTitle">${titles.map(t=>`<option value="${esc(t.titleId)}">${esc(t.title||t.label)}</option>`).join('')}</select></label><label class="field"><span>الاسم</span><input id="pubName" required></label><label class="field"><span>الوحدة</span><select id="pubUnit" required><option value="">اختر الوحدة</option>${units.map(u=>`<option value="${esc(u.unitId)}">شقة ${esc(unitNo(u.unitNumber))} · دور ${esc(floorNo(u.floor||''))}${u.unitType?' · '+esc(u.unitType):''}</option>`).join('')}</select></label><label class="field"><span>صلة القرابة</span>${relationFields('pub')}</label><label class="field"><span>الهاتف</span><input id="pubPhone" class="ltr-number" dir="ltr" inputmode="tel" placeholder="اختياري، ويُطلب لمدير الوحدة"></label><label class="field"><span>البريد الإلكتروني — اختياري</span><input id="pubEmail" type="email"></label><button class="primary-btn wide" type="submit">إرسال الطلب</button><button class="text-action" type="button" onclick="showLogin()">العودة لتسجيل الدخول</button></form></div></section>`);}catch(e){showLogin(errText(e));}}
async function submitPublicRegistration(e){e.preventDefault();try{const titleId=$('pubTitle').value,t=(await direct('getPublicRegistrationContext')).titles.find(x=>x.titleId===titleId);await direct('submitRegistrationRequest',{unitId:$('pubUnit').value,name:$('pubName').value,titleId,title:t?t.title:'',phone:$('pubPhone').value,email:$('pubEmail').value,relation:readRelation('pub')});showLogin('تم إرسال طلب الانضمام للإدارة. بعد الموافقة ستحصل على User ID وكود تفعيل.');}catch(x){toast(errText(x),'error');}}
function showActivationForm(){showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>تفعيل الحساب</strong><small>استخدم User ID وكود التفعيل الصادر من الإدارة.</small></div></div><form class="login-form" onsubmit="submitActivation(event)"><label class="field"><span>User ID</span><input id="actLogin" class="ltr-id" dir="ltr" required></label><label class="field"><span>كود التفعيل</span><input id="actCode" class="ltr-id" dir="ltr" inputmode="numeric" maxlength="6" required></label><label class="field"><span>PIN الجديد</span>${pinInputHtml('actPin','new-password')}</label><button class="primary-btn wide" type="submit">تفعيل الحساب</button><button class="text-action" type="button" onclick="showLogin()">العودة</button></form></div></section>`);}
async function submitActivation(e){e.preventDefault();try{await direct('activateRegistration',$('actLogin').value,$('actCode').value,$('actPin').value);showLogin('تم تفعيل الحساب. يمكنك تسجيل الدخول الآن.');}catch(x){toast(errText(x),'error');}}
function showPinRecovery(){showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>استرجاع PIN</strong><small>أرسل طلبًا للإدارة أو أدخل الكود إذا وصلك بالفعل.</small></div></div><form class="login-form" onsubmit="submitPinResetRequestUi(event)"><label class="field"><span>User ID</span><input id="resetLogin" class="ltr-id" dir="ltr" required></label><button class="primary-btn wide" type="submit">إرسال طلب الاسترجاع</button><button class="text-action" type="button" onclick="showCompletePinReset()">معي كود استرجاع</button><button class="text-action" type="button" onclick="showLogin()">العودة</button></form></div></section>`);}
async function submitPinResetRequestUi(e){e.preventDefault();try{await direct('submitPinResetRequest',$('resetLogin').value);showLogin('تم إرسال طلب استرجاع PIN للإدارة.');}catch(x){toast(errText(x),'error');}}
function showCompletePinReset(){showRoot(`<section class="login-wrap"><div class="login-card"><div class="login-brand"><span class="brand-mark"></span><div><strong>تعيين PIN جديد</strong><small>استخدم كود الاسترجاع الصادر من الإدارة.</small></div></div><form class="login-form" onsubmit="completePinResetUi(event)"><label class="field"><span>User ID</span><input id="reset2Login" class="ltr-id" dir="ltr" required></label><label class="field"><span>كود الاسترجاع</span><input id="reset2Code" class="ltr-id" dir="ltr" inputmode="numeric" maxlength="6" required></label><label class="field"><span>PIN الجديد</span>${pinInputHtml('reset2Pin','new-password')}</label><button class="primary-btn wide" type="submit">حفظ PIN الجديد</button><button class="text-action" type="button" onclick="showLogin()">إلغاء</button></form></div></section>`);}
async function completePinResetUi(e){e.preventDefault();try{await direct('completePinReset',$('reset2Login').value,$('reset2Code').value,$('reset2Pin').value);showLogin('تم تغيير PIN. سجل الدخول بالرقم الجديد.');}catch(x){toast(errText(x),'error');}}






function roleMenu(role){const menus={ADMIN:[['home','⌂','الرئيسية'],['collections','◉','التحصيل'],['finance','▤','المالية'],['units','▦','الوحدات'],['people','♙','الأعضاء'],['services','◇','الخدمات'],['activity','◴','النشاط'],['reports','▤','التقارير'],['settings','⚙','الإعدادات']],UNION:[['home','⌂','الرئيسية'],['collections','◉','التحصيل'],['finance','▤','المالية'],['units','▦','الوحدات'],['people','♙','الأعضاء'],['services','◇','الخدمات'],['activity','◴','النشاط'],['reports','▤','التقارير'],['settings','⚙','الإعدادات']],RESIDENT:[['home','⌂','الرئيسية'],['building','▤','العمارة'],['trips','↗','المشاوير'],['unit','▦','الوحدة']],OPERATOR:[['trips','↗','المشاوير'],['collections','◉','التحصيل'],['settings','⚙','الإعدادات']]};return menus[role]||menus.RESIDENT;}
const NAV_PENDING={people:0,services:0};
function navHtml(menu){return menu.map(x=>`<button class="nav-btn nav-${x[0]} ${APP.page===x[0]?'active':''} ${NAV_PENDING[x[0]]>0?'pending-alert':''}" aria-label="${esc(x[2])}" onclick="go('${x[0]}')"><span class="nav-icon">${x[1]}</span><span>${x[2]}</span></button>`).join('');}
function mobilePrimaryKeys(role){return({ADMIN:['home','units','people'],UNION:['home','collections','units'],RESIDENT:['home','building','trips','unit'],OPERATOR:['trips','collections','settings']})[role]||['home','account','unit'];}
function mobileNavHtml(role){const menu=roleMenu(role),keys=mobilePrimaryKeys(role),main=menu.filter(x=>keys.includes(x[0])),more=menu.filter(x=>!keys.includes(x[0])),moreActive=more.some(x=>x[0]===APP.page);return `${navHtml(main)}${more.length?`<button class="nav-btn nav-more ${moreActive?'active':''}" aria-label="المزيد" onclick="openMoreMenu()"><span class="nav-icon">•••</span><span>المزيد</span></button>`:''}`;}
function refreshMobileNav(){const n=document.querySelector('.mobile-nav');if(n&&APP.ctx&&APP.ctx.user)n.innerHTML=mobileNavHtml(APP.ctx.user.role);}
function openMoreMenu(){const role=APP.ctx.user.role,keys=mobilePrimaryKeys(role),items=roleMenu(role).filter(x=>!keys.includes(x[0]));openModal(`<div class="modal-head"><div><h3>المزيد</h3><p>الأقسام الأقل استخدامًا.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="more-menu-list">${items.map(x=>`<button class="more-menu-item" onclick="closeModal();go('${x[0]}')"><span class="nav-icon">${x[1]}</span><strong>${esc(x[2])}${NAV_PENDING[x[0]]>0?'<span class="alert-dot" aria-label="طلبات معلقة"></span>':''}</strong><span class="more-arrow">‹</span></button>`).join('')}</div>`);}
function appCopyright(){return `<span>© ${new Date().getFullYear()} Islam Sallam. All rights reserved.</span><span>V${esc(APP.ctx?.version||'')}</span>`;}
function activeUnitHeaderHtml(){const entry=(APP.unitChoices||[]).find(x=>x.unit.unitId===APP.activeUnitId);const label='ساكن'+(entry?' | وحدة '+unitNo(entry.unit.unitNumber):'');
 const options=APP.unitChoices||[];if(options.length<2)return esc(label);
 return `<span>${esc(label)}</span> <button type="button" class="btn-sm" onclick="openActiveUnitPicker()" aria-label="تبديل الوحدة" title="تبديل الوحدة">⇄</button>`;
}
function openActiveUnitPicker(){const entries=APP.unitChoices||[];openModal(`<div class="modal-head"><h3>تبديل الوحدة</h3><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><div class="list-stack">${entries.map(x=>`<button type="button" class="btn-sm" style="width:100%;text-align:right;padding:14px" onclick="switchActiveUnit('${esc(x.unit.unitId)}')">${x.unit.unitId===APP.activeUnitId?'✓ ':''}وحدة ${esc(unitNo(x.unit.unitNumber))} · الدور ${esc(floorNo(x.unit.floor))} · ${x.membership.memberRole==='MANAGER'?'مدير':'عضو'}</button>`).join('')}</div>`);}
async function switchActiveUnit(unitId){if(ACTIVE_SAVES>0){toast('انتظر انتهاء الحفظ الجاري قبل تبديل الوحدة.','error');return;}const target=(APP.unitChoices||[]).find(x=>x.unit.unitId===unitId&&x.unit.status==='ACTIVE');if(!target){toast('الوحدة المختارة غير متاحة لهذا الحساب.','error');return;}
 if(unitId===APP.activeUnitId){closeModal();return;}
 closeModal();window.clearServiceWorkspaceSession?.();APP.activeUnitId=unitId;sessionStorage.setItem('tower-active-unit-'+APP.ctx.user.userId,unitId);
 APP.home=null;TRIP_UI.resident=null;clearClientCaches();
 const role=document.querySelector('.greeting-role');if(role)role.innerHTML=activeUnitHeaderHtml();
 await go('home');toast('تم الانتقال إلى الوحدة '+unitNo(target.unit.unitNumber));
}
function shellHtml(){const u=APP.ctx.user,b=APP.ctx.building||{name:'Tower App'},menu=roleMenu(u.role);return `<div class="app-shell"><aside class="sidebar"><div class="brand"><span class="brand-mark"></span><div><strong>${esc(b.name||'Tower App')}</strong><small>Tower App</small></div></div><nav class="nav">${navHtml(menu)}</nav><div class="sidebar-footer"><div class="version-line">${appCopyright()}</div></div></aside><main class="main"><header class="topbar"><div class="account-greeting"><span class="greeting-intro">مرحبًا،</span><strong class="greeting-name">${esc(u.displayName||u.roleLabel)}</strong><span class="greeting-role">${u.role==='RESIDENT'?activeUnitHeaderHtml():esc(u.roleLabel)}</span></div><div class="top-actions"><button class="icon-btn" aria-label="الإعدادات" title="الإعدادات" onclick="go('settings')">⚙</button>${themeButton()}<button class="icon-btn" aria-label="تسجيل الخروج" title="تسجيل الخروج" onclick="logoutApp()"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M14 3h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5"/></svg></button></div></header><div id="content" class="content"></div><footer class="app-global-footer">${appCopyright()}</footer></main><nav class="mobile-nav">${mobileNavHtml(u.role)}</nav></div>`;}
// Remember navigation per authenticated user, only within this browser tab.
const LAST_PAGE_KEY='tower-last-page-v1';
// Route access is independent of sidebar visibility. This is UI routing, not API authorization.
const ROLE_ROUTES=Object.freeze({
 ADMIN:['home','collections','finance','units','unit','people','services','activity','reports','system','settings','admin-registration','admin-pin'],
 UNION:['home','collections','finance','units','unit','people','services','activity','reports','settings','admin-registration','admin-pin'],
 RESIDENT:['home','building','building-fund','account','trips','unit','settings'],
 OPERATOR:['trips','collections','accounts','settings']
});
function allowedPage(key,role){return !!ROLE_ROUTES[role]?.includes(key);}
function navigationDenied(key,role){
 const known=Object.values(ROLE_ROUTES).some(pages=>pages.includes(key));
 const message=known?'هذه الصفحة غير متاحة لهذا الحساب.':'رابط الصفحة غير معروف. حدّث التطبيق أو انسخ تفاصيل الخطأ للدعم.';
 LAST_ERROR_DETAILS='Tower App navigation error\nPage: '+String(key)+'\nRole: '+String(role||'UNKNOWN')+'\nTime: '+new Date().toISOString();
 toast(message,'error');
}

function pageStorageId(){return APP.ctx?.user?.userId||'';}
function rememberedPage(role){
 const fallback=role==='OPERATOR'?'trips':'home';
 try{const record=JSON.parse(sessionStorage.getItem(LAST_PAGE_KEY)||'null');
  if(record?.userId===pageStorageId()&&allowedPage(record.page,role))return record.page;
 }catch(_){}return fallback;
}
function rememberPage(key){try{if(pageStorageId())sessionStorage.setItem(LAST_PAGE_KEY,JSON.stringify({userId:pageStorageId(),page:key}));}catch(_){}}
// Telegram links only request a known client route; every actual data fetch remains
// protected by the existing Worker/SQL role authorization.
function consumeTelegramPage(role){
 try{
  const url=new URL(location.href),target=url.searchParams.get('view');
  if(!target)return null;
  url.searchParams.delete('view');
  history.replaceState(null,'',url.pathname+url.search+url.hash);
  return allowedPage(target,role)?target:null;
 }catch{return null;}
}
async function enterApp(){if(APP.ctx?.user?.role==='RESIDENT'){
  const initial=await run('getMyUnitGovernance');const entries=(initial.units||[]).filter(x=>x.unit.status==='ACTIVE');
  APP.unitChoices=entries;
  const saved=sessionStorage.getItem('tower-active-unit-'+APP.ctx.user.userId);
  const selected=entries.find(x=>x.unit.unitId===saved)||entries.find(x=>x.membership.memberRole==='MANAGER')||entries[0];
  APP.activeUnitId=selected?.unit.unitId||'';
 }const first=consumeTelegramPage(APP.ctx.user.role)||rememberedPage(APP.ctx.user.role);APP.page=first;updateDocumentTitle();showRoot(shellHtml());hydratePageCache();bindPageCacheObserver();await go(first);refreshPendingNav().catch(()=>{});scheduleRolePrefetch();if(APP.ctx.user.role==='RESIDENT')setTimeout(()=>checkWelcomeWizard(),350);setTimeout(()=>tryAutoDailyPdf(),1200);}
async function refreshPendingNav(){
 const role=APP.ctx?.user?.role;if(!['ADMIN','UNION'].includes(role))return;
 const work=[run('listServiceSubscriptionRequests')];if(role==='ADMIN')work.push(run('listMemberRequests'));
 const answers=await Promise.allSettled(work);
 if(APP.ctx?.user?.role!==role)return;
 if(answers[0].status==='fulfilled')NAV_PENDING.services=(Array.isArray(answers[0].value)?answers[0].value:[]).filter(x=>x.status==='PENDING').length;
 if(role==='ADMIN'&&answers[1]?.status==='fulfilled')NAV_PENDING.people=(Array.isArray(answers[1].value)?answers[1].value:[]).filter(x=>x.status==='PENDING').length;
 document.querySelectorAll('.nav-btn.nav-people,.nav-btn.nav-services').forEach(el=>{const key=el.classList.contains('nav-people')?'people':'services';el.classList.toggle('pending-alert',NAV_PENDING[key]>0);});
 document.querySelectorAll('.nav-btn.nav-more').forEach(el=>el.classList.toggle('pending-alert',mobileMoreHasPending(role)));
}
function mobileMoreHasPending(role){return roleMenu(role).some(x=>!mobilePrimaryKeys(role).includes(x[0])&&NAV_PENDING[x[0]]>0);}
function syncNav(){document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));document.querySelectorAll('.nav-'+APP.page).forEach(b=>b.classList.add('active'));refreshMobileNav();}
window.addEventListener('popstate',event=>{
 const state=event.state||{};
 const expectedDepth=Number(state.towerModalDepth|| (state.towerModal?1:0));
 while(towerModalDepth()>expectedDepth){const before=towerModalDepth();closeModal(true);if(towerModalDepth()===before)return;}
 if(state.towerPage&&state.towerPage!==APP.page&&APP.ctx?.user){go(state.towerPage,true).catch(e=>console.warn('Navigation restore',e));}else if(state.towerPage==='services'&&state.towerTab&&state.towerTab!==TOWER_SERVICE_TAB){towerSelectServiceTab(state.towerTab,true);}
});
async function go(key,fromHistory=false){const role=APP.ctx?.user?.role;if(role==='ADMIN'&&key==='system')key='settings';if(!allowedPage(key,role)){navigationDenied(key,role);return;}if(!fromHistory&&history.state?.towerPage!==key)history.pushState({towerPage:key,towerModal:false},'', '#'+encodeURIComponent(key));const navStart=performance.now();if(APP.page!==key)cacheCurrentPage();APP.page=key;rememberPage(key);syncNav();updateDocumentTitle();if(['people','services'].includes(key))refreshPendingNav().catch(()=>{});const titles={home:'الرئيسية',units:'الوحدات',unit:'الوحدة',building:'العمارة',people:'الأعضاء',activity:'النشاط',settings:'الإعدادات',finance:'المالية',services:'الخدمات',account:'الحساب',trips:'المشاوير',accounts:'الحسابات',reports:'التقارير',system:'الإعدادات',collections:'التحصيل'};const pt=$('pageTitle');if(pt)pt.textContent=titles[key]||'Tower App';if(key==='home'){await renderHome();return;}if(key==='settings'){if(role==='ADMIN')await renderAdminCombined();else await renderSettings();return;}if(key==='units'||key==='unit'){await renderUnits();return;}if(key==='people'){await renderPeople();return;}if(key==='building'&&APP.ctx.user.role==='RESIDENT'){await renderResidentBuilding();return;}if(key==='building-fund'&&APP.ctx.user.role==='RESIDENT'){await renderResidentBuildingFund();return;}if(key==='account'&&APP.ctx.user.role==='RESIDENT'){await renderResidentAccount();return;}if(key==='trips'&&APP.ctx.user.role==='RESIDENT'){await renderResidentTripsPage();return;}if(key==='trips'&&APP.ctx.user.role==='OPERATOR'){await renderGuardTrips();return;}if(key==='accounts'&&APP.ctx.user.role==='OPERATOR'){await renderGuardAccounts();return;}if(key==='services'){await renderServices();return;}if(key==='finance'&&['ADMIN','UNION'].includes(APP.ctx.user.role)){await renderFinance();return;}if(key==='collections'&&['ADMIN','UNION','OPERATOR'].includes(APP.ctx.user.role)){await renderCollections();return;}if(key==='activity'&&['ADMIN','UNION'].includes(APP.ctx.user.role)){await renderActivity();return;}if(key==='reports'){await renderReports();return;}if(key==='system'&&APP.ctx.user.role==='ADMIN'){await renderSystemAdmin();return;}if(key==='admin-registration'&&['ADMIN','UNION'].includes(APP.ctx.user.role)){await renderAdminRequests('registration');return;}if(key==='admin-pin'&&['ADMIN','UNION'].includes(APP.ctx.user.role)){await renderAdminRequests('pin');return;}renderPlanned(key,titles[key]||key);perfRecord('nav',key,performance.now()-navStart);}
// Shared, accessible quick-action tile. The callback is authored by the application, never by API data.
const ACTION_ICON_PATHS={
 copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
 printer:'<path d="M6 9V3h12v6M6 18H4V9h16v9h-2"/><path d="M6 14h12v7H6z"/>',
 share:'<circle cx="18" cy="5" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="19" r="2"/><path d="m8 11 8-5M8 13l8 5"/>',
 attachment:'<path d="m21 11.5-8.7 8.7a6 6 0 0 1-8.5-8.5l9-9a4 4 0 0 1 5.7 5.7l-9 9a2 2 0 0 1-2.8-2.8l8-8"/>',
 palette:'<circle cx="12" cy="12" r="9"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7" r="1"/><circle cx="16" cy="9" r="1"/><path d="M14 15c-1.5-2.5 3.5-3.5 4.5-1S16 19 14 15Z"/>',
 shield:'<path d="M12 2 4 5v6c0 5 3.2 8.7 8 11 4.8-2.3 8-6 8-11V5z"/><path d="m9 12 2 2 4-4"/>',
 bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
 account:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-5 3-7 8-7s8 2 8 7"/>',
 wrench:'<path d="M14 7a5 5 0 0 0-6 6l-6 6 3 3 6-6a5 5 0 0 0 6-6l-3 3-3-3z"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="m4 12 4 4 5-6M12 12l4 4 5-6"/>',
 wallet:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M15 15h3"/>',
 settings:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="17" r="2"/>',
 building:'<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 7h2M14 7h2M9 11h2M14 11h2M10 21v-5h4v5"/>',
 users:'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5"/>',
 report:'<path d="M7 3h7l4 4v14H7zM14 3v5h4M10 12h5M10 16h5"/>',
 activity:'<path d="M3 12h4l3-7 4 14 3-7h4"/>',
 collections:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M8 15h8"/>',
 services:'<path d="M4 9h16M4 15h16M9 4v16M15 4v16"/>',
 trips:'<path d="m3 17 5-5 4 4 9-9M16 7h5v5"/>',
 expense:'<path d="M5 12h14"/>',
 receipt:'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6"/>'
};
function actionIcon(name){return `<svg class="tower-action-svg" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ACTION_ICON_PATHS[name]||ACTION_ICON_PATHS.report}</svg>`;}
function actionTile(icon,label,description,handler,primary=false,disabled=false){
 return `<button type="button" class="tower-action-tile ${primary?'is-primary':''}" ${disabled?'disabled aria-disabled="true"':''} onclick="${handler}"><span class="tower-action-glyph">${actionIcon(icon)}</span><span class="tower-action-label">${esc(label)}</span>${description?`<small class="tower-action-description">${esc(description)}</small>`:''}</button>`;
}
const HOME_ACTION_ICONS={home:'building',units:'building',unit:'building',people:'users',activity:'activity',services:'services',reports:'report',finance:'wallet',accounts:'wallet',trips:'trips',collections:'collections'};
function homeAction(_icon,title,text,key,primary){return actionTile(HOME_ACTION_ICONS[key]||'report',title,text,`go('${key}')`,primary);}
function homeMetric(label,value,kind,target=''){const iconMap={'رصيد الصندوق':'wallet','المطلوب':'receipt','المحصل':'collections','المصروفات':'expense','المتأخرات':'activity','المشاوير المفتوحة':'trips','الوحدات':'building','المستخدمون':'users','طلبات العضوية':'users','طلبات الخدمات':'services'};const glyph=iconMap[label]?`<span class="home-metric-glyph" aria-hidden="true">${actionIcon(iconMap[label])}</span>`:'';const inner=`<span>${esc(label)}</span><strong>${value}</strong>`;const tab=target.startsWith('finance:')?target.split(':')[1]:'';const click=tab?`openFinanceSummaryTab('${tab}')`:`go('${target}')`;return target?`<button type="button" class="home-metric home-metric-action ${kind||''}" onclick="${click}" aria-label="فتح ${esc(label)}">${glyph}${inner}</button>`:`<div class="home-metric ${kind||''}">${glyph}${inner}</div>`;}
async function openFinanceSummaryTab(tab){await go('finance');if(!FIN_UI.data||!document.getElementById('financeBody'))return;setFinanceTab(tab);}
function homeAttention(title,text,key){return `<button class="attention-card" onclick="go('${key}')"><span class="attention-dot"></span><span><strong>${esc(title)}</strong><small>${esc(text)}</small></span><span class="home-action-arrow">‹</span></button>`;}
async function openUnionFinanceAction(kind){try{if(!FIN_UI.data)FIN_UI.data=await run('getFinanceContext');if(!FIN_UI.categories.length)try{FIN_UI.categories=await run('listCollectionCategories',true);}catch(_){}if(kind==='charge')openChargeModal();else if(kind==='payment')openBuildingPaymentModal();else if(kind==='expense')openFinanceModal('EXPENSE');else if(kind==='deposit')openFinanceModal('INCOME');}catch(e){toast(errText(e),'error');}}
function adminRequestCard(title,count,target){return `<button class="stat admin-action-stat" onclick="go('${target}')" aria-label="فتح ${esc(title)}"><span>${esc(title)}</span><strong>${count===null?'—':count}</strong><span>فتح الطلبات ←</span></button>`;}
async function renderHome(){$('content').innerHTML=pageLoading('جاري تجهيز الصفحة الرئيسية…');try{APP.home=await run('getCoreHomeData');const h=APP.home,u=APP.ctx.user;if(u.role==='RESIDENT'&&APP.activeUnitId){const x=(APP.unitChoices||[]).find(z=>z.unit.unitId===APP.activeUnitId);if(x)h.membership=x.membership;}let html='';if(u.role==='RESIDENT'&&h.membership?.unitId){try{h.account=await run('getResidentAccountData');}catch(err){h.account=null;h.accountError=err;}}
if(u.role==='OPERATOR'){try{const c=await run('getGuardTripContext');h.openTripCount=Array.isArray(c?.trips)?c.trips.length:null;}catch(err){h.openTripCount=null;h.tripCountError=err;}}
if(u.role==='RESIDENT'&&h.membership?.unitId){try{h.buildingStatement=await run('getResidentDuesPage',{mode:'summary'});}catch(err){h.buildingStatementError=err;}}
if(u.role==='RESIDENT'&&h.membership?.unitId){try{const visibility=await run('getUnitFundVisibility',APP.activeUnitId);h.unionFundVisible=visibility?.canViewFund===true;if(h.unionFundVisible)h.fundOverview=await run('getResidentBuildingFundSummary',APP.activeUnitId);}catch(err){h.fundOverviewError=err;h.unionFundVisible=false;}}
 const mayViewUnionFund=h.unionFundVisible===true;
if(u.role==='OPERATOR'){html+=`<section class="home-focus"><div class="focus-copy"><span>المهمة الأساسية</span><h3>سجّل المشتريات بسرعة</h3><p>اختَر الوحدة، أضف البنود والأسعار، واحفظ المشوار.</p></div>${actionTile('plus','مشوار جديد','','go(\'trips\')',true)}</section>${h.tripCountError?`<p class="resident-building-empty">تعذر تحميل عدد المشاوير المفتوحة؛ افتح المشاوير للمحاولة مجددًا.</p>`:''}<div class="home-metrics">${homeMetric('المشاوير المفتوحة',h.openTripCount==null?'—':String(Number(h.openTripCount)),Number(h.openTripCount)>0?'attention':'','trips')}${homeMetric('الوحدات',String(Number(h.unitCount||0)),'','units')}</div><section class="panel home-section"><div class="panel-head"><div><h3>الوصول السريع</h3><p>كل ما تحتاجه في أقل عدد من الخطوات.</p></div></div><div class="home-actions">${homeAction('▤','الحسابات التشغيلية','إجمالي المشتريات المفتوحة لكل وحدة','accounts',false)}${homeAction('▤','التقارير','تقارير المشتريات المسموح بها','reports',false)}</div></section>`;}
else if(u.role==='RESIDENT'){
 const statement=h.buildingStatement||null;
 const due=statement?.totalDue==null?null:Number(statement.totalDue);
 const rows=(statement?.rows||[]).filter(r=>Number(r.remaining||0)>0).slice(0,3);
 const a=h.account,open=a?.openTripCount==null?null:Number(a.openTripCount),credit=a?.creditBalance==null?null:Number(a.creditBalance),guardDue=a?.dueTotal==null?null:Number(a.dueTotal);
 const manager=Boolean(a&&(a.canManageAccount||h.membership?.memberRole==='MANAGER'));
 if(a)TRIP_UI.resident=a;
 const settlements=Array.isArray(a?.settlements)?a.settlements:[];
 const lastSettlement=settlements.length?('#'+String(Math.max(...settlements.map(z=>Number(z.sequenceNo)||0))).padStart(3,'0')):'—';
 const buildingAlerts=(h.notifications||[]).filter(n=>n.status==='UNREAD'&&['BUILDING_CHARGE','BUILDING_PAYMENT'].includes(n.entity)).slice(0,2);
 html+=`<div class="resident-home-v247 resident-dashboard-256" dir="rtl">
 <section class="resident-home-heading"><h2>ملخص حساباتي</h2><p>حساب العمارة وحساب الحارس مستقلان، وبنفس الأهمية.</p></section>
 <div class="resident-account-pair">
  <section class="resident-account-panel resident-clickable-panel" role="link" tabindex="0" onclick="if(!event.target.closest('button,a,input,select,textarea'))go('building')" onkeydown="if((event.key==='Enter'||event.key===' ')&&event.target===this){event.preventDefault();go('building')}" aria-label="حساب العمارة — افتح كشف العمارة">
   <div class="resident-account-panel-heading"><span class="resident-account-symbol" aria-hidden="true">${actionIcon('building')}</span><h3>حساب العمارة</h3></div>
   <div class="resident-account-primary"><span>المستحقات غير المسددة</span><strong class="resident-money">${due===null?'—':money(due)}</strong></div>
   ${due===null?'<p class="resident-building-empty">تعذر تحميل حساب العمارة.</p>':''}
   <div class="resident-account-details"><div><span>آخر مستحقات</span><strong>${!statement?'—':rows.length?String(rows.length)+' معروضة':'لا توجد'}</strong></div><div><span>تفاصيل السداد</span><strong>في كشف العمارة</strong></div></div>
   <div class="resident-account-buttons"><button type="button" class="btn-sm primary" onclick="go('building')">${actionIcon('receipt')} كشف العمارة</button>${mayViewUnionFund?`<button type="button" class="btn-sm" onclick="go('building-fund')">${actionIcon('wallet')} صندوق العمارة</button>`:""}</div>
  </section>
  <section class="resident-account-panel resident-clickable-panel" role="link" tabindex="0" onclick="if(!event.target.closest('button,a,input,select,textarea'))go('trips')" onkeydown="if((event.key==='Enter'||event.key===' ')&&event.target===this){event.preventDefault();go('trips')}" aria-label="حساب الحارس — افتح المشاوير">
   <div class="resident-account-panel-heading"><span class="resident-account-symbol" aria-hidden="true">${actionIcon('trips')}</span><h3>حساب الحارس</h3></div>
   <div class="resident-account-primary"><span>المستحق للحارس</span><strong class="resident-money">${guardDue===null?'—':money(guardDue)}</strong></div>
   ${h.accountError?'<p class="resident-building-empty">تعذر تحميل حساب المشاوير.</p>':''}
   <div class="resident-account-details"><div><span>رصيد دائن</span><strong class="resident-money">${credit===null?'—':money(credit)}</strong></div><div><span>مشاوير مفتوحة</span><strong>${open===null?'—':open}</strong></div><div><span>آخر تسوية</span><strong>${a?lastSettlement:'—'}</strong></div></div>
   <div class="resident-account-buttons"><button type="button" class="btn-sm primary" onclick="openResidentTripFromHome()">${actionIcon('plus')} + مشوار</button><button type="button" class="btn-sm" onclick="go('account')">${actionIcon('receipt')} الحساب والتسويات</button>${manager?`<button type="button" class="btn-sm" ${open?'':'disabled'} onclick="closeSettlement()">${actionIcon('check')} اعتماد التسوية</button><button type="button" class="btn-sm" onclick="openTripSettings()">${actionIcon('services')} إعدادات المشاوير</button>`:''}</div>
  </section>
 </div>
 ${buildingAlerts.length?`<section class="panel resident-building-alerts"><div class="panel-head"><div><h3>تنبيهات العمارة</h3></div></div><div class="list-stack">${buildingAlerts.map(n=>`<button class="attention-card" onclick="readNotice('${esc(n.notificationId)}')"><span class="attention-dot"></span><span><strong>${esc(n.title)}</strong><small>${esc(n.body||'')}</small></span></button>`).join('')}</div></section>`:''}
 <section class="panel resident-building-recent"><div class="panel-head"><div><h3>آخر المستحقات</h3><p>عرض مختصر، والتفاصيل الكاملة في كشف العمارة.</p></div><button class="btn-sm" onclick="go('building')">عرض الكل ‹</button></div>
 ${!statement?`<p class="resident-building-empty">بيانات المستحقات غير متاحة حاليًا.</p>`:rows.length?`<div class="resident-recent-list">${rows.map(r=>`<button class="resident-recent-row" onclick="go('building')"><span><strong>${esc(r.title||'استحقاق')}</strong><small>${esc(r.dueDate||r.category||'')}</small></span><b class="resident-money">${money(r.remaining)}</b></button>`).join('')}</div>`:`<p class="resident-building-empty">لا توجد مستحقات غير مسددة حاليًا.</p>`}</section>
 ${mayViewUnionFund?renderResidentFundHomeCard(h.fundOverview,h.fundOverviewError):''}
 <section class="panel resident-home-actions"><div class="panel-head"><div><h3>الخدمات والوحدة</h3></div></div><div class="resident-home-action-grid">${actionTile('services','الخدمات والوحدة','','go(\'unit\')')}</div></section>
 </div>`;
}
else if(u.role==='ADMIN'){let adminReg=null,adminPin=null;try{const ar=await Promise.allSettled([run('adminListRegistrationRequests'),run('adminListPinResetRequests')]);if(ar[0].status==='fulfilled')adminReg=(ar[0].value||[]).filter(x=>x.status==='PENDING').length;if(ar[1].status==='fulfilled')adminPin=(ar[1].value||[]).filter(x=>['PENDING','ISSUED'].includes(x.status)).length;}catch(_){}let pendingServices=null,pendingMembers=null;try{const q=await run('listServiceSubscriptionRequests');pendingServices=(q||[]).filter(x=>x.status==='PENDING').length;}catch(_){}try{const req=await run('listMemberRequests');pendingMembers=(req||[]).filter(x=>x.status==='PENDING').length;}catch(_){}html+=`<section class="dashboard-hero admin-dashboard-hero"><div><span class="dashboard-eyebrow">مركز الإدارة</span><h2>ملخص إدارة النظام</h2><p>ابدأ بالطلبات التي تحتاج قرارًا، ثم انتقل لإدارة الحسابات والإعدادات.</p></div><button class="btn-sm dashboard-hero-link" onclick="go('system')">${actionIcon('activity')} مركز فحص النظام</button></section><div class="home-metrics admin-metrics">${adminRequestCard('طلبات التسجيل والتفعيل',adminReg,'admin-registration')}${adminRequestCard('طلبات استرجاع PIN',adminPin,'admin-pin')}${homeMetric('طلبات العضوية',pendingMembers===null?'—':String(pendingMembers),pendingMembers>0?'attention':'','people')}${homeMetric('طلبات الخدمات',pendingServices===null?'—':String(pendingServices),pendingServices>0?'attention':'','services')}${homeMetric('الوحدات',String(Number(h.unitCount||0)),'','units')}${homeMetric('الأعضاء',String(Number(h.userCount||0)),'','people')}</div>${(pendingMembers>0||pendingServices>0)?`<section class="home-attention"><div class="section-title"><h3>تحتاج مراجعتك</h3><span>${(pendingMembers||0)+(pendingServices||0)}</span></div>${pendingMembers?homeAttention(`${pendingMembers} طلب عضوية`,'طلبات انضمام تنتظر المراجعة.','people'):''}${pendingServices?homeAttention(`${pendingServices} طلب خدمة`,'اشتراكات خدمات تنتظر القرار.','services'):''}</section>`:(pendingMembers===null||pendingServices===null||adminReg===null||adminPin===null)?`<section class="home-all-clear"><strong>تعذر التحقق من بعض الطلبات</strong><span>راجع شاشات الطلبات، أو حدّث الصفحة. الأعداد غير المتاحة تظهر بعلامة —.</span></section>`:`<section class="home-all-clear"><strong>لا توجد طلبات معلقة الآن ✓</strong><span>يمكنك متابعة إدارة البرج من الاختصارات بالأسفل.</span></section>`}<section class="panel home-section"><div class="panel-head"><div><h3>مهام الإدارة</h3><p>اختصارات بأيقونات موحدة لكل المهام اليومية.</p></div></div><div class="home-actions">${homeAction('▦','الوحدات','إدارة الوحدات والمديرين والأعضاء','units',true)}${homeAction('♙','الأعضاء','الحسابات وطلبات العضوية','people',false)}${homeAction('◇','الخدمات','الخدمات وطلبات الاشتراك','services',false)}${homeAction('◴','النشاط','مراجعة آخر العمليات','activity',false)}${homeAction('▤','التقارير','عرض التقارير والإحصائيات','reports',false)}${homeAction('⌘','الإعدادات','الفحص والعمليات الحساسة','system',false)}</div></section><section class="panel dashboard-sensitive"><div class="panel-head"><div><h3>${actionIcon('settings')} إعدادات وعمليات حساسة</h3><p>التصفير التشغيلي وتغيير إعدادات النظام متاحان داخل الإعدادات فقط، مع المعاينة والتأكيد الحاليين.</p></div><button class="btn-sm" onclick="go('system')">فتح الإعدادات</button></div></section>`;}
else if(u.role==='UNION'){let fin=null,pendingServices=null,pendingRegistrations=null,pendingMembers=null;try{const r=await Promise.allSettled([run('getFinanceDashboard'),run('listServiceSubscriptionRequests'),run('adminListRegistrationRequests'),run('listMemberRequests')]);if(r[0].status==='fulfilled')fin=r[0].value||null;if(r[1].status==='fulfilled')pendingServices=(r[1].value||[]).filter(x=>x.status==='PENDING').length;if(r[2].status==='fulfilled')pendingRegistrations=(r[2].value||[]).filter(x=>x.status==='PENDING').length;if(r[3].status==='fulfilled')pendingMembers=(r[3].value||[]).filter(x=>x.status==='PENDING').length;}catch(_){ }html+=`<section class="dashboard-hero union-dashboard-hero"><div><span class="dashboard-eyebrow">لوحة الاتحاد</span><h2>الصندوق والتحصيل</h2><p>حالة العمارة المالية والإجراءات المطلوبة في مكان واحد.</p></div><button class="btn-sm dashboard-hero-link" onclick="go('finance')">${actionIcon('wallet')} فتح المالية</button></section><div class="home-metrics admin-metrics">${adminRequestCard('طلبات التسجيل والتفعيل',pendingRegistrations,'admin-registration')}${homeMetric('طلبات العضوية',pendingMembers===null?'—':String(pendingMembers),pendingMembers>0?'attention':'','people')}${homeMetric('طلبات الخدمات',pendingServices===null?'—':String(pendingServices),pendingServices>0?'attention':'','services')}</div>${!fin?`<p class="resident-building-empty">تعذر تحميل بيانات الصندوق من الخادم. القيم غير متاحة وليست صفرًا.</p>`:''}<div class="home-metrics admin-metrics union-finance-metrics">${homeMetric('رصيد الصندوق',(fin?.balance==null?'—':money(fin.balance)),'positive fund-featured','finance:fund')}${homeMetric('المطلوب',(fin?.outstandingTotal==null?'—':money(fin.outstandingTotal)),Number(fin?.outstandingTotal)>0?'attention':'','finance:charges')}${homeMetric('المحصل',(fin?.incomeTotal==null?'—':money(fin.incomeTotal)),'','finance:payments')}${homeMetric('المصروفات',(fin?.expenseTotal==null?'—':money(fin.expenseTotal)),'','finance:fund')}${homeMetric('المتأخرات',(fin?.arrearsTotal==null?'—':money(fin.arrearsTotal)),Number(fin?.arrearsTotal)>0?'attention':'','finance:arrears')}</div>${pendingServices?`<section class="home-attention"><div class="section-title"><h3>يحتاج مراجعتك</h3></div>${homeAttention(`${pendingServices} طلب خدمة`,`طلبات اشتراك تنتظر المراجعة.`,'services')}</section>`:''}<section class="panel home-section"><div class="panel-head"><div><h3>إجراءات مالية</h3><p>التحصيل والدفعات والإيرادات والمصروفات بأيقونات واضحة.</p></div></div><div class="home-actions">${actionTile('plus','تحصيل جديد','إنشاء استحقاق وتوزيعه على الوحدات',"openUnionFinanceAction('charge')",true)}${actionTile('check','تسجيل دفعة','سداد استحقاق كامل أو جزئي',"openUnionFinanceAction('payment')",false)}${actionTile('expense','مصروف','تسجيل مصروف من الصندوق',"openUnionFinanceAction('expense')",false)}${actionTile('wallet','إيداع','إضافة حركة للصندوق',"openUnionFinanceAction('deposit')",false)}${homeAction('◉','تقارير التحصيل','مراجعة التحصيل الميداني واعتماده','collections',false)}${homeAction('▦','الوحدات','إدارة الوحدات والمديرين والأعضاء','units',false)}</div></section><section class="panel home-section"><div class="panel-head"><div><h3>آخر حركات الصندوق</h3><p>آخر ما دخل أو خرج من الصندوق، وليس حساب الحارس.</p></div></div>${typeof fundList==='function'?fundList((fin?.entries||[]).slice(0,8)):''}</section>`;}
const notes=(h.notifications||[]).filter(n=>n.status==='UNREAD'&&(u.role!=='RESIDENT'||!['BUILDING_CHARGE','BUILDING_PAYMENT'].includes(n.entity)));if(notes.length)html+=`<section class="panel home-section"><div class="panel-head"><div><h3>إشعارات جديدة</h3><p>آخر التحديثات المرتبطة بحسابك.</p></div><span class="badge">${notes.length}</span></div><div class="list-stack">${notes.map(n=>`<button class="attention-card" onclick="readNotice('${esc(n.notificationId)}')"><span class="attention-dot"></span><span><strong>${esc(n.title)}</strong><small>${esc(n.body||'')}</small></span></button>`).join('')}</div></section>`;$('content').innerHTML=html;}catch(e){$('content').innerHTML=errorCard(e);}}
async function readNotice(id){try{const n=(APP.home&&APP.home.notifications||[]).find(x=>x.notificationId===id);await run('markNotificationRead',id);if(n&&['BUILDING_CHARGE','BUILDING_PAYMENT'].includes(n.entity)){await go('building');return;}if(n&&APP.ctx?.user?.role==='ADMIN'&&(/MEMBER|UNIT_MEMBER|MEMBERSHIP|عضو|عضوية|إضافة عضو/i.test(String(n.entity||'')+' '+String(n.title||'')))){await openPeopleMemberRequests(n.entityId||n.entity_id||n.requestId||'');return;}await renderHome();}catch(e){toast(errText(e),'error');}}
async function renderSettings(){const u=APP.ctx.user;let trip='',adminUi='';if(u.role==='ADMIN'){try{const p=await run('getUiPreferences');window.UI_PREFS=p;adminUi=`<section class="panel"><div class="panel-head"><div><h3>فونتات النظام</h3><p>تحكم مركزي في أحجام الخط للموبايل والديسكتوب.</p></div><button class="btn-sm" onclick="openUiPreferencesModal()">تعديل</button></div><div class="feature-grid"><article><strong>${esc(p.fontFamily)}</strong><span>الخط</span></article><article><strong>${esc(p.desktopBody)}px</strong><span>Desktop · النص</span></article><article><strong>${esc(p.mobileBody)}px</strong><span>Mobile · النص</span></article><article><strong>${esc(p.desktopTitle)} / ${esc(p.mobileTitle)}px</strong><span>العناوين</span></article></div></section>`;}catch(_){adminUi='';}}if(u.role==='RESIDENT'){trip+=`<section class="panel"><div class="panel-head"><div><h3>معالج الترحيب</h3><p>راجع خطوات إعداد الوحدة وTelegram في أي وقت.</p></div><button class="btn-sm" onclick="openWelcomeWizard(0)">فتح المعالج</button></div></section>`;try{const st=await run('getMyTripSettings');trip+=`<section class="panel"><div class="panel-head"><div><h3>أتعاب المشاوير الافتراضية</h3><p>حدّد أتعاب كل مسافة، ويمكنك تغيير المسافة لكل مشوار لتُضاف الأتعاب تلقائيًا إلى قيمة المشتريات.</p></div><button class="btn-sm" onclick="openTripSettingsFromSettings()">تعديل</button></div><div class="feature-grid"><button type="button" class="trip-fee-shortcut" onclick="openTripSettingsFromSettings('feeNear')" aria-label="تعديل أتعاب المسافة القريبة"><strong>${money(st.feeNear)}</strong><span>قريب · اضغط للتعديل</span></button><button type="button" class="trip-fee-shortcut" onclick="openTripSettingsFromSettings('feeMedium')" aria-label="تعديل أتعاب المسافة المتوسطة"><strong>${money(st.feeMedium)}</strong><span>متوسط · اضغط للتعديل</span></button><button type="button" class="trip-fee-shortcut" onclick="openTripSettingsFromSettings('feeFar')" aria-label="تعديل أتعاب المسافة البعيدة"><strong>${money(st.feeFar)}</strong><span>بعيد · اضغط للتعديل</span></button><button type="button" class="trip-fee-shortcut" onclick="openTripSettingsFromSettings('defaultDistance')" aria-label="تعديل المسافة الافتراضية"><strong>${esc(({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[st.defaultDistance]||st.defaultDistance)}</strong><span>الافتراضي · اضغط للتعديل</span></button></div></section>`;window.SETTINGS_TRIP=st;}catch(e){trip='';}}$('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الحساب والمظهر</h3><p>إعدادات الحساب الحالية.</p></div></div><div class="settings-list"><div class="setting-row"><div><strong>${esc(u.displayName)}</strong><span>${esc(u.roleLabel)} · ${ltrId(u.loginId)}</span></div><span class="badge">الحساب الحالي</span></div><div class="setting-row"><div><strong>مظهر التطبيق</strong><span>الوضع الفاتح أو الداكن.</span></div><button class="btn-sm" onclick="toggleTheme();renderSettings()">${APP.theme==='dark'?'الوضع الفاتح':'الوضع الداكن'}</button></div><div class="setting-row"><div><strong>الاسم واللقب</strong><span>اللقب المختار يظهر مع الاسم في النظام.</span></div><button class="btn-sm" onclick="openProfileModal()">تعديل</button></div><div class="setting-row"><div><strong>بيانات الاتصال</strong><span>الموبايل: ${esc(u.phone||'غير مسجل')} · الإيميل: ${esc(u.email||'غير مسجل')}</span></div><button class="btn-sm" onclick="openContactsModal()">تعديل</button></div><div class="setting-row"><div><strong>PIN</strong><span>تغييره يلغي الجلسات الحالية.</span></div><button class="btn-sm" onclick="openChangePinModal()">تغيير PIN</button></div></div></section>${adminUi}${u.role==='ADMIN'?`<section class="panel" id="healthAlertSettings"><div class="panel-head"><div><h3>مراقبة Supabase وتنبيهات تليجرام</h3><p>إيقاف التنبيهات لا يوقف فحص اتصال النظام.</p></div></div><div id="healthAlertBody">جاري تحميل الإعدادات…</div></section>`:''}${trip}<section class="panel" id="telegramSettings"><div class="panel-head"><div><h3>إشعارات Telegram</h3><p>ربط شخصي آمن، ويمكنك إظهار المبالغ أو إخفاؤها من إعدادات حسابك.</p></div></div><div id="telegramSettingsBody">جاري تحميل حالة الربط…</div></section>`;loadTelegramSettings();if(u.role==='ADMIN')loadHealthAlertSettings();}
// Unified administrator workspace: one index, no duplicate fixed legacy navigation.
const HEALTH_ALERT_BOOL_KEYS=['alertsEnabled','failure','recovery','reminder','dailyOk'];
async function loadHealthAlertSettings(){const host=$('healthAlertBody');if(!host)return;try{const result=await run('adminGetHealthAlertSettings');const pref=result.settings||{};window.TOWER_HEALTH_PREFS=pref;host.innerHTML=`<div class="settings-list"><div class="setting-row"><div><strong>مراقبة الاتصال</strong><span>${result.monitorEnabled?'تعمل تلقائيًا في Cloudflare':'غير مفعّلة في Cloudflare'} · المستلم ${result.hasRecipient?'مُعدّ':'غير مُعدّ'}</span></div><span class="badge">الفحص مستقل عن التنبيهات</span></div>${[['alertsEnabled','تفعيل كل تنبيهات تليجرام'],['failure','التنبيه عند اكتشاف عطل'],['recovery','التنبيه عند عودة الاتصال'],['reminder','تذكير عند استمرار العطل'],['dailyOk','تقرير نجاح يومي']].map(([k,label])=>`<label class="setting-row health-pref-row"><span>${label}</span><input type="checkbox" data-health-pref="${k}" ${pref[k]?'checked':''}></label>`).join('')}<label class="setting-row"><span>تكرار تذكير العطل</span><select id="healthReminderHours" class="input">${[6,12,24,48].map(n=>`<option value="${n}" ${Number(pref.reminderHours)===n?'selected':''}>كل ${n} ساعة</option>`).join('')}</select></label><div class="setting-row"><span>الإعدادات محفوظة في Cloudflare KV، ولا تشمل معرّف المحادثة أو أي أسرار.</span><button class="btn-sm primary" onclick="saveHealthAlertSettings()">حفظ اختيارات التنبيه</button></div></div>`;const globalSwitch=host.querySelector('[data-health-pref="alertsEnabled"]');const update=()=>{const enabled=globalSwitch.checked;host.querySelectorAll('[data-health-pref]').forEach(x=>{if(x!==globalSwitch)x.disabled=!enabled});host.querySelector('#healthReminderHours').disabled=!enabled||!host.querySelector('[data-health-pref="reminder"]').checked};host.querySelectorAll('input[data-health-pref]').forEach(x=>x.addEventListener('change',update));update();}catch(e){host.textContent='تعذر تحميل إعدادات مراقبة النظام: '+errText(e);}}
async function saveHealthAlertSettings(){const host=$('healthAlertBody');if(!host)return;const settings={};for(const key of HEALTH_ALERT_BOOL_KEYS)settings[key]=!!host.querySelector(`[data-health-pref="${key}"]`)?.checked;settings.reminderHours=Number(host.querySelector('#healthReminderHours')?.value||24);try{await run('adminSaveHealthAlertSettings',settings);toast('تم حفظ إعدادات تنبيهات صحة النظام.','success');await loadHealthAlertSettings();}catch(e){toast(errText(e),'error');}}
async function renderAdminCombined(){
 BRAND_FILE_PREVIEWS.logo=null;BRAND_FILE_PREVIEWS.main=null;BRAND_PENDING_REMOVALS.logo=false;BRAND_PENDING_REMOVALS.main=false;
 const host=$('content');
 await renderSettings();
 const personal=host.innerHTML;
 await renderSystemAdmin();
 if(adminSectionNavCleanup){adminSectionNavCleanup();adminSectionNavCleanup=null;}
 host.querySelector('.admin-section-nav')?.remove();
 host.querySelectorAll('.admin-nav-placeholder').forEach(n=>n.remove());
 const system=host.innerHTML;
 const sections=[
  {id:'brand',label:'هوية النظام',desc:'الاسم والصور والألوان وخطوط النظام',icon:'palette'},
  {id:'security',label:'الأمان والحسابات',desc:'أكواد التفعيل واسترجاع PIN وطلبات المستخدمين',icon:'shield'},
  {id:'alerts',label:'الإشعارات والتقارير',desc:'Telegram والملخص اليومي وتقارير PDF الدورية',icon:'bell'},
  {id:'account',label:'الحساب والمظهر',desc:'بيانات الحساب والمظهر الشخصي',icon:'account'},
  {id:'maintenance',label:'الصيانة والتشخيص',desc:'فحوص النظام والتصفير التشغيلي',icon:'wrench'}
 ];
 host.innerHTML=`<header class="admin-workspace-heading"><div><span class="admin-workspace-eyebrow">مركز التحكم</span><h2>الإعدادات</h2><p>كل إعدادات الإدارة في أقسام واضحة. اختر قسمًا أو ابحث عن الوظيفة المطلوبة.</p></div></header><div class="admin-settings-search"><label for="adminSettingsSearch">ابحث عن إعداد</label><div class="admin-settings-search-row"><input id="adminSettingsSearch" type="search" autocomplete="off" placeholder="مثل: Telegram أو الخطوط أو PIN" oninput="filterAdminSettingsGroups(this.value)"><button class="btn-sm" type="button" onclick="clearAdminSettingsSearch()">مسح</button></div><p id="adminSettingsSearchFeedback" class="muted" role="status" aria-live="polite"></p></div><div class="admin-settings-grid" role="navigation" aria-label="أقسام إعدادات الإدارة">${sections.map(x=>`<button class="admin-settings-tile" onclick="showAdminSettingsGroup('${x.id}')" data-group="${x.id}" aria-controls="settings-group-${x.id}" aria-expanded="false"><span class="admin-settings-icon" aria-hidden="true">${actionIcon(x.icon)}</span><span><strong>${x.label}</strong><small>${x.desc}</small></span><span aria-hidden="true">‹</span></button>`).join('')}</div><div id="adminSettingsGroups">${sections.map(x=>`<section id="settings-group-${x.id}" class="admin-settings-group" hidden><header class="admin-settings-group-head"><h3>${x.label}</h3><button class="btn-sm" onclick="showAdminSettingsGroup(null)">إغلاق القسم</button></header><div id="settings-contents-${x.id}"></div></section>`).join('')}</div>`;
 const temp=document.createElement('div');temp.innerHTML=personal;
 [...temp.children].forEach(node=>{
  const dest=(node.id==='telegramSettings'||node.id==='healthAlertSettings')?'alerts':node.textContent?.includes('فونتات النظام')?'brand':'account';
  host.querySelector('#settings-contents-'+dest).appendChild(node);
 });
 const systemTemp=document.createElement('div');systemTemp.innerHTML=system;
 [...systemTemp.children].forEach(node=>{
  const dest=node.id==='adminBranding'?'brand':node.id==='adminDigestSchedule'?'alerts':'maintenance';
  host.querySelector('#settings-contents-'+dest).appendChild(node);
 });
 const brand=host.querySelector('#settings-contents-brand');
 const brandPanel=brand.querySelector('#adminBranding');
 if(brandPanel){brandPanel.innerHTML=`<div class="panel-head"><div><h3>هوية النظام</h3><p>عدّل الاسم والألوان والصور هنا مباشرة، واحفظها بزر واحد.</p></div></div>`+adminBrandInlineForm();}
 const security=host.querySelector('#settings-contents-security');
 security.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الأمان والحسابات</h3><p>مدد صلاحية أكواد التفعيل واسترجاع PIN، بعيدًا عن هوية النظام.</p></div><button class="btn-sm primary" onclick="openSecuritySettings()">تعديل الأكواد</button></div><div class="settings-list"><div class="setting-row"><div><strong>طلبات التسجيل والتفعيل</strong><span>راجع طلبات الانضمام وقرار مدير الوحدة الاستشاري.</span></div><button class="btn-sm" onclick="go('admin-registration')">فتح الطلبات</button></div><div class="setting-row"><div><strong>طلبات استرجاع PIN</strong><span>إدارة طلبات استرجاع الدخول.</span></div><button class="btn-sm" onclick="go('admin-pin')">فتح الطلبات</button></div></div></section>`;
 const alerts=host.querySelector('#settings-contents-alerts');
 // One coherent workspace: delivery channel, text digest, then scheduled PDF.
 alerts.classList.add('admin-notification-hub');
 const telegramPanel=alerts.querySelector('#telegramSettings');
 if(telegramPanel){telegramPanel.classList.add('admin-telegram-channel');telegramPanel.querySelector('.panel-head h3').textContent='قناة Telegram';}
 const digestPanel=alerts.querySelector('#adminDigestSchedule');
 if(digestPanel)digestPanel.classList.add('admin-digest-channel');
 alerts.insertAdjacentHTML('beforeend',`<section class="panel admin-pdf-channel"><div class="panel-head"><div><h3>تقارير PDF الدورية</h3><p>التكرار ووقت الإرسال، المعاينة والتجربة، ثم سجل المحاولات.</p></div><span class="badge">للإدارة والاتحاد</span></div><div id="adminPdfSettingsBody" class="settings-list"><p class="muted">جارٍ تحميل إعدادات PDF…</p></div><div class="form-actions"><button class="btn-sm" onclick="go('reports')">فتح مكتبة التقارير</button></div></section>`);
 // Open the familiar first section immediately; preserve selection on revisit.
 showAdminSettingsGroup(window.TOWER_ADMIN_SETTINGS_GROUP||'brand',false);
 enableSettingsRowClickability(host);loadTelegramSettings();loadHealthAlertSettings();loadDailyDigestTime();
}
function enableSettingsRowClickability(root=document){
 root.querySelectorAll('#settings-contents-account .setting-row, #settings-contents-security .setting-row').forEach(row=>{
  if(row.dataset.rowClickReady)return;
  const buttons=Array.from(row.querySelectorAll('button[onclick]'));
  if(buttons.length!==1 || row.querySelector('input,select,textarea,a,[role=switch]'))return;
  const button=buttons[0],handler=button.getAttribute('onclick');
  if(!handler || /delete|remove|reset|cancel|unlink|logout|operational/i.test(handler))return;
  row.dataset.rowClickReady='true';row.classList.add('setting-row-clickable');
  row.tabIndex=0;row.setAttribute('role','button');
  row.setAttribute('aria-label',(row.querySelector('strong')?.textContent||'فتح الإعداد').trim());
  row.addEventListener('click',e=>{if(e.target.closest('button,a,input,select,textarea,label'))return;button.click();});
  row.addEventListener('keydown',e=>{if(e.target===row&&(e.key==='Enter'||e.key===' ')){e.preventDefault();button.click();}});
  button.classList.add('setting-row-accessory');button.tabIndex=-1;button.setAttribute('aria-hidden','true');
 });
}
// V2.5.35: enhance single-action cards across all roles without hijacking destructive or multi-action cards.
const SINGLE_ACTION_CARD_SELECTOR='.data-card,.member-line,.setting-row,.trip-card';
function enhanceSingleActionCards(root=document){
 root.querySelectorAll(SINGLE_ACTION_CARD_SELECTOR).forEach(card=>{
  if(card.dataset.singleActionReady || card.matches('.resident-trip-editable,[onclick],[role="button"],.setting-row-clickable'))return;
  if(card.querySelector('input,select,textarea,[contenteditable="true"],a[href],form,[role="switch"]'))return;
  const actions=Array.from(card.querySelectorAll('button[onclick]'));
  if(actions.length!==1)return;
  const action=actions[0];
  const handler=action.getAttribute('onclick')||'';
  const label=String(action.textContent||action.getAttribute('aria-label')||'').trim();
  if(!/^(فتح|عرض|تعديل|تفاصيل|مراجعة|الأعضاء)(?:\s|$)/.test(label))return;
  if(/\b(?:delete|remove|reset|cancel|undo|settle|approve|reject|disable|deactivate|logout|transfer|pay|collect|submit|unlink)\b/i.test(handler))return;
  card.dataset.singleActionReady='true';card.classList.add('tower-single-action-card');
  card.tabIndex=0;card.setAttribute('role','button');
  card.setAttribute('aria-label',label+' — '+String(card.querySelector('strong,h3')?.textContent||'').trim().slice(0,80));
  card.addEventListener('click',event=>{if(event.target.closest('button,a,input,select,textarea,label,[role="button"]'))return;action.click();});
  card.addEventListener('keydown',event=>{if(event.target===card&&(event.key==='Enter'||event.key===' ')){event.preventDefault();action.click();}});
  action.classList.add('tower-single-action-accessory');action.tabIndex=-1;action.setAttribute('aria-hidden','true');
 });
}
function installSingleActionCardEnhancement(){
 if(window.__towerSingleActionInstalled)return;
 window.__towerSingleActionInstalled=true;
 let queued=false;
 const update=()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;enhanceSingleActionCards(document);});};
 const observer=new MutationObserver(update);
 observer.observe(document.body,{subtree:true,childList:true});update();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installSingleActionCardEnhancement,{once:true});
else installSingleActionCardEnhancement();
function showAdminSettingsGroup(id,scroll=true){
 const valid=['brand','security','alerts','account','maintenance'];
 if(id!==null&&!valid.includes(id))id='brand';
 window.TOWER_ADMIN_SETTINGS_GROUP=id;
 document.querySelectorAll('.admin-settings-group').forEach(el=>{el.hidden=el.id!=='settings-group-'+id;});
 document.querySelectorAll('.admin-settings-tile').forEach(el=>{
  const selected=el.dataset.group===id;el.classList.toggle('active',selected);
  el.setAttribute('aria-expanded',selected?'true':'false');
  el.setAttribute('aria-current',selected?'true':'false');
 });
 const current=document.getElementById('adminSettingsCurrent');if(current)current.textContent=id?document.querySelector('.admin-settings-tile.active strong')?.textContent||'':'';
 if(id&&scroll){document.getElementById('settings-group-'+id)?.scrollIntoView({behavior:'smooth',block:'start'});}
}
function filterAdminSettingsGroups(term){
 const q=String(term||'').trim().toLocaleLowerCase('ar');let count=0;
 document.querySelectorAll('.admin-settings-tile').forEach(tile=>{
  const group=document.getElementById('settings-group-'+tile.dataset.group);
  const text=(tile.textContent+' '+(group?.textContent||'')).toLocaleLowerCase('ar');
  const found=!q||text.includes(q);tile.hidden=!found;if(found)count++;
 });
 const feedback=document.getElementById('adminSettingsSearchFeedback');
 if(feedback)feedback.textContent=q?(count?`${count} قسم مطابق — اختر القسم لفتح إعداداته`:'مفيش إعدادات مطابقة؛ جرّب كلمة مختلفة'):'';
 const selected=document.querySelector('.admin-settings-tile.active');
 if(q&&(!selected||selected.hidden)){
  const first=document.querySelector('.admin-settings-tile:not([hidden])');showAdminSettingsGroup(first?.dataset.group||null,false);
 }
}
function clearAdminSettingsSearch(){const input=document.getElementById('adminSettingsSearch');if(!input)return;input.value='';filterAdminSettingsGroups('');input.focus();}

function openUiPreferencesModal(){const p=window.UI_PREFS||{};const size=(id,label,v)=>`<label class="field"><span>${label}</span><input id="${id}" type="number" min="9" max="24" step="0.5" value="${esc(v)}"></label>`;openModal(`<div class="modal-head"><div><h3>فونتات النظام</h3><p>القيم تطبق على النظام كله؛ إعداد منفصل للموبايل والديسكتوب.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="form-grid"><label class="field span-2"><span>نوع الخط</span><select id="uiFont">${['Cairo','Tajawal','Noto Sans Arabic','Noto Kufi Arabic'].map(x=>`<option ${p.fontFamily===x?'selected':''}>${x}</option>`).join('')}</select></label><div class="span-2"><strong>Desktop</strong></div>${size('dHelper','النص التوضيحي',p.desktopHelper)}${size('dBody','النص العادي',p.desktopBody)}${size('dLabel','Labels',p.desktopLabel)}${size('dTitle','العناوين',p.desktopTitle)}<div class="span-2"><strong>Mobile</strong></div>${size('mHelper','النص التوضيحي',p.mobileHelper)}${size('mBody','النص العادي',p.mobileBody)}${size('mLabel','Labels',p.mobileLabel)}${size('mTitle','العناوين',p.mobileTitle)}</div><div class="form-actions"><button class="btn-sm primary" onclick="saveUiPreferences()">حفظ وتطبيق</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`,true);}
async function saveUiPreferences(){const v=id=>Number($(id).value);try{const r=await run('adminUpdateUiPreferences',{fontFamily:$('uiFont').value,desktopHelper:v('dHelper'),desktopBody:v('dBody'),desktopLabel:v('dLabel'),desktopTitle:v('dTitle'),mobileHelper:v('mHelper'),mobileBody:v('mBody'),mobileLabel:v('mLabel'),mobileTitle:v('mTitle')});applyUiPreferences(r.preferences);APP.ctx.uiPreferences=r.preferences;closeModal();toast('تم تطبيق فونتات النظام.');if(APP.ctx?.user?.role==='ADMIN'){await renderAdminCombined();showAdminSettingsGroup('brand');}else await renderSettings();}catch(e){toast(errText(e),'error');}}
function openTripSettingsFromSettings(focusId){const s=window.SETTINGS_TRIP;if(!s)return;openModal(`<div class="modal-head"><div><h3>أتعاب المشاوير الافتراضية</h3><p>حدّد أتعاب كل مسافة، ويمكنك تغيير المسافة لكل مشوار لتُضاف الأتعاب تلقائيًا إلى قيمة المشتريات.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="form-grid"><label class="field"><span>قريب</span><input id="feeNear" inputmode="decimal" value="${esc(s.feeNear)}"></label><label class="field"><span>متوسط</span><input id="feeMedium" inputmode="decimal" value="${esc(s.feeMedium)}"></label><label class="field"><span>بعيد</span><input id="feeFar" inputmode="decimal" value="${esc(s.feeFar)}"></label><label class="field"><span>المسافة الافتراضية</span><select id="defaultDistance">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${s.defaultDistance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></label></div><div class="form-actions"><button class="btn-sm primary" onclick="saveTripSettingsFromSettings()">حفظ</button></div>`);if(['feeNear','feeMedium','feeFar','defaultDistance'].includes(focusId)){requestAnimationFrame(()=>{const input=$(focusId);if(input){input.focus();if(input.select&&focusId!=='defaultDistance')input.select();}});}}
async function saveTripSettingsFromSettings(){try{await run('updateMyTripSettings',{feeNear:$('feeNear').value,feeMedium:$('feeMedium').value,feeFar:$('feeFar').value,defaultDistance:$('defaultDistance').value});closeModal();toast('تم حفظ إعدادات الوحدة.');await renderSettings();}catch(e){toast(errText(e),'error');}}
async function openProfileModal(){try{const titles=await run('listTitles',true);USER_UI.titles=titles;APP.titles=titles.filter(x=>x.status==='ACTIVE');}catch(e){toast('تعذر تحميل قائمة الألقاب: '+errText(e),'error');return;}const u=APP.ctx.user;openModal(`<div class="modal-head"><div><h3>الاسم واللقب</h3><p>سيظهران بهذه الصيغة في كل واجهات النظام.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitProfile(event)"><label class="field"><span>اللقب</span>${titleFields('my',u.preferredTitle||'أ.',u.titleId||'',u.customTitle||'')}</label><label class="field"><span>الاسم</span><input id="myName" value="${esc(u.name||'')}" required></label>${u.role==='RESIDENT'?userUnitsSelector(u):''}<div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function submitProfile(e){e.preventDefault();const old=Object.assign({},APP.ctx.user),p={name:$('myName').value};Object.assign(p,readTitle('my'));closeModal();beginBackgroundSave();try{APP.ctx.user.name=p.name;if(p.title)APP.ctx.user.preferredTitle=p.title;document.querySelectorAll('.user-card strong').forEach(x=>x.textContent=[APP.ctx.user.preferredTitle,APP.ctx.user.name].filter(Boolean).join(' '));await run('updateMyProfile',p);APP.ctx=await direct('getBootstrapContext',APP.token);document.querySelectorAll('.user-card strong').forEach(x=>x.textContent=APP.ctx.user.displayName);updateDocumentTitle();document.querySelectorAll('.greeting-name').forEach(x=>x.textContent=APP.ctx.user.displayName||APP.ctx.user.roleLabel);(APP.ctx?.user?.role==='ADMIN'?renderAdminCombined():renderSettings());toast('تم تحديث الاسم واللقب.');}catch(x){APP.ctx.user=old;toast('تعذر حفظ التعديل وتمت استعادة البيانات السابقة.','error');(APP.ctx?.user?.role==='ADMIN'?renderAdminCombined():renderSettings());}finally{endBackgroundSave();}}
function openContactsModal(){const u=APP.ctx.user;openModal(`<div class="modal-head"><div><h3>بيانات الاتصال</h3><p>بيانات فقط، دون ربط بتسجيل الدخول.</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><form class="form-grid" onsubmit="saveMyContacts(event)"><label class="field"><span>رقم الموبايل (مطلوب لمدير الوحدة فقط)</span><input id="contactPhone" dir="ltr" class="ltr-number" inputmode="tel" value="${esc(u.phone||'')}"></label><label class="field"><span>البريد الإلكتروني (اختياري)</span><input id="contactEmail" type="email" dir="ltr" value="${esc(u.email||'')}"></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit" id="contactSave">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function saveMyContacts(event){event.preventDefault();const phone=$('contactPhone').value.trim(),email=$('contactEmail').value.trim();if(phone&&!/^[+0-9\s()\-]{5,40}$/.test(phone)){toast('رقم الموبايل غير صحيح؛ راجع الرقم.','error');return;}if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast('صيغة الإيميل غير صحيحة؛ راجع العنوان.','error');return;}const btn=$('contactSave');btn.disabled=true;try{await run('updateMyContacts',{phone,email});APP.ctx=await direct('getBootstrapContext',APP.token);closeModal();await (APP.ctx?.user?.role==='ADMIN'?renderAdminCombined():renderSettings());toast('تم حفظ بيانات الاتصال.');}catch(e){toast(errText(e),'error');btn.disabled=false;}}
function openChangePinModal(){openModal(`<div class="modal-head"><div><h3>تغيير PIN</h3><p>سيتم تسجيل خروج كل الجلسات بعد الحفظ.</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><form class="login-form" onsubmit="submitPinChange(event)"><label class="field"><span>PIN الحالي</span>${pinInputHtml("mCurrentPin","current-password")}</label><label class="field"><span>PIN الجديد</span>${pinInputHtml("mNewPin","new-password")}</label><label class="field"><span>تأكيد PIN الجديد</span>${pinInputHtml("mConfirmPin","new-password")}</label><button id="mPinBtn" class="btn-sm primary wide" type="submit">حفظ</button></form>`);}
async function submitPinChange(ev){ev.preventDefault();const a=$('mCurrentPin').value,b=$('mNewPin').value,c=$('mConfirmPin').value;if(b!==c){toast('تأكيد PIN غير مطابق.','error');return;}const btn=$('mPinBtn');btn.disabled=true;try{await run('changeMyPin',a,b);closeModal();const publicCtx={version:APP.ctx&&APP.ctx.version,building:APP.ctx&&APP.ctx.building,uiPreferences:APP.ctx&&APP.ctx.uiPreferences};clearSession();APP.ctx=publicCtx;showLogin('تم تغيير PIN. سجل الدخول بالـPIN الجديد.');}catch(e){toast(errText(e),'error');}finally{if(btn)btn.disabled=false;}}
function renderPlanned(key,title){const stage={trips:'المرحلة التالية',account:'مرحلة المشاوير والحساب',accounts:'مرحلة المشاوير والحساب',services:'مرحلة الخدمات والمالية',finance:'مرحلة الخدمات والمالية',activity:'مرحلة الخدمات والمالية'}[key]||'مرحلة لاحقة';$('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>${esc(title)}</h3><p>${esc(stage)} حسب Master Rebuild Plan المضغوطة.</p></div><span class="badge muted">غير مفعّل بعد</span></div><div class="state-card empty-state"><strong>القسم محفوظ في الخطة</strong><span>لن نعيد استخدام كود قديم متعارض؛ سيتم تنفيذ الـworkflow كاملًا في مرحلته.</span></div></section>`;}





const UNIT_UI={types:[],units:[],users:[],requests:[],former:[],tab:'units'};
function unitStatusLabel(v){return({ACTIVE:'نشطة',INACTIVE:'غير نشطة',PAUSED:'موقوفة'})[v]||v||'—';}
function memberRoleLabel(v){return v==='MANAGER'?'مدير الوحدة':'عضو';}
let RESIDENT_UNIT_RENDER_EPOCH=0;
async function renderUnits(){
 const c=$('content');let residentCurrent=null;
 c.innerHTML=pageLoading('جاري تحميل الوحدات…');
 try{
  if(['ADMIN','UNION'].includes(APP.ctx.user.role)){await loadAdminUnitsData();renderAdminUnits();}
  else if(APP.ctx.user.role==='RESIDENT'){
   const epoch=++RESIDENT_UNIT_RENDER_EPOCH,unitId=APP.activeUnitId,pageKey=APP.page,userId=APP.ctx.user.userId;
   residentCurrent=()=>epoch===RESIDENT_UNIT_RENDER_EPOCH&&APP.ctx?.user?.role==='RESIDENT'&&APP.ctx.user.userId===userId&&APP.activeUnitId===unitId&&APP.page===pageKey&&c===$('content');
   const data=await run('getMyUnitGovernance');
   if(!residentCurrent())return;
   let services={services:[],subscriptions:[],isManager:data.membership?.memberRole==='MANAGER'};
   try{services=await run('getMyServices');}
   catch(serviceError){if(residentCurrent()){console.warn('Unit services unavailable',serviceError);toast('بيانات الخدمات غير متاحة حاليًا، لكن بيانات الوحدة ما زالت قابلة للعرض.','error');}}
   if(!residentCurrent())return;
   UNIT_UI.currentGovernance=data;renderResidentUnit(data,services);
  }else renderPlanned('units','الوحدات');
 }catch(e){if(!residentCurrent||residentCurrent())c.innerHTML=errorCard(e);}
}

async function loadAdminUnitsData(){const [types,units,users,requests,services,former]=await Promise.all([run('listUnitTypes',true),run('listUnits'),run(APP.ctx.user.role==='UNION'?'listUnitPeople':'adminListUsers'),run('listMemberRequests'),run('listServices'),run('listFormerUnitMembers')]);UNIT_UI.types=types;UNIT_UI.units=units;UNIT_UI.users=users;UNIT_UI.requests=requests;UNIT_UI.services=services||[];UNIT_UI.former=former||[];}
function renderAdminUnits(){const pending=UNIT_UI.requests.filter(x=>x.status==='PENDING').length;$('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الوحدات وأنواعها</h3><p>النوع Master Data من الأدمن فقط، والوحدة ترتبط بـ ID وليس نصًا حرًا.</p></div><div class="compact-actions"><div class="compact-actions"><button class="btn-sm" onclick="openBulkUnitsModal()">إضافة / تعديل مجموعة وحدات</button><button class="btn-sm primary" onclick="openNewUnitModal()">+ وحدة</button></div><button class="btn-sm" onclick="openNewTypeModal()">+ نوع</button></div></div><div class="tab-row"><button class="tab-btn ${UNIT_UI.tab==='units'?'active':''}" onclick="UNIT_UI.tab='units';renderAdminUnits()">الوحدات <b>${UNIT_UI.units.length}</b></button><button class="tab-btn ${UNIT_UI.tab==='types'?'active':''}" onclick="UNIT_UI.tab='types';renderAdminUnits()">الأنواع <b>${UNIT_UI.types.length}</b></button><button class="tab-btn ${UNIT_UI.tab==='requests'?'active':''}" onclick="UNIT_UI.tab='requests';renderAdminUnits()">طلبات الأعضاء <b>${pending}</b></button><button class="tab-btn ${UNIT_UI.tab==='former'?'active':''}" onclick="UNIT_UI.tab='former';renderAdminUnits()">الأعضاء السابقون <b>${UNIT_UI.former.length}</b></button></div><div id="unitTabBody"></div></section>`;renderAdminUnitsTab();}
function renderAdminUnitsTab(){const body=$('unitTabBody');if(UNIT_UI.tab==='types'){renderTypesTable(body);return;}if(UNIT_UI.tab==='requests'){renderRequestsTable(body);return;}if(UNIT_UI.tab==='former'){renderFormerMembers(body);return;}renderUnitsTable(body);}
function renderUnitsTable(body){if(!UNIT_UI.units.length){body.innerHTML=emptyState('لا توجد وحدات بعد','أنشئ أنواع الوحدات أولًا ثم أضف أول وحدة.');return;}body.innerHTML=`<div class="filter-toolbar"><input id="unitListSearch" type="search" aria-label="بحث الوحدات" autocomplete="off" placeholder="رقم الوحدة، الدور، النوع أو المدير" oninput="filterUnitList()"><select id="unitListType" aria-label="فلترة حسب نوع الوحدة" onchange="filterUnitList()"><option value="">كل الأنواع</option>${UNIT_UI.types.filter(t=>t.status==='ACTIVE').map(t=>`<option value="${esc(t.unitTypeId)}">${esc(t.name)}</option>`).join('')}</select><select id="unitListStatus" aria-label="فلترة حسب حالة الوحدة" onchange="filterUnitList()"><option value="">كل الحالات</option><option value="ACTIVE">نشطة</option><option value="INACTIVE">غير نشطة</option></select><button class="btn-sm" id="unitListReset" disabled onclick="clearUnitListFilters()">مسح الفلاتر</button></div><div id="unitListCount" class="selection-count" role="status" aria-live="polite">${UNIT_UI.units.length} وحدة</div><div class="list-stack">${UNIT_UI.units.map(u=>`<article class="data-card record-card unit-filter-row ${u._pending?'pending-record':''}" role="button" tabindex="0" aria-label="تفاصيل الوحدة ${esc(u.unitNumber)}" onkeydown="if((event.key==='Enter'||event.key===' ')&&event.target===this){event.preventDefault();openUnitDetailsById(this.dataset.unitId)}" data-unit-id="${esc(u.unitId)}" data-search="${esc(normAr([u.unitNumber,u.floor,u.managerName,u.unitTypeName,unitStatusLabel(u.status)].join(' ')))}" data-type="${esc(u.unitTypeId)}" data-status="${esc(u.status)}" onclick="openUnitDetailsById('${esc(u.unitId)}')"><div class="data-main"><div><strong>${esc(unitNo(u.unitNumber))}</strong><span>${esc(u.floor?floorNo(u.floor):'بدون دور')} · ${esc(u.unitTypeName)}</span></div><span class="badge ${u.status==='ACTIVE'?'success':'muted'}">${esc(unitStatusLabel(u.status))}</span></div><div class="data-meta"><span>مدير الوحدة: <b>${esc(u.managerName||'المدير غير متاح')}</b>${u._pending?' <em class="pending-inline">جاري التحديث…</em>':''}</span>${u.updatedAt?`<span>${esc(displayDateTime12(u.updatedAt))}</span>`:``}</div><div class="compact-actions"><button class="btn-sm" onclick="event.stopPropagation();openUnitDetailsById('${esc(u.unitId)}')">عرض</button><button class="btn-sm" onclick="event.stopPropagation();openUnitMembersModal('${esc(u.unitId)}')">الأعضاء</button></div></article>`).join('')}</div><div id="unitListEmpty" class="unit-filter-empty" role="status" hidden>لا توجد وحدات مطابقة للبحث. غيّر كلمات البحث أو امسح الفلاتر.</div>`;}

function filterUnitList(){const raw=($('unitListSearch')?.value||'').trim(),tokens=normAr(raw).split(/\s+/).filter(Boolean),type=$('unitListType')?.value||'',status=$('unitListStatus')?.value||'';let shown=0;document.querySelectorAll('.unit-filter-row').forEach(r=>{const hay=r.dataset.search||'',hide=!tokens.every(t=>hay.includes(t))||(type&&r.dataset.type!==type)||(status&&r.dataset.status!==status);r.hidden=hide;if(!hide)shown++;});const total=UNIT_UI.units.length;if($('unitListCount'))$('unitListCount').textContent=`عرض ${shown} من ${total} وحدة`;if($('unitListEmpty'))$('unitListEmpty').hidden=shown!==0;if($('unitListReset'))$('unitListReset').disabled=!(raw||type||status);}

function clearUnitListFilters(){if($('unitListSearch'))$('unitListSearch').value='';if($('unitListType'))$('unitListType').value='';if($('unitListStatus'))$('unitListStatus').value='';filterUnitList();}

function unitById(id){return UNIT_UI.units.find(x=>x.unitId===id);}
function unitShareText(u){return westernDigits(`الوحدة ${u.unitNumber||''}
الدور: ${u.floor||''}
النوع: ${u.unitTypeName||''}
مدير الوحدة: ${u.managerName||'المدير غير متاح'}
الحالة: ${unitStatusLabel(u.status)}`);}
function openUnitDetailsById(id){const u=unitById(id);if(!u)return;openModal(`<div class="modal-head"><div><h3>الوحدة ${esc(unitNo(u.unitNumber))}</h3><p>${esc(u.unitTypeName||'')} · الدور ${esc(floorNo(u.floor||'—'))}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-grid"><div><span>مدير الوحدة</span><strong>${esc(u.managerName||'المدير غير متاح')}</strong></div><div><span>الحالة</span><strong>${esc(unitStatusLabel(u.status))}</strong></div></div><div class="detail-actions"><button class="icon-action" onclick="copyUnitDetails('${esc(u.unitId)}')">⧉<span>نسخ</span></button><button class="icon-action" onclick="shareUnitDetails('${esc(u.unitId)}')">↗<span>مشاركة</span></button><button class="icon-action" onclick="openUnitStatement('${esc(u.unitId)}')" aria-label="كشف حساب الوحدة">▤<span>كشف الحساب</span></button><button class="icon-action" onclick='closeModal();openEditUnitModal(${JSON.stringify(u)})'>✎<span>تعديل</span></button></div>`);}
async function copyUnitDetails(id){const u=unitById(id);if(!u)return;try{await navigator.clipboard.writeText(unitShareText(u));toast('تم نسخ بيانات الوحدة.');}catch(e){toast('تعذر النسخ.','error');}}
async function shareUnitDetails(id){const u=unitById(id);if(!u)return;const text=unitShareText(u);try{if(navigator.share){await navigator.share({title:'الوحدة '+u.unitNumber,text});return;}await navigator.clipboard.writeText(text);toast('المشاركة غير مدعومة؛ تم نسخ البيانات.');}catch(e){if(e&&e.name!=='AbortError')toast('تعذر المشاركة.','error');}}
function renderTypesTable(body){if(!UNIT_UI.types.length){body.innerHTML=emptyState('لا توجد أنواع وحدات','أضف نوعًا مثل: شقة، محل، جراج.');return;}const active=UNIT_UI.types.filter(t=>t.status==='ACTIVE');body.innerHTML=`<div class="list-stack">${UNIT_UI.types.map(t=>`<article class="data-card unit-type-card"><div class="unit-type-card-top"><div class="unit-type-primary"><div class="unit-type-field"><span class="unit-type-label">اسم النوع</span><strong>${esc(t.name)}</strong></div><div class="unit-type-field"><span class="unit-type-label">وزن النوع</span><strong dir="ltr">${Math.round(Number(t.collectionWeight??1)*100)}%</strong></div></div><span class="badge ${t.status==='ACTIVE'?'success':'muted'}">${t.status==='ACTIVE'?'نشط':'معطل'}</span></div><div class="compact-actions unit-type-actions"><button class="btn-sm" onclick='openEditTypeModal(${JSON.stringify(t)})'>تعديل</button>${t.status==='ACTIVE'?`<button class="btn-sm danger-soft" onclick="openDeactivateTypeModal('${esc(t.unitTypeId)}')">تعطيل</button>`:`<button class="btn-sm" onclick="reactivateType('${esc(t.unitTypeId)}')">إعادة تفعيل</button>`}</div></article>`).join('')}</div>`;}
function renderFormerMembers(body){const items=UNIT_UI.former||[];if(!items.length){body.innerHTML=emptyState('لا يوجد أعضاء سابقون','');return;}body.innerHTML=`<div class="tower-directory-toolbar"><label for="formerMembersRowsSearch">بحث في الأعضاء السابقون</label><div class="tower-directory-controls"><input id="formerMembersRowsSearch" type="search" autocomplete="off" placeholder="ابحث بالاسم أو الوحدة" oninput="towerFilterDirectory(this,'formerMembersRows','.data-card','formerMembersRowsCount','formerMembersRowsEmpty')"><button id="formerMembersRowsReset" class="btn-sm" disabled onclick="towerResetDirectory('formerMembersRowsSearch','formerMembersRows','.data-card','formerMembersRowsCount','formerMembersRowsEmpty')">مسح البحث</button></div><span id="formerMembersRowsCount" class="tower-directory-count" role="status" aria-live="polite">${items.length} من ${items.length}</span></div><div class="list-stack" id="formerMembersRows" aria-label="الأعضاء السابقون">${items.map(x=>`<article class="data-card"><div class="data-main"><div><strong>${esc(x.displayName||x.userId)}</strong><span>الوحدة ${esc(unitNo(x.unitNumber||''))} · ${esc(memberRoleLabel(x.memberRole))} · ${esc(x.relation||'')}</span></div><span class="badge muted">سابق</span></div><div class="data-meta"><span>انضم ${esc(displayDateTime12(x.joinedAt))}</span><span>انتهى ${esc(displayDateTime12(x.endedAt))}</span></div></article>`).join('')}</div><div id="formerMembersRowsEmpty" class="tower-directory-empty" hidden>لا توجد نتائج مطابقة للبحث.</div>`;}
function renderRequestsTable(body){const items=UNIT_UI.requests;if(!items.length){body.innerHTML=emptyState('لا توجد طلبات أعضاء','طلبات مدير الوحدة ستظهر هنا للمراجعة.');return;}const unitName=id=>(UNIT_UI.units.find(u=>u.unitId===id)||{}).unitNumber||id;body.innerHTML=`<div class="tower-directory-toolbar"><label for="memberRequestsRowsSearch">بحث في طلبات العضوية</label><div class="tower-directory-controls"><input id="memberRequestsRowsSearch" type="search" autocomplete="off" placeholder="ابحث بالاسم أو الوحدة أو الحالة" oninput="towerFilterDirectory(this,'memberRequestsRows','.data-card','memberRequestsRowsCount','memberRequestsRowsEmpty')"><button id="memberRequestsRowsReset" class="btn-sm" disabled onclick="towerResetDirectory('memberRequestsRowsSearch','memberRequestsRows','.data-card','memberRequestsRowsCount','memberRequestsRowsEmpty')">مسح البحث</button></div><span id="memberRequestsRowsCount" class="tower-directory-count" role="status" aria-live="polite">${items.length} من ${items.length}</span></div><div class="list-stack" id="memberRequestsRows" aria-label="طلبات العضوية">${items.map(r=>`<article class="data-card"><div class="data-main"><div><strong>${esc(personName(r))}</strong><span>الوحدة ${esc(unitName(r.unitId))} · ${esc(r.relation||'بدون صلة محددة')}</span></div><span class="badge ${r.status==='PENDING'?'warning-badge':r.status==='APPROVED'?'success':'muted'}">${esc(({PENDING:'قيد المراجعة',APPROVED:'مقبول',REJECTED:'مرفوض',CANCELED:'ملغي'})[r.status]||r.status)}</span></div><div class="data-meta"><span>${r.phone?phoneDisplay(r.phone):'بدون هاتف'}</span><span>${esc(displayDateTime12(r.createdAt))}</span><span>رأي المدير: ${esc(memberOpinionLabel(r))}</span>${r.managerOpinionAt?`<span>${esc(displayDateTime12(r.managerOpinionAt))}</span>`:''}${r.managerOpinionNote?`<span>${esc(r.managerOpinionNote)}</span>`:''}</div>${r.status==='PENDING'?`<div class="compact-actions"><button class="btn-sm primary" onclick="openApproveRequestModal('${esc(r.requestId)}')">موافقة</button><button class="btn-sm danger-soft" onclick="rejectMemberRequest('${esc(r.requestId)}')">رفض</button></div>`:''}</article>`).join('')}</div><div id="memberRequestsRowsEmpty" class="tower-directory-empty" hidden>لا توجد نتائج مطابقة للبحث.</div>`;}
function defaultResidentialTypeId(){const t=(UNIT_UI.types||[]).find(t=>t.status==='ACTIVE'&&normAr(t.name||'')===normAr('سكني'));return t?t.unitTypeId:'';}
function typeOptions(selected='',includeInactive=false){return UNIT_UI.types.filter(t=>includeInactive||t.status==='ACTIVE').map(t=>`<option value="${esc(t.unitTypeId)}" ${t.unitTypeId===selected?'selected':''}>${esc(t.name)}${t.status!=='ACTIVE'?' — معطل':''}</option>`).join('');}
function residentOptions(selected=''){return UNIT_UI.users.filter(u=>u.role==='RESIDENT'&&u.status==='ACTIVE').map(u=>`<option value="${esc(u.userId)}" ${u.userId===selected?'selected':''}>${esc(u.displayName)} · ${esc(u.loginId)}</option>`).join('');}
function openNewTypeModal(){openModal(`<div class="modal-head"><div><h3>إضافة نوع وحدة</h3><p>سيظهر بعد الحفظ في كل قوائم اختيار نوع الوحدة، والترتيب يتم تلقائيًا.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitType(event)"><label class="field"><span>اسم النوع</span><input id="utName" maxlength="60" required placeholder="مثال: شقة"></label><label class="field"><span>وزن التحصيل</span><select id="utWeight">${[25,50,75,100,125,150,200,400].map(n=>`<option value="${n}" ${Math.round(Number(1)*100)===n?'selected':''}>${n}%</option>`).join('')}</select></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ النوع</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function submitType(e,id=''){e.preventDefault();try{await run(id?'adminUpdateUnitType':'adminCreateUnitType',{unitTypeId:id,name:$('utName').value,collectionWeight:Number($('utWeight')?.value||100)/100});closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تم الحفظ.');}catch(x){toast(errText(x),'error');}}
function openEditTypeModal(t){openModal(`<div class="modal-head"><div><h3>تعديل نوع الوحدة</h3><p>تغيير الاسم لا يغيّر ID ولا يكسر الوحدات المرتبطة؛ الترتيب تلقائي حسب الإنشاء.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitType(event,'${esc(t.unitTypeId)}')"><label class="field"><span>اسم النوع</span><input id="utName" maxlength="60" value="${esc(t.name)}" required></label><label class="field"><span>وزن التحصيل</span><select id="utWeight">${[25,50,75,100,125,150,200,400].map(n=>`<option value="${n}" ${Math.round(Number(t.collectionWeight||1)*100)===n?'selected':''}>${n}%</option>`).join('')}</select></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
function openDeactivateTypeModal(id){const replacements=UNIT_UI.types.filter(t=>t.status==='ACTIVE'&&t.unitTypeId!==id);openModal(`<div class="modal-head"><div><h3>تعطيل نوع الوحدة</h3><p>لو النوع مستخدم لازم تختار بديل؛ الوحدات القديمة لن تنكسر.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><label class="field"><span>النوع البديل عند الحاجة</span><select id="utReplacement"><option value="">— بدون بديل —</option>${replacements.map(t=>`<option value="${esc(t.unitTypeId)}">${esc(t.name)}</option>`).join('')}</select></label><div class="form-actions"><button class="btn-sm danger-soft" onclick="deactivateType('${esc(id)}')">تعطيل</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`);}
async function deactivateType(id){try{await run('adminDeactivateUnitType',id,$('utReplacement').value);closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تم تعطيل النوع.');}catch(e){toast(errText(e),'error');}}
async function reactivateType(id){try{await run('adminReactivateUnitType',id);await loadAdminUnitsData();renderAdminUnits();toast('تمت إعادة التفعيل.');}catch(e){toast(errText(e),'error');}}
function openNewUnitModal(){if(!UNIT_UI.types.some(t=>t.status==='ACTIVE')){toast('أضف نوع وحدة نشط أولًا.','error');return;}openModal(unitFormHtml({},'إضافة وحدة','submitUnit(event)'));}
function openEditUnitModal(u){openModal(unitFormHtml(u,'تعديل الوحدة',`submitUnit(event,'${esc(u.unitId)}')`));}
function bulkUnitRowHtml(i,values={}){const typeId=values.unitTypeId||$('bulkDefaultType')?.value||defaultResidentialTypeId()||(UNIT_UI.types||[]).find(t=>t.status==='ACTIVE')?.unitTypeId||'';return `<div class="bulk-unit-row tower-bulk-unit-row" data-unit-row><div class="bulk-unit-row-top"><span class="bulk-row-no">${i+1}</span><div class="bulk-row-tools"><button type="button" class="btn-sm bulk-copy" onclick="copyPreviousBulkUnitRow(this)" aria-label="نسخ الدور والنوع من السطر السابق" title="نسخ الدور والنوع">${actionIcon('copy')||'⧉'}</button><button type="button" class="btn-sm danger-soft bulk-remove" onclick="removeBulkUnitRow(this)" aria-label="حذف السطر" title="حذف السطر">×</button></div></div><label class="field"><span class="sr-only">رقم الوحدة</span><input data-k="unitNumber" aria-label="رقم الوحدة" placeholder="رقم الوحدة" value="${esc(values.unitNumber||'')}" oninput="refreshBulkUnitsValidation()"></label><label class="field"><span class="sr-only">الدور</span><input data-k="floor" aria-label="الدور" placeholder="الدور" value="${esc(values.floor||'')}" oninput="refreshBulkUnitsValidation()"></label><label class="field"><span class="sr-only">نوع الوحدة</span><select data-k="unitTypeId" aria-label="نوع الوحدة" onchange="refreshBulkUnitsValidation()"><option value="">النوع</option>${typeOptions(typeId,false)}</select></label><p class="bulk-unit-error" aria-live="polite"></p></div>`;}
function openBulkUnitsModal(){openModal(`<div class="modal-head"><div><h3>إضافة / تعديل مجموعة وحدات</h3><p>اختر إنشاء وحدات جديدة أو تنفيذ تعديل جماعي على الوحدات الحالية.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="choice-grid"><button class="choice-card" onclick="openBulkUnitsCreate()"><strong>+ إضافة مجموعة</strong><span>إنشاء وحدات جديدة دفعة واحدة.</span></button><button class="choice-card" onclick="openBulkUnitsEdit()"><strong>✎ تعديل مجموعة</strong><span>حالة، نوع، مدير، مسمى أو اشتراك خدمة.</span></button></div>`);}
function bulkUnitSelectRows(){return UNIT_UI.units.map(u=>`<label class="bulk-select-row"><input type="checkbox" data-bulk-unit value="${esc(u.unitId)}"><span><strong>${esc(unitNo(u.unitNumber))}</strong><small>${esc(floorNo(u.floor||''))} · ${esc(u.unitTypeName)} · ${esc(u.managerName||'')}</small></span></label>`).join('');}
function selectedBulkUnitIds(){return [...document.querySelectorAll('[data-bulk-unit]:checked')].map(x=>x.value);}
function filterBulkUnitList(input){return uiFilterCollection(input,'.bulk-select-row',$('bulkUnitSearchList'),'bulkUnitSearch');}
function openBulkUnitsEdit(){openModal(`<div class="modal-head"><div><h3>تعديل مجموعة وحدات</h3><p>حدد الوحدات والعملية؛ يتم عرض معاينة قبل التنفيذ.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="bulk-manage-layout"><div class="ui-search-selection"><div class="filter-toolbar"><input id="bulkUnitSearch" type="search" autocomplete="off" oninput="filterBulkUnitList(this)" placeholder="بحث في الوحدات" aria-label="بحث في الوحدات"><button type="button" class="btn-sm" id="bulkUnitSearchClear" disabled onclick="clearUiSearch('bulkUnitSearch',filterBulkUnitList)">مسح</button></div><p id="bulkUnitSearchCount" class="selection-count" role="status" aria-live="polite">عرض الكل</p><div class="bulk-select-list" id="bulkUnitSearchList">${bulkUnitSelectRows()}</div><p id="bulkUnitSearchEmpty" class="selection-count" hidden>لا توجد نتائج مطابقة. جرّب كلمة أخرى.</p></div><div><label class="field"><span>العملية</span><select id="bulkUnitAction" onchange="syncBulkUnitAction()"><option value="STATUS">تغيير الحالة</option><option value="TYPE">تغيير النوع</option><option value="MANAGERS">تعيين / تغيير المدير</option><option value="RENAME">تغيير المسمى</option></select></label><div id="bulkUnitActionFields"></div><div id="bulkUnitPreview" class="state-card hidden"></div><div class="form-actions"><button class="btn-sm" onclick="previewBulkUnits()">معاينة</button><button id="bulkUnitApply" class="btn-sm primary" disabled onclick="applyBulkUnits()">تنفيذ</button></div></div></div>`,true);syncBulkUnitAction();filterBulkUnitList($('bulkUnitSearch'));}
function syncBulkUnitAction(){const a=$('bulkUnitAction').value,b=$('bulkUnitActionFields');if(a==='STATUS')b.innerHTML=`<label class="field"><span>الحالة الجديدة</span><select id="bulkUnitStatus"><option value="ACTIVE">نشطة</option><option value="INACTIVE">غير نشطة</option></select></label>`;else if(a==='TYPE')b.innerHTML=`<label class="field"><span>النوع الجديد</span><select id="bulkUnitType">${typeOptions(defaultResidentialTypeId(),false)}</select></label>`;else if(a==='SERVICE')b.innerHTML=`<label class="field"><span>الخدمة</span><select id="bulkUnitService"><option value="">اختر الخدمة</option>${(UNIT_UI.services||[]).filter(x=>x.status==='ACTIVE').map(x=>`<option value="${esc(x.serviceId)}">${esc(x.name)}</option>`).join('')}</select></label>`;else if(a==='MANAGERS')b.innerHTML=`<div class="state-card"><strong>تعيين المدير</strong><span>بعد اختيار الوحدات واضغط معاينة سيظهر مدير لكل وحدة.</span></div>`;else b.innerHTML=`<div class="state-card"><strong>تغيير المسمى</strong><span>بعد اختيار الوحدات واضغط معاينة ستظهر حقول المسميات الجديدة.</span></div>`;if($('bulkUnitApply'))$('bulkUnitApply').disabled=true;if($('bulkUnitPreview'))$('bulkUnitPreview').classList.add('hidden');}
function previewBulkUnits(){const ids=selectedBulkUnitIds(),a=$('bulkUnitAction').value;if(!ids.length){toast('اختر وحدة واحدة على الأقل.','error');return;}const p=$('bulkUnitPreview');if(a==='MANAGERS'){p.innerHTML=`<strong>معاينة تعيين المدير</strong>${ids.map(id=>{const u=UNIT_UI.units.find(x=>x.unitId===id);return `<label class="field"><span>${esc(unitNo(u.unitNumber))}</span><select data-manager-unit="${esc(id)}"><option value="">اختر المدير</option>${residentOptions(u.managerUserId||'')}</select></label>`;}).join('')}`;}else if(a==='RENAME'){p.innerHTML=`<strong>معاينة تغيير المسميات</strong>${ids.map(id=>{const u=UNIT_UI.units.find(x=>x.unitId===id);return `<label class="field"><span>${esc(u.unitNumber)}</span><input data-rename-unit="${esc(id)}" value="${esc(u.unitNumber)}"></label>`;}).join('')}`;}else{const labels={STATUS:'تغيير الحالة',TYPE:'تغيير النوع',SERVICE:'الاشتراك في خدمة'};p.innerHTML=`<strong>معاينة</strong><span>سيتم تنفيذ «${labels[a]}» على ${ids.length} وحدة.</span>`;}p.classList.remove('hidden');$('bulkUnitApply').disabled=false;}
function optimisticBulkUnitPatch(p){const byUser={};UNIT_UI.users.forEach(u=>byUser[u.userId]=u);UNIT_UI.units.forEach(u=>{if(!p.unitIds.includes(u.unitId))return;u._pending=true;if(p.action==='STATUS')u.status=p.status;if(p.action==='TYPE'){const t=UNIT_UI.types.find(x=>x.unitTypeId===p.unitTypeId);u.unitTypeId=p.unitTypeId;if(t)u.unitTypeName=t.name;}if(p.action==='MANAGERS'){const a=(p.assignments||[]).find(x=>x.unitId===u.unitId);if(a){u.managerUserId=a.userId;u.managerName=byUser[a.userId]?byUser[a.userId].displayName:u.managerName;}}if(p.action==='RENAME'){const n=(p.names||[]).find(x=>x.unitId===u.unitId);if(n)u.unitNumber=n.unitNumber;}});}
async function applyBulkUnits(){const unitIds=selectedBulkUnitIds(),action=$('bulkUnitAction').value,p={unitIds,action};if(action==='STATUS')p.status=$('bulkUnitStatus').value;if(action==='TYPE')p.unitTypeId=$('bulkUnitType').value;if(action==='SERVICE')p.serviceId=$('bulkUnitService').value;if(action==='MANAGERS')p.assignments=[...document.querySelectorAll('[data-manager-unit]')].map(x=>({unitId:x.dataset.managerUnit,userId:x.value})).filter(x=>x.userId);if(action==='RENAME')p.names=[...document.querySelectorAll('[data-rename-unit]')].map(x=>({unitId:x.dataset.renameUnit,unitNumber:x.value.trim()}));if(!await confirmAction({title:'تأكيد تعديل الوحدات',message:`سيتم تنفيذ العملية على ${unitIds.length} وحدة.`,confirmLabel:'تنفيذ'}))return;const before=UNIT_UI.units.map(x=>Object.assign({},x));closeModal();optimisticBulkUnitPatch(p);renderAdminUnits();beginBackgroundSave();try{const r=await run('adminBulkUpdateUnits',p);await loadAdminUnitsData();renderAdminUnits();toast(`تم تعديل ${r.count} وحدة.`);}catch(e){UNIT_UI.units=before;renderAdminUnits();toast('تعذر حفظ التعديلات وتمت استعادة البيانات السابقة.','error');}finally{endBackgroundSave();}}
function openBulkUnitsCreate(){if(!(UNIT_UI.types||[]).some(t=>t.status==='ACTIVE')){toast('أضف نوع وحدة نشط أولًا.','error');return;}const first=defaultResidentialTypeId()||(UNIT_UI.types||[]).find(t=>t.status==='ACTIVE')?.unitTypeId||'';openModal(`<div class="modal-head"><div><h3>إضافة مجموعة وحدات</h3><p>السطور الفارغة لا تُنشأ. راجع الوحدات قبل التأكيد.</p></div><button class="icon-btn" type="button" onclick="closeBulkUnitCreate()" aria-label="إلغاء">×</button></div><form id="bulkUnitsCreateForm" class="bulk-units-create" novalidate onsubmit="submitBulkUnits(event)"><div class="bulk-unit-controls"><label class="field"><span>عدد السطور</span><input id="bulkUnitsCount" type="number" min="1" max="100" value="3" onchange="resizeBulkUnitsRows(this.value)"></label><label class="field"><span>النوع الافتراضي</span><select id="bulkDefaultType" onchange="setBulkUnitDefaultType(this.value)">${typeOptions(first,false)}</select></label></div><div class="bulk-unit-controls bulk-unit-generator"><label class="field"><span>رقم البداية (اختياري)</span><input id="bulkStartNumber" inputmode="numeric" placeholder="مثال: 101"></label><button type="button" class="btn-sm" onclick="generateBulkUnitNumbers()">ترقيم تلقائي</button></div><div id="bulkUnitsRows" class="bulk-unit-list">${Array.from({length:3},(_,i)=>bulkUnitRowHtml(i)).join('')}</div><button type="button" class="btn-sm" onclick="addBulkUnitRow()">+ سطر</button><div class="bulk-unit-footer"><span id="bulkUnitsReady" aria-live="polite">0 وحدات جاهزة</span><button type="button" class="btn-sm" onclick="closeBulkUnitCreate()" title="إلغاء" aria-label="إلغاء">× <span class="bulk-unit-action-text">إلغاء</span></button><button id="bulkUnitsSubmit" class="btn-sm primary" type="submit" title="إنشاء الوحدات" aria-label="إنشاء الوحدات">✓ <span class="bulk-unit-action-text">إنشاء</span></button></div></form>`,true);refreshBulkUnitsValidation();}
function addBulkUnitRow(){const b=$('bulkUnitsRows'),n=b?.querySelectorAll('[data-unit-row]').length||0;if(n>=100){toast('الحد الأقصى 100 وحدة.','error');return;}b.insertAdjacentHTML('beforeend',bulkUnitRowHtml(n));$('bulkUnitsCount').value=n+1;refreshBulkUnitsValidation();}
function removeBulkUnitRow(btn){const b=$('bulkUnitsRows'),rows=[...b.querySelectorAll('[data-unit-row]')];if(rows.length===1){toast('اترك سطرًا واحدًا على الأقل.','error');return;}const row=btn.closest('[data-unit-row]');if(row.querySelector('[data-k="unitNumber"]').value.trim()||row.querySelector('[data-k="floor"]').value.trim()){if(!confirm('حذف السطر وبياناته؟'))return;}row.remove();renumberBulkUnitRows();refreshBulkUnitsValidation();}
async function bulkUnitsRead(){return [...document.querySelectorAll('#bulkUnitsRows [data-unit-row]')].map((r,i)=>{const g=k=>r.querySelector(`[data-k="${k}"]`).value.trim();return {row:i+1,unitNumber:g('unitNumber'),floor:g('floor'),unitTypeId:g('unitTypeId'),status:'ACTIVE'};});}
function bulkUnitsValidate(items){const known=new Set((UNIT_UI.units||[]).map(u=>String(u.unitNumber||'').trim().toLowerCase()));const seen=new Set();const errors=[];for(const x of items){const key=x.unitNumber.toLowerCase();let message='';if(!x.unitNumber)message='اكتب رقم الوحدة.';else if(!x.unitTypeId)message='اختَر نوع الوحدة.';else if(known.has(key))message='رقم الوحدة موجود بالفعل.';else if(seen.has(key))message='رقم الوحدة مكرر في السطور الجديدة.';if(message)errors.push({row:x.row,message});if(key)seen.add(key);}return errors;}
function refreshBulkUnitsValidation(){const all=bulkUnitsRead(),used=all.filter(x=>x.unitNumber||x.floor),errors=bulkUnitsValidate(used);for(const r of document.querySelectorAll('#bulkUnitsRows [data-unit-row]')){const i=[...r.parentNode.children].indexOf(r)+1,err=errors.find(x=>x.row===i);const host=r.querySelector('.bulk-unit-error');if(host)host.textContent=err?.message||'';r.classList.toggle('has-error',!!err);}const status=$('bulkUnitsReady');if(status)status.textContent=`${used.length-errors.length} جاهزة · ${all.length-used.length} فارغة${errors.length?' · '+errors.length+' تحتاج مراجعة':''}`;}
function renumberBulkUnitRows(){const rows=[...document.querySelectorAll('#bulkUnitsRows [data-unit-row]')];rows.forEach((r,i)=>r.querySelector('.bulk-row-no').textContent=i+1);if($('bulkUnitsCount'))$('bulkUnitsCount').value=rows.length;}
function resizeBulkUnitsRows(value){const count=Number(value);if(!Number.isInteger(count)||count<1||count>100){toast('اختر عدد سطور من 1 إلى 100.','error');renumberBulkUnitRows();return;}const box=$('bulkUnitsRows');let rows=[...box.querySelectorAll('[data-unit-row]')];if(count<rows.length){const removed=rows.slice(count);if(removed.some(r=>r.querySelector('[data-k="unitNumber"]').value.trim()||r.querySelector('[data-k="floor"]').value.trim())&&!confirm('تقليل عدد السطور سيحذف البيانات الموجودة في السطور الزائدة. هل تريد الاستمرار؟')){renumberBulkUnitRows();return;}removed.forEach(r=>r.remove());}else for(let i=rows.length;i<count;i++)box.insertAdjacentHTML('beforeend',bulkUnitRowHtml(i));renumberBulkUnitRows();refreshBulkUnitsValidation();}
function setBulkUnitDefaultType(value){for(const row of document.querySelectorAll('#bulkUnitsRows [data-unit-row]')){const number=row.querySelector('[data-k="unitNumber"]').value.trim(),floor=row.querySelector('[data-k="floor"]').value.trim();if(!number&&!floor)row.querySelector('[data-k="unitTypeId"]').value=value;}refreshBulkUnitsValidation();}
function copyPreviousBulkUnitRow(btn){const row=btn.closest('[data-unit-row]'),prev=row.previousElementSibling;if(!prev){toast('مفيش سطر سابق للنسخ.');return;}for(const k of ['floor','unitTypeId'])row.querySelector(`[data-k="${k}"]`).value=prev.querySelector(`[data-k="${k}"]`).value;refreshBulkUnitsValidation();}
function generateBulkUnitNumbers(){const raw=$('bulkStartNumber').value.trim();if(!/^\d+$/.test(raw)){toast('اكتب رقم بداية صحيح بالأرقام.','error');return;}const start=Number(raw),rows=[...document.querySelectorAll('#bulkUnitsRows [data-unit-row]')];if(!Number.isSafeInteger(start)||start<0||!Number.isSafeInteger(start+rows.length-1)){toast('رقم البداية غير صالح.','error');return;}if(rows.some(r=>r.querySelector('[data-k="unitNumber"]').value.trim())&&!confirm('سيتم استبدال أرقام الوحدات المكتوبة. هل تريد المتابعة؟'))return;rows.forEach((r,i)=>r.querySelector('[data-k="unitNumber"]').value=String(start+i));refreshBulkUnitsValidation();}
function closeBulkUnitCreate(){const used=bulkUnitsRead().some(x=>x.unitNumber||x.floor);if(used&&!confirm('إلغاء الإضافة وفقدان البيانات غير المحفوظة؟'))return;closeModal();}
async function submitBulkUnits(e){e.preventDefault();const items=bulkUnitsRead().filter(x=>x.unitNumber||x.floor);if(!items.length){toast('اكتب رقم وحدة واحدة على الأقل.','error');return;}const errors=bulkUnitsValidate(items);if(errors.length){refreshBulkUnitsValidation();toast(`راجع السطر ${errors[0].row}: ${errors[0].message}`,'error');return;}const ignored=$('bulkUnitsRows').querySelectorAll('[data-unit-row]').length-items.length;if(!await confirmAction({title:'تأكيد إنشاء الوحدات',message:`سيتم إنشاء ${items.length} وحدة، وتجاهل ${ignored} سطر فارغ. لن يتم تعديل أي وحدة موجودة.`,confirmLabel:'إنشاء'}))return;const btn=$('bulkUnitsSubmit');if(btn)btn.disabled=true;beginBackgroundSave();try{const r=await run('adminBulkCreateUnits',items.map(({row,...x})=>x));closeModal();await loadAdminUnitsData();renderAdminUnits();toast(`تم إنشاء ${r.count} وحدة.`);}catch(x){toast(errText(x),'error');refreshBulkUnitsValidation();}finally{if(btn?.isConnected)btn.disabled=false;endBackgroundSave();}}
function unitFormHtml(u,title,submit){return `<div class="modal-head"><div><h3>${esc(title)}</h3><p>نوع الوحدة اختيار من Master Data فقط.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="${submit}"><label class="field"><span>رقم / اسم الوحدة</span><input id="unitNumber" value="${esc(u.unitNumber||'')}" required></label><label class="field"><span>الدور</span><input id="unitFloor" value="${esc(u.floor||'')}"></label><label class="field"><span>نوع الوحدة</span><select id="unitType" required><option value="">اختر النوع</option>${typeOptions(u.unitTypeId||defaultResidentialTypeId(),!!u.unitTypeId)}</select></label><label class="field"><span>الحالة</span><select id="unitStatus"><option value="ACTIVE" ${u.status==='ACTIVE'?'selected':''}>نشطة</option><option value="PAUSED" ${u.status==='PAUSED'?'selected':''}>موقوفة</option><option value="INACTIVE" ${u.status==='INACTIVE'?'selected':''}>غير نشطة</option></select></label>${u.unitId?`<div class="field span-2"><span>مدير الوحدة الرسمي</span><select id="unitManagerCandidate" onchange="updateUnitManagerChoice('${esc(u.unitId)}')"><option value="">${esc(u.managerName||'المدير الحالي غير متاح')} — بدون تغيير</option>${UNIT_UI.users.filter(x=>x.role==='RESIDENT'&&x.status==='ACTIVE'&&userUnitMemberships(x).some(m=>m.unitId===u.unitId&&m.memberRole==='MEMBER')).map(x=>`<option value="${esc(x.userId)}">${esc(personName(x))}</option>`).join('')}</select><p class="field-hint" id="unitManagerChoiceHint">يظهر الأعضاء النشطون المسجلون في الوحدة فقط. اختيار مدير جديد يستلزم مراجعة النقل وتأكيده.</p><button class="btn-sm" type="button" onclick="closeModal();openUnitMembersModal('${esc(u.unitId)}')">إدارة أعضاء الوحدة</button></div>`:`<label class="field span-2"><span>مدير الوحدة — اختياري الآن</span><select id="unitManager"><option value="">تعيين لاحقًا</option>${residentOptions()}</select></label>`}<div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`;}
function updateUnitManagerChoice(unitId){const id=$('unitManagerCandidate')?.value||'';const hint=$('unitManagerChoiceHint');if(hint)hint.textContent=id?'عند الحفظ ستظهر نافذة مراجعة نقل الإدارة، ولن يتم النقل قبل تأكيدها.':'لن يتم تغيير مدير الوحدة عند الحفظ.';}
async function submitUnit(e,id=''){e.preventDefault();const p={unitId:id,unitNumber:$('unitNumber').value,floor:$('unitFloor').value,unitTypeId:$('unitType').value,status:$('unitStatus').value,managerUserId:id?'':($('unitManager')?$('unitManager').value:'')};try{const managerChoice=id?($('unitManagerCandidate')?.value||''):'';await run(id?'adminUpdateUnit':'adminCreateUnit',p);closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تم حفظ الوحدة.');if(id&&managerChoice){await adminTransferManager(id,managerChoice);}}catch(x){toast(errText(x),'error');}}
function openAssignManagerModal(u){openModal(`<div class="modal-head"><div><h3>مدير الوحدة ${esc(unitNo(u.unitNumber))}</h3><p>التعيين ذري؛ لن يسمح النظام بوجود مديرين نشطين لنفس الوحدة.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><label class="field"><span>مدير الوحدة</span><select id="managerUser"><option value="">اختر ساكنًا</option>${residentOptions(u.managerUserId)}</select></label><div class="form-actions"><button class="btn-sm primary" onclick="assignManager('${esc(u.unitId)}')">حفظ</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`);}
async function assignManager(unitId){const uid=$('managerUser').value;if(!uid){toast('اختر المستخدم.','error');return;}try{await run('adminAssignUnitManager',unitId,uid);closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تم تعيين مدير الوحدة.');}catch(e){toast(errText(e),'error');}}
async function openUnitMembersModal(unitId){try{const allUsers=UNIT_UI.users,members=await directMembersForAdmin(unitId);const unit=UNIT_UI.units.find(u=>u.unitId===unitId);openModal(`<div class="modal-head"><div><h3>أعضاء الوحدة ${esc(unit?unitNo(unit.unitNumber):'')}</h3><p>مدير واحد فقط؛ ويمكن نقل الإدارة لعضو نشط من نفس الوحدة.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="list-stack mini-list">${members.length?members.map(m=>`<div class="member-line"><div><strong>${esc(m.displayName)}</strong><span>${esc(memberRoleLabel(m.memberRole))} · ${ltrId(m.loginId)}</span></div>${m.memberRole==='MEMBER'?`<button class="btn-sm" onclick="adminTransferManager('${esc(unitId)}','${esc(m.userId)}')">نقل الإدارة</button>`:'<span class="badge success">المدير</span>'}</div>`).join(''):emptyState('لا يوجد أعضاء','عيّن مديرًا أو أضف عضوًا.')}</div><hr class="soft-rule"><label class="field"><span>إضافة ساكن موجود كعضو</span><select id="existingMember"><option value="">اختر ساكنًا</option>${allUsers.filter(u=>u.role==='RESIDENT'&&u.status==='ACTIVE'&&!userUnitMemberships(u).some(m=>m.unitId===unitId)).map(u=>`<option value="${esc(u.userId)}">${esc(u.displayName)} · ${esc(u.loginId)}</option>`).join('')}</select></label><label class="field"><span>صلة القرابة — اختياري</span>${relationFields('existing')}</label><div class="form-actions"><button class="btn-sm primary" onclick="adminAddMember('${esc(unitId)}')">إضافة عضو</button></div>`);}catch(e){toast(errText(e),'error');}}
async function directMembersForAdmin(unitId){const unit=UNIT_UI.units.find(u=>u.unitId===unitId);const users=UNIT_UI.users.filter(u=>userUnitMemberships(u).some(m=>m.unitId===unitId));return users.map(u=>({userId:u.userId,displayName:u.displayName,loginId:u.loginId,memberRole:userUnitMemberships(u).find(m=>m.unitId===unitId).memberRole}));}
async function adminAddMember(unitId){const uid=$('existingMember').value;if(!uid){toast('اختر الساكن.','error');return;}try{await run('adminAddExistingMember',unitId,uid,readRelation('existing'));closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تمت إضافة العضو.');}catch(e){toast(errText(e),'error');}}
async function adminTransferManager(unitId,userId){
 const unit=UNIT_UI.units.find(x=>String(x.unitId)===String(unitId));
 const candidate=UNIT_UI.users.find(x=>String(x.userId)===String(userId));
 if(!candidate){toast('تعذر تحميل بيانات العضو. أعد فتح قائمة أعضاء الوحدة.','error');return;}
 const phone=String(candidate.phone||candidate.phoneNumber||'').trim();
 const name=candidate.displayName||'العضو المختار';
 openModal(`<div class="modal-head"><div><h3>مراجعة نقل إدارة الوحدة</h3><p>سيُستخدم رقم العضو المحفوظ تلقائيًا. لا حاجة لإعادة إدخاله.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-grid"><div><span>الوحدة</span><strong>${esc(unit?.unitNumber||'')}</strong></div><div><span>المدير الحالي</span><strong>${esc(unit?.managerName||'غير متاح')}</strong></div><div><span>المدير الجديد</span><strong>${esc(name)}</strong></div></div>${phone?`<div class="state-card">رقم الموبايل المسجل: <b dir="ltr">${esc(phone)}</b><input id="transferManagerPhone" type="hidden" value="${esc(phone)}"></div>`:`<label class="field"><span>رقم موبايل العضو غير مسجل — أدخله مرة واحدة</span><input id="transferManagerPhone" type="tel" inputmode="tel" dir="ltr" class="ltr-number" placeholder="رقم الموبايل" oninput="refreshAdminTransferState()"></label>`}<p id="transferManagerHint" class="resident-building-empty">${phone?'رقم العضو محفوظ؛ اضغط تأكيد نقل الإدارة مباشرة.':'أدخل رقم العضو المفقود ثم أكد النقل.'}</p><div class="form-actions">${phone?'':`<button id="transferSavePhone" class="btn-sm" onclick="saveAdminTransferPhone('${esc(unitId)}','${esc(userId)}')">حفظ الموبايل</button>`}<button id="transferConfirm" class="btn-sm primary" onclick="confirmAdminTransferManager('${esc(unitId)}','${esc(userId)}')">تأكيد نقل الإدارة</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`);
 refreshAdminTransferState();
}
function refreshAdminTransferState(){
 const input=$('transferManagerPhone'),button=$('transferConfirm');if(!input||!button)return;
 const value=input.value.trim();button.disabled=!value||!/^\+?[0-9 ()-]{8,20}$/.test(value);
 const hint=$('transferManagerHint');if(hint&&!button.disabled)hint.textContent='زر تأكيد نقل الإدارة سيحفظ الموبايل تلقائيًا إن تغيّر، ثم ينفذ النقل.';
}
async function saveAdminTransferPhone(unitId,userId){
 const candidate=UNIT_UI.users.find(x=>String(x.userId)===String(userId)),field=$('transferManagerPhone');
 if(!candidate||!field){toast('تعذر قراءة بيانات المدير الجديد.','error');return;}
 const phone=field.value.trim();if(!/^\+?[0-9 ()-]{8,20}$/.test(phone)){toast('أدخل رقم موبايل صحيح (8 إلى 20 خانة).','error');field.focus();return;}
 const button=$('transferSavePhone');if(button)button.disabled=true;
 try{
  await run('adminUpdateUser',{userId,candidateId:userId,name:candidate.name,status:candidate.status,phone,email:candidate.email||'',titleId:candidate.titleId||'',title:candidate.title||'',customTitle:candidate.customTitle||''});
  candidate.phone=phone;
  if($('transferManagerHint'))$('transferManagerHint').textContent='تم حفظ الموبايل بنجاح. يمكنك الآن تأكيد نقل الإدارة.';
  toast('تم حفظ رقم الموبايل. لم يتم نقل الإدارة بعد.');
 }catch(e){toast('تعذر حفظ الموبايل، ولم يتم نقل الإدارة: '+errText(e),'error');}
 finally{if(button?.isConnected)button.disabled=false;refreshAdminTransferState();}
}
async function confirmAdminTransferManager(unitId,userId){
 const candidate=UNIT_UI.users.find(x=>String(x.userId)===String(userId));
 const field=$('transferManagerPhone'),entered=String(field?.value||'').trim();
 if(!candidate||!field){toast('تعذر تحميل بيانات المدير الجديد. أعد فتح نافذة النقل.','error');return;}
 if(!/^\+?[0-9 ()-]{8,20}$/.test(entered)){toast('أدخل رقم موبايل صحيح قبل تأكيد النقل.','error');field.focus();return;}
 const button=$('transferConfirm'),saveButton=$('transferSavePhone');
 if(button)button.disabled=true;if(saveButton)saveButton.disabled=true;
 try{
  if(entered!==String(candidate.phone||candidate.phoneNumber||'').trim()){
   if($('transferManagerHint'))$('transferManagerHint').textContent='جاري حفظ رقم الموبايل…';
   await run('adminUpdateUser',{userId,candidateId:userId,name:candidate.name,status:candidate.status,phone:entered,email:candidate.email||'',titleId:candidate.titleId||'',title:candidate.title||'',customTitle:candidate.customTitle||''});
   candidate.phone=entered;
   if($('transferManagerHint'))$('transferManagerHint').textContent='تم حفظ الموبايل. جاري نقل إدارة الوحدة…';
  }
  await run('transferUnitManager',unitId,userId);
  closeModal();await loadAdminUnitsData();renderAdminUnits();toast('تم حفظ البيانات ونقل إدارة الوحدة بنجاح.');
 }catch(e){toast('لم يكتمل نقل الإدارة. '+errText(e)+(entered===String(candidate.phone||'').trim()?' (رقم الموبايل محفوظ).':''),'error');}
 finally{if(button?.isConnected)button.disabled=false;if(saveButton?.isConnected)saveButton.disabled=false;}
}
function openApproveRequestModal(requestId){openModal(`<div class="modal-head"><div><h3>الموافقة على طلب العضو</h3><p>User ID سيتولد تلقائيًا من الوحدة. PIN الافتراضي 123456 ويمكن تعديله الآن.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><label class="field"><span>PIN</span>${pinInputHtml("requestPin","new-password","123456")}</label><div class="form-actions"><button class="btn-sm primary" onclick="approveRequest('${esc(requestId)}')">موافقة وإنشاء الحساب</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`);}
async function approveRequest(id){const pin=$('requestPin').value;try{const r=await run('adminApproveMemberRequest',{requestId:id,pin});openCredentialsResult(r,'تمت الموافقة على العضو');if(APP.page==='people')await (APP.ctx?.user?.role==='UNION'?renderUnionPeople():renderPeople());else await loadAdminUnitsData();}catch(e){toast(errText(e),'error');}}
async function rejectMemberRequest(id){const notes=await promptAction({title:'رفض طلب العضوية',message:'يمكن إضافة سبب الرفض أو تركه فارغًا.',label:'سبب الرفض',confirmLabel:'رفض'});if(notes===null)return;try{await run('adminRejectMemberRequest',id,notes);if(APP.page==='people')await (APP.ctx?.user?.role==='UNION'?renderUnionPeople():renderPeople());else{await loadAdminUnitsData();renderAdminUnits();}toast('تم رفض الطلب.');}catch(e){toast(errText(e),'error');}}
function renderResidentUnit(data,serviceData){if(!data.hasUnit){$('content').innerHTML=emptyState('الحساب غير مرتبط بوحدة','راجع الإدارة لربط حسابك بوحدتك.');return;}const u=data.unit,m=data.membership,isManager=m.memberRole==='MANAGER';const pendingMemberRequests=(Array.isArray(data.requests)?data.requests:[]).filter(r=>r.status==='PENDING');$('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الوحدة ${esc(unitNo(u.unitNumber))}</h3><p>الدور ${esc(floorNo(u.floor||'—'))} · ${esc(u.unitTypeName||'')} · ${esc(memberRoleLabel(m.memberRole))}</p></div><span class="badge ${isManager?'success':''}">${isManager?'مدير الوحدة':'عضو'}</span></div><div class="list-stack mini-list">${data.members.map(x=>`<div class="member-line"><div><strong>${esc(x.displayName)}</strong><span>${esc(memberRoleLabel(x.memberRole))} · ${esc(x.relation||'')}</span></div>${isManager&&x.memberRole==='MEMBER'?`<button class="btn-sm" onclick="residentTransfer('${esc(u.unitId)}','${esc(x.userId)}')">نقل الإدارة</button>`:''}</div>`).join('')}</div>${`<div class="section-actions"><button class="btn-sm primary" onclick="openMemberRequestModal('${esc(u.unitId)}')">+ طلب إضافة عضو</button></div>`}</section>${isManager&&(data.registrationRequests||[]).length?`<section class="panel"><div class="panel-head"><div><h3>طلبات الانضمام من صفحة الدخول</h3><p>رأيك استشاري. قرار قبول العضوية أو رفضها للأدمن ورئيس الاتحاد، ورأيك استشاري.</p></div></div><div class="list-stack">${data.registrationRequests.map(r=>`<div class="member-line"><div><strong>${esc(personName(r))}</strong><span>${esc(displayDateTime12(r.createdAt))} · ${esc(r.phone||'')}</span><small>${r.managerOpinion==='SUPPORT'?'تم تأييد الطلب':r.managerOpinion==='OBJECT'?'تم تسجيل الاعتراض':'لم تراجع الطلب بعد'}</small></div><div class="compact-actions"><button class="btn-sm" onclick="reviewRegistrationOpinion('${esc(r.requestId)}','SUPPORT')">تأييد</button><button class="btn-sm" onclick="reviewRegistrationOpinion('${esc(r.requestId)}','OBJECT')">اعتراض</button></div></div>`).join('')}</div></section>`:''}${pendingMemberRequests.length?`<section class="panel"><div class="panel-head"><div><h3>طلبات الأعضاء</h3><p>طلبات الانضمام التي تنتظر موافقة الإدارة.</p></div></div><div class="list-stack">${pendingMemberRequests.map(r=>`<div class="member-line"><div><strong>${esc(personName(r))}</strong><span>${esc(displayDateTime12(r.createdAt))} · ${esc(r.relation||'')}</span></div><span class="badge ${r.status==='APPROVED'?'success':'muted'}">${esc(({PENDING:'قيد المراجعة',APPROVED:'مقبول',REJECTED:'مرفوض'})[r.status]||r.status)}</span>${isManager&&r.status==='PENDING'?`<button class="btn-sm" onclick="reviewMemberOpinion('${esc(r.requestId)}','SUPPORT')">تأييد</button><button class="btn-sm" onclick="reviewMemberOpinion('${esc(r.requestId)}','OBJECT')">اعتراض</button>`:''}${r.status==='PENDING'?`<button class="btn-sm" onclick="openEditPendingMemberRequest('${esc(r.requestId)}')">تعديل الطلب</button>`:''}</div>`).join('')}</div></section>`:''}${isManager?`<section class="panel"><div class="panel-head"><div><h3>خصوصية حسابات الاتحاد</h3><p>السماح لأعضاء الوحدة بعرض الصندوق والمالية العامة. لا يؤثر على المشاوير أو مستحقات الوحدة.</p></div></div><label class="field"><span>عرض حسابات الاتحاد للأعضاء</span><select id="unitFundVisibility" onchange="saveUnitFundVisibility('${esc(u.unitId)}')" disabled><option>جارٍ التحميل…</option></select></label></section>`:''}${serviceData?.scopePending?'<section class="panel"><p>الخدمات: جارٍ تجهيز ربط الاشتراكات بالوحدة المختارة. لا يمكن تعديلها لحساب متعدد الوحدات مؤقتًا.</p></section>':residentServicesSection(serviceData||{services:[],subscriptions:[],isManager:isManager})}`;if(isManager)loadUnitFundVisibility(u.unitId);}
// Resident service workflow: one rendering contract for both Services and Unit pages.
// No ledger amount is inferred from the subscription snapshot for a finalized shared task.
function residentSharedState(s,q){
 if(s.pricingMode!=='SHARED_TOTAL')return null;
 const state=s.enrollmentStatus||'OPEN';
 const part=q?.status==='ACTIVE'?'ACTIVE':q?.status==='PENDING'?'PENDING':'NONE';
 const count=Number(s.activeSubscriberCount);
 const share=s.project?.ownEstimatedShare!=null?taskExactMoney(s.project.ownEstimatedShare):s.project?.distribution==='CUSTOM'?(s.project?.ownAgreedAmount!=null?taskExactMoney(s.project.ownAgreedAmount):'حسب اتفاق الوحدة'):Number(s.totalBudget)>0&&Number.isFinite(count)&&count>0?money(taskEstimatedNetBudget(s)/count):'غير متاح';
 const label=state==='OPEN'?'الاشتراك مفتوح':state==='CLOSED'?'مغلق — بانتظار الاعتماد':state==='FINALIZED'?'التوزيع معتمد':'حالة غير معروفة';
 const status=part==='PENDING'?'طلبك قيد المراجعة':part==='ACTIVE'?'أنت مشترك':state==='OPEN'?'لم تشترك بعد':state==='FINALIZED'?'غير مشترك — التوزيع معتمد':'غير مشترك — باب الاشتراك مغلق';
 const detail=state==='FINALIZED'?(part==='ACTIVE'?'تم اعتماد التوزيع. الأرقام من دفتر مستحقات الوحدة؛ المدفوع يشمل الدفعات والمقدمات المخصصة للمستحق بإيصالات مرحّلة، بعد الردود المؤكدة.':'تم اعتماد التوزيع. لا يمكن إضافة مشتركين الآن.'):
   state==='CLOSED'?(part==='ACTIVE'?'تم غلق الاشتراك. نصيبك ما زال تقديريًا حتى الاعتماد.':'باب الاشتراك مغلق ولا يستقبل طلبات جديدة.'):
   part==='PENDING'?'لم يتم قبول طلبك بعد؛ النصيب التقديري يتغير مع عدد المشتركين.':part==='ACTIVE'?'النصيب التقديري قابل للتغيير لحين اعتماد التوزيع.':'يمكنك طلب الاشتراك. النصيب الحالي تقديري وقد يتغير.';
 return {state,part,share,label,status,detail};
}
function residentServiceActions(s,q){
 if(s.taskProjectUnavailable)return '<span role="status">بيانات المهمة غير متاحة؛ حاول فتح الصفحة مرة تانية.</span>';
 if(s.project?.eligible===false)return '<span class="badge muted">المهمة موجهة لوحدات أخرى</span>';
 if(s.project?.phase==='PROPOSAL')return `<button type="button" class="btn-sm primary" onclick="openTaskProject('${esc(s.serviceId)}')">الفكرة وإبداء الاهتمام — بدون التزام</button>`;
 if(['CANCELLED','FINANCIAL_CLOSED'].includes(s.project?.phase))return `<span class="badge">${esc(TASK_PROJECT_PHASE[s.project.phase])}</span>`;
 const shared=residentSharedState(s,q);
 if(shared&&shared.state!=='OPEN')return `<button type="button" class="btn-sm" onclick="openTaskProject('${esc(s.serviceId)}')">تفاصيل المهمة والحساب</button><span class="badge muted">${esc(shared.label)}</span>`;
 if(!q)return `<button class="btn-sm primary" onclick="requestService('${esc(s.serviceId)}',${s.autoRenewDefault?'true':'false'},${s.allowQuantity?'true':'false'})">طلب اشتراك</button>`;
 if(q.status==='PENDING')return `<button class="btn-sm" onclick="editPendingService('${esc(q.subscriptionId)}',${Number(q.quantity||1)},${s.allowQuantity?'true':'false'})">تعديل الطلب</button><button class="btn-sm danger-soft" onclick="cancelMyService('${esc(q.subscriptionId)}')">إلغاء الطلب</button>`;
 if(q.status!=='ACTIVE')return '';
 return `${s.allowQuantity?`<button class="btn-sm" onclick="requestServiceChangeUi('${esc(q.subscriptionId)}','ADD',${Number(q.quantity||1)},true)">زيادة الكمية</button>`:''}${s.cancelable?`<button class="btn-sm danger-soft" onclick="requestServiceChangeUi('${esc(q.subscriptionId)}','REDUCE',${Number(q.quantity||1)},${s.allowQuantity?'true':'false'})">طلب الإلغاء</button>`:''}`;
}
function residentTaskBalanceHtml(s){
 const f=s?.unitTaskFinance;
 if(f?.state!=='RECORDED')return `<span class="resident-task-ledger-state" role="status">${f?.state==='NOT_RECORDED'?'لم يُسجل مستحق رسمي للوحدة لهذه المهمة.':'المستحق والمدفوع والمتبقي غير متاحين حاليًا؛ افتح الصفحة مرة تانية.'}</span>`;
 return `<span>المستحق المعتمد: <strong>${money(f.due)}</strong></span><span>المدفوع للمستحق: <strong>${money(f.paid)}</strong></span><span>المتبقي: <strong>${money(f.remaining)}</strong></span>${Number(f.credit)>0?`<span>حق رد للوحدة: <strong>${money(f.credit)}</strong></span>`:''}${Number(f.refunded)>0?`<span>المردود للوحدة: <strong>${money(f.refunded)}</strong></span>`:''}`;
}
function residentServiceCard(s,q){
 const shared=residentSharedState(s,q);
 const financial=s.project?.phase==='PROPOSAL'?`<div class="resident-task-status"><strong>فكرة مقترحة — بدون التزام مالي</strong><p>${esc(s.project.scope||s.description||'')}</p><span>التكلفة التقريبية: ${money(s.totalBudget)}</span></div>`:shared?`<div class="resident-task-status" role="group" aria-label="حالة المهمة ونصيب الوحدة"><div class="resident-task-status-top"><strong>${esc(shared.status)}</strong><span class="badge ${shared.state==='FINALIZED'?'success':''}">${esc(shared.label)}</span></div><div class="resident-task-facts"><span>تكلفة المهمة: <strong>${money(s.totalBudget)}</strong></span>${s.responsibleName?`<span>مسؤول الحساب: <strong>${esc(s.responsibleName)}</strong></span>`:''}${shared.state!=='FINALIZED'?`<span>النصيب التقديري الحالي: <strong>${shared.share}</strong></span>`:residentTaskBalanceHtml(s)}${Number.isFinite(Number(s.activeSubscriberCount))&&s.activeSubscriberCount!=null?`<span>الوحدات المشاركة: <strong>${Number(s.activeSubscriberCount)}</strong></span>`:''}</div><p>${esc(shared.detail)}</p></div>`:
 q?`<div class="service-resident-summary"><span>العدد: ${Number(q.quantity||1)}</span><span>سعر الاشتراك: ${money(Number(q.unitPriceSnapshot??s.price))}</span><span>الإجمالي: ${money(Number(q.amountSnapshot||0))}</span></div>`:'';
 return `<article class="data-card service-card-clickable resident-service-card" role="button" tabindex="0" onclick="openResidentServiceDetails('${esc(s.serviceId)}')" onkeydown="if(event.target===this&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openResidentServiceDetails('${esc(s.serviceId)}')}"><div class="data-main"><div><strong>${esc(s.name)}</strong><span>${esc(s.description||'')}</span></div><strong>${shared?'مهمة لمرة واحدة':money(s.price)}</strong></div>${financial}${!shared?`<div class="data-meta"><span>${s.serviceKind==='ONE_TIME'?'خدمة لمرة واحدة':'خدمة دورية'}</span>${q?`<span class="badge ${q.status==='ACTIVE'?'success':'muted'}">${esc(subStatusLabel(q.status))}</span>`:''}</div>`:''}<div class="compact-actions resident-service-actions" onclick="event.stopPropagation()">${residentServiceActions(s,q)}</div></article>`;
}
function residentServicesSection(d){
 SERVICE_UI.services=Array.isArray(d.services)?d.services:[];SERVICE_UI.subscriptions=Array.isArray(d.subscriptions)?d.subscriptions:[];
 const current=id=>(d.subscriptions||[]).find(s=>s.serviceId===id&&['PENDING','ACTIVE'].includes(s.status));
 return `<section class="panel"><div class="panel-head"><div><h3>الخدمات والاشتراكات</h3><p>نفس حالة المهمة ونصيب الوحدة المعروضان في صفحة الخدمات.</p></div></div>${(d.services||[]).length?`<div class="list-stack">${d.services.map(s=>residentServiceCard(s,current(s.serviceId))).join('')}</div>`:emptyState('لا توجد خدمات متاحة','')}</section>`;
}

async function openMemberRequestModal(unitId){
  let titles;
  try {
    titles=await run('listTitles',true);
    if(!Array.isArray(titles))throw new Error('INVALID_TITLES_RESPONSE');
    const active=titles.filter(t=>t&&t.status==='ACTIVE'&&t.titleId&&t.label);
    if(!active.length){toast('لا توجد ألقاب نشطة متاحة. راجع إدارة الألقاب أو حاول لاحقًا.','error');return;}
    APP.titles=active;
    USER_UI.titles=titles;
  } catch(e){toast('تعذر تحميل الألقاب. حاول مرة أخرى. ' + errText(e),'error');return;}openModal(`<div class="modal-head"><div><h3>طلب إضافة عضو</h3><p>الإدارة تراجع الطلب قبل إنشاء العضوية والحساب.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitMemberRequest(event,'${esc(unitId)}')"><label class="field"><span>اللقب</span>${titleFields('mr','أ.')}</label><label class="field"><span>الاسم</span><input id="mrName" maxlength="80" required></label><label class="field"><span>الهاتف</span><input id="mrPhone" class="ltr-number" dir="ltr" inputmode="tel"></label><label class="field"><span>كود الدولة</span><input id="mrCountry" placeholder="+20"></label><label class="field span-2"><span>صلة القرابة</span>${relationFields('mr')}</label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">إرسال الطلب</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function submitMemberRequest(e,unitId){e.preventDefault();try{const p=Object.assign({unitId,name:$('mrName').value,phone:$('mrPhone').value,phoneCountry:$('mrCountry').value,relation:readRelation('mr')},readTitle('mr'));if(p.titleId==='__OTHER__'&&!p.customTitle){toast('اكتب اللقب المخصص أولًا.','error');return;}await run('requestUnitMember',p);closeModal();await renderUnits();toast('تم إرسال الطلب للإدارة.');}catch(x){toast(errText(x),'error');}}
async function openEditPendingMemberRequest(requestId){
 const available=(UNIT_UI.currentGovernance?.requests||[]).concat(...(UNIT_UI.currentGovernance?.units||[]).map(x=>x.requests||[]));
 const r=available.find(x=>x.requestId===requestId&&x.status==='PENDING');
 if(!r){toast('الطلب مش موجود أو لم يعد قابلًا للتعديل.','error');return;}
 try{
  const list=await run('listTitles',true);
  APP.titles=list.filter(t=>t.status==='ACTIVE');USER_UI.titles=list;
  if(!APP.titles.length)throw Error('لا توجد ألقاب متاحة.');
 }catch(e){toast('تعذر تحميل الألقاب: '+errText(e),'error');return;}
 openModal(`<div class="modal-head"><div><h3>تعديل طلب إضافة عضو</h3><p>متاح قبل قرار الإدارة فقط.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="savePendingMemberRequest(event,'${esc(r.requestId)}')"><label class="field"><span>اللقب</span>${titleFields('me',r.title||'',r.titleId||'',r.customTitle||(!r.titleId?r.title:''))}</label><label class="field"><span>الاسم</span><input id="meName" maxlength="80" required value="${esc(r.name)}"></label><label class="field"><span>الهاتف</span><input id="mePhone" class="ltr-number" dir="ltr" value="${esc(r.phone||'')}"></label><label class="field"><span>كود الدولة</span><input id="meCountry" value="${esc(r.phoneCountry||'')}"></label><label class="field span-2"><span>صلة القرابة</span>${relationFields('me',r.relation||'')}</label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ التعديل</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);

}
async function savePendingMemberRequest(e,requestId){e.preventDefault();try{
 const p=Object.assign({requestId,name:$('meName').value,phone:$('mePhone').value,phoneCountry:$('meCountry').value,relation:readRelation('me')},readTitle('me'));
 await run('updatePendingMemberRequest',p);closeModal();toast('تم تعديل الطلب، والإدارة هتشوف البيانات الجديدة.');await renderUnits();
 }catch(e){toast(errText(e),'error');}}
async function residentTransfer(unitId,userId){if(!await confirmAction({title:'نقل إدارة الوحدة',message:'ستصبح عضوًا عاديًا فورًا بعد نقل الإدارة.',confirmLabel:'نقل الإدارة'}))return;try{await run('transferUnitManager',unitId,userId);await renderUnits();toast('تم نقل الإدارة.');}catch(e){toast(errText(e),'error');}}
function emptyState(title,text){return `<div class="state-card empty-state"><strong>${esc(title)}</strong>${text?`<span>${esc(text)}</span>`:''}</div>`;}
function errorCard(e){const description=errText(e);LAST_ERROR_DETAILS='Tower App error\n'+description+'\nPage: '+String(APP.page||'unknown')+'\nTime: '+new Date().toISOString();return `<div class="state-card error-state" role="alert"><strong>تعذر تحميل البيانات</strong><span>${esc(description)}</span><button class="btn-sm" onclick="copyLastErrorDetails()" aria-label="نسخ تفاصيل الخطأ">⧉ نسخ تفاصيل الخطأ</button></div>`;}





const USER_UI={items:[],units:[],titles:[],filters:{search:'',role:'',status:'',unit:''}};
function userFilterMatch(u){const f=USER_UI.filters,m=userUnitMemberships(u),tokens=normAr((f.search||'').trim()).split(/\s+/).filter(Boolean),haystack=normAr([u.displayName,u.name,u.loginId,u.phone,u.email,userUnitsText(u)].filter(Boolean).join(' '));return (tokens.every(token=>haystack.includes(token)))&&(!f.role||u.role===f.role)&&(!f.status||u.status===f.status)&&(!f.unit||(f.unit==='__none__'?!m.length:m.some(x=>String(x.unitId)===f.unit)));}
function updatePeopleFilters(){const filtered=USER_UI.items.filter(userFilterMatch),list=document.getElementById('usersFilteredList'),count=document.getElementById('usersFilterCount');if(!list)return;list.innerHTML=filtered.length?filtered.map(userCardHtml).join(''):emptyState('لا يوجد أعضاء مطابقون للفلاتر','جرّب تعديل الفلاتر أو مسحها');if(count)count.textContent=`عرض ${filtered.length} من ${USER_UI.items.length} عضو` ;const reset=document.getElementById('usersFiltersReset');if(reset)reset.disabled=!Object.values(USER_UI.filters).some(Boolean);}
function setPeopleFilter(key,value){USER_UI.filters[key]=value;updatePeopleFilters();}
function resetPeopleFilters(){USER_UI.filters={search:'',role:'',status:'',unit:''};for(const id of ['usersSearch','usersRole','usersStatus','usersUnit']){const el=document.getElementById(id);if(el)el.value='';}updatePeopleFilters();}
function userCardHtml(u){return `<article class="data-card record-card" role="button" tabindex="0" onkeydown="if((event.key==='Enter'||event.key===' ')&&event.target===this){event.preventDefault();openUserDetailsById(this.dataset.userId)}" data-user-id="${esc(u.userId)}" onclick="openUserDetailsById('${esc(u.userId)}')"><div class="data-main"><div><strong>${esc(personName(u))}</strong><span>${esc(u.roleLabel)} · ${ltrId(u.loginId)}</span></div><span class="badge ${u.status==='ACTIVE'?'success':'muted'}">${u.status==='ACTIVE'?'نشط':u.status==='INACTIVE'?'غير نشط':'مؤرشف'}</span></div><div class="data-meta"><span>${esc(userUnitsText(u))}</span><span>${u.phone?phoneDisplay(u.phone):esc(u.email||'')}</span></div><div class="compact-actions"><button class="btn-sm" onclick="event.stopPropagation();openUserDetailsById('${esc(u.userId)}')">عرض</button><button class="btn-sm" onclick="event.stopPropagation();resetUserPin('${esc(u.userId)}')">PIN جديد</button></div></article>`;}
function userFiltersHtml(){const f=USER_UI.filters;const roles=[['ADMIN','الأدمن'],['UNION','رئيس الاتحاد'],['OPERATOR','الحارس'],['RESIDENT','الساكن']];return `<div class="user-filters" role="search" aria-label="فلترة الأعضاء"><label class="field"><span>بحث بالاسم أو رقم الدخول</span><input id="usersSearch" type="search" placeholder="اسم، لقب، رقم دخول أو وحدة" autocomplete="off" value="${esc(f.search)}" oninput="setPeopleFilter('search',this.value)"></label><label class="field"><span>الدور</span><select id="usersRole" onchange="setPeopleFilter('role',this.value)"><option value="">كل الأدوار</option>${roles.map(([value,label])=>`<option value="${value}" ${f.role===value?'selected':''}>${label}</option>`).join('')}</select></label><label class="field"><span>الحالة</span><select id="usersStatus" onchange="setPeopleFilter('status',this.value)"><option value="">كل الحالات</option>${[['ACTIVE','نشط'],['INACTIVE','غير نشط'],['ARCHIVED','مؤرشف']].map(([v,l])=>`<option value="${v}" ${f.status===v?'selected':''}>${l}</option>`).join('')}</select></label><label class="field"><span>الوحدة</span><select id="usersUnit" onchange="setPeopleFilter('unit',this.value)"><option value="">كل الوحدات</option>${USER_UI.units.map(x=>`<option value="${esc(x.unitId)}" ${f.unit===String(x.unitId)?'selected':''}>الوحدة ${esc(unitNo(x.unitNumber))}</option>`).join('')}<option value="__none__" ${f.unit==='__none__'?'selected':''}>بدون وحدة</option></select></label><div class="user-filter-footer"><span id="usersFilterCount" aria-live="polite"></span><button type="button" class="btn-sm" id="usersFiltersReset" onclick="resetPeopleFilters()">مسح الفلاتر</button></div></div>`;}

// UNION and ADMIN use the same member directory filters. Official membership decisions stay ADMIN-only.
async function renderUnionPeople(){
 const c=$('content');c.innerHTML=pageLoading('جاري تحميل الأعضاء…');
 try{
  const [people,units,titles]=await Promise.all([run('adminListUsers'),run('listUnits'),run('listTitles',true)]);
  USER_UI.items=people;USER_UI.units=units;USER_UI.titles=titles;APP.titles=titles.filter(x=>x.status==='ACTIVE');
  USER_UI.filters={search:'',role:'',status:'',unit:''};
  c.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>إدارة الأعضاء</h3><p>البحث والتصفية وإدارة الحسابات من مكان واحد. اعتماد طلبات العضوية من صلاحيات الأدمن ورئيس الاتحاد.</p></div><div class="compact-actions"><button class="btn-sm primary" onclick="openNewUserModal()">+ عضو</button></div></div></section><section class="panel"><div class="panel-head"><h3>الحسابات المسجلة</h3></div>${userFiltersHtml()}<div id="usersFilteredList" class="list-stack"></div></section>`;
  updatePeopleFilters();
 }catch(e){c.innerHTML=errorCard(e);}
}
async function renderPeople(){const c=$('content');if(!['ADMIN','UNION'].includes(APP.ctx.user.role)){renderPlanned('people','الأعضاء');return;}c.innerHTML=pageLoading('جاري تحميل المستخدمين…');try{const r=await Promise.all([run('adminListUsers'),run('listUnits'),run('listTitles',true),run('listMemberRequests')]);USER_UI.items=r[0];USER_UI.units=r[1];USER_UI.titles=r[2];USER_UI.memberRequests=r[3]||[];peopleMemberHistoryVisible=false;APP.titles=r[2].filter(x=>x.status==='ACTIVE');c.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>إدارة الأعضاء</h3><p>حساب الساكن يرتبط بوحدة، وUser ID الخاص بالدخول يتولد تلقائيًا من الدور + الوحدة + تسلسل الساكن.</p></div><div class="compact-actions"><button class="btn-sm" onclick="openTitlesManager()">الألقاب</button><button class="btn-sm" onclick="openBulkResidentsModal()">مجموعة</button><button class="btn-sm primary" onclick="openNewUserModal()">+ عضو</button></div></div></section><section class="panel" id="people-member-requests"><div class="panel-head"><div><h3>طلبات إضافة الأعضاء</h3><p>تظهر هنا نفس الطلبات الموجودة في الوحدات، مع رأي المدير الرسمي وحالة القرار.</p></div><span class="badge">${USER_UI.memberRequests.filter(x=>x.status==='PENDING').length} معلّق</span></div><div id="peopleMemberRequestsList" class="list-stack"></div><div class="section-actions"><button type="button" class="btn-sm" id="peopleMemberHistoryToggle" onclick="togglePeopleMemberHistory()">عرض سجل الطلبات المنتهية</button></div></section><section class="panel"><div class="panel-head"><h3>الحسابات المسجلة</h3></div>${userFiltersHtml()}<div id="usersFilteredList" class="list-stack"></div></section>`;updatePeopleFilters();renderPeopleMemberRequests();}catch(e){c.innerHTML=errorCard(e);}}


function memberOpinionLabel(r){return r.managerOpinion==='SUPPORT'?'مؤيد':r.managerOpinion==='OBJECT'?'معترض':'لم يُبدِ رأيًا بعد';}
// Keep pending work actionable and completed requests in an optional history.
let peopleMemberHistoryVisible=false;
function peopleMemberRequestCard(r){
 const unit=(USER_UI.units||[]).find(u=>String(u.unitId)===String(r.unitId));
 const pending=r.status==='PENDING',id=esc(r.requestId);
 return `<article class="data-card" id="member-request-${id}"><div class="data-main"><div><strong>${esc(personName(r))}</strong><span>الوحدة ${esc(unit?unitNo(unit.unitNumber):'—')} · ${esc(r.relation||'')}</span></div><span class="badge ${pending?'warning-badge':'muted'}">${esc(({PENDING:'قيد المراجعة',APPROVED:'مقبول',REJECTED:'مرفوض',CANCELED:'ملغي'})[r.status]||r.status)}</span></div><div class="data-meta"><span>رأي المدير: ${esc(memberOpinionLabel(r))}</span>${r.managerOpinionAt?`<span>${esc(displayDateTime12(r.managerOpinionAt))}</span>`:''}${r.managerOpinionNote?`<span>${esc(r.managerOpinionNote)}</span>`:''}<span>الطلب: ${esc(displayDateTime12(r.createdAt))}</span>${r.requestedByName?`<span>مقدم الطلب: ${esc(r.requestedByName)}</span>`:''}</div><div class="compact-actions"><button class="btn-sm" onclick="openPeopleMemberRequestDetails('${id}')">التفاصيل</button></div></article>`;
}
function renderPeopleMemberRequests(focusId=''){
 const host=$('peopleMemberRequestsList');if(!host)return;
 const all=[...(USER_UI.memberRequests||[])].sort((a,b)=>(Date.parse(b.createdAt)||0)-(Date.parse(a.createdAt)||0));
 const pending=all.filter(x=>x.status==='PENDING'),complete=all.filter(x=>x.status!=='PENDING');
 host.innerHTML=pending.length?pending.map(peopleMemberRequestCard).join(''):emptyState('لا توجد طلبات معلقة','كل طلبات إضافة الأعضاء تمت مراجعتها.');
 const toggle=$('peopleMemberHistoryToggle');if(toggle){toggle.textContent=`سجل الطلبات المنتهية (${complete.length})`;toggle.setAttribute('aria-label',`فتح سجل الطلبات المنتهية وعددها ${complete.length}`);}
 if(focusId){const found=all.find(r=>String(r.requestId)===String(focusId));if(found)openPeopleMemberRequestDetails(String(focusId));else toast('الطلب المحدد غير موجود أو لم يعد متاحًا.','warning');}
}
function togglePeopleMemberHistory(){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role))return;
 const complete=[...(USER_UI.memberRequests||[])].filter(r=>r.status!=='PENDING').sort((a,b)=>(Date.parse(b.createdAt)||0)-(Date.parse(a.createdAt)||0));
 openModal(`<div class="modal-head"><div><h3>سجل طلبات الأعضاء المنتهية</h3><p>${complete.length} طلب · للعرض عند الحاجة فقط</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق السجل">×</button></div><div class="list-stack" style="max-height:65vh;overflow:auto">${complete.length?complete.map(peopleMemberRequestCard).join(''):emptyState('السجل فارغ','لا توجد طلبات منتهية.')}</div><div class="form-actions"><button class="btn-sm" onclick="closeModal()">إغلاق</button></div>`);
}
function openPeopleMemberRequestDetails(requestId){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role))return;
 const r=(USER_UI.memberRequests||[]).find(x=>String(x.requestId)===String(requestId));if(!r){toast('هذا الطلب غير متاح. حدّث الصفحة وحاول مرة أخرى.','warning');return;}
 const unit=(USER_UI.units||[]).find(x=>String(x.unitId)===String(r.unitId));const pending=r.status==='PENDING',id=esc(r.requestId);
 openModal(`<div class="modal-head"><div><h3>تفاصيل طلب إضافة عضو</h3><p>الوحدة ${esc(unit?unitNo(unit.unitNumber):'—')} · ${esc(r.status==='PENDING'?'قيد المراجعة':'طلب منتهٍ')}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="list-stack mini-list"><div class="member-line"><div><strong>${esc(personName(r))}</strong><span>${esc(r.relation||'صلة القرابة غير محددة')}</span></div></div><div class="member-line"><div><strong>رأي المدير الرسمي</strong><span>${esc(memberOpinionLabel(r))}</span>${r.managerOpinionNote?`<small>${esc(r.managerOpinionNote)}</small>`:''}</div></div>${r.requestedByName?`<div class="member-line"><div><strong>مقدم الطلب</strong><span>${esc(r.requestedByName)}</span></div></div>`:''}<div class="member-line"><div><strong>تاريخ الطلب</strong><span>${esc(displayDateTime12(r.createdAt))}</span></div></div></div><div class="form-actions">${pending?`<button class="btn-sm primary" onclick="openApproveRequestModal('${id}')">موافقة</button><button class="btn-sm danger-soft" onclick="closeModal();rejectMemberRequest('${id}')">رفض</button>`:''}<button class="btn-sm" onclick="closeModal()">إغلاق</button></div>`);
}
async function openPeopleMemberRequests(requestId=''){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role)){await go('units');return;}
 await go('people');document.getElementById('people-member-requests')?.scrollIntoView({block:'start'});renderPeopleMemberRequests(String(requestId||''));
}

function userById(id){return USER_UI.items.find(x=>x.userId===id);}
function userUnitMemberships(u){return Array.isArray(u.memberships)?u.memberships:(u.membership?[u.membership]:[]);}
function userUnitsText(u){const memberships=userUnitMemberships(u);return memberships.length?memberships.map(m=>{const unit=USER_UI.units.find(x=>x.unitId===m.unitId);return `وحدة ${unit?unitNo(unit.unitNumber):m.unitId} (${m.memberRole==='MANAGER'?'مدير':'عضو'})`;}).join('، '):'غير مرتبط بوحدة';}
function userUnitsSelector(u){const memberships=userUnitMemberships(u),ids=new Set(memberships.map(m=>m.unitId));return `<div class="span-2"><label class="field"><span>الوحدات المرتبط بها الساكن</span></label><div class="list-stack">${USER_UI.units.map(x=>`<label class="bulk-select-row"><input type="checkbox" data-resident-unit value="${esc(x.unitId)}" ${ids.has(x.unitId)?'checked':''}><span>الوحدة ${esc(unitNo(x.unitNumber))} — ${esc(x.floor||'')} ${memberships.some(m=>m.unitId===x.unitId&&m.memberRole==='MANAGER')?'(مدير الوحدة)':''}</span></label>`).join('')}</div><small>تغيير العضوية لا ينقل إدارة الوحدة. انقل الإدارة أولًا قبل إلغاء عضوية المدير.</small></div>`;}
function userShareText(u){return westernDigits(`${personName(u)}
معرف الدخول: ${u.loginId||''}
الهاتف: ${u.phone||''}
الحالة: ${u.status||''}`);}
function openUserDetailsById(id){const u=userById(id);if(!u)return;openModal(`<div class="modal-head"><div><h3>${esc(personName(u))}</h3><p>${esc(u.roleLabel)} · ${ltrId(u.loginId)}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-grid"><div><span>معرف الدخول</span><strong>${ltrId(u.loginId)}</strong></div><div><span>الهاتف</span><strong>${phoneDisplay(u.phone)}</strong></div><div><span>البريد الإلكتروني</span><strong>${esc(u.email||'—')}</strong></div>${u.role==='RESIDENT'?`<div class="span-2"><span>الوحدات</span><strong>${esc(userUnitsText(u))}</strong></div>`:''}<div><span>الحالة</span><strong>${esc(({ACTIVE:'نشط',INACTIVE:'غير نشط',ARCHIVED:'مؤرشف'})[u.status]||u.status)}</strong></div></div><div class="detail-actions"><button class="icon-action" onclick="copyUserDetails('${esc(u.userId)}')">⧉<span>نسخ</span></button><button class="icon-action" onclick="shareUserDetails('${esc(u.userId)}')">↗<span>مشاركة</span></button><button class="icon-action" onclick='closeModal();openEditUserModal(${JSON.stringify(u)})'>✎<span>تعديل</span></button>${u.role==='RESIDENT'&&u.status!=='ARCHIVED'?`<button class="icon-action danger" onclick="archiveResident('${esc(u.userId)}')">×<span>حذف</span></button>`:''}</div>`);}
async function copyUserDetails(id){const u=userById(id);if(!u)return;try{await navigator.clipboard.writeText(userShareText(u));toast('تم نسخ بيانات الساكن.');}catch(e){toast('تعذر النسخ.','error');}}
async function shareUserDetails(id){const u=userById(id);if(!u)return;const text=userShareText(u);try{if(navigator.share){await navigator.share({title:u.displayName||'Tower App',text});return;}await navigator.clipboard.writeText(text);toast('المشاركة غير مدعومة؛ تم نسخ البيانات.');}catch(e){if(e&&e.name!=='AbortError')toast('تعذر المشاركة.','error');}}
async function archiveResident(id){const u=userById(id);if(!u)return;if(!await confirmAction({title:'أرشفة الساكن',message:`حذف ${personName(u)} من الوحدة وأرشفة الحساب؟`,warning:'سيظل التاريخ المالي محفوظًا.',danger:true,confirmLabel:'أرشفة'}))return;try{await run('adminArchiveResident',id);closeModal();await renderPeople();toast('تم أرشفة الساكن وفك عضويته من الوحدة.');}catch(e){toast(errText(e),'error');}}
function roleOptions(selected){return Object.entries({ADMIN:'إدارة',UNION:'اتحاد الشاغلين',RESIDENT:'ساكن',OPERATOR:'حارس'}).map(([v,l])=>`<option value="${v}" ${v===selected?'selected':''}>${l}</option>`).join('');}
function residentUnitOptions(){return USER_UI.units.filter(u=>u.status==='ACTIVE').map(u=>`<option value="${esc(u.unitId)}">الوحدة ${esc(unitNo(u.unitNumber))} · الدور ${esc(floorNo(u.floor))}</option>`).join('');}
async function openNewUserModal(){try{const titles=await run('listTitles',true);USER_UI.titles=titles;APP.titles=titles.filter(x=>x.status==='ACTIVE');}catch(e){toast('تعذر تحميل الألقاب: '+errText(e),'error');return;}openModal(`<div class="modal-head"><div><h3>إضافة عضو</h3><p>للساكن: User ID تلقائي وPIN الافتراضي 123456 وقابل للتعديل قبل الحفظ.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitNewUser(event)"><label class="field"><span>اللقب</span>${titleFields('usr','أ.')}</label><label class="field"><span>الاسم</span><input id="usrName" required></label><label class="field"><span>الدور</span><select id="usrRole" onchange="syncNewUserRole()">${roleOptions('RESIDENT')}</select></label><label class="field resident-only"><span>الوحدة</span><select id="usrUnit" onchange="refreshResidentIdPreview()" required><option value="">اختر الوحدة</option>${residentUnitOptions()}</select></label><div class="resident-only span-2"><label class="field"><span>وحدات إضافية — اختياري</span></label><details class="extra-units-picker"><summary>اختيار وحدات إضافية (اختياري)</summary><input type="search" placeholder="ابحث عن وحدة…" oninput="filterExtraUnits(this)"><div class="list-stack extra-units-options">${USER_UI.units.map(u=>`<label class="bulk-select-row"><input type="checkbox" data-new-resident-unit value="${esc(u.unitId)}"><span>وحدة ${esc(unitNo(u.unitNumber))}</span></label>`).join('')}</div></details></div><label class="field resident-only"><span>User ID — تلقائي</span><input id="usrResidentId" class="ltr-id" dir="ltr" value="—" readonly></label><label class="field nonresident-only hidden"><span>Login ID</span><input id="usrLogin" class="ltr-id" dir="ltr" inputmode="latin" maxlength="32"></label><label class="field"><span>PIN</span>${pinInputHtml("usrPin","new-password","123456")}</label><label class="field"><span>الهاتف</span><input id="usrPhone" class="ltr-number" dir="ltr" inputmode="tel"></label><label class="field span-2"><span>Email — اختياري</span><input id="usrEmail" type="email"></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">إنشاء الحساب</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);syncNewUserRole();}
function syncNewUserRole(){const resident=$('usrRole')&&$('usrRole').value==='RESIDENT';document.querySelectorAll('.resident-only').forEach(x=>x.classList.toggle('hidden',!resident));document.querySelectorAll('.nonresident-only').forEach(x=>x.classList.toggle('hidden',resident));if($('usrUnit'))$('usrUnit').required=resident;if($('usrLogin'))$('usrLogin').required=!resident;if(resident)refreshResidentIdPreview();}
async function refreshResidentIdPreview(){const unitId=$('usrUnit')?$('usrUnit').value:'';if(!$('usrResidentId'))return;$('usrResidentId').value=unitId?'جاري التوليد…':'—';if(!unitId)return;try{const r=await run('adminPreviewResidentLoginId',unitId);$('usrResidentId').value=r.loginId;}catch(e){$('usrResidentId').value='—';toast(errText(e),'error');}}
async function submitNewUser(e){e.preventDefault();const role=$('usrRole').value,p=Object.assign({name:$('usrName').value,role,pin:$('usrPin').value,phone:$('usrPhone').value,email:$('usrEmail').value},readTitle('usr'));if(role==='RESIDENT')p.unitId=$('usrUnit').value;else p.loginId=$('usrLogin').value;try{const r=await run('adminCreateUser',p);if(role==='RESIDENT'&&r.userId){const ids=[...new Set([...document.querySelectorAll('[data-new-resident-unit]:checked')].map(x=>x.value).filter(id=>id&&id!==p.unitId))];if(ids.length){try{await run('adminSetResidentUnits',{userId:r.userId,unitIds:[p.unitId,...ids]});}catch(linkError){toast('تم إنشاء الحساب الأساسي بنجاح، لكن تعذر ربط الوحدات الإضافية المحددة: '+errText(linkError),'error');}}}openCredentialsResult(r,'تم إنشاء المستخدم');await (APP.ctx?.user?.role==='UNION'?renderUnionPeople():renderPeople());}catch(x){toast(errText(x),'error');}}
function credentialShareText(r){return westernDigits(`بيانات الدخول إلى Tower App
معرف الدخول: ${r.loginId||''}
PIN المؤقت: ${r.pin||''}`);}
async function copyCredentialValue(v,label){try{await navigator.clipboard.writeText(String(v||''));toast(`تم نسخ ${label}.`);}catch(e){toast('تعذر النسخ.','error');}}
async function shareCredentials(r){const text=credentialShareText(r);try{if(navigator.share){await navigator.share({title:'بيانات الدخول — Tower App',text});return;}await navigator.clipboard.writeText(text);toast('المشاركة غير مدعومة؛ تم نسخ بيانات الدخول.');}catch(e){if(e&&e.name!=='AbortError')toast('تعذر المشاركة.','error');}}
function openCredentialsResult(r,title){window.LAST_CREDENTIALS=r;openModal(`<div class="modal-head"><div><h3>${esc(title)}</h3><p>انسخ أو شارك البيانات الآن؛ PIN لا يُخزن كنص صريح.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="credential-box credential-actions-box"><span>User ID / Login ID</span><div class="credential-line"><strong>${ltrId(r.loginId)}</strong><button class="icon-action" onclick="copyCredentialValue('${esc(r.loginId)}','معرف الدخول')">⧉<span>نسخ</span></button></div><span>Temporary PIN</span><div class="credential-line"><strong>${ltrId(r.pin)}</strong><button class="icon-action" onclick="copyCredentialValue('${esc(r.pin)}','PIN')">⧉<span>نسخ</span></button></div></div><div class="detail-actions"><button class="icon-action" onclick="shareCredentials(window.LAST_CREDENTIALS)">↗<span>مشاركة</span></button></div><div class="form-actions"><button class="btn-sm primary" onclick="closeModal();${APP.page==='people'?(APP.ctx?.user?.role==='UNION'?'renderUnionPeople()':'renderPeople()'):'renderUnits()'}">تم</button></div>`);}
function bulkFloorOptions(){const floors=[...new Set((USER_UI.units||[]).filter(u=>u.status==='ACTIVE').map(u=>String(u.floor??'').trim()))].filter(Boolean).sort((a,b)=>Number(a)-Number(b));return floors.map(f=>`<option value="${esc(f)}">${esc(floorNo(f))}</option>`).join('');}
function bulkResidentRowHtml(i){return `<div class="bulk-user-row" data-bulk-row="${i}"><div class="bulk-row-header"><span class="bulk-row-no" aria-label="ساكن ${i+1}">${i+1}</span><div class="bulk-row-tools"><button class="icon-btn bulk-more" type="button" onclick="toggleBulkExtra(this)" aria-label="البيانات الإضافية" aria-expanded="false" title="البيانات الإضافية">⋯</button><button class="icon-btn bulk-copy" type="button" onclick="copyBulkResidentPlace(this)" aria-label="نسخ الدور والوحدة من السطر السابق" title="نسخ الدور والوحدة من السطر السابق">⧉</button><button class="icon-btn bulk-remove" type="button" onclick="removeBulkResidentRow(this)" aria-label="حذف السطر" title="حذف السطر">×</button></div></div><div class="bulk-main-fields"><label class="field bulk-title-field"><span class="bulk-visually-hidden">اللقب</span><select aria-label="اللقب" data-k="titleId" onchange="this.parentElement.querySelector('[data-k=customTitle]').classList.toggle('hidden',this.value!=='__OTHER__')">${titleOptions('أ.')}</select><input aria-label="لقب مخصص" data-k="customTitle" class="hidden" placeholder="اللقب" maxlength="40"></label><label class="field bulk-name-field"><span class="bulk-visually-hidden">الاسم</span><input aria-label="الاسم" data-k="name" placeholder="الاسم" autocomplete="off"></label></div><div class="bulk-place-fields"><label class="field"><span class="bulk-visually-hidden">الدور</span><select aria-label="الدور" data-k="floor" onchange="bulkFloorChanged(this)"><option value="">الدور</option>${bulkFloorOptions()}</select></label><label class="field"><span class="bulk-visually-hidden">الوحدة</span><select aria-label="الوحدة" data-k="unitId" disabled><option value="">الوحدة</option></select></label></div><div class="bulk-extra"><label class="field"><span class="bulk-visually-hidden">PIN</span><div class="pin-field"><input aria-label="PIN" id="bulkPin${i}" type="password" class="ltr-id" dir="ltr" data-k="pin" inputmode="numeric" maxlength="8" value="123456"><button type="button" class="pin-eye" onclick="togglePinVisibility('bulkPin${i}',this)" aria-label="إظهار PIN">◉</button></div></label><label class="field"><span class="bulk-visually-hidden">الهاتف</span><input aria-label="الهاتف" placeholder="الهاتف" data-k="phone" class="ltr-number" dir="ltr" inputmode="tel"></label><label class="field"><span class="bulk-visually-hidden">إيميل</span><input aria-label="إيميل" placeholder="إيميل" data-k="email" type="email"></label></div></div>`;}
function bulkFloorChanged(sel){const row=sel.closest('.bulk-user-row'),unit=row?.querySelector('[data-k="unitId"]');if(!unit)return;const floor=sel.value;const units=(USER_UI.units||[]).filter(u=>u.status==='ACTIVE'&&String(u.floor??'').trim()===floor);unit.innerHTML=`<option value="">${!floor?'الوحدة':units.length?'الوحدة':'لا توجد وحدات'}</option>`+units.map(u=>`<option value="${esc(u.unitId)}">${esc(unitNo(u.unitNumber))}</option>`).join('');unit.disabled=!floor||!units.length;}
function toggleBulkExtra(btn){const row=btn.closest('.bulk-user-row');const open=row.classList.toggle('bulk-extra-open');btn.setAttribute('aria-expanded',String(open));}
function copyBulkResidentPlace(btn){const row=btn.closest('.bulk-user-row'),prev=row.previousElementSibling;if(!prev)return;const floor=prev.querySelector('[data-k="floor"]')?.value||'',unit=prev.querySelector('[data-k="unitId"]')?.value||'';const sel=row.querySelector('[data-k="floor"]');sel.value=floor;bulkFloorChanged(sel);row.querySelector('[data-k="unitId"]').value=unit;}
function openBulkResidentsModal(){openModal(`<div class="modal-head"><div><h3>إضافة / تعديل مجموعة ساكنين</h3><p>اختر إنشاء حسابات جديدة أو تنفيذ تعديل جماعي آمن على حسابات موجودة.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="choice-grid"><button class="choice-card" onclick="openBulkResidentsCreate()"><strong>+ إضافة مجموعة</strong><span>إنشاء عدة سكان وUser IDs تلقائيًا.</span></button><button class="choice-card" onclick="openBulkResidentsEdit()"><strong>✎ تعديل مجموعة</strong><span>حالة، لقب أو Reset PIN جماعي.</span></button></div>`);}
function bulkResidentSelectRows(){return (USER_UI.items||[]).filter(u=>u.role==='RESIDENT').map(u=>`<label class="bulk-select-row"><input type="checkbox" data-bulk-user value="${esc(u.userId)}"><span><strong>${esc(u.displayName)}</strong><small>${ltrId(u.loginId)} · ${esc(u.status)}</small></span></label>`).join('');}
function filterBulkResidentList(input){return uiFilterCollection(input,'.bulk-select-row',$('bulkResidentSearchList'),'bulkResidentSearch');}
function openBulkResidentsEdit(){openModal(`<div class="modal-head"><div><h3>تعديل مجموعة ساكنين</h3><p>حدد الحسابات ثم العملية. ستظهر معاينة قبل التنفيذ.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="bulk-manage-layout"><div class="ui-search-selection"><div class="filter-toolbar"><input id="bulkResidentSearch" type="search" autocomplete="off" oninput="filterBulkResidentList(this)" placeholder="بحث في السكان" aria-label="بحث في السكان"><button type="button" class="btn-sm" id="bulkResidentSearchClear" disabled onclick="clearUiSearch('bulkResidentSearch',filterBulkResidentList)">مسح</button></div><p id="bulkResidentSearchCount" class="selection-count" role="status" aria-live="polite">عرض الكل</p><div class="bulk-select-list" id="bulkResidentSearchList">${bulkResidentSelectRows()}</div><p id="bulkResidentSearchEmpty" class="selection-count" hidden>لا توجد نتائج مطابقة. جرّب كلمة أخرى.</p></div><div><label class="field"><span>العملية</span><select id="bulkResidentAction" onchange="syncBulkResidentAction()"><option value="STATUS">تغيير الحالة</option><option value="TITLE">تغيير اللقب</option><option value="RESET_PIN">Reset PIN</option></select></label><div id="bulkResidentActionFields"></div><div id="bulkResidentPreview" class="state-card hidden"></div><div class="form-actions"><button class="btn-sm" onclick="previewBulkResidents()">معاينة</button><button id="bulkResidentApply" class="btn-sm primary" disabled onclick="applyBulkResidents()">تنفيذ</button></div></div></div>`,true);syncBulkResidentAction();filterBulkResidentList($('bulkResidentSearch'));}
function selectedBulkResidentIds(){return [...document.querySelectorAll('[data-bulk-user]:checked')].map(x=>x.value);}
function syncBulkResidentAction(){const a=$('bulkResidentAction').value,b=$('bulkResidentActionFields');if(a==='STATUS')b.innerHTML=`<label class="field"><span>الحالة الجديدة</span><select id="bulkResidentStatus"><option value="ACTIVE">نشط</option><option value="INACTIVE">غير نشط</option><option value="ARCHIVED">مؤرشف</option></select></label>`;else if(a==='TITLE')b.innerHTML=`<label class="field"><span>اللقب الجديد</span>${titleFields('bulkResident','أ.')}</label>`;else b.innerHTML=`<div class="state-card warning-state"><strong>Reset PIN جماعي</strong><span>سيتم إلغاء الجلسات الحالية وإصدار PIN مختلف لكل ساكن.</span></div>`;if($('bulkResidentApply'))$('bulkResidentApply').disabled=true;if($('bulkResidentPreview'))$('bulkResidentPreview').classList.add('hidden');}
function previewBulkResidents(){const ids=selectedBulkResidentIds();if(!ids.length){toast('اختر ساكنًا واحدًا على الأقل.','error');return;}const a=$('bulkResidentAction').value,labels={STATUS:'تغيير الحالة',TITLE:'تغيير اللقب',RESET_PIN:'Reset PIN'};$('bulkResidentPreview').innerHTML=`<strong>معاينة</strong><span>سيتم تنفيذ «${labels[a]}» على ${ids.length} ساكن.</span>`;$('bulkResidentPreview').classList.remove('hidden');$('bulkResidentApply').disabled=false;}
async function applyBulkResidents(){const userIds=selectedBulkResidentIds(),action=$('bulkResidentAction').value,p={userIds,action};if(action==='STATUS')p.status=$('bulkResidentStatus').value;if(action==='TITLE')Object.assign(p,readTitle('bulkResident'));if(!await confirmAction({title:'تأكيد التعديل الجماعي',message:`سيتم تنفيذ العملية على ${userIds.length} ساكن.`,confirmLabel:'تنفيذ'}))return;try{const r=await run('adminBulkUpdateResidents',p);if(action==='RESET_PIN')openBulkCredentialsResult(r);else{closeModal();toast(`تم تعديل ${r.count} ساكن.`);}await renderPeople();}catch(e){toast(errText(e),'error');}}
function openBulkResidentsCreate(){openModal(`<div class="modal-head"><div><h3>إضافة مجموعة ساكنين</h3><p>User ID يتولد من الوحدة، وPIN الافتراضي 123456 ويمكن تغييره.</p></div></div><form id="bulkResidentsForm" novalidate onsubmit="submitBulkResidents(event)"><div class="bulk-count-control"><label for="bulkRowCount">عدد السطور</label><input id="bulkRowCount" type="number" inputmode="numeric" min="1" max="50" value="3" onchange="setBulkResidentCount(this.value)"></div><div id="bulkResidentsRows" class="bulk-user-list">${Array.from({length:3},(_,i)=>bulkResidentRowHtml(i)).join('')}</div><div class="bulk-user-actions"><button class="btn-sm" type="button" onclick="addBulkResidentRow()">+ سطر</button><span class="muted-note">الحد الأقصى 50 ساكنًا في الدفعة.</span></div><div class="bulk-floating-actions"><button type="button" class="btn-sm danger-soft" onclick="cancelBulkResidents()" aria-label="إلغاء" title="إلغاء">✕ <span class="bulk-action-text">إلغاء</span></button><span id="bulkValidCount" aria-live="polite"></span><button class="btn-sm primary" type="submit" aria-label="مراجعة إنشاء الحسابات" title="مراجعة إنشاء الحسابات">✓ <span class="bulk-action-text">مراجعة الإنشاء</span></button></div></form>`,true);$('modalSheet')?.classList.add('bulk-create-sheet');$('bulkResidentsRows')?.addEventListener('input',updateBulkResidentCount);}
function bulkResidentUsed(row){const get=k=>row.querySelector(`[data-k="${k}"]`)?.value?.trim()||'';return !!(get('name')||get('floor')||get('unitId')||get('phone')||get('email')||get('customTitle')||(get('pin')&&get('pin')!=='123456'));}
function updateBulkResidentCount(){const rows=[...document.querySelectorAll('#bulkResidentsRows .bulk-user-row')];const active=rows.filter(bulkResidentUsed).length;const el=$('bulkValidCount');if(el)el.textContent=`${active} مستخدم مُدخل`;} 
function setBulkResidentCount(n){const box=$('bulkResidentsRows');if(!box)return;const count=Math.max(1,Math.min(50,Math.floor(Number(n)||1)));const rows=[...box.querySelectorAll('.bulk-user-row')];if(count<rows.length&&rows.slice(count).some(bulkResidentUsed)&&!confirm('تقليل العدد سيحذف بيانات السطور الأخيرة. هل تريد المتابعة؟')){if($('bulkRowCount'))$('bulkRowCount').value=rows.length;return;}if(count<rows.length)rows.slice(count).forEach(r=>r.remove());else for(let i=rows.length;i<count;i++)box.insertAdjacentHTML('beforeend',bulkResidentRowHtml(i));renumberBulkResidentRows();updateBulkResidentCount();if($('bulkRowCount'))$('bulkRowCount').value=count;}
function cancelBulkResidents(){if([...document.querySelectorAll('#bulkResidentsRows .bulk-user-row')].some(bulkResidentUsed)&&!confirm('إلغاء الإدخال وفقدان البيانات المكتوبة؟'))return;closeModal();}
function renumberBulkResidentRows(){document.querySelectorAll('#bulkResidentsRows .bulk-user-row').forEach((row,i)=>{row.dataset.bulkRow=i;const n=row.querySelector('.bulk-row-no');if(n){n.textContent=i+1;n.setAttribute('aria-label',`ساكن ${i+1}`);}});}
function addBulkResidentRow(){const box=$('bulkResidentsRows');if(!box)return;const count=box.querySelectorAll('.bulk-user-row').length;if(count>=50){toast('الحد الأقصى 50 ساكنًا في الدفعة.','error');return;}box.insertAdjacentHTML('beforeend',bulkResidentRowHtml(count));if($('bulkRowCount'))$('bulkRowCount').value=count+1;updateBulkResidentCount();}
function removeBulkResidentRow(btn){const box=$('bulkResidentsRows');if(!box)return;const rows=box.querySelectorAll('.bulk-user-row');if(rows.length===1){toast('اترك سطرًا واحدًا على الأقل.','error');return;}btn.closest('.bulk-user-row').remove();renumberBulkResidentRows();if($('bulkRowCount'))$('bulkRowCount').value=box.querySelectorAll('.bulk-user-row').length;updateBulkResidentCount();}
function collectBulkResidents(){return [...document.querySelectorAll('#bulkResidentsRows .bulk-user-row')].map((row,i)=>{const get=k=>{const el=row.querySelector(`[data-k="${k}"]`);return el?el.value:'';};return{row:i+1,name:get('name').trim(),titleId:get('titleId'),customTitle:get('customTitle').trim(),unitId:get('unitId'),pin:get('pin').trim()||'123456',phone:get('phone').trim(),email:get('email').trim()};}).filter(x=>x.name||x.unitId||x.phone||x.email||x.customTitle);}
async function submitBulkResidents(e){e.preventDefault();const items=collectBulkResidents();if(!items.length){toast('اكتب بيانات ساكن واحد على الأقل.','error');return;}const bad=items.find(x=>!x.name||!x.unitId);if(bad){toast(`أكمل الاسم والدور والوحدة في السطر ${bad.row}.`,'error');return;}const badPin=items.find(x=>!/^[0-9]{4,8}$/.test(x.pin));if(badPin){toast(`الـPIN يجب أن يكون من 4 إلى 8 أرقام في السطر ${badPin.row}.`,'error');return;}const badEmail=items.find(x=>x.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x.email));if(badEmail){toast(`البريد الإلكتروني غير صحيح في السطر ${badEmail.row}.`,'error');return;}const badTitle=items.find(x=>x.titleId==='__OTHER__'&&!x.customTitle);if(badTitle){toast(`اكتب اللقب في السطر ${badTitle.row}.`,'error');return;}const blanks=document.querySelectorAll('#bulkResidentsRows .bulk-user-row').length-items.length;if(!await confirmAction({title:'مراجعة إنشاء الحسابات',message:`سيتم إنشاء ${items.length} حساب، وتجاهل ${blanks} سطر غير مستخدم. هل تريد المتابعة؟`,confirmLabel:'إنشاء'}))return;const btn=document.querySelector('#bulkResidentsForm [type="submit"]');if(btn)btn.disabled=true;try{const r=await run('adminBulkCreateResidents',items);openBulkCredentialsResult(r);await (APP.ctx?.user?.role==='UNION'?renderUnionPeople():renderPeople());}catch(x){toast(errText(x),'error');}finally{if(btn&&btn.isConnected)btn.disabled=false;}}
function openBulkCredentialsResult(r){const rows=(r.items||[]).map(x=>`<tr><td>${esc(x.displayName)}</td><td>${ltrId(x.loginId)}</td><td class="ltr-id" dir="ltr">${esc(x.pin)}</td></tr>`).join('');openModal(`<div class="modal-head"><div><h3>تم إنشاء ${esc(r.count)} حساب</h3><p>انسخ بيانات الدخول الآن؛ PINs لا تُخزن كنص صريح.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="bulk-result-wrap"><table class="bulk-result-table"><thead><tr><th>الساكن</th><th>User ID</th><th>PIN المؤقت</th></tr></thead><tbody>${rows}</tbody></table></div><div class="form-actions"><button class="btn-sm primary" onclick="closeModal();renderPeople()">تم</button></div>`,true);}
function openTitlesManager(){const rows=USER_UI.titles.map(t=>`<div class="member-line"><div><strong>${esc(t.label)}</strong><span>${t.status==='ACTIVE'?'نشط':'غير نشط'}</span></div><div class="compact-actions"><button class="btn-sm" onclick="editTitle('${esc(t.titleId)}')">تعديل</button><button class="btn-sm" onclick="toggleTitleStatus('${esc(t.titleId)}','${t.status==='ACTIVE'?'INACTIVE':'ACTIVE'}')">${t.status==='ACTIVE'?'تعطيل':'تفعيل'}</button></div></div>`).join('');openModal(`<div class="modal-head"><div><h3>إدارة الألقاب</h3><p>الألقاب Master Data مركزية. خيار «أخرى...» يظل متاحًا ولا يضاف تلقائيًا للقائمة.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="list-stack mini-list">${rows||emptyState('لا توجد ألقاب','')}</div><hr class="soft-rule"><form class="form-grid" onsubmit="createTitle(event)"><label class="field span-2"><span>لقب جديد</span><input id="newTitleLabel" maxlength="40" required></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">إضافة اللقب</button></div></form>`);}
async function createTitle(e){e.preventDefault();try{await run('adminCreateTitle',{label:$('newTitleLabel').value});await renderPeople();openTitlesManager();toast('تمت إضافة اللقب.');}catch(x){toast(errText(x),'error');}}
async function editTitle(id){const t=USER_UI.titles.find(x=>x.titleId===id),label=await promptAction({title:'تعديل اللقب',label:'اسم اللقب',value:t?t.label:'',confirmLabel:'حفظ'});if(label==null)return;try{await run('adminUpdateTitle',{titleId:id,label});await renderPeople();openTitlesManager();toast('تم تعديل اللقب.');}catch(x){toast(errText(x),'error');}}
async function toggleTitleStatus(id,status){try{await run('adminSetTitleStatus',id,status);await renderPeople();openTitlesManager();toast('تم تحديث حالة اللقب.');}catch(x){toast(errText(x),'error');}}
async function openEditUserModal(u){try{const titles=await run('listTitles',true);USER_UI.titles=titles;APP.titles=titles.filter(x=>x.status==='ACTIVE');}catch(e){toast('تعذر تحميل الألقاب: '+errText(e),'error');return;}const titleField=titleFields('usr',u.title||'أ.',u.titleId||'',u.customTitle||'');openModal(`<div class="modal-head"><div><h3>تعديل المستخدم</h3><p>الاسم واللقب قابلان للتعديل، بينما User ID ثابت.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitEditUser(event,'${esc(u.userId)}')"><label class="field"><span>اللقب</span>${titleField}</label><label class="field"><span>الاسم</span><input id="usrName" value="${esc(u.name)}" required></label><label class="field"><span>الحالة</span><select id="usrStatus"><option value="ACTIVE" ${u.status==='ACTIVE'?'selected':''}>نشط</option><option value="INACTIVE" ${u.status==='INACTIVE'?'selected':''}>غير نشط</option><option value="ARCHIVED" ${u.status==='ARCHIVED'?'selected':''}>مؤرشف</option></select></label><label class="field"><span>User ID</span><input class="ltr-id" dir="ltr" value="${esc(u.loginId)}" readonly></label><label class="field"><span>الهاتف</span><input id="usrPhone" class="ltr-number" dir="ltr" inputmode="tel" value="${esc(u.phone||'')}"></label><label class="field"><span>Email</span><input id="usrEmail" type="email" value="${esc(u.email||'')}"></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function submitEditUser(e,id){e.preventDefault();const u=userById(id),p={userId:id,name:$('usrName').value,status:$('usrStatus').value,phone:$('usrPhone').value,email:$('usrEmail').value};Object.assign(p,readTitle('usr'));try{await run('adminUpdateUser',p);closeModal();await (APP.ctx?.user?.role==='UNION'?renderUnionPeople():renderPeople());toast('تم حفظ المستخدم.');}catch(x){toast(errText(x),'error');}}
async function resetUserPin(id){if(!await confirmAction({title:'إصدار PIN مؤقت',message:'سيتم إصدار PIN مؤقت جديد وإلغاء جلسات المستخدم الحالية.',confirmLabel:'إصدار'}))return;try{const r=await run('adminResetUserPin',id);openCredentialsResult({loginId:(USER_UI.items.find(x=>x.userId===id)||{}).loginId,pin:r.pin},'تم إصدار PIN جديد');}catch(e){toast(errText(e),'error');}}





const TRIP_UI={resident:null,guard:null,selectedUnitId:'',guardItems:[],requestId:''};
// Display amounts as whole Egyptian pounds, always rounded toward +infinity.
// Display-only: never round values before payments, balances, or ledger calculations.
const amountDisplayNumber=v=>{const n=Number(v||0);return Number.isFinite(n)?Math.ceil(n):0;};
const amountText=v=>amountDisplayNumber(v).toLocaleString('en-US',{maximumFractionDigits:0});
const money=v=>`${amountText(v)} ج.م`;
const reqId=()=>`REQ-${Date.now()}-${Math.random().toString(36).slice(2,10)}`;
function tripItemsEditor(items,prefix){const rows=(items&&items.length?items:prefix==='newTrip'?[{name:'',price:''}]:[{name:'',price:''},{name:'',price:''},{name:'',price:''}]);return `<div id="${prefix}Rows" class="trip-item-list">${rows.map((x,i)=>tripItemRow(x,prefix,i)).join('')}</div><button type="button" class="btn-sm" onclick="addTripItemRow('${prefix}')">+ إضافة بند</button>`;}
function tripItemRow(x,prefix,i){const creating=prefix==='newTrip';return `<div class="trip-item-row ${creating?'trip-item-row-name-only':''}" data-row><input data-name placeholder="الطلب / البند" value="${esc(x.name||'')}" oninput="onTripEditorChanged('${prefix}')">${creating?'':`<input data-price inputmode="decimal" placeholder="السعر" value="${esc(x.price==null?'':x.price)}" aria-label="سعر البند" oninput="onTripEditorChanged('${prefix}')">`}<button type="button" class="btn-sm danger-soft item-x" aria-label="حذف هذا البند" title="حذف هذا البند" onclick="removeTripItemRow(this,'${prefix}')">×</button></div>`;}
function addTripItemRow(prefix){const box=$(prefix+'Rows');if(box){box.insertAdjacentHTML('beforeend',tripItemRow({},prefix,box.children.length));updateTripEditorWarnings(prefix);}}
function removeTripItemRow(btn,prefix){const row=btn?.closest?.('[data-row]');if(row)row.remove();onTripEditorChanged(prefix);}
function collectTripItems(prefix){const box=$(prefix+'Rows');return box?Array.from(box.querySelectorAll('[data-row]')).map(r=>({name:r.querySelector('[data-name]').value.trim(),price:r.querySelector('[data-price]')?.value.trim()??''})).filter(r=>r.name||r.price):[];}
function validGuardItems(items){if(items.some(x=>x.price!==''&&!validTripPrice(String(x.price)))){toast('السعر لازم يكون رقمًا غير سالب، أو اتركه فارغًا.','error');return false;}if(!items.length){toast('اكتب بندًا واحدًا على الأقل.','error');return false;}if(items.some(x=>!x.name&&x.price)){toast('فيه سعر بدون اسم بند. اكتب اسم البند أو امسح السعر.','error');return false;}return true;}
function guardItemsInline(t){const rows=Array.isArray(t.items)?t.items:[];return rows.length?rows.map(x=>`<span class="guard-inline-item">${esc(x.name||'بند')}${x.price===null||x.price===undefined||x.price===''?'<span class="trip-price-pending-dot" role="img" aria-label="السعر لم يُحدد بعد" title="السعر لم يُحدد بعد"></span>':` <bdi dir="ltr">${esc(amountText(x.price))}</bdi>`}</span>`).join('<span class="guard-inline-separator">، </span>'):esc(t.orders||'لا توجد مشتريات');}
function validTripPrice(value){return value===''||(/^(?:\d+)(?:\.\d{1,2})?$/.test(value)&&Number.isFinite(Number(value))&&Number(value)>=0);}
function updateTripEditorWarnings(prefix){const box=$(prefix+'Rows');if(!box)return;Array.from(box.querySelectorAll('[data-row]')).forEach(r=>{const name=(r.querySelector('[data-name]')?.value||'').trim();const input=r.querySelector('[data-price]');if(!input)return;const price=input.value.trim();const invalid=!!price&&!validTripPrice(price);r.classList.toggle('trip-item-row-invalid-price',invalid);r.classList.toggle('trip-item-row-missing-price',!!name&&!price);input.setAttribute('aria-invalid',String(invalid));let help=r.querySelector('.trip-price-error');if(invalid){if(!help){help=document.createElement('small');help.className='trip-price-error';help.setAttribute('role','alert');r.appendChild(help);}help.textContent='اكتب رقمًا غير سالب أو اترك السعر فارغًا.';}else if(help)help.remove();});}
function validateTripEditor(prefix){updateTripEditorWarnings(prefix);const box=$(prefix+'Rows');if(!box)return true;const invalid=box.querySelector('.trip-item-row-invalid-price input[data-price]');if(invalid){invalid.focus();toast('راجع السعر المميز بالأحمر: اكتب رقمًا غير سالب أو اتركه فارغًا.','error');return false;}return true;}
function onTripEditorChanged(prefix){updateTripEditorWarnings(prefix);if(prefix!=='guardTrip')return;const e=$('guardCurrentPurchases');if(!e)return;const total=collectTripItems(prefix).reduce((sum,x)=>sum+(Number(x.price)||0),0);e.textContent=money(total);}
function renderResidentFundHomeCard(d,error){
 if(!d)return `<section class="panel resident-fund-summary"><div class="panel-head"><div><h3>صندوق العمارة</h3></div></div><p class="resident-building-empty">${error?'تعذر تحميل ملخص الصندوق حاليًا.':'البيانات المالية غير متاحة.'}</p><button class="btn-sm" onclick="go('building-fund')">عرض المالية العامة ‹</button></section>`;
 return `<button type="button" class="resident-fund-summary resident-fund-action resident-fund-action-v35" onclick="go('building-fund')" aria-label="عرض مالية صندوق العمارة"><span class="resident-fund-heading">${actionIcon('wallet')} صندوق العمارة</span><span class="resident-fund-balance"><small>الرصيد الحالي</small><strong class="resident-money">${money(d.balance)}</strong></span><span class="resident-fund-inline"><span><small>إيرادات الشهر</small><strong>${money(d.monthIncome)}</strong></span><span><small>مصروفات الشهر</small><strong>${money(d.monthExpenses)}</strong></span></span><span class="resident-fund-report-link">${actionIcon('receipt')} عرض التقرير المالي ‹</span></button>`;
}
function residentMonthLabel(value){const m=/^(\d{4})-(\d{1,2})/.exec(String(value||''));if(!m)return 'الشهر الحالي';const n=Number(m[2]);const names=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];return n>=1&&n<=12?names[n-1]+' '+m[1]:String(value);}
function residentMoney(v){return `<span class="resident-amount-ltr" dir="ltr">${money(v)}</span>`;}
function residentFundDetail(d){
 const rec=(d.recent||[]).map(x=>`<div class="resident-recent-row"><span><strong>${esc(x.label)}</strong><small>${esc(displayDateTime12(x.at))}</small></span><strong class="resident-money">${x.type==='INCOME'?'+':'−'} ${money(x.amount)}</strong></div>`).join('');
 const cats=(d.expenseCategories||[]).map(x=>`<div class="resident-recent-row"><strong>${esc(x.category)}</strong><strong class="resident-money">${money(x.amount)}</strong></div>`).join('');
 return `<div class="resident-fund-detail" dir="rtl"><section class="resident-home-focus resident-building-static"><span class="resident-home-focus-label">رصيد صندوق العمارة الحالي</span><strong class="resident-money">${residentMoney(d.balance)}</strong><span>البيانات حتى ${esc(displayDateTime12(d.asOf))}</span></section><section class="panel"><div class="panel-head"><div><h3>حركة ${esc(residentMonthLabel(d.month))}</h3></div></div><div class="resident-fund-stats"><div><span>الإيرادات</span><strong>${residentMoney(d.monthIncome)}</strong></div><div><span>المصروفات</span><strong>${residentMoney(d.monthExpenses)}</strong></div><div><span>الصافي</span><strong>${residentMoney(d.monthNet)}</strong></div></div>${!(d.recent||[]).length&&Number(d.monthIncome||0)===0&&Number(d.monthExpenses||0)===0?`<p class="resident-fund-zero-note">لا توجد حركات مالية مسجلة خلال هذا الشهر.</p>`:''}<p>مستحقات غير محصلة على مستوى العمارة: <strong class="resident-money">${residentMoney(d.buildingOutstanding)}</strong></p></section><section class="panel"><div class="panel-head"><div><h3>آخر حركات الصندوق</h3><p>تُعرض دون أسماء السكان أو أرقام الوحدات أو مراجع التحصيل.</p></div></div>${rec||emptyState('لا توجد حركات مسجلة','')}</section><section class="panel"><div class="panel-head"><div><h3>المصروفات حسب البند</h3></div></div>${cats||emptyState('لا توجد مصروفات هذا الشهر','')}</section><button class="btn-sm" onclick="go('building')">العودة لحساب الوحدة</button></div>`;
}
async function renderResidentBuildingFund(){
 $('content').innerHTML=pageLoading('جاري تحميل مالية العمارة…');
 try{const d=await run('getResidentBuildingFundSummary',APP.activeUnitId);if(!d||d.scope!=='RESIDENT_BUILDING_FUND_PUBLIC')throw Error('INVALID_FUND_RESPONSE');$('content').innerHTML=residentFundDetail(d);}
 catch(e){$('content').innerHTML=String(e).includes('UNION_FINANCE_ACCESS_DENIED')?`<section class="panel"><h3>حسابات الاتحاد غير متاحة</h3><p>مدير الوحدة أوقف عرض حسابات الاتحاد لأعضاء هذه الوحدة. مستحقات الوحدة والمشاوير متاحة كالمعتاد.</p><button class="btn-sm primary" onclick="go('building')">عرض حساب الوحدة</button></section>`:errorCard(e);}
}
async function renderResidentBuilding(){
 $('content').innerHTML=pageLoading('جاري تحميل حساب العمارة…');
 try{
  const h=APP.home?.membership?.unitId?APP.home:await run('getCoreHomeData');
  const unitId=h.membership?.unitId;
  if(!unitId)throw Error('لا توجد وحدة نشطة مرتبطة بالحساب.');
  const d=await run('getResidentDuesPage',{mode:'summary'});
  let mayViewFund=true;try{const visibility=await run('getUnitFundVisibility',APP.activeUnitId);mayViewFund=visibility.canViewFund!==false;}catch(_){mayViewFund=false;}
  $('content').innerHTML=`<div class="resident-building-page" dir="rtl"><section class="resident-home-focus resident-building-static"><span class="resident-home-focus-label">مستحقات العمارة غير المسددة</span><strong class="resident-money">${money(d.totalDue||0)}</strong><span class="resident-home-focus-bottom">كشف حساب الوحدة ${esc(unitNo(d.unit?.unitNumber||h.membership?.unitNumber||''))}</span></section>${mayViewFund?`<section class="panel"><div class="panel-head"><div><h3>مالية العمارة</h3><p>رصيد الصندوق والإيرادات والمصروفات العامة، بدون بيانات خاصة بالوحدات.</p></div><button class="btn-sm primary" onclick="go('building-fund')">عرض مالية العمارة</button></div></section>`:""}${renderBuildingLedgerResident(d)}<section class="panel"><div class="panel-head"><div><h3>المدفوعات المسجلة</h3><p>التحصيلات الخاصة بالعمارة فقط.</p></div></div>${(d.payments||[]).length?`<div class="resident-recent-list">${d.payments.map(p=>`<div class="resident-recent-row"><span><strong>${money(p.amount)}</strong><small>${esc(displayDateTime12(p.paidAt))}</small></span><span>${esc(p.method||'')}</span></div>`).join('')}</div>`:emptyState('لا توجد مدفوعات مسجلة','')}</section></div>`;
  await Promise.all([loadResidentDueGroup('current',true),loadResidentDueGroup('archive',true)]);
 }catch(e){$('content').innerHTML=errorCard(e);}
}
let residentTripSubmitting=false;
function residentTripInlineForm(a){const distance=a.settings?.defaultDistance||'NEAR';TRIP_UI.requestId=reqId();return `<section class="panel resident-trip-create" aria-label="طلب مشوار">${tripItemsEditor([], 'newTrip')}<div class="form-grid"><label class="field"><span>المسافة</span><select id="newTripDistance">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${distance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></label><label class="field"><span>ملاحظات (اختياري)</span><input id="newTripNotes" placeholder="ملاحظات للحارس"></label></div><div class="form-actions"><button type="button" class="btn-sm primary" id="residentTripSubmit" onclick="saveNewTrip()">إرسال طلب المشوار</button></div></section>`;}
async function renderResidentTripsPage(){
 $('content').innerHTML=pageLoading('جاري تحميل المشاوير…');
 try{
  const a=await run('getResidentAccountData');TRIP_UI.resident=a;a.settings=await run('getMyTripSettings');if(!a.settings||!['NEAR','MEDIUM','FAR'].includes(a.settings.defaultDistance))throw Error('تعذر تحميل إعدادات المسافة الافتراضية.');
  const can=Boolean(a.canManageAccount||(APP.home?.membership?.unitId&&String(APP.home.membership.unitId)===String(a.unitId)));
  const settlements=a.settlements||[];
  const canUndo=settlements.some(x=>x.status==='ACTIVE'&&x.sequenceNo===Math.max(...settlements.map(z=>z.sequenceNo||0)));
  $('content').innerHTML=`<div class="resident-trips-page" dir="rtl">${residentTripInlineForm(a)}<section class="panel"><div class="panel-head"><div><h2>مشاوير الوحدة ${esc(unitNo(a.unitNumber))}</h2><p>المشاوير والدفعات والتسويات في مكان واحد.</p></div></div><div class="resident-trip-summary"><button type="button" class="summary-action-card" onclick="goTripSection('residentOpenTrips')" aria-label="عرض المشاوير المفتوحة"><strong dir="ltr">${Number(a.openTripCount||0)}</strong><span>مشاوير مفتوحة</span><span class="summary-card-arrow" aria-hidden="true">↙</span></button><button type="button" class="summary-action-card" onclick="goTripSection('residentOpenTrips')" aria-label="عرض المشاوير والمستحق للحارس"><strong class="resident-money">${money(a.dueTotal)}</strong><span>مستحق للحارس</span><span class="summary-card-arrow" aria-hidden="true">↙</span></button><button type="button" class="summary-action-card" onclick="goTripSection('residentAdvancePayments')" aria-label="عرض الدفعات والرصيد الدائن"><strong class="resident-money">${money(a.creditBalance)}</strong><span>رصيد دائن</span><span class="summary-card-arrow" aria-hidden="true">↙</span></button></div><div class="compact-actions resident-trip-toolbar"><button class="btn-sm" onclick="openPaymentModal()">+ دفعة</button>${can?`<button class="btn-sm primary" ${a.openTripCount?'':'disabled'} onclick="closeSettlement()">اعتماد تسوية المشاوير</button>`:''}${can?`<button class="btn-sm" onclick="openTripSettings()">إعدادات الأتعاب</button>`:''}</div></section><section class="panel" id="residentOpenTrips" tabindex="-1"><div class="panel-head"><div><h3>المشاوير المفتوحة</h3><p>اضغط على المشوار لتعديله مباشرة، أو استخدم الإجراءات المرفقة.</p></div></div>${renderResidentTrips(a.trips||[])}</section><section class="panel" id="residentAdvancePayments" tabindex="-1"><div class="panel-head"><div><h3>الدفعات تحت الحساب</h3><p>الدفعات المسجلة ضمن حساب الحارس فقط.</p></div><button type="button" class="btn-sm resident-payment-add" onclick="openPaymentModal()" aria-label="إضافة دفعة تحت الحساب" title="إضافة دفعة تحت الحساب">+ دفعة</button></div>${renderPayments(a.payments||[],can)}</section><section class="panel"><div class="panel-head"><div><h3>التسويات السابقة</h3><p>يمكن فتح كل تسوية لعرض تفاصيلها.</p></div>${canUndo&&can?`<button class="btn-sm danger-soft" title="التراجع عن آخر تسوية معتمدة" aria-label="التراجع عن آخر تسوية معتمدة" onclick="undoSettlement()">التراجع عن آخر تسوية</button>`:''}</div>${renderSettlements(settlements)}</section></div>`;
 }catch(e){$('content').innerHTML=errorCard(e);}
}
async function residentHomeAccountAction(fn){try{const a=await run('getResidentAccountData');TRIP_UI.resident=a;await fn(a);}catch(e){toast(errText(e),'error');}}
function openResidentTripFromHome(){go('trips');}
function openResidentAdvanceFromHome(){residentHomeAccountAction(()=>openPaymentModal());}
function openResidentSettlementFromHome(){residentHomeAccountAction(a=>{if(!Number(a.openTripCount||0)){toast('لا توجد مشاوير مفتوحة للتسوية.');return;}return closeSettlement();});}
async function renderResidentAccount(silent=false){ if(!silent)$('content').innerHTML=pageLoading('جاري تحميل الحساب…');try{const mem=APP.home&&APP.home.membership?APP.home.membership:null;const results=await Promise.allSettled([run('getResidentAccountData'),mem&&mem.unitId?run('getResidentDuesPage',{mode:'summary'}):Promise.resolve(null)]);if(results[0].status!=='fulfilled')throw results[0].reason;const a=results[0].value;TRIP_UI.resident=a;const building=results[1].status==='fulfilled'?results[1].value:null;const can=Boolean(a.canManageAccount||(APP.home?.membership?.unitId&&String(APP.home.membership.unitId)===String(a.unitId))),canUndo=(a.settlements||[]).some(s=>s.status==='ACTIVE'&&s.sequenceNo===Math.max(...a.settlements.map(z=>z.sequenceNo||0))),buildingDue=building?Number(building.totalDue||0):null;$('content').innerHTML=`<section class="account-hero account-hero-unified"><div class="account-hero-total"><small>حساب الحارس · الوحدة ${esc(unitNo(a.unitNumber))}</small><strong>${money(a.dueTotal)}</strong><span>المستحق للحارس</span></div><div class="account-hero-split"><div><span>استحقاقات العمارة</span><strong>${buildingDue===null?'غير متاحة':money(buildingDue)}</strong></div><div><span>مستحقات الحارس (مستقلة)</span><strong>${money(a.dueTotal)}</strong></div></div><div class="account-hero-actions"><button class="btn-sm" onclick="go('building')">كشف العمارة ‹</button>${can?`<button class="btn-sm primary" ${a.openTripCount?'':'disabled'} onclick="closeSettlement()">اعتماد التسوية</button>`:''}<button class="btn-sm" onclick="openResidentTripCreate()">+ مشوار</button>${can?`<button class="btn-sm" onclick="openTripSettings()">إعدادات المشاوير</button>`:''}</div></section><div class="grid account-grid account-grid-unified"><div class="stat"><span>استحقاقات العمارة</span><strong>${buildingDue===null?'غير متاحة':money(buildingDue)}</strong></div><div class="stat"><span>مستحقات الحارس (مستقلة)</span><strong>${money(a.dueTotal)}</strong></div><div class="stat"><span>رصيد دائن</span><strong>${money(a.creditBalance)}</strong></div><div class="stat"><span>آخر تسوية</span><strong>${a.settlements&&a.settlements.length?('#'+String(Math.max(...a.settlements.map(z=>z.sequenceNo||0))).padStart(3,'0')):'—'}</strong></div></div><section class="panel"><div class="panel-head"><div><h3>المشاوير المفتوحة</h3><p>المسافة والأتعاب كاملة للساكن قبل التسوية.</p></div><span class="badge">${a.trips.length}</span></div>${renderResidentTrips(a.trips)}</section><section class="panel"><div class="panel-head"><div><h3>الدفعات</h3><p>الدفعات المفتوحة تخص حساب المشاوير فقط.</p></div>${can?`<button class="btn-sm primary" onclick="openPaymentModal()">+ دفعة</button>`:''}</div>${renderPayments(a.payments,can)}</section><section class="panel"><div class="panel-head"><div><h3>التسويات</h3><p>كل تسوية Snapshot ثابتة بتاريخها ومدير الوحدة وقت الاعتماد.</p></div><span class="badge">${a.settlements.length}</span></div>${renderSettlements(a.settlements)}${can?`<div class="section-actions"><button class="btn-sm danger-soft" ${canUndo?'':'disabled'} onclick="undoSettlement()">↶ التراجع عن آخر تسوية</button></div>`:''}</section>`;}catch(e){$('content').innerHTML=errorCard(e);}}
function residentTripDateLine(v){
 const output=displayDateTime12(v);
 const match=output.match(/^(\d{2}\/\d{2}\/\d{4})\s+(\d{1,2}:\d{2})\s*([صم])$/);
 if(!match)return `<bdi dir="auto">${esc(output)}</bdi>`;
 return `<bdi class="trip-date-part" dir="ltr">${esc(match[1])}</bdi><span class="trip-clock-part" dir="rtl"><bdi dir="ltr">${esc(match[2])}</bdi><span class="trip-period">${esc(match[3])}</span></span>`;
}
function renderResidentTrips(rows){if(!rows.length)return emptyState('لا توجد مشاوير مفتوحة','');return `<div class="trip-list">${rows.map(t=>`<article class="trip-card resident-trip-editable" tabindex="0" role="button" aria-label="فتح المشوار للتعديل" onclick="if(!event.target.closest('button,select,input,a'))openTripEdit('${esc(t.tripId)}')" onkeydown="if(event.target===this&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openTripEdit('${esc(t.tripId)}')}"><div class="trip-top resident-trip-top"><div class="trip-date-line"><strong class="trip-date-time">${residentTripDateLine(t.createdAt)}</strong><span>${t.actorRole==='OPERATOR'?'سجله الحارس':'مسجل من الساكن'}</span></div><button type="button" class="trip-cancel-icon" onclick="cancelMyTrip('${esc(t.tripId)}')" aria-label="إلغاء المشوار" title="إلغاء المشوار">×</button></div><div class="trip-orders guard-inline-purchases">${guardItemsInline(t)}</div><div class="trip-values"><div><span>المشتريات</span><strong class="trip-money-display"><bdi dir="ltr">${amountText(t.purchasesTotal)}</bdi><span class="trip-money-unit">ج.م</span></strong></div><div><span>الأتعاب</span><strong class="trip-money-display"><bdi dir="ltr">${amountText(t.feesTotal)}</bdi><span class="trip-money-unit">ج.م</span></strong></div><div><span>الإجمالي</span><strong class="trip-money-display"><bdi dir="ltr">${amountText(t.totalDue)}</bdi><span class="trip-money-unit">ج.م</span></strong></div></div><div class="trip-distance"><button type="button" class="trip-history-icon" onclick="openOpenTripHistory('${esc(t.tripId)}')" aria-label="سجل تعديلات المشوار" title="سجل التعديلات"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7M3 3v6h6"/><path d="M12 7v5l3 2"/></svg></button><select aria-label="اختيار مسافة المشوار" onclick="event.stopPropagation()" onchange="quickDistance('${esc(t.tripId)}',this.value)">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${t.distance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></div></article>`).join('')}</div>`;}
function renderPayments(rows,can){if(!rows.length)return emptyState('لا توجد دفعات مفتوحة','');return `<div class="list-stack">${rows.map(p=>`<div class="member-line"><div><strong>${money(p.amount)}</strong><span>${esc(displayDateTime12(p.createdAt))}${p.reference?' · '+esc(p.reference):''}</span></div>${can?`<button class="btn-sm danger-soft" aria-label="إلغاء الدفعة المفتوحة" title="إلغاء الدفعة المفتوحة" onclick="cancelPayment('${esc(p.paymentId)}')">×</button>`:''}</div>`).join('')}</div>`;}
function renderSettlements(rows){if(!rows.length)return emptyState('لا توجد تسويات حتى الآن','');return `<div class="list-stack">${rows.map(s=>`<button class="settlement-row" onclick="openSettlementDetails('${esc(s.settlementId)}')"><div><strong>تسوية #${String(s.sequenceNo).padStart(3,'0')}</strong><span>${esc(displayDateTime12(s.settledAt))} · ${esc(s.managerDisplayName||'—')}</span></div><div><strong>${money(s.grossTotal)}</strong><span class="${s.status==='CANCELED'?'danger-text':''}">${s.status==='CANCELED'?'ملغاة':'معتمدة'}</span></div></button>`).join('')}</div>`;}
async function loadResidentTripSettingsForModal(){
 try{
  if(!TRIP_UI.resident){toast('بيانات حساب الوحدة غير جاهزة. حدّث الصفحة وحاول تاني.','error');return null;}
  const s=await run('getMyTripSettings');
  if(!s||!['NEAR','MEDIUM','FAR'].includes(s.defaultDistance)||!['feeNear','feeMedium','feeFar'].every(k=>s[k]!==undefined&&s[k]!==null))throw Error('إعدادات المشاوير غير مكتملة.');
  TRIP_UI.resident.settings=s;
  return s;
 }catch(e){toast('تعذر تحميل إعدادات المشاوير: '+errText(e),'error');return null;}
}
async function openResidentTripCreate(){const st=await loadResidentTripSettingsForModal();if(!st)return;openModal(`<div class="modal-head"><div><h3>إضافة مشوار</h3><p>الأتعاب يحسبها السيرفر من إعدادات وحدتك.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>${tripItemsEditor([], 'newTrip')}<label class="field"><span>المسافة</span><select id="newTripDistance">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${st.defaultDistance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></label><label class="field"><span>ملاحظات</span><input id="newTripNotes"></label><div class="form-actions"><button class="btn-sm primary" onclick="saveNewTrip()">تسجيل المشوار</button></div>`);TRIP_UI.requestId=reqId();}
async function saveNewTrip(){if(residentTripSubmitting)return;const items=collectTripItems('newTrip');if(!items.some(x=>x.name)){toast('اكتب بندًا واحدًا على الأقل.','error');return;}if(!validGuardItems(items))return;const btn=$('residentTripSubmit');residentTripSubmitting=true;setButtonBusy(btn,true,'جاري الإرسال…');beginBackgroundSave();try{await run('createResidentTrip',{items,distance:$('newTripDistance').value,notes:$('newTripNotes').value,requestId:TRIP_UI.requestId});if(!btn)closeModal();toast('تم تسجيل طلب المشوار.');if(APP.page==='trips')await renderResidentTripsPage();else if(APP.page==='home')await renderHome();else await renderResidentAccount(true);}catch(e){toast(errText(e),'error');}finally{residentTripSubmitting=false;endBackgroundSave();setButtonBusy(btn,false);}}
function openTripEdit(id){const t=TRIP_UI.resident.trips.find(x=>x.tripId===id);if(!t)return;openModal(`<div class="modal-head"><div><h3>تعديل المشوار</h3><p>متاح قبل التسوية فقط.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>${tripItemsEditor(t.items,'editTrip')}<label class="field"><span>المسافة</span><select id="editTripDistance">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${t.distance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></label><label class="field"><span>ملاحظات</span><input id="editTripNotes" value="${esc(t.notes||'')}"></label><div class="form-actions"><button class="btn-sm primary" onclick="saveTripEdit('${esc(id)}')">حفظ</button></div>`);updateTripEditorWarnings('editTrip');}
async function saveTripEdit(id){if(!validateTripEditor('editTrip'))return;try{await run('updateMyTrip',{tripId:id,items:collectTripItems('editTrip'),distance:$('editTripDistance').value,notes:$('editTripNotes').value});closeModal();toast('تم حفظ المشوار.');if(APP.page==='trips')await renderResidentTripsPage();else await renderResidentAccount(true);}catch(e){toast(errText(e),'error');}}
async function quickDistance(id,d){try{await run('updateMyTripDistance',id,d);await (APP.page==='trips'?renderResidentTripsPage():renderResidentAccount(true));}catch(e){toast(errText(e),'error');await (APP.page==='trips'?renderResidentTripsPage():renderResidentAccount(true));}}
async function cancelMyTrip(id){if(!await confirmAction({title:'إلغاء المشوار',message:'إلغاء هذا المشوار قبل التسوية؟',danger:true,confirmLabel:'إلغاء المشوار'}))return;try{await run('deleteMyTrip',id);toast('تم إلغاء المشوار.');if(APP.page==='trips')await renderResidentTripsPage();else await renderResidentAccount(true);}catch(e){toast(errText(e),'error');}}
async function openTripSettings(){const s=await loadResidentTripSettingsForModal();if(!s)return;openModal(`<div class="modal-head"><div><h3>أتعاب المشاوير الافتراضية</h3><p>حدّد أتعاب كل مسافة، ويمكنك تغيير المسافة لكل مشوار لتُضاف الأتعاب تلقائيًا إلى قيمة المشتريات.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="form-grid"><label class="field"><span>قريب</span><input id="feeNear" inputmode="decimal" value="${esc(s.feeNear)}"></label><label class="field"><span>متوسط</span><input id="feeMedium" inputmode="decimal" value="${esc(s.feeMedium)}"></label><label class="field"><span>بعيد</span><input id="feeFar" inputmode="decimal" value="${esc(s.feeFar)}"></label><label class="field"><span>المسافة الافتراضية</span><select id="defaultDistance">${['NEAR','MEDIUM','FAR'].map(d=>`<option value="${d}" ${s.defaultDistance===d?'selected':''}>${({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[d]}</option>`).join('')}</select></label></div><div class="form-actions"><button class="btn-sm primary" onclick="saveTripSettings()">حفظ</button></div>`);}
async function saveTripSettings(){try{await run('updateMyTripSettings',{feeNear:$('feeNear').value,feeMedium:$('feeMedium').value,feeFar:$('feeFar').value,defaultDistance:$('defaultDistance').value});closeModal();toast('تم حفظ إعدادات الوحدة.');await (APP.page==='trips'?renderResidentTripsPage():renderResidentAccount(true));}catch(e){toast(errText(e),'error');}}
function openPaymentModal(){openModal(`<div class="modal-head"><div><h3>دفعة تحت الحساب</h3><p>الرصيد الزائد يتحول Credit ولا يضيع.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><label class="field"><span>المبلغ</span><input id="payAmount" inputmode="decimal"></label><label class="field"><span>مرجع / ملاحظة</span><input id="payRef"></label><div class="form-actions"><button class="btn-sm primary" onclick="savePayment()">تسجيل الدفعة</button></div>`);}
async function savePayment(){try{await run('addResidentPayment',$('payAmount').value,$('payRef').value);closeModal();toast('تم تسجيل الدفعة.');if(APP.page==='home')await renderHome();else if(APP.page==='trips')await renderResidentTripsPage();else await renderResidentAccount(true);}catch(e){toast(errText(e),'error');}}
async function cancelPayment(id){if(!await confirmAction({title:'إلغاء الدفعة',message:'سيتم إلغاء الدفعة المفتوحة.',danger:true,confirmLabel:'إلغاء الدفعة'}))return;try{await run('cancelResidentPayment',id,'CANCELED_BY_RESIDENT');await (APP.page==='trips'?renderResidentTripsPage():renderResidentAccount(true));toast('تم إلغاء الدفعة.');}catch(e){toast(errText(e),'error');}}

function residentDueStatusLabel(x){return({PAID:'مسدد',PARTIAL:'مسدد جزئيًا',OVERDUE:'متأخر',OPEN:'غير مسدد'})[x]||x;}
function residentDueStatusClass(x){return x==='PAID'?'success':x==='OVERDUE'?'danger':x==='PARTIAL'?'warning':'muted';}
const RESIDENT_DUES_PAGE_SIZE=10;
const RESIDENT_DUES_STATE={current:{rows:[],count:0,offset:0,loading:false},archive:{rows:[],count:0,offset:0,loading:false},request:0,timer:null};
function residentDueLine(r){return `<details class="data-card resident-due-row collapsible-card"><summary><div class="data-main"><div><strong>${esc(r.title)}</strong><span>${esc(r.category||'')} · ${esc(r.dueDate||'')}</span></div><span class="badge ${residentDueStatusClass(r.status)}">${residentDueStatusLabel(r.status)}</span></div></summary><div class="collapsible-body"><div class="data-meta"><span>المستحق ${money(r.amount)}</span><span>المدفوع ${money(r.paid)}</span><strong>المتبقي ${money(r.remaining)}</strong></div></div></details>`;}
function renderBuildingLedgerResident(d){
 for(const kind of ['current','archive'])Object.assign(RESIDENT_DUES_STATE[kind],{rows:[],count:0,offset:0,loading:false});
 RESIDENT_DUES_STATE.request++;
 return `<section class="panel resident-ledger-panel"><div class="panel-head"><div><h3>استحقاقات الوحدة</h3><p>المستحقات الحالية أولًا، والسجل المسدد محفوظ في الأرشيف.</p></div><span class="badge">${Number(d.currentCount||0)+Number(d.archiveCount||0)}</span></div><div class="filter-toolbar"><input id="residentDueSearch" type="search" placeholder="ابحث باسم البند أو التاريخ" oninput="filterResidentDues()"><select id="residentDueStatus" onchange="filterResidentDues()"><option value="">كل الحالات</option><option value="OPEN">غير مسدد</option><option value="PARTIAL">مسدد جزئيًا</option><option value="OVERDUE">متأخر</option><option value="PAID">مسدد</option></select></div><div id="residentDueRows" aria-live="polite"></div></section>`;
}
function renderResidentDuesState(){
 const host=$('residentDueRows');if(!host)return;
 host.innerHTML=['current','archive'].map(kind=>{
  const data=RESIDENT_DUES_STATE[kind],title=kind==='current'?'المستحقات الحالية':'الأرشيف المسدد';
  return `<div class="resident-dues-group"><h4>${title} <small>(${data.count})</small></h4>${data.rows.length?`<div class="list-stack">${data.rows.map(residentDueLine).join('')}</div>`:data.loading?'<p class="resident-building-empty">جاري التحميل…</p>':'<p class="resident-building-empty">لا توجد استحقاقات في هذا القسم.</p>'}${data.error?`<p role="alert" class="resident-building-empty">${esc(data.error)}</p>`:''}${data.rows.length<data.count?`<button type="button" class="btn-sm" onclick="showMoreResidentDues('${kind}')" ${data.loading?'disabled':''}>${data.loading?'جاري التحميل…':'عرض استحقاقات أخرى'}</button>`:''}</div>`;
 }).join('');
}
async function loadResidentDueGroup(kind,reset=false){
 const state=RESIDENT_DUES_STATE[kind];if(!state||state.loading&&!reset)return;
 const generation=RESIDENT_DUES_STATE.request;
 const offset=reset?0:state.rows.length;
 if(reset)Object.assign(state,{rows:[],count:0,offset:0,error:''});
 state.loading=true;renderResidentDuesState();
 try{
  const data=await run('getResidentDuesPage',{mode:'page',group:kind,search:($('residentDueSearch')?.value||'').trim(),status:$('residentDueStatus')?.value||'',offset,limit:RESIDENT_DUES_PAGE_SIZE});
  if(generation!==RESIDENT_DUES_STATE.request||!$('residentDueRows'))return;
  if(!data||data.scope!=='RESIDENT_UNIT_DUES_PAGE'||!Array.isArray(data.rows))throw Error('INVALID_DUES_RESPONSE');
  state.rows=offset?[...state.rows,...data.rows]:data.rows;
  state.count=Number(data.count||0);state.offset=state.rows.length;state.error='';
 }catch(e){if(generation===RESIDENT_DUES_STATE.request&&$('residentDueRows'))state.error=errText(e);}
 finally{if(generation===RESIDENT_DUES_STATE.request&&$('residentDueRows')){state.loading=false;renderResidentDuesState();}}
}
function filterResidentDues(){
 clearTimeout(RESIDENT_DUES_STATE.timer);
 RESIDENT_DUES_STATE.request++;
 for(const kind of ['current','archive'])RESIDENT_DUES_STATE[kind].loading=false;
 RESIDENT_DUES_STATE.timer=setTimeout(()=>{
  loadResidentDueGroup('current',true);loadResidentDueGroup('archive',true);
 },300);
}
async function showMoreResidentDues(group){await loadResidentDueGroup(group,false);}

async function closeSettlement(){const a=TRIP_UI.resident;if(!a)return;const ok=await confirmAction({title:'اعتماد تسوية الحساب',message:'راجع ملخص الحساب قبل الاعتماد.',rows:[{label:'المشاوير المفتوحة',value:String(a.openTripCount||0)},{label:'المشتريات',value:money(a.purchasesTotal)},{label:'الأتعاب',value:money(a.feesTotal)},{label:'الإجمالي المستحق',value:money(a.dueTotal)}],warning:'بعد الاعتماد ستُغلق المشاوير الحالية، ويمكن التراجع عن آخر تسوية فقط.',confirmLabel:'اعتماد التسوية'});if(!ok)return;const preview=document.querySelector('.account-hero');if(preview)preview.classList.add('pending-record');beginBackgroundSave();try{const r=await run('closeMyAccount');toast('تم اعتماد التسوية #'+String(r.sequenceNo).padStart(3,'0'));if(APP.page==='home')await renderHome();else if(APP.page==='trips')await renderResidentTripsPage();else await renderResidentAccount(true);}catch(e){if(preview)preview.classList.remove('pending-record');toast(errText(e),'error');}finally{endBackgroundSave();}}
async function undoSettlement(){if(!await confirmAction({title:'التراجع عن آخر تسوية',message:'ستعود المشاوير والدفعات الأصلية للحساب المفتوح.',warning:'متاح لآخر تسوية فقط.',danger:true,confirmLabel:'تراجع'}))return;try{await run('undoMyLastSettlement','UNDO_BY_MANAGER');toast('تم التراجع عن آخر تسوية.');await (APP.page==='trips'?renderResidentTripsPage():renderResidentAccount(true));}catch(e){toast(errText(e),'error');}}
function displayDateTime12(v){
 if(!v)return '—';
 const d=v instanceof Date?v:new Date(v);
 if(Number.isNaN(d.getTime()))return 'تاريخ غير متاح';
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true}).formatToParts(d);
 const get=key=>parts.find(x=>x.type===key)?.value||'';
 return `${get('day')}/${get('month')}/${get('year')} · ${get('hour')}:${get('minute')} ${get('dayPeriod').toUpperCase()==='AM'?'ص':'م'}`;
}
function cairoDateStamp(value=new Date()){
 const d=value instanceof Date?value:new Date(value);
 if(Number.isNaN(d.getTime()))return 'date-unavailable';
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(d);
 const v=k=>parts.find(x=>x.type===k)?.value||'';
 return `${v('year')}-${v('month')}-${v('day')}`;
}
function settlementDate(v){return displayDateTime12(v);}
function settlementTrips(r){return (r.details||[]).filter(d=>d.type==='TRIP');}
function settlementItems(snap){return Array.isArray(snap&&snap.items)?snap.items:[];}
function settlementTripHeading(d,i){const snap=d.snapshot||{};const items=settlementItems(snap);return money(snap.purchasesTotal??items.reduce((a,it)=>a+Number(it.price||0),0));}
function settlementBrandName(){return (APP.ctx&&APP.ctx.building&&APP.ctx.building.name)||'Tower App';}
function settlementUnitLabel(s){return 'الوحدة '+unitNo(s.unitNumber||'—');}
function settlementCompactItems(items){return items.map(it=>`${it.name||'بند'} ${it.price==null?'السعر لم يُحدد بعد':amountText(it.price)}`).join(' · ');}
function settlementText(r){const s=r.settlement,trips=settlementTrips(r),lines=[settlementBrandName(),`تسوية #${String(s.sequenceNo).padStart(3,'0')}`,settlementUnitLabel(s),`مدير الوحدة: ${s.managerDisplayName||'—'}`,`التاريخ: ${settlementDate(s.settledAt)}`,'',`إجمالي التسوية: ${money(s.grossTotal)}`,`المشتريات: ${money(s.purchasesTotal)} | الأتعاب: ${money(s.feesTotal)}`,`الدفعات السابقة: ${money(s.priorPayments)}`,`المدفوع عند الإغلاق: ${money(s.closingPayment)}`,`الرصيد المرحّل: ${money(s.creditAfter)}`,'',`تفاصيل المشاوير (${trips.length}):`];trips.forEach((d,i)=>{const snap=d.snapshot||{},items=settlementItems(snap);lines.push('',`مشتريات المشوار: ${settlementTripHeading(d,i)} — ${settlementDate(snap.createdAt)}`,settlementCompactItems(items)||'لا توجد مشتريات مسجلة',)});return lines.join('\n');}
function settlementDetailsHtml(r){const s=r.settlement,trips=settlementTrips(r);return `<article class="settlement-document" dir="rtl"><div class="settlement-doc-head"><div class="settlement-doc-brand"><span class="brand-mark settlement-doc-logo" aria-hidden="true"></span><div><strong>${esc(settlementBrandName())}</strong><span>كشف تسوية مشاوير</span></div></div><div class="settlement-doc-heading"><div><h3>تسوية #${esc(String(s.sequenceNo).padStart(3,'0'))}</h3><p>${esc(settlementUnitLabel(s))} · ${esc(s.managerDisplayName||'—')}</p><p>تاريخ التسوية: ${esc(settlementDate(s.settledAt))}</p></div><button class="icon-btn settlement-doc-close" onclick="closeModal()" aria-label="إغلاق">×</button></div></div><div class="detail-actions settlement-doc-actions"><button class="icon-action" onclick="copyTextValue(settlementText(window.LAST_SETTLEMENT_DETAIL),'تم نسخ التسوية بالتفاصيل.')">⧉<span>نسخ</span></button><button class="icon-action" onclick="printSettlement()">▣<span>طباعة</span></button><button class="icon-action" onclick="downloadSettlementPdf()">${actionIcon('report')}<span>PDF</span></button><button class="icon-action" onclick="shareTextValue('تسوية المشاوير',settlementText(window.LAST_SETTLEMENT_DETAIL))">↗<span>مشاركة</span></button></div><div class="settlement-doc-main"><div class="settlement-doc-total"><span>إجمالي التسوية</span><strong>${money(s.grossTotal)}</strong></div><div class="settlement-doc-total settlement-doc-carried"><span>الرصيد المرحّل</span><strong>${money(s.creditAfter)}</strong></div></div><div class="settlement-summary settlement-doc-summary"><div><span>إجمالي المشتريات</span><strong>${money(s.purchasesTotal)}</strong></div><div><span>أتعاب</span><strong>${money(s.feesTotal)}</strong></div><div><span>الدفعات السابقة</span><strong>${money(s.priorPayments)}</strong></div><div><span>المدفوع عند الإغلاق</span><strong>${money(s.closingPayment)}</strong></div></div><h4 class="settlement-trip-title">تفاصيل المشاوير والمشتريات (${trips.length})</h4><div class="settlement-trip-list">${trips.map((d,i)=>{const snap=d.snapshot||{},items=settlementItems(snap);return `<section class="settlement-trip-card"><header><strong>${esc(settlementTripHeading(d,i))}</strong><time>${esc(settlementDate(snap.createdAt))}</time></header><div class="settlement-compact-items">${items.length?items.map((it,j)=>`<span class="settlement-inline-item">${esc(it.name||'بند')} <span class="settlement-item-price">${it.price==null?'<span class="trip-price-pending-dot" role="img" aria-label="السعر لم يُحدد بعد" title="السعر لم يُحدد بعد"></span>':amountText(it.price)}</span></span>`).join(' <span class="settlement-item-sep">·</span> '):'<span>لا توجد مشتريات مسجلة</span>'}</div></section>`}).join('')||'<p>لا توجد مشاوير مسجلة في هذه التسوية.</p>'}</div><footer class="settlement-doc-footer">© Islam Sallam — Tower App V${esc(APP_VERSION)}</footer></article>`;}
async function downloadSettlementPdf(){
 const detail=window.LAST_SETTLEMENT_DETAIL;
 if(!detail||!detail.settlement){toast('افتح تفاصيل التسوية أولًا.','error');return;}
 if(!(await ensurePdfLibs()))return;
 const host=document.createElement('div');host.className='settlement-pdf-host';
 try{
  const original=settlementDetailsHtml(detail);
  host.innerHTML=original;
  document.body.appendChild(host);
  const article=host.querySelector('.settlement-document');
  article.querySelector('.settlement-doc-close')?.remove();
  article.querySelector('.settlement-doc-actions')?.remove();
  if(document.fonts?.ready)await document.fonts.ready;
  const canvas=await html2canvas(article,{scale:2,useCORS:true,backgroundColor:'#ffffff',logging:false,windowWidth:article.scrollWidth});
  const {jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4'});
  const margin=10,width=190,ratio=canvas.width/width,step=Math.max(1,Math.floor(277*ratio));
  let y=0,page=0;
  while(y<canvas.height){const h=Math.min(step,canvas.height-y),part=document.createElement('canvas');part.width=canvas.width;part.height=h;part.getContext('2d').drawImage(canvas,0,y,canvas.width,h,0,0,canvas.width,h);if(page++)pdf.addPage();pdf.addImage(part.toDataURL('image/jpeg',.94),'JPEG',margin,margin,width,h/ratio,undefined,'FAST');y+=h;}
  const seq=String(detail.settlement.sequenceNo||'0').padStart(3,'0');
  await downloadBlobSafe(pdf.output('blob'),`Tower_Settlement_${seq}_${cairoDateStamp()}.pdf`);
  toast('تم تجهيز ملف التسوية PDF.');
 }catch(e){toast('تعذر تجهيز PDF للتسوية. جرّب الطباعة أو أعد المحاولة.','error');console.error('SETTLEMENT_PDF_ERROR',e?.message||'unknown');}
 finally{host.remove();}
}
function printSettlement(){
 const detail=window.LAST_SETTLEMENT_DETAIL;
 if(!detail||!detail.settlement){toast('بيانات التسوية غير متاحة للطباعة.','error');return;}
 // Print an independent document, not the scrollable modal or the SPA shell.
 const w=window.open('','_blank');
 if(!w){toast('اسمح بفتح نافذة الطباعة من المتصفح.','error');return;}
 const article=settlementDetailsHtml(detail)
   .replace(/<button\b[^>]*class="icon-btn settlement-doc-close"[^>]*>[\s\S]*?<\/button>/g,'')
   .replace(/<div class="detail-actions settlement-doc-actions">[\s\S]*?<\/div>/g,'');
 const css=`@page{size:A4 portrait;margin:13mm 14mm}*{box-sizing:border-box}html,body{margin:0;padding:0;direction:rtl;background:#fff;color:#172536;font-family:Cairo,Arial,sans-serif;font-size:12px}body{padding:0;overflow:visible!important}article{width:100%;max-width:none;overflow:visible!important}.settlement-doc-head{display:flex;align-items:center;justify-content:space-between;gap:20px;border-bottom:1px solid #dbe1e7;padding-bottom:13px;margin-bottom:14px}.settlement-doc-brand{display:flex;align-items:center;gap:12px;margin-bottom:0;flex:0 0 auto}.settlement-doc-brand>div{display:flex;flex-direction:column;gap:4px}.settlement-doc-brand strong{font-size:15px;color:#173b63}.settlement-doc-brand span:not(.brand-mark){font-size:10px;color:#607187}.settlement-doc-logo{width:43px;height:43px;display:block;flex:none;background-image:url("data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48ZGVmcz48c3R5bGU+CiAgICAgIC5zdDAgewogICAgICAgIGZpbGw6ICM2MmFiZjk7CiAgICAgIH0KCiAgICAgIC5zdDEgewogICAgICAgIGZpbGw6ICM3NWY0ZmM7CiAgICAgIH0KCiAgICAgIC5zdDIgewogICAgICAgIGZpbGw6ICMxZDliZmI7CiAgICAgIH0KCiAgICAgIC5zdDMgewogICAgICAgIGZpbGw6ICMyNWUxZmM7CiAgICAgIH0KCiAgICAgIC5zdDQgewogICAgICAgIGZpbGw6ICMwMjczZmI7CiAgICAgIH0KCiAgICAgIC5zdDUgewogICAgICAgIGZpbGw6ICNmYWMwMGQ7CiAgICAgIH0KCiAgICAgIC5zdDYgewogICAgICAgIGZpbGw6ICMwNGE2ZmI7CiAgICAgIH0KCiAgICAgIC5zdDcgewogICAgICAgIGZpbGw6ICMwMTFiNDU7CiAgICAgIH0KCiAgICAgIC5zdDggewogICAgICAgIGZpbGw6ICNmN2Y4Zjk7CiAgICAgIH0KCiAgICAgIC5zdDkgewogICAgICAgIGZpbGw6ICNmNzMyM2U7CiAgICAgIH0KCiAgICAgIC5zdDEwIHsKICAgICAgICBmaWxsOiAjMDA0NWM4OwogICAgICB9CgogICAgICAuc3QxMSB7CiAgICAgICAgZmlsbDogIzBkZGE4ODsKICAgICAgfQoKICAgICAgLnN0MTIgewogICAgICAgIGZpbGw6ICMyMWMyZjk7CiAgICAgIH0KCiAgICAgIC5zdDEzIHsKICAgICAgICBmaWxsOiAjZThlZmY2OwogICAgICB9CgogICAgICAuc3QxNCB7CiAgICAgICAgZmlsbDogIzAxMjQ1NzsKICAgICAgfQoKICAgICAgLnN0MTUgewogICAgICAgIGZpbGw6ICMwMTMxN2E7CiAgICAgIH0KCiAgICAgIC5zdDE2IHsKICAgICAgICBmaWxsOiAjMDQ0Mzk5OwogICAgICB9CgogICAgICAuc3QxNyB7CiAgICAgICAgZmlsbDogIzAxMmM2ZjsKICAgICAgfQogICAgPC9zdHlsZT48L2RlZnM+PHBhdGggY2xhc3M9InN0MTUiIGQ9Ik0xOTkuOTgsMTI5LjE5Yy0uMDcuMDEtLjE5LS4wNi0uMTktLjJ2LTExLjM3YzAtLjE0LjExLS4yMS4yLS4ydjExLjc3WiIvPjxnPjxwYXRoIGNsYXNzPSJzdDE1IiBkPSJNMTk5Ljk3LDEwMi45Yy0uMDYsMC0uMTgtLjA2LS4xOC0uMnYtMTEuOTJjMC0uMTQuMTEtLjIxLjIxLS4yMWwtLjAzLDEyLjMzWiIvPjxnPjxwYXRoIGNsYXNzPSJzdDQiIGQ9Ik0xNzUuMzQsODEuMzloLjU1Yy0uMjIuMzItLjYyLjE1LS45NC4xNS4xLS4xLjI0LS4xNC4zOS0uMTVaIi8+PGc+PHBhdGggY2xhc3M9InN0NCIgZD0iTTE4NS4zMSw3NC44MWMtLjItLjAzLS4yNy0uMTktLjEtLjI4LDEuOTgtMi41OSwzLjMyLTUuNjMsMy4zMy04Ljk1LjAxLTUuNTctMy40MS05LjQ5LTguMS0xMi4wOWwtMS4xOS0uNjZjLTQuOTgtMi40NS0xMC40Mi0zLjM2LTE1Ljg2LTMuNTlsLTYuODEtLjAzYy0uNjcsMC0xLjMyLS4wOS0xLjg2LjM0LDMuMTktLjAzLDYuMi4yOCw5LjIxLjc4bDUuMzcsMS4yM2MyLjM4LjU0LDQuNSwxLjc5LDYuMzUsMy4zOSwzLjM1LDIuOTEsMy40LDcuMDcsMS4xOSwxMC44Ni0zLjc4LDYuNDgtMTIuMDYsMTEuNzYtMTguNzEsMTUuMjgtLjI3LjE0LS40Ni4xNi0uNDguNDJsLTUuNDktLjA3YzMuNjktMi4wMyw3LjI5LTQuMjIsMTAuNjItNi44OGwxLjk2LTEuNzMsMS4wMS0xLjAxYzMuNjYtMy42Niw2LTkuMDIsMS43MS0xMi43NS0zLjM3LTIuOTMtOC4zMi0zLjM4LTEyLjU0LTMuODJsLTEuODQtLjE5YzEtMS4xMywxLjE3LTIuNTQsMS4xNy00LjAzdi00LjAycy0uMDItMi45Mi0uMDItMi45MnYtLjcxcy4xMS0uMDIuMTUtLjAzbDEuNDQtLjE3LDIuMjMtLjE2LDcuMzMtLjAzYy4yNSwwLC41Ni4yNi43Ny4zOC44NC0uMzksMS42MS0uMjEsMi40My0uMWw0LjI1LjU2YzQuMDcuNzQsOC4xMywxLjU1LDExLjgxLDMuNDVsNC4yMywyLjE5YzEuNjEsMS4wNSwzLjEzLDIuMSw0LjQsMy41LDEuOTEsMi4xMSwzLjA4LDQuNzQsMi43OSw3LjU5LS4yMSwyLjAxLS44NSwzLjkzLTIuMDIsNS40OWwtMS45LDIuNTRjLS44LDEuMDctMS43NiwxLjg3LTIuNzYsMi43NmwtMS44NCwxLjY1LTIuMjMsMS44MloiLz48cGF0aCBjbGFzcz0ic3QxMiIgZD0iTTE4NS4yMSw3NC41M2MxLjk4LTIuNTksMy4zMi01LjYzLDMuMzMtOC45NS4wMS01LjU3LTMuNDEtOS40OS04LjEtMTIuMDlsLTEuMTktLjY2Yy00Ljk4LTIuNDUtMTAuNDItMy4zNi0xNS44Ni0zLjU5bC02LjgxLS4wM2MtLjY3LDAtMS4zMi0uMDktMS44Ni4zNCwzLjE5LS4wMyw2LjIuMjgsOS4yMS43OGw1LjM3LDEuMjNjMi4zOC41NCw0LjUsMS43OSw2LjM1LDMuMzksMy4zNSwyLjkxLDMuNCw3LjA3LDEuMTksMTAuODYtMy43OCw2LjQ4LTEyLjA2LDExLjc2LTE4LjcxLDE1LjI4LS4yNy4xNC0uNDYuMTYtLjQ4LjQybDE3LjMuMDJjLjEtLjEuMjQtLjE0LjM5LS4xNSwzLjQ2LTEuOTgsNi44OS00LjA3LDkuOTctNi41OC0uMi0uMDMtLjI3LS4xOS0uMS0uMjhaIi8+PC9nPjxnPjxwYXRoIGNsYXNzPSJzdDE1IiBkPSJNMTk5Ljk5LDE1NC41OGMtLjA5LDAtLjItLjA3LS4yLS4yMXYtMTAuNjNjMC0uMTQuMTEtLjIxLjE2LS4xOWwuMDUsMTEuMDNaIi8+PHBhdGggY2xhc3M9InN0MTQiIGQ9Ik0xOTAuNTksMTM1LjA3Yy0uMDcuMDItLjE1LjEzLS4xOC4ybC0uOTcuMDNjLTEuNDEtMS45My0zLjU4LTMuMDUtNi4wMS0zLjUzbC0xNi4wNi0zLjItMS4wOS0uMjEtMTIuODQtMi42Mi0uNDItMS4wNWMtLjIyLS41MS0uNC0uOTMtMS4wMy0xLjAxLS4yOS0uNy0uNTUtMS41Ny0uMzItMi4zMS4xLS4zMS41NC0uMjkuNjktLjE5LjIuMTQuMzUuMy41MS41My0uMTguMzUtLjE3LDEuMDEtLjA0LDEuMzkuMTEuMzQuNTMuODgsMS4xLjg4aDIxLjE5Yy44NiwwLDEuMjctMS4wNiwxLjItMS42NC0uMS0uODktLjc0LTEuNDEtMS43MS0xLjQxaC0xOS44M2MtLjQ2LDAtLjg4LS4wNC0xLjI1LjE5LS40NS0uMTEtLjc4LS4yNS0uOTctLjczbC0xLjEuMTktLjk1LTYuODNoNDAuMDZjMi43OSwwLDQuODUsMi40LDQuODcsNC45NWwuMDQsOS43N2MuMDEsMy4xNy0xLjg5LDUuODUtNC44Nyw2LjYxWk0xOTAuNjgsMTIzLjM5YzAtMi41Ni0yLjA4LTQuNjQtNC42NC00LjY0cy00LjY0LDIuMDgtNC42NCw0LjY0LDIuMDgsNC42NCw0LjY0LDQuNjQsNC42NC0yLjA4LDQuNjQtNC42NFoiLz48cGF0aCBjbGFzcz0ic3QxNCIgZD0iTTE5MS4yMywxNjAuMTRsLS4wNi0yMC40OGMyLjE5LjI2LDQuMjQsMi4yMyw0LjI1LDQuNTlsLjA1LDkuMzljLjAyLDIuOTktMS40Nyw1LjU4LTQuMjQsNi40OVoiLz48cGF0aCBjbGFzcz0ic3QxMCIgZD0iTTE5My44OSwxMzguMWMyLjA4Ljk0LDMuODksMi44OCwzLjg5LDUuMzlsLjAyLDExLjFjMCwzLjY5LTMuMTIsNi40LTYuNiw2LjUzbC4wMi0uOTljMi43Ny0uOTEsNC4yNi0zLjUsNC4yNC02LjQ5bC0uMDUtOS4zOWMtLjAxLTIuMzYtMi4wNi00LjM0LTQuMjUtNC41OSwwLS42Ni0uMjctMS41Ni0uNTEtMi4xMiwxLjE3LS4wNSwyLjIzLjEsMy4yNC41NloiLz48cGF0aCBjbGFzcz0ic3Q3IiBkPSJNMTkyLjk5LDEzNS4wNmMtLjAyLjcxLjk5LjYyLDEuMjYsMS4yNy4wOC4yLS4yNy40OS0uMjcuNzlzLjI3Ljc1LS4wOS45OWMtMS4wMS0uNDYtMi4wNy0uNjEtMy4yNC0uNTYtLjMyLS43Ni0uNzMtMS41OS0xLjIxLTIuMjVsLjk3LS4wM2guMThzMi4zOS0uMjEsMi4zOS0uMjFaIi8+PHBhdGggY2xhc3M9InN0MTAiIGQ9Ik0xOTMuNDksMTExLjY1YzIuNDIuOTksNC4zMiwzLjE5LDQuMzIsNS45N3YxMS42NGMtLjAyLDIuODctMi4yNSw1LjE0LTQuODIsNS44bC0yLjM5LjE5di0uMTljMi45OC0uNzUsNC44OC0zLjQ0LDQuODYtNi42MWwtLjA0LTkuNzdjLS4wMS0yLjU1LTIuMDctNC45NS00Ljg3LTQuOTVoLTQwLjA2cy0uMzEtMi41OS0uMzEtMi41OWw0MC45My4wMmMuODcsMCwxLjc0LjIyLDIuMzcuNDhaIi8+PHBhdGggY2xhc3M9InN0NiIgZD0iTTE1Mi44NiwxMjEuNzFjLjEyLS4yMi40Ni0uNDguNjUtLjYuMzctLjIyLjc5LS4xOCwxLjI1LS4xOGgxOS44M2MuOTcsMCwxLjYxLjUxLDEuNzEsMS40LjA3LjU4LS4zMywxLjY1LTEuMiwxLjY1aC0yMS4xOWMtLjU3LDAtLjk4LS41NC0xLjEtLjg4LS4xMy0uMzgtLjE0LTEuMDQuMDQtMS4zOVoiLz48Y2lyY2xlIGNsYXNzPSJzdDMiIGN4PSIxODYuMDQiIGN5PSIxMjMuMzkiIHI9IjQuNjQiLz48cGF0aCBjbGFzcz0ic3QxNyIgZD0iTTE5MC42LDEzNS4yNWgtLjE4Yy4wMy0uMDYuMTEtLjE3LjE4LS4xOXYuMTlaIi8+PGc+PHBhdGggY2xhc3M9InN0MTciIGQ9Ik0xNTIuMTcsODEuNDRsNS40OS4wNywxNy4zLjAyYy4zMSwwLC43MS4xOC45NC0uMTVsMTUuMzcuMDNjNC44Mi43Miw4LjQzLDQuNDYsOC43NCw5LjE2LS4xLDAtLjIxLjA3LS4yMS4yMXYxMS45MmMwLC4xNC4xMS4yMS4xOC4yLDAsMy4wMi0xLjgxLDUuNzQtNC42NSw3LjIzLDIuNzksMS40Nyw0LjUzLDQuMjUsNC42OCw3LjI5LS4wOSwwLS4yLjA3LS4yLjJ2MTEuMzdjMCwuMTQuMTEuMjEuMTkuMi0uMDEsMy4xMi0xLjgyLDUuODQtNC43LDcuMjksMi44NywxLjQyLDQuNjUsNC4wOSw0LjY3LDcuMDYtLjA0LS4wMi0uMTYuMDYtLjE2LjE5djEwLjYzYzAsLjE0LjExLjIxLjIuMjEtLjE0LDQuNjQtNC4wMSw4LjU3LTguNjUsOC44NC0uMDMtLjA2LS4xLS4wNy0uMTctLjA3bC4wMy0yLjIzYzMuNDgtLjEzLDYuNjEtMi44NCw2LjYtNi41M2wtLjAyLTExLjFjMC0yLjUtMS44MS00LjQ1LTMuODktNS4zOS4zNi0uMjQuMDktLjcuMDktLjk5cy4zNS0uNTkuMjctLjc5Yy0uMjYtLjY0LTEuMjctLjU2LTEuMjYtMS4yNywyLjU3LS42Niw0LjgtMi45Myw0LjgxLTUuOHYtMTEuNjRjLjAyLTIuNzgtMS44OS00Ljk4LTQuMy01Ljk3LS4xNS0uNy4zMi0xLjA0Ljc1LTEuNDctLjE3LTEuMTItMS44Mi0uNDMtMS42Mi0xLjQsMi44NC0uNTQsNS4xOC0yLjk5LDUuMTgtNi4wN3YtMTEuNzJjMC00LjMyLTMuNTYtNy4zNC03Ljc4LTcuMzRsLTQzLjQ1LS4wMy0uMjgtMi4yMiw1Ljg3LjA1WiIvPjxwYXRoIGNsYXNzPSJzdDEwIiBkPSJNMTkyLjYyLDEwOC43OGwtMi4yMS4xNmMuMDktLjI5LjQxLS4yMy43MS0uMzQsMi41My0uODcsNC4yOC0zLjE4LDQuMy01Ljg5bC4wNC0xMC42NmMuMDEtMy4yNC0yLjI5LTUuOTQtNS42My01Ljk0aC00MS45cy0xLjA4LS4wMi0xLjA4LS4wMmwtLjI5LTIuNDksNDMuNDUuMDNjNC4yMiwwLDcuNzgsMy4wMiw3Ljc4LDcuMzR2MTEuNzJjMCwzLjA4LTIuMzQsNS41My01LjE5LDYuMDdaIi8+PHBhdGggY2xhc3M9InN0MTQiIGQ9Ik0xOTAuNDIsMTA4Ljk0bC00LjQ3LS4wNmgtMzYuMDZzLTIuODctMjEuNi0yLjg3LTIxLjZjLjU5LS4yNiwxLjA2LS41Mi45Mi0xLjE2aDQxLjljMy4zNSwwLDUuNjQsMi43LDUuNjMsNS45NGwtLjA0LDEwLjY2Yy0uMDEsMi43MS0xLjc3LDUuMDItNC4zLDUuODktLjMxLjExLS42Mi4wNC0uNzEuMzRaTTE5MC43LDk3LjExYzAtMi41Ny0yLjA5LTQuNjYtNC42Ni00LjY2cy00LjY2LDIuMDktNC42Niw0LjY2LDIuMDksNC42Niw0LjY2LDQuNjYsNC42Ni0yLjA5LDQuNjYtNC42NlpNMTc0Ljg3LDk2LjcxYzEuMDEsMCwxLjQ5LS45MiwxLjQ0LTEuNjEtLjA2LS43Ni0uNjItMS40NC0xLjUzLTEuNDRsLTIwLjc0LjAyYy0uOTUsMC0xLjQyLDEuMDQtMS4zLDEuNzQuMTQuOC43NSwxLjMsMS42NiwxLjNoMjAuNDhaTTE3NC44NSwxMDMuMjVjLjk5LDAsMS40NS0uODcsMS40NS0xLjU0cy0uNTItMS40OS0xLjM4LTEuNWwtMjAuNTMtLjAzYy0uOTMsMC0xLjU4LjU0LTEuNjgsMS4zNy0uMDcuNi4zLDEuNjcsMS4xNiwxLjY3bDIwLjk4LjAzWiIvPjxwYXRoIGNsYXNzPSJzdDYiIGQ9Ik0xNzQuODUsMTAzLjI1bC0yMC45OC0uMDNjLS44NiwwLTEuMjMtMS4wNy0xLjE2LTEuNjcuMS0uODMuNzUtMS4zNywxLjY4LTEuMzdsMjAuNTMuMDNjLjg2LDAsMS4zOC44MiwxLjM4LDEuNXMtLjQ2LDEuNTQtMS40NSwxLjU0WiIvPjxjaXJjbGUgY2xhc3M9InN0MyIgY3g9IjE4Ni4wNCIgY3k9Ijk3LjExIiByPSI0LjY2Ii8+PHBhdGggY2xhc3M9InN0NiIgZD0iTTE3NC44Nyw5Ni43MWgtMjAuNDhjLS45MS4wMi0xLjUyLS40OS0xLjY2LTEuMjktLjEyLS42OS4zNS0xLjczLDEuMy0xLjc0bDIwLjc0LS4wMmMuOTEsMCwxLjQ3LjY4LDEuNTMsMS40NC4wNS42OS0uNDMsMS42MS0xLjQ0LDEuNjFaIi8+PC9nPjwvZz48L2c+PGc+PHBhdGggY2xhc3M9InN0MTQiIGQ9Ik00My40NywxNTMuNDNsLTIuNDQsMTMuNzYtMi4zMS4xNSwyLjY3LTE0LjMyYy43My0uMjksMS40MS4yMywyLjA5LjQxWiIvPjxwYXRoIGNsYXNzPSJzdDE2IiBkPSJNMTE5LjY4LDI4LjY1bC0uMDctOS45NGMwLS4xMy4xMy0uMjIuMTktLjJsLS4xMiwxMC4xNFoiLz48cGF0aCBjbGFzcz0ic3QxMyIgZD0iTTEwMC4yNyw0OS41M2MuMDYuMDcuMjEuMDcuMjYtLjA0bC4wNCwxMS44NGMtNS44LjM0LTkuNzUsNS4zMi05LjcyLDExLjA2bC4xLDE2LjM0aDIuNDhzNi44NCwwLDYuODQsMGwuMDksMTMuMTVjLTguMTIsMy45Mi0xNi4xOSw5LjI4LTIwLjIzLDE3LjU5LTEuMzUsMi43Ny0xLjk4LDUuNTQtMi4wOSw4LjYzbC0uNTMsMTQuMjdjLTUuOTQtMS4yNi0xMS44NC0yLjc2LTE3LjY1LTQuNWw3LjA4LTU0Ljg3LDMuMDQtMjQuODIsMzAuMjktOC42NloiLz48cGF0aCBjbGFzcz0ic3Q4IiBkPSJNNjkuOTgsNTguMTlsLTMuMDQsMjQuODItNy4wOCw1NC44N2MtNC4xOS0xLjI1LTguMzctMi42LTEyLjQyLTQuMjNsMTEuODQtNzAuNmMuMDctLjQtLjAyLS44MS0uMTktLjk1bDEwLjg4LTMuOVoiLz48cGF0aCBjbGFzcz0ic3Q3IiBkPSJNMTE0LjY0LDExOC4wMmMtNS45Ni0xLjA1LTExLjk1LDMuNDQtMTEuOTksOS43M2wtLjEzLDE5LjA3Yy03LjA2LTEuMDItMTQuMTItMi4xNC0yMS4xLTMuNjJsLjYtMTUuMDZjLjEzLTMuMjUsMS4yOC02LjE4LDIuOTctOC45NSwzLjUtNS43Miw5LjQ3LTkuNzcsMTUuNDYtMTIuNjgsNS40NywyLjc5LDEwLjAxLDUuODYsMTMuNzMsMTAuNjQuMjIuMy40MS41NS40NS44NloiLz48cGF0aCBjbGFzcz0ic3QxNiIgZD0iTTEwMC4zNywxMDEuODhsNy4zMyw0LjEyYzMuMDcsMi4wMSw1LjgsNC4yOCw4LjI0LDcsMS41NCwxLjg4LDIuOTYsMy43NiwzLjg3LDUuOTJsLTUuMTgtLjkxYy0uMDMtLjMxLS4yMi0uNTYtLjQ1LS44Ni0zLjczLTQuNzgtOC4yNi03Ljg2LTEzLjczLTEwLjY0LTUuOTgsMi45MS0xMS45NSw2Ljk2LTE1LjQ2LDEyLjY4LTEuNjksMi43Ny0yLjg0LDUuNjktMi45Nyw4Ljk1bC0uNiwxNS4wNi0zLjktLjgzLjUzLTE0LjI3Yy4xMS0zLjA5Ljc0LTUuODYsMi4wOS04LjYzLDQuMDQtOC4zMSwxMi4xMi0xMy42NiwyMC4yMy0xNy41OVoiLz48cGF0aCBjbGFzcz0ic3QxMyIgZD0iTTcyLjc1LDE2MC4wM2wtLjM2LDMuOTMtMzEuMzYsMy4yNCwyLjQ0LTEzLjc2LDExLjM0LDMuMDVjNi4wMSwxLjQyLDExLjk0LDIuNTgsMTcuOTQsMy41NVoiLz48cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTUxLjAxLDI3LjU3Yy4wNi0uMDMuMTMsMCwuMTYsMGwuMjUuMTRjLjQ0LjI1Ljc2LjY2Ljc1LDEuMjhsLS4wNiwxOS40OC4wMy41NS0uMDUsMy4wOWMwLC41NC0uMjQsMS4wNS0uNjEsMS4zOGwtLjctLjE1LTEyLjYtMy41OS0zNy42OC05Ljk1LjE0LTMwLjM5LDE2LjExLDUuODVjLjY0LjE4LjgxLjYxLjgxLDEuMjJsLS4wNiwxMy43NiwxNi45NSw1LjQ1LjA0LTE0LjQzYzAtLjIyLjEyLS40LjIyLS40NXMuMzItLjE0LjUxLS4wNmwxNS43OSw2LjgxWiIvPjxwYXRoIGNsYXNzPSJzdDEzIiBkPSJNMTAwLjY0LDkuNDJsLS4xNCwzMC4zOS03LjQyLDIuMDEtMjkuOTQsNy44OC0xMi45MiwzLjY1Yy0uMjEuMDYtLjM1LjE1LS41My4zNC0uNDUtLjQtLjg0LS43Ni0uODUtMS41OGwtLjA3LTIzLjI4YzAtLjY0LjQ5LS45NS45OC0xLjE2bDE2LjA0LTYuODljLjItLjA5LjQxLS4wMi41MS4wMy4xLjA1LjI1LjIzLjI1LjQ2bC4wMiwxNC41MSwxNy4yLTUuNDItLjEtMTQuMDVjMC0uNDYuMjYtLjc2LjY0LS45NmwxNi4zMi01LjkyWiIvPjxwYXRoIGNsYXNzPSJzdDE2IiBkPSJNMTAwLjUsMzkuODF2OC40OGMwLC41LDAsLjkyLS4yMywxLjI0bC0zMC4yOSw4LjY2LTEwLjg4LDMuOS05LjQtOC40Yy4xOC0uMTkuMzItLjI4LjUzLS4zNGwxMi45Mi0zLjY1LDI5Ljk0LTcuODgsNy40Mi0yLjAxWiIvPjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMzEuMDcsNTguMDVjLjEyLjA5LjA5LjE5LjA2LjI0bDYuODUsNjQuMy05Ljg4LTIuMDQtOC4yOS0xLjYxYy0uOTEtMi4xNy0yLjMzLTQuMDQtMy44Ny01LjkyLTIuNDQtMi43My01LjE3LTUtOC4yNC03bC03LjMzLTQuMTItLjA5LTEzLjE1aDYuOTRzMi42NCwwLDIuNjQsMHYtMTcuOTljLS41LTQuOTctNC4zMy04LjkyLTkuMjktOS40bC0uMDQtMTEuODQsMzAuNTQsOC41NloiLz48cGF0aCBjbGFzcz0ic3QyIiBkPSJNMTQxLjkxLDYxLjk5Yy0uMTYuMTQtLjMzLjQ4LS4yOC44N2w2LjEyLDQ2LjgzLDEuODcsMTQuMThjLS4yNS4xNC0uMi41Mi0uMTksMS4wM2wtMTEuNDUtMi4zMS02Ljg1LTY0LjMsMTAuNzgsMy43WiIvPjxwYXRoIGNsYXNzPSJzdDE0IiBkPSJNMTk0LjI0LDExMC4xOGMtLjE3LTEuMTItMS44Mi0uNDMtMS42Mi0xLjRsLTIuMjEuMTYtNC40Ny0uMDZoLTM2LjA2cy0yLjg3LTIxLjYtMi44Ny0yMS42Yy41OS0uMjYsMS4wNi0uNTIuOTItMS4xNmwtMS4wOC0uMDItLjI5LTIuNDktLjI4LTIuMjItLjI0LTEuMWMuMDctLjU3LS4wNy0uOS0uMTUtMS40MWwtLjItMS4yOS0uMzctMi44N2MtLjA2LS40Ny0uMDgtLjkyLS4xNC0xLjQybC0uNzMtNS41NC0uNDUtMi45OGMtLjA1LS4zLjE3LS43MS0uMDgtMS4xMS0uMTMtLjIxLS4wOC0uNjUuMDctLjgyLjEtLjEyLjQyLS4xOC42MS0uMjYuMzMtLjc2LDEuMDctMS4xNiwxLjY0LTEuNjZsMS40OC0xLjMxLDEuNDItMS4zMywxLjYxLTEuM2MuNTctLjQ2Ljg2LS45MSwxLjUzLTEuMzEuMjctLjE2LjM3LS42OS44MS0uNjUsMS0xLjEzLDEuMTctMi41NCwxLjE3LTQuMDN2LTQuMDJzLS4wMi0yLjkyLS4wMi0yLjkydi0uNzFzLS4wNy00LjAzLS4wNy00LjAzbC4wMi00LjM5di0yLjg0czAtMi4xNywwLTIuMTd2LS45OXMwLS44NywwLS44N3YtLjE5Yy4wNC0uNjMtLjU4LTEuMjUtMS4wOC0xLjY2LS4wOC4wMi0uMTUuMDItLjIuMDItLjA3LDAtLjEzLDAtLjIsMCwuMDYsMCwuMTMsMCwuMiwwLS4xOC0uNDEtLjYyLS40My0xLjA1LS42MmwtMTIuNi01LjQxLTIuNDItMS4wN2MtMS40Mi0uNjMtMi41Ni0uNS0zLjkyLjE3bC02LjQzLDMuMTNjLS40OC4yMy0xLjEyLjY1LTEuMTIsMS4yNmwtLjA1LDYuODQtNS42NC0xLjg4LS4wNy05Ljk0YzAtLjEzLjEzLS4yMi4xOS0uMmwtLjA2LTIuODdjLS4yLTEuMTQtLjk0LTEuOS0xLjk3LTIuMjhsLTE2LTUuODZjLS43OC0uMjktMS41NS0uMjYtMi4zMy4wM2wtMTUuNTcsNS43M2MtMS4wOC40LTIuMzIsMS4yLTIuMjUsMi40Ni4wNC43MiwwLDEuMzUsMCwyLjA2bC0uMDYsMTEuMDktNS42OSwxLjc4Yy0uMDcuMDItLjItLjA1LS4yLS4xOXYtMy41cy0uMDYtMy40OS0uMDYtMy40OWMtLjAxLS42MS0uOTctLjk4LTEuNDUtMS4yMWwtMi41MS0xLjIxLTQuNzEtMi4yNmMtLjUxLS4yNC0xLjQtLjE4LTEuOTcuMDZsLTE1LjgxLDYuNzZjLTEuNDguNjMtMi41MywxLjcyLTIuNTMsMy4zOGwuMDMsMTkuM2MwLDEuMDYuMzIsMi4wNi4xNywzLjEzLS4yNywxLjgzLjQ0LDMuMzIsMS45Myw0LjMybDEuODEsMS42OCw1LjMxLDQuNmMuNDEuMzUuNjQuODUsMS4yMSwxLjA1bC0uNTYsMy41Ny0xLjI0LDcuNDJjLS4wNS4zMS0uMTMuNjItLjQuNzEuMDYsMCwuMjYtLjAyLjM0LjA2bC0yLjE0LDEyLjgyLTEuOTcsMTEuNjhjLS4xMS42Ny0uMTYsMS40Mi0uMjcsMS45MS0uMTUuNzEtLjM1LDEuMzktLjQ1LDIuMDRsLTEuNTUsMTAuMS0uMzIuOTMtMS4zNiw4LjA4LTEuODksMTAuMzcsMi4xNS44NywxMS44NC03MC42Yy4wNy0uNC0uMDItLjgxLS4xOS0uOTVsLTkuNC04LjRjLS40NS0uNC0uODQtLjc2LS44NS0xLjU4bC0uMDctMjMuMjhjMC0uNjQuNDktLjk1Ljk4LTEuMTZsMTYuMDQtNi44OWMuMi0uMDkuNDEtLjAyLjUxLjAzLjEuMDUuMjUuMjMuMjUuNDZsLjAyLDE0LjUxLDE3LjItNS40Mi0uMS0xNC4wNWMwLS40Ni4yNi0uNzYuNjQtLjk2bDE2LjMyLTUuOTIsMTYuMTEsNS44NWMuNjQuMTguODEuNjEuODEsMS4yMmwtLjA2LDEzLjc2LDE2Ljk1LDUuNDUuMDQtMTQuNDNjMC0uMjIuMTItLjQuMjItLjQ1LjA5LS4wNS4zMi0uMTQuNTEtLjA2bDE1Ljc5LDYuODFjLjA2LS4wMy4xMywwLC4xNiwwLC4xMS0uMDMuMjUuMDIuMjUuMTQuNDQuMjUuNzYuNjYuNzUsMS4yOGwtLjA2LDE5LjQ4LjAzLjU1LS4wNSwzLjA5YzAsLjU0LS4yNCwxLjA1LS42MSwxLjM4bC05LjU4LDguNDhjLS4xNi4xNC0uMzMuNDgtLjI4Ljg3bDYuMTIsNDYuODMsMS44NywxNC4xOGMuMDQuMjkuMTIuNzguMDIsMS4wMy4yMi40MS41LjI1Ljg1LjMxbDIuOTQuNTMtLjQyLTEuMDVjLS4yMi0uNTEtLjQtLjkzLTEuMDMtMS4wMS0uMjktLjctLjU1LTEuNTctLjMyLTIuMzEuMS0uMzEuNTQtLjI5LjY5LS4xOS4yLjE0LjM1LjMuNTEuNTMuMTItLjIyLjQ2LS40OC42NS0uNi0uNDUtLjExLS43OC0uMjUtLjk3LS43M2wtMS4xLjE5LS45NS02LjgzLS4zMS0yLjU5LDQwLjkzLjAyYy44NywwLDEuNzQuMjIsMi4zNy40OC0uMTUtLjcuMzItMS4wNC43NS0xLjQ3Wk0xNTEuNTksMjYuOTdjLjEtLjEuMi0uMjEuMy0uMy0uMS4wOS0uMi4xOS0uMy4zWiIvPjxwYXRoIGNsYXNzPSJzdDE0IiBkPSJNMTUxLjQyLDI3LjcybC0uMjUtLjE0Yy4xMS0uMDMuMjUuMDIuMjUuMTRaIi8+PHBhdGggY2xhc3M9InN0MTciIGQ9Ik0xMzguMTgsNDkuNzZjMCwuMjItLjA1LjQ0LS4yNS42N2wtNi44Nyw3LjYyLTMwLjU0LTguNTZjLS4wNS4xMS0uMi4xMS0uMjYuMDQuMjQtLjMyLjIzLS43NC4yMy0xLjI0di04LjQ4czM3LjY4LDkuOTUsMzcuNjgsOS45NVoiLz48cGF0aCBjbGFzcz0ic3Q3IiBkPSJNMTA3LjIyLDg4LjczaC02Ljk0cy02Ljg0LDAtNi44NCwwbC4xLTE2LjY3Yy40Ny0zLjgxLDMuNTktNi44Miw3LjUzLTYuNDIsMy40NS4zNSw2LjE3LDMuNDQsNi4xOCw2LjlsLS4wMiwxNi4xOVoiLz48cGF0aCBjbGFzcz0ic3QxNSIgZD0iTTEwMC41Nyw2MS4zM2M0Ljk2LjQ4LDguNzksNC40Myw5LjI5LDkuNHYxNy45OXMtMi42NC4wMi0yLjY0LjAybC4wMi0xNi4xOWMwLTMuNDYtMi43My02LjU0LTYuMTgtNi45LTMuOTMtLjQtNy4wNiwyLjYxLTcuNTMsNi40MmwtLjEsMTYuNjdoLTIuNDhzLS4xLTE2LjM1LS4xLTE2LjM1Yy0uMDMtNS43MywzLjkyLTEwLjcyLDkuNzItMTEuMDZaIi8+PHBhdGggY2xhc3M9InN0MTYiIGQ9Ik0xNTEuNDksNTMuNTFsLTkuNTgsOC40OC0xMC43OC0zLjdzLjA1LS4xNS0uMDYtLjI0bDYuODctNy42MmMuMi0uMjIuMjUtLjQ0LjI1LS42N2wxMi42LDMuNTkuNy4xNVoiLz48L2c+PGc+PGc+PHBhdGggY2xhc3M9InN0MTciIGQ9Ik0xNDkuNjcsMTI4LjAybDMzLjkzLDYuODhjMi41My41MSw1Ljc4LDMuMjUsNS43OCw1Ljg3bC0xLjIyLDQzLjM3YzAsMy4xNC0yLjgsNS41OC01LjgzLDUuNDhsLTM2LjQ2LTEuMTktMS4wNi0uMDMtLjI3LS4wNC0xLjk2LS4wMy0yLjA5LS4wNy0yNy42OS0uOTZjLTMuNzItLjEzLTcuNjktMy4yLTcuNjktNy4xMmwuNDgtNTEuODZjLjA4LTQuMzMsMy40OC03LjU5LDcuOC03LjQzbDIyLjY5LDQuMzcsMTMuNTgsMi43OFpNMTIyLjYsMTMyLjU1YzAtMi40LTEuOTUtNC4zNS00LjM1LTQuMzVzLTQuMzUsMS45NS00LjM1LDQuMzUsMS45NSw0LjM1LDQuMzUsNC4zNSw0LjM1LTEuOTUsNC4zNS00LjM1Wk0xMzQuMDIsMTM0LjU0YzAtMi40LTEuOTQtNC4zNC00LjM0LTQuMzRzLTQuMzQsMS45NC00LjM0LDQuMzQsMS45NCw0LjM0LDQuMzQsNC4zNCw0LjM0LTEuOTQsNC4zNC00LjM0Wk0xNDUuMjksMTM2LjQ4YzAtMi4zOS0xLjk0LTQuMzMtNC4zMy00LjMzcy00LjMzLDEuOTQtNC4zMyw0LjMzLDEuOTQsNC4zMyw0LjMzLDQuMzMsNC4zMy0xLjk0LDQuMzMtNC4zM1pNMTg1LjYsMTgyLjk1di0zMC4zN2MtLjAyLTIuMDktMi4wNy0zLjY3LTQuMDEtMy45MWwtMzcuMDktNC42MS0zMS4yNy00LjA1Yy0yLjM0LS4zLTQuNDMsMS42Ni00LjQzLDMuOTJsLS4wMywzNS4yOWMwLDIuMjMsMS43LDQuNiw0LjExLDQuNzRsMzEuOTcsMS44MywzNS43OCwxLjYyYzIuNTQuMTIsNC45Ni0xLjcxLDQuOTYtNC40NVoiLz48cGF0aCBjbGFzcz0ic3QxMiIgZD0iTTE5MS4xNywxNjMuMzVjLjA4LTEuNTMsMC0yMS41Ny0uMDEtMjMuNjktLjQtNC4wOS0zLjY4LTcuMjMtNy43My03LjksMCwwLTE2LjA2LTMuMi0xNi4wNi0zLjItMi45MS0uNTYtMTQuMDYtMi45Mi0xNi44Ny0zLjM2LS4zNS0uMDYtLjYzLjEtLjg1LS4zMS4wOS0uMjUuMDEtLjc1LS4wMi0xLjAzLS4yNS4xNC0uMi41Mi0uMTksMS4wMy04Ljc4LTEuNzItMjAuODYtNC4zMy0yOS42Mi01Ljk3LTcuODEtMi4yMy0xNi40NS0uODktMTcuMTcsOC44Mi0uMDUsOS40LS4xOCwyNS4zMS0uMTMsMzQuNTYtLjE5LDIuMjEuMDYsMTEuNzctLjAyLDEzLjkxLS41Niw2Ljg5LDEuNzEsMTIuMTMsOC42NywxNC4wMmwyLjMxLjU1LDY3Ljc0LDEuODRjNC44Ny43LDkuOTYtMy4yNiw5LjkzLTguMDgsMCwwLDAtNi40Mi4wMS0xMi4xOXYxMi4ycy4xNy0uMDUuMTctLjIxYzAsMC0uMDktMjAuOTgtLjE2LTIwLjk4Wk0xODguMTYsMTg0LjE0YzAsMy4xNC0yLjgsNS41OC01LjgzLDUuNDhsLTM2LjQ2LTEuMTljLS4yMS4wMi0xLjE0LS4wNC0xLjMzLS4wNywwLDAtMS45Ni0uMDMtMS45Ni0uMDMtNTAuNjctMS42Ni0zNC4yNyw1LjUyLTM2Ljk5LTYwLjAxLjA4LTQuMzMsMy40OC03LjU5LDcuOC03LjQzLDguNTUsMS43MiwyNy45Nyw1LjMyLDM2LjI3LDcuMTUsNTEuODksMTEuNjEsMzYuNS0uNDgsMzguNDksNTYuMTFaIi8+PHBhdGggY2xhc3M9InN0NyIgZD0iTTE4NS42LDE4Mi45NWMwLDIuNzQtMi40Miw0LjU2LTQuOTYsNC40NWwtMzUuNzgtMS42Mi0zMS45Ny0xLjgzYy0yLjQyLS4xNC00LjExLTIuNTEtNC4xMS00Ljc0bC4wMy0zNS4yOWMwLTIuMjYsMi4wOC00LjIyLDQuNDMtMy45MmwzMS4yNyw0LjA1LDM3LjA5LDQuNjFjMS45NC4yNCwzLjk5LDEuODIsMy45OSwzLjkxdjMwLjM3Wk0xMjIuNDUsMTc2LjQybDEzLjE5LTEwLjc4YzEuNDktMS4yMiwxLjgyLTMuMjQuMzctNC42OWwtMTIuMzktMTIuMzdjLTEuMjMtMS4yMy0zLjI1LS44Ny00LjMxLjIzcy0xLjI2LDMuMDgtLjA1LDQuMjlsOS43LDkuNzktMTAuNTksOS4xN2MtMS4yMSwxLjA1LS44OCwyLjk5LjA5LDMuOTgsMS4wMywxLjA0LDIuNzIsMS40MSwzLjk5LjM3Wk0xNjMuNTUsMTczLjQ2bC0yMS44Ni0xLjI2Yy0xLjc4LS4xLTMuMDksMS40Mi0zLjA5LDMuMDNzMS4xOCwyLjk2LDIuOTIsMy4wNWwyMS42NywxLjEzYzEuNjYuMDksMi44MS0xLjM4LDIuODYtMi44OS4wNC0xLjI2LS44Ny0yLjk3LTIuNTEtMy4wN1oiLz48Y2lyY2xlIGNsYXNzPSJzdDkiIGN4PSIxMTguMjUiIGN5PSIxMzIuNTUiIHI9IjQuMzUiLz48Y2lyY2xlIGNsYXNzPSJzdDUiIGN4PSIxMjkuNjciIGN5PSIxMzQuNTQiIHI9IjQuMzQiLz48Y2lyY2xlIGNsYXNzPSJzdDExIiBjeD0iMTQwLjk2IiBjeT0iMTM2LjQ4IiByPSI0LjMzIi8+PHBhdGggY2xhc3M9InN0MTMiIGQ9Ik0xMjIuNDUsMTc2LjQyYy0xLjI3LDEuMDQtMi45Ni42Ny0zLjk5LS4zN3MtMS4zMS0yLjkzLS4wOS0zLjk4bDEwLjU5LTkuMTctOS43LTkuNzljLTEuMjEtMS4yMi0xLjA1LTMuMTUuMDUtNC4yOXMzLjA4LTEuNDYsNC4zMS0uMjNsMTIuMzksMTIuMzdjMS40NSwxLjQ0LDEuMTIsMy40Ny0uMzcsNC42OWwtMTMuMTksMTAuNzhaIi8+PHBhdGggY2xhc3M9InN0MTMiIGQ9Ik0xNjMuNTUsMTczLjQ2YzEuNjQuMDksMi41NCwxLjgsMi41MSwzLjA3LS4wNSwxLjUtMS4yLDIuOTctMi44NiwyLjg5bC0yMS42Ny0xLjEzYy0xLjc1LS4wOS0yLjkyLTEuNDgtMi45Mi0zLjA1czEuMy0zLjE0LDMuMDktMy4wM2wyMS44NiwxLjI2WiIvPjwvZz48Zz48cGF0aCBjbGFzcz0ic3QxNSIgZD0iTTExMC40MiwxODkuOTFjLTQuNC0xLjA1LTcuNi00Ljk2LTcuODktOS41OGwtLjAyLTQuMTFjLTE1Ljk3LS4zMy0zMS45My4yLTQ3Ljk3LDEuNDQtMTEuMjMuODctMjIuMzYsMS44NC0zMy40MSwzLjIyLS40MS4wNS0uNjIuNTItLjgxLjg5bC0zLjI3LDYuMjhjLS4yLjM5LS4yNy44NS0uMTIsMS4yNi4xMS4zLjM4LjgxLjg2LjgybDQuNTguMTJoNDAuNjRzMy4xMywwLDMuMTMsMGgyLjk0czMuNDksMCwzLjQ5LDBoMzIuNTRzNi4wOCwwLDYuMDgsMGMtLjIxLS4yMS0uNDgtLjI2LS43NS0uMzJaIi8+PHBhdGggY2xhc3M9InN0MTYiIGQ9Ik03Ny43MSwxNjAuNDRjLjQzLS4wNC44OC4xMywxLjI5LjE3bC0uNDQsMTMuNTVjLTE2Ljg2LjQxLTMzLjcxLDEuNi01MC40NywzLjY0bDIuODMtOC4wNWMuMzktMS4xLDEuNDQtMS43MiwyLjU3LTEuODRsNS4yMy0uNTYsMi4zMS0uMTUsMzEuMzYtMy4yNC4zNi0zLjkzYzEuNjUuMjcsMy4yOC41Niw0Ljk2LjQxWiIvPjxwYXRoIGNsYXNzPSJzdDEiIGQ9Ik03OC43OCwxNzQuMTFjLjA1LjE1LjE5LjE0LjI1LjA1aDIzLjQ4czAsMi4wNiwwLDIuMDZjLTE1Ljk3LS4zMy0zMS45My4yLTQ3Ljk3LDEuNDQtMTEuMjMuODctMjIuMzYsMS44NC0zMy40MSwzLjIyLjUzLTEuNDEsMS45LTIuNDYsMy41Mi0yLjY1bDMuNDUtLjQyYzE2Ljc1LTIuMDQsMzMuNjEtMy4yMyw1MC40Ny0zLjY0LjA1LS4wOS4xNi0uMDYuMjItLjA2WiIvPjxwYXRoIGNsYXNzPSJzdDE2IiBkPSJNNDguNTQsMTE0LjMyYy0uNTgtLjAyLTEsLjMzLTEuNDkuNThsLTIuMDcsMS4wOWMtNC41OSwyLjQyLTguODksNS4yMi0xMi42NSw4LjgzLS4zMi4zLS40Mi43NS0uODEuOTMtLjMxLjA4LS41My0uMDMtLjg2LS4yOC0xLjU0LTEuMTQtNC4zMi0zLjQ4LTMuNzMtNC41OC41My0uOTgsMS4yNy0yLjIzLDIuMTgtMy4xMmwzLjYzLTMuNTVjNC40NC0zLjYzLDkuMTctNi42MywxNC4yMy05LjMsMS4xNi0uNjEsMi4xNS0xLjI1LDMuNDMtMS42M2wtMS41NSwxMC4xLS4zMi45M1oiLz48cGF0aCBjbGFzcz0ic3QxNCIgZD0iTTc5LjgsMTYwLjc1YzcuNDYsMS4xLDE0Ljk5LDIuMDYsMjIuNjQsMi41OGwuMDcsMTAuODJoLTIzLjQ4Yy0uMDYtLjA0LS4xOC0uMDQtLjI1LS4wNC0uMDYsMC0uMTctLjA0LS4yMi4wNmwuNDQtMTMuNTVoLjE1Yy4xNC4zMi40OC4xMi42NS4xNFoiLz48cGF0aCBjbGFzcz0ic3QxNiIgZD0iTTc4Ljc4LDE3NC4xMWMuMDYsMCwuMTksMCwuMjUuMDUtLjA2LjA5LS4xOS4xLS4yNS0uMDVaIi8+PGc+PHBhdGggY2xhc3M9InN0NCIgZD0iTTU0LjksNzQuNzdjLjA2LDAsLjI2LS4wMi4zNC4wNmwtMi4xNCwxMi44MmMtNS45NiwyLjc4LTExLjYyLDYuMjMtMTYuODEsMTAuMzlsLTEuNzgsMS41NWMtNS45NSw1LjE3LTEyLjIsMTMuOTUtNy45MSwyMS40OS4xNSwwLC4yOS0uMS4zNC0uMTktLjYsMS4xLDIuMTgsMy40NCwzLjczLDQuNTguMzMuMjUuNTUuMzYuODYuMjgsMS4xOC45OCwyLjc1LDEuNzksNC4yMiwyLjU1bDMuMTcsMS42MiwyLjg4LDEuMzQsMy41LDEuNTIsMi4xNS44N2M0LjA1LDEuNjQsOC4yMywyLjk4LDEyLjQyLDQuMjMsNS44MiwxLjc0LDExLjcyLDMuMjQsMTcuNjUsNC41bDMuOS44M2M2Ljk4LDEuNDgsMTQuMDQsMi42LDIxLjEsMy42MnY3LjM1Yy0yMy4zNy01Ljc2LTQ1LjA1LTEyLjgyLTY2LjI0LTI0LjUyLTIuNjEtMS40NC01LjA5LTIuNzMtNy40My00LjM5LTEuNzEtMS4yMS0zLjMxLTIuNi00LjczLTQuMjMtMy45LTQuNDktNC43LTEwLjQ0LTIuMjgtMTUuNzYsMS4xOS0yLjYxLDIuOTEtNC45Niw0Ljk0LTcuMTVsMy43OS0zLjU0YzQuMTUtMy40Myw4LjY0LTYuMzcsMTMuNDEtOS4wM2w2LjU5LTMuNjhjLTguMzIsMi44LTE2LjA5LDYuMy0yMy42MSwxMC4zMS01LjY0LDMuMDEtMTEuNTgsNi43Mi0xNi4zMywxMC45Ny0yLjUsMi4yNC00LjkxLDQuNjktNi42MSw3LjctLjgzLDEuNDctMS43MiwyLjk3LTEuNyw0LjU0LTEuMTIsNC4wOC0uNDYsOC40MSwxLjU4LDEyLjIyLDQuMTgsNy43OSwxMi45NCwxMy4yMywyMC43NywxNy4xMyw2LjIzLDMuMDksMTIuNTcsNS42NSwxOS4xOSw3LjcyLDYuMzEsMS45NywxMi41MSwzLjczLDE5LjAxLDVsMTQuODMsMi45OGMtMS42Ny4xNS0zLjMxLS4xNC00Ljk2LS40MS02LS45Ny0xMS45My0yLjEzLTE3Ljk0LTMuNTVsLTExLjM0LTMuMDVjLS42OC0uMTgtMS4zNy0uNy0yLjA5LS40MWwtLjYzLS41Yy0uNDgtLjYzLTEuNDUtLjk5LTIuMjctLjdsLTYuNjMtMi4zNS04LjE2LTMuNmMtMy43My0xLjY0LTcuMDMtMy42Ni0xMC4zOS01Ljk3LTYuMTMtNC4yLTEyLjI1LTEwLjI1LTEzLjE1LTE3Ljg4LTEuMTMtOS41NCw0Ljc2LTE3LjczLDExLjU2LTIzLjg5LDUuNTEtNSwxMS4zNi04Ljc0LDE3Ljg0LTEyLjMxLDMuMDctMS42OSw1Ljk5LTMuMTksOS4yLTQuNjIsNS4zNS0yLjM5LDEwLjY1LTQuNjMsMTYuMTUtNi40NFpNNTEuMTMsODEuNTdsLS4wOS4wOS4wOS4wOS4wOS0uMDktLjA5LS4wOVpNNTAuNzYsODEuNzZsLS4wOS4wOS4wOS4wOS4wOS0uMDktLjA5LS4wOVoiLz48cGF0aCBjbGFzcz0ic3QyIiBkPSJNNDAuNzYsMTUyLjUzYy0uNzctLjExLTEuNTctLjM0LTIuMjctLjcuODItLjI4LDEuNzkuMDcsMi4yNy43WiIvPjxwYXRoIGNsYXNzPSJzdDYiIGQ9Ik0xMDIuNTEsMTU0LjE4djguMTNjLTcuMzEtLjc2LTE0LjU4LTEuNzctMjEuODktMy4wNS0uNTQtLjA5LS45Mi0uMTgtMS4zNC4wNS0uMTEtLjI1LS40Mi0uMzgtLjcyLS40NGwtNS4yNS0xLjA1LTEuMDctLjE3LTEyLjgxLTNjLTQuMjQtLjk5LTguMjUtMi4yNC0xMi4yNy0zLjg5bC03LjA4LTIuOS0zLjc4LTEuOWMtMi41LTEuMjYtNC43Ny0yLjg4LTYuNjEtNC45LTMuNzctNC4xMy01LjE4LTEwLjA4LTEuNzctMTQuNzZsLjk0LTEuMDNjMi4zNCwxLjY1LDQuODIsMi45NSw3LjQzLDQuMzksMjEuMiwxMS43LDQyLjg3LDE4Ljc2LDY2LjIzLDI0LjUyWiIvPjxwYXRoIGNsYXNzPSJzdDMiIGQ9Ik0xMC42MywxMDMuMTVsMS4zLjc2Yy40OS40OCwxLjA2LjI5LDEuNTQuNSwxLjYxLjcsMy4xOC44Nyw0Ljg4Ljg3aDMuNDhjLTIuNDIsNS4zMi0xLjYyLDExLjI2LDIuMjgsMTUuNzUsMS40MiwxLjYzLDMuMDEsMy4wMiw0LjczLDQuMjNsLS45NCwxLjAzYy0zLjQxLDQuNjgtMiwxMC42MywxLjc3LDE0Ljc2LS41MS4xNC0uODgtLjA0LTEuMzEtLjIyLTMuODYtMS41OS03LjU2LTMuMjMtMTEuMTUtNS4zOC02LjU0LTMuOTItMTMuNTMtOS4zLTE0Ljg0LTE3LjE0bC0uMDUtMi45M2MtLjAyLTEuNTcuODctMy4wNywxLjctNC41NCwxLjctMy4wMSw0LjEyLTUuNDYsNi42MS03LjdaIi8+PHBhdGggY2xhc3M9InN0MSIgZD0iTTI5LjY3LDE0MS4wNmMxLjg0LDIuMDIsNC4xMSwzLjY0LDYuNjEsNC45bDMuNzgsMS45LDcuMDgsMi45YzQuMDIsMS42NSw4LjAzLDIuODksMTIuMjcsMy44OWwxMi44MSwzLDEuMDcuMTcsNS4yNSwxLjA1Yy4zLjA2LjYxLjE5LjcyLjQ0bC41NywxLjMyaC0uNjlzLS4xNS0uMDItLjE1LS4wMmMtLjQyLS4wNC0uODctLjIxLTEuMjktLjE3bC0xNC44My0yLjk4Yy02LjUtMS4yNy0xMi43LTMuMDMtMTkuMDEtNS02LjYyLTIuMDctMTIuOTYtNC42My0xOS4xOS03LjcyLTcuODMtMy44OS0xNi42LTkuMzQtMjAuNzctMTcuMTMtMi4wNC0zLjgxLTIuNy04LjE0LTEuNTgtMTIuMjJsLjA1LDIuOTNjMS4zMiw3Ljg0LDguMywxMy4yMiwxNC44NCwxNy4xNCwzLjU5LDIuMTUsNy4yOSwzLjc5LDExLjE1LDUuMzguNDQuMTguODEuMzYsMS4zMS4yMloiLz48cGF0aCBjbGFzcz0ic3QxMiIgZD0iTTI2Ljk2LDkyLjE4Yy42LDEuMzQsMS45My44NSwyLjU2LDEuNzEuMjguMzguNTcuNiwxLjA0LjY5bC0zLjc5LDMuNTRjLTIuMDMsMi4xOS0zLjc1LDQuNTMtNC45NCw3LjE1aC0zLjQ4Yy0xLjcsMC0zLjI3LS4xNi00Ljg4LS44Ni0uNDgtLjIxLTEuMDQtLjAxLTEuNTQtLjVsLTEuMy0uNzZjNC43NC00LjI1LDEwLjY5LTcuOTYsMTYuMzMtMTAuOTdaIi8+PHBhdGggY2xhc3M9InN0NiIgZD0iTTMwLjU2LDk0LjU4Yy0uNDctLjA5LS43Ny0uMzEtMS4wNC0uNjktLjYzLS44Ni0xLjk2LS4zNy0yLjU2LTEuNzEsNy41Mi00LjAyLDE1LjI5LTcuNTEsMjMuNjEtMTAuMzFsLTYuNTksMy42OGMtNC43OCwyLjY2LTkuMjYsNS42LTEzLjQxLDkuMDNaIi8+PHJlY3QgY2xhc3M9InN0NiIgeD0iNTEuMDciIHk9IjgxLjYiIHdpZHRoPSIuMTMiIGhlaWdodD0iLjEzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDIuNzcgNjAuMDgpIHJvdGF0ZSgtNDUpIi8+PHJlY3QgY2xhc3M9InN0NiIgeD0iNTAuNyIgeT0iODEuNzgiIHdpZHRoPSIuMTMiIGhlaWdodD0iLjEzIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDMuMDEgNTkuODcpIHJvdGF0ZSgtNDUpIi8+PHBhdGggY2xhc3M9InN0MyIgZD0iTTEwMi41MiwxNjIuMzFsLS4wOCwxLjAxYy03LjY1LS41MS0xNS4xOC0xLjQ4LTIyLjY0LTIuNTgtLjA0LjAxLS4wNC0uMDguMDQtLjEybC0uNTctMS4zMmMuNDItLjI0LjgxLS4xNSwxLjM0LS4wNSw3LjMxLDEuMjgsMTQuNTksMi4yOSwyMS45LDMuMDVaIi8+PHBhdGggY2xhc3M9InN0MTYiIGQ9Ik03OS44NCwxNjAuNjNjLS4wOS4wNC0uMDguMTMtLjA0LjEyLS4xNy0uMDItLjUxLjE4LS42NS0uMTJoLjY5WiIvPjwvZz48L2c+PC9nPjwvZz48L3N2Zz4=");background-position:center;background-size:contain;background-repeat:no-repeat}.settlement-doc-heading{text-align:left;flex:1;min-width:0}.settlement-doc-heading h3{font-size:20px;margin:0 0 7px;color:#162c45}.settlement-doc-heading p{font-size:11px;margin:4px 0;color:#56687a;overflow-wrap:anywhere}.settlement-doc-total{text-align:center;padding:15px 8px;background:#edf7f1;border:1px solid #d8ebe2;border-radius:10px;margin:13px 0}.settlement-doc-total span{display:block;color:#5c6f79}.settlement-doc-total strong{display:block;font-size:28px;margin-top:5px;color:#173b63}.settlement-summary{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.settlement-summary>div{border:1px solid #e2e7ed;background:#f8fafb;border-radius:9px;padding:10px 12px;display:flex;flex-direction:column;gap:6px}.settlement-summary span{color:#65768a;font-size:10px}.settlement-summary strong{font-size:13px}.settlement-summary .settlement-doc-credit{grid-column:1/-1;background:#ecfaf4}.settlement-trip-title{font-size:14px;margin:20px 0 12px}.settlement-trip-list{display:block;overflow:visible!important}.settlement-trip-card{border:1px solid #dfe6ed;border-radius:10px;padding:11px 13px;margin:0 0 10px;break-inside:avoid-page;page-break-inside:avoid;overflow:visible!important}.settlement-trip-card header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding-bottom:9px;border-bottom:1px solid #e7ebef}.settlement-trip-card header strong{font-size:17px;color:#173b63}.settlement-trip-card time{font-size:10px;color:#67788b;direction:ltr}.settlement-compact-items{line-height:2.2;padding:10px 0;overflow-wrap:anywhere}.settlement-inline-item{display:inline;break-inside:avoid}.settlement-inline-item strong{white-space:nowrap;margin-inline-start:3px}.settlement-item-sep{color:#8795a6;padding:0 3px}.settlement-trip-card footer{display:flex;justify-content:space-between;gap:10px;padding-top:9px;border-top:1px solid #e7ebef;font-weight:bold}.settlement-doc-main{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin:13px 0}.settlement-doc-main>.settlement-doc-total{margin:0;min-width:0}.settlement-doc-carried{background:#ecfaf4}.settlement-inline-item .settlement-item-price{font-weight:400;white-space:nowrap;margin-inline-start:3px}.detail-actions,.settlement-doc-close{display:none!important}@media print{html,body{height:auto!important;max-height:none!important;overflow:visible!important} .settlement-trip-card{break-inside:avoid-page} } .settlement-doc-summary>div,.settlement-summary>div{background:#f5f7fa!important;color:#172536!important;border:1px solid #e1e6ec!important}.settlement-doc-summary>div span{color:#556475!important}.settlement-doc-summary>div strong{color:#172536!important}.settlement-doc-footer{text-align:center;font-size:10px;color:#617084;margin-top:16px;padding-top:8px;border-top:1px solid #dfe6ed} `;
 const title='تسوية '+String(detail.settlement.sequenceNo||'');
 w.document.open();
 w.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+esc(title)+'</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap"><style>'+css+'</style></head><body>'+article+'</body></html>');
 w.document.close();
 w.addEventListener('load',()=>{setTimeout(async()=>{try{if(w.document.fonts&&w.document.fonts.ready)await w.document.fonts.ready;w.focus();w.print()}catch(e){toast('تعذرت الطباعة.','error')}},180)},{once:true});
}
async function openOpenTripHistory(id){try{const rows=await run('getOpenTripChangeHistory',id);openModal(`<div class="modal-head"><div><h3>سجل تعديلات المشوار</h3><p>التعديلات المسجلة أثناء فتح المشوار.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>${Array.isArray(rows)&&rows.length?renderTripChangeHistory(rows):emptyState('لا توجد تعديلات مسجلة','')}`);}catch(e){if(APP.ctx?.user?.role==='OPERATOR'){try{const c=await run('getGuardTripContext');if(Array.isArray(c.trips)&&!c.trips.some(t=>String(t.tripId)===String(id))){toast('المشوار لم يعد ضمن المشاوير المفتوحة، ربما تمت تسويته أو إلغاؤه. جارٍ تحديث القائمة.','info');await renderGuardTrips(true);return;}}catch(_){} }toast(errText(e),'error');}}
function tripHistoryItems(items){
 if(!Array.isArray(items)||!items.length)return 'لا يوجد';
 return items.map(x=>esc(String(x.name||x.title||'بند'))+' ('+(x.price==null?'🔴':money(x.price))+')').join('، ');
}
function tripHistoryDistance(v){return ({NEAR:'قريب',MEDIUM:'متوسط',FAR:'بعيد'})[v]||'غير محدد';}
function renderTripChangeHistory(rows){
 if(!Array.isArray(rows)||!rows.length)return '';
 const isGuard=APP.ctx&&APP.ctx.user&&['GUARD','OPERATOR'].includes(APP.ctx.user.role);
 return `<details class="trip-change-history"><summary>سجل تعديلات المشوار (${rows.length})</summary><div class="list-stack">${rows.map(h=>{
 const before=h.before||{},after=h.after||{},changes=[];
 if(JSON.stringify(before.items)!==JSON.stringify(after.items))changes.push('المشتريات: '+tripHistoryItems(before.items)+' ← '+tripHistoryItems(after.items));
 if(!isGuard&&before.distance!==after.distance)changes.push('المسافة: '+tripHistoryDistance(before.distance)+' ← '+tripHistoryDistance(after.distance));
 if(!isGuard&&before.distanceFee!==after.distanceFee)changes.push('الأتعاب: '+money(before.distanceFee||0)+' ← '+money(after.distanceFee||0));
 if(before.notes!==after.notes)changes.push('الملاحظات: '+esc(before.notes||'—')+' ← '+esc(after.notes||'—'));
 return `<div class="data-card compact-card"><strong>${esc(h.by||'مستخدم')}</strong><time class="trip-history-time" dir="auto">${esc(settlementDate(h.at))}</time><div>${changes.map(c=>`<div>${c}</div>`).join('')||'تحديث بيانات المشوار'}</div></div>`;
 }).join('')}</div></details>`;
}

async function openSettlementDetails(id){try{const r=await run('getSettlementDetails',id);window.LAST_SETTLEMENT_DETAIL=r;openModal(settlementDetailsHtml(r));}catch(e){toast(errText(e),'error');}}
function guardStoreKey(kind){const id=APP.ctx&&APP.ctx.user?APP.ctx.user.loginId:'guard';return `tower-guard-${kind}-${id}`;}
function guardStoredIds(kind){try{const x=JSON.parse(localStorage.getItem(guardStoreKey(kind))||'[]');return Array.isArray(x)?x:[];}catch(_){return[];}}
function saveGuardIds(kind,ids){localStorage.setItem(guardStoreKey(kind),JSON.stringify(ids));}
function guardFavorites(){return guardStoredIds('favorites').slice(0,8);}
function guardRecents(){return guardStoredIds('recents').slice(0,3);}
function toggleGuardFavorite(id,event){if(event){event.preventDefault();event.stopPropagation();}let ids=guardFavorites();ids=ids.includes(id)?ids.filter(x=>x!==id):[id,...ids].slice(0,8);saveGuardIds('favorites',ids);renderGuardQuickUnits();if(!$('guardUnitResults')?.classList.contains('hidden'))filterGuardUnits();}
function rememberGuardRecent(id){if(!id)return;const ids=[id,...guardRecents().filter(x=>x!==id)].slice(0,3);saveGuardIds('recents',ids);renderGuardQuickUnits();}
function guardQuickChip(u,kind){return `<button type="button" class="guard-quick-chip" onclick="selectGuardUnit('${esc(u.unitId)}')" title="${esc(guardUnitLabel(u))}"><strong>${esc(unitNo(u.unitNumber))}</strong>${kind==='fav'?'<b>★</b>':''}</button>`;}
function renderGuardQuickUnits(){const box=$('guardQuickUnits');if(!box||!TRIP_UI.guard)return;const byId={};TRIP_UI.guard.units.forEach(u=>byId[u.unitId]=u);const fav=guardFavorites().map(id=>byId[id]).filter(Boolean),recent=guardRecents().filter(id=>!guardFavorites().includes(id)).map(id=>byId[id]).filter(Boolean);box.innerHTML=`${fav.length?`<div class="guard-quick-group"><small>المفضلة</small><div class="guard-quick-list">${fav.map(u=>guardQuickChip(u,'fav')).join('')}</div></div>`:''}${recent.length?`<div class="guard-quick-group"><small>الأخيرة</small><div class="guard-quick-list">${recent.map(u=>guardQuickChip(u,'recent')).join('')}</div></div>`:''}`;}

async function openGuardSettlementSummary(id){try{const r=await run('getGuardSettlementDetails',id);window.LAST_SETTLEMENT_DETAIL=r;openModal(settlementDetailsHtml(r));}catch(e){toast(errText(e),'error');}}
function renderGuardSettlements(rows){if(!rows||!rows.length)return emptyState('لا توجد تسويات حتى الآن','');return `<div class="list-stack">${rows.map(s=>`<button class="settlement-row" onclick="openGuardSettlementSummary('${esc(s.settlementId)}')"><div><strong>تسوية #${String(s.sequenceNo).padStart(3,'0')} · وحدة ${esc(unitNo(s.unitNumber||'—'))}</strong><span>${esc(displayDateTime12(s.settledAt))} · ${esc(s.managerDisplayName||s.managerName||'—')}</span></div><div><strong>${money(s.purchasesTotal+s.feesTotal)}</strong><span>مشتريات ${money(s.purchasesTotal)} · أتعاب ${money(s.feesTotal)}</span></div></button>`).join('')}</div>`;}

async function renderGuardTrips(silent=false){ if(!silent)$('content').innerHTML=pageLoading('جاري تجهيز شاشة الحارس…');try{const [tripResult,settlementResult]=await Promise.allSettled([run('getGuardTripContext'),run('getGuardSettlements')]);if(tripResult.status!=='fulfilled')throw tripResult.reason;const c=tripResult.value;c.settlements=settlementResult.status==='fulfilled'?(settlementResult.value||[]):[];c.settlementsAvailable=settlementResult.status==='fulfilled';c.settlementsError=settlementResult.status==='rejected'?errText(settlementResult.reason):'';TRIP_UI.guard=c;TRIP_UI.guardItems=[{name:'',price:''},{name:'',price:''},{name:'',price:''}];TRIP_UI.requestId=reqId();$('content').innerHTML=`<section class="panel guard-entry"><div class="panel-head"><div><h3>تسجيل مشوار</h3><p>اختر الوحدة ثم أدخل المشتريات؛ يمكن استكمال الأسعار لاحقًا.</p></div><span class="badge">الحارس</span></div><div id="guardQuickUnits" class="guard-quick-units"></div><div class="guard-unit-picker"><label class="field"><span>بحث برقم الوحدة / الدور / اسم أي عضو</span><span class="guard-unit-input-wrap"><input id="guardUnitSearch" autocomplete="off" oninput="onGuardUnitSearchInput()" onfocus="showGuardUnitResults()" onblur="hideGuardUnitResultsSoon()"><button type="button" class="guard-unit-clear" onclick="clearGuardUnitSearch()" title="اختيار ساكن آخر" aria-label="مسح اختيار الساكن">×</button></span></label><div id="guardUnitResults" class="unit-results guard-unit-results hidden"></div></div><div id="guardItemsBox">${tripItemsEditor(TRIP_UI.guardItems,'guardTrip')}</div><div class="guard-current-total"><span>إجمالي المشتريات للمشوار</span><strong id="guardCurrentPurchases">${money(0)}</strong></div><div class="section-actions"><button id="guardTripSubmit" class="btn-sm primary" onclick="submitGuardTrip()">تسجيل المشوار</button></div></section><section class="panel"><div class="panel-head"><div><h3>المشاوير المفتوحة</h3></div><span class="badge">${c.trips.length}</span></div>${renderGuardTripRows(c.trips)}</section><section class="panel"><div class="panel-head"><div><h3>التسويات</h3><p>بعد التسوية يظهر للحارس نفس ملف التسوية الذي يظهر للساكن.</p></div>${c.settlementsAvailable?`<span class="badge">${(c.settlements||[]).length}</span>`:''}</div>${c.settlementsAvailable?renderGuardSettlements(c.settlements||[]):`<div class="state-card">تعذر تحميل تسويات الحارس: ${esc(c.settlementsError||'حاول تحديث الصفحة')}</div>`}</section>`;renderGuardSelected();renderGuardQuickUnits();}catch(e){$('content').innerHTML=errorCard(e);}}
function normAr(v){return String(v||'').toLowerCase().replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/ـ/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه').trim();}
// Shared picker behavior used by guard units and service beneficiaries.
function searchablePickerMatches(value,query){return !normAr(query)||normAr(value).includes(normAr(query));}
function searchablePickerTermsMatches(value,query){
 const source=normAr(value),terms=normAr(query).split(/\s+/).filter(Boolean);
 return terms.every(term=>source.includes(term));
}
// Shared Arabic search for non-trip filterable collections. Trip screens retain their accepted behavior.
function uiSearchMatch(text,query){return searchablePickerTermsMatches(text,query);}
function uiFilterCollection(input,selector,root,metaPrefix){
 const scope=root||document,items=[...scope.querySelectorAll(selector)],query=(input?.value||'').trim();let shown=0;
 items.forEach(item=>{const show=uiSearchMatch(item.textContent||'',query);item.hidden=!show;if(show)shown++;});
 if(metaPrefix){const count=$(metaPrefix+'Count'),empty=$(metaPrefix+'Empty'),clear=$(metaPrefix+'Clear');
  if(count)count.textContent=`عرض ${shown} من ${items.length}`;
  if(empty)empty.hidden=shown!==0;
  if(clear)clear.disabled=!query;
 }
 return {shown,total:items.length};
}
function clearUiSearch(id,update){const input=$(id);if(!input)return;input.value='';update(input);input.focus();}
function searchablePickerCountLabel(found,total){return found===total?`${total} نتيجة متاحة`:`${found} من ${total} نتيجة`;}
function searchablePickerVisibleItems(list,selector){return list?Array.from(list.querySelectorAll(selector)).filter(x=>!x.hidden):[];}
function searchablePickerMove(list,selector,direction){
 const options=searchablePickerVisibleItems(list,selector);if(!options.length)return;
 let i=options.findIndex(x=>x.classList.contains('is-keyboard-active'));
 options.forEach(x=>{x.classList.remove('is-keyboard-active');x.removeAttribute('data-keyboard-active');});
 i=i<0?(direction>0?0:options.length-1):(i+direction+options.length)%options.length;
 options[i].classList.add('is-keyboard-active');options[i].setAttribute('data-keyboard-active','true');options[i].scrollIntoView({block:'nearest'});
}
function searchablePickerFirst(list,selector){return searchablePickerVisibleItems(list,selector).find(x=>x.classList.contains('is-keyboard-active'))||searchablePickerVisibleItems(list,selector)[0];}
function guardFloorLabel(v){const s=String(v==null?'':v).trim();return /^\d+$/.test(s)?s.padStart(2,'0'):(s||'—');}
function guardUnitLabel(u){return `شقة ${unitNo(u&&u.unitNumber||'—')} دور ${floorNo(u&&u.floor||'—')} (${String(u&&u.managerName||'—')})`;}
function filterGuardUnits(){const input=$('guardUnitSearch'),box=$('guardUnitResults');if(!input||!box||!TRIP_UI.guard)return;const q=normAr(input.value),rows=TRIP_UI.guard.units.filter(u=>searchablePickerMatches(u.search||guardUnitLabel(u),q)||searchablePickerMatches(guardUnitLabel(u),q)).slice(0,30);box.innerHTML=rows.length?rows.map(u=>`<div class="guard-unit-result-row"><button type="button" class="unit-pick guard-unit-pick structured" onmousedown="event.preventDefault()" onclick="selectGuardUnit('${esc(u.unitId)}')"><span><small>الوحدة</small><strong>${esc(unitNo(u.unitNumber))}</strong></span><span><small>الدور</small><strong>${esc(floorNo(u.floor))}</strong></span><span class="guard-manager"><small>مدير الوحدة</small><strong>${esc(u.managerName||'المدير غير متاح')}</strong></span></button><button type="button" class="guard-fav-btn ${guardFavorites().includes(u.unitId)?'active':''}" onmousedown="event.preventDefault()" onclick="toggleGuardFavorite('${esc(u.unitId)}',event)" aria-label="${guardFavorites().includes(u.unitId)?'إزالة من المفضلة':'إضافة إلى المفضلة'}">${guardFavorites().includes(u.unitId)?'★':'☆'}</button></div>`).join(''):`<div class="guard-unit-empty">لا توجد وحدة مطابقة للبحث.</div>`;}
function showGuardUnitResults(){const box=$('guardUnitResults');if(!box)return;box.classList.remove('hidden');filterGuardUnits();}
function hideGuardUnitResults(){const box=$('guardUnitResults');if(box)box.classList.add('hidden');}
function hideGuardUnitResultsSoon(){setTimeout(hideGuardUnitResults,120);}
function onGuardUnitSearchInput(){const input=$('guardUnitSearch');if(!input)return;const selected=TRIP_UI.guard&&TRIP_UI.guard.units.find(x=>x.unitId===TRIP_UI.selectedUnitId);if(selected&&input.value!==guardUnitLabel(selected))TRIP_UI.selectedUnitId='';syncGuardUnitClear();showGuardUnitResults();}
function clearGuardUnitSearch(){const input=$('guardUnitSearch');TRIP_UI.selectedUnitId='';if(!input)return;input.value='';syncGuardUnitClear();input.focus();showGuardUnitResults();}
function selectGuardUnit(id){TRIP_UI.selectedUnitId=id;renderGuardSelected();hideGuardUnitResults();const input=$('guardUnitSearch');if(input)input.blur();}
function renderGuardSelected(){const input=$('guardUnitSearch');if(!input)return;const u=TRIP_UI.guard&&TRIP_UI.guard.units.find(x=>x.unitId===TRIP_UI.selectedUnitId);if(u)input.value=guardUnitLabel(u);syncGuardUnitClear();}
function syncGuardUnitClear(){const input=$('guardUnitSearch'),clear=document.querySelector('.guard-unit-clear');if(clear)clear.hidden=!input||!input.value.trim();}
function guardTripNotesHtml(trip){
 if(trip.notesUnavailable)return '<p class="guard-trip-notes is-unavailable">تعذر تحميل ملاحظات المشوار دلوقتي.</p>';
 const notes=String(trip.notes||'').trim();
 return notes?`<p class="guard-trip-notes"><strong>ملاحظات الساكن</strong><span>${esc(notes)}</span></p>`:'';
}
function renderGuardTripRows(rows){if(!rows.length)return emptyState('لا توجد مشاوير مفتوحة','');return `<div class="trip-list">${rows.map(t=>`<article class="trip-card resident-trip-editable" tabindex="0" role="button" aria-label="فتح المشوار للتعديل" onclick="if(!event.target.closest('button,select,input,a'))openGuardTripEdit('${esc(t.tripId)}')" onkeydown="if(event.target===this&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openGuardTripEdit('${esc(t.tripId)}')}"><div class="trip-top resident-trip-top"><div class="trip-date-line"><strong>وحدة ${esc(unitNo(t.unitNumber))}</strong><span>${esc(t.managerName)}</span><strong class="trip-date-time">${residentTripDateLine(t.createdAt)}</strong></div><div class="guard-trip-actions"><button type="button" class="trip-history-icon" onclick="openOpenTripHistory('${esc(t.tripId)}')" aria-label="سجل تعديلات المشوار" title="سجل التعديلات"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7M3 3v6h6"/><path d="M12 7v5l3 2"/></svg></button><button type="button" class="trip-cancel-icon" onclick="cancelGuardTrip('${esc(t.tripId)}')" aria-label="إلغاء المشوار" title="إلغاء المشوار">×</button></div></div><div class="trip-orders guard-inline-purchases">${guardItemsInline(t)}</div>${guardTripNotesHtml(t)}<div class="trip-purchase"><span>المشتريات</span><strong>${money(t.purchasesTotal)}</strong></div></article>`).join('')}</div>`;}
let guardTripSubmitting=false;
async function submitGuardTrip(){if(guardTripSubmitting)return;if(!validateTripEditor('guardTrip'))return;if(!TRIP_UI.selectedUnitId){toast('اختر الوحدة أولًا.','error');return;}const items=collectTripItems('guardTrip');if(!validGuardItems(items))return;const btn=$('guardTripSubmit'),unitId=TRIP_UI.selectedUnitId;guardTripSubmitting=true;setButtonBusy(btn,true,'جاري التسجيل…');beginBackgroundSave();try{const r=await run('createGuardTrip',{unitId,items,requestId:TRIP_UI.requestId});rememberGuardRecent(unitId);toast(r&&r.duplicate?'المشوار كان مسجلًا بالفعل.':'تم تسجيل المشوار.');TRIP_UI.requestId=reqId();await renderGuardTrips(true);TRIP_UI.selectedUnitId=unitId;renderGuardSelected();}catch(e){toast(errText(e),'error');}finally{guardTripSubmitting=false;endBackgroundSave();setButtonBusy(btn,false);}}
function openGuardTripEdit(id){const t=TRIP_UI.guard.trips.find(x=>x.tripId===id);if(!t)return;openModal(`<div class="modal-head"><div><h3>تعديل المشتريات</h3><p>عدّل بنود المشتريات وأسعارها.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>${tripItemsEditor(t.items,'guardEdit')}<div class="form-actions"><button class="btn-sm primary" onclick="saveGuardTripEdit('${esc(id)}')">حفظ</button></div>`);updateTripEditorWarnings('guardEdit');}
async function saveGuardTripEdit(id){if(!validateTripEditor('guardEdit'))return;const items=collectTripItems('guardEdit');if(!validGuardItems(items))return;try{await run('updateGuardTrip',{tripId:id,items});closeModal();toast('تم حفظ المشتريات.');await renderGuardTrips(true);}catch(e){toast(errText(e),'error');}}
async function cancelGuardTrip(id){if(!await confirmAction({title:'إلغاء المشوار',message:'سيتم إلغاء آخر مشوار مفتوح مؤهل.',danger:true,confirmLabel:'إلغاء المشوار'}))return;try{await run('cancelGuardTrip',id);toast('تم إلغاء المشوار.');await renderGuardTrips(true);}catch(e){toast(errText(e),'error');}}
async function renderGuardAccounts(){ $('content').innerHTML=pageLoading('جاري تحميل الحسابات التشغيلية…');try{const rows=await run('getGuardAccounts');$('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الحسابات التشغيلية</h3><p>ملخص المشتريات التشغيلية المفتوحة حسب الوحدة.</p></div><span class="badge">${rows.length}</span></div>${rows.length?`<div class="list-stack">${rows.map(x=>`<div class="data-card"><div class="data-main"><div><strong>وحدة ${esc(unitNo(x.unitNumber))}</strong><span>${esc(x.managerName)} · ${x.openTripCount} مشوار</span></div><strong>${money(x.purchasesTotal)}</strong></div></div>`).join('')}</div>`:emptyState('لا توجد حسابات مفتوحة','')}</section>`;}catch(e){$('content').innerHTML=errorCard(e);}}




const SERVICE_UI={services:[],subscriptions:[]};
function cycleLabel(v){return 'شهري';}
function serviceTimingLabel(v){return v==='POSTPAID'?'مؤخر':'مقدم';}
function subStatusLabel(v){return({PENDING:'قيد المراجعة',ACTIVE:'نشط',REJECTED:'مرفوض',CANCELED:'ملغي',ENDED:'منتهي'})[v]||v||'—';}
async function renderServices(){const c=$('content');c.innerHTML=pageLoading('جاري تحميل الخدمات…');const servicesEpoch=++SERVICES_RENDER_EPOCH,servicesUser=APP.ctx?.user?.userId;try{if(APP.ctx.user.role==='RESIDENT'){await Promise.all([loadTaskWorkflows(),loadTaskNotices()]);const d=await run('getMyServices');if(APP.page!=='services'||c!==$('content')||servicesEpoch!==SERVICES_RENDER_EPOCH||APP.ctx?.user?.userId!==servicesUser)return;SERVICE_UI.services=d.services;SERVICE_UI.subscriptions=d.subscriptions;renderResidentServices(d);mountResidentPersonalHandovers();mountResidentPendingRefunds();return;}if(['ADMIN','UNION'].includes(APP.ctx.user.role)){await Promise.all([loadTaskWorkflows(),loadTaskNotices()]);const r=await Promise.all([run('listServices'),run('listServiceSubscriptionRequests'),run('listServiceChangeRequests')]);if(APP.page!=='services'||c!==$('content')||servicesEpoch!==SERVICES_RENDER_EPOCH||APP.ctx?.user?.userId!==servicesUser)return;SERVICE_UI.services=r[0];SERVICE_UI.subscriptions=r[1];SERVICE_UI.changes=r[2];await renderManageServices(SERVICE_UI.changes);return;}renderPlanned('services','الخدمات');}catch(e){if(APP.page==='services'&&c===$('content')&&servicesEpoch===SERVICES_RENDER_EPOCH)c.innerHTML=errorCard(e);}}
// Stage-only recipient inbox on the resident Services screen. Avoid exposing
// union-only ledger APIs or unrelated units; SQL 180 scopes by session user.
let SERVICES_RENDER_EPOCH=0;
let PERSONAL_PENDING_REQUEST_EPOCH=0;
async function mountResidentPersonalHandovers(){
 if(APP.ctx?.user?.role!=='RESIDENT'||APP.page!=='services')return;
 const epoch=++PERSONAL_PENDING_REQUEST_EPOCH;
 const page=document.getElementById('content');if(!page)return;
 let rows;
 try{rows=await run('listMyPersonalPendingHandovers');}catch(_e){return;} // feature disabled / unavailable
 if(epoch!==PERSONAL_PENDING_REQUEST_EPOCH||APP.page!=='services'||page!==document.getElementById('content')||!Array.isArray(rows))return;
 // Remove stale inbox when the authoritative read no longer has actionable rows.
 const existing=document.getElementById('residentPersonalHandoverInbox');if(existing)existing.remove();
 if(!rows.some(m=>m.canConfirm===true||m.canCancel===true))return;
 const panel=document.createElement('div');panel.id='residentPersonalHandoverInbox';
 panel.innerHTML=personalPendingHandoversPanel();page.prepend(panel);
 // Reuse the server-filtered listing; do not allow client-provided account/user ids.
 const root=document.getElementById('personalPendingHandovers');if(!root)return;
 root.innerHTML=personalPendingHandoversHtml(rows);
}
// Staging-only refunds: no cross-unit or manager selection is accepted from UI.
let PERSONAL_REFUND_INBOX_EPOCH=0;
const PERSONAL_REFUND_CONFIRMING=new Set();
async function mountResidentPendingRefunds(){
 if(APP.ctx?.user?.role!=='RESIDENT'||APP.page!=='services')return;
 const epoch=++PERSONAL_REFUND_INBOX_EPOCH,page=document.getElementById('content');
 let rows;try{rows=await run('listMyPendingPersonalRefunds');}catch(_e){return;}
 if(epoch!==PERSONAL_REFUND_INBOX_EPOCH||page!==document.getElementById('content')||APP.page!=='services'||!Array.isArray(rows))return;
 const available=rows.filter(r=>r&&r.canConfirm===true);
 const previous=document.getElementById('residentPersonalRefundInbox');
 if(previous)previous.remove();
 if(!available.length)return;
 const node=document.createElement('section');node.id='residentPersonalRefundInbox';node.className='panel';
 node.innerHTML=`<div class="panel-head"><div><h3>استرداد مقدم خدمة</h3><p>أكد الاستلام فقط بعد استلام المبلغ فعليًا.</p></div></div><div id="residentPersonalRefundItems">${available.map(r=>`<article class="data-card"><div class="data-main"><div><strong>رد مقدم — وحدة ${esc(r.unitNumber||'—')}</strong><span>${esc(r.requestedAt?displayDateTime12(r.requestedAt):'طلب معلق')}</span></div><strong>${money(r.amount||0)}</strong></div><button type="button" class="btn-sm primary" onclick="confirmResidentPersonalRefund('${esc(r.movementId)}')">تأكيد استلام المبلغ</button></article>`).join('')}</div>`;
 page.prepend(node);
}
async function confirmResidentPersonalRefund(movementId){
 if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(movementId)||PERSONAL_REFUND_CONFIRMING.has(movementId))return;
 if(!await confirmAction({title:'تأكيد استلام رد المقدم',message:'هل استلمت المبلغ فعليًا؟ لا تؤكد قبل استلامه.',confirmLabel:'تأكيد الاستلام'}))return;
 PERSONAL_REFUND_CONFIRMING.add(movementId);++PERSONAL_REFUND_INBOX_EPOCH;
 const pageAtConfirmation=document.getElementById('content');
 const panel=document.getElementById('residentPersonalRefundInbox');
 if(panel)panel.querySelectorAll('button').forEach(b=>b.disabled=true);
 try{await run('confirmPersonalUnitRefund',{movementId});toast('تم تأكيد استلام رد المقدم.','success');if(panel&&panel.isConnected)panel.remove();if(APP.page==='services'&&pageAtConfirmation===document.getElementById('content'))mountResidentPendingRefunds();}
 catch(e){toast(errText(e),'error');if(panel&&panel.isConnected&&pageAtConfirmation===document.getElementById('content'))panel.querySelectorAll('button').forEach(b=>b.disabled=false);}
 finally{PERSONAL_REFUND_CONFIRMING.delete(movementId);}
}
function personalPendingHandoversHtml(rows){
 return rows.length?rows.map(m=>`<article class="data-card"><div class="data-main"><div><strong>طلب عهدة معلّق</strong><span>${esc(m.counterpartyName||'الطرف الآخر')}</span></div><strong>${money(m.amount||0)}</strong></div><div class="compact-actions">${m.canConfirm===true?`<button class="btn-sm primary" onclick="resolveMyPersonalHandover('${esc(m.movementId)}','confirm')">تأكيد الاستلام</button>`:''}${m.canCancel===true?`<button class="btn-sm" onclick="resolveMyPersonalHandover('${esc(m.movementId)}','cancel')">إلغاء الطلب</button>`:''}</div></article>`).join(''):'<p>لا توجد طلبات عهدة معلقة تخص حسابك.</p>';
}
// One navigation state for both admin and resident service lists.
let TOWER_SERVICE_TAB='recurring';
function towerIsTask(s){return s?.serviceKind==='ONE_TIME';}
function towerServiceTabs(services,pending=[]){
 const taskAlerts=Object.values(TASK_NOTICES).reduce((a,b)=>a+Number(b||0),0) + (pending||[]).filter(q=>q.status==='PENDING'&&services.some(s=>s.serviceId===q.serviceId&&towerIsTask(s))).length + (['ADMIN','UNION'].includes(APP.ctx?.user?.role)?services.filter(s=>towerIsTask(s)&&TASK_WORKFLOW_META[s.serviceId]?.stage==='COLLECT_FUNDS'&&towerTaskReadiness(TASK_WORKFLOW_META[s.serviceId],s).ready).length:0);
 return `<div class="tower-service-tabs" role="tablist" aria-label="نوع الخدمة"><button type="button" role="tab" aria-selected="${TOWER_SERVICE_TAB==='recurring'}" class="tower-service-tab ${TOWER_SERVICE_TAB==='recurring'?'active':''}" onclick="towerSelectServiceTab('recurring')">الخدمات الدورية</button><button type="button" role="tab" aria-selected="${TOWER_SERVICE_TAB==='tasks'}" class="tower-service-tab ${TOWER_SERVICE_TAB==='tasks'?'active':''}" onclick="towerSelectServiceTab('tasks')">المهمات${taskAlerts?'<span class="tower-task-dot" aria-label="طلبات تستلزم إجراء"></span>':''}</button></div>`;
}
function towerSelectServiceTab(tab,fromHistory=false){const next=tab==='tasks'?'tasks':'recurring';if(!fromHistory&&TOWER_SERVICE_TAB!==next&&history.state?.towerPage==='services')history.pushState({...history.state,towerTab:next,towerModal:false},'');TOWER_SERVICE_TAB=next;document.querySelectorAll('.tower-service-tab').forEach(b=>{const active=b.textContent.includes('المهمات')?TOWER_SERVICE_TAB==='tasks':TOWER_SERVICE_TAB==='recurring';b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));});document.querySelectorAll('[data-tower-service-kind]').forEach(el=>{el.hidden=el.dataset.towerServiceKind!==TOWER_SERVICE_TAB;});const z=document.getElementById('tower-service-empty');if(z){const visible=[...document.querySelectorAll('[data-tower-service-kind]')].filter(x=>!x.hidden);z.hidden=visible.length>0;z.textContent=TOWER_SERVICE_TAB==='tasks'?'لا توجد مهمات في هذا التبويب.':'لا توجد خدمات دورية في هذا التبويب.';}}
function towerTaskStage(s){const state=s?.enrollmentStatus;return state==='OPEN'?'تجميع المشتركين':state==='CLOSED'?'بانتظار اعتماد التوزيع':state==='FINALIZED'?'تجميع التكلفة':'لم تبدأ';}
// Financially neutral installment projection: the sole underlying due is unchanged.
function towerTaskInstallmentProjection(meta){
 const count=Number(meta?.installmentCount);
 const n=Number.isInteger(count)&&count>=1&&count<=36?count:0;
 const amount=Number(meta?.approvedDues);
 const first=String(meta?.firstDueDate||'');
 if(!n||!Number.isFinite(amount)||amount<=0||Math.round(amount*100)!==amount*100||!/^(?:19|20|21)\d{2}-\d{2}-\d{2}$/.test(first))return [];
 const cents=Math.round(amount*100);
 // No zero-value installments: the actual ledger is not split or rewritten.
 if(cents<n)return [];
 const base=Math.floor(cents/n),extra=cents%n;
 const [year,month,day]=first.split('-').map(Number);
 if(month<1||month>12||day<1||day>new Date(Date.UTC(year,month,0)).getUTCDate())return [];
 return Array.from({length:n},(_,i)=>{
  const monthIndex=(month-1)+i,y=year+Math.floor(monthIndex/12),m=monthIndex%12+1;
  const last=new Date(Date.UTC(y,m,0)).getUTCDate();
  const dueDate=`${y}-${String(m).padStart(2,'0')}-${String(Math.min(day,last)).padStart(2,'0')}`;
  return {number:i+1,dueDate,amount:(base+(i<extra?1:0))/100};
 });
}
function towerLocalDate(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function towerTaskFinancialSnapshot(meta,service){
 const rawBudget=Number(service?.totalBudget),rawFund=Number(meta?.fundContributionPosted||0),rawCollected=Number(meta?.collected||0);
 if(![rawBudget,rawFund,rawCollected].every(Number.isFinite)||rawBudget<=0||rawFund<0||rawFund>rawBudget||rawCollected<0)return null;
 const budget=Math.round(rawBudget*100),fund=Math.round(rawFund*100),collected=Math.round(rawCollected*100);
 if([rawBudget,rawFund,rawCollected].some((v,i)=>Math.abs(v*100-[budget,fund,collected][i])>0.000001))return null;
 const rawApproved=meta?.approvedDues;
 const net=service?.enrollmentStatus==='FINALIZED'&&rawApproved!=null&&Number.isFinite(Number(rawApproved))&&Number(rawApproved)>=0?Math.round(Number(rawApproved)*100):budget-fund;
 return {budget,fund,net,collected,remaining:Math.max(0,net-collected),percent:net?Math.min(100,Math.floor(collected*100/net)):0};
}
function towerTaskReadiness(meta,service){
 if(!meta||service?.enrollmentStatus!=='FINALIZED')return {ready:false,message:'يجب اعتماد التوزيع أولًا'};
 const snapshot=towerTaskFinancialSnapshot(meta,service);
 if(!snapshot)return {ready:false,message:'تعذر التحقق من بيانات التكلفة والتحصيل'};
 const value=Number(meta.collectionThreshold);
 const threshold=Number.isFinite(value)&&value>=1&&value<=100?value:100;
 const minimum=Number(meta.minimumStartAmount||0);
 const reached=minimum>0?snapshot.collected>=Math.round(minimum*100):snapshot.net===0||snapshot.collected*100>=snapshot.net*threshold;
 const date=String(meta.executionDate||'');
 const validDate=/^\d{4}-\d{2}-\d{2}$/.test(date)&&!Number.isNaN(Date.parse(date))&&new Date(`${date}T00:00:00Z`).toISOString().slice(0,10)===date;
 const datePassed=validDate&&date<=towerLocalDate();
 const rule=meta.startRule||'MANUAL';
 const ready=rule==='MANUAL'&&minimum>0?reached:rule==='COLLECTION'?reached:rule==='DATE'?(datePassed&&(minimum<=0||reached)):rule==='DATE_AND_COLLECTION'?(datePassed&&reached):false;
 return {ready,message:ready?'شروط بدء التنفيذ متحققة — تحتاج تأكيد الإدارة':rule==='MANUAL'&&minimum<=0?'بدء التنفيذ بقرار الإدارة':`شروط البدء لم تتحقق بعد (التحصيل ${snapshot.percent}% من صافي تكلفة المهمة)`};
}
async function openTaskInstallments(serviceId){
 const current=(SERVICE_UI.services||[]).find(x=>x.serviceId===serviceId);if(current?current.pricingMode==='SHARED_TOTAL':TASK_PROJECT_DATA.has(serviceId))return openTaskProject(serviceId,true,'payments');
 try{
  const result=await run('listTaskInstallments',serviceId);
  const rows=Array.isArray(result?.rows)?result.rows:[];
  const name=(SERVICE_UI.services||[]).find(s=>s.serviceId===serviceId)?.name||'المهمة';
  const admin=['ADMIN','UNION'].includes(APP.ctx?.user?.role);
  const unitGroups=new Map();
  rows.forEach(r=>{const k=String(r.unitId||'');if(!unitGroups.has(k))unitGroups.set(k,[]);unitGroups.get(k).push(r);});
  const html=rows.length?Array.from(unitGroups.values()).map(group=>`<section class="tower-task-installment-unit"><strong>الوحدة: ${esc((SERVICE_UI.units||[]).find(u=>u.unitId===group[0].unitId)?.unitNumber||'—')}</strong>${group.map(r=>`<div class="tower-task-installment-row"><span>قسط ${r.installment} · ${esc(r.dueDate)}</span><strong>${money(r.amount)} · متبقي ${money(r.remaining)}</strong></div>`).join('')}</section>`).join(''):result.noPlanNeeded?'<p class="muted">لا توجد مستحقات تحتاج جدول أقساط.</p>':result.hasPayments?'<p class="muted">تثبيت خطة الأقساط يحتاج أن يكون قبل بدء السداد. المديونية والمدفوع محفوظان في دفتر الوحدة.</p>':'<p class="muted">لم يُثبّت جدول أقساط لهذه المهمة بعد.</p>';
  openModal(`<div class="modal-head"><div><h3>أقساط المهمة</h3><p>${esc(name)}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><div class="tower-task-installment-list">${html}</div><p class="small muted">الأقساط أجزاء من المستحق الأصلي، والسداد الفعلي يُخصم من الدفتر المحاسبي؛ يمكن سداد المتبقي كاملًا من شاشة التحصيل.</p><div class="form-actions">${admin&&!rows.length&&!result.noPlanNeeded&&!result.hasPayments?`<button class="btn-sm primary" onclick="installTaskInstallments('${esc(serviceId)}')">تثبيت جدول الأقساط</button>`:''}<button class="btn-sm" onclick="closeModal()">إغلاق</button></div>`,true);
 }catch(e){toast(errText(e),'error');}
}
async function installTaskInstallments(serviceId){
 if(!await confirmAction({title:'تثبيت خطة الأقساط',message:'سيتم إنشاء جدول استحقاق للأقساط من الدين الأصلي دون أي دين جديد. لا يمكن تثبيت الخطة بعد وجود سداد فعلي، ولا تعديلها بعد التثبيت. هل تريد المتابعة؟',confirmLabel:'تثبيت'}))return;
 try{await run('installTaskInstallments',serviceId);await openTaskInstallments(serviceId);toast('تم تثبيت جدول الأقساط','success');}catch(e){toast(errText(e),'error');}
}
function towerTaskPaymentPlanHtml(s,meta){
 if(s?.enrollmentStatus!=='FINALIZED'||!meta)return '';
 const rows=towerTaskInstallmentProjection(meta);
 const applied=Math.max(0,Number(meta.collected)||0);
 const total=Math.max(0,Number(meta.approvedDues)||0);
 const balance=Math.max(0,Math.round(total*100)-Math.round(applied*100))/100;
 return `<section class="tower-task-payment" aria-label="خطة السداد"><div class="tower-task-workflow-head"><strong>متابعة السداد</strong><span>${money(balance)} متبقي من المستحقات المعتمدة</span></div><button type="button" class="btn-sm service-action-secondary" onclick="openTaskInstallments('${esc(s.serviceId)}')">الأقساط</button><p class="tower-task-workflow-hint">المحصل بالفعل: ${money(applied)} · إجمالي المستحقات: ${money(total)}. يمكن تسجيل السداد الكامل أو الجزئي عبر التحصيل المعتاد، ولا يُنشئ هذا العرض مستحقات جديدة.</p>${rows.length?`<details><summary>عرض جدول الأقساط التخطيطي (${rows.length})</summary><div class="tower-task-plan-rows">${rows.map(r=>`<div><span>قسط ${r.number} · ${esc(r.dueDate)}</span><strong>${money(r.amount)}</strong></div>`).join('')}</div><p class="small muted">الجدول إرشادي ولم يُعتمد كأقساط مالية مستقلة؛ المدفوع والمتبقي مصدرهما دفتر المستحقات.</p></details>`:'<p class="small muted">لم يُحدد تاريخ بداية الأقساط، أو لم تُنشأ مستحقات معتمدة.</p>'}</section>`;
}
function towerTaskStageHtml(s){
 if(!towerIsTask(s))return '';
 const meta=TASK_WORKFLOW_META[s.serviceId]||null;
 const state=s?.enrollmentStatus;
 const stages=['تجميع المشتركين','تجميع التكلفة','جاهز للتنفيذ','جار التنفيذ','مكتملة'];
 const enrolled=state==='CLOSED'||state==='FINALIZED';
 const financeStage=state==='FINALIZED';
 const stageIndex=meta?Object.keys(TASK_STAGE_NAMES).indexOf(meta.stage):-1;
 const collected=Number(meta?.collected||0),due=Number(meta?.approvedDues||0);
 const netBudget=Math.max(0,(Number(s.totalBudget)||0)-(Number(meta?.fundContributionPosted)||0));
 const collectionPercent=netBudget>0?Math.min(100,Math.floor(100*collected/netBudget)):0;
 const status=state==='OPEN'?'تجميع المشتركين':state==='CLOSED'?'الاشتراك مغلق · بانتظار اعتماد التوزيع':financeStage?'تجميع التكلفة · الاستحقاقات معتمدة':'لم تبدأ';
 const cards=stages.map((label,i)=>{
  const done=meta&&stageIndex>=0?i<stageIndex:i===0&&enrolled;
  const active=meta&&stageIndex>=0?i===stageIndex:i===0&&!enrolled||i===1&&financeStage;
  return `<li class="tower-task-step ${done?'is-done':active?'is-current':'is-later'}" aria-current="${active?'step':'false'}"><span class="tower-task-step-num">${done?'✓':i+1}</span><span class="tower-task-step-label">${label}</span></li>`;
 }).join('');
 const readiness=towerTaskReadiness(meta,s);
 const financial=towerTaskFinancialSnapshot(meta,s);
 const facts=financeStage&&financial?`<div class="tower-task-finance-summary" aria-label="ملخص الحساب المالي للمهمة"><div><span>الصافي المطلوب</span><strong>${money(financial.net/100)}</strong></div><div><span>المحصّل من السكان</span><strong>${money(financial.collected/100)}</strong></div><div><span>المتبقي</span><strong>${money(financial.remaining/100)}</strong></div></div>`:'';
 const note=meta&&financeStage?'المحصل فعليًا: '+money(collected)+' من أصل '+money(due)+' ('+collectionPercent+'%) · التنفيذ: '+Number(meta.executionPercent||0)+'% · '+readiness.message:state==='CLOSED'?'باب الاشتراك مغلق؛ يلزم اعتماد التوزيع قبل حساب التحصيل.':financeStage?'تم اعتماد الأنصبة؛ التحصيل يُراجع من دفتر المستحقات.':'النصيب الحالي تقديري وقد يتغير حتى إغلاق الاشتراك.';
 return `<section class="tower-task-workflow" aria-label="مراحل المهمة"><div class="tower-task-workflow-head"><strong>سير المهمة</strong><span>${esc(meta?.stage?TASK_STAGE_NAMES[meta.stage]:status)}</span></div><ol class="tower-task-steps">${cards}</ol>${facts}<p class="tower-task-workflow-hint">${esc(note)}</p>${towerTaskPaymentPlanHtml(s,meta)}</section>`;
}
// Task plan and verified collections use the same authoritative RPC for admin and resident.
let TASK_WORKFLOW_META={};
let TASK_NOTICES={};
async function loadTaskNotices(){try{const rows=await run('listTaskNotices');TASK_NOTICES=Object.fromEntries((Array.isArray(rows)?rows:[]).map(r=>[r.serviceId,r.unreadCount||0]));}catch(e){TASK_NOTICES={};console.warn('Task notices unavailable',String(e?.message||e).slice(0,80));}}
async function markTaskSeen(serviceId){if(!TASK_NOTICES[serviceId])return;try{await run('markTaskNoticeRead',serviceId);delete TASK_NOTICES[serviceId];document.querySelectorAll(`[data-task-alert-id="${serviceId}"]`).forEach(x=>x.remove());}catch(e){console.warn('Unable to mark task notice read');}}
const TASK_STAGE_NAMES={COLLECT_SUBSCRIBERS:'تجميع المشتركين',COLLECT_FUNDS:'تجميع التكلفة',READY:'جاهز للتنفيذ',IN_PROGRESS:'جار التنفيذ',COMPLETED:'مكتملة'};
async function loadTaskWorkflows(){try{const rows=await run('listTaskWorkflows');TASK_WORKFLOW_META=Object.fromEntries((Array.isArray(rows)?rows:[]).map(x=>[x.serviceId,x]));}catch(e){TASK_WORKFLOW_META={};console.warn('Task workflow metadata unavailable',String(e?.message||e).slice(0,90));}}
async function editTaskWorkflow(serviceId){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role))return;
 const s=(SERVICE_UI.services||[]).find(x=>x.serviceId===serviceId);if(!s)return;
 const current=TASK_WORKFLOW_META[serviceId]||{};
 // The database is authoritative: never offer a second confirmation for a received contribution.
 let fundReceiptState=null;
 if(Number(current.fundContributionPosted||0)>0){
  try{fundReceiptState=await run('getTaskFundReceiptStatus',serviceId);}
  catch(e){console.warn('Task fund receipt status unavailable',String(e?.message||e).slice(0,100));}
 }
 const fundReceiptConfirmed=fundReceiptState?.confirmed===true;
 const fundReceiptReady=Number(current.fundContributionPosted||0)>0&&fundReceiptState!==null&&!fundReceiptConfirmed;
 const fundReceiptLabel=fundReceiptConfirmed?'تم تأكيد استلام المساهمة':fundReceiptState===null&&Number(current.fundContributionPosted||0)>0?'تعذر التحقق من حالة الاستلام':'تأكيد استلام مساهمة الصندوق بحساب المهمة';
 const fundReceiptInfo=fundReceiptConfirmed?'تم توثيق استلام '+money(Number(fundReceiptState.confirmedAmount||0))+' في عهدة المسؤول الذي أكد الاستلام.':fundReceiptState===null&&Number(current.fundContributionPosted||0)>0?'حالة الاستلام غير متاحة؛ حاول فتح المهمة مرة أخرى.':'يُضاف مبلغ المساهمة إلى عهدة الشخص الذي يؤكد استلام النقد، دون تحصيلات سكان';
 const validTaskStages=s.enrollmentStatus==='OPEN'?['COLLECT_SUBSCRIBERS','COLLECT_FUNDS']:s.enrollmentStatus==='FINALIZED'?['COLLECT_FUNDS','READY','IN_PROGRESS','COMPLETED']:['COLLECT_FUNDS'];
 const currentStage=validTaskStages.includes(current.stage)?current.stage:(s.enrollmentStatus==='OPEN'?'COLLECT_SUBSCRIBERS':'COLLECT_FUNDS');
 const opts=Object.entries(TASK_STAGE_NAMES).filter(([k])=>validTaskStages.includes(k)).map(([k,v])=>`<option value="${k}" ${currentStage===k?'selected':''}>${v}</option>`).join('');
 openModal(`<div class="modal-head"><div><h3>إدارة تقدم المهمة</h3><p>${esc(s.name)}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div>
 <div class="task-plan-form tower-task-plan-unified">
 <label><span>المرحلة الحالية</span><select id="taskStageInput">${opts}</select></label>
 <label><span>شرط بدء التنفيذ</span><select id="taskRuleInput"><option value="MANUAL">بقرار الإدارة</option><option value="DATE">في موعد محدد</option><option value="COLLECTION">عند بلوغ نسبة التحصيل</option><option value="DATE_AND_COLLECTION">الموعد ونسبة التحصيل معًا</option></select></label>
 <label class="task-needs-date"><span>موعد التنفيذ</span><input id="taskDateInput" type="date" value="${esc(current.executionDate||'')}"></label>
 <label class="task-needs-collection"><span>نسبة التحصيل المطلوبة (%)</span><input id="taskThresholdInput" type="number" min="1" max="100" value="${Number(current.collectionThreshold)||100}"></label>
 <label><span>تقدم الأعمال الفعلي (%)</span><input id="taskExecutionInput" type="number" min="0" max="100" value="${Number(current.executionPercent)||0}"></label>
 <label><span>عدد الأقساط المقترح (1–36)</span><input id="taskInstallmentsInput" type="number" min="1" max="36" value="${Number(current.installmentCount)||1}"></label>
 <label><span>تاريخ بداية الأقساط</span><input id="taskFirstDueInput" type="date" value="${esc(current.firstDueDate||'')}"></label>
 <label><span>مساهمة الصندوق المقترحة (جنيه)</span><input id="taskFundInput" type="number" min="0" step="0.01" max="${Number(s.totalBudget)||0}" value="${Number(current.fundContributionProposed)||0}"></label>
 </div>
 <section class="tower-fund-management" aria-label="مساهمة الصندوق"><div class="tower-fund-heading"><strong>مساهمة الصندوق</strong><span class="badge">${fundReceiptConfirmed?'تم تأكيد الاستلام':Number(current.fundContributionPosted||0)>0?'بانتظار الاستلام':'غير مسجلة'}</span></div>
 <div class="tower-fund-facts"><div><span>المساهمة المقترحة</span><strong>${money(Number(current.fundContributionProposed||0))}</strong></div><div><span>المساهمة المسجلة فعليًا</span><strong>${money(Number(current.fundContributionPosted||0))}</strong></div></div>
 <div class="tower-fund-impact"><span>صافي التكلفة التقديري على السكان</span><strong>${money(Math.max(0,Math.round((Number(s.totalBudget||0)-Number(current.fundContributionProposed||0))*100)/100))}</strong><small>قبل اعتماد التوزيع، هذا تقدير فقط وليس قيدًا ماليًا.</small></div>
 ${fundReceiptConfirmed?`<p class="tower-fund-state-success">✓ تم تأكيد استلام المساهمة. ${esc(fundReceiptInfo)}</p>`:Number(current.fundContributionPosted||0)>0?`<div class="tower-fund-action"><button type="button" class="btn-sm primary" onclick="confirmTaskFundReceipt('${esc(serviceId)}')" ${fundReceiptReady?'':'disabled'}>تأكيد استلام المساهمة</button>${fundReceiptReady?'':`<p class="small muted">${esc(fundReceiptInfo)}</p>`}</div>`:`<div class="tower-fund-action"><button type="button" class="btn-sm primary" onclick="postTaskFundContribution('${esc(serviceId)}')" ${s.enrollmentStatus==='CLOSED'?'':'disabled'}>تنفيذ مساهمة الصندوق</button>${s.enrollmentStatus!=='CLOSED'?'<p class="small muted">أغلق باب الاشتراك أولًا لتسجيل مساهمة الصندوق، ثم اعتمد التوزيع.</p>':''}</div>`}
 </section>
 <div class="form-actions tower-task-plan-footer"><button type="button" class="btn-sm primary" onclick="saveTaskWorkflow('${esc(serviceId)}')">حفظ الخطة</button><button type="button" class="btn-sm" onclick="closeModal()">إلغاء</button></div>`,true);
 const choice=document.getElementById('taskRuleInput');if(choice){choice.value=current.startRule||'MANUAL';choice.addEventListener('change',updateTaskRuleFields);updateTaskRuleFields();}
}
function updateTaskRuleFields(){
 const rule=document.getElementById('taskRuleInput')?.value||'MANUAL';
 const date=rule==='DATE'||rule==='DATE_AND_COLLECTION';const collection=rule==='COLLECTION'||rule==='DATE_AND_COLLECTION';
 document.querySelectorAll('.task-needs-date').forEach(el=>el.hidden=!date);
 document.querySelectorAll('.task-needs-collection').forEach(el=>el.hidden=!collection);
}
async function postTaskFundContribution(serviceId){
 const proposed=Number(TASK_WORKFLOW_META[serviceId]?.fundContributionProposed||0);
 if(!(proposed>0)){toast('احفظ مبلغ مساهمة الصندوق المقترح أولًا.','error');return;}
 if(!await confirmAction({title:'تخصيص مساهمة الصندوق',message:'سيُسجل مصروف حقيقي من صندوق العمارة لتمويل المهمة بمبلغ '+money(proposed)+'، وسيُخصم من المبلغ الذي يوزع على الوحدات قبل الاعتماد. لا يمكن تكرار العملية أو تغييرها تلقائيًا.',confirmLabel:'تأكيد التمويل'}))return;
 try {await run('postTaskFundContribution',serviceId);closeModal();await loadTaskWorkflows();await renderServices();toast('تم تسجيل مصروف مساهمة الصندوق. يلزم تأكيد استلامها في حساب المهمة بشكل منفصل.','success');}
 catch(e){toast(errText(e),'error');}
}
async function confirmTaskFundReceipt(serviceId){
 try{const status=await run('getTaskFundReceiptStatus',serviceId);if(status?.confirmed){toast('تم تأكيد استلام مساهمة الصندوق بالفعل.','info');return;}}
 catch(e){toast('تعذر التحقق من حالة الاستلام: '+errText(e),'error');return;}
 if(!await confirmAction({title:'تأكيد استلام مساهمة الصندوق',message:'أكد فقط أن مبلغ مساهمة الصندوق وصل إلى مسؤول حساب المهمة. هذا توثيق استلام مستقل ولا يخصم الصندوق مرة ثانية.',confirmLabel:'تأكيد الاستلام'}))return;
 try{await run('confirmTaskFundReceipt',serviceId);closeModal();await loadTaskWorkflows();await renderServices();toast('تم توثيق المساهمة وإضافتها إلى عهدتك النقدية بحساب المهمة.','success');}
 catch(e){toast(errText(e),'error');}
}
async function saveTaskWorkflow(serviceId){
 const get=id=>document.getElementById(id)?.value;
 const payload={serviceId,stage:get('taskStageInput'),startRule:get('taskRuleInput'),executionDate:get('taskDateInput')||null,collectionThreshold:Number(get('taskThresholdInput')),executionPercent:Number(get('taskExecutionInput')),installmentCount:Number(get('taskInstallmentsInput')),firstDueDate:get('taskFirstDueInput')||null,fundContributionProposed:Number(get('taskFundInput'))};
 const service=(SERVICE_UI.services||[]).find(s=>s.serviceId===serviceId);
 if(!service){toast('تعذر العثور على المهمة. حدّث بيانات الخدمات.','error');return;}
 if(service.enrollmentStatus!=='OPEN'&&payload.stage==='COLLECT_SUBSCRIBERS'){toast('الاشتراك مغلق؛ لا يمكن الرجوع لمرحلة تجميع المشتركين.','error');return;}
 if(service.enrollmentStatus!=='FINALIZED'&&['READY','IN_PROGRESS','COMPLETED'].includes(payload.stage)){toast('لا يمكن بدء التنفيذ قبل اعتماد توزيع تكلفة المهمة.','error');return;}
 const saved=TASK_WORKFLOW_META[serviceId]||{};
 if(service.enrollmentStatus==='FINALIZED'&&Math.round(Number(payload.fundContributionProposed)*100)!==Math.round(Number(saved.fundContributionProposed||0)*100)){toast('مساهمة الصندوق مقفلة بعد اعتماد التوزيع ولا يمكن تغييرها.','error');return;}
 const blocked=towerTaskTransitionBlock(payload,service,saved);if(blocked){toast(blocked,'error');return;}
 if(!Number.isInteger(payload.collectionThreshold)||payload.collectionThreshold<1||payload.collectionThreshold>100){toast('نسبة التحصيل المطلوبة يجب أن تكون عددًا صحيحًا بين 1 و100%.','error');return;}
 if(!['MANUAL','DATE','COLLECTION','DATE_AND_COLLECTION'].includes(payload.startRule)){toast('شرط بدء التنفيذ غير صالح.','error');return;}
 if(!['COLLECT_SUBSCRIBERS','COLLECT_FUNDS','READY','IN_PROGRESS','COMPLETED'].includes(payload.stage)){toast('مرحلة المهمة غير صالحة.','error');return;}
 if(!Number.isFinite(payload.executionPercent)||payload.executionPercent<0||payload.executionPercent>100){toast('تقدم الأعمال يجب أن يكون بين 0 و100%.','error');return;}
 if(!Number.isInteger(payload.installmentCount)||payload.installmentCount<1||payload.installmentCount>36){toast('عدد الأقساط يجب أن يكون من 1 إلى 36.','error');return;}
 if(!Number.isFinite(payload.fundContributionProposed)||payload.fundContributionProposed<0||payload.fundContributionProposed>Number(service?.totalBudget||0)){toast('المساهمة المقترحة لا يجوز أن تتجاوز تكلفة المهمة.','error');return;}
 if(!Number.isInteger(payload.executionPercent)){toast('نسبة تقدم الأعمال لازم تكون عددًا صحيحًا من 0 إلى 100%.','error');return;}
 if(!Number.isInteger(Math.round(payload.fundContributionProposed*100))||Math.abs(payload.fundContributionProposed*100-Math.round(payload.fundContributionProposed*100))>0.000001){toast('مساهمة الصندوق تُكتب بدقة قرشين فقط.','error');return;}
 const exactDate=value=>{if(!value)return true;if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const dt=new Date(value+'T00:00:00Z');return !Number.isNaN(dt.getTime())&&dt.toISOString().slice(0,10)===value;};
 if(!exactDate(payload.firstDueDate)||!exactDate(payload.executionDate)){toast('راجع التاريخ المدخل؛ اليوم غير موجود في هذا الشهر.','error');return;}
 if(['DATE','DATE_AND_COLLECTION'].includes(payload.startRule)&&!/^\d{4}-\d{2}-\d{2}$/.test(payload.executionDate||'')){toast('حدد تاريخ تنفيذ صحيحًا للشرط المختار.','error');return;}
 if(['COLLECTION','DATE_AND_COLLECTION'].includes(payload.startRule)&&(!Number.isFinite(payload.collectionThreshold)||payload.collectionThreshold<1||payload.collectionThreshold>100)){toast('نسبة التحصيل المطلوبة يجب أن تكون من 1 إلى 100%.','error');return;}
 try{await run('saveTaskWorkflow',payload);towerAcceptTaskFormChanges();closeModal();await loadTaskWorkflows();await renderServices();toast('تم حفظ مراحل وخطة المهمة.','success');}catch(e){toast('تعذر حفظ خطة المهمة: '+errText(e),'error');}
}
function renderResidentServices(d){
 SERVICE_UI.services=Array.isArray(d.services)?d.services:[];SERVICE_UI.subscriptions=Array.isArray(d.subscriptions)?d.subscriptions:[];
 const current=id=>(d.subscriptions||[]).find(s=>s.serviceId===id&&['PENDING','ACTIVE'].includes(s.status));
 $('content').innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الخدمات</h3><p>المهام تعرض حالتها ونصيبها التقديري أو مرجع المستحق النهائي حسب مرحلة الاشتراك.</p></div></div>${towerServiceTabs(d.services)}${d.services.length?`<div class="list-stack">${d.services.map(s=>`<div data-tower-service-kind="${towerIsTask(s)?'tasks':'recurring'}" ${TOWER_SERVICE_TAB===(towerIsTask(s)?'tasks':'recurring')?'':'hidden'}>${towerIsTask(s)&&TASK_NOTICES[s.serviceId]?`<span data-task-alert-id="${esc(s.serviceId)}" class="tower-task-notice-pill" role="status">● تحديث جديد</span>`:''}${residentServiceCard(s,current(s.serviceId))}${towerTaskStageHtml(s)}</div>`).join('')}</div><p id="tower-service-empty" ${d.services.some(s=>(towerIsTask(s)?'tasks':'recurring')===TOWER_SERVICE_TAB)?'hidden':''}>${TOWER_SERVICE_TAB==='tasks'?'لا توجد مهمات في هذا التبويب.':'لا توجد خدمات دورية في هذا التبويب.'}</p>`:emptyState('لا توجد خدمات متاحة','')}</section>`;
}

function openResidentServiceDetails(id){
 return openServiceWorkspaceOrTask(id);
}
// Service mutations may start on Unit or Services. Refresh only the current
// resident's matching unit view; never redirect a user who has navigated away.
function towerResidentServiceOrigin(){return {userId:APP.ctx?.user?.userId,unitId:APP.activeUnitId};}
function towerResidentServiceOriginMatches(origin){return APP.ctx?.user?.role==='RESIDENT'&&APP.ctx.user.userId===origin.userId&&APP.activeUnitId===origin.unitId;}
function towerCheckResidentServiceOrigin(origin){
 if(towerResidentServiceOriginMatches(origin))return true;
 toast('الوحدة أو الحساب اتغير. افتح الخدمة من الوحدة المطلوبة وجرب تاني.','error');return false;
}
async function towerRefreshResidentServices(origin){
 if(!towerResidentServiceOriginMatches(origin))return;
 if(['unit','units'].includes(APP.page))await renderUnits();
 else if(APP.page==='services')await renderServices();
 await refreshOpenServiceWorkspace();
 const workspace=typeof taskProjectCurrentHub==='function'?taskProjectCurrentHub():null;if($('modalSheet')?.querySelector('.task-workspace')&&workspace&&taskProjectOriginMatches(workspace))await openTaskProject(workspace.serviceId,true);
}
function towerResidentServiceUnitLabel(){
 const unit=(APP.unitChoices||[]).find(x=>x.unit?.unitId===APP.activeUnitId)?.unit;
 return unit?.unitNumber!=null?unitNo(unit.unitNumber):'الوحدة المختارة';
}
async function requestService(id,autoRenew,allowQuantity){const origin=towerResidentServiceOrigin();let quantity=1;if(allowQuantity){const q=await promptAction({title:'كمية الاشتراك',message:'حدد الكمية المطلوبة للخدمة.',label:'الكمية',value:'1',type:'number',confirmLabel:'متابعة'});if(q==null)return;quantity=Number(q)||1;if(quantity<1)return;}const service=SERVICE_UI.services.find(x=>x.serviceId===id),price=Number(service?.price||0);if(service?.pricingMode==='SHARED_TOTAL'&&service.enrollmentStatus!=='OPEN'){toast('باب الاشتراك في هذه المهمة مغلق.','error');return;}if(!await confirmAction({title:'مراجعة طلب الاشتراك',message:`الخدمة: ${service?.name||'—'}\nالوحدة: ${towerResidentServiceUnitLabel()}\n${service?.pricingMode==='SHARED_TOTAL'?'التكلفة الإجمالية: '+money(service.totalBudget)+' — نصيب الوحدة يتحدد عند اعتماد التوزيع':'سعر الاشتراك: '+money(price)}\nالعدد: ${quantity}\n${service?.pricingMode==='SHARED_TOTAL'?'المستحق الآن: لم يُحدد بعد':'الإجمالي: '+money(price*quantity)}\nسيُرسل الطلب للمراجعة قبل تفعيل الاشتراك.`,confirmLabel:'إرسال الطلب'}))return;if(!towerCheckResidentServiceOrigin(origin))return;try{await run('requestServiceSubscription',id,autoRenew,quantity);await towerRefreshResidentServices(origin);toast('تم إرسال الطلب.');}catch(e){toast(errText(e),'error');}}
async function editPendingService(id,qty,allowQuantity){const origin=towerResidentServiceOrigin();if(!allowQuantity){toast('هذه الخدمة لها اشتراك واحد فقط.');return;}const q=await promptAction({title:'تعديل طلب الاشتراك',message:'يمكن تعديل الكمية قبل الموافقة على الطلب.',label:'الكمية',value:String(qty||1),type:'number',confirmLabel:'حفظ التعديل'});if(q==null)return;if(!towerCheckResidentServiceOrigin(origin))return;beginBackgroundSave();try{await run('updatePendingServiceSubscription',id,Number(q)||1);await towerRefreshResidentServices(origin);toast('تم تحديث الطلب.');}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
async function requestServiceChangeUi(id,type,currentQty,allowQuantity){const origin=towerResidentServiceOrigin();let qty=1;if(allowQuantity){const q=await promptAction({title:type==='ADD'?'إضافة اشتراك':'طلب الإلغاء',message:type==='ADD'?`العدد الحالي ${currentQty}. حدد عدد الاشتراكات الإضافية.`:`العدد الحالي ${currentQty}. حدد عدد الاشتراكات المطلوب إلغاؤها.`,label:'العدد',value:'1',type:'number',confirmLabel:'إرسال الطلب'});if(q==null)return;qty=Number(q);if(!Number.isInteger(qty)||qty<1||qty>99){toast('أدخل عددًا صحيحًا من 1 إلى 99.','error');return;}if(type==='ADD'&&qty>99-currentQty){toast('الكمية الإضافية تتجاوز الحد المسموح.','error');return;}if(type==='REDUCE'&&qty>currentQty){toast('عدد الإلغاءات أكبر من الاشتراكات النشطة المتاحة.','error');return;}}if(type==='REDUCE'&&qty===currentQty&&!await confirmAction({title:'إيقاف الاشتراك بالكامل',message:'سيؤدي ذلك إلى إنهاء الاشتراكات النشطة في هذه الخدمة بعد الموافقة.',danger:true,confirmLabel:'إرسال الطلب'}))return;if(!towerCheckResidentServiceOrigin(origin))return;beginBackgroundSave();try{await run('requestServiceChange',id,type,qty);await towerRefreshResidentServices(origin);toast('تم إرسال الطلب للمراجعة.');}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
async function cancelMyService(id){const origin=towerResidentServiceOrigin();if(!await confirmAction({title:'إلغاء الطلب',message:'إلغاء طلب الاشتراك قبل الموافقة؟',danger:true,confirmLabel:'إلغاء الطلب'}))return;if(!towerCheckResidentServiceOrigin(origin))return;try{await run('cancelMyServiceSubscription',id);await towerRefreshResidentServices(origin);toast('تم إلغاء الطلب.');}catch(e){toast(errText(e),'error');}}
function serviceActiveCount(id){return SERVICE_UI.subscriptions.filter(s=>s.serviceId===id&&s.status==='ACTIVE').length;}
function servicePendingOrder(rows){return (Array.isArray(rows)?rows:[]).filter(x=>x&&x.status==='PENDING').sort((a,b)=>(Date.parse(b.requestedAt||b.createdAt||'')||0)-(Date.parse(a.requestedAt||a.createdAt||'')||0));}
function serviceRequestUnitText(q){return `الوحدة ${unitNo(q.unitNumber||'—')}${q.floor?' · الدور '+floorNo(q.floor):''}`;}
function serviceRequestUnitHtml(q){const unit=unitNo(q.unitNumber||'—');return `الوحدة <strong class="service-request-emphasis">${esc(unit)}</strong>${q.floor?' · الدور '+esc(floorNo(q.floor)):''}`;}
function serviceRequestAmountHtml(q){const qty=Math.max(1,Number(q.quantity)||1);return `<strong class="service-request-emphasis">${esc(String(qty))}</strong>`;}
function serviceRequestCostStatus(s){return s?.pricingMode==='SHARED_TOTAL'&&s?.enrollmentStatus!=='FINALIZED'?'النصيب التقديري قابل للتغيير حتى اعتماد التوزيع':null;}
function serviceRequestAmountText(q){const qty=Math.max(1,Number(q.quantity)||1),total=Number(q.amountSnapshot);const unit=Number(q.unitPriceSnapshot);const price=Number.isFinite(unit)&&unit>=0?unit:(Number.isFinite(total)?total/qty:NaN);return `الكمية: ${qty} × ${Number.isFinite(price)?money(price):'—'} = ${Number.isFinite(total)?money(total):'—'}`;}


function serviceAdminMetricCard(label,value,helper,tone=''){
 return `<article class="service-admin-stat ${tone?`is-${tone}`:''}"><strong>${esc(value)}</strong><span>${esc(label)}</span>${helper?`<small>${esc(helper)}</small>`:''}</article>`;
}
function serviceAdminQuickSummary(pending,changes){
 const services=Array.isArray(SERVICE_UI.services)?SERVICE_UI.services:[];
 const recurring=services.filter(s=>!towerIsTask(s)).length;
 const tasks=services.filter(s=>towerIsTask(s)).length;
 const active=services.filter(s=>s.status==='ACTIVE').length;
 return `<section class="panel service-admin-overview"><div class="service-admin-overview-head"><div><span class="dashboard-eyebrow">إدارة الاشتراكات والمهمات</span><h3>تعريف الخدمات</h3><p>تنظيم الخدمات الدورية والمهمات، مع متابعة الطلبات والاشتراكات من شاشة أوضح وأسهل.</p></div></div><div class="service-admin-metrics">${serviceAdminMetricCard('إجمالي الخدمات',String(services.length),`${recurring} دورية · ${tasks} مهمات`)}${serviceAdminMetricCard('الخدمات النشطة',String(active),services.length?`${services.length-active} متوقفة`:'لا توجد خدمات',active>0?'success':'')}${serviceAdminMetricCard('طلبات الاشتراك',String(pending.length),pending.length?'تحتاج مراجعة':'لا توجد طلبات',pending.length?'attention':'')}${serviceAdminMetricCard('طلبات التعديل',String(changes.length),changes.length?'بانتظار قرار':'لا توجد طلبات',changes.length?'attention':'')}</div></section>`;
}
const TOWER_ADMIN_EXPANDED_TASKS=new Set();
function towerAdminCardOpen(event,card){
 if(event.target.closest('button,a,input,select,textarea,summary'))return;
 const id=card.dataset.serviceId;
 if(card.dataset.kind==='tasks')openAdminTaskDetails(id);else openServiceDetails(id);
}
function towerTaskDetailsSummary(s,subscriptions,meta){
 const budget=Math.max(0,Number(s.totalBudget)||0),posted=Math.max(0,Number(meta?.fundContributionPosted)||0);
 const proposed=Math.max(0,Number(meta?.fundContributionProposed)||0);
 const finalized=s.enrollmentStatus==='FINALIZED';
 const fund=finalized?posted:proposed;
 const net=Math.max(0,Math.round(budget*100)-Math.round(fund*100))/100;
 const units=new Set((subscriptions||[]).filter(r=>r.status==='ACTIVE').map(r=>String(r.unitId||r.unit_id||r.subscriptionId)));
 const count=units.size||serviceActiveCount(s.serviceId);
 const estimate=count?Math.ceil(net/count):0;
 const fact=(label,value,note='')=>`<div class="tower-task-detail-fact"><span>${esc(label)}</span><strong>${esc(value)}</strong>${note?`<small>${esc(note)}</small>`:''}</div>`;
 const fundLabel=finalized?'مساهمة الصندوق المسجلة':'مساهمة الصندوق المقترحة';
 return `<section class="tower-task-details-summary" aria-label="ملخص المهمة"><div class="tower-task-summary-finance">${fact('تكلفة المهمة',money(budget))}${fact(fundLabel,money(fund),finalized?'':'خصم تقديري لا يُنشئ قيدًا')}${fact(finalized?'الصافي المعتمد على الوحدات':'صافي التكلفة التقديري',money(net))}${fact(finalized?'متوسط نصيب الوحدة المعتمد':'متوسط نصيب الوحدة التقديري',count?money(estimate):'—',finalized?'':'قيمة معروضة بالتقريب، وقابلة للتغيير')}</div><div class="tower-task-summary-enrollment">${fact('الوحدات المشتركة',String(count))}${fact('باب الاشتراك',serviceUiEnrollment(s))}</div></section>`;
}
function openAdminTaskDetails(id){
 const target=(SERVICE_UI.services||[]).find(x=>String(x.serviceId)===String(id));if(target&&target.pricingMode!=='SHARED_TOTAL')return openServiceWorkspace(id);if(target?.pricingMode==='SHARED_TOTAL')return openTaskProject(id);
 const s=(SERVICE_UI.services||[]).find(x=>String(x.serviceId)===String(id));if(!s)return;
 if(s.project?.phase==='PROPOSAL'||['CANCELLED','FINANCIAL_CLOSED'].includes(s.project?.phase))return openTaskProject(id);
 const subscriptions=(SERVICE_UI.subscriptions||[]).filter(x=>x.serviceId===id);
 const meta=TASK_WORKFLOW_META[id]||null;
 const isManager=['ADMIN','UNION'].includes(APP.ctx?.user?.role);
 const actions=isManager?`<div class="tower-task-context-actions"><button type="button" class="btn-sm service-action-secondary" onclick="openServiceAdminEditById('${esc(id)}')" aria-label="تعديل المهمة">✎ تعديل المهمة</button></div>`:'';
 const allocationAction=isManager?`<button type="button" class="btn-sm primary tower-task-main-action" onclick="openSharedAllocation('${esc(id)}')">الاشتراك والتوزيع</button>`:'';
 const progressAction=isManager?`<button type="button" class="btn-sm service-action-secondary" onclick="editTaskWorkflow('${esc(id)}')">إدارة تقدم المهمة</button>`:'';
 openModal(`<div class="modal-head"><div><h3>${esc(s.name)}</h3><p>تفاصيل المهمة · ${esc(TASK_STAGE_NAMES[meta?.stage]||serviceUiEnrollment(s))}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><div class="tower-task-modal-body">${towerTaskDetailsSummary(s,subscriptions,meta)}${s.pricingMode==='SHARED_TOTAL'?`<button type="button" class="btn-sm primary" onclick="openTaskProject('${esc(id)}')">إدارة المهمة</button>`:''}${actions}${towerTaskStageHtml(s)}<div class="tower-task-stage-controls">${progressAction}</div>${allocationAction}</div>`,true);
}
function towerAdminCardKeyboard(event,card){if(event.target!==card)return;if(event.key==='Enter'||event.key===' '){event.preventDefault();towerAdminCardOpen(event,card);}}
function openServiceAdminEditById(id){const s=(SERVICE_UI.services||[]).find(x=>String(x.serviceId)===String(id));if(!s){toast('الخدمة غير متاحة؛ حدّث الصفحة.','error');return;}openServiceModal(s);}
function serviceAdminServiceCard(s,isManager){
 const id=esc(s.serviceId),isTask=towerIsTask(s),expanded=false;
 const activeSubs=serviceActiveCount(s.serviceId),meta=TASK_WORKFLOW_META[s.serviceId]||null;
 const chips=[serviceUiType(s),serviceUiRevenue(s),serviceTimingLabel(s.billingTiming),`${activeSubs} مشترك`].filter(Boolean).map(v=>`<span class="service-admin-chip">${esc(v)}</span>`).join('');
 const amountText=s.pricingMode==='SHARED_TOTAL'?money(s.totalBudget)+' إجمالي':money(s.price)+' للوحدة';
 const stage=meta?.stage?TASK_STAGE_NAMES[meta.stage]:(s.enrollmentStatus==='OPEN'?'تجميع المشتركين':s.enrollmentStatus==='CLOSED'?'بانتظار اعتماد التوزيع':'لم تبدأ');
 const taskContent=isTask?'':'';
 return `<article class="data-card service-admin-card service-card-clickable ${isTask?'service-admin-task-card':''} ${expanded?'is-expanded':''}" data-kind="${isTask?'tasks':'recurring'}" data-service-id="${id}" role="button" tabindex="0" ${isTask?`aria-expanded="${expanded}"`:''} aria-label="${isTask?'إظهار تفاصيل المهمة':'عرض تفاصيل الخدمة'}: ${esc(s.name)}" onclick="towerAdminCardOpen(event,this)" onkeydown="towerAdminCardKeyboard(event,this)">
 <div class="service-admin-card-top"><div class="service-admin-card-title"><div class="service-admin-title-row"><strong>${esc(s.name)}</strong><span class="badge ${s.status==='ACTIVE'?'success':'muted'}">${s.status==='ACTIVE'?'نشطة':'موقوفة'}</span></div><div class="service-admin-chip-row">${chips}</div>${isTask?`<span class="service-admin-task-stage">${esc(stage)}</span>`:''}</div><div class="service-admin-amount"><span>${s.pricingMode==='SHARED_TOTAL'?'تكلفة المهمة':'سعر الاشتراك'}</span><strong>${amountText}</strong>${isTask?`<small class="service-admin-expand-indicator">اضغط لعرض التفاصيل</small>`:''}</div></div>${taskContent}</article>`;
}

function openServiceAdminEdit(button){
 const id=button?.dataset?.serviceId;
 const service=(SERVICE_UI.services||[]).find(item=>String(item.serviceId)===String(id));
 if(!service){toast('تعذر العثور على الخدمة. حدّث الصفحة وحاول مرة أخرى.','error');return;}
 openServiceModal(service);
}
function serviceAdminPendingCard(q){
 const shared=(SERVICE_UI.services||[]).find(s=>s.serviceId===q.serviceId)?.pricingMode==='SHARED_TOTAL';
 return `<article class="data-card service-request-card service-pending-card"><div class="service-request-card-head"><div><strong>${esc(q.serviceName)}</strong><span>${esc(displayDateTime12(q.requestedAt))}</span>${q.requestedByName?`<span>طالب الخدمة: ${esc(q.requestedByName)}</span>`:''}</div><span class="badge attention">معلّق</span></div><div class="service-pending-facts"><div><span>الوحدة</span><strong>${esc(unitNo(q.unitNumber||'—'))}</strong></div><div><span>الدور</span><strong>${esc(floorNo(q.floor||q.unitFloor||'—'))}</strong></div><div><span>مدير الوحدة</span><strong>${esc(q.managerName||q.unitManagerName||'غير متاح')}</strong></div><div><span>الكمية</span>${serviceRequestAmountHtml(q)}</div></div><div class="service-pending-price">${shared?'<span>مهمة بتكلفة إجمالية — نصيب الوحدة يُحدد بعد إغلاق الاشتراك واعتماد التوزيع</span>':`<span>سعر الوحدة <strong>${money(Number(q.unitPriceSnapshot)||0)}</strong></span><span>الإجمالي <strong>${money(q.amountSnapshot)}</strong></span>`}</div><div class="compact-actions"><button class="btn-sm primary" onclick="reviewSub('${esc(q.subscriptionId)}','APPROVE',this)">موافقة</button><button class="btn-sm danger-soft" onclick="reviewSub('${esc(q.subscriptionId)}','REJECT',this)">رفض</button></div></article>`;
}
function serviceAdminChangeCard(q){
 return `<article class="data-card service-request-card"><div class="service-request-card-head"><div><strong>${esc(q.serviceName)}</strong><span>${esc(serviceRequestUnitText(q))}</span></div><span class="badge">${q.type==='ADD'?'زيادة':'تقليل'} ${Math.abs(q.quantityDelta)}</span></div><div class="service-change-summary"><div><span>الكمية المطلوبة</span><strong>${esc(String(q.requestedQuantity))}</strong></div></div><div class="compact-actions"><button class="btn-sm primary" onclick="reviewServiceChange('${esc(q.requestId)}','APPROVE')">موافقة</button><button class="btn-sm danger-soft" onclick="reviewServiceChange('${esc(q.requestId)}','REJECT')">رفض</button></div></article>`;
}

async function renderManageServices(changes){const isManager=['ADMIN','UNION'].includes(APP.ctx.user.role),pending=servicePendingOrder(SERVICE_UI.subscriptions);changes=servicePendingOrder(changes||SERVICE_UI.changes||[]);$('content').innerHTML=`${serviceAdminQuickSummary(pending,changes)}<section class="panel service-admin-main-panel"><div class="panel-head service-admin-main-head"><div><h3>الخدمات الحالية</h3><p>اختر نوع الخدمة، ثم افتح البطاقة المناسبة لإدارة التفاصيل أو المشتركين أو التوزيع.</p></div>${isManager?'<div class="compact-actions"><button class="btn-sm" onclick="generateServiceDues()">تحديث</button><button class="btn-sm primary" onclick="openTaskIdeaForm()">＋ مهمة</button><button class="btn-sm" onclick="openServiceModal()">+ خدمة</button></div>':''}</div>${towerServiceTabs(SERVICE_UI.services,pending)}${SERVICE_UI.services.length?`<div class="list-stack service-admin-list">${SERVICE_UI.services.map(s=>`<div data-tower-service-kind="${towerIsTask(s)?'tasks':'recurring'}" ${TOWER_SERVICE_TAB===(towerIsTask(s)?'tasks':'recurring')?'':'hidden'}>${serviceAdminServiceCard(s,isManager)}</div>`).join('')}</div>`:''}<div id="tower-service-empty" class="state-card empty-state service-admin-empty" ${SERVICE_UI.services.some(s=>(towerIsTask(s)?'tasks':'recurring')===TOWER_SERVICE_TAB)?'hidden':''}><strong>${TOWER_SERVICE_TAB==='tasks'?'لا توجد مهمات في هذا التبويب.':'لا توجد خدمات دورية في هذا التبويب.'}</strong><span>يمكنك إضافة خدمة جديدة أو تغيير التبويب.</span></div></section><section class="panel service-admin-request-panel"><div class="panel-head"><div><h3>طلبات الاشتراك</h3><p>يمكن للإدارة أو الاتحاد الموافقة أو الرفض.</p></div><span class="badge">${pending.length}</span></div>${pending.length?`<div class="list-stack service-request-list">${pending.map(q=>serviceAdminPendingCard(q)).join('')}</div>`:`<div class="state-card empty-state service-admin-empty compact"><strong>لا توجد طلبات معلقة</strong><span>ستظهر هنا الاشتراكات الجديدة التي تحتاج قرارًا.</span></div>`}</section><section class="panel service-admin-request-panel"><div class="panel-head"><div><h3>طلبات تعديل الاشتراك</h3><p>زيادة أو تقليل عدد الاشتراكات.</p></div><span class="badge">${changes.length}</span></div>${changes.length?`<div class="list-stack service-request-list">${changes.map(q=>serviceAdminChangeCard(q)).join('')}</div>`:`<div class="state-card empty-state service-admin-empty compact"><strong>لا توجد طلبات تعديل معلقة</strong><span>ستظهر هنا طلبات الزيادة أو التقليل عند ورودها.</span></div>`}</section>`;}
async function openServiceModal(s={}){
 // Details RPC does not carry financial classification; use the authoritative service list.
 if(s.serviceId){await openManagedServiceEdit(s.serviceId);return;}
 if(s.serviceId){const classified=SERVICE_UI.services.find(x=>x.serviceId===s.serviceId);if(classified)s={...s,revenueKind:classified.revenueKind,beneficiaryUserId:classified.beneficiaryUserId,financeAccountId:classified.financeAccountId};}
 let people=[];
 try{people=await run('listServiceBeneficiaries');}catch(e){toast('تعذر تحميل قائمة المستفيدين: '+errText(e),'error');return;}
 const personal=s.revenueKind==='PERSONAL_SERVICE';
 const options=(Array.isArray(people)?people:[]).sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'ar')).map(x=>`<button type="button" class="service-beneficiary-item ${s.beneficiaryUserId===x.userId?'is-selected':''}" data-beneficiary-id="${esc(x.userId)}" data-search-name="${esc(x.name||'')}" onmousedown="event.preventDefault()" onclick="chooseServiceBeneficiary(this)" role="option" aria-selected="${s.beneficiaryUserId===x.userId?'true':'false'}">${esc(personName(x))} <span class="service-beneficiary-role">${esc(({ADMIN:'إدارة النظام',UNION:'رئيس الاتحاد',RESIDENT:'ساكن',OPERATOR:'حارس'})[x.role]||x.role||'')}</span></button>`).join('');
 openModal(`<div class="modal-head"><div><h3>${s.serviceId?'تعديل الخدمة':'إضافة خدمة'}</h3><p>حدّد نوع الخدمة وتسعيرها وجهة إيرادها.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid service-editor-form" onsubmit="submitService(event,'${esc(s.serviceId||'')}')"><label class="field"><span>اسم الخدمة</span><input id="srvName" value="${esc(s.name||'')}" required></label><label class="field" id="srvPriceField" style="${s.pricingMode==='SHARED_TOTAL'?'display:none':''}"><span>سعر الاشتراك (جنيه)</span><input id="srvPrice" type="number" min="0" step="0.01" value="${Number(s.price||0)}" ${s.pricingMode==='SHARED_TOTAL'?'':'required'}></label><label class="field"><span>نوع الخدمة</span><select id="srvServiceKind" onchange="updateServicePricingEditor()"><option value="RECURRING" ${s.serviceKind!=='ONE_TIME'?'selected':''}>دورية</option><option value="ONE_TIME" ${s.serviceKind==='ONE_TIME'?'selected':''}>مهمة محددة</option></select></label><label class="field"><span>طريقة التسعير</span><select id="srvPricingMode" onchange="updateServicePricingEditor()"><option value="PER_SUBSCRIPTION" ${s.pricingMode!=='SHARED_TOTAL'?'selected':''}>سعر لكل اشتراك</option><option value="SHARED_TOTAL" ${s.pricingMode==='SHARED_TOTAL'?'selected':''}>إجمالي موزع بالتساوي</option></select></label><label class="field span-2" id="srvTotalBudgetField" style="${s.pricingMode==='SHARED_TOTAL'?'':'display:none'}"><span>إجمالي تكلفة المهمة (جنيه)</span><input id="srvTotalBudget" type="number" min="0.01" step="0.01" value="${s.totalBudget==null?'':Number(s.totalBudget)}" ${s.pricingMode==='SHARED_TOTAL'?'required':''}></label><p class="span-2 service-budget-explainer" id="srvBudgetExplainer" style="${s.pricingMode==='SHARED_TOTAL'?'':'display:none'}">ده إجمالي تكلفة المهمة لكل المشتركين، مش سعر الفرد. مش هيتحدد نصيب أي وحدة ولا ينشأ استحقاق من مجرد حفظ المهمة؛ التوزيع بيتم بعد إغلاق باب الاشتراك ومعاينته واعتماده.</p><label class="field"><span>توقيت السداد</span><select id="srvTiming"><option value="PREPAID" ${s.billingTiming!=='POSTPAID'?'selected':''}>مقدم</option><option value="POSTPAID" ${s.billingTiming==='POSTPAID'?'selected':''}>مؤخر</option></select></label><label class="field"><span>السماح بكمية</span><select id="srvQty"><option value="0" ${!s.allowQuantity?'selected':''}>لا</option><option value="1" ${s.allowQuantity?'selected':''}>نعم</option></select></label><label class="field"><span>قابلة للإلغاء</span><select id="srvCancelable"><option value="1" ${s.cancelable!==false?'selected':''}>نعم</option><option value="0" ${s.cancelable===false?'selected':''}>لا</option></select></label><label class="field span-2"><span>جهة إيراد الخدمة</span><div class="service-revenue-choices" role="radiogroup" aria-label="جهة إيراد الخدمة"><label class="service-revenue-option"><input type="radio" name="srvRevenueChoice" value="FUND" ${!personal?'checked':''} onchange="setServiceRevenueKind('FUND')"><span>▣ صندوق العمارة</span></label><label class="service-revenue-option"><input type="radio" name="srvRevenueChoice" value="PERSONAL_SERVICE" ${personal?'checked':''} onchange="setServiceRevenueKind('PERSONAL_SERVICE')"><span>♙ حساب شخصي</span></label></div><input type="hidden" id="srvRevenueKind" value="${personal?'PERSONAL_SERVICE':'FUND'}"></label><label class="field span-2" id="srvBeneficiaryField" style="${personal?'':'display:none'}"><span>المستفيد من إيراد الخدمة</span><div class="service-beneficiary-picker"><span class="service-beneficiary-input-wrap"><input id="srvBeneficiarySearch" type="search" autocomplete="off" placeholder="ابحث واختر المستفيد..." oninput="onServiceBeneficiaryInput()" onfocus="showServiceBeneficiaryResults()" onblur="hideServiceBeneficiaryResultsSoon()" onkeydown="onServiceBeneficiaryKeydown(event)" aria-label="بحث واختيار المستفيد" aria-controls="srvBeneficiaryResults" aria-expanded="false" aria-autocomplete="list" role="combobox"><button type="button" class="service-beneficiary-clear" onclick="clearServiceBeneficiary()" aria-label="مسح المستفيد والبحث" title="اختيار مستفيد آخر">×</button></span><input type="hidden" id="srvBeneficiary" value="${esc(s.beneficiaryUserId||'')}"><div id="srvBeneficiaryResults" class="service-beneficiary-results hidden" role="listbox" aria-label="نتائج البحث عن المستفيد">${options}</div></div><div id="srvBeneficiarySelected" class="service-beneficiary-selected" aria-live="polite">${s.beneficiaryUserId?'المستفيد الحالي محدد ✓':'لم يتم اختيار مستفيد'}</div><small id="srvBeneficiaryCount" class="muted">اكتب جزءًا من الاسم، أو استخدم الأسهم وEnter للاختيار</small></label><label class="field span-2"><span>الوصف</span><textarea id="srvDesc">${esc(s.description||'')}</textarea></label><p class="span-2" style="font-size:.8rem;opacity:.75">تغيير جهة الإيراد أو المستفيد لخدمة عليها اشتراكات أو حساب مالي قائم يتطلب إجراءات انتقال محاسبي منفصلة.</p><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);
 const preselected=$('srvBeneficiaryResults')?.querySelector('.service-beneficiary-item.is-selected');
 if(preselected&&$('srvBeneficiarySearch'))$('srvBeneficiarySearch').value=(preselected.firstChild?.textContent||preselected.textContent).trim().replace(/\s+/g,' ');
}
function filterServiceBeneficiaries(query){
 const list=$('srvBeneficiaryResults'),counter=$('srvBeneficiaryCount');if(!list)return;
 const needle=normAr(query);let matches=0;
 list.querySelectorAll('.service-beneficiary-item').forEach(item=>{const ok=searchablePickerTermsMatches(item.dataset.searchName||'',needle);item.hidden=!ok;item.classList.remove('is-keyboard-active');if(ok)matches++;});
 if(counter)counter.textContent=matches?`${matches} مستفيد مطابق · اختر اسمًا من القائمة`:'لا يوجد مستفيد مطابق — جرّب جزءًا آخر من الاسم';
}
function showServiceBeneficiaryResults(){
 const list=$('srvBeneficiaryResults'),search=$('srvBeneficiarySearch');if(!list||!search)return;
 filterServiceBeneficiaries(search.value);list.classList.remove('hidden');search.setAttribute('aria-expanded','true');
}
function hideServiceBeneficiaryResults(){
 const list=$('srvBeneficiaryResults'),search=$('srvBeneficiarySearch');if(list)list.classList.add('hidden');if(search)search.setAttribute('aria-expanded','false');
}
function hideServiceBeneficiaryResultsSoon(){setTimeout(hideServiceBeneficiaryResults,150);}
function onServiceBeneficiaryInput(){
 const search=$('srvBeneficiarySearch'),chosen=$('srvBeneficiary');if(!search||!chosen)return;
 chosen.value='';const status=$('srvBeneficiarySelected');if(status)status.textContent='اختر مستفيدًا من النتائج';
 $('srvBeneficiaryResults')?.querySelectorAll('.service-beneficiary-item').forEach(el=>{el.classList.remove('is-selected');el.setAttribute('aria-selected','false');});
 showServiceBeneficiaryResults();
}
function onServiceBeneficiaryKeydown(event){
 const list=$('srvBeneficiaryResults');if(!list)return;
 if(event.key==='Escape'){hideServiceBeneficiaryResults();event.currentTarget.blur();return;}
 if(event.key==='ArrowDown'||event.key==='ArrowUp'){
  event.preventDefault();if(list.classList.contains('hidden'))showServiceBeneficiaryResults();
  searchablePickerMove(list,'.service-beneficiary-item',event.key==='ArrowDown'?1:-1);return;
 }
 if(event.key==='Enter'&&!list.classList.contains('hidden')){
  const first=searchablePickerFirst(list,'.service-beneficiary-item');
  event.preventDefault();if(first)chooseServiceBeneficiary(first);return;
 }
 if(event.key==='Tab')hideServiceBeneficiaryResults();
}

function clearServiceBeneficiary(){
 const input=$('srvBeneficiary'),search=$('srvBeneficiarySearch');if(input)input.value='';if(!search)return;
 search.value='';const current=$('srvBeneficiarySelected');if(current)current.textContent='لم يتم اختيار مستفيد';
 search.focus();showServiceBeneficiaryResults();
}
function chooseServiceBeneficiary(button){
 const id=button?.dataset?.beneficiaryId||'',input=$('srvBeneficiary'),list=$('srvBeneficiaryResults');if(!input||!list)return;
 input.value=id;
 list.querySelectorAll('.service-beneficiary-item').forEach(el=>{const chosen=el===button;el.classList.toggle('is-selected',chosen);el.setAttribute('aria-selected',chosen?'true':'false');});
 const name=(button.firstChild?.textContent||button.textContent).trim().replace(/\s+/g,' '),search=$('srvBeneficiarySearch');if(search)search.value=name;
 const current=$('srvBeneficiarySelected');if(current)current.textContent='✓ المستفيد: '+name;
 hideServiceBeneficiaryResults();if(search)search.blur();
}
function updateServicePricingEditor(){const one=$('srvServiceKind')?.value==='ONE_TIME';if(!one&&$('srvPricingMode')?.value==='SHARED_TOTAL')$('srvPricingMode').value='PER_SUBSCRIPTION';const shared=one&&$('srvPricingMode')?.value==='SHARED_TOTAL';const price=$('srvPrice'),budget=$('srvTotalBudget');if($('srvPriceField'))$('srvPriceField').style.display=shared?'none':'';if(price)price.required=!shared;if($('srvTotalBudgetField'))$('srvTotalBudgetField').style.display=shared?'':'none';if(budget)budget.required=shared;if($('srvBudgetExplainer'))$('srvBudgetExplainer').style.display=shared?'':'none';}
function setServiceRevenueKind(kind){const field=$('srvRevenueKind');if(field)field.value=kind;toggleServiceBeneficiaryField();}
function toggleServiceBeneficiaryField(){const field=$('srvBeneficiaryField'),personal=$('srvRevenueKind')?.value==='PERSONAL_SERVICE';if(field)field.style.display=personal?'':'none';}
async function submitService(e,id){e.preventDefault();const kind=$('srvRevenueKind').value,beneficiaryId=$('srvBeneficiary').value;
 if($('srvPricingMode').value==='SHARED_TOTAL'&&($('srvServiceKind').value!=='ONE_TIME'||!(Number($('srvTotalBudget').value)>0))){toast('التكلفة الإجمالية تتطلب مهمة محددة ومبلغًا أكبر من صفر.','error');return;}
 if(kind==='PERSONAL_SERVICE'&&!beneficiaryId){toast('اختر المستفيد من إيراد الخدمة.','error');return;}
 const existing=id?SERVICE_UI.services.find(x=>x.serviceId===id):null;
 if(existing){
  const original=existing.revenueKind==='PERSONAL_SERVICE'?'PERSONAL_SERVICE':'FUND';
  const changing=kind!==original;
  const changingOwner=kind==='PERSONAL_SERVICE'&&original==='PERSONAL_SERVICE'&&beneficiaryId!==existing.beneficiaryUserId;
  const hasHistory=SERVICE_UI.subscriptions.some(x=>x.serviceId===id);
  if(changing&&hasHistory){toast('التعديل لم يُحفظ: اختر «صندوق العمارة» للخدمة القديمة وعدّل بياناتها كالمعتاد. تحويلها لحساب شخصي مع اشتراكات قائمة يحتاج انتقالًا محاسبيًا منفصلًا.','error');return;}
  if(changingOwner){toast('تغيير المستفيد لحساب شخصي قائم يتطلب إجراء انتقال مالي منفصل. يمكنك تعديل بيانات الخدمة دون تغيير المستفيد.','error');return;}
 }
 const submit=e.submitter;if(submit)submit.disabled=true;
 try{await run('saveService',{serviceId:id,name:$('srvName').value,price:$('srvPricingMode').value==='SHARED_TOTAL'?'0':$('srvPrice').value,billingTiming:$('srvTiming').value,billingCycle:'MONTHLY',autoRenewDefault:true,allowQuantity:$('srvQty').value==='1',cancelable:$('srvCancelable').value==='1',description:$('srvDesc').value,revenueKind:kind,beneficiaryUserId:kind==='PERSONAL_SERVICE'?beneficiaryId:null,serviceKind:$('srvServiceKind').value,pricingMode:$('srvPricingMode').value,totalBudget:$('srvPricingMode').value==='SHARED_TOTAL'?$('srvTotalBudget').value:null});closeModal();await renderServices();toast('تم حفظ الخدمة.');}catch(x){toast(errText(x),'error');}finally{if(submit&&submit.isConnected)submit.disabled=false;}
}
// Subscribers are rendered from one normalized, read-only snapshot for both screen and print.
// A presentation-only estimate for open shared tasks. The PostgreSQL RPC remains
// authoritative for dues; cents and sorting mirror SQL200 (unit_id order).
function serviceSharedDisplay(s,subscriptions){
 const shared=s?.pricingMode==='SHARED_TOTAL',finalized=s?.enrollmentStatus==='FINALIZED';
 const members=(subscriptions||[]).filter(x=>x.status==='ACTIVE');
 if(shared&&s?.project?.distribution==='CUSTOM'){
  const agreed=new Map((s.project.agreedAmounts||[]).map(x=>[String(x.subscriptionId),Number(x.amount)]));
  return {shared,finalized,safe:false,amount:Number(s.totalBudget),memberCount:members.length,perUnit:agreed,custom:true,label:'أنصبة متفق عليها لكل وحدة',note:finalized?'هذه الأنصبة تخص التوزيع الأصلي. التسويات والمدفوع والمتبقي تُراجع من متابعة المهمة ودفتر الوحدة.':'مبالغ الاتفاق المقترحة لكل وحدة، ولا تُنشأ مستحقات قبل اعتماد التوزيع.'};
 }
 const amount=Number(s?.totalBudget),safe=shared&&Number.isFinite(amount)&&amount>0&&members.length>0;
 const cents=safe?Math.round(taskEstimatedNetBudget(s)*100):0,base=safe?Math.floor(cents/members.length):0,remainder=safe?cents%members.length:0;
 const byId=[...members].sort((a,b)=>String(a.unitId||'').localeCompare(String(b.unitId||'')));
 const bySubscription=new Map(byId.map((x,i)=>[String(x.subscriptionId||x.unitId),((base+(i<remainder?1:0))/100)]));
 return {shared,finalized,safe,amount,memberCount:members.length,perUnit:bySubscription,
  label:finalized?'حساب توضيحي — راجع المستحقات المعتمدة':'النصيب التقديري الحالي',
  note:finalized?'الأنصبة المحسوبة للعرض ليست كشف حساب؛ التسويات والمدفوع والمتبقي تُراجع من متابعة المهمة ودفتر المستحقات.':
  'تقدير مؤقت يتغير عند إضافة أو حذف مشترك. لا تُنشأ مستحقات قبل إغلاق الاشتراك واعتماد التوزيع.'};
}
function serviceSubscriptionDisplay(s,x,estimate){
 if(s?.pricingMode!=='SHARED_TOTAL')return money(Number(x.amountSnapshot)||0);
 const v=estimate?.perUnit.get(String(x.subscriptionId||x.unitId));
 return v==null?'لا يمكن احتساب النصيب حاليًا':money(v)+(estimate.custom?' — اتفاق التوزيع الأصلي':estimate.finalized?' — نصيب محسوب':' — تقديري');
}
function serviceSubscriberSnapshot(data){
 const active=(data.subscriptions||[]).filter(x=>x.status==='ACTIVE');
 const sorted=[...active].sort((a,b)=>String(a.unitNumber||'').localeCompare(String(b.unitNumber||''),'en',{numeric:true}));
 const total=sorted.reduce((sum,x)=>{const n=Number(x.amountSnapshot);return sum+(Number.isFinite(n)?n:0)},0);
 const unitCount=new Set(sorted.map(x=>String(x.unitId||x.unitNumber||''))).size;
 return {service:data.service,subscriptions:sorted,total,unitCount,quantityTotal:sorted.reduce((sum,x)=>sum+Math.max(1,Number(x.quantity)||1),0),estimate:serviceSharedDisplay(data.service,sorted)};
}
function serviceSubscriberRowsHtml(d){
 return d.subscriptions.map(x=>`<div class="member-line service-subscriber-row"><div><strong>الوحدة ${esc(unitNo(x.unitNumber||'—'))}</strong><span>الدور ${esc(floorNo(x.floor||'—'))} · ${esc(x.managerName||'—')}</span></div><div class="service-subscriber-amount"><strong>${esc(serviceSubscriptionDisplay(d.service,x,d.estimate))}</strong><span>الكمية <strong>${esc(String(Math.max(1,Number(x.quantity)||1)))}</strong></span></div></div>`).join('');
}
let SERVICE_SUBSCRIBER_PRINT=null;
let SERVICE_SUBSCRIBER_MODE='summary';
function setServiceSubscribersReportMode(mode){
 if(!['summary','detailed'].includes(mode))return;
 SERVICE_SUBSCRIBER_MODE=mode;
 const region=$('serviceSubscriberReportMode');
 if(region)region.querySelectorAll('button').forEach(b=>{const active=b.dataset.mode===mode;b.classList.toggle('primary',active);b.setAttribute('aria-pressed',String(active));});
 const list=$('serviceSubscriberDetailRows');if(list)list.hidden=mode==='summary';
 const hint=$('serviceSubscriberModeNote');if(hint)hint.textContent=mode==='summary'?'الملخص يعرض التكلفة وعدد المشتركين، ويمكن عرض الأنصبة لكل وحدة من تفاصيل الوحدات.':'عرض تفصيلي للوحدات والقيم مع توضيح ما إذا كانت تقديرية.';
}
function serviceSubscribersReport(d){
 if(!d||!d.service||!Array.isArray(d.subscriptions))throw Error('SERVICE_SUBSCRIBERS_UNAVAILABLE');
 const shared=d.estimate.shared;
 const finalized=d.estimate.finalized;
 const estimateOk=d.estimate.safe;
 const sumProposed=shared?Math.max(0,Math.min(Number(d.service.totalBudget)||0,Number(TASK_WORKFLOW_META?.[d.service.serviceId]?.fundContributionProposed||0))):0;
 const sumPosted=shared?Math.max(0,Math.min(Number(d.service.totalBudget)||0,Number(TASK_WORKFLOW_META?.[d.service.serviceId]?.fundContributionPosted||0))):0;
 const net=shared?Math.max(0,(Number(d.service.totalBudget)||0)-(finalized?sumPosted:sumProposed)):0;
 const note=shared?(finalized?'المهمة معتمدة: هذا التقرير يعرض المشتركين فقط. المستحقات النهائية والسداد الفعلي يُرجع فيهما إلى دفتر مستحقات الوحدات.':`المساهمة المقترحة (${money(sumProposed)}) تستخدم للتقدير فقط، ولا تعتبر مصروف صندوق أو سدادًا أو مستحقًا معتمدًا.`):'قيمة الاشتراكات لا تعني مبالغ تم تحصيلها بالفعل.';
 const stats=shared?[{label:'تكلفة المهمة الإجمالية',value:serviceUiAmount(d.service)},{label:'مساهمة الصندوق المقترحة',value:money(sumProposed)},{label:'مساهمة الصندوق المسجلة',value:money(sumPosted)},{label:finalized?'الصافي بعد المساهمة المسجلة — للعرض فقط':'الصافي التقديري على الوحدات',value:money(net),emphasis:true},{label:'الوحدات المشتركة',value:String(d.unitCount)},{label:'إجمالي الكميات',value:String(d.quantityTotal)},{label:finalized?'متوسط تقديري، غير معتمد':'متوسط النصيب التقديري',value:estimateOk?money(net/d.estimate.memberCount):'غير متاح'}]:[{label:'الوحدات المشتركة',value:String(d.unitCount)},{label:'إجمالي الكميات',value:String(d.quantityTotal)},{label:'قيمة الاشتراكات (غير محصلة بالضرورة)',value:money(d.total),emphasis:true}];
 return {system:'Tower App',version:APP_VERSION,reportClass:'service-subscribers-paper',building:{name:APP.ctx?.building?.name||'Tower App'},
 title:'تقرير مشتركي الخدمة — '+String(d.service.name||'الخدمة'),subtitle:'الاشتراكات النشطة · '+serviceUiSubtitle(d.service)+' · '+serviceUiEnrollment(d.service),
 generatedAt:displayDateTime12(new Date()),generatedBy:APP.ctx?.user?.displayName||APP.ctx?.user?.name||'إدارة الخدمات',
 footer:'تقرير مشتركين، وليس كشف مستحقات أو إثبات تحصيل.',
 sections:[{type:'stats',items:stats},{type:'note',text:note},
 {type:'table',title:'تفاصيل الوحدات المشتركة ('+d.subscriptions.length+')',columns:[{label:'الوحدة'},{label:'الدور'},{label:'مدير الوحدة'},{label:'الكمية'},{label:shared?(finalized?'نصيب تقديري غير معتمد':'النصيب التقديري'):'قيمة الاشتراك'}],
 rows:d.subscriptions.map(x=>['الوحدة '+unitNo(x.unitNumber||'—'),floorNo(x.floor||'—'),x.managerName||'—',String(Math.max(1,Number(x.quantity)||1)),serviceSubscriptionDisplay(d.service,x,d.estimate)])}]};
}
function printServiceSubscribers(){
 const d=SERVICE_SUBSCRIBER_PRINT;if(!d){toast('افتح قائمة المشتركين أولًا.','error');return;}
 const r=serviceSubscribersReport(d),w=window.open('','_blank');if(!w){toast('اسمح بفتح نافذة الطباعة.','error');return;}
 w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc(r.title)}</title><style>${reportStandaloneCss()}</style></head><body>${reportDocumentHtml(r)}<script>window.onload=()=>setTimeout(()=>window.print(),300)<\/script></body></html>`);w.document.close();
}
async function downloadServiceSubscribersPdf(){
 try{if(!SERVICE_SUBSCRIBER_PRINT)throw Error('افتح قائمة المشتركين أولًا.');const d=SERVICE_SUBSCRIBER_PRINT,blob=await buildCurrentPdfBlob(serviceSubscribersReport(d));await downloadBlobSafe(blob,'Tower_Service_Subscribers_'+cairoDateStamp()+'.pdf');toast('تم تجهيز PDF.');}catch(e){toast(errText(e),'error');}
}
async function copyServiceSubscribers(){
 try{const d=SERVICE_SUBSCRIBER_PRINT;if(!d)throw Error('افتح قائمة المشتركين أولًا.');const lines=[d.service.name,'الوحدات المشتركة: '+d.unitCount,'إجمالي الكميات: '+d.quantityTotal,'نوع الخدمة: '+serviceUiType(d.service),'جهة الإيراد: '+serviceUiRevenue(d.service),d.estimate.shared?'تكلفة المهمة الإجمالية: '+serviceUiAmount(d.service):'قيمة الاشتراكات الحالية: '+money(d.total),d.estimate.shared?(d.estimate.finalized?'نصيب الوحدة التوضيحي: ':'نصيب الوحدة التقديري: ')+(d.estimate.safe?money(taskEstimatedNetBudget(d.service)/d.estimate.memberCount):'لم يُحسب بعد'):'قيمة الاشتراكات ليست بالضرورة محصلة.',d.estimate.shared?d.estimate.note:'',...(SERVICE_SUBSCRIBER_MODE==='detailed'?d.subscriptions:[]).map(x=>'الوحدة '+unitNo(x.unitNumber||'—')+' | الدور '+floorNo(x.floor||'—')+' | '+(x.managerName||'—')+' | الكمية '+Math.max(1,Number(x.quantity)||1)+' | '+serviceSubscriptionDisplay(d.service,x,d.estimate))];await copyTextValue(lines.join('\n'),'تم نسخ تفاصيل المشتركين.');}catch(e){toast(errText(e),'error');}
}
// Shared service presentation contract: one source for service detail, reports and subscriber views.
function serviceUiType(s){return s?.serviceKind==='ONE_TIME'?'مهمة لمرة واحدة':s?.pricingMode==='SHARED_TOTAL'?'مهمة بتكلفة مشتركة':'خدمة دورية';}
function serviceUiRevenue(s){return s?.revenueKind==='PERSONAL_SERVICE'?'حساب شخصي':'صندوق العمارة';}
function serviceUiPricing(s){if(s?.project?.distribution==='CUSTOM')return 'مبلغ متفق عليه لكل وحدة';return s?.pricingMode==='SHARED_TOTAL'?'إجمالي موزع بالتساوي':'سعر لكل اشتراك';}
function serviceUiEnrollment(s){return s?.pricingMode!=='SHARED_TOTAL'?'لا ينطبق':s.enrollmentStatus==='FINALIZED'?'تم اعتماد التوزيع':s.enrollmentStatus==='CLOSED'?'الاشتراك مغلق — بانتظار الاعتماد':'الاشتراك مفتوح';}
function serviceUiAmount(s){return s?.pricingMode==='SHARED_TOTAL'?money(Number(s.totalBudget)||0):money(Number(s.price)||0);}
function serviceUiAmountLabel(s){return s?.pricingMode==='SHARED_TOTAL'?'التكلفة الإجمالية':'سعر الاشتراك';}
function serviceUiSubtitle(s){return [serviceUiType(s),serviceUiRevenue(s),serviceUiPricing(s)].join(' · ');}
function serviceUiIdentity(s){return [serviceUiType(s),serviceUiRevenue(s),serviceUiPricing(s),s?.status==='ACTIVE'?'نشطة':'موقوفة'].map((x,i)=>`<span class="service-identity-chip ${i===1?'service-revenue-chip':''}">${esc(x)}</span>`).join('');}
// Shared-cost headline is presentation-only. Final accounting remains server-authoritative.
// Context-aware service summary: compact in lists; full once in details.
// Never create a formal due from a browser estimate. All visible money uses money() (no decimals).
function taskProposedContribution(s){
 const v=Number(TASK_WORKFLOW_META[s?.serviceId]?.fundContributionProposed||0);
 const total=Number(s?.totalBudget||0);
 return s?.enrollmentStatus==='FINALIZED'?Math.max(0,Number(TASK_WORKFLOW_META[s?.serviceId]?.fundContributionPosted||0)):Math.max(0,Math.min(total,Number.isFinite(v)?v:0));
}
function taskEstimatedNetBudget(s){return Math.max(0,Number(s?.totalBudget||0)-taskProposedContribution(s));}
function serviceUiSharedHeadline(s,records,knownCount,layout='full'){
 if(s?.pricingMode!=='SHARED_TOTAL')return '';
 const active=Array.isArray(records)?records.filter(x=>x.status==='ACTIVE'):[];
 const count=Array.isArray(records)?new Set(active.map(x=>String(x.unitId||x.subscriptionId))).size:
   Number.isInteger(knownCount)&&knownCount>=0?knownCount:null;
 const budget=Number(s.totalBudget),ready=count>0&&Number.isFinite(budget)&&budget>0;
 const finalized=s.enrollmentStatus==='FINALIZED';
 const share=s.project?.ownEstimatedShare!=null?taskExactMoney(s.project.ownEstimatedShare):s.project?.distribution==='CUSTOM'?'حسب اتفاق كل وحدة':ready?money(taskEstimatedNetBudget(s)/count):'لم يُحسب بعد';
 const shareText=finalized?'راجع المستحق المعتمد':share;
 const label=finalized?'الأنصبة المعتمدة في دفتر المستحقات':s.project?.distribution==='CUSTOM'?'النصيب حسب الاتفاق':'نصيب الوحدة التقديري';
 const contribution=taskProposedContribution(s);
 const fundingLabel=finalized?'مساهمة الصندوق المسجلة':'مساهمة الصندوق المقترحة (تقديريًا)';
 if(layout==='compact')return `<div class="service-summary-compact"><span>${esc(label)}: <strong>${esc(shareText)}</strong></span><span>${count==null?'عدد المشتركين غير متاح':count+' وحدة'}</span><span>${esc(serviceUiEnrollment(s))}</span>${!finalized&&contribution>0?`<span>المساهمة المقترحة: ${money(contribution)} · الصافي التقديري: ${money(taskEstimatedNetBudget(s))}</span>`:''}</div>`;
 return `<div class="service-core-financial" role="group" aria-label="ملخص المهمة المالي"><div><span>تكلفة المهمة</span><strong>${money(budget)}</strong></div><div><span>${esc(label)}</span><strong>${esc(shareText)}</strong><small>${finalized?'القيمة الرسمية من دفتر المستحقات':ready?'تقديري، قابل للتغيير':count===0?'لا يوجد مشتركون':'العدد غير متاح'}</small></div><div><span>الوحدات المشتركة</span><strong>${count==null?'—':count}</strong></div><div><span>باب الاشتراك</span><strong>${esc(serviceUiEnrollment(s))}</strong></div><div><span>${esc(fundingLabel)}</span><strong>${money(contribution)}</strong><small>${finalized?'قيد فعلي فقط':'للتقدير فقط، لا يؤثر على الصندوق أو المستحقات'}</small></div><div><span>صافي التكلفة ${finalized?'بعد المساهمة المسجلة':'التقديري'}</span><strong>${money(taskEstimatedNetBudget(s))}</strong></div></div>`;
}
function serviceUiFact(label,value){return `<div><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`;}
function serviceUiSubscriberAmount(s,sub){return serviceRequestCostStatus(s)||money(Number(sub.amountSnapshot)||0);}
// Do not turn incomplete backend metadata into a recurring service or zero-cost report.
async function towerReadServiceManagerContext(id){
 const data=await run('getServiceManagerContext',id),s=data?.service;
 const classified=s&&String(s.serviceId)===String(id)&&
  ['RECURRING','ONE_TIME'].includes(s.serviceKind)&&
  ['PER_SUBSCRIPTION','SHARED_TOTAL'].includes(s.pricingMode)&&
  ['FUND','PERSONAL_SERVICE'].includes(s.revenueKind);
 const sharedValid=s?.pricingMode!=='SHARED_TOTAL'||(
  ['OPEN','CLOSED','FINALIZED'].includes(s.enrollmentStatus)&&
  s.totalBudget!=null&&Number.isFinite(Number(s.totalBudget))&&Number(s.totalBudget)>0);
 if(!classified||!sharedValid||!Array.isArray(data?.subscriptions)||!Array.isArray(data?.units)){
  throw Error('بيانات الخدمة اللي رجعت من النظام ناقصة. حدّث نسخة الـWorker وحاول تاني؛ مش هنعتبر الاشتراك مقفول أو نعرض تقرير بمبالغ غير صحيحة.');
 }
 return data;
}
async function openServiceSubscribers(id){
 return openServiceWorkspaceOrTask(id,'members',true);
}
async function openServiceDetails(id){
 return openServiceWorkspaceOrTask(id);
}
async function openAddServiceSubscribers(id){
 try{
  const d=await towerReadServiceManagerContext(id);
  if(d.service.pricingMode==='SHARED_TOTAL'&&d.service.enrollmentStatus!=='OPEN'){toast('باب الاشتراك مقفول؛ مش متاح إضافة مشتركين دلوقتي.','error');return;}
  const active=new Set(d.subscriptions.filter(x=>['ACTIVE','PENDING'].includes(x.status)).map(x=>x.unitId));
  window.SERVICE_PICK={...d,active,selected:new Set()};
  openModal(`<div class="modal-head"><div><h3>إضافة مشتركين</h3><p>${esc(d.service.name)} · ${esc(serviceUiSubtitle(d.service))}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div>
   <div class="unit-selector-toolbar service-unit-toolbar"><label class="service-unit-search-label" for="serviceUnitSearch">البحث عن وحدة أو ساكن</label>
   <input id="serviceUnitSearch" type="search" autocomplete="off" placeholder="رقم الوحدة، الدور، المدير أو أي عضو" oninput="renderServiceUnitPicker()" aria-controls="serviceUnitPicker" aria-describedby="servicePickerCount">
   <button class="icon-action" type="button" onclick="serviceSelectAll(true)" title="تحديد كل الوحدات الظاهرة غير المشتركة">✓<span>تحديد الظاهر</span></button>
   <button class="icon-action" type="button" onclick="serviceSelectAll(false)" title="إلغاء التحديد">×<span>إلغاء التحديد</span></button></div>
   <div id="servicePickerCount" class="selection-count" aria-live="polite"></div><div id="serviceUnitPicker" class="service-unit-picker" role="group" aria-label="الوحدات المتاحة"></div>${d.service.pricingMode==='SHARED_TOTAL'?taskDirectAgreementFields():''}
   <div class="form-actions"><button class="btn-sm primary" id="serviceAddSelectedButton" type="button" onclick="submitServiceSubscribers('${esc(id)}')">إضافة المشتركين</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div>`,true);
  renderServiceUnitPicker();
 }catch(e){toast(errText(e),'error');}
}
function serviceVisibleUnits(){
 const d=window.SERVICE_PICK;if(!d)return [];
 const q=$('serviceUnitSearch')?.value||'';
 return (d.units||[]).filter(u=>searchablePickerTermsMatches([u.unitNumber,u.floor,u.managerName,...(u.memberNames||[])].join(' '),q));
}
function renderServiceUnitPicker(){
 const d=window.SERVICE_PICK,box=$('serviceUnitPicker');if(!d||!box)return;
 const rows=serviceVisibleUnits(),available=(d.units||[]).filter(u=>!d.active.has(u.unitId));
 box.innerHTML=rows.length?rows.map(u=>{
  const locked=d.active.has(u.unitId),checked=d.selected.has(u.unitId);
  return `<label class="service-unit-row ${locked?'is-disabled':''} ${checked?'is-selected':''}"><input type="checkbox" ${checked?'checked':''} ${locked?'disabled':''} onchange="serviceToggleUnit('${esc(u.unitId)}',this.checked)" aria-label="إضافة وحدة ${esc(unitNo(u.unitNumber))}">
   <span><strong>وحدة ${esc(unitNo(u.unitNumber))}</strong><small>الدور ${esc(floorNo(u.floor||'—'))}</small></span>
   <span class="service-unit-manager"><small>مدير الوحدة</small><strong>${esc(u.managerName||'المدير غير متاح')}</strong></span>
   ${locked?'<span class="badge success">مشترك بالفعل</span>':checked?'<span class="badge">محدد</span>':''}</label>`;
 }).join(''):'<div class="service-unit-empty" role="status">لا توجد وحدات مطابقة. جرّب البحث بجزء من الاسم أو رقم الوحدة.</div>';
 const count=$('servicePickerCount');if(count)count.textContent=`${searchablePickerCountLabel(rows.length,(d.units||[]).length)} · المتاح: ${available.length} · المحدد: ${d.selected.size}`;
 const submit=$('serviceAddSelectedButton');if(submit){submit.disabled=d.selected.size===0;submit.textContent=d.selected.size?`إضافة ${d.selected.size} وحدة`:'اختر وحدة للإضافة';}
}
function serviceToggleUnit(id,on){const d=window.SERVICE_PICK;if(!d||d.active.has(id))return;if(on)d.selected.add(id);else d.selected.delete(id);renderServiceUnitPicker();}
function serviceSelectAll(on){const d=window.SERVICE_PICK;if(!d)return;
 if(on)serviceVisibleUnits().forEach(u=>{if(!d.active.has(u.unitId))d.selected.add(u.unitId)});
 else serviceVisibleUnits().forEach(u=>d.selected.delete(u.unitId));
 renderServiceUnitPicker();
}
async function submitServiceSubscribers(id){
 const d=window.SERVICE_PICK,ids=d?Array.from(d.selected):[];
 if(!ids.length){toast('اختر وحدة واحدة على الأقل.','error');return;}
 const btn=$('serviceAddSelectedButton');if(btn?.disabled)return;
 const agreement=taskDirectAgreementPayload(d);if(btn)btn.disabled=true;beginBackgroundSave();
 try{const r=await run('addServiceSubscribers',{serviceId:id,unitIds:ids,...agreement});closeModal();toast(`تمت إضافة ${r.created} وحدة${r.skipped?'، وتجاوز '+r.skipped+' وحدة قائمة.':''}`);await renderServices();await refreshOpenServiceWorkspace(id);}
 catch(e){toast(errText(e),'error');}
 finally{endBackgroundSave();if(btn?.isConnected)btn.disabled=false;}
}

async function generateServiceDues(){try{const r=await run('generateServiceDues');await renderServices();toast(r.created?'تم إنشاء '+r.created+' استحقاق خدمة.':'لا توجد استحقاقات جديدة.');}catch(e){toast(errText(e),'error');}}
async function toggleService(id,status){try{await run('setServiceStatus',id,status);await renderServices();await refreshOpenServiceWorkspace(id);}catch(e){toast(errText(e),'error');}}
async function reviewServiceChange(id,decision){const notes=await promptAction({title:decision==='APPROVE'?'موافقة على تعديل الاشتراك':'رفض تعديل الاشتراك',message:'الملاحظة اختيارية.',label:'ملاحظة',confirmLabel:decision==='APPROVE'?'موافقة':'رفض'});if(notes===null)return;try{await run('reviewServiceChangeRequest',id,decision,notes);await renderServices();await refreshOpenServiceWorkspace();toast(decision==='APPROVE'?'تمت الموافقة.':'تم الرفض.');}catch(e){toast(errText(e),'error');}}
async function reviewSub(id,decision,button){if(button?.disabled)return;let notes='';if(decision!=='APPROVE'){notes=await promptAction({title:'رفض الاشتراك',message:'الملاحظة اختيارية.',label:'سبب الرفض',confirmLabel:'رفض'});if(notes===null)return;}if(button){button.disabled=true;button.setAttribute('aria-busy','true');}try{await run('reviewServiceSubscription',id,decision,notes);await renderServices();await refreshOpenServiceWorkspace();if($('modalSheet')?.querySelector('.task-workspace'))await openTaskProject(taskProjectCurrentHub().serviceId,true,'members');toast(decision==='APPROVE'?'تمت الموافقة.':'تم الرفض.');}catch(e){toast(errText(e),'error');}finally{if(button?.isConnected){button.disabled=false;button.removeAttribute('aria-busy');}}}



const FIN_UI={tab:'overview',data:null,categories:[]};
function finUnitLabel(u){return u?`شقة ${esc(unitNo(u.unitNumber||'—'))} · دور ${esc(floorNo(u.floor||'—'))} · ${esc(u.managerName||'المدير غير متاح')}`:'—';}
function finTabs(){return `<div class="finance-tabs">${[['overview','الرئيسية'],['charges','التحصيلات'],['payments','الدفعات'],['arrears','المتأخرات'],['fund','الصندوق'],['personal','الخدمات الشخصية'],['audit','المراجعة']].map(x=>`<button type="button" class="finance-tab ${FIN_UI.tab===x[0]?'active':''}" data-finance-tab="${x[0]}" aria-current="${FIN_UI.tab===x[0]?'page':'false'}" aria-selected="${FIN_UI.tab===x[0]?'true':'false'}" onclick="setFinanceTab('${x[0]}')">${x[1]}</button>`).join('')}</div>`;}
function syncFinanceTabSelection(){
 const tabs=document.querySelector('.finance-tabs');
 if(!tabs)return;
 tabs.querySelectorAll('.finance-tab').forEach(btn=>{
  const selected=btn.dataset.financeTab===FIN_UI.tab;
  btn.classList.toggle('active',selected);
  btn.setAttribute('aria-current',selected?'page':'false');
  btn.setAttribute('aria-selected',selected?'true':'false');
  btn.tabIndex=selected?0:-1;
 });
}
async function setFinanceTab(t){
 const supported=['overview','charges','payments','arrears','fund','personal','audit'];
 if(!supported.includes(t))return;
 FIN_UI.tab=t;
 syncFinanceTabSelection();
 renderFinanceBody();
}
async function renderFinance(){const c=$('content');c.innerHTML=pageLoading('جاري تحميل مالية العمارة…');try{const results=await Promise.allSettled([run('getFinanceContext'),run('listCollectionCategories',true)]);if(results[0].status!=='fulfilled')throw results[0].reason;FIN_UI.data=results[0].value;FIN_UI.categories=results[1].status==='fulfilled'?results[1].value:[];c.innerHTML=finTabs()+`<div id="financeBody"></div>`;syncFinanceTabSelection();renderFinanceBody();}catch(e){c.innerHTML=errorCard(e);}}
async function refreshFinanceSilent(tab){FIN_UI.data=await run('getFinanceContext');if(tab)FIN_UI.tab=tab;const c=$('content');if(!$('financeBody'))c.innerHTML=finTabs()+`<div id="financeBody"></div>`;syncFinanceTabSelection();renderFinanceBody();}
// V2.4.61: Reusable accessible record filters; searches only currently loaded records.
function financeListTools(placeholder='بحث في السجلات'){
 return `<div class="filter-toolbar finance-list-tools"><label class="sr-only" for="financeRecordSearch">${esc(placeholder)}</label><input id="financeRecordSearch" type="search" autocomplete="off" placeholder="${esc(placeholder)}" oninput="filterFinanceRecords()" aria-controls="financeRecordList"><button class="btn-sm" id="financeRecordReset" type="button" disabled onclick="clearFinanceRecordSearch()">مسح البحث</button></div><p class="selection-count" id="financeRecordCount" role="status" aria-live="polite"></p>`;
}
function filterFinanceRecords(){
 const input=document.getElementById('financeRecordSearch'),list=document.getElementById('financeRecordList');if(!input||!list)return;
 const query=normAr(input.value.trim()),tokens=query.split(/\s+/).filter(Boolean);const rows=[...list.querySelectorAll('[data-finance-record]')];let visible=0;
 rows.forEach(row=>{const show=uiSearchMatch(row.textContent||'',input.value);row.hidden=!show;if(show)visible++;});
 const count=document.getElementById('financeRecordCount');if(count)count.textContent=query?`${visible} نتيجة من ${rows.length}`:`${rows.length} سجل`;
 const empty=document.getElementById('financeNoMatches');if(empty)empty.hidden=visible!==0;const reset=document.getElementById('financeRecordReset');if(reset)reset.disabled=!input.value.trim();
}
function clearFinanceRecordSearch(){const input=document.getElementById('financeRecordSearch');if(!input)return;input.value='';filterFinanceRecords();input.focus();}
function finishFinanceRecordList(){filterFinanceRecords();}
async function loadPersonalRefundApprovalPanel(){
 const host=document.getElementById('personalRefundApprovalPanel');if(!host)return;
 try{
  const data=await run('listPersonalRefundApprovals');
  if(!Array.isArray(data?.subscriptions))throw Error('INVALID_APPROVAL_LIST');
  const items=data.subscriptions.filter(x=>!x.hasApproval);
  host.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>اعتماد استرداد خدمة شخصية</h3><p>لرئيس الاتحاد فقط. لا تعتمد مبلغًا قبل مراجعة الحساب وتاريخ الإلغاء.</p></div></div>${items.length?`<label for="refundApprovalSubscription">الاشتراك المنتهي</label><select id="refundApprovalSubscription">${items.map(x=>`<option value="${esc(x.subscriptionId)}">${esc(x.serviceName||'خدمة')} — ${esc(x.unitId)} — ${esc(x.endedAt||'')}</option>`).join('')}</select><label for="refundApprovalDate">تاريخ سريان الإلغاء</label><input id="refundApprovalDate" type="date"><label for="refundApprovalAmount">مبلغ الاسترداد الأقصى (جنيه)</label><input id="refundApprovalAmount" inputmode="decimal" type="number" min="0.01" step="0.01"><button class="btn-sm primary" type="button" onclick="submitPersonalRefundApproval()">اعتماد بعد المراجعة</button><p id="refundApprovalMessage" role="status" aria-live="polite"></p>`:'<p>لا توجد اشتراكات منتهية تحتاج موافقة جديدة.</p>'}</section>`;
 }catch(e){host.innerHTML='<p class="selection-count">اعتمادات الاسترداد غير مفعّلة في هذه البيئة. لا يمكن صرف أي مبلغ من هنا.</p>';}
}
async function submitPersonalRefundApproval(){
 const subscriptionId=document.getElementById('refundApprovalSubscription')?.value;
 const effectiveDate=document.getElementById('refundApprovalDate')?.value;
 const amount=document.getElementById('refundApprovalAmount')?.value;
 const out=document.getElementById('refundApprovalMessage');if(!out)return;
 if(!subscriptionId||!effectiveDate||!/^\d+(\.\d{1,2})?$/.test(String(amount||''))||Number(amount)<=0){out.textContent='راجع الاشتراك والتاريخ والمبلغ أولًا.';return;}
 if(!confirm('اعتماد سقف استرداد لهذه الوحدة والخدمة؟ لن يتم تسليم مال بدون طلب مستقل وتأكيد الاستلام.'))return;
 out.textContent='جارٍ إرسال الاعتماد…';
 try{await run('approvePersonalUnitRefund',{subscriptionId,effectiveDate,amount});out.textContent='تم تسجيل الموافقة. لم يتم صرف أي مبلغ.';await loadPersonalRefundApprovalPanel();}
 catch(e){out.textContent='تعذر اعتماد الاسترداد: '+String(e?.message||e||'خطأ');}
}
// Stage-only personal collection UI. No fund entries are posted through this form.
// Keep an idempotency key for an ambiguous network failure. A changed draft always
// gets a different key; retrying exactly the same draft reuses its original key.
let PERSONAL_RECEIPT_PENDING=null;
function personalReceiptRows(){return [...document.querySelectorAll('.personal-receipt-portion')].map(row=>({
 account_id:row.querySelector('select')?.value||'',amount:(row.querySelector('input')?.value||'').trim()
}));}
function personalReceiptAddPortion(){
 const holder=document.getElementById('personalReceiptPortions');if(!holder)return;
 const first=holder.querySelector('.personal-receipt-portion');if(!first||holder.children.length>=100)return;
 const row=first.cloneNode(true);row.querySelector('input').value='';row.querySelector('select').selectedIndex=0;
 holder.append(row);PERSONAL_RECEIPT_PENDING=null;
}
function personalReceiptRemovePortion(button){
 const holder=document.getElementById('personalReceiptPortions');if(!holder||holder.children.length<=1)return;
 button.closest('.personal-receipt-portion')?.remove();PERSONAL_RECEIPT_PENDING=null;
}
async function submitPersonalReceiptStage(){
 const msg=document.getElementById('personalReceiptMessage');if(!msg)return;
 const unitId=document.getElementById('personalReceiptUnit')?.value||'';
 const portions=personalReceiptRows();
 const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 const toCents=v=>{if(!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(v))return null;
  const parts=v.split('.');const cents=Number(parts[0])*100+Number((parts[1]||'').padEnd(2,'0'));
  return Number.isSafeInteger(cents)&&cents>0?cents:null;};
 const ids=new Set();let total=0;
 if(!uuid.test(unitId)||!portions.length||portions.length>100){msg.textContent='اختر وحدة وحساب خدمة صحيحين.';return;}
 for(const part of portions){const c=toCents(part.amount),key=part.account_id.toLowerCase();
  if(!uuid.test(part.account_id)||c===null||ids.has(key)){msg.textContent='راجع حسابات الخدمات والمبالغ؛ ممنوع تكرار الحساب أو إدخال مبلغ غير صحيح.';return;}
  ids.add(key);total+=c;
  if(!Number.isSafeInteger(total)){msg.textContent='إجمالي المبلغ غير صالح.';return;}
 }
 const amount=(Math.floor(total/100))+'.'+String(total%100).padStart(2,'0');
 const signature=JSON.stringify({unitId,amount,portions});
 if(!await confirmAction({title:'تحصيل خدمات شخصية تجريبي',message:'الإجمالي '+amount+' جنيه موزع على '+portions.length+' حساب خدمات شخصية فقط، ولن يدخل صندوق العمارة. هل تؤكد؟',confirmLabel:'تأكيد التحصيل'}))return;
 if(!PERSONAL_RECEIPT_PENDING||PERSONAL_RECEIPT_PENDING.signature!==signature){
  const reference='personal-ui-'+(globalThis.crypto?.randomUUID?.()||String(Date.now())+'-'+Math.random().toString(36).slice(2));
  PERSONAL_RECEIPT_PENDING={signature,reference};
 }
 const button=document.getElementById('personalReceiptSubmit');if(button)button.disabled=true;
 msg.textContent='جارٍ تسجيل التحصيل…';
 try{
  const result=await run('postPersonalServiceReceipt',{unitId,amount,portions,externalReference:PERSONAL_RECEIPT_PENDING.reference});
  PERSONAL_RECEIPT_PENDING=null;
  msg.textContent=`تم تسجيل الإيصال ${result?.receiptId||''} في حسابات الخدمات الشخصية فقط.`;
  await refreshFinanceSilent('personal');
 }catch(e){msg.textContent='تعذر تأكيد تسجيل التحصيل: '+errText(e)+' — أعد المحاولة بدون تعديل البيانات لإعادة استخدام نفس مرجع الإيصال.';}
 finally{if(button)button.disabled=false;}
}
function personalReceiptStageForm(accounts,units){
 const validAccounts=accounts.filter(x=>/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(x.accountId||'')&&x.status==='ACTIVE');
 const validUnits=(units||[]).filter(x=>/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(x.unitId||''));
 if(!validAccounts.length||!validUnits.length)return '<p>لا توجد وحدات أو حسابات خدمات شخصية نشطة للتحصيل التجريبي.</p>';
 const options=validAccounts.map(x=>`<option value="${esc(x.accountId)}">${esc(x.serviceName||'خدمة')} — ${esc(x.beneficiaryName||'المستفيد')}</option>`).join('');
 return `<section class="panel"><div class="panel-head"><div><h3>تحصيل خدمات شخصية — بيئة تجريبية فقط</h3><p>يمكن توزيع المبلغ على حسابات خدمات شخصية متعددة. صندوق العمارة منفصل.</p></div></div>
 <label for="personalReceiptUnit">الوحدة</label><select id="personalReceiptUnit">${validUnits.map(x=>`<option value="${esc(x.unitId)}">${finUnitLabel(x)}</option>`).join('')}</select>
 <div id="personalReceiptPortions"><div class="personal-receipt-portion"><label>حساب الخدمة <select>${options}</select></label><label>المبلغ بالجنيه <input type="number" inputmode="decimal" min="0.01" step="0.01" placeholder="0.00"></label><button class="btn-sm" type="button" onclick="personalReceiptRemovePortion(this)">حذف الحساب</button></div></div>
 <div class="compact-actions"><button class="btn-sm" type="button" onclick="personalReceiptAddPortion()">+ حساب خدمة آخر</button>
 <button id="personalReceiptSubmit" class="btn-sm primary" type="button" onclick="submitPersonalReceiptStage()">تسجيل التحصيل الشخصي</button></div>
 <p id="personalReceiptMessage" role="status" aria-live="polite"></p></section>`;
}
// Mixed cash collection is a single database RPC; never split it into two calls.
// Preserve the reference when retrying an unchanged request after network uncertainty.
let MIXED_COLLECTION_PENDING=null;
let MIXED_COLLECTION_SUBMITTING=false;
function mixedCollectionStageForm(accounts,units){
 const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 const ac=accounts.filter(x=>uuid.test(x.accountId||'')&&x.status==='ACTIVE');
 let saved=null;try{if(MIXED_COLLECTION_PENDING)saved=JSON.parse(MIXED_COLLECTION_PENDING.signature);}catch(_){saved=null;}
 const savedUnit=saved?.fund?.lines?.[0]?.unitId||'';
 const savedAccount=saved?.personal?.portions?.[0]?.account_id||'';
 const savedFund=saved?.fund?.lines?.[0]?.amount||'';
 const savedPersonal=saved?.personal?.amount||'';
 const us=(units||[]).filter(x=>uuid.test(x.unitId||''));
 if(!ac.length||!us.length)return '<p class="selection-count">التحصيل المختلط متاح بعد تهيئة حساب خدمة شخصية نشط.</p>';
 return `<section class="panel mixed-collection-panel" aria-labelledby="mixedCollectionTitle">
  <div class="panel-head"><div><h3 id="mixedCollectionTitle">تحصيل الصندوق والخدمة الشخصية</h3><p>عملية واحدة مشتركة تسجل المبلغين معًا، أو تلغيهما معًا عند الفشل. متاحة في البيئة التجريبية فقط.</p></div><span class="mixed-collection-stage">تجريبي</span></div>
  <div class="mixed-collection-form" role="group" aria-label="بيانات التحصيل المشترك">
    <div class="mixed-collection-unit"><label class="mixed-field" for="mixedUnit"><span>الوحدة</span><select id="mixedUnit">${us.map(x=>`<option value="${esc(x.unitId)}" ${x.unitId===savedUnit?'selected':''}>${finUnitLabel(x)}</option>`).join('')}</select></label></div>
    <div class="mixed-collection-grid">
      <div class="mixed-collection-part"><div class="mixed-collection-part-head"><span class="mixed-collection-part-icon" aria-hidden="true">▣</span><div><h4>صندوق العمارة</h4><p>مبلغ المستحق للصندوق</p></div></div><label class="mixed-field" for="mixedFundAmount"><span>المبلغ (جنيه)</span><input id="mixedFundAmount" value="${esc(savedFund)}" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0.00" dir="ltr"></label></div>
      <div class="mixed-collection-part"><div class="mixed-collection-part-head"><span class="mixed-collection-part-icon" aria-hidden="true">▤</span><div><h4>الخدمة الشخصية</h4><p>مبلغ مستقل عن الصندوق</p></div></div><label class="mixed-field" for="mixedPersonalAccount"><span>حساب الخدمة</span><select id="mixedPersonalAccount">${ac.map(x=>`<option value="${esc(x.accountId)}" ${x.accountId===savedAccount?'selected':''}>${esc(x.serviceName||'خدمة')} — ${esc(x.beneficiaryName||'مستفيد')}</option>`).join('')}</select></label><label class="mixed-field" for="mixedPersonalAmount"><span>المبلغ (جنيه)</span><input id="mixedPersonalAmount" value="${esc(savedPersonal)}" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0.00" dir="ltr"></label></div>
    </div>
    ${saved?'<p role="status" class="mixed-collection-warning">يوجد تحصيل سابق لم تتأكد نتيجته. أعد المحاولة بنفس الوحدة والمبالغ للتحقق منه، ولا تنشئ تحصيلًا آخر.</p>':''}
    <div class="mixed-collection-footer"><p>تأكد من الوحدة والمبلغين قبل التسجيل. لا يتم التحصيل في حسابين بعمليتين منفصلتين.</p><button id="mixedSubmit" type="button" class="btn-sm primary" onclick="submitMixedCollectionStage()">✓ تأكيد التحصيل</button></div>
    <p id="mixedMessage" role="status" aria-live="polite"></p>
  </div>
 </section>`;
}
async function submitMixedCollectionStage(){
 const out=document.getElementById('mixedMessage');if(!out||MIXED_COLLECTION_SUBMITTING||out.dataset.completed==='true')return;
 const formEpoch=PERSONAL_FINANCE_RENDER_EPOCH;
 const isLiveForm=()=>formEpoch===PERSONAL_FINANCE_RENDER_EPOCH&&FIN_UI.tab==='personal'&&out===document.getElementById('mixedMessage')&&document.getElementById('mixedSubmit')!==null;
 const unitId=document.getElementById('mixedUnit')?.value||'';
 const accountId=document.getElementById('mixedPersonalAccount')?.value||'';
 const fundAmount=(document.getElementById('mixedFundAmount')?.value||'').trim();
 const personalAmount=(document.getElementById('mixedPersonalAmount')?.value||'').trim();
 const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 const validMoney=x=>/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(x)&&Number(x)>0&&Number.isSafeInteger(Math.round(Number(x)*100));
 if(!uuid.test(unitId)||!uuid.test(accountId)||!validMoney(fundAmount)||!validMoney(personalAmount)){
  out.textContent='راجع الوحدة والحساب والمبلغين قبل التأكيد.';return;
 }
 const payload={fund:{lines:[{unitId,amount:fundAmount}]},personal:{unitId,amount:personalAmount,portions:[{account_id:accountId,amount:personalAmount}]}};
 const signature=JSON.stringify(payload);
 if(MIXED_COLLECTION_PENDING&&MIXED_COLLECTION_PENDING.signature!==signature){
  out.textContent='في تحصيل سابق نتيجته غير مؤكدة. أعد نفس الوحدة والمبالغ للتحقق من المعاملة أولًا؛ لا يمكن إرسال طلب مختلف قبل حسم الطلب السابق.';return;
 }
 if(!await confirmAction({title:'تحصيل مالي مشترك تجريبي',message:'الصندوق: '+fundAmount+' جنيه، والخدمة الشخصية: '+personalAmount+' جنيه. سيتم ترحيل الطرفين معًا أو إلغاؤهما معًا. تأكد من استلام المبلغ بالفعل.',confirmLabel:'تأكيد التحصيل'}))return;
 if(!isLiveForm())return;
 if(!MIXED_COLLECTION_PENDING||MIXED_COLLECTION_PENDING.signature!==signature)
  MIXED_COLLECTION_PENDING={signature,reference:'mixed-ui-'+(globalThis.crypto?.randomUUID?.()||String(Date.now())+'-'+Math.random().toString(36).slice(2))};
 MIXED_COLLECTION_SUBMITTING=true;const btn=document.getElementById('mixedSubmit');if(btn)btn.disabled=true;
 out.textContent='جارٍ تنفيذ المعاملة المشتركة…';
 try{
  const result=await run('createAndApproveMixedCollection',{externalReference:MIXED_COLLECTION_PENDING.reference,...payload});
  MIXED_COLLECTION_PENDING=null;
  if(isLiveForm()){out.dataset.completed='true';out.textContent=result?.replayed?'تم العثور على نفس المعاملة المسجّلة سابقًا، بدون تحصيل مكرر.':'تم تسجيل تحصيل الصندوق والخدمة في معاملة واحدة.';}
 }catch(e){if(isLiveForm())out.textContent='تعذر التحقق من التحصيل: '+errText(e)+' — لإعادة المحاولة بنفس المرجع، لا تعدّل المبالغ أو الوحدة.';}
 finally{MIXED_COLLECTION_SUBMITTING=false;if(btn&&isLiveForm()&&out.dataset.completed!=='true')btn.disabled=false;}
}
// Staging-only request: recipient is derived from the selected personal-service account.
// Never allow the browser to nominate an arbitrary beneficiary via this form.
async function submitPersonalBeneficiaryHandover(){
 const select=document.getElementById('personalHandoverAccount');
 const amount=(document.getElementById('personalHandoverAmount')?.value||'').trim();
 const out=document.getElementById('personalHandoverMessage');if(!out||!select)return;
 const accountId=select.value,recipientId=select.selectedOptions?.[0]?.dataset?.recipientId||'';
 const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 if(!uuid.test(accountId)||!uuid.test(recipientId)||!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(amount)||Number(amount)<=0){out.textContent='راجع الحساب والمبلغ والمستفيد.';return;}
 if(!await confirmAction({title:'طلب تسليم عهدة شخصية',message:'طلب تسليم '+amount+' جنيه إلى المستفيد المحدد للحساب. المبلغ لن يدخل صندوق العمارة، ولن يعتبر مسلّمًا قبل تأكيد المستلم.',confirmLabel:'إرسال الطلب'}))return;
 const button=document.getElementById('personalHandoverSubmit');if(button)button.disabled=true;
 out.textContent='جارٍ إرسال طلب التسليم…';
 try{const r=await run('requestPersonalCashHandover',{accountId,recipientId,amount,kind:'BENEFICIARY_DELIVERY'});
  out.textContent='تم إنشاء طلب عهدة معلّق: '+String(r?.movementId||'')+' — لم يتم تأكيد الاستلام.';
  await refreshMyPendingHandovers();
 }catch(e){out.textContent='تعذر إنشاء الطلب: '+errText(e);}
 finally{if(button)button.disabled=false;}
}
function personalHandoverStageForm(accounts){
 const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 const usable=accounts.filter(x=>x.status==='ACTIVE'&&uuid.test(x.accountId||'')&&uuid.test(x.beneficiaryUserId||''));
 if(!usable.length)return '<p>لا توجد حسابات شخصية نشطة ومستفيدون صالحون للتسليم.</p>';
 return `<section class="panel"><div class="panel-head"><div><h3>تسليم عهدة للمستفيد — تجربة فقط</h3><p>طلب معلّق يحتاج تأكيد المستلم. الرصيد المتاح يتحقق منه PostgreSQL.</p></div></div>
 <label for="personalHandoverAccount">حساب الخدمة والمستفيد</label><select id="personalHandoverAccount">${usable.map(a=>`<option value="${esc(a.accountId)}" data-recipient-id="${esc(a.beneficiaryUserId)}">${esc(a.serviceName||'خدمة')} — ${esc(a.beneficiaryName||'المستفيد')}</option>`).join('')}</select>
 <label for="personalHandoverAmount">المبلغ بالجنيه</label><input id="personalHandoverAmount" type="number" inputmode="decimal" min="0.01" step="0.01">
 <button id="personalHandoverSubmit" class="btn-sm primary" type="button" onclick="submitPersonalBeneficiaryHandover()">إنشاء طلب تسليم معلّق</button>
 <p id="personalHandoverMessage" role="status" aria-live="polite"></p></section>`;
}
async function refreshMyPendingHandovers(){
 const root=document.getElementById('personalPendingHandovers');if(!root)return;
 const epoch=++PERSONAL_PENDING_REQUEST_EPOCH;
 root.textContent='جارٍ تحميل طلبات العهدة المعلقة…';
 try{
  const rows=await run('listMyPersonalPendingHandovers');
  if(epoch!==PERSONAL_PENDING_REQUEST_EPOCH||root!==document.getElementById('personalPendingHandovers'))return;
  if(!Array.isArray(rows))throw Error('INVALID_PENDING_HANDOVERS');
  const actionable=rows.filter(m=>m&&(m.canConfirm===true||m.canCancel===true));
  root.innerHTML=personalPendingHandoversHtml(actionable);
  if(APP.ctx?.user?.role==='RESIDENT'&&APP.page==='services'&&actionable.length===0){document.getElementById('residentPersonalHandoverInbox')?.remove();}
 }catch(e){
  if(epoch===PERSONAL_PENDING_REQUEST_EPOCH&&root===document.getElementById('personalPendingHandovers'))root.textContent='تعذر تحميل الطلبات: '+errText(e);
 }
}
const PERSONAL_HANDOVER_IN_FLIGHT=new Set();
async function resolveMyPersonalHandover(movementId,action){
 if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(movementId)||!['confirm','cancel'].includes(action)||PERSONAL_HANDOVER_IN_FLIGHT.has(movementId))return;
 const label=action==='confirm'?'تأكيد استلام العهدة':'إلغاء طلب العهدة';
 if(!await confirmAction({title:label,message:action==='confirm'?'هل استلمت المبلغ فعليًا؟ سيُسجل الاستلام بعد التأكيد.':'سيتم إلغاء الطلب المعلّق وإتاحة الرصيد مجددًا.',confirmLabel:label}))return;
 const root=document.getElementById('personalPendingHandovers');
 const epoch=++PERSONAL_PENDING_REQUEST_EPOCH;
 PERSONAL_HANDOVER_IN_FLIGHT.add(movementId);
 if(root)root.textContent='جارٍ تنفيذ '+label+'…';
 try{
  await run(action==='confirm'?'confirmPersonalCashHandover':'cancelPersonalCashHandover',{movementId});
  toast('تم '+label,'success');await refreshMyPendingHandovers();
 }catch(e){if(epoch===PERSONAL_PENDING_REQUEST_EPOCH&&root===document.getElementById('personalPendingHandovers'))root.textContent='تعذر تنفيذ الإجراء: '+errText(e);}
 finally{PERSONAL_HANDOVER_IN_FLIGHT.delete(movementId);}
}
function personalPendingHandoversPanel(){
 return `<section class="panel"><div class="panel-head"><div><h3>طلبات العهدة المعلّقة</h3><p>لا يظهر إلا ما يخص حسابك. المستلم يؤكد، والمرسل يلغي.</p></div><button class="btn-sm" onclick="refreshMyPendingHandovers()">تحديث</button></div><div id="personalPendingHandovers" role="status" aria-live="polite"></div></section>`;
}
let PERSONAL_FINANCE_RENDER_EPOCH=0;
function renderFinanceBody(){const financeEpoch=++PERSONAL_FINANCE_RENDER_EPOCH;const root=$('financeBody'),d=FIN_UI.data;if(!root||!d)return;const dash=d.dashboard||{};
 if(FIN_UI.tab==='personal'){
  root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>حسابات الخدمات الشخصية</h3><p>حسابات المستفيدين منفصلة عن صندوق العمارة، ولا تُعرض كإيرادات للصندوق.</p></div></div><div id="personalFinanceStatus" role="status" aria-live="polite">${pageLoading('جاري التحقق من جاهزية الحسابات الشخصية…')}</div></section><div id="personalRefundApprovalPanel"></div>`;
  loadPersonalRefundApprovalPanel();
  const personalStatusNode=$('personalFinanceStatus');
  const isCurrentPersonal=()=>financeEpoch===PERSONAL_FINANCE_RENDER_EPOCH&&FIN_UI.tab==='personal'&&root===$('financeBody')&&personalStatusNode===$('personalFinanceStatus');
  run('getPersonalFinanceIntegrationStatus').then(status=>{
   if(!isCurrentPersonal())return;
   const el=personalStatusNode;
   if(status?.available===true&&status?.canRead===true&&status?.canMutate===false){
    el.innerHTML=pageLoading('جاري تحميل كشف الخدمات الشخصية…');
    run('getPersonalFinanceLedger').then(data=>{
     if(!isCurrentPersonal())return;
     const node=personalStatusNode;
     const accounts=Array.isArray(data?.accounts)?data.accounts:[];
     node.innerHTML=`<p class="selection-count">${status.canPostPersonalReceipt||status.canRequestPersonalHandover?'عمليات تجريبية مقيّدة على Staging فقط؛ الاسترداد وباقي الحركات غير مفعّلة من هذه الشاشة.':'قراءة فقط — التحصيل والتسليم والاسترداد غير مفعّلين هنا.'}</p>${accounts.length?`<div class="list-stack">${accounts.map(a=>`<article class="data-card"><div class="data-main"><div><strong>${esc(a.serviceName||'خدمة شخصية')}</strong><span>المستفيد: ${esc(a.beneficiaryName||'—')}</span></div><span class="badge muted">${esc(a.status||'')}</span></div><div class="data-meta"><span>المحصّل ${money(a.collected||0)}</span><span>المستحقات ${money(a.dues||0)}</span><span>تسليمات معلقة ${money(a.pendingMovements||0)}</span></div></article>`).join('')}</div>`:emptyState('لا توجد حسابات شخصية','لم تُسجّل حسابات للخدمات الشخصية بعد.')}`;
     if(status.canPostPersonalReceipt===true){node.insertAdjacentHTML('afterend',personalReceiptStageForm(accounts,FIN_UI.data?.units||[]));}
     if(status.canPostMixedCollection===true){node.insertAdjacentHTML('afterend',mixedCollectionStageForm(accounts,FIN_UI.data?.units||[]));}
     if(status.canRequestPersonalHandover===true){node.insertAdjacentHTML('afterend',personalHandoverStageForm(accounts));}
     if(status.canRequestPersonalHandover===true){node.insertAdjacentHTML('afterend',personalPendingHandoversPanel());refreshMyPendingHandovers();}
    }).catch(()=>{if(isCurrentPersonal())personalStatusNode.innerHTML='<p class="resident-building-empty">تعذّر تحميل الكشف. لا توجد معاملات مالية متاحة.</p>';});
    return;
   }
   el.innerHTML=`<p class="resident-building-empty">${esc(status?.message||'الحسابات الشخصية غير مفعّلة حاليًا.')}</p><p class="selection-count">حالة الربط: ${esc(status?.mode||'غير متاح')} · قاعدة البيانات: ${esc(status?.components?.schema||'غير معروفة')} · اختبارات PostgreSQL: ${esc(status?.components?.postgresTests||'غير معروفة')}</p><p class="selection-count">لا توجد عمليات تحصيل أو صرف أو استرداد مفعّلة في هذا القسم.</p>`;
  }).catch(()=>{if(isCurrentPersonal())personalStatusNode.innerHTML='<p class="resident-building-empty">تعذر التحقق من حالة الحسابات الشخصية. لن تُنفذ أي معاملة.</p>';});
  return;
 }
 if(FIN_UI.tab==='overview'){root.innerHTML=`<div class="grid finance-kpis"><div class="stat fund-featured"><span>رصيد الصندوق</span><strong>${money(dash.balance||0)}</strong></div><div class="stat"><span>المطلوب حاليًا</span><strong>${money(dash.outstandingTotal||0)}</strong></div><div class="stat"><span>المحصل</span><strong>${money(dash.incomeTotal||0)}</strong></div><div class="stat"><span>المصروفات</span><strong>${money(dash.expenseTotal||0)}</strong></div><div class="stat"><span>المتأخرات</span><strong>${dash.arrearsTotal==null?'—':money(dash.arrearsTotal)}</strong></div></div><section class="panel"><div class="panel-head"><div><h3>إجراءات سريعة</h3><p>أكثر عمليات رئيس الاتحاد استخدامًا.</p></div></div><div class="home-actions">${homeAction('＋','تحصيل جديد','إنشاء استحقاق وتوزيعه على الوحدات','financeCharge',true).replace("go('financeCharge')","openChargeModal()")}${homeAction('✓','تسجيل دفعة','سداد كامل أو جزئي لاستحقاق','financePay',false).replace("go('financePay')","openBuildingPaymentModal()")}${homeAction('−','مصروف','تسجيل مصروف من الصندوق','financeExpense',false).replace("go('financeExpense')","openFinanceModal('EXPENSE')")}${homeAction('＋','إيداع','إضافة مبلغ للصندوق','financeDeposit',false).replace("go('financeDeposit')","openFinanceModal('INCOME')")}</div></section><section class="panel"><div class="panel-head"><div><h3>آخر الحركات</h3><p>التحصيلات والمصروفات والإيداعات الفعلية فقط.</p></div></div>${fundList(dash.entries||[])}</section>`;return;}
 if(FIN_UI.tab==='charges'){root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>التحصيلات</h3><p>كل استحقاق وتوزيعه وحالة تحصيله.</p></div><button class="btn-sm primary" onclick="openChargeModal()">+ تحصيل جديد</button></div>${d.charges.length?`${financeListTools('ابحث بعنوان التحصيل أو التصنيف')}<div class="list-stack" id="financeRecordList">${d.charges.map(c=>`<article class="data-card" data-finance-record><div class="data-main"><div><strong>${esc(c.title)}</strong><span>${esc(c.category||'تحصيل')} · ${esc(c.periodLabel||c.dueDate||'')}</span></div><strong>${money(c.allocatedTotal)}</strong></div><div class="data-meta"><span>${c.unitCount} وحدة · محصل ${money(c.paidTotal)}</span><span class="badge ${c.remainingTotal<=.005?'success':'muted'}">متبقي ${money(c.remainingTotal)}</span></div><div class="compact-actions"><button class="btn-sm" onclick="openBuildingPaymentModal('${esc(c.chargeId)}')">تسجيل دفعة</button></div></article>`).join('')}</div><p id="financeNoMatches" class="empty-search" hidden>لا توجد سجلات تطابق البحث.</p>`:emptyState('لا توجد تحصيلات','أنشئ أول تحصيل من الزر بالأعلى.')}</section>`;finishFinanceRecordList();return;}
 if(FIN_UI.tab==='payments'){root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الدفعات</h3><p>سجل الدفعات الفعلية للوحدات.</p></div><button class="btn-sm primary" onclick="openBuildingPaymentModal()">+ تسجيل دفعة</button></div>${d.payments.length?`${financeListTools('ابحث بالوحدة أو طريقة الدفع')}<div class="list-stack" id="financeRecordList">${d.payments.map(p=>`<article class="data-card" data-finance-record><div class="data-main"><div><strong>${finUnitLabel(p.unit)}</strong><span>${esc(p.method||'نقدي')} · ${esc(displayDateTime12(p.paidAt))}</span></div><strong class="positive">+ ${money(p.amount)}</strong></div><div class="data-meta"><span>${esc(p.note||'')}</span><span class="badge success">مسددة${p.attachmentCount?` · ${p.attachmentCount} مرفق`:''}</span></div><div class="compact-actions"><button class="btn-sm" onclick="openPaymentReceiptById('${esc(p.paymentId)}')">إيصال</button></div></article>`).join('')}</div><p id="financeNoMatches" class="empty-search" hidden>لا توجد سجلات تطابق البحث.</p>`:emptyState('لا توجد دفعات','')}</section>`;finishFinanceRecordList();return;}
 if(FIN_UI.tab==='arrears'){
  const grouped=new Map();
  for(const item of d.arrears||[]){const key=String(item.unitId||'');if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(item);}
  const groups=[...grouped.entries()].map(([unitId,items])=>({unitId,items,total:items.reduce((s,x)=>s+Number(x.remaining||0),0)})).sort((a,b)=>b.total-a.total);
  const outstanding=groups.reduce((s,x)=>s+x.total,0);
  root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>المتأخرات والمبالغ المستحقة</h3><p>كل وحدة مرة واحدة؛ افتح تفاصيلها لتسجيل دفعة على الاستحقاق الصحيح.</p></div><span class="badge">${groups.length} وحدة · ${d.arrears.length} استحقاق</span></div><div class="finance-arrears-summary"><span>إجمالي المبالغ المتبقية</span><strong>${money(outstanding)}</strong></div>${groups.length?`<div class="list-stack finance-arrears-groups">${groups.map(g=>{const u=(d.units||[]).find(u=>String(u.unitId)===g.unitId)||g.items[0].unit;return `<details class="finance-arrears-unit"><summary><span class="arrears-unit-identity"><strong>${finUnitLabel(u)}</strong><small>${g.items.length} استحقاق ${g.items.length===1?'مفتوح':'مفتوحة'}</small></span><span class="arrears-unit-total"><strong>${money(g.total)}</strong><small>المتبقي</small></span><span class="arrears-unit-chevron" aria-hidden="true">⌄</span></summary><div class="finance-arrears-unit-body"><div class="arrears-unit-actions"><button class="btn-sm" onclick="openUnitStatement('${esc(g.unitId)}')">كشف الحساب</button></div>${g.items.map(item=>`<div class="arrears-charge-line"><div><strong>${esc(item.chargeTitle||'استحقاق')}</strong><small>${esc(item.dueDate||'')}</small></div><strong>${money(item.remaining)}</strong><button class="btn-sm primary" onclick="openBuildingPaymentModal('${esc(item.chargeId)}','${esc(item.unitId)}')">تسجيل دفعة</button></div>`).join('')}</div></details>`}).join('')}</div>`:emptyState('لا توجد مبالغ مستحقة','كل التحصيلات الحالية مسددة.')}</section>`;return;
 }

 if(FIN_UI.tab==='fund'){root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>الصندوق</h3><p>الرصيد الفعلي وحركاته، مستقل تمامًا عن حساب مشاوير الحارس.</p></div><div class="compact-actions"><button class="btn-sm primary" onclick="openFinanceModal('INCOME')">+ إيداع</button><button class="btn-sm" onclick="openFinanceModal('EXPENSE')">+ مصروف</button></div></div><div class="union-balance"><span>الرصيد الحالي</span><strong>${money(dash.balance||0)}</strong><div><small>إيرادات ${money(dash.incomeTotal||0)}</small><small>مصروفات ${money(dash.expenseTotal||0)}</small></div></div>${(dash.entries||[]).length?financeListTools('ابحث بالبيان أو التصنيف أو المرجع'):''}${fundList(dash.entries||[],true)}</section>`;finishFinanceRecordList();return;}
 if(FIN_UI.tab==='audit'){root.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>المراجعة المالية</h3><p>سجل الحركات الحساسة مع إظهار التغييرات المسجّلة عندما تكون متاحة.</p></div></div><div id="finAuditBody">${pageLoading('جاري تحميل السجل…')}</div></section>`;run('getFinancialAudit',150).then(rows=>{const b=$('finAuditBody');if(!b)return;b.innerHTML=rows.length?`<div class="list-stack">${rows.map(x=>`<button class="activity-row" onclick="openFinancialAudit('${esc(x.auditId)}')"><div><strong>${esc(activityActionLabel(x.action))}</strong><span>${esc(activityContextLabel(x))}</span></div><div><span>${esc(displayDateTime12(x.timestamp))}</span><small>${esc(activityActorLabel(x))}</small></div></button>`).join('')}</div>`:emptyState('لا توجد حركات مالية مسجلة','');}).catch(e=>{const b=$('finAuditBody');if(b)b.innerHTML=errorCard(e);});return;}
}
function fundList(entries,searchable=false){return entries.length?`<div class="list-stack" ${searchable?'id="financeRecordList"':''}>${entries.map(e=>`<article class="data-card" ${searchable?'data-finance-record':''}><div class="data-main"><div><strong>${esc(e.description)}</strong><span>${esc(e.category||'بدون تصنيف')} · ${esc(e.entryDate)}</span></div><strong class="${e.entryType==='INCOME'?'positive':'negative'}">${e.entryType==='INCOME'?'+':'−'} ${money(e.amount)}</strong></div><div class="data-meta"><span>${esc(e.reference||'')}</span><span class="badge ${e.status==='ACTIVE'?'success':'muted'}">${e.status==='ACTIVE'?'فعالة':'ملغاة'}</span></div>${e.status==='ACTIVE'?`<div class="compact-actions"><button class="btn-sm danger" onclick="cancelFinance('${esc(e.entryId)}')">إلغاء الحركة</button></div>`:''}</article>`).join('')}</div>`:emptyState('لا توجد حركات مالية','');}
function unitOptions(selected=''){return (FIN_UI.data.units||[]).map(u=>`<option value="${esc(u.unitId)}" ${u.unitId===selected?'selected':''}>شقة ${esc(unitNo(u.unitNumber))} — دور ${esc(floorNo(u.floor||''))} — ${esc(u.managerName||'المدير غير متاح')}</option>`).join('');}
function financeUnitRows(){return (FIN_UI.data.units||[]).map(u=>{const id=esc(u.unitId),no=esc(unitNo(u.unitNumber));return `<div class="finance-unit-row" data-type="${esc(u.unitTypeId)}" data-unit="${id}"><label class="charge-unit-main" for="chgUnit_${id}"><input id="chgUnit_${id}" type="checkbox" class="chgUnit" value="${id}" onchange="syncChargeUnitCount()"><span class="finance-unit-id"><small>الوحدة</small><strong>${no}</strong></span><span class="charge-unit-floor"><small>الدور</small><strong>${esc(floorNo(u.floor||''))}</strong></span><span class="finance-unit-manager"><small>مدير الوحدة</small><strong>${esc(u.managerName||'المدير غير متاح')}</strong></span></label><label class="defer-mini"><input type="checkbox" class="chgDeferred" value="${id}"><span>مؤجل</span></label><input class="chgCustomAmount hidden" data-custom-unit="${id}" type="number" min="0" step="0.01" inputmode="decimal" placeholder="مبلغ الوحدة بالجنيه" aria-label="مبلغ الوحدة ${no}" oninput="syncChargeUnitCount()"></div>`}).join('');}
function filterChargeUnits(){
 const raw=($('chgUnitSearch')?.value||'').trim(),tokens=normAr(raw).split(/\s+/).filter(Boolean),type=$('chgUnitType')?.value||'';
 let visible=0;const rows=[...document.querySelectorAll('.finance-unit-row')];
 rows.forEach(r=>{const show=uiSearchMatch(r.textContent||'',raw)&&(!type||r.dataset.type===type);r.classList.toggle('hidden',!show);r.hidden=!show;if(show)visible++;});
 const counter=$('chgUnitResultsCount');if(counter)counter.textContent=`عرض ${visible} من ${rows.length} وحدة`;
 const empty=$('chgUnitNoMatches');if(empty)empty.hidden=visible!==0;
 const reset=$('chgUnitReset');if(reset)reset.disabled=!(raw||type);
 syncChargeUnitCount();
}
function clearChargeUnitFilters(){if($('chgUnitSearch'))$('chgUnitSearch').value='';if($('chgUnitType'))$('chgUnitType').value='';filterChargeUnits();$('chgUnitSearch')?.focus();}
function setAllChargeUnits(v){document.querySelectorAll('.finance-unit-row:not([hidden]) .chgUnit').forEach(x=>{if(!x.disabled)x.checked=v;});syncChargeUnitCount();}

function syncChargeUnitCount(){const e=$('chgUnitCount'),mode=$('chgDist')?$('chgDist').value:'EQUAL_SELECTED';if(!e)return;const selected=[...document.querySelectorAll('.chgUnit:checked')];document.querySelectorAll('.finance-unit-row').forEach(row=>{const chosen=!!row.querySelector('.chgUnit:checked'),amount=row.querySelector('.chgCustomAmount');row.classList.toggle('unit-selected',chosen);if(amount){amount.disabled=mode!=='CUSTOM'||!chosen;amount.classList.toggle('hidden',mode!=='CUSTOM'||!chosen);}});e.textContent=mode==='CUSTOM'?`${selected.length} وحدة محددة — أدخل مبلغ كل وحدة`:`${selected.length} محددة`;}
function openChargeModal(){openModal(`<div class="modal-head"><div><h3>تحصيل جديد</h3><p>أنشئ الاستحقاق وعاين توزيعه قبل الحفظ.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid charge-form" onsubmit="previewCharge(event)"><label class="field"><span>اسم التحصيل</span><input id="chgTitle" required placeholder="مثال: صيانة المصعد"></label><label class="field"><span>الإجمالي</span><input id="chgTotal" type="number" min="0.01" step="0.01" required></label><label class="field"><span>التصنيف</span><select id="chgCategory" onchange="applyChargeCategoryPolicy()">${(FIN_UI.categories||[]).filter(x=>x.status==='ACTIVE').map(x=>`<option value="${esc(x.categoryId)}">${esc(x.name)}</option>`).join('')}</select><button class="text-action" type="button" onclick="openCollectionCategories()">إدارة التصنيفات</button></label><label class="field"><span>تاريخ الاستحقاق</span><input id="chgDue" type="date"></label><label class="field"><span>طريقة التوزيع</span><select id="chgDist" onchange="toggleChargeUnits()"><option value="EQUAL_ALL">بالتساوي على كل الوحدات</option><option value="EQUAL_SELECTED">بالتساوي على وحدات مختارة</option><option value="CATEGORY_POLICY">حسب التصنيف</option><option value="TYPE_POLICY">حسب وزن نوع الوحدة</option><option value="CUSTOM">توزيع مخصص لكل وحدة</option></select></label><label class="field"><span>الفترة</span><input id="chgPeriod" placeholder="مثال: أكتوبر 2026"></label><section id="chgUnitsWrap" class="charge-unit-section span-2" hidden><div class="charge-unit-head"><div><strong>الوحدات المشاركة</strong><small id="chgUnitCount">0 محددة</small></div><div class="compact-actions"><button type="button" class="btn-sm" onclick="setAllChargeUnits(true)" title="تحديد الوحدات الظاهرة بعد الفلترة">تحديد الظاهر</button><button type="button" class="btn-sm" onclick="setAllChargeUnits(false)" title="إلغاء تحديد الوحدات الظاهرة فقط">إلغاء تحديد الظاهر</button></div></div><div class="filter-toolbar"><input id="chgUnitSearch" type="search" autocomplete="off" aria-label="البحث عن وحدات التحصيل" aria-controls="chgUnitResultsCount" oninput="filterChargeUnits()" placeholder="بحث: الوحدة / الدور / المدير"><select id="chgUnitType" aria-label="فلترة نوع الوحدة" onchange="filterChargeUnits()"><option value="">كل الأنواع</option>${[...new Map((FIN_UI.data.units||[]).filter(u=>u.unitTypeId).map(u=>[u.unitTypeId,u.unitTypeName])).entries()].map(x=>`<option value="${esc(x[0])}">${esc(x[1])}</option>`).join('')}</select><button type="button" class="btn-sm" id="chgUnitReset" onclick="clearChargeUnitFilters()" disabled>مسح الفلاتر</button></div><p class="selection-count" id="chgUnitResultsCount" role="status" aria-live="polite">${(FIN_UI.data.units||[]).length} وحدة</p><div class="finance-unit-picker modern">${financeUnitRows()}</div><p id="chgUnitNoMatches" class="selection-count" role="status" hidden>لا توجد وحدات مطابقة. جرّب تعديل البحث أو مسح الفلاتر.</p></section><label class="field span-2"><span>ملاحظات</span><textarea id="chgNotes"></textarea></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">معاينة التوزيع</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`,true);}
function toggleChargeUnits(){const w=$('chgUnitsWrap'),mode=$('chgDist').value;if(w){w.hidden=mode==='EQUAL_ALL';w.classList.toggle('hidden',w.hidden);}document.querySelectorAll('.chgUnit').forEach(x=>{x.disabled=false;});syncChargeUnitCount();}
function applyChargeCategoryPolicy(){const c=(FIN_UI.categories||[]).find(x=>x.categoryId===$('chgCategory')?.value);if(c&&$('chgDist'))$('chgDist').value=c.defaultDistribution||'CATEGORY_POLICY';toggleChargeUnits();}
function openCollectionCategories(){const types=(FIN_UI.data&&FIN_UI.data.units||[]).reduce((o,u)=>{if(u.unitTypeId&&!o[u.unitTypeId])o[u.unitTypeId]={id:u.unitTypeId,name:u.unitTypeName};return o;},{}),rows=(FIN_UI.categories||[]);openModal(`<div class="modal-head"><div><h3>تصنيفات التحصيل</h3><p>حدد سياسة الحساب الافتراضية وأوزان أنواع الوحدات.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="list-stack">${rows.map(c=>`<article class="data-card"><div class="data-main"><div><strong>${esc(c.name)}</strong><span>${c.status==='ACTIVE'?'نشط':'غير نشط'} · ${esc(c.defaultDistribution||'CATEGORY_POLICY')}</span></div><button class="btn-sm" onclick="editCollectionCategory('${esc(c.categoryId)}')">تعديل</button></div></article>`).join('')}</div><div class="form-actions"><button class="btn-sm primary" onclick="editCollectionCategory('')">+ تصنيف</button></div>`);}
function editCollectionCategory(id){const c=(FIN_UI.categories||[]).find(x=>x.categoryId===id)||{name:'',defaultDistribution:'CATEGORY_POLICY',weights:{}},types=[...new Map((FIN_UI.data.units||[]).filter(u=>u.unitTypeId).map(u=>[u.unitTypeId,{id:u.unitTypeId,name:u.unitTypeName}])).values()];openModal(`<div class="modal-head"><div><h3>${id?'تعديل التصنيف':'تصنيف جديد'}</h3><p>الأوزان تخص هذا التصنيف فقط ولا تغير التحصيلات السابقة.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="saveCollectionCategoryClient(event,'${esc(id)}')"><label class="field span-2"><span>اسم التصنيف</span><input id="catName" value="${esc(c.name)}" required></label><label class="field span-2"><span>طريقة التوزيع</span><select id="catDist"><option value="CATEGORY_POLICY" ${c.defaultDistribution==='CATEGORY_POLICY'?'selected':''}>حسب أوزان التصنيف</option><option value="EQUAL_ALL" ${c.defaultDistribution==='EQUAL_ALL'?'selected':''}>بالتساوي</option></select></label>${types.map(t=>`<label class="field"><span>${esc(t.name)}</span><input class="catWeight" data-type="${esc(t.id)}" type="number" min="0" step="0.01" value="${Number(c.weights&&c.weights[t.id]||1)}"></label>`).join('')}<div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="openCollectionCategories()">إلغاء</button></div></form>`);}
async function saveCollectionCategoryClient(e,id){e.preventDefault();const weights={};document.querySelectorAll('.catWeight').forEach(x=>weights[x.dataset.type]=Number(x.value)||0);const p={categoryId:id,name:$('catName').value,defaultDistribution:$('catDist').value,weights};closeModal();beginBackgroundSave();try{await run('saveCollectionCategory',p);FIN_UI.categories=await run('listCollectionCategories',true);toast('تم حفظ التصنيف.');}catch(x){toast(errText(x),'error');}finally{endBackgroundSave();}}

function chargePayload(){const distribution=$('chgDist').value,customAmounts={};if(distribution==='CUSTOM')document.querySelectorAll('.finance-unit-row').forEach(row=>{if(!row.querySelector('.chgUnit:checked'))return;const x=row.querySelector('.chgCustomAmount'),v=Number(x.value)||0;if(v>0)customAmounts[x.dataset.customUnit]=v;});const cat=(FIN_UI.categories||[]).find(x=>x.categoryId===$('chgCategory').value);return{title:$('chgTitle').value,totalAmount:$('chgTotal').value,categoryId:$('chgCategory').value,category:cat?cat.name:$('chgCategory').value,dueDate:$('chgDue').value,distribution,periodLabel:$('chgPeriod').value,notes:$('chgNotes').value,unitIds:[...document.querySelectorAll('.chgUnit:checked')].map(x=>x.value),deferredUnitIds:[...document.querySelectorAll('.chgDeferred:checked')].map(x=>x.value),customAmounts};}
async function previewCharge(e){e.preventDefault();const p=chargePayload();if(['CUSTOM','EQUAL_SELECTED'].includes(p.distribution)&&!p.unitIds.length){toast('اختار وحدة واحدة على الأقل علشان تعاين التوزيع.','error');$('chgUnitSearch')?.focus();return;}if(p.distribution==='CUSTOM'&&p.unitIds.some(id=>!(Number(p.customAmounts[id])>0))){toast('اكتب مبلغًا أكبر من صفر لكل وحدة محددة.','error');return;}try{const rows=await run('previewBuildingCharge',p);openModal(`<div class="modal-head"><div><h3>معاينة التحصيل</h3><p>${esc(p.title)} · ${rows.length} وحدة</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="list-stack finance-preview">${rows.map(x=>`<div class="data-card"><div class="data-main"><strong>شقة ${esc(unitNo(x.unitNumber))} · دور ${esc(floorNo(x.floor||''))}</strong><strong>${x.deferred?'مؤجل':money(x.amount)}</strong></div><div class="data-meta"><span>${esc(x.managerName||'غير معين')} · ${esc(x.unitTypeName||'')}</span>${x.deferred?`<span class="badge muted">نصيبه الأساسي ${money(x.baseAmount||0)}</span>`:''}</div></div>`).join('')}</div><div class="form-actions"><button class="btn-sm primary" onclick='commitCharge(${JSON.stringify(p)})'>تأكيد إنشاء التحصيل</button><button class="btn-sm" onclick="closeModal()">رجوع</button></div>`);}catch(x){toast(errText(x),'error');}}
async function commitCharge(p){closeModal();beginBackgroundSave();try{await run('createBuildingCharge',p);await refreshFinanceSilent('charges');toast('تم إنشاء التحصيل.');}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
function financePaymentDues(chargeId){
 const rows=FIN_UI.data?.arrears;
 if(!Array.isArray(rows))return null;
 return rows.filter(x=>String(x.chargeId)===String(chargeId)&&Number(x.remaining)>0.005);
}
function syncPaymentEligibleUnits(preferred=''){
 const charge=$('payCharge'),sel=$('payUnit'),info=$('payUnitRemaining'),btn=$('paySubmit');if(!charge||!sel)return;
 const dues=financePaymentDues(charge.value),old=preferred||sel.value;
 if(!dues){sel.innerHTML='<option value="">تعذر تحديد مستحقات الوحدات؛ حدّث المالية</option>';sel.disabled=true;if(btn)btn.disabled=true;if(info)info.textContent='بيانات متبقي الوحدات غير متاحة. أعد فتح المالية قبل تسجيل الدفعة.';return;}
 const permitted=new Map(dues.map(x=>[String(x.unitId),Number(x.remaining)]));
 const options=(FIN_UI.data?.units||[]).filter(u=>permitted.has(String(u.unitId)));
 const floorSelect=$('payFloor');
 if(floorSelect){const floorValues=[...new Set(options.map(u=>String(u.floor??'').trim()))].sort((a,b)=>Number(a)-Number(b));const oldFloor=floorSelect.value;floorSelect.innerHTML='<option value="">الدور</option>'+floorValues.map(f=>`<option value="${esc(f)}">${esc(floorNo(f))}</option>`).join('');if(floorValues.includes(oldFloor))floorSelect.value=oldFloor;else if(permitted.has(String(old)))floorSelect.value=String(options.find(u=>String(u.unitId)===String(old))?.floor??'').trim();}
 const filtered=options.filter(u=>!floorSelect?.value||String(u.floor??'').trim()===floorSelect.value);
 sel.innerHTML='<option value="">الوحدة</option>'+filtered.map(u=>`<option value="${esc(u.unitId)}">${esc(unitNo(u.unitNumber))} — متبقي ${money(permitted.get(String(u.unitId)))}</option>`).join('');
 if(permitted.has(String(old)))sel.value=old;
 sel.disabled=!options.length;if(btn)btn.disabled=!options.length;
 if(info)info.textContent=options.length?'المتبقي على الوحدة المختارة يظهر بعد اختيارها.':'كل الوحدات مسددة لهذا التحصيل، أو لا توجد مبالغ متبقية قابلة للسداد.';
 syncPaymentUnitRemaining();
}
function syncPaymentFloor(){const sel=$('payUnit');if(sel)sel.value='';syncPaymentEligibleUnits();}
function syncPaymentUnitRemaining(){const charge=$('payCharge'),sel=$('payUnit'),info=$('payUnitRemaining'),amount=$('payAmount');if(!charge||!sel||!info)return;const due=(financePaymentDues(charge.value)||[]).find(x=>String(x.unitId)===sel.value);const remaining=Number(due?.remaining||0);info.textContent=due?'المتبقي على الوحدة: '+money(remaining):'اختر الوحدة لعرض المبلغ المتبقي عليها.';if(amount){amount.max=due?String(Math.round(remaining*100)/100):'';}}
function openBuildingPaymentModal(chargeId='',unitId=''){
 const charges=(FIN_UI.data?.charges||[]).filter(c=>Number(c.remainingTotal)>0.005);
 const eligible=charges.filter(c=>{const dues=financePaymentDues(c.chargeId);return dues!==null&&dues.length>0;});
 if(!Array.isArray(FIN_UI.data?.arrears)){toast('تعذر تحميل مستحقات الوحدات. حدّث شاشة المالية وحاول مرة أخرى.','error');return;}
 if(!eligible.length){toast('لا توجد وحدات عليها مبالغ مستحقة يمكن تسجيل دفعة لها.','warning');return;}
 const selected=eligible.some(c=>String(c.chargeId)===String(chargeId))?chargeId:eligible[0].chargeId;
 openModal(`<div class="modal-head"><div><h3>تسجيل دفعة</h3><p>الاختيار متاح للوحدات التي عليها مبالغ متبقية فقط.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitBuildingPayment(event)"><label class="field span-2"><span>التحصيل</span><select id="payCharge" required onchange="syncPaymentEligibleUnits()">${eligible.map(c=>`<option value="${esc(c.chargeId)}" ${String(c.chargeId)===String(selected)?'selected':''}>${esc(c.title)} — متبقي الفاتورة ${money(c.remainingTotal)}</option>`).join('')}</select></label><label class="field"><span>الدور</span><select id="payFloor" required onchange="syncPaymentFloor()"><option value="">الدور</option></select></label><label class="field"><span>الوحدة</span><select id="payUnit" required onchange="syncPaymentUnitRemaining()"></select><small id="payUnitRemaining" role="status" aria-live="polite"></small></label><label class="field"><span>المبلغ</span><input id="payAmount" type="number" min="0.01" step="0.01" required></label><label class="field"><span>طريقة الدفع</span><select id="payMethod"><option>نقدي</option><option>تحويل</option><option>محفظة إلكترونية</option><option>أخرى</option></select></label><label class="field span-2"><span>ملاحظة</span><input id="payNote"></label><div class="form-actions span-2"><button id="paySubmit" class="btn-sm primary" type="submit">تسجيل الدفعة</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);
 syncPaymentEligibleUnits(unitId);
 if(unitId&&!$('payUnit').value)toast('الوحدة المحددة مسددة بالكامل لهذا التحصيل، أو غير مشاركة فيه. اختر وحدة عليها متبقي.','warning');
}
async function submitBuildingPayment(e){
 e.preventDefault();const p={chargeId:$('payCharge').value,unitId:$('payUnit').value,amount:$('payAmount').value,method:$('payMethod').value,note:$('payNote').value},unit=(FIN_UI.data.units||[]).find(x=>x.unitId===p.unitId),charge=(FIN_UI.data.charges||[]).find(x=>x.chargeId===p.chargeId);
 const dues=financePaymentDues(p.chargeId),due=dues?.find(x=>String(x.unitId)===String(p.unitId)),amount=Number(p.amount);
 if(!dues){toast('معلومات المتبقي على الوحدة غير متاحة. حدّث شاشة المالية قبل المحاولة.','error');return;}
 if(!due){toast('الوحدة مسددة نصيبها بالكامل في التحصيل ده، أو غير مشاركة فيه. اختَر وحدة عليها مبلغ متبقٍ.','error');return;}
 if(!Number.isFinite(amount)||amount<=0){toast('اكتب مبلغًا صحيحًا أكبر من صفر.','error');return;}
 if(Math.round(amount*100)>Math.round(Number(due.remaining)*100)){toast('المبلغ أكبر من المتبقي على الوحدة ('+money(due.remaining)+').','error');return;}
 beginBackgroundSave();try{const r=await run('recordBuildingPayment',p);closeModal();await refreshFinanceSilent('payments');openPaymentReceipt({paymentId:r.paymentId,unit,chargeTitle:charge?charge.title:'تحصيل',amount,method:p.method,note:p.note,paidAt:new Date().toISOString(),attachmentCount:0});toast('تم تسجيل الدفعة.','success');}catch(x){toast(errText(x),'error');}finally{endBackgroundSave();}
}
function paymentReceiptDate(r){
 const value=r&&r.paidAt;if(!value)return '—';
 if(typeof value==='string'&&/^\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2}\s+(AM|PM)$/i.test(value))return value.replace(/\s+AM$/i,' ص').replace(/\s+PM$/i,' م');
 const raw=displayDateTime12(value);
 return raw.replace(/\s+AM$/i,' ص').replace(/\s+PM$/i,' م');
}
function paymentReceiptReference(r){return String(r?.paymentId||'').split('-')[0].toUpperCase();}
function paymentReceiptText(r){
 const building=(APP.ctx&&APP.ctx.building&&APP.ctx.building.name)||'Tower App';
 return [building,'إيصال دفعة',r.paymentId?'مرجع الإيصال: '+paymentReceiptReference(r):'',r.unit?'الوحدة: '+finUnitLabel(r.unit):'',`البند: ${r.chargeTitle||'تحصيل'}`,`المبلغ: ${money(r.amount)}`,`طريقة الدفع: ${r.method||'نقدي'}`,`التاريخ: ${paymentReceiptDate(r)}`,paymentReceiptVisibleNote(r)?`ملاحظة: ${paymentReceiptVisibleNote(r)}`:''].filter(Boolean).join('\n');
}
function paymentReceiptVisibleNote(r){
 const note=String(r?.note||'').trim();
 // Technical collection-report UUIDs are internal references, not user-entered notes.
 if(/^تقرير تحصيل\s*[—–:-]?\s*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\s*[—–-]?$/i.test(note))return ''; 
 return note;
}
function paymentReceiptDocument(r){
 const building=(APP.ctx&&APP.ctx.building&&APP.ctx.building.name)||'Tower App';
 const logo=APP.ctx?.branding?.logoUrl||REPORT_LOGO_DATA_URI;
 const note=paymentReceiptVisibleNote(r);
 const unit=r.unit?finUnitLabel(r.unit):'—';
 const fields=[['الوحدة',unit],['البند',r.chargeTitle||'تحصيل'],['طريقة الدفع',r.method||'نقدي'],['تاريخ الدفع',paymentReceiptDate(r)]];
 return `<article class="report-paper tower-receipt-paper" dir="rtl" lang="ar"><header class="report-head"><div class="report-brand"><img class="report-logo-img" src="${esc(logo)}" onerror="this.onerror=null;this.src='${REPORT_LOGO_DATA_URI}'" alt="Tower App" width="40" height="40"><div><strong>${esc(building)}</strong>${building!=='Tower App'?'<span>Tower App</span>':''}</div></div><div class="report-title"><h2>إيصال دفعة</h2><p>${r.paymentId?'مرجع الإيصال: '+esc(paymentReceiptReference(r)):'دفعة مسجلة'}</p></div></header><main><div class="tower-receipt-amount"><span>المبلغ المدفوع</span><strong>${esc(money(r.amount))}</strong></div><section class="report-section"><h3>بيانات الدفعة</h3><div class="tower-receipt-fields">${fields.map(([k,v])=>`<div class="tower-receipt-field"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('')}</div></section>${note?`<section class="tower-receipt-note"><span>ملاحظات</span><p>${esc(note)}</p></section>`:''}</main><footer class="report-footer"><span>© ${new Date().getFullYear()} Islam Sallam. All rights reserved.</span><span>Tower App V${esc(APP.ctx?.version||APP_VERSION)}</span></footer></article>`;
}
function paymentReceiptCss(){return reportStandaloneCss()+`
/* A5 receipt: compact, single purpose, branded like other Tower App reports. */
@page{size:A5 portrait;margin:8mm}
html,body{height:auto;min-height:0}
body{padding:8mm}
.tower-receipt-paper{width:100%;max-width:132mm;margin:0 auto;padding:0;background:#fff;min-height:0;height:auto;border:0;border-radius:0;box-shadow:none}
.tower-receipt-paper .report-head{padding-bottom:9px;border-bottom-width:2px}
.tower-receipt-paper .report-brand{gap:8px}
.tower-receipt-paper .report-logo-img{width:40px;height:40px}
.tower-receipt-paper .report-brand strong{font-size:15px}
.tower-receipt-paper .report-title{margin-top:9px;padding:10px 12px;border-radius:10px}
.tower-receipt-paper .report-title h2{font-size:17px}
.tower-receipt-paper .report-title p{font-size:10px}
.tower-receipt-amount{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:12px 0 10px;background:#eef6ff;border:1px solid #b8d5f2;border-radius:11px;padding:10px 12px}
.tower-receipt-amount span{font-size:11px;color:#53677f}
.tower-receipt-amount strong{color:#011b45;font-size:23px;line-height:1.4;white-space:nowrap}
.tower-receipt-paper .report-section{margin-top:8px}
.tower-receipt-paper .report-section h3{margin-bottom:7px;font-size:11px}
.tower-receipt-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
.tower-receipt-field{background:#fff;border:1px solid #d9e3ed;border-radius:9px;padding:9px 10px;min-height:54px;overflow-wrap:anywhere;break-inside:avoid}
.tower-receipt-field span,.tower-receipt-note span{display:block;color:#708198;font-size:9px;margin-bottom:4px}
.tower-receipt-field strong{display:block;color:#132033;font-size:12px;line-height:1.65}
.tower-receipt-note{border:1px solid #d9e3ed;border-radius:9px;padding:9px 10px;margin-top:8px;break-inside:avoid}
.tower-receipt-note p{font-size:11px;line-height:1.7;margin:0;overflow-wrap:anywhere}
.tower-receipt-paper .report-footer{margin-top:13px;padding-top:7px;font-size:8px}
@media print{html,body{width:auto!important;height:auto!important;min-height:0!important}body{padding:0!important}.tower-receipt-paper{max-width:none!important}.tower-receipt-field,.tower-receipt-amount{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
`;}
function paymentReceiptFullHtml(r,autoPrint=false){return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>إيصال دفعة ${esc(paymentReceiptReference(r))}</title><style>${paymentReceiptCss()}</style></head><body>${paymentReceiptDocument(r)}${autoPrint?'<script>window.onload=async function(){if(document.fonts&&document.fonts.ready)await document.fonts.ready;await Promise.all(Array.from(document.images).map(i=>i.complete?Promise.resolve():new Promise(resolve=>{i.onload=resolve;i.onerror=resolve;})));window.print()}<\/script>':''}</body></html>`;}
function printPaymentReceipt(){
 const r=window.LAST_PAYMENT_RECEIPT;if(!r)return;
 const w=window.open('','_blank');if(!w){toast('المتصفح منع فتح نافذة الطباعة. اسمح بالنوافذ المنبثقة وحاول مرة أخرى.','error');return;}
 w.document.open();w.document.write(paymentReceiptFullHtml(r,true));w.document.close();
}
async function paymentReceiptPdfBlob(r){
 if(!(await ensurePdfLibs()))throw new Error('مكتبة PDF غير متاحة.');
 const host=document.createElement('div');host.setAttribute('aria-hidden','true');host.style.cssText='position:fixed;top:0;left:-12000px;width:560px;background:#fff;color:#132033;direction:rtl;z-index:-1;padding:24px;';
 host.innerHTML=`<style>${paymentReceiptCss()}</style>${paymentReceiptDocument(r)}`;document.body.appendChild(host);
 try{
  if(document.fonts&&document.fonts.ready)await document.fonts.ready;
  await Promise.all(Array.from(host.querySelectorAll('img')).map(i=>i.complete?Promise.resolve():new Promise(resolve=>{i.onload=resolve;i.onerror=resolve;})));
  const paper=host.querySelector('.tower-receipt-paper');const canvas=await html2canvas(paper,{scale:2,useCORS:true,backgroundColor:'#fff',logging:false,windowWidth:560});
  const {jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'p',unit:'mm',format:'a5'}),imgWidth=132,imgHeight=canvas.height*132/canvas.width;
  if(!Number.isFinite(imgHeight)||imgHeight<=0)throw Error('PDF_INVALID_CANVAS_DIMENSIONS');
  if(imgHeight>194)throw Error('بيانات الإيصال أطول من صفحة A5. يرجى تقصير الملاحظات أو استخدام الطباعة.');
  pdf.addImage(canvas.toDataURL('image/jpeg',0.95),'JPEG',8,8,imgWidth,imgHeight,undefined,'FAST');return pdf.output('blob');
 }finally{host.remove();}
}
function paymentReceiptPdfName(r){return 'Tower_App_Receipt_'+(paymentReceiptReference(r)||cairoDateStamp())+'.pdf';}
async function downloadPaymentReceiptPdf(){try{const r=window.LAST_PAYMENT_RECEIPT;if(!r)return;const blob=await paymentReceiptPdfBlob(r);await downloadBlobSafe(blob,paymentReceiptPdfName(r));toast('تم تجهيز ملف الإيصال PDF.','success');}catch(e){toast('تعذر تجهيز PDF: '+errText(e),'error');}}
async function sharePaymentReceiptPdf(){try{const r=window.LAST_PAYMENT_RECEIPT;if(!r)return;const blob=await paymentReceiptPdfBlob(r),file=typeof File==='function'?new File([blob],paymentReceiptPdfName(r),{type:'application/pdf'}):null;
 if(file&&navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title:'إيصال دفعة',files:[file]});return;}
 await downloadBlobSafe(blob,paymentReceiptPdfName(r));toast('مشاركة ملفات PDF مش مدعومة على الجهاز؛ تم تنزيل الإيصال علشان تشاركه بنفسك.','warning');
 }catch(e){if(e?.name==='AbortError')return;toast('تعذر مشاركة الإيصال: '+errText(e),'error');}}
function openPaymentReceipt(r){window.LAST_PAYMENT_RECEIPT=r;openModal(`<div class="modal-head"><div><h3>إيصال دفعة</h3><p>${r.unit?finUnitLabel(r.unit):''}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-actions receipt-actions"><button class="icon-action" onclick="copyTextValue(paymentReceiptText(window.LAST_PAYMENT_RECEIPT),'تم نسخ الإيصال.')">${actionIcon('copy')}<span>نسخ</span></button><button class="icon-action" onclick="printPaymentReceipt()">${actionIcon('printer')}<span>طباعة</span></button><button class="icon-action" onclick="sharePaymentReceiptPdf()">${actionIcon('share')}<span>مشاركة</span></button><button class="icon-action" onclick="downloadPaymentReceiptPdf()">${actionIcon('report')}<span>PDF</span></button>${r.paymentId?`<button class="icon-action" onclick="openPaymentAttachments('${esc(r.paymentId)}')">${actionIcon('attachment')}<span>المرفقات</span></button>`:''}</div><div class="settlement-summary"><div><span>البند</span><strong>${esc(r.chargeTitle||'تحصيل')}</strong></div><div><span>المبلغ</span><strong>${money(r.amount)}</strong></div><div><span>طريقة الدفع</span><strong>${esc(r.method||'نقدي')}</strong></div><div><span>التاريخ</span><strong>${esc(paymentReceiptDate(r))}</strong></div></div>${r.note?`<div class="state-card"><span>${esc(r.note)}</span></div>`:''}${r.paymentId?`<div class="receipt-short-ref">مرجع الإيصال: ${esc(paymentReceiptReference(r))}</div>`:''}`);}
function openPaymentReceiptById(id){const p=(FIN_UI.data.payments||[]).find(x=>x.paymentId===id);if(!p)return;const c=(FIN_UI.data.charges||[]).find(x=>x.chargeId===p.chargeId);openPaymentReceipt({paymentId:p.paymentId,unit:p.unit,chargeTitle:c?c.title:'تحصيل',amount:p.amount,method:p.method,note:p.note,paidAt:p.paidAt,attachmentCount:p.attachmentCount});}
function fileAsDataUrl(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(new Error('تعذر قراءة الملف.'));r.readAsDataURL(file);});}
// Download helper for browsers/webviews where URL.createObjectURL is unavailable.
// Keep the blob content intact; never round, transform, or upload financial documents.
function downloadBlobSafe(blob,fileName){
 return new Promise((resolve,reject)=>{
  const a=document.createElement('a');a.download=fileName||'download';
  const objectUrlApi=typeof URL!=='undefined'&&typeof URL.createObjectURL==='function';
  const finish=(href,isObjectUrl)=>{
   a.href=href;document.body.appendChild(a);
   try{a.click();resolve();}catch(e){reject(e);}
   finally{setTimeout(()=>{if(isObjectUrl&&typeof URL.revokeObjectURL==='function')URL.revokeObjectURL(href);a.remove();},30000);}
  };
  if(objectUrlApi){try{return finish(URL.createObjectURL(blob),true);}catch(e){/* fall through to data URL */}}
  if(typeof FileReader==='undefined'){reject(new Error('المتصفح لا يدعم تنزيل الملفات.'));return;}
  const reader=new FileReader();
  reader.onload=()=>finish(String(reader.result||''),false);
  reader.onerror=()=>reject(new Error('تعذر تجهيز الملف للتنزيل.'));
  reader.readAsDataURL(blob);
 });
}
async function viewPrivatePaymentAttachment(attachmentId){
 try{
  const r=await run('readPaymentAttachment',attachmentId);
  if(!r||!r.dataUrl||!['image/jpeg','image/png','image/webp','application/pdf'].includes(r.mimeType))throw Error('نوع ملف غير مسموح.');
  const resp=await fetch(r.dataUrl);const blob=await resp.blob();
  await downloadBlobSafe(blob,r.fileName||'payment-proof');
 }catch(e){toast(errText(e),'error');}
}
async function openPaymentAttachments(id){try{const rows=await run('getPaymentAttachments',id);openModal(`<div class="modal-head"><div><h3>إثباتات الدفع</h3><p>${rows.length} مرفق</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>${rows.length?`<div class="list-stack">${rows.map(x=>`<button type="button" class="data-card record-card" onclick="viewPrivatePaymentAttachment('${esc(x.attachmentId)}')"><div class="data-main"><strong>${esc(x.fileName)}</strong><span class="badge">فتح</span></div><div class="data-meta"><span>${esc(x.mimeType)}</span><span>${esc(displayDateTime12(x.createdAt))}</span></div></button>`).join('')}</div>`:emptyState('لا توجد مرفقات','')}`);}catch(e){toast(errText(e),'error');}}
async function openFinancialAudit(id){try{const x=await run('getActivityDetails',id);openModal(`<div class="modal-head"><div><h3>تفاصيل المراجعة المالية</h3><p>${esc(displayDateTime12(x.timestamp))} · ${esc(activityRoleLabel(x.role))}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-grid"><div><span>العملية</span><strong>${esc(activityActionLabel(x.action))}</strong></div><div><span>من نفّذ العملية</span><strong>${esc(activityActorLabel(x))}</strong></div><div><span>موضوع العملية</span><strong>${esc(activityContextLabel(x))}</strong></div><div><span>ملاحظات</span><strong>${esc(x.notes||'—')}</strong></div></div><details class="system-diag-note"><summary>التفاصيل التقنية</summary><p>${esc(x.entity||'')} · ${esc(x.entityId||'')} · ${esc(x.actorUserId||'')}</p></details><p class="system-diag-note">قد لا تحتفظ بعض العمليات القديمة بقيم قبل وبعد؛ لا تُعرض قيم غير مسجّلة.</p>${x.before!=null&&String(x.before).trim()?`<details class="json-details"><summary>قبل العملية (بيانات مسجّلة)</summary><pre>${esc(typeof x.before==='string'?x.before:JSON.stringify(x.before,null,2))}</pre></details>`:''}${x.after!=null&&String(x.after).trim()?`<details class="json-details"><summary>بعد العملية (بيانات مسجّلة)</summary><pre>${esc(typeof x.after==='string'?x.after:JSON.stringify(x.after,null,2))}</pre></details>`:''}`);}catch(e){toast(errText(e),'error');}}
const UNIT_STATEMENT_UI={current:null};
function statementReportData(d){
 const u=d.unit||{},manager=((FIN_UI.data?.units||[]).find(x=>String(x.unitId)===String(u.unitId))||{}).managerName||u.managerName||'المدير غير متاح';
 const unitLabel=`شقة ${unitNo(u.unitNumber||'—')} · الدور ${floorNo(u.floor||'—')} · ${manager}`;
 const rows=Array.isArray(d.rows)?d.rows:[];
 const due=Number(d.totalDue||0),paid=Number(d.totalPaid||0);
 const fmt=x=>money(x);
 return {title:'كشف حساب الوحدة',subtitle:unitLabel,building:{name:(APP.ctx?.building?.name)||'Tower App'},generatedAt:displayDateTime12(new Date()),generatedBy:APP.ctx?.user?.displayName||APP.ctx?.user?.name||'',sections:[
  {type:'stats',items:[{label:'المتبقي من استحقاقات العمارة',value:fmt(due),emphasis:true},{label:'إجمالي الدفعات المسجلة',value:fmt(paid)},{label:'عدد الاستحقاقات',value:String(rows.length)}]},
  {type:'note',text:'المتبقي محسوب بالفعل بعد خصم المسدد من كل استحقاق؛ لا يُخصم إجمالي الدفعات مرة ثانية. كشف الحساب خاص باستحقاقات العمارة فقط ولا يشمل حساب الحارس.'},
  {type:'table',title:'تفاصيل استحقاقات الوحدة',columns:[{label:'الاستحقاق'},{label:'الفئة / التاريخ'},{label:'الأصل'},{label:'المسدد'},{label:'المتبقي'}],rows:rows.map(r=>[r.title||'',`${r.category||''} · ${r.dueDate||''}`,fmt(r.amount),fmt(r.paid),fmt(r.remaining)])}
 ],footer:'كشف حساب معلوماتي صادر من Tower App — لا يمثل إيصال سداد.'};
}
function statementText(){return UNIT_STATEMENT_UI.current?reportText(statementReportData(UNIT_STATEMENT_UI.current)):'';}
async function copyUnitStatement(){if(!UNIT_STATEMENT_UI.current)return;await copyTextValue(statementText(),'تم نسخ كشف الحساب.');}
async function shareUnitStatement(){if(!UNIT_STATEMENT_UI.current)return;await shareTextValue('كشف حساب الوحدة',statementText());}
async function statementPdfBlob(){
 const d=UNIT_STATEMENT_UI.current;
 if(!d)throw Error('NO_STATEMENT');
 // The unit statement uses the same document schema and paginated A4 renderer
 // as the building reports. Do not slice a single tall canvas through rows.
 return buildCurrentPdfBlob(statementReportData(d));
}

async function downloadUnitStatementPdf(){try{const blob=await statementPdfBlob(),u=UNIT_STATEMENT_UI.current.unit||{};await downloadBlobSafe(blob,`Tower_Unit_${String(u.unitNumber||'statement').replace(/[^\w\u0600-\u06FF-]/g,'_')}_${cairoDateStamp()}.pdf`);toast('تم تجهيز كشف الحساب PDF.');}catch(e){toast(errText(e),'error');}}
function unitStatementModalHtml(d){
 const u=d.unit||{},manager=((FIN_UI.data?.units||[]).find(x=>String(x.unitId)===String(u.unitId))||{}).managerName||u.managerName;
 const rows=Array.isArray(d.rows)?d.rows:[];
 const totalOriginal=rows.reduce((sum,r)=>sum+Number(r.amount||0),0);
 return `<div class="unit-statement" dir="rtl"><div class="modal-head statement-header"><div><h3>كشف حساب الوحدة</h3><p>${esc(finUnitLabel({...u,managerName:manager}))}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><div class="statement-actions" aria-label="إجراءات كشف الحساب"><button class="btn-sm primary" onclick="printUnitStatement()">طباعة</button><button class="btn-sm" onclick="downloadUnitStatementPdf()">PDF</button><button class="btn-sm" onclick="shareUnitStatement()">مشاركة</button><button class="btn-sm" onclick="copyUnitStatement()">نسخ</button></div><div class="statement-summary"><div class="statement-total"><span>المتبقي</span><strong>${money(d.totalDue)}</strong></div><div class="statement-stat"><span>إجمالي المستحقات</span><strong>${money(totalOriginal)}</strong></div><div class="statement-stat"><span>إجمالي الدفعات المسجلة</span><strong>${money(d.totalPaid)}</strong></div></div><p class="statement-note">المتبقي بعد خصم المسدد من كل استحقاق، ويخص استحقاقات العمارة فقط.</p><div class="statement-section-head"><h4>تفاصيل الاستحقاقات</h4><span>${rows.length} استحقاق</span></div><div class="statement-entries">${rows.length?rows.map(r=>`<article class="statement-entry"><div class="statement-entry-top"><div><strong>${esc(r.title||'استحقاق')}</strong><small>${esc([r.category,r.dueDate].filter(Boolean).join(' · '))}</small></div><div class="statement-entry-balance"><span>المتبقي</span><strong>${money(r.remaining)}</strong></div></div><div class="statement-entry-bottom"><span>المستحق: <b>${money(r.amount)}</b></span><span>المسدد: <b>${money(r.paid)}</b></span></div></article>`).join(''):'<p class="statement-empty">لا توجد استحقاقات مسجلة لهذه الوحدة.</p>'}</div></div>`;
}
function printUnitStatement(){
 const d=UNIT_STATEMENT_UI.current;if(!d){toast('افتح كشف حساب الوحدة أولًا.','error');return;}
 const w=window.open('','_blank');if(!w){toast('اسمح بفتح نافذة الطباعة من المتصفح.','error');return;}
 const html=reportDocumentHtml(statementReportData(d));
 w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>كشف حساب الوحدة</title><link rel="stylesheet" href="/styles.css?v=${esc(APP_VERSION)}"><style>:root{color-scheme:light!important}html,body{margin:0;background:#fff!important;color:#172536!important}body{padding:12mm;font-family:Arial,Tahoma,sans-serif}.report-paper{width:100%!important;max-width:none!important;margin:0!important;box-shadow:none!important;background:#fff!important;color:#172536!important}.report-paper *{color:#172536!important}.report-paper .report-footer{color:#536174!important}thead{display:table-header-group}tr{break-inside:avoid-page}@page{size:A4;margin:10mm}@media print{body{padding:0}html,body,.report-paper{background:#fff!important;print-color-adjust:exact;-webkit-print-color-adjust:exact}}</style></head><body>${html}<script>window.addEventListener('load',function(){Promise.resolve(document.fonts&&document.fonts.ready).then(function(){setTimeout(function(){window.print()},250)})});<\/script></body></html>`);w.document.close();
}
async function openUnitStatement(unitId){try{const d=await run('getUnitBuildingStatement',unitId);UNIT_STATEMENT_UI.current=d;openModal(unitStatementModalHtml(d),true);}catch(e){toast(errText(e),'error');}}

function openFinanceModal(type='INCOME'){openModal(`<div class="modal-head"><div><h3>${type==='EXPENSE'?'تسجيل مصروف':'إيداع بالصندوق'}</h3><p>${type==='EXPENSE'?'سيُخصم من الرصيد الفعلي للصندوق.':'حركة مالية مستقلة عن مستحقات الوحدات.'}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="submitFinance(event,'${type}')"><label class="field"><span>المبلغ</span><input id="finAmount" type="number" min="0.01" step="0.01" required></label><label class="field"><span>التصنيف</span><input id="finCategory" placeholder="${type==='EXPENSE'?'صيانة':'إيداع'}"></label><label class="field span-2"><span>البيان</span><input id="finDescription" required></label><label class="field span-2"><span>المرجع / ملاحظة</span><input id="finReference"></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);}
async function submitFinance(e,type){e.preventDefault();const form=e.target,p={entryType:type,amount:form.querySelector('#finAmount')?.value,category:form.querySelector('#finCategory')?.value||'',reference:form.querySelector('#finReference')?.value||'',description:form.querySelector('#finDescription')?.value||''};beginBackgroundSave();try{await run('addFinanceEntry',p);closeModal();await refreshFinanceSilent('fund');toast('تم تحديث الصندوق.');}catch(x){toast(errText(x),'error');}finally{endBackgroundSave();}}
async function cancelFinance(id){const reason=await promptAction({title:'إلغاء الحركة المالية',message:'سيظل أصل الحركة محفوظًا في السجل.',label:'سبب الإلغاء',confirmLabel:'إلغاء الحركة'});if(!reason)return;beginBackgroundSave();try{await run('cancelFinanceEntry',id,reason);FIN_UI.data=await run('getFinanceContext');renderFinanceBody();toast('تم إلغاء الحركة مع الاحتفاظ بها في السجل.');}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
const ACTIVITY_UI={rows:[],term:'',category:'ALL',page:0,hasMore:false,loading:false,searchSeq:0};
function activityCategory(row){const t=String(row.action||'')+' '+String(row.entity||'');if(/financ|payment|fund|charge|collect|expense|deposit|cash|settle|مالي|دفع|صندوق|تحصيل/i.test(t))return 'FINANCE';if(/unit|member|user|resident|pin|login|registration|وحدة|عضو|مستخدم/i.test(t))return 'PEOPLE';if(/service|subscription|خدم|اشتراك/i.test(t))return 'SERVICE';return 'OTHER';}
function activityActionLabel(action){const a=String(action||'').toUpperCase();const labels={EDIT_SERVICE_DETAILS_230:'تعديل تفاصيل خدمة أو مهمة',CREATE_BUILDING_CHARGE:'إنشاء استحقاق',RECORD_BUILDING_PAYMENT:'تسجيل دفعة',CREATE_FINANCE_ENTRY:'تسجيل حركة مالية',CANCEL_FINANCE_ENTRY:'إلغاء حركة مالية',APPROVE_COLLECTION_REPORT:'اعتماد تقرير تحصيل',ADD_PAYMENT_ATTACHMENT:'إضافة مرفق دفعة',LOGIN:'تسجيل دخول',UNIT_MANAGER_TRANSFER:'نقل إدارة وحدة',REQUEST_SERVICE_SUBSCRIPTION:'طلب اشتراك خدمة',UPDATE_USER:'تعديل مستخدم',UPDATE_MEMBER:'تعديل عضو',SERVICE_SUBSCRIPTION_REQUEST:'طلب اشتراك خدمة'};return labels[a]||String(action||'عملية غير محددة').replace(/_/g,' ');}
function activityRoleLabel(role){return ({ADMIN:'إدارة النظام',UNION:'الاتحاد',RESIDENT:'ساكن',OPERATOR:'الحارس'})[String(role||'').toUpperCase()]||'';}
function activityContextLabel(x){const unit=String(x.unitNumber||'').trim(),id=String(x.unitId||'').trim();if(unit)return 'الوحدة '+unit;if(id)return 'عملية مرتبطة بوحدة';return ({USER:'حساب مستخدم',UNIT:'وحدة سكنية',SERVICE_SUBSCRIPTION:'اشتراك خدمة',SESSION:'جلسة دخول',TRIP:'مشوار',BUILDING_PAYMENT:'دفعة مالية'})[String(x.entity||'').toUpperCase()]||'عملية بالنظام';}
function activityActorLabel(x){return [x.actorDisplayName||'مستخدم غير معروف',activityRoleLabel(x.role),x.unitNumber?'الوحدة '+x.unitNumber:''].filter(Boolean).join(' · ');}
function activityExportText(){const rows=activityVisibleRows();return ['Tower App — سجل النشاط (صفحات البحث المحمّلة)','تاريخ التصدير: '+displayDateTime12(new Date()),'عدد العمليات: '+rows.length,'التصدير يشمل الصفحات المحمّلة حاليًا فقط.','',...rows.map(x=>[displayDateTime12(x.timestamp),activityActionLabel(x.action),x.actorDisplayName||x.actorUserId||'غير معروف',x.entity||'',x.entityId||''].join(' | '))].join('\n');}
async function activityCopyVisible(){await copyTextValue(activityExportText(),'تم نسخ سجل النشاط المعروض.');}
function activityItemText(x){return [activityActionLabel(x.action),activityContextLabel(x),displayDateTime12(x.timestamp),activityActorLabel(x),x.notes||''].filter(Boolean).join(' | ');}
async function activityCopyItem(id){const x=ACTIVITY_UI.rows.find(x=>String(x.auditId)===String(id));if(!x){toast('السجل غير متاح حاليًا.','error');return;}await copyTextValue(activityItemText(x),'تم نسخ النشاط.');}

// One source of truth for the loaded activity rows displayed and copied.
// The database continues to enforce the server-side search and role permissions.
function activityVisibleRows(){const tokens=normAr(ACTIVITY_UI.term||'').trim().split(/\s+/).filter(Boolean);return ACTIVITY_UI.rows.filter(x=>{if(ACTIVITY_UI.category!=='ALL'&&activityCategory(x)!==ACTIVITY_UI.category)return false;const hay=normAr([x.action,activityActionLabel(x.action),x.entity,x.entityId,x.actorUserId,x.actorDisplayName,x.unitId,x.unitNumber,activityRoleLabel(x.role),activityContextLabel(x)].filter(Boolean).join(' '));return tokens.every(t=>hay.includes(t));});}
function resetActivityFilters(){const input=$('activitySearch'),select=$('activityCategory');if(input)input.value='';if(select)select.value='ALL';activitySetFilter();input?.focus();}
function activityRenderList(){const host=$('activityResults');if(!host)return;const rows=activityVisibleRows();host.innerHTML=`<div class="activity-summary">يظهر ${rows.length} من ${ACTIVITY_UI.rows.length} سجل محمّل من نتائج البحث. ${ACTIVITY_UI.hasMore?'توجد صفحات أقدم.':'لا توجد صفحات إضافية.'} التصنيف يطبق على الصفحات المحمّلة.</div>${rows.length?`<div class="list-stack activity-list">${rows.map(x=>`<div class="activity-copy-row"><button class="activity-row" onclick="openActivity('${esc(x.auditId)}')"><div><strong>${esc(activityActionLabel(x.action))}</strong><span>${esc(activityContextLabel(x))}</span></div><div><span>${esc(displayDateTime12(x.timestamp))}</span><small>${esc(activityActorLabel(x))}</small></div></button><button class="btn-sm activity-copy-item" type="button" aria-label="نسخ النشاط" title="نسخ النشاط" onclick="activityCopyItem('${esc(x.auditId)}')">⧉ نسخ</button></div>`).join('')}</div>`:emptyState('لا توجد عمليات مطابقة','جرّب تغيير البحث أو التصنيف.')}${ACTIVITY_UI.hasMore?`<div class="section-actions"><button class="btn-sm" type="button" onclick="activityLoadPage(true)" ${ACTIVITY_UI.loading?'disabled':''}>${ACTIVITY_UI.loading?'جاري التحميل…':'تحميل سجلات أقدم'}</button></div>`:''}`;}
function activitySetFilter(){ACTIVITY_UI.term=$('activitySearch')?.value||'';ACTIVITY_UI.category=$('activityCategory')?.value||'ALL';const clear=$('activityClearFilters');if(clear)clear.disabled=!(ACTIVITY_UI.term.trim()||ACTIVITY_UI.category!=='ALL');activityRenderList();clearTimeout(ACTIVITY_UI.debounce);ACTIVITY_UI.debounce=setTimeout(()=>activityLoadPage(false),350);}
async function activityLoadPage(more=false){if(more&&(!ACTIVITY_UI.hasMore||ACTIVITY_UI.loading))return;const seq=++ACTIVITY_UI.searchSeq;const page=more?ACTIVITY_UI.page+1:0;ACTIVITY_UI.loading=true;if(!more)ACTIVITY_UI.rows=[];activityRenderList();try{const data=await run('searchActivityFeed',{term:ACTIVITY_UI.term,page});if(seq!==ACTIVITY_UI.searchSeq)return;ACTIVITY_UI.rows=more?[...ACTIVITY_UI.rows,...(data.rows||[])]:data.rows||[];ACTIVITY_UI.page=page;ACTIVITY_UI.hasMore=Boolean(data.hasMore);}catch(e){if(seq===ACTIVITY_UI.searchSeq){toast(errText(e),'error');const host=$('activityResults');if(host&&!ACTIVITY_UI.rows.length)host.innerHTML=errorCard(e);}}finally{if(seq===ACTIVITY_UI.searchSeq){ACTIVITY_UI.loading=false;activityRenderList();}}}
async function renderActivity(){clearTimeout(ACTIVITY_UI.debounce);const c=$('content');c.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>سجل النشاط</h3><p>بحث في سجل العمليات على مستوى قاعدة البيانات، مع تحميل السجلات الأقدم تدريجيًا.</p></div></div><div class="activity-toolbar"><label class="field"><span>بحث في كل السجلات</span><input id="activitySearch" type="search" placeholder="نوع العملية أو اسم المستخدم أو الكيان" oninput="activitySetFilter()"></label><label class="field"><span>تصنيف النتائج المحمّلة</span><select id="activityCategory" onchange="activitySetFilter()"><option value="ALL">كل العمليات</option><option value="FINANCE">مالية وتحصيل</option><option value="PEOPLE">مستخدمون ووحدات</option><option value="SERVICE">خدمات</option><option value="OTHER">أخرى</option></select></label></div><div class="section-actions activity-list-actions"><button type="button" class="btn-sm" id="activityClearFilters" onclick="resetActivityFilters()" disabled>مسح البحث والفلاتر</button><button type="button" class="btn-sm" onclick="activityCopyVisible()">نسخ النتائج الظاهرة</button><button type="button" class="btn-sm" onclick="activityLoadPage(false)">تحديث السجل</button></div><div id="activityResults" aria-live="polite"></div></section>`;ACTIVITY_UI.rows=[];ACTIVITY_UI.term='';ACTIVITY_UI.category='ALL';ACTIVITY_UI.page=0;ACTIVITY_UI.hasMore=false;await activityLoadPage(false);setupAdminSectionNavigation();}
function copyActivityDetailCurrent(){if(window.ACTIVITY_DETAIL_CURRENT)return copyTextValue(activityItemText(window.ACTIVITY_DETAIL_CURRENT),'تم نسخ تفاصيل النشاط.');}
async function openActivity(id){try{const x=await run('getActivityDetails',id);window.ACTIVITY_DETAIL_CURRENT=x;openModal(`<div class="modal-head"><div><h3>${esc(activityActionLabel(x.action))}</h3><p>${esc(displayDateTime12(x.timestamp))} · ${esc(x.role||'')}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="form-actions"><button type="button" class="btn-sm" id="copyActivityDetail" onclick="copyActivityDetailCurrent()">⧉ نسخ النشاط</button></div><div class="detail-grid"><div><span>موضوع العملية</span><strong>${esc(activityContextLabel(x))}</strong></div><div><span>المستخدم</span><strong>${esc(x.actorDisplayName||'مستخدم غير معروف')} </strong></div><div><span>الوحدة</span><strong>${esc(x.unitNumber?'وحدة '+x.unitNumber:(x.unitId?'مرتبطة بوحدة':'—'))}</strong></div><div><span>ملاحظات</span><strong>${esc(x.notes||'—')}</strong></div></div><details class="system-diag-note"><summary>التفاصيل التقنية</summary><p>${esc(x.entity||'')} · ${esc(x.entityId||'')} ${esc(x.unitId||'')}</p></details><p class="system-diag-note">قيم قبل وبعد تظهر فقط إذا كان مصدر السجل قد احتفظ بها بالفعل.</p>${x.before!=null&&String(x.before).trim()?`<details class="json-details"><summary>قبل العملية (بيانات مسجّلة)</summary><pre>${esc(typeof x.before==='string'?x.before:JSON.stringify(x.before,null,2))}</pre></details>`:''}${x.after!=null&&String(x.after).trim()?`<details class="json-details"><summary>بعد العملية (بيانات مسجّلة)</summary><pre>${esc(typeof x.after==='string'?x.after:JSON.stringify(x.after,null,2))}</pre></details>`:''}`);}catch(e){toast(errText(e),'error');}}



const COL_UI={data:null,lines:new Map()};
function colStatus(v){return({DRAFT:'مسودة',PENDING_APPROVAL:'بانتظار الاعتماد',NEEDS_CHANGES:'يحتاج تعديل',APPROVED:'معتمد',REJECTED:'مرفوض'})[v]||v;}
async function renderCollections(){const c=$('content');c.innerHTML=pageLoading('جاري تحميل التحصيل…');try{COL_UI.data=await run('getCollectionContext');COL_UI.lines=new Map();const pending=(COL_UI.data.reports||[]).filter(r=>r.status==='PENDING_APPROVAL'),history=(COL_UI.data.reports||[]).filter(r=>r.status!=='PENDING_APPROVAL');c.innerHTML=`<section id="personalCollectionDues" class="panel" aria-live="polite">جاري تحميل مستحقات الخدمات والمهمات…</section><section class="collection-dashboard-strip" aria-label="ملخص تقارير التحصيل"><div class="stat"><span>بانتظار الاعتماد</span><strong>${pending.length}</strong></div><div class="stat"><span>التقارير السابقة</span><strong>${history.length}</strong></div></section>${COL_UI.data.canApprove?`<section class="panel priority-panel"><div class="panel-head"><div><h3>تقارير بانتظار الاعتماد</h3><p>راجع التقارير المرسلة واعتمدها قبل تسجيلها في الصندوق.</p></div><span class="badge attention">${pending.length}</span></div>${pending.length?`<div class="list-stack">${pending.map(collectionReportRow).join('')}</div>`:emptyState('لا توجد تقارير بانتظار الاعتماد','')}</section>`:''}${COL_UI.data.canCollect?`<section class="panel"><div class="panel-head"><div><h3>تقرير تحصيل جديد</h3><p>${COL_UI.data.isUnionCollector?'سجّل ما استلمته فعليًا؛ سيتم الاعتماد والتسجيل في الصندوق مباشرة.':'سجّل ما استلمته فعليًا؛ لن يدخل الصندوق إلا بعد اعتماد التقرير.'}</p></div><span class="badge">${COL_UI.data.units.length} وحدة</span></div><div class="section-actions collection-collapse-actions"><button class="icon-action text-action" onclick="setAllCollectionUnits(true)">⌄<span>فرد الكل</span></button><button class="icon-action text-action" onclick="setAllCollectionUnits(false)">⌃<span>طي الكل</span></button></div><div class="list-stack">${COL_UI.data.units.map(collectionUnitRow).join('')}</div><div class="form-actions"><button class="btn-sm primary" onclick="submitNewCollectionReport()">${COL_UI.data.isUnionCollector?'تسجيل التحصيل واعتماده':'إرسال التقرير للاعتماد'}</button></div></section>`:''}<section class="panel"><div class="panel-head"><div><h3>${COL_UI.data.canApprove?'سجل تقارير التحصيل':'تقارير التحصيل'}</h3><p>${COL_UI.data.canApprove?'التقارير السابقة والمعتمدة والمرفوضة.':'تابع حالة تقاريرك.'}</p></div><span class="badge">${history.length}</span></div>${history.length?`<div class="list-stack">${history.map(collectionReportRow).join('')}</div>`:emptyState('لا توجد تقارير سابقة','')}</section>`;await loadPersonalCollectionDues();}catch(e){c.innerHTML=errorCard(e);}}
function collectionUnitRow(u){const details=(u.items||[]).map(x=>`${esc(x.title)}: ${money(x.remaining)}`).join(' · ');return `<details class="data-card collection-unit collapsible-card" data-unit="${esc(u.unitId)}"><summary class="collection-unit-summary"><div class="collection-line-primary"><div class="collection-unit-id"><strong>وحدة ${esc(unitNo(u.unitNumber))}</strong><span>${esc(u.managerName||'المدير غير متاح')} · الدور ${esc(floorNo(u.floor||'—'))}</span></div><strong class="collection-total">${money(u.available)}</strong></div><div class="collection-line-secondary"><span>${details||'لا توجد بنود مفتوحة'}</span>${u.pendingReported>0?`<span class="badge muted">${money(u.pendingReported)} قيد الاعتماد</span>`:''}</div></summary>${u.available>0?`<div class="collapsible-body"><div class="collection-controls"><select onchange="collectionMode('${esc(u.unitId)}',this.value)"><option value="NONE">لم يتم التحصيل</option><option value="FULL">كامل</option><option value="PARTIAL">جزئي</option></select><input id="colAmt_${esc(u.unitId)}" type="number" min="0" max="${Number(u.available)}" step="0.01" placeholder="المبلغ" disabled><select id="colMethod_${esc(u.unitId)}"><option>نقدي</option><option>تحويل</option><option>إنستاباي</option><option>محفظة إلكترونية</option><option>أخرى</option></select></div></div>`:''}</details>`;}
function setAllCollectionUnits(open){document.querySelectorAll('.collection-unit').forEach(x=>x.open=!!open);}
function collectionMode(id,mode){const u=COL_UI.data.units.find(x=>x.unitId===id),inp=$('colAmt_'+id);if(!u||!inp)return;if(mode==='NONE'){inp.value='';inp.disabled=true;COL_UI.lines.delete(id);}else if(mode==='FULL'){inp.value=u.available;inp.disabled=true;COL_UI.lines.set(id,{unitId:id,amount:u.available});}else{inp.value='';inp.disabled=false;inp.focus();COL_UI.lines.set(id,{unitId:id,amount:0});}inp.oninput=()=>{const x=COL_UI.lines.get(id)||{unitId:id};x.amount=Math.min(Number(u.available),Math.max(0,Number(inp.value)||0));COL_UI.lines.set(id,x);};}
async function submitNewCollectionReport(){const lines=[];COL_UI.lines.forEach((x,id)=>{const amount=Number(($('colAmt_'+id)||{}).value||x.amount)||0;if(amount>0)lines.push({unitId:id,amount,method:($('colMethod_'+id)||{}).value||'نقدي'});});if(!lines.length){toast('حدد وحدة واحدة على الأقل تم التحصيل منها.','error');return;}const immediate=COL_UI.data?.isUnionCollector===true;const title=immediate?'تسجيل التحصيل واعتماده':'إرسال تقرير التحصيل';const message=immediate?`سيتم تسجيل تحصيل ${lines.length} وحدة واعتماده وإضافته للصندوق في عملية واحدة.`:`سيتم إرسال ${lines.length} وحدة للمراجعة، ولن تسجل ماليًا قبل الاعتماد.`;if(!await confirmAction({title,message,confirmLabel:immediate?'تسجيل واعتماد':'إرسال التقرير'}))return;beginBackgroundSave();try{if(immediate){const r=await run('createAndApproveUnionCollection',{lines});toast(`تم تسجيل واعتماد ${money(r.approvedTotal)} في الصندوق.`);}else{await run('createCollectionReport',{lines,submit:true});toast('تم إرسال تقرير التحصيل للاعتماد.');}await renderCollections();}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
function collectionReportRow(r){return `<button class="data-card service-card-clickable" onclick="openCollectionReport('${esc(r.reportId)}')"><div class="data-main"><div><strong>${esc(r.collectorName||'محصّل')}</strong><span>${esc(displayDateTime12(r.createdAt))} · ${r.lineCount} وحدة</span></div><strong>${money(r.totalReported)}</strong></div><div class="data-meta"><span class="badge ${r.status==='APPROVED'?'success':'muted'}">${esc(colStatus(r.status))}</span></div></button>`;}
async function openCollectionReport(id){try{const d=await run('getCollectionReport',id),r=d.report;window.COL_REPORT=d;const editable=!d.canApprove&&['DRAFT','NEEDS_CHANGES'].includes(r.status);const reviewable=d.canApprove&&r.status==='PENDING_APPROVAL';openModal(`<div class="modal-head"><div><h3>تقرير التحصيل</h3><p>${esc(r.reportId)} · ${esc(colStatus(r.status))}</p>${r.reviewNotes?`<p>${esc(r.reviewNotes)}</p>`:''}</div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="detail-actions collection-report-actions"><button class="icon-action" onclick="copyCollectionReport()">⧉<span>نسخ</span></button><button class="icon-action" onclick="printCollectionReport()">▣<span>طباعة</span></button><button class="icon-action" onclick="shareCollectionReport()">↗<span>مشاركة</span></button></div><div class="section-actions collection-collapse-actions"><button class="icon-action text-action" onclick="setAllReportLines(true)">⌄<span>فرد الكل</span></button><button class="icon-action text-action" onclick="setAllReportLines(false)">⌃<span>طي الكل</span></button></div><div class="list-stack">${d.lines.map(l=>`<details class="data-card collapsible-card collection-report-line"><summary><div class="data-main"><div><strong>وحدة ${esc(unitNo(l.unit&&l.unit.unitNumber||l.unitId))}</strong><span>${esc(l.unit&&l.unit.managerName||'')}</span></div><strong>${money(l.reportedAmount)}</strong></div></summary><div class="collapsible-body"><div class="data-meta">${(l.allocation||[]).map(a=>`<span>${esc(a.title)}: ${money(a.amount)}</span>`).join('')}<span>${esc(l.method)}</span></div>${editable?`<label class="field"><span>المبلغ المسجل</span><input class="col-edit-amount" data-line="${esc(l.lineId)}" type="number" min="0" max="${Number(l.current&&l.current.available||l.reportedAmount)}" step="0.01" value="${Number(l.reportedAmount)}"></label>`:''}${reviewable?`<div class="collection-review-row"><select class="col-review-decision" data-line="${esc(l.lineId)}"><option value="APPROVE">اعتماد السطر</option><option value="REJECT">رفض السطر</option></select><input class="col-review-amount" data-line="${esc(l.lineId)}" type="number" min="0" max="${Number(l.current&&l.current.available||l.reportedAmount)}" step="0.01" value="${Number(l.reportedAmount)}"></div>`:''}</div></details>`).join('')}</div>${editable?`<div class="form-actions"><button class="btn-sm primary" onclick="saveAndResubmitCollection('${esc(r.reportId)}')">حفظ وإعادة الإرسال</button></div>`:''}${reviewable?`<div class="form-actions"><button class="btn-sm primary" onclick="approveCollection('${esc(r.reportId)}')">اعتماد المحدد</button><button class="btn-sm" onclick="returnCollection('${esc(r.reportId)}')">إرجاع للتعديل</button></div>`:''}`,true);}catch(e){toast(errText(e),'error');}}
function setAllReportLines(open){document.querySelectorAll('.collection-report-line').forEach(x=>x.open=!!open);}

function collectionReportText(d){if(!d||!d.report)return '';const r=d.report,lines=d.lines||[];const rows=lines.map(l=>{const u=l.unit||{};const details=(l.allocation||[]).map(a=>`${a.title}: ${amountText(a.amount)} ج.م`).join('، ');return `وحدة ${unitNo(u.unitNumber||l.unitId)} — ${u.managerName||''}\nالمبلغ: ${amountText(l.reportedAmount)} ج.م — ${l.method||'نقدي'}${details?'\n'+details:''}`;});return [`تقرير التحصيل ${r.reportId||''}`,`الحالة: ${colStatus(r.status)}`,`المحصّل: ${r.collectorName||''}`,`التاريخ: ${r.createdAt||''}`,`الإجمالي: ${amountText(r.totalReported)} ج.م`,'',...rows].join('\n');}
function copyCollectionReport(){return copyTextValue(collectionReportText(window.COL_REPORT),'تم نسخ تقرير التحصيل.');}
async function shareCollectionReport(){return shareTextValue('تقرير التحصيل',collectionReportText(window.COL_REPORT));}
function printCollectionReport(){const d=window.COL_REPORT;if(!d||!d.report)return;const r=d.report,w=towerOpenPrintWindow();if(!w){toast('اسمح بفتح نافذة الطباعة.','error');return;}const rows=(d.lines||[]).map(l=>`<tr><td>وحدة ${esc(unitNo(l.unit&&l.unit.unitNumber||l.unitId))}</td><td>${esc(l.unit&&l.unit.managerName||'')}</td><td>${money(l.reportedAmount)}</td><td>${esc(l.method||'نقدي')}</td></tr>`).join('');w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير التحصيل ${esc(r.reportId||'')}</title><style>:root{color-scheme:light only}html,body{background:#fff!important;color:#111!important}body{font-family:Arial,sans-serif;padding:28px;color:#111}h1{font-size:22px}p{color:#555}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{padding:10px;border:1px solid #ddd;text-align:right;color:#111;background:#fff}th{background:#f5f5f5}.print-footer{margin-top:24px;padding-top:10px;border-top:1px solid #ddd;color:#555;font-size:11px;text-align:center}@media print{html,body{background:#fff!important;color:#111!important;print-color-adjust:exact;-webkit-print-color-adjust:exact}thead{display:table-header-group}tr{break-inside:avoid}}</style></head><body><h1>تقرير التحصيل ${esc(r.reportId||'')}</h1><p>${esc(r.collectorName||'')} · ${esc(displayDateTime12(r.createdAt))} · ${esc(colStatus(r.status))}</p><table><thead><tr><th>الوحدة</th><th>مدير الوحدة</th><th>المبلغ</th><th>طريقة الدفع</th></tr></thead><tbody>${rows}</tbody></table><footer class="print-footer">© Islam Sallam · Tower App V${esc(APP.ctx?.version||APP_VERSION)}</footer><script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`);w.document.close();}

async function saveAndResubmitCollection(id){const lines={};document.querySelectorAll('.col-edit-amount').forEach(x=>lines[x.dataset.line]=Number(x.value)||0);closeModal();beginBackgroundSave();try{await run('updateCollectionReport',id,{lines});await run('submitCollectionReport',id);toast('تم تحديث التقرير وإعادة إرساله.');await renderCollections();}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
async function approveCollection(id){if(!await confirmAction({title:'اعتماد تقرير التحصيل',message:'سيتم إعادة التحقق من المستحقات ثم تسجيل السطور المعتمدة فعليًا في الصندوق.',confirmLabel:'اعتماد'}))return;const lines={};document.querySelectorAll('.col-review-decision').forEach(x=>{const id=x.dataset.line,amt=document.querySelector(`.col-review-amount[data-line="${id}"]`);lines[id]={decision:x.value,amount:amt?Number(amt.value)||0:0};});closeModal();beginBackgroundSave();try{const r=await run('approveCollectionReport',id,{lines});toast(`تم اعتماد ${money(r.approvedTotal)} وتسجيله في الصندوق.`);await renderCollections();}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
async function returnCollection(id){const note=await promptAction({title:'إرجاع التقرير للتعديل',message:'اكتب الملاحظة التي سيشاهدها المحصّل.',label:'الملاحظة',confirmLabel:'إرجاع'});if(note===null)return;closeModal();beginBackgroundSave();try{await run('returnCollectionReport',id,note);toast('تم إرجاع التقرير للتعديل.');await renderCollections();}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}




// Shared searchable directory component for administrative lists (trip UI excluded).
function towerDirectorySearch(query, values){const tokens=normAr(String(query||'')).split(/\s+/).filter(Boolean);return tokens.every(t=>normAr(values.filter(v=>v!==null&&v!==undefined).join(' ')).includes(t));}
function towerFilterDirectory(input,rootId,rowSelector,countId,emptyId){const root=document.getElementById(rootId);if(!root)return;const q=input?.value||'';let visible=0,total=0;root.querySelectorAll(rowSelector).forEach(row=>{total++;const on=towerDirectorySearch(q,[row.getAttribute('data-search')||row.textContent]);row.hidden=!on;if(on)visible++;});const count=document.getElementById(countId);if(count)count.textContent=`${visible} من ${total}`;const empty=document.getElementById(emptyId);if(empty)empty.hidden=visible!==0;const reset=document.getElementById(rootId+'Reset');if(reset)reset.disabled=!q.trim();}
function towerResetDirectory(inputId,rootId,rowSelector,countId,emptyId){const input=document.getElementById(inputId);if(!input)return;input.value='';towerFilterDirectory(input,rootId,rowSelector,countId,emptyId);input.focus();}
const REPORT_UI={catalog:[],current:null,currentKey:''};
async function renderReports(){const c=$('content');c.innerHTML=pageLoading('جاري تحميل التقارير…');try{REPORT_UI.catalog=await run('getReportCatalog');if(['ADMIN','UNION'].includes(APP.ctx.user.role))REPORT_UI.catalog=[{id:'COMBINED_OVERVIEW',title:'التقرير المالي للعمارة — لقطة موحدة',description:'الصندوق والاستحقاقات والدفعات والخدمات، من لقطة قراءة واحدة. حساب الحارس منفصل.'},...REPORT_UI.catalog];c.innerHTML=`<section class="panel"><div class="panel-head"><div><h3>التقارير والمستندات</h3><p>المعاينة والطباعة وPDF تعمل دائمًا بمظهر فاتح مستقل عن مظهر التطبيق.</p></div><span class="badge">${REPORT_UI.catalog.length}</span></div>${REPORT_UI.catalog.length?`<div class="tower-directory-toolbar"><label for="reportCatalogSearch">ابحث في التقارير</label><div class="tower-directory-controls"><input id="reportCatalogSearch" type="search" autocomplete="off" placeholder="اسم التقرير أو محتواه" oninput="towerFilterDirectory(this,'reportCatalogRows','.report-card','reportCatalogCount','reportCatalogEmpty')"><button id="reportCatalogRowsReset" class="btn-sm" disabled onclick="towerResetDirectory('reportCatalogSearch','reportCatalogRows','.report-card','reportCatalogCount','reportCatalogEmpty')">مسح البحث</button></div><span class="tower-directory-count" id="reportCatalogCount" role="status" aria-live="polite">${REPORT_UI.catalog.length} من ${REPORT_UI.catalog.length}</span></div><div class="report-catalog" id="reportCatalogRows">${REPORT_UI.catalog.map((x,i)=>`<button class="report-card" data-search="${esc([x.title,x.description].filter(Boolean).join(' '))}" onclick="openReport(${i})"><span class="report-card-icon">▤</span><div><strong>${esc(x.title)}</strong><span>${esc(x.description||'')}</span></div><b>عرض</b></button>`).join('')}</div><div id="reportCatalogEmpty" class="tower-directory-empty" hidden>لا توجد تقارير مطابقة للبحث.</div>`:emptyState('لا توجد تقارير متاحة لهذا الحساب','')}</section>`;}catch(e){c.innerHTML=errorCard(e);}}
async function openReport(index){const item=REPORT_UI.catalog[index];if(!item)return;const c=$('content');c.innerHTML=pageLoading('جاري تجهيز المستند…');try{const r=item.id==='COMBINED_OVERVIEW'?await buildCombinedOverview():await run('getReportData',item.id,item.options||{});REPORT_UI.current=r;REPORT_UI.currentKey=item.id+(item.key?'-'+item.key:'');renderReportPreview(r);}catch(e){c.innerHTML=errorCard(e);}}
// Presentation-only grouping: never changes ledgers, snapshots or the detailed export.
function reportCents(value){const n=Number(value);if(!Number.isFinite(n))throw Error('REPORT_INVALID_AMOUNT');return Math.round(n*100);}
function reportGroupUnitNumbers(numbers){
 const vals=[...new Set(numbers.map(String))];
 if(!vals.every(v=>/^\d+$/.test(v)))return vals.join('، ');
 vals.sort((a,b)=>Number(a)-Number(b));const out=[];let start=0;
 for(let i=1;i<=vals.length;i++){
  if(i<vals.length&&Number(vals[i])===Number(vals[i-1])+1)continue;
  out.push(i-start>2?`${vals[start]}–${vals[i-1]}`:vals.slice(start,i).join('، '));start=i;
 }
 return out.join('، ');
}
function reportSettlementStatus(paid,remaining){return remaining===0?'مسدد بالكامل':paid>0?'مسدد جزئيًا':'غير مسدد';}
function reportGroupedDues(rows,fmtDate,amount){
 const groups=new Map();let original=[0,0,0];
 for(const x of rows){
  const a=reportCents(x.amount),p=reportCents(x.paid),r=reportCents(x.remaining);
  const title=String(x.title||'—').trim(),date=fmtDate(x.dueDate),rawDate=String(x.dueDate||''),type=String(x.unitTypeName||x.unitType||x.typeName||'غير متاح في اللقطة');
  const status=reportSettlementStatus(p,r);
  // Include exact monetary values and due date; never merge partially paid with unpaid.
  const key=JSON.stringify([title,rawDate,type,a,p,r,status]);
  if(!groups.has(key))groups.set(key,{title,date,type,a,p,r,status,units:[]});
  groups.get(key).units.push(String(x.unitNumber||'—'));
  original[0]+=a;original[1]+=p;original[2]+=r;
 }
 const result=[...groups.values()];
 const check=result.reduce((v,g)=>[v[0]+g.a*g.units.length,v[1]+g.p*g.units.length,v[2]+g.r*g.units.length],[0,0,0]);
 if(check.some((v,i)=>v!==original[i]))throw Error('REPORT_GROUP_TOTAL_MISMATCH');
 return {type:'table',title:'استحقاقات الوحدات — مجمّعة حسب السداد',columns:[{label:'البند'},{label:'نوع الوحدة'},{label:'الوحدات'},{label:'عدد'},{label:'تاريخ الاستحقاق'},{label:'الأصلي للوحدة'},{label:'المدفوع للوحدة'},{label:'المتبقي للوحدة'},{label:'حالة السداد'}],rows:result.map(g=>[g.title,g.type,reportGroupUnitNumbers(g.units),String(g.units.length),g.date,amount(g.a/100),amount(g.p/100),amount(g.r/100),g.status])};
}
function reportGroupedSubscriptions(rows,amount){
 const groups=new Map(),totals=[0,0];
 for(const x of rows){
  const title=String(x.serviceName||'—'),type=String(x.unitTypeName||x.unitType||x.typeName||'غير متاح في اللقطة');
  const qty=String(x.quantity??'—'),value=reportCents(x.amount),status=String(x.status||'—');
  // Snapshot amount, quantity, billing cycle and subscription status are group dimensions.
  const cycle=String(x.billingCycle||x.billingMode||x.period||'—');
  const key=JSON.stringify([title,type,qty,value,status,cycle]);
  if(!groups.has(key))groups.set(key,{title,type,qty,value,status,cycle,units:[]});
  groups.get(key).units.push(String(x.unitNumber||'—'));totals[0]+=value;totals[1]++;
 }
 const groupsList=[...groups.values()];
 if(groupsList.reduce((a,g)=>a+g.value*g.units.length,0)!==totals[0]||groupsList.reduce((a,g)=>a+g.units.length,0)!==totals[1])throw Error('REPORT_GROUP_TOTAL_MISMATCH');
 return {type:'table',title:'اشتراكات الخدمات — مجمّعة',columns:[{label:'الخدمة'},{label:'نوع الوحدة'},{label:'الوحدات'},{label:'عدد الوحدات'},{label:'الكمية للوحدة'},{label:'المبلغ للوحدة'},{label:'دورة التحصيل'},{label:'الحالة'}],rows:groupsList.map(g=>[g.title,g.type,reportGroupUnitNumbers(g.units),String(g.units.length),g.qty,amount(g.value/100),g.cycle,g.status])};
}
function setCombinedReportView(mode){
 if(!REPORT_UI.current||!Array.isArray(REPORT_UI.current.groupedSections))return;
 REPORT_UI.current.viewMode=mode==='detailed'?'detailed':'grouped';renderReportPreview(REPORT_UI.current);
}
async function buildCombinedOverview(forAutomation=false){
 // 060: one database-statement snapshot, authorized server-side; BUILDING_ONLY.
 const data=await run(forAutomation?'getPdfAutomationSnapshot':'getBuildingFinancialSnapshot');
 if(!data||data.scope!=='BUILDING_ONLY'||Number(data.schemaVersion)!==1||!data.fund||!data.buildingDues||!data.buildingPayments||!data.subscriptions||
   !Array.isArray(data.fund.entries)||!Array.isArray(data.buildingDues.rows)||!Array.isArray(data.buildingPayments.rows)||!Array.isArray(data.subscriptions.rows)||
   data.privateGuardAccounts?.included!==false){
   throw Error('اللقطة المالية غير مكتملة أو غير متوافقة. لا يمكن إصدار التقرير.');
 }
 const fund=data.fund,dues=data.buildingDues,payments=data.buildingPayments,subs=data.subscriptions;
 const fmtDate=v=>{if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?'تاريخ غير متاح':displayDateTime12(d);};
 const amount=v=>money(Number(v||0));
 const labelUnit=u=>`وحدة ${unitNo(u.unitNumber||'—')}`;
 const dueRows=dues.rows.map(x=>[labelUnit(x),String(x.title||'—'),fmtDate(x.dueDate),amount(x.amount),amount(x.paid),amount(x.remaining)]);
 const paymentRows=payments.rows.map(x=>[labelUnit(x),fmtDate(x.paidAt),String(x.method||'—'),amount(x.amount),String(x.status||'—')]);
 const fundRows=fund.entries.map(x=>[fmtDate(x.createdAt),x.entry_type||x.type||'—',String(x.description||x.category||'—'),amount(x.amount),String(x.status||'—')]);
 const subRows=subs.rows.map(x=>[labelUnit(x),String(x.serviceName||'—'),String(x.quantity??'—'),amount(x.amount),String(x.status||'—')]);
 const outstandingUnits=new Set(dues.rows.filter(x=>Number(x.remaining)>0).map(x=>String(x.unitId)));
 // Diagnostic only: do not substitute the sum of detail rows for the authoritative
 // RPC summary, as those figures may have different inclusion rules.
 const listedDueOriginalCents=dues.rows.reduce((sum,x)=>sum+reportCents(x.amount),0);
 const listedDuePaidCents=dues.rows.reduce((sum,x)=>sum+reportCents(x.paid),0);
 const listedDueRemainingCents=dues.rows.reduce((sum,x)=>sum+reportCents(x.remaining),0);
 const rpcOutstandingCents=reportCents(dues.outstanding);
 const duesSummaryNote=listedDueRemainingCents===rpcOutstandingCents
  ?'مطابقة الاستحقاقات: مجموع المتبقي في الصفوف يساوي إجمالي المتبقي المعلن.'
  :`تنبيه مراجعة: مجموع المتبقي في صفوف الاستحقاقات ${amount(listedDueRemainingCents/100)}، بينما إجمالي المتبقي في بطاقة الملخص ${amount(rpcOutstandingCents/100)}. الفرق ${amount(Math.abs(listedDueRemainingCents-rpcOutstandingCents)/100)}. قد يرجع الفرق لاختلاف نطاق أو حالة السجلات؛ لم تتغير أي قيمة مالية.`;
 const groupedDues=reportGroupedDues(dues.rows,fmtDate,amount);
 const groupedSubscriptions=reportGroupedSubscriptions(subs.rows,amount);
 const report={system:'Tower App',version:APP_VERSION,building:{name:APP.ctx?.building?.name||'Tower App'},
 title:'التقرير المالي للعمارة — لقطة موحدة',subtitle:'صندوق العمارة، الاستحقاقات والدفعات واشتراكات الخدمات — حساب الحارس منفصل.',
 generatedAt:fmtDate(data.snapshotAt),generatedBy:String(data.generatedBy?.displayName||''),role:APP.ctx?.user?.role,
 isAtomicSnapshot:true,snapshotAt:String(data.snapshotAt||''),scope:'BUILDING_ONLY',
 sections:[
 {type:'note',tone:'success',text:'البيانات المالية الخاصة بالعمارة مستخرجة من لقطة قراءة موحدة من قاعدة البيانات. هذا التقرير ليس نسخة احتياطية ولا يغيّر أي أرصدة.'},
 {type:'stats',items:[{label:'رصيد الصندوق',value:amount(fund.balance),emphasis:true},{label:'إيرادات الصندوق',value:amount(fund.income)},{label:'مصروفات الصندوق',value:amount(fund.expenses)},
 {label:'الاستحقاقات المتبقية',value:amount(dues.outstanding),emphasis:true},{label:'الوحدات ذات المتبقي',value:String(outstandingUnits.size)},{label:'دفعات العمارة النشطة',value:amount(payments.totalActive)}]},
 {type:'table',title:'حركات صندوق العمارة',columns:[{label:'التاريخ'},{label:'النوع'},{label:'البيان'},{label:'المبلغ'},{label:'الحالة'}],rows:fundRows},
 {type:'note',tone:listedDueRemainingCents===rpcOutstandingCents?'success':'warning',text:duesSummaryNote},
 {type:'table',title:'استحقاقات الوحدات',columns:[{label:'الوحدة'},{label:'البند'},{label:'تاريخ الاستحقاق'},{label:'الأصلي'},{label:'المدفوع'},{label:'المتبقي'}],rows:dueRows},
 {type:'table',title:'دفعات الوحدات للعمارة',columns:[{label:'الوحدة'},{label:'تاريخ الدفع'},{label:'الطريقة'},{label:'المبلغ'},{label:'الحالة'}],rows:paymentRows},
 {type:'table',title:'اشتراكات الخدمات',columns:[{label:'الوحدة'},{label:'الخدمة'},{label:'العدد'},{label:'المبلغ'},{label:'الحالة'}],rows:subRows},
 {type:'note',tone:'warning',text:'حسابات الحارس والمشاوير والدفعات الخاصة غير مدرجة في هذا التقرير ولا تُجمع مع صندوق العمارة. رئيس الاتحاد غير مصرح له بالاطلاع عليها.'}
 ],footer:'لقطة موحدة للعمارة فقط — Tower App V'+APP_VERSION};
 report.groupedSections=report.sections.map(section=>section.title==='استحقاقات الوحدات'?groupedDues:section.title==='اشتراكات الخدمات'?groupedSubscriptions:section);
 report.viewMode='grouped';
 return report;
}
function renderReportPreview(r){const topbar=document.querySelector('.topbar');if(topbar)document.documentElement.style.setProperty('--report-toolbar-top',Math.ceil(topbar.getBoundingClientRect().height+8)+'px');$('content').innerHTML=`<div class="report-toolbar tower-report-actions no-print"><button class="btn-sm tower-btn-secondary" onclick="renderReports()">رجوع</button>${Array.isArray(r.groupedSections)?`<button class="btn-sm ${r.viewMode!=='detailed'?'primary':''}" onclick="setCombinedReportView('grouped')">ملخص</button><button class="btn-sm ${r.viewMode==='detailed'?'primary':''}" onclick="setCombinedReportView('detailed')">تفاصيل الوحدات</button>`:''}<span class="grow"></span><button class="btn-sm" onclick="copyCurrentReport()">⧉ نسخ</button><button class="btn-sm" onclick="downloadCurrentReportJson()">▤ JSON</button><button class="btn-sm" onclick="printCurrentReport()">▣ طباعة</button><button class="btn-sm primary" onclick="downloadCurrentReportPdf()">▤ PDF</button><button class="btn-sm" onclick="sendReportPdfToTelegram()">↗ Telegram</button><button class="btn-sm" onclick="shareCurrentReportPdf()">↗ مشاركة</button></div><div id="reportHost">${reportDocumentHtml(r)}</div>`;}
// V2.4.30: embed the original Tower App artwork directly in report markup for reliable PDF capture.
const REPORT_LOGO_DATA_URI='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAC0CAYAAAA9zQYyAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nOx9d3gc1dX+e+7MNkmr3mU1q1tylcG90EJCSQiBGEgghQBJvkAC9peQ7vzS89ESCCEhCSkEQgwJSQgpNBvbuHdbsiVZktV7WWn7zD2/PyTZK2ml3ZXWRcTv8/Bgzc7cubv77plzzz3nPcBFXMRFXMRFXMRFXMRFXMRFXMRFXMRFXMS7AXS+J/Bfgbyby0E0H4w6ZHZsxebN2vme0rsVFwl9tpD/kVmA/hECfxJAoc8rPUR4Uery96jdtO18Te/diouEDieK3m+FtNxEjDsArAYgAMCgKE2z87KrTtY3ZWseT57PFUeY6XdQ8RxO/LHlvMz5XYaLhJ42NgrMPrZcKOJ2ZtwGIAoAiMhWnJd+5P5PfcBy3eWLF9b3ibef3ifWdLWcqj28+e+NjRV786UuM4YHkQB2MNPvYNafw7FNg+ft7cxwXCT0VFGwrgRM64j5YyDkDB/Vk+JiDt156xXOu299z0KL2RQxcnptL2355T6xZuRvZpZNJw4fO/TGX/o6m+oWARw5/JKTgFck+PeY1fHPi/52aLhI6FCQd3syhOfWYZdi0cjhqEjLkdvev7r7vk9cU5YQF53o79KT3djyqwPKGn+vaR636/iuN45XbPu3sNt6SwEowy81EuhZSfx7VL9QGfb38y7ERUIHhY1C5FX+gAn3ATABgEFVGq5YMb/6S5/9UF7x7PScQCNUd2PLMxMQ2hd2W3ff4bf+cfzkgW1JXrfrjL9NeJW97o+g/uW+abyRdz0uEjoY5K27gwi/BWBfPDd/3/2fuj7usmVzy4go6M8vWEL7orOprvbg6y81N1UdmQfmGCI8LqtfuC/k+f8XQT3fE5gJEETFDMbn77zuwIOf/tDqqY1CHOoVSbNyZ1/18Q2za/Zv3791088XMePSqd37vwfifE9gJiE9OcEw1Wun8yi0xieOLC6N0xjmvwL/PRa69OYoOJELl+skWv7uCO1iJgDQdTnl23PI9nnUtUNXE4Ue8Vi7VkVb6iwM6u1o2uSc+ixmBt79Frpw3XyRv+6X5BYdJMRhiohsQP66byDrtrigx+Chz0lKOWVa8nRM9MivgdTuoK8pvDlD5K97lJpSukjjOjKLLpG/7nfIX7co8MUzF+9OC712rYqm1BsIfC8kVjMAIrJHmI3H7U53MQHfglHfQPkfflLqyqOoe749wIgjFnoadnbqYB65bxC3L74lR3jxJZb8CR6OyBjNERUelyOXgdsJuB35t2xhko+jml8GNulnc+7nGu8uQhfemgip30VN9BmAMwHAaFAbbrthdd2Dn/nQwkGHO3bxdQ+MnG1l0JdIkfdRwbpfSkn/h5N/bPQ7rmACE3gafsN0fgpBXTr7tgIh9C+zxh9lwihf/8Nffixb17zevf/atLdm/9Z81vU1xLQG+dTAuOVJqO5f4vhfgrf+FzDeHYTOv2WhAD7HUt4GkBkAJ8Ra93z13pvc665btUwIygIAp9vjz3e2MONeIr6H8tc9Lmte2DDuDKYhlyNIbvkDT/1STO6BbxQiv/LHDP0zfGZDZhQEKcIQYY5ceeMnVy2/4WOyeu/Wwwf+86LitNtKCfwDaMZvUv66P0hdPI665w9PY6LnHTOX0GvXqmhKvpFI3AvmlSNuxaKy3C0/ePBj6WWFWZf4uWoyT9bIwHpk3fZdNDzXO/olJoCgaVPfhZ7WovC07+5nUTq7Ko+Bz006gM+7FkIRRZeunVd06Vp0NJ48tfuvv2/vbK6dz8CnSJGfQv66zUx4HNXyrzPRHZl5hM6/OQlQPklN/FkAWWCGQRGNN16zvPabn79lXlxMZEibF+Ng9I7/TJgEaHqLwukE7lgOm3d/QRbBwYTy/N48OTMv+7rPbcx22m22/f95aW/13i2zWcq1xFiLfNHCuOVpCHoCVc93TXny5xgziNA3K6JAfIsZDwBsAcAJsVF7v/yZm9y33rB6qRCUGWiEoDb2FMVPrHnIQuvToPN01pPMI0z2MwZLCuK3MukZlsjo6BUf/MSKZR+4Qx7f+fqBg6+/bHY77SUE/iYkf5EKPvxTaeSv4tgmz1Tmfy4xYwgt8sV3mPEgAMfiuflvf//Bj2SUFeYsDmkQDuKr9+rjPxNBBAZ4GnHo6YDE8C4j+Qn+SSGgTD6vYHfohVDEnOVXL5yz/Gq01lWe2PXXZ3t62xvnM9MG4SazBO4NffbnFjOG0Ay6C2DXO3/+fk9uZuoUt5+nenMWAEGfhssRjBmdEHLYlWVEofRm4yhLqWoCHP7thLTckqIbvvBd1B/Zc+Ct5x5fyEBoxuM8YWYQuvxuA/r7ExQh2nMzU2dNdRhC8MlEKLw5A1J8gMA3MGgtML2dwmmF7c6ESFaQW7RTwS1/lcAmGPXX4BaB2RxCEtVYzCqeVxj4rAsHM4PQ1ipGf8o5uZVQxAYuWLcUEosBEEAQgrrmFedU3nDVpVP+MU0HyTkFOfnlK7eeOrY3yetyFTPzxwj4GNyiD+A9QSw4p0xolufHzZoqZgahh8E8rQ3koOwz85CfaFCUxiULC0/eddt7oq5YPm+BoohV07n3dGhhskTFrLrp7lWrbrobAz0dPZU736it3b/d4rTbSgC6KtD1PB1CTyvgeO4xowgdisfg9/IAGRUmk/HkyvLipk+suyL+8qF854CRk2ARLlpY45PjL73m1vhLr7kVLsdA74ndmyuqd282D/R2zsUE2XiCxJQ/OJrejtA5x8widPghIyPMJy5bXtax/s73ZxXnZ+YByAt41RRwNlhhjrDGzV97/Yr5a6+H2zHorDu8e9/xXW+4etuaFvjUKA75TVPERQt9NrA5iZEPTDNnbcTCu1ISYw7dfN2KwbtuubosOSG6BEDJ9CcZ6N5nd3hTRJSleOnl5cVLL4fmcbtq9m/fd3zna9zb0VIMICLgAO8SzAxCo5SBSmCatIiNiYyt2vxTlzUyYkl45hU8zmWenmo0mUfIrWteD4imHNfj0xlZoVfcnA/MsHzo6TnRqqKo1siIqHDNJjScn/JNRTVMr8qFR4jMMyLcMcMIfRHnHMQj1TIXLXT4sJEBgKfrQ58nMIObWnrd53se/w2YIT70MGaEjRhCR6+r85Ud9TUvvV2rHavryfd2nrKwZu+0xiXUZJeWaUULlsy2xidkBB7p/ILlsIVmnhFcmRGTPI1gkovOE+wur/3fe5qO/enNk469JzozXB6tAECSzynVzJxk6+lKOrJ1M45s3QwhRGNC6qz63PmL1Py5C4pNlojg6xzPEXzC0DOCKzNikrgAbbMuWd9/oqvq+TeqOt460Grt7HeWAqHpZkgpMztbGjI7Wxqw+58v6wajqTIlK6ejYOGl1szC4jmKajCfpekHDTpdzwgVX+BYkCcDqohXGSYwiJlix1widaFsBbljANMA/o/azuV8Zwqhh+AvffIc4mRzf+OmLbX1/9h5Sq1vHZjDjHDGsBWvx13SVHOipKnmBAA4TWbz7ozCku6iBZckpOTkLSSiKeuCTBU8EuVQTVFC0XoBAUifrXw/a0XBGsAKAA1Y73UCqGWgjoBqYtqvQ9uNR0zVZyMUOLMIPd297xDR1utof3VHQ+2IH6zpnAkgbNvhAWBxu1yX1h4+gNrDBwCinkhrdFVaXoG7YOElyamZucU4B7FAPv10nDL3LABKCSgFhqKAAgqwXutleHcTYbfU8Qaa1G3YRNMu+ZpJhGac5S+wq9/V/bft9VV/f6feebi2J9nt0csAnJs0v0Bgjrfb+pfWHNiLmgN7QYLarbEJtdmlZVpx+fK8qJjY9LN6fxn2pOs4Aq4G42oh8HVka514QHtZQv4MjxgPTHXQGUbo8LocTo/ueHNf0/E/vlU7sKuyLdnh1IoALAvnPc4WWHKKracrxd8Cs2D+wjlGkyUmHPehM9oNZ/dpwEgC8V0CdBdt8G6BpB/pj6ivhjrMTCL0tB9Hmi71d4601WzaXNu55XBLTI/NXQQfneezirPsHIxZYHqNZsvhtNn53YULFsel5xXOEUKZMbp4zFgD4jXKeu9OYnxNe8TwRrDXzhxCM3eBhDXUyw6f7K564c2alv/saYps63WUMKMIQNFZmOFEkFERhuPpKbk91RWV1ZqmFZyDexo8Lue8UxVHcKriCACyR1ijD2YWzrEXXboiLSE5uQjB/sQUcZojhgi0RGahDoJZMUudIDxKBAyKic0gYmZI6YamucHsALn7EeXp5VSvXaQHfT8fMLCUCa/Teu/rrMv78JgpoOj7zCE00SCA6ECnOdya/Y19zUd+/Wql40BVV5EmuRCju1CddRBRT05a1Ilrl2Zrd1xdWJSeEDnn2UOio6KTCgb6ehqrD+ypqzt2wGjr6S0Bc1hcg8nBkY6B/ktPHNjTXtPYDyGoJTou9nhBaYGaV5A332g0jQ29nYEuT4uReB1I7zuO9CFuntG0IYVchkhqMcbKbksavBEJiBXpXGAFIgGAWdqlhlp3J3XbGynO2Y45zAg6YkPAlaSIfVjv+ZJ82PDEZNGRC3ajYiwob91xAJmte58Zmwopj5zsPv7rf55oe3NfU3T3gHsezoPsrMWk1i4tTW285bLZ1qsvyZynqmKUsfj9IbG5snOoNnEEzFJvbzpVdWLf7uam48eSPG7XXJytdARSBpSkgmaQKB7zim4wGmrSszI7SuYUJyenJRf6VvQO9Pa0vvijL6TBEFFB1/xiTtC3I2jmBFRHpOudEekiWph4HkbeG2PAbeOD/UeVBGcXgh5zaGB+VtoMn8QvyOvv5ZljoQXcYERU17U0JCQmRP55S23li2/XeSvre4p1yXOAED+YacKPFZ4NYPaE5/sdQyipmbklqZm5JQDgsg92nzx2uKru0H6tq7WpgFmmhmm2HiVh9gmQ8Fe5rXg93qJTNbVFp2pqQaCu6NjoutlFeVw4p6iwva6iCUAajFEhdeZihursQomzSynpPgwYo1GfUM4txmgsA8FqiqFVySskpIYK2wnq7T9Jy0ZUXicfmD5K0Voi38s34HEalx8zYyy0yP/wdxn0FYNBrZYpl1qgmM91waqMMqvHV8xLa73j6sLolXPTFiqCgjYIzx4SmyvGWOhA9+tqaTxeuXdHZ3PVcavTPliGqTx5CFJJyN8Bxbgi5GtZr9Kbd0RD96Si6IZtVHzTypDHGIOIdD6QVI50CB4VDpVePtaxUyjuHhr7BJkA9KR8WP2fcUenO8FzhtKbo8gtXgewBETNSuriQRitZ3Vx58cKJ091rOeOiM1H20Mi9Ch4PW57U/XxI5W7tjs6mhoKmWVQP2gRm72FTFOQR5PeCr151yxITzSE8me69lf9TGoGEWYByMJwP8apQLGgI+MK2UMKxrk/jmba2rmPVgdjrQXjyrERkJlDaABIvz6CLJY/gehaMPVSyrwGYUmYH85bBPKFp4rpEnos+rs6G6sP76mvP3JYDPT1zAMwLgKkRKe/BUvsZSEPrjn36C275oGliYBHZI384jjhxi9zgurV5kvwPADlYHoPgKB/8IoJPbOulg4M/UBG395OO1vepIUsh/StJwIB7+gPG1aMOTbDUH63QfT3P8PARwA4RVzRforOCP1xOoxwWuHJ8PwRsflIGAntC13zOhqrjh+vPrB7oL2hPtnrcReLyMTtFJW8AiF+x+zq3SY7DqwAQ2fGAzj5wuNBXbiRhTqgXaUD9xNwdTCXRM3ivQnl7FeRSXNhT/N/xCKwf4ngEUhVzcYPqWHk75lH6CGQyP/wdxj0FQA6orO3K3F5QcuDqYpoWzk3tfLTH5iTsqw0tVgRU6+5CxbPH6HNR9rF2rN9HwAY6Ompf+W17Y3evu754MChzmFIDDZv17tPrAJgY0k3ovaPQW9o+EK93/teKfAMgMkXtQTOuk6eInG6E+8oODtoc8eOyY0Age7QH1Z/f/reoU/3ggDLmj99Ffm31BL4Z7CdWs3ewdcoed6VkyQw2YozYw7ed2OZ5dYr8hYqQmTbXPqEUYmZDGt8fE7Sez+gSl03OetP7nFUHfN4+3rnY2K/1809VYflQNMqAJ3M8n2o3bRvqvfXHjX8C1/kS4Tu3QZQ9oQnMsgzwI2mGMrx97IlmVdbEnHc2TXxQpFJjsohn6mEHkLNH3/F+esaCdgknd1XoWXPViX9kqXA6TRLPTnWcujTN5Q4P3t96YJIs3LaikuJ3glGPSs4t3mCgMLoZaHMiphdeEnE7EKwrrmcp2pHyL0QZ6QN+mTnoSZ2dF8CoIZZvg8nN9VMewI/oiZ5v/taIegAMPEmiu4UOmIm3CcR8Ytga/5P8LedqS7HaMy+eS4JehWgWVBMe+MLVysfe1+J7YGbysoSos0J/i7RpNxqd/O05L0CobPb3vXoH7Yee+dgvdrUYY+yRMc6sueUijnlSxaoBnXSBc908Y6Ndtgl+U200j3uAWf18cP2E4eFVv9OKnsHcgHsZJO8Fsc29YRzHmKD57dgumOi11NW8hZzAk8WhZEtr4k2rwN+swmJ6VrfJKaZbaFHULvpCOfdfBkRvQrdvfirH0zZ+ZnbFk8aquLpyc1NCrvDbf/Y1zbt3X6wfjmANWeOO9HV1or9b73eV7pkxb7Fl12xLJT2yqHALMhjn+AdKkaTNap0/gpP1VtbvN6BXIC2sKbfgprwkhkACOLfDJ6Q0EZrQB9fRGRyXf8J8kdoTZfKO6NOnsokL0gMPSZrAaAgJy1gjFQLIZcgFDS129rmfPDR9u0H69dggkctM2KP7ty+/M9P/XSP5tVcZ2MeFhE41VbEJhMAEPNB1G86K6VSOrhlwvsbqVsYuSzQGOZE+G1uw8A/8Rj1jRoz9Cle0CgGgMWluQGrSqROwa7+g0b/oMu24o6fujxeLajFpq23+9KXn37y0LT6xU2ASCVwuZYxOWvIjyby65aFAwpowjBowjx5BJP41yMQZr+ehGTm7407N7TpXcBIvz4CQKaiiNbYmKiAGWy6lEmBzgkVH7jvt0c8Xj3n9AGWFRhs2oHuwy3oPNCHvuPVcPVsBfh0T8CBvt4lu996fXu45xJBMuBTypCUnQAADM4P9/1HwBJ+1ylqhGyLSOeFQQ3i13Win+ER486xR989hI6IKAYgkuKiJ3zE+cDDjLAS+uDxluoT9Z3LR/5mV+8WdO4rhqN1GXR3OliLhWegALaTq9B1SEBqp8uMKnbumKP576E4ZUSqCCiJoManpmOotC3I/IkQsZHNIL5p3HECp66iRhCCSp3VnBibWXdQWpXx/STxbiI0qBQASgoygskKa0OY3/uXf/zPNoxEjTy2LWSrWTPhPaQ3Dt2H5oDlCQBgcHzFvl0Hwzkfs0AKAlS2kmowgUQngFgUfzDsboewaZ+Fn82VhPm8RTGzvz6SfuHpHeWW9EvW12Ej+V17vGsILSBLAWDZgvxJt0oBQAJhbwN8pLp9SFeauQX91YHVTVma0F/FGCbdyaPhbeBKgIGAgFELxWwZ6nPuMeWGdQIbnLkgfHPs4ags3hOVHVK4VA6eOl2g4RHAzXjEXDXRye8aQvOwhV5RXhxYfYjZHs57t3UPtOtSpgMAu3urwDI4gRjPQDFYrwSAwf6+sOeQCOKADTNFVPzA0D9k+HZNN3KEwuofMabCyJLGBxIWchkmaOHsD7obh3QXJQEYFALXaw8bXpvs/HcNoTGU4M8L5+QEjHDozGFt+dvc3n86dESu7tBKqjR7FwBIKcO+0WIg2AKek5A27J9SeAh9NxtoQPsjj1GRiszi3cmXcjGGdDqCRs/Qg6tDSr5M+z9DwD3DdwehhyIcOYoiWmOjIwOG43Q9vBtK/YOuM30DpTdyklP9TEY7azJnRvLvZ/pCSc5WAUAQpu9y3MsmitJeIOB638MxhbwtcSEvQIhk1t3Y72gRUVLqK/CocW8w17w7CG2OKAUgkhOiW4M5nZnCKnouhM8T9AISlLQogUXKTcnZVgBg5qxp3exBjlNM2r+J8MHTxwh68hLeElvCKxF6tY29fYeokx51BR41B51bMrO3vj/LUYpF/xA377yS9z6O0vxZQdW9aVImhnMaBHmGxHQW2rpOEVFCKu0B3FVD4qzh8CVNXdr3Ac984dX+xD7V9QYrN6au4h5hQOjVMgBLD37olur38Tj53SWcCDOP0BtZYEBbLkC3A9ptDESxYtwMAEsWFgTzfnTm8Mp7KYpP27QLSCc1UhUBmwUp0QmpANyA/5zkQBDrPZ8G6FEAQwthAseWYGt0PpcTTUkHsJuY7zh1pTlk1SRgJhF6vbtYkLgFA/odAHJ9mSN6TqgSwMogIhzMaGf4z9yaKhRBF6SFjiCOCZhQSUSkqq2saTkovDURVc8HjIwAAP6XU0nXngLwgZFDihkdqau4Xo3gqfZi/4+i63fWXBbRNMXrL3BCb2ShDOrXSub7CLhiyD8dbwJlV2UiAF44JzugH8hDoawwCxtOvbHl2YRZBLcbKkyRPbrWnwOpFQCYnNAbWSiD3jtZaj8CIRYY0uCIK+F3rPk8DxSaRvYwegD6Ut0qw6+m28vlwiT0lzhGaN6PY8B7P4OyA7BFh60x26CKluioiMB+IGMgTLM8DUXxTQGVF4yFNhCiAdgxrGA0EdSYZLtu7wdAJQB2THji/Z7FyoD2OIOWjhyKSOf9ieUcRQJTscoM4FmheDacXGHtmML143BhEfqLriKhKZ+FV/sUiIJrFin1RuienOSU+BYAAQmt6/5TEaeDUSnNMrT8ZvaVKToLEESdknlyQidmSHdLNTCR9vWXOUG4tW+A8DkejowZrVSfuES2GiJ5amqtjIMC4n9OrjG8E/jk4HFBEFrd4L1cZ3yZdFwZ8NsleCDghYQZDIVdvW0AckoK0oNK7tGZg96lChbCt7Hl2eVnyFBY9skAUzKkZJsAgISyBmX3jd+Je+2bRhYGA4BdI4f0CEbH2wT4WnQSLMzmgJtWrOmap6XVC9a/RWX3BftWhm7B1CGJtkHz/gnHfzouheE8EppJ2aBfB+avSMbSQCwQVlRyFNqpn5Olg87IftkanACwfGFRUERlcNjbBI9aFOLCWRQCgFGQ3RsgGq0mZQ4tpiWnDrsdo+HqH3dIC0tuYOi/fSaAwLdBVR+hss//VLJ3I449eTpce14IrTygXcekfZcZ8yY7j0xoxizUUBRiuQMD3IrVjNGSA6KnyiABrFhYFFS2mK4jrDFoYChQcPqPUHP1xdmN81kEtIlKsUZgSJyVNvzPdE65cf9ZndB0wJoGze4kV50ZjrpyBq8nMlzH8z73Phx+og4414Te4F2mAN9nnrwoEnE4KGbBDQPK2AbIo8iD7r8EX3YdTwLAC0qzJy6X9zldBtKKmAJG+dAXUNgOACJUUKBVg2KJigZRP5hjwFQAxRiyDve5gQlQIsGmZCB6cS31buuDu2URSfUtXnjvJTjweOe5IfQXXUWkKw8R47oJ7ZGBekUGH+F4yiXiBeyi7XwUDngmJb8O26ksg6I0WyMtwWi9tTGHO2QHKIrvU+NcCxZMjkiaXE5rBKQa2tjriaG2lw6wKckDyHPecSsgyABEFiTBPGsOSJnN8Ws06t+9DY6TK8mjPM3ADWeX0A9ynPBo34CO/8EEtWNkQjNyUEuRXA7CatL5CGrQz4NB5MxK7RR07+yUlPhWYLxG2lgw0Imwx6ABBaNcjguK0BFCWoNJ2VEi4vq0/nbA0y7J03YFLlSJC9tBQInYzxm3Z0OJSODoS+eTu7UJuuMDKP3CirND6I0shM17D7za/wP591lFJKqRxR2IoCUAMsAYQDu2yiasQOBvYBDAE3LrdyoI+F1pYWawEY6QNI6DhdmsGgyKaAQAYTL2S4/0jD1HZ/Lb9Egxml26EI1Go6kHZ6FlXIQSXAGsGp/k0vrbMbxxdWGSeQS6YxE1PXOcsz4dBVKsHLt0F3W/OUuQ/Hj4Cb3BXaYMaE8znQm++0JYUYFcOGHAIoCG+o24sUtWIRMe/wWVPhgiMtSH8TB1If+WrwDAskWFQb0PZg57DBoAcjLiZzW89pWRP/2S8rtb1AN2r9+i0Mwx/w8rTIKTANIQYL2kJmYK1B09B83zwgTpKUbv9q2IX70KhsTZAMCM1eEj9N1sENHaA2B8izHeb6NIrqHZ1AkjluLMRzaANuyRzbg8wOgMwotSUTf4Kk0KcCkDWLmoMNgIx3kLUzKFX6ogGNDQvnw7A2mTnWdMzR2WNOCImcFogAYrojl+NUBqBkBeAAnh+YL/17NISO0P4PHVwxRBJylXdsFMlwI4Uy6v81E+Diu7aFIyE7BTl/x5PGrcPfY1JpSBIecHUaUCAJLJer7S4YjOXx6eSujx8uSENiRlDhuFs6fREXboruGsSTYBGAChZ5qEZhIPaPdD4vsYk8CtWNCetESv0lTF1NNHOb6J7zyIzVxFKzC5epGNwP+rP2x42m/Xo7VrVTShyGhQmiMtpqAIrUl53rrCCj6fhOZBb4C1qhqXmo4hBYyM4f+fn/AjEWI/ePX+mPdfYRexMVa9s7u/57mXkwbf2uWnhw6PKxqYOqHv5SQyas8AuHbUfBRyJCyQ+yMyeCERrTJBIjISek+v2GK3o5ybsZ/bsHayoZnwL1bUe3zdi3FoTcoDYEpJjG1DcP5n2LU4QsJ5tNBmhdzOAJsrpBqMEKINUqaCuBVMZyx6dHyH+Oj6ajKagye5UBQYDP755XK65XOPpHFnS87oSRAyn/rOAVN+zulmqIo1Eqlfuw8DK3bsbf/OE37F0X0xNUJv8CwRrP0FY/wyaw7vjpsnM4kwtrmMEh/Lpe6j1ODpmTQra4CY75MPG38TcA5SlAJAWVFwEQ5mtAIIZvPlrGB6SZHTQwQx9wbhFysmS6futKeC0QGf71Zcc3slpWZPpfLEPyJjQDd9biv/7Cs5vodjb3jPQVN+jl81Jetly8ptf32t3nnkhM8147dZQ36sKOu1m4SkN+HzhhULt6dfyTvj55xCmWUAACAASURBVPOlRON9NZZobt2MXk/PpK3XKqSUy/RHgiAzADDKgFAiHOHX4ggF59OHjhCBde4AQIlKGKoSZxpVLc77t8QBYQ15unFo27jcm+j3XzVZUS/F3HxN4+gjYxbaHJKFZhIPaN9g8DdPZ5QROL6Mt1pn82IAfsN0LFHX+gaMXgdN0hKYfimlch8eJWewsxGgUgZj1aLgcjiYwqvFETLOJ6FVGRmM7RIJaRo6G8AEzdeec9XBefo379Bhieyb8OJQ4PFYoHmWjz2sWCMnLaRVk+LHHhr3mQZH6I2sigHvrwG6/fSFEbItdTW1KqZJym0YDc2vUdSwUIg/eIn50/ojhl8HNY9RQ3MpADm3KKgcDmj6+QmbjcBvqc05QuRwZUkgGBIzDS7sAhEbxu0BMStwDAY1zlShdXW6lLiJVSi0uuYxkxrvyAX+2W5kIw1oL/iS2ZrLOzLeA6Nimlg9khn2ti3CNQmZBwThGv0RY8hkxtq1KoACo0FtjLAYg9J6kHzu2yX74nxGds3KxJK2vjCl5w4ngImwSw0Hg55fvzTZPN3df/jL6NTWcTaKeHILPaSC82cajmQQQUteye+Y43l1AHsjew7TEXe/fzcEQLcEv08+ZNwz6SgToSklG4AxLSm2DUEu9HQZnJU6WzifFloBW0DUB578M1ATMobCmpKTfX+BlJxRLz7x9T62WEa5d6RLF1gPffdV6pp87jGV6ytHEdS++1C+7c//2hd943sXwFcujNnZ+ZNfn/Q2t48VRw/F5WASVu8zAF0LAMJIvemX6/WKKXDtmKNDbBmsh/+Gj4ROqcvL8KjpWKBxJgaVAoyywllBq99LDr4pZLjh1aTX7vQ4QSEJB4UVgqlLgicntDUhGYALhBT41CLSVbfUIzJq7binjFAQhF65X9A1H93OT3513PGOn/6+vP8fb7XGvP+qCjUrTXhqGtD30qvztc4ef0r/wRNabNAeAtNHAMAYw7Wpq6VCAgEFqplR27ULE9WZ2aXO102PzIAAljKAZYuKg/00B5l53IribEMye3/1j+M7vvfsgSyvrl9WUlayY/HySzOJ6Fz3KYdBcJ87kI4SEZFiaGXdmwugBUABAPCOfycif24tEUWCxPQ1+KTu4C1/nbByyF3flNbxk2cm3dkcnvCIbrQEQQWz1S+hlfXa7cz8AABY0lCVfpNIkDaukP1SByMHk/jePfupiyX8Cf9JIlqHRw3jtrCDhXr5U6shaD13Hk1lewdWlBcGW33SAh9Vn3OBP75Zs+vLT+9O8nr100+0yiOVy6oqq11LVy3ZnFeUXw7QOUukNxFc7iDOExFRPfpAby4IPSP2j2uPlvG3Ph7O6cQiHGm8akQHgEyAW8A8C4S+8YS+313K4J8BgCWNT6TdLJIBxIkYWiViFLCOLjnAJ9nFLugwEp9JRPK6YRtsmrDz5w/0h9R/TGXexiuemiOBHwJ0HRiQ7oEGAPq8ouxgczjOWU/CylO9Nbd++/X+rj6XX41oXdPM29/avnb/jv1da997+Z6k1KQ1CEFedqqwEOu2IJamanSiQx/oBZicF5QMlB9wZOFQmNfbdQJD+fA7RhN6IxvFgPYCgEhLOirTbhKphNGtDUhBohJLif7W7X3v8DZ/NybgHd2qjhO/Doi1P09UFXxdAp/FGffICd2ZYTQoTRazIagFoWQZjHGaFrya9G54cvvOl96uH52EdQZO+KhvOl3OxH++/I/LE1KSTr7nmqs8BpNxfHFqGBGhQgQj4KAmzmJ3czUudDIDohFxKy8Fo4u6t88BAGZ+YnTB6YC2AUCpMU40pt9EKWPJHACO/kPkz8fWdMi7sDEE0b3ynxvUK3/+oKqgDsB98PX1WTaAoaSlxAfdhozl2f12Kht6TpZ87IXal96uX4UxqbPM8hR3HHlTP/EXQl/ddoBHlVB3t3fmvfDbPxacqj31NoCw6lb7IlIEJ2VrSMkamf/5W8EGAlEzz/oYAUoP9bzeCnamAXgVx37y1hlCb3DmgvFVYYRj1i1wAwhpEaW7qIq9/gRN6Jd42FQR7DjqFU+vUmOwH4zvw19vas3dBQDzCjODjnDoMvzSBSN44s9Ht1/1wKupLrdWNOoFRhd6qrfIqpfTZM+Jy8G6WW/bt0KvfkVjR+dm4EwjHCmluuU/b61+819vHGZw59mYp0VwULFlQ0rucCSEL7w0UhIdHJm7mWd9sg/6QBV1vGSAp3MugMPskrcCPos7wYZvgBCRej3tJUPobb48XXK8eAPglpqyMagBVvzKqlzx86cBuQWECZsxssfuAYBliwqD3ijROKQnTVCQzPpNG/+z+QfPHVgBjPkhe2xv69V/U/SOQ2vAcvQ8dXeCbNiyVp7aXM9SG6V73FTfuPCvz72k6bp+MtzztSjByTcMp5ECoLPW6m2K8ICllex1a6nxGS91vR4J6Ukgxm/YJVeh5nEbMELoBzgT4I9EZPIxS8a4TLmgoA34yScj/A0/pvZA16qX/2K5YtH2E/ApBNpU8/arALBiUVHQ+hpSchAhoODh9uju1ff+de/Oo+1rR73AspvbD+zUa/+zGtIz6Y+InV0Fsvpv2TzQvAM4493abINpLz27KcHjdh8N55xNhDgAgRX9LVFW4NwtokOAEafdILmAdbcNgFuCto+QGRj2TQVp9wMwpFyr8FSVf9g9nogk6XeTXrR2o6oqad8DeD1xcJl/7OyPA6DNLcoKTnGe0M1A2B6fHq/uuuTTL1X02Nyjoxiaa49+6vUceF0T7Y6OB0uDbN6xTERn7KP0pfkAxQCAy+mKffH3mww33f7hQ0aTcX6Ypk4E6mRwwMgQGU3t7HHFcepNx2DJLA3DvXVgkn4vuieEjVSvG67mRnLUAJrNSMRPU+nnV8hjP/4khsjLBGCddQ72BNN3eSKIiHEzcunRysRNXt7zs2RVSf03gP9F8GmszN7BTJPB0Gg2GYIL8EsO+IQIFpou9bWf/9vhHpt7ke9xdnS8qZ98pRxe15QKCKStuVzWvdHJUp5Oj9Q0LfIvf3hxttfjPTHdeY9AJQ7K8iqRMUNZdd7ugE2HgoSCoQCD//8UYywUU5D/RaUgsmgxJ117Fcev3gtQHxM+jrn3fQ0AVKz3LgYoPf5STFlkGgAMcTxq146AI9hI48r5geENEp1eQKgqRqwdBWtz01KSK4HgmtxIJn++/ZRww9f+va2hY9A30Z3Rc3Kr7DgQqMg3INjdl8+1r3Ypee+tAqmFAOD2eKz/ePHlqBtuvbkHFNoi3R+Mgu1ePYhYdFyaR+ttBwYOdpI+8Pp07xs+CIWNyYzIvHxAZMGUcQknXnmIul6zENPXueyB36iC6FowoFhpWjs3xnhK831sSIbfFsXKZU9dA6KXMNLCIBgwjrOgr+mntqYS8MT84qzgczgk+/1RhYqn/n5sx8HqrtFVG73VW/WOQ1NVqx8PzZWo1/5bF7OvaRrZHrfZ7Bnb39q6Z8Xlq+IwzaQ9M5EnmKRwNTlDoPYgyNMbDc/etdO5Z7hBAECKm9Nv3QZj0koYEufDkPwGvB1XCOifF8yYqxrgsijTS68kBbNNCaLO587jYqrKZb94Pwn6M4IncwsR3aklxJXpr9/9kgDPAYDlC4uCzieQQfrmk6Gqoa/uu7/bP9f3GNvbtujtYSTzCLzOFK57TQJ8ugvsyaqTl7S3dGyd7tARIjhVJ2NKzlDUJszdwsIG1k3U/NxS6N7jAMAxi7MAgIE1goD85FTUKxRatyF/iF8hz2hmjGnMo1zxi+tI8J/gR7PDDxwg+qHmUou9r9/9a2z6sD404eFusYsLgvZVdcjQ+gb6wbpvv9bD7BMT11x7ZNO2UNr7hgT22LJkw7YG+Gy0vPmv1xZJ5mmp3EeqwRktQ2L2cASJz1uVfGBIlfp3DPn6hujZALwA56kAZqdl4DDA0xbni8imxUokOnU7JzFhLu5mA35BXvXKn68E80sIrlfdyxrLz+GNzzSPf4nnANBKCzKDVhmarnzups21uzp7ffMyuFuvfyMbYbD8IyBFdUeUL3nHetW1vYasrBgyWcxgjmUv75M2u3B39gnXiVNR1TU1LUUFBVNOg40UHBWM16LGp6QB0EHIQBAtLc4KBLmUmJg+vbcvARPlqDpPDXdsIAWAC0Q9KoY159NNaOlzIG9akyBEpt+AQ41/QBKAaNWqrdWu/uU+aPqLCEzmVia6V3/97pf8vpp7awogk0xGtdZkNATbxnda8rmSWX7p5ztG/SC461glNOeUYvXjIAjx6+7YH33dTRkQND5/3AwoVgsMGYmIWpCPFiCvTfJJi07tsRp5E92IjXFznuJvR9UPLCK4hSUJRYUQzZAyA0AzzmGmopqc0J/+owdrjJnpJQBSwWxzVlTva/3y/y2QdsdoV1V6xrmuKgC3xwuRbmRR4Zh+oZAxAcvjl2B7zy6s0AkPKCzqAD3Qo+sfmo6PY/PdE3dgEvocgJCRktAB+E1P9Ydpyee+uKV2r8crz3R1ktoJ2X18XHHnVCDMFpn+wycq1eSUUSFAMHpZ03qgiggiMXZDSJGC8uwCeXYDo3lom0EXjBqzxq2xGryJLhEX5+V8wRiXmjrcFSsoERnFHNWpO2wZAHrB2A5rTDGZLGHR7We3y4jBvnGcEJERruzfPTxIBkP56YNE0ZbSwqXZzz52vO6mTxdBl761NOMIqwJwOmwwRylUYCTq8YQhET5uCV3iHeR9A8fwXorN3YPuqolO9QD8Ze2Nex4NrFwx5D/PL84MOnNuuvK5D71waPR47Yf6wuJqECHtu48dVZNTRjoYsKe9Y0fPsy/Fu2rri8AcBwBKtLXHXDi7PrKkaMCQl2NSE+LSSFGyMNpvUCQh32GgfIcBaLEwMNSKq9qsc1usW3Cim+PivJQnmCMw9JkEXIMo0fGDusM21DWsuNyj3PaFWFDYZMIYW/++WX/thbW+BxPvvu0AGQx+i0OU6MjimGsvP9D/t9d9EuDGU0ZloPpUPS0GYJhv5b17bFNqZTsWxuQraC6Y9w/wilTR39ALzTV6K5jQC6IPaq/dswX4dMABBVDGAJYvCj7CMR35XJdHd7R02s9sNLFskbb6gMo9wSDmmhsOGdIzRnYA3T0v/OWgbcuOcZZftw3E2/ceirfvPfPDEhHmQXP+7DpLcWGfqSBXUZOTkoVBzcHo6iMhgQKHQgWOCEZLBACwLiROGmL1Nt2OKnYo8exEHqR/V1CNn6V72uoBsFDmXmoFUThztonz5xFee2HUQUv53EmNRdTKxQP9f/MNi4+P2qhE2Kt5eK3XI46lG3iukajXM2whpglj8pVUZkqmzV28Llccf9EDj33kMdNMOl/rfeueQ5OOMHrq8wFg2aKioCMc05HPfW1PUwWA0wRme1sVmKdfZUGE2HW3n3YH+l95ba9ty44VwV4uHa4ox+GKuY7DZxIYyWDwmHKzj1vmFHabC3LZkJqSKCzmXIyOKClSIA8myhMmAPESADQwquDmTulUmO1IZAfywDAY0rMZFdsAEmX6K7+rF5Exb8McEZ7ida9HypefHrcxRiLA008d95vyQ2jQ2wzeUFfNHYWlKF0dw++83oew+IkAjDHz8B5TsrKledPNhKp/9ir29kivUJfijTv9brz4x0YBVJYB8JYVzgolwjFl7b7NB5tHWXfur4uZ6li+MOUVVpDBOAcAdLvjSO+rrwVN5onAXq/RVVVT7Ko6k7xHiqIbs9LrIoqLO8wledKQnhYvIiw5GE1yFYRCmKlQmOVI9ruHJSqjU5ep0nlqt+vE8VRvV3e0/O0PptIhNiQ4jlZ5o1MmDko5dh4cmwY8ntC6TfmXsGodb/0TJYWlcEcpWJ5nxs6TrgklCEKFtA3AJBYJC8dd26x1a/UwmFW8dmfwI+Qdmw2IKLPJeNJoUIOOxExHPvdofa+vOWAe7Cia8OQQELVsdQcwJIk28Ob2cOVKjAPruuKua8x11zXm4p9DrQdJUWCcld5lKSloMRcXeAyz0mKUiIgsjCa5kQRKlJhoJNx59/BgsksftO9x19cNuo8eNjmPHpnlaWvLCrnjVwB0P/nsvOi1S7ugiHGslk5Xfd9f/jNmAe3H5cAvyIsN3t8NDvCGrg7ampiMVXMjMc8m+Winh6acrDQCjwNb7R1DfjnlIkNJV3fKKv1NbPD8REYZnpoo32MUSFkAMGalxnUCwYcWNSmnHLPtG3Cd8S0Z3WA9LO3g1Myc01+C48Chc1r9zboO96nGRPepxkT8600Aw5Y8O/NkRGlxm7k4jw1pqQnCbMqDb5iVRKJitSZGzJ2HiLnzhg052+SAvc59qs7mPHzI5Dp2eJantW1aLpne1x/V+OmvDqY/9LVjSkzkSJaf9La0H2x+4Lv57PWOcUn8ERqA9KoPCVW756/PIeeT92OQGFHLrZTyVj/qbFpwSUATzbHj2JhiAROWijJ2cB/dKBq0u+kB7Qd6o/I8NtGE5UeC5TwmwvyS7FBqAz08DS0Ou9PrE+PUeoDw9DcUUZGnLb/WZwu4HsgnV/uDov1YrnCLI2yhb+tpi7pZDVu1OOu64q6tz3PX1ufh70PHSFW8ppysE5Y5xd3mknwYUpOThcmUg1ELT4oW1qj5lrK5sJQNZwUw+nRbf52rrmbQffioyVlxJNPb0RFSLrq7tiG17sa7U4U1ssM0K7XLfao5XTpci/yfPT4yNjTBH1M71nt/1NfL3z6yh96atxiXEZB0WQzobRuf6PXSlB63upcPeT0YPxlCBMVhDcWiA218j1C0L9EG7dt6lPIiNtI49YiRBeHyRcVBRziYeVryuR7dp9JEcviKbEeFTmlSH3+90n7020pLPjDUsmMZ2fEp6u67Rcute4VjpmNoJgVrusFVU1fkqqkD/jY8U0XxmnKzTkTML+01F+WRITkliYxqDnxj2oRYJSZmYeSCckQuGAkls00fGGzyNDb0uyqOGF3HjqW7GxrSArkrcsCe7Kw8OblBUiNsAGIBlgAMYKSc/kClR/0/YdQ+9MY/eFXhXHHIbOL5BCSuiSbD3gHa1+Th8olH9g+3DZOrVRKSkYZkSkEztckvijb6Jj3geViPNjw7yhVhmgcCVpSHsO1LoguQUya0pvuow7P0TnJqSBDijKYxGRRlohqSbPL0fltpKcSYHVZBHPucoU5L8szX3D4/iDlpva1P3761pjCpP9bmMg4+uaVUfeSNskvC5eay7kPykblYzB7z7Kxay5ziblNBnjAkJ6SQ0Thm04uiFat1jmVOKSxzSoGbgNMkb2jod1UcNbgqjqS7GxrTQ/bJzbmtALKgDZzCUDpx8xkL8Ti55Rfct4HF3md+LFPvWU+NQkEmgJjFVl6Q5ubtewZpOUJIYfS4SASzKCOBDKRThkiVJ7iBPiO6tW9jvfenEuov8JcPe0HIBuAtyQs+wiFZTmtXS5c+CyUZPkJDnPn4SFUmDFPdKboqAf/RJhWceIUYOPqqjC4DgHXltSd/94nNmRjW7I62ePG9G3bjtkuqjyz+wQfn+uWJAS5opIID6BtOAul0GR3Hqoodx85snClx0W5LQUG9ubTIZp6dbVbjozNByhgJsmGSl5bCUloKYB3A3KsP2Oo8dfUDjv17Iu0H9pfIwcFJc0g4ZuGQVJntUB2AXAL+PfrNPGaqpPXaxxx2fuFPv+Hj6+4kOw0lpigZJlqRaMCetwcoya5xTlDvOFRNZIEiygEoC8dkLW4R/drXcf0v/8I7Hq4w22tNBlUJunBzuvK5UrKvDx1GeQFfQqsTGodk0ib9EaXCawcAIRi/uuPtSPjJlSnL6J17S3ltxfN7Z58WmjcsNZ0w3hfHZKZ8AC7Zrh93facnRzZrYVkj6L020+DufUWDu/edPqYmxTssRfmNlpLiQVNulkWJtmZBjElNJYpTomPiLPPnwzJ/PhI+Aben4dSO9icey9a7uscvNmOX7IJiWQJPVwXcTcsASKkoj46LVPOO/1dBy7/eP9BPt7c3oqJkHkViuL2uSsiYbYLJInh/u5cyEMBaSw/X2bumsKgkJFM8UigJh8htSEPqmjJRcF1br0upXDQL1ghDYM0Ir86tugzcXXYiPPKnQxLDJGGvs577asPSziL6Pdc3KNEx2QAwsG0X5KD/lPsEaH3Xif4JE6u+qadRJwzRJan9TZ9dUzFhdCHK5K14bk9+DgAY1lhqTOvjCkilJAz5vkaKEumGqyPc3jcdDOf0My79QTqcBk9Dc6J9/6F02xtvJ/X96w2jfe9hu9bRVUsGtV2xWlVSlLHfqarExGbGXHk1tK7O/Z7GxuGnMwFxK3dw3NJFcNTsod63CwCKJMJ3+fBjL/p93MiHjT8W672m2pP4wUu/5yM33k45RIgGACJYcsy0JM3EB7f1U8KAPnHDHlPUNNuoGVCOAkDoOKI1qp4n3sGqJ7aTN82Kdzasgffjl/ClZtU/uacpn8vwLUKQ3vAFXGmUhZ7wtOdl3PwforkhGvq4YuDjbDp2jC2lAGBQJneHTOqZzVLTPTGAPyOkUJzprph3XD/oDdeG2uSQDG9be6S3rb3Y9taQ2JYhNRlRixe4olYthWKNOvPZE1kTP3XPYvZ63rLvrySOWeqCwSKo7cWTYO/SoWRR/qU88pNvAJNkXcmHDT8C+HP1J1H2uye5XddR6/u6iWjBFbFIWRWN3WaFBvyNoZgwRyiYfk2fgrmUg3KxENWUir2tg7Rk/Su0JnGjcK1+Umx94SDtdWsYFYlgpiknp3t16cIotSY9jIT2+eckhPZA0CXu4rgaNu3zOay/LaN2rdWKTrf3qGyLyZJy4rrJV44Mi5gL6DDThE9LUWCcvqroNOBt60DvK/8xNz74HXPHU8/A09rm+5kbku75n1Ihuy6h5j+9l+p/+x642loAOBm8Th79yV0YtpyT7p3Lh41PEtH7uzqQ8ouHEON00IExpxgTDLj06jim8ijeqdK4HimRcVnjrpk6CIWUgeW0kFrELLzNBMu+Zqz65CZanLBReMoeEVt/so22DnhEq2Q55XwUp0sfFXsgXQsfoX0Xhcrk+T6NZLTO884pT/PO61npLTqe6J3veK9WsMTGyml/2aMpyvf+uaDR3/U9dlP1T7cUD0WnJBQGJg4/ujmQ2O65AUs4Dlei9fs/poFtu84cFyI57hOf3QWh1AFwQPcaAVgIdCtKvnCmgVXA8d/5f9W85Gt/1XS6du8OnhOfSFsSk5EJnx8DAcYYlWYVWDAQoWJ3txfxcng71WiF2dYMyRxU6VVQIEIMopBNaXAgCnvJDsEakvqcyH6jhrIf2gLjb/aJw7XdOJEQCU+aFfFEwUdnugdd/U//vfLMosXRc4rtY3rqTRHWq69vVKzRWQBg33MAWldPoEvghrC0wpDoBfn9DN+uSUs+2RFTsbaotdWk6madRevfDmcdu/Kxa8tc3jO/GsNKy1GKHpdjDQDw/sPRoR/zhFWQZ1qQDOfR4zBmpMGQOhStNaZlufqOlxQgcZUOY0IbeTs1gJcR4UNILn8BnXsGg8+e2sgRYkB/FOC7c2bzkRs+KqyKghx/pzLB3uPhfQftImtA5xxXP29pPRqWtNSJoMODfbKJVfTRQt+utQAgBNrz4/n4h+ZBv2WePicpiietYqlt6a9ffd/fck4f6Kl6W+84HJaC2IxHf7HVkJq+CgA6fvYMHEcqwzFsUBCpqs3yk0Q7qTSKuLJdP+r4XGcZwuhZhQtKjBWzvv3lEffMW//dvQ0slaH0B5Yu6njlIKR9KcC7+Wj8spDTAdX13qsl+CnVQCnX3YSdecW0EhP3JZAOnfdVOCAqT8DZ1TI1mbFQwEx11MmNsgULoY+v2gAgI004sTCNO64rZdPV+TIvxcqjtqAPn+yuuuZLr54pO+qq2KZ3VYRl7rMe+8VWNWWY0E/9Br5poHB1vwNnewaA7CE5LmqDUG1QTW4IowLFHAnFnADFmAoE13twLMhEbtMno3cqc00qu9nrfd0e6X3VeUm4E43CiaS7bkfkwqHt9YbP3D0gKamJUz8YAVKyAemm9k0NkLKAwTeGHFTXHjb8Gxu4TPNo33n5edybmiZrb/gI9UdayV/yu4hQ6JLFVmDxYrj+dUDurGykcGXx+QUR5yIZuSIZLrixWzbBhH7M87Hawu5GybZ6KtlWT3gQAgaFanPj+dR7i3T9/XM4bdA1Ou7Mujd8ye3ku2zxIZG7dyec7T5RBo4DOA7SA3j85W9xH4RoBRn6IIweKGYBYYqEwZwEMmWA/K+P2M0m18/6z+bTMuxwV9WcJjQAwNVYQo2/6uasu3oAEc/WRR3Uv7eAQJ+c2i7RQ2SXwP1Y73murZWefuohLC4o4X3vu1GYDUaeSAvN/N6FYqHVzNt2V599Sw3ADBMuFXkAMzdSL52ULSiAGxljT/TqPLuqE7OrOhX8ZBtAyOiSpet2icF2Bw00RKGrInwLJvKJ27HPv5xtOSEOFAvJsYAH0D2Ad1T6thsQrRCiB2RwQDFLqCYTVEsshCEVpIYlt/tcQesapWA29Knp9gTq37+NY8pXwpIzB/17AWDO1JvXA8DDxj3yZi5Xsr0fr66kb1V/T6YvWoJtq99DmYriNzHItKKEVuYk8ZY/78Ilmo6zptvsCyLKRDwyRTwkvHyAO4SDO3kBdP/l+QxKJENkIsfNBsfNBrLWgqTexK6+BvTV2ETrfrNs358BW3MeQm0vTf5O1/vAk/v1IcIEyBxImQNogO4ERhl5HgAprSClD4rBBcVMUMwWKOY4CFM66Dy26/IDrdcnJYh8MuzsJ9IQUw6QIQ5D73CSQGiw2ES6DvwKG/l5Mei9e/9OWn9wDycvvwxbFi+nHH/EzkikNZ99n6z/9wHqOtGMsNTpBQkBAy2kDAalwwEvdnA7iLswHzLA7qNQZlFEwixEJIDTlwz7L9zP7oE69J3qE50HFdl5LA69tZnwDE5iAf0Y+2mUoSm1mwAAFS5JREFUik0NZAVLK1gC0gt4x6a9cB9I7QHEAIRqg2KUUCxGKOZYKMYMCPWcNubUHROk5Uj3WBkD9/QJPYKN5JDAY9jIT5LN+9Ftr9MXtr/JGeVLsW3FFSJRVbnY93RFiJxrypGzppT2vbpPNzd1UzhkW4MHIQJGLKNMgDIxCDe2cysM3Iv5kMGGGCmGTNELkDIXnDL3TGiF9Xb2uhox2GoTPScYXZVG2X0iFYMts+Fba3rBLsQoFqzHAjqge4cs/Oj9MTcgOiFEB8hgH014dRaEMbzdvUZ9Tr5/jEvwnzwfd0rYSB4d+DWAX6sbvFfu2YH79+6Qy0rKsHv11YQoKxbD5zEdaebym1cIDDp5z6sHENHchXNL7CFEwYQVlANQDvrhxB7ugspdmAs5BdUgUlLIGJmC+HxwfD6Qf+0I2Z1elzb1QscLByZAzoKUs067NEET3pABYQiPhR8dnmUg2Ob1U4T2kOF1AK/z/a78ysPKvZVH+M7ERNG49jrZmJVD80byQwAgykKXfHg54PTQgV3HpetQAxZLOcU2pdNDDCxYOWy5XfDybnTToOzAHHinrsI0DAtDmXKX5EVzC078/mdfd8TFRGd3dPbUfvATX02pO9UadErtOUQAwvMAoLRDKL0ggxOqmaCYTFAsiVDNAUSERlWp+C/BOut41Fwjgc/jfv5WV7d214u/xceMBhblK+jt8mUUbTLx/JHJWYy8cO08wpp5/7+9Mw+yq6rz+Pecu769+/Xe2TtJJ51A0kGSCCHElCg66DgMQkp0kBlrLBHBkplxnQFUoLRUVFBQxylmrFHAEXFAEFCJhE0CikNIYpJO7+nt9fL29+5yzm/+eL28pNPdr/fu2J+qV6nqvu/e2ze/+zu/81vRc7KTjjx/GLXR9AwMaZwaJjS2A5UAr4SES4cRZxH0oFKmseHMAE5BjNIphREuDvY//uOvlXCeqx6qKC8Jv/DYfZ17//bm5uMn21ZP+j7mFRYAZABSAnAAkWcjM9YJT1U7jKLtwz/S8vVavkDLM54mm+PV75usPzdAE1/N3mJve3k/PvjyftpXUsqbLnmHbK5Zz9YPFhWAAeXrqlj5uiqIeIoOvnQC7FgbtkmatxWbQ2WbEQYQBjihB1kcp35w6sVGuAU2JM/rvJQ3931C0d7313uPcc5O6yrEFV61/+f3LFKhHgOiKqQ7qgD5CozwTgDgWl6qN8kFoKHPxt366xJ4HbfTpwci7p7HHmLv9xYBoYDs3LGLDayuZRsUjtUAlKCP7XhXPXD5VkS7ojjy+z9TuDmCjRNdYlZhKIcH5WwZwJZBQuIwxRFhEYRlAnWgMc2lkb3jcPxmYkWfzp59A39OCjUAZLpXwMjpCGaO1eeTTtfQjGZhUzhZbmfSBfYD2B+6mzwDUbr40Qf6b2VGiK9cww9teyvrXVWDSs1gGxlDUVUxLr7yIgYh0Xi8C62vN8jl3dF5H0HGwbGZFQEoAjiQgoP/Qwwp9FO5TLJa0OhEMHIKr+x68NHfbr390x9pMA191N96Tgo1UTVAWYCZTMsvNud54ajRA67mX6DzaL+FZQD8lq3b919gvPobD/9w4GeHFOXHj/OszVnrxvNx4ry3kFpcwi5QOGrqqlFTV81BhN7+FDU1dIAOtbKaRJpmpJxoGvig4UKUAihl4EAMNo4hhgxMpg9ZGJMRaNt29Euu+HjopSfvb9V1bVTSP1d41f5H7+1559W3nDx8rHF6bZEXDhIAuJ6noVlemitT7dOOJbYANPSZrLu6DMCyNSvKWnetYVt3rZEAJLIuyzx9nPU//CueeLQDbeVrkNm6HYnqFXyZqtL6Ej8rLakFdtaCHIHjPVF0NXRCa+jAmnh22t6J6RKCjh0oA+Cl4SRfcoZs6MIc0qe6ImW7rrih86Vf3d+qqWcRas7Kn/mfu3GOCTXYWLUHekkEQBVAFgADoPKFJ9Dg2wDgrVtrcyXqg5gqed63iba9b1PuBY0k0ffIYeX4z59Cz6kMnNUbEK3dAqeykldrGtYuK0HtshJgz3mAJLRFk9Tc2MOcY6dkZU+UbcRkQ9YzBMvzjMhJaOgh2jsjVbv+6uMdLz55X5umaqNcdueiUHMj34bO83L41uZi4m60BUAtwE4uPIFm2AoCdm/fPG4bgjI/Sj62U1z0sZ25jVVnkvXsP8Fbf32Aeo73IW5Uwl27gWeqV5HXH2QrwwG2OxwALlzLAWAgkaGG1gjSxzsQPtXP1jru7M0DP4ORTaEztWLyto6e6kvec2PHi0/c36YqyphCffk1t5x888+LX6iZnre/psHVjDFB/k01AMCSh9oB1DLQEwtOoDlhKwHYsnnVpKZyVfmp/NptovzawXbYQkIc6mJNz7yKrv2NakMUaCqqhlxRw5zqFfD6A2zV5pWo3JxbA0hI1hJLo6OjH3ZjN4VORVCTdTHzOQt568JkbOgzaW3vrt51xQ0dL/7y/jZVPbtQP/3w3ezyfYtfqJlhEEYUAQEAVbzvBYDvgdN/AplTOwFkpcr+fcEJNAH1ALC8qmRadq/CodRX07r6aqz79NtGBKcjjp7njystv2+lY12u8iYrIQpWMK1yOfOFQ6gJ+1Fx3koGAOKFbnqiU7BSN0VZKwktE0exncIK6RY202QiRmzoqdHa3l19yXtv7Hjh8e+2q6oyqmUDV1jZ0w/fjcUu1MzQBQYdGEz199Oyq05CL9sDK3KUDTwbBOAjwr/hT99qXlgCve7dBoANuq5ldU2bkT4YZ1IdRPm+raJ831ZgKPPt6i/97nePncwUcbO0pajUOL6ylrmVa4KcWUnBN9UaZshc5QkrFUWDWoII3cKhTmEhkU0yWHHy2wlUOjYqChhZMZioBxckh57/lLOUWto6q/deeXPbc7+4t5Mro+sFucLKnnr4G/LtV93cfKxhcbr0uGkMC7Ss/oAHyW7Bep8+AKf/IgAaY3iQ3vz2ncACc9tBhs4HJ7V+46oGYO4CJ12RmMlT8fVI9SLaB0SPAW8AEC37YwDlmlmoqq1VlnUbNSsjxvrVKX3tCqktr9aD4VARqzJWAIOdgAgxItbhWhR1M2RbacadjAzaWR5w06gc6mlMkDaGnv80k+4amtpX7L3yk63PPvrtLkXho1Y2ReEVTz749T9vuOha13XFwvo/LwBu6MOuOhZ53McymaF8D5tAt9Oh8JcxF8lJk4ZTPQDsurAugjkU6GjSHiMXeqQdGLmubrd3rrDbO1ckDrwy6kglFLDUsuKIVlUe1aoq0npVucuXlXNvSVjhYR8Unw/M0NKiG0QWACltYOYKHI43tq7c99FbD//sP+6owFlCj16PubFu/aqTh44uPtOD6Uae75kYgJOM8JiUdD+O3nMi/9gFJdAcuQ3hzm0bZjXhPZa24+3diUhzVzLW0BHLxJPWWSKNRChsUCgAQMQShoglllsNreO2H6v4zBeaPBs25OrUZ5CaVdWtP/nebSbGjqPLSF90ThPzZwrmMYfXsMrrrt906hN1fWMtagtKoImxehChbv3yKT142xFWbzwbO9WT7mvsjCebuuLZ5q64bOtJ8Y5I2hfL2CHHEWVECAITeDByerTQmeQFw2QuXEvIa+FF08v037Vzy5s//cGXKrjCRgVbhnjp4KEXu3r6Z22c82zC87LttM0bx/V1LiSBZiA6HwBKi4OjtFwsYUfbIom+lu5k7GRnLNPckXCPtcd4ZCBjRtO238q6JYJQCqB88DM9SMyKQINkbtMo5Iw0Uf/wNe966Su33lCPccyXAy+/ceDaj9027eFE8wUztOEX3jXG33TPr0C/7QHT4PYywXg1ifQGlup9nWke+f7bnlY7erPNsVTWn7FEiStkKYDB1J+5Yga79ueflVEuSUm6IybHJLo65XPX5/7xwN9/8D2XYOyop/WN+x587ev3PTQjTXLmDUUZFmhKj/+s5lygtXd870KS7MsgvAXMLsutHxJMMYHgchCAg0cjc31boyApZtTGHUbmNLR0x+kzNwGKwsUjD9zxws4LNo/ZX0NK6rvuE3d0//bAa4tWMw/B8zo/ePSFpKHf/p0Skuw3AEJT00lzSL4GnUmGcjnE1MKEXq+ZOvC/331zWVXpmMKcztjH9l75iUBre/emsY5ZVCgjKaOuSI3b9GdOBVqD9kECFkWTE8q51WbhxLkNIInTVoCCNoWVZeHuF564v8/nNXeOdUxDU/vL77z6n+oz2eyC6q0xLfLm0gjtrI1NRg6d/bsZgUAfmMvrTQsSMzdXJf+0Q305hJhUZtL5G9eeePXXP3R9XnMsrSt+8sgzz+9+740XnVPCDIDxETElzhaGDW1edl+NS2xMzbLgIHd2fOFisCZuEs3FdF2zn3zoa4aqKqPamAEAEcVv/uw3G372xHMFueV2XFB35KHvfxEej1ELICslJV3hpm3LTWcsy0qlsnY8mXGisbiMxpMUHYix3v4E7xuIapH+mNHbFzX6owlPNJbwxeJpf9ayJt/qYTLkbQoNZ4HY0K5UPjDV3fxswhWeNryarWpqWvWoQjPVlGqqpDpGV/dr7X+cdlz6DMwi/+AzL/y8q1dW9qiqclYfs2U7ze/e9y84eqJpjOGUp6PreubnD9xVpCh8qJLezznz61yDrmnw+z0oKyn41oZwiCieTGa6Pnfn97OP/PJ3kx4BOB4sz8qQ6vgmx9zZ0Awzam6oppr0FXn7fcVmylvkSXtDHtsTMl1P0CO8RR7yBHSYflPRfZqqe3RT1RVT1biHAIUrSjC3eLEgcv5bL0a7BOuAD83kLQMAXm6Ub5yKEkjKfB09rnQ3tXZWSikHOOenTSXo6h74496/uXFdNJEqOBBVf966RkXhM93MR2OMlQQC3pLvfOVT1sE/Hu1q6+iesSohyns+0l0AGlrb+72thAk7IslA2Nvjr/D3hioD6WCp3wqU+d1gmZ+8YY/mCZiG4TE8qs6KuKqEAfgHP1NkpHCECHEiaZGQtnQpKVwhpCNsKSQ5ljO8ebPTWSndwZo2SSydSI9rBysqVwyveVqDwXjcH4DuBxRecFjdsV31U1+45+S37vrkRsaYH4B49sAfXrrupjt2CSEntQ861dFTgpzBM1v7J+Paqy5r+Oq9P54xgWYkR/o9LAQbmunsmkCxrzNUFYwULy9KhlcU2+HqAPlLA5qv2AxohlqsqEoFgMrBT8EQKEWu7HcdmXKydsZOW5aVyDiZWEqm+1NI9aV4si+upfuTRqo/6UlHMx5hO7qVzHjsjO0XjlAxhwGb8o/sO+rdshFc0yf1Mv708f0XPvPca7FLL97ypyPHW0obGtunFMY+1dVb+cxzB/e/c8+OvVP5fkHX6IzM6AAiymtmqc21hr6pj4IeXX6IGG1HblztSgDLkevyX8gMj7SUYkDYst9OWul0LGWnBhJOMpJw46cG9Fh31Jvojhqx7pg31ZeocC03CEyh/9x8wXKd95muTnp1icYToceeerF+urfw4Rvv3Hvpzi2H33P5rt7ysjALBX3weU0l4PMpXq9hmLpu6IZmqIpiqgr3gbEQCpwgnEikjzz8i2e3Tfce86F8Da3OoUB/JmFtlkw8Qzhr6y5buiJiZ53+9EAqmeiJOgOtfehv6dUHWnt90c6BcLIvUexk7CGb9qw7+sUOuU4WAJhujNi9nM+5m+3AK29sPvDKGwUf7/WY2UDATAV8/nRJOJAqCgbs4lDALg75nXBx0C0Jh+hkc4f2w//+5QWO686oXDFiwy5U6c7VpnDdTUakpe+Lkqgp1hE9EW8fYL3NXZ6Btr7AQEc0nOyNl4NoGc5RQS0UkbHiAMBNI8xNEzKbBaAUg7F2EE158u1sk85kzXQma3YjWpI3v35OIKIRgVbmSEPzQOA/H/i771w1U+c7V7FaOhK4+C0AwDx165F6/VDuF3rxCVj9C1ag55lhk0Pn45s+M7PTveDzWwi4ZkbOdY6TPXJiuBl4YM+ukQm8nopLoJgH5uWmFi4KADCiYU+TFHOgoRlwF+apcctiQ8QTF4hYskUJ+VeZtTV+75ZNIv3GEQWMaQjWXAo7ehBWPAkSKiA0kNRBpAPkAUkfQIHh+sVzmz6AlQAAYcSGpgmCc9MX6PovXAyiK6Z9nr8czN4fPXKi4qYPrwLAyj56nRP5/o9E+tCRnF9aL9oBfUIvogOSCUg3CbgpCJEFXBtC2oArQIIgBUAuh5QKIDUQ6WDCzE0koACAAOY7H348dP9hAJcCgOIzhwotrKYu/fB4X5v2H8SYvLNAj84Sg2Qamvemj5541Vu3fjvj3Cy/4XrKHD3RE/vVb8qzjc2AnDAsroHxMBQ9DOgFDLgeA6IEyE2CKAUSWZBjQ0oLkALSJUA4ucFCQgFJCSk5mNQhSQGTKiA9IDJAMADyDa4c039JuHYQvhU7AID7fQPc5xsqmG7ENWzcYNb0JHHbv17GIH89rXP8xcL6Kz/1Dx3m6uXn5f9UOnbS7e7rcyK9MbezO+N09VhuPKHKeIJEImmKVBrIpeBy5AJCQ/8uECgDkllINwGClXsp3CyktEEkAEeAhABJghQ818BccpDUwdQsjJAPevF2DMpm1Wdvft5YuXwoiPTlpkuNW8e7+rQEmm37/FMALp/OOf6iIZYseu/b/lB02e7dp2XgTEwKubl8FoA0AAEgTlIojOBKV1ggMBIOwREWSamScF2yHAkpFHIcKS0XkEKVliXIthQIyUU6A7IcyExGJddhMpXWSUhG6YwphWAynfZBEEQ6GwAJJjPZWcttZ6pil9/wkZc9deuGChn6SDjnNe/1d437velclG/73E8IbPHkOC9QmGkcDr19VyK4e3s995gzX5g7u0gQxQEQiBIkCSTcFACQ5WYAQNqWBZKQWcuBkExmsi6E4JTJSOk6nDJZSFdwSmYYdAX66pWup27DeqbwoZiFC6KrmvaYj010M9MzOa6+WkHz2lXIuVIWRSXKQsa7bA1V/vP1q8HYbmLYnCvXoiByVrKOkRD/kMlhAhMMDF38xCXD9S27jUcLOXhpN3eOsPJ5KgYAYmkPI8XUXHCoPAQAUjIf40KXBGUwZRYMzE+ABik14jk3ICMEGUGRjOmMZO7l4awIBAaCOTIyOXctBngo91LlKzQfJtGgZxwyBDykkLjt5B5vW6FfWhLoJWaHn5KysirXzEdl2YBLTFUYNE7cDwCuEEFFYQokdOIs9/IQKwIABtHIdfPVhrey+Lzd/xJLLLHEEkssscQSSyyxxBJLLLHEvPL/AtdXI/iyaEYAAAAASUVORK5CYII=';
function reportDisplayCell(value,heading){
 const text=String(value==null?'':value),head=String(heading||'').trim();
 const statuses={ACTIVE:'نشط',INACTIVE:'غير نشط',PAID:'مسدد',OPEN:'مفتوح',PARTIAL:'مسدد جزئيًا',OVERDUE:'متأخر',PENDING:'قيد الانتظار',INCOME:'إيراد',EXPENSE:'مصروف',CANCELED:'ملغى',CANCELLED:'ملغى',APPROVED:'معتمد',DRAFT:'مسودة'};
 if(Object.prototype.hasOwnProperty.call(statuses,text))return statuses[text];
 // Only format values explicitly presented as currency; never round dates, counts, or references.
 if(/ج\.م/.test(text)){let out=text.replace(/(-?\d+(?:[.,]\d+)?)\s*ج\.م/g,(_,num)=>money(Number(num.replace(',','.'))));out=out.replace(/ج\.م\s*(-?\d+(?:[.,]\d+)?)/g,(_,num)=>money(Number(num.replace(',','.'))));return out;}
 if(/(?:تاريخ|وقت)/.test(head)&&/^\d{4}-\d\d-\d\dT/.test(text)){
   const d=new Date(text);if(!Number.isNaN(d.getTime()))return displayDateTime12(d);
 }
 if(/(?:المبلغ|القيمة|الرصيد|المتبقي|المسدد|المدفوع|الإجمالي)/.test(head)&&/^-?\d+(?:\.\d+)?$/.test(text))return money(Number(text));
 return text;
}
function reportDocumentHtml(r){const visible=(r.viewMode!=='detailed'&&Array.isArray(r.groupedSections))?r.groupedSections:r.sections;const sections=(visible||[]).map(reportSectionHtml).join('');return `<article class="report-paper ${r.reportClass==='service-subscribers-paper'?'service-subscribers-paper':''}" dir="rtl"><header class="report-head"><div class="report-brand"><img class="report-logo-img" src="${esc(APP.ctx?.branding?.logoUrl||REPORT_LOGO_DATA_URI)}" onerror="this.onerror=null;this.src='${REPORT_LOGO_DATA_URI}'" alt="Tower App" width="48" height="48"><div><strong>${esc((r.building&&r.building.name)||'Tower App')}</strong>${((r.building&&r.building.name)&&r.building.name!=='Tower App')?'<span>Tower App</span>':''}</div></div><div class="report-title"><h2>${esc(r.title||'تقرير')}</h2><p>${esc(r.subtitle||'')}</p></div><div class="report-meta"><span>تاريخ الإنشاء: ${esc(r.generatedAt||'')}</span><span>أُنشئ بواسطة: ${esc(r.generatedBy||'')}</span></div></header><main>${sections}</main><footer class="report-footer"><span>${esc(r.footer||'')} · © ${new Date().getFullYear()} Islam Sallam. All rights reserved.</span><span>Tower App V${esc(APP.ctx?.version||APP_VERSION)}</span></footer></article>`;}
function reportSectionHtml(s){if(!s)return'';if(s.type==='stats')return `<section class="report-stats">${(s.items||[]).map(x=>`<div class="report-stat ${x.emphasis?'emphasis':''}"><span>${esc(x.label||'')}</span><strong>${esc(x.value||'')}</strong></div>`).join('')}</section>`;if(s.type==='note')return `<div class="report-note ${esc(s.tone||'info')}">${esc(s.text||'')}</div>`;if(s.type==='table'){const cols=s.columns||[],rows=s.rows||[];return `<section class="report-section"><h3>${esc(s.title||'')}</h3><div class="report-table-wrap"><table class="report-table"><thead><tr>${cols.map(c=>`<th>${esc(c.label||'')}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.map(row=>`<tr>${cols.map((c,i)=>`<td>${esc(reportDisplayCell(row[i],c.label))}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${Math.max(1,cols.length)}" class="report-empty">لا توجد بيانات</td></tr>`}</tbody></table></div></section>`;}return'';}
// V2.4.33 — Structured, read-only companion export; it is NOT a backup or atomic ledger snapshot.
function reportStructuredExport(r){
 if(!r||!Array.isArray(r.sections))throw Error('REPORT_DATA_UNAVAILABLE');
 return {format:'tower-report-readonly-v1',isBackup:false,isAtomicSnapshot:r.isAtomicSnapshot===true,
  report:{title:String(r.title||''),subtitle:String(r.subtitle||''),generatedAt:String(r.generatedAt||''),
   buildingName:String(r.building?.name||'Tower App'),version:String(r.version||'')},
  caveat:r.isAtomicSnapshot?'لقطة قراءة موحدة لأموال العمارة فقط؛ لا تشمل حساب الحارس ولا تصلح لاستعادة البيانات.':'تجميع للقراءة فقط؛ المصادر مستقلة وقد تختلف أوقات تحميلها؛ لا يصلح للاستعادة.',
  sections:r.sections.map(s=>({type:String(s.type||''),title:String(s.title||''),tone:String(s.tone||''),
   text:String(s.text||''),columns:(s.columns||[]).map(c=>String(c.label||'')),
   rows:(s.rows||[]).map(row=>row.map(v=>String(v??''))),
   items:(s.items||[]).map(x=>({label:String(x.label||''),value:String(x.value||'')}))}))};
}
async function downloadCurrentReportJson(){
 try{
  if(!REPORT_UI.current)throw Error('REPORT_DATA_UNAVAILABLE');
  const payload=reportStructuredExport(REPORT_UI.current);
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json;charset=utf-8'});
  await downloadBlobSafe(blob,`Tower_Report_${cairoDateStamp()}.json`);
  toast('تم تنزيل بيانات التقرير للقراءة فقط؛ الملف ليس نسخة احتياطية.');
 }catch(e){toast(errText(e),'error');}
}
function reportText(r){const out=[(r.building&&r.building.name)||'Tower App',r.title||'',r.subtitle||'',`تاريخ الإنشاء: ${r.generatedAt||''}`,''];(r.sections||[]).forEach(s=>{if(s.type==='stats'){(s.items||[]).forEach(x=>out.push(`${x.label}: ${x.value}`));out.push('');}else if(s.type==='note'){out.push(s.text||'','');}else if(s.type==='table'){out.push(s.title||'');out.push((s.columns||[]).map(c=>c.label).join(' | '));(s.rows||[]).forEach(row=>out.push(row.join(' | ')));out.push('');}});out.push(r.footer||'');return out.join('\n');}
async function copyCurrentReport(){if(!REPORT_UI.current)return;try{await navigator.clipboard.writeText(reportText(REPORT_UI.current));toast('تم نسخ نص التقرير.');}catch(e){toast('تعذر النسخ التلقائي.','error');}}
function towerOpenPrintWindow(){
 const w=window.open('','_blank');
 if(w)w.opener=null;
 return w;
}
function printCurrentReport(){if(!REPORT_UI.current)return;const r=REPORT_UI.current,w=towerOpenPrintWindow();if(!w){toast('اسمح بفتح نافذة الطباعة.','error');return;}w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc(r.title||'تقرير')}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet"><style>${reportStandaloneCss()}</style></head><body>${reportDocumentHtml(r)}<script>window.onload=()=>setTimeout(()=>window.print(),300)<\/script></body></html>`);w.document.close();}
function reportStandaloneCss(){return `*{box-sizing:border-box}html,body{margin:0;background:#fff;color:#132033;font-family:Cairo,Arial,sans-serif;direction:rtl;color-scheme:light only}body{padding:12mm}.report-paper{width:100%;max-width:190mm;margin:auto;background:#fff;color:#132033}.report-head{border-bottom:2px solid #011b45;padding-bottom:12px}.report-brand{display:flex;align-items:center;gap:10px}.report-brand strong{display:block;font-size:17px}.report-brand span{font-size:10px;color:#708198}.report-logo-img{width:48px;height:48px;object-fit:contain;display:block;flex:none}.report-title{background:#f7f9fc;border-radius:14px;padding:14px 16px;margin-top:12px}.report-title h2{margin:0;font-size:19px}.report-title p{margin:4px 0 0;color:#708198;font-size:10px}.report-meta{display:flex;justify-content:space-between;gap:10px;color:#708198;font-size:9px;margin-top:8px}.report-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin:14px 0}.report-stat{border:1px solid #d9e3ed;border-radius:12px;padding:10px;background:#fff}.report-stat.emphasis{background:#eef6ff;border-color:#b8d5f2}.report-stat span{display:block;color:#708198;font-size:8px}.report-stat strong{display:block;font-size:13px;margin-top:3px}.report-section{margin-top:14px;break-inside:auto}.report-section h3{margin:0 0 7px;font-size:12px}.report-table{width:100%;border-collapse:separate;border-spacing:0;border:1px solid #d9e3ed;border-radius:11px;overflow:hidden;font-size:8px}.report-table th{background:#011b45;color:#fff;padding:7px;text-align:right;font-weight:600}.report-table td{padding:7px;border-bottom:1px solid #e7edf3;text-align:right;vertical-align:top}.report-table tr:last-child td{border-bottom:0}.report-empty{text-align:center!important;color:#708198}.report-note{margin-top:12px;border:1px solid #d9e3ed;background:#f7f9fc;border-radius:10px;padding:9px;font-size:8px;line-height:1.8}.report-note.success{border-color:#bfe3d1;background:#f0faf5}.report-note.warning{border-color:#f0d99b;background:#fff9ea}.report-footer{margin-top:18px;padding-top:8px;border-top:1px solid #d9e3ed;display:flex;justify-content:space-between;color:#708198;font-size:7.5px}.brand-mark{display:inline-block;background-size:contain;background-repeat:no-repeat;background-position:center}.service-subscribers-paper .report-title{padding:17px 19px}.service-subscribers-paper .report-title h2{font-size:19px;line-height:1.6}.service-subscribers-paper .report-stats{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.service-subscribers-paper .report-stat{padding:13px;min-height:68px}.service-subscribers-paper .report-stat span{font-size:10px}.service-subscribers-paper .report-stat strong{font-size:15px}.service-subscribers-paper .report-note{font-size:10px;padding:12px;line-height:1.8}.service-subscribers-paper .report-section h3{font-size:14px;margin-bottom:10px}.service-subscribers-paper .report-table{font-size:10px}.service-subscribers-paper .report-table th,.service-subscribers-paper .report-table td{padding:10px 8px;line-height:1.5}.service-subscribers-paper .report-table tbody tr:nth-child(even){background:#f7f9fc}.service-subscribers-paper .report-table td{overflow-wrap:anywhere}.service-subscribers-paper .report-footer{font-size:9px;line-height:1.6} @page{size:A4;margin:10mm}@media print{body{padding:0}.report-paper{max-width:none}.report-table{overflow:visible}.report-table thead{display:table-header-group}.report-table tbody tr{break-inside:avoid}.report-section{break-inside:auto}.report-stat,.report-note{break-inside:avoid}}`;}
async function ensurePdfLibs(){if(window.html2canvas&&window.jspdf&&window.jspdf.jsPDF)return true;toast('مكتبة PDF لم تكتمل بعد؛ حاول مرة أخرى أو استخدم الطباعة.','error');return false;}
// V2.4.32: align PDF image slices with visible table rows and section boundaries.
// Financial amounts and the original report DOM remain unchanged.
function reportPdfSliceEnds(source, canvasWidth, canvasHeight, maxSlicePx){
 const bounds=source.getBoundingClientRect(),ratio=canvasWidth/Math.max(1,bounds.width);
 const markers=[...source.querySelectorAll('.report-head,.report-section h3,.report-table thead,.report-table tbody tr,.report-note,.report-stats,.report-footer')];
 const edges=markers.map(el=>Math.round((el.getBoundingClientRect().bottom-bounds.top)*ratio)).filter(n=>n>0&&n<canvasHeight).sort((a,b)=>a-b);
 const ends=[];let pos=0;
 while(pos<canvasHeight){
  const limit=Math.min(canvasHeight,pos+maxSlicePx);
  if(limit===canvasHeight){ends.push(canvasHeight);break;}
  // Cut after a complete row/section, but avoid tiny last fragments.
  const eligible=edges.filter(n=>n>pos+Math.round(maxSlicePx*.55)&&n<=limit-3);
  const end=eligible.length?eligible[eligible.length-1]:limit;
  if(end<=pos)throw Error('INVALID_PDF_PAGE_BOUNDARY');
  ends.push(end);pos=end;
 }
 return ends;
}
// V2.4.39: PDF tables move orphan headers to a fresh page. Fixed A4 width, visible row-level pagination, and repeated thead.
// V2.4.39: paginate the DOM before rendering; never slice a tall canvas through a row.
// Each continuation page repeats its table heading and thead.
function reportPdfPages(source, host){
 // PDF uses a fixed A4 content width, independently of the preview/modal viewport.
 const width=718;
 if(!width)throw Error('PDF_REPORT_WIDTH_MISSING');
 // Use the usable A4 height while retaining 6mm safety for canvas rounding (PDF image cap: 268mm).
 const pageHeight=Math.floor(width*262/194);
 const pages=[];
 // Continuation pages must identify the building and report without repeating the
 // full first-page title block. Text is copied from the same report DOM, not recalculated.
 const brandName=source.querySelector('.report-brand strong')?.textContent?.trim()||'Tower App';
 const reportName=source.querySelector('.report-title h2')?.textContent?.trim()||'تقرير';
 const createPage=()=>{
  const page=source.cloneNode(false);
  page.classList.add('report-pdf-page');
  page.style.width=width+'px';page.style.maxWidth='none';
  page.style.margin='0';page.style.padding='10px';page.style.minHeight='0';
  page.style.boxSizing='border-box';
  if(pages.length){
   const head=document.createElement('div');
   head.className='report-pdf-continuation';
   head.dir='rtl';
   head.style.cssText='display:flex;justify-content:space-between;align-items:center;gap:12px;padding:4px 2px 8px;margin-bottom:10px;border-bottom:1px solid #d9e3ed;color:#132033;font-size:11px';
   const identity=document.createElement('div');identity.style.cssText='display:flex;align-items:center;gap:8px';
   const originalLogo=source.querySelector('.report-brand img');
   if(originalLogo){const logo=originalLogo.cloneNode(true);logo.style.cssText='width:25px;height:25px;object-fit:contain';identity.appendChild(logo);}
   const brand=document.createElement('strong');brand.textContent=brandName;identity.appendChild(brand);
   const title=document.createElement('span');title.textContent=reportName+' — تابع';
   head.append(identity,title);page.appendChild(head);
  }
  host.appendChild(page);pages.push(page);return page;
 };
 let page=createPage();
 const fits=()=>page.getBoundingClientRect().height<=pageHeight;
 const newPage=()=>{page=createPage();return page;};
 const appendWhole=(node)=>{
  const copy=node.cloneNode(true);page.appendChild(copy);
  if(!fits() && page.children.length>1){copy.remove();newPage().appendChild(copy);}
  if(!fits())throw Error('PDF_BLOCK_TOO_TALL');
 };
 // The report body is wrapped in <main>; paginate its sections, not the whole wrapper.
 // Keeping <main> as one block caused PDF_BLOCK_TOO_TALL for real financial reports.
 const blocks=[...source.children].flatMap(node=>node.tagName==='MAIN'?[...node.children]:[node]);
 for(const node of blocks){
  const table=node.matches&&node.matches('.report-section')?node.querySelector('table.report-table'):null;
  if(!table){appendWhole(node);continue;}
  const rows=[...table.querySelectorAll('tbody > tr')];
  if(!rows.length){appendWhole(node);continue;}
  let chunk=null,chunkBody=null,chunkRows=0,continued=false;
  const beginChunk=()=>{
   chunk=node.cloneNode(true);
   const heading=chunk.querySelector('h3');
   if(heading&&continued)heading.textContent=(heading.textContent||'')+' — تابع';
   chunkBody=chunk.querySelector('tbody');chunkBody.replaceChildren();
   const wrap=chunk.querySelector('.report-table-wrap');
   if(wrap){wrap.style.overflow='visible';wrap.style.width='100%';}
   const cloneTable=chunk.querySelector('.report-table');
   if(cloneTable){cloneTable.style.minWidth='0';cloneTable.style.width='100%';cloneTable.style.tableLayout='fixed';cloneTable.style.overflow='visible';}
   chunk.querySelectorAll('th,td').forEach(cell=>{cell.style.overflowWrap='anywhere';cell.style.wordBreak='normal';});
   page.appendChild(chunk);chunkRows=0;
   if(!fits() && page.children.length>1){chunk.remove();newPage().appendChild(chunk);}
   if(!fits())throw Error('PDF_TABLE_HEADER_TOO_TALL');
  };
  // If a single logical row is taller than an A4 page, split only its text into
  // continuation rows. Never crop a rendered image through the middle of a row.
  const splitLongRow=(row)=>{
   const cells=[...row.querySelectorAll('td')];
   const texts=cells.map(cell=>Array.from(cell.textContent||''));
   const maxLength=Math.max(0,...texts.map(t=>t.length));
   if(!maxLength)throw Error('PDF_TABLE_ROW_TOO_TALL');
   const candidate=row.cloneNode(true),candidateCells=[...candidate.querySelectorAll('td')];
   chunkBody.appendChild(candidate);
   let low=0,high=maxLength;
   while(low<high){
    const take=Math.ceil((low+high)/2);
    candidateCells.forEach((cell,i)=>cell.textContent=texts[i].slice(0,take).join(''));
    if(fits())low=take;else high=take-1;
   }
   if(low<1){candidate.remove();throw Error('PDF_TABLE_ROW_TOO_TALL');}
   candidateCells.forEach((cell,i)=>cell.textContent=texts[i].slice(0,low).join(''));
   chunkRows++;
   const next=row.cloneNode(true);
   [...next.querySelectorAll('td')].forEach((cell,i)=>cell.textContent=texts[i].slice(low).join(''));
   return [...next.querySelectorAll('td')].some(cell=>cell.textContent.length)?next:null;
  };
  beginChunk();
  for(const row of rows){
   let pending=row;
   let fragments=0;
   while(pending){
    if(++fragments>500)throw Error('PDF_TABLE_ROW_TOO_TALL');
    const copy=pending.cloneNode(true);
    copy.querySelectorAll('td').forEach(cell=>{cell.style.overflowWrap='anywhere';cell.style.wordBreak='normal';});
    chunkBody.appendChild(copy);
    if(fits()){chunkRows++;break;}
    copy.remove();
    // Never leave only a table heading on the previous page.
    if(chunkRows||page.children.length>1){
     if(!chunkRows)chunk.remove();
     continued=true;newPage();beginChunk();
     continue;
    }
    // Here the heading fits on a completely fresh page, but the row does not.
    pending=splitLongRow(pending);
    if(pending){continued=true;newPage();beginChunk();}
   }
  }
 }
 // Never export an empty page (e.g. when the source contains an empty footer).
 for(let i=pages.length-1;i>0;i--){
  if(!pages[i].children.length){pages[i].remove();pages.splice(i,1);}else break;
 }
 return pages;
}
async function buildCurrentPdfBlob(automaticReport=null){
 if(!automaticReport&&!REPORT_UI.current)throw new Error('NO_REPORT');
 if(!(await ensurePdfLibs()))throw new Error('PDF_LIB_UNAVAILABLE');
 const host=document.createElement('div');host.className='pdf-capture-host';
 let source=document.querySelector('#reportHost .report-paper');
 if(automaticReport){host.innerHTML=reportDocumentHtml(automaticReport);source=host.querySelector('.report-paper');}
 if(!source)throw new Error('NO_REPORT_DOM');
 document.body.appendChild(host);
 try{
  // Keep the report disclaimer, with version/copyright printed once by the PDF footer.
  const pdfSource=source.cloneNode(true);
  const footer=pdfSource.querySelector('.report-footer');
  if(footer){
   const disclaimer=(footer.firstElementChild?.textContent||'').split(' · © ')[0].trim();
   if(disclaimer){footer.className='report-note';footer.textContent=disclaimer;}
   else footer.remove();
  }
  host.replaceChildren(pdfSource);source=pdfSource;
  await document.fonts.ready;
 // Prefer full-size text. Only retry a denser layout if it removes a nearly blank trailing page.
 let pages=reportPdfPages(source,host);
 if(pages.length>1){
  const last=pages[pages.length-1];
  const lastRows=last.querySelectorAll('tbody > tr').length;
  const lastSections=last.querySelectorAll('.report-section').length;
  const lastHeight=last.getBoundingClientRect().height;
  const nearlyEmpty=lastRows===0&&lastSections===0&&lastHeight<210;
  if(nearlyEmpty){
   pages.forEach(p=>p.remove());
   host.classList.add('pdf-compact-trailing');
   try{
    const compactPages=reportPdfPages(source,host);
    if(compactPages.length<pages.length){pages=compactPages;}
    else{compactPages.forEach(p=>p.remove());host.classList.remove('pdf-compact-trailing');pages=reportPdfPages(source,host);}
   }catch(e){host.querySelectorAll('.report-pdf-page').forEach(p=>p.remove());host.classList.remove('pdf-compact-trailing');pages=reportPdfPages(source,host);}
  }
 }
 const {jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'p',unit:'mm',format:'a4'});
  for(let i=0;i<pages.length;i++){
   const canvas=await html2canvas(pages[i],{scale:2,useCORS:true,backgroundColor:'#ffffff',logging:false,windowWidth:pages[i].scrollWidth});
   if(i)pdf.addPage();
   const measuredHeight=canvas.height*194/canvas.width;
   if(!Number.isFinite(measuredHeight)||measuredHeight<=0)throw Error('PDF_INVALID_CANVAS_DIMENSIONS');
   // html2canvas may measure slightly taller than getBoundingClientRect; fit safely
   // inside A4 instead of failing or clipping a completed table row.
   const height=Math.min(measuredHeight,268);
   const imageWidth=194*height/measuredHeight;
   pdf.addImage(canvas.toDataURL('image/jpeg',0.94),'JPEG',8,8,imageWidth,height,undefined,'FAST');
   pdf.setFontSize(8);pdf.setTextColor(112,129,152);
   // A footer on every page, with the original application's single version source.
   pdf.text(`Tower App V${APP_VERSION}  |  Islam Sallam`,8,290);
   pdf.text(`${i+1} / ${pages.length}`,105,290,{align:'center'});
  }
  return pdf.output('blob');
 }finally{host.remove();}
}
function reportFileName(){const r=REPORT_UI.current||{};return ((r.building&&r.building.name)||'Tower_App').replace(/[\\/:*?"<>|]+/g,'_')+'_'+(r.title||'Report').replace(/[\\/:*?"<>|]+/g,'_')+'_'+cairoDateStamp()+'.pdf';}
async function downloadCurrentReportPdf(){try{const blob=await buildCurrentPdfBlob();await downloadBlobSafe(blob,reportFileName());toast('تم تجهيز ملف PDF.');}catch(e){toast(errText(e),'error');}}
// Explicitly user-initiated report send; PDF bytes never saved on Supabase or public storage.
let REPORT_TELEGRAM_SEND_BUSY=false;
async function sendReportPdfToTelegram(){
 if(REPORT_TELEGRAM_SEND_BUSY){toast('إرسال التقرير جارٍ بالفعل. انتظر نتيجة العملية.');return;}
 if(!REPORT_UI.current||!REPORT_UI.currentKey){toast('افتح التقرير أولًا.','error');return;}
 const reportId=String(REPORT_UI.currentKey).split('-')[0];
 const confirmed=window.confirm('إرسال نسخة PDF من هذا التقرير إلى حساب Telegram المرتبط بحسابك الحالي؟ قد يحتوي التقرير على بيانات مالية.');
 if(!confirmed)return;
 REPORT_TELEGRAM_SEND_BUSY=true;
 try{
  toast('جاري تجهيز PDF وإرساله إلى Telegram…');
  const blob=await buildCurrentPdfBlob();
  if(blob.size>6*1024*1024)throw Error('حجم التقرير أكبر من الحد المسموح (6 MB). استخدم تحميل PDF.');
  const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('تعذر قراءة PDF'));reader.readAsDataURL(blob);});
  const base64=String(data).split(',')[1];
  await run('telegramSettings','sendPdf',{reportId,filename:reportFileName(),base64});
  toast('تم إرسال التقرير إلى Telegram بنجاح.','success',{persistent:true});
 }catch(e){toast(errText(e),'error');}
 finally{REPORT_TELEGRAM_SEND_BUSY=false;}
}
// Compare report data rather than PDF bytes; creation timestamps and visual layout are excluded.
async function financialPdfFingerprint(report){
 const payload=JSON.stringify({title:report.title,sections:report.sections,groupedSections:report.groupedSections});
 const bytes=new TextEncoder().encode(payload);
 const hash=await crypto.subtle.digest('SHA-256',bytes);
 return Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');
}
function financialPdfFingerprintKey(){return 'tower:tg:financial_pdf:last:'+String(APP.ctx?.user?.user_id||APP.ctx?.user?.userId||'unknown');}
function rememberFinancialPdfFingerprint(hash){try{localStorage.setItem(financialPdfFingerprintKey(),hash);}catch{}}
function towerPdfQuotaEstimate(){
 const el=$('telegramPdfQuotaEstimate');if(!el)return;
 const frequency=$('telegramPdfFrequency')?.value||'MONTHLY';
 const seconds=Math.max(5,Math.min(120,Number($('telegramPdfSeconds')?.value)||30));
 const accounts=Math.max(1,Math.min(10,Number($('telegramPdfRecipients')?.value)||1));
 const reports=frequency==='DAILY'?30:frequency==='WEEKLY'?5:1;
 const monthSec=reports*accounts*seconds;
 const dayMax=accounts*seconds;
 el.textContent=`تقدير: ${reports*accounts} ملف/شهر ≈ ${(monthSec/60).toFixed(1)} دقيقة لتوليد التقارير في متصفح الحساب الذي يفتح النظام. أقصى وقت تقديري في يوم إرسال: ${(dayMax/60).toFixed(1)} دقيقة متصفح. استهلاك Cloudflare Browser Run: صفر (لا نستخدمه). التقدير لا يشمل زمن الرفع أو إعادة المحاولة.`;
}
function towerPdfMonthlyDayVisibility(){
 const wrap=$('telegramPdfMonthlyDayWrap');
 if(wrap)wrap.style.display=$('telegramPdfFrequency')?.value==='MONTHLY'?'inline-flex':'none';
}
async function adminSetPdfSchedule(){
 const picker=$('telegramPdfTime');if(!picker)return;
 const time=String(picker.value||'').trim();if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)){toast('اختار موعد صحيح لتقرير PDF بصيغة ساعة ودقيقة.','error');return;}
 const monthlyDay=Number($('telegramPdfMonthlyDay')?.value||1);
 if(!Number.isInteger(monthlyDay)||monthlyDay<1||monthlyDay>31){toast('اختار يوم إرسال شهري من 1 إلى 31.','error');return;}
 try{const result=await run('telegramSettings','setPdfSchedule',{time,frequency:$('telegramPdfFrequency')?.value||'MONTHLY',monthlyDay});picker.value=result.time;toast('تم حفظ موعد وتكرار تقرير PDF بتوقيت القاهرة.','success');checkOpenAppPdfDue();}
 catch(e){toast(errText(e),'error');}
}
// Daily PDF: only after per-account opt-in. Server owns the due-day claim and lease.
let AUTO_DAILY_PDF_RUNNING=false;
// No report contents, credentials or identifiers are kept in this diagnostic state.
let AUTO_PDF_LAST_STATUS={stage:'not_checked',at:null};
function recordAutoPdfStage(stage){
 AUTO_PDF_LAST_STATUS={stage,at:new Date().toISOString()};
 const status=$('telegramPdfAutomationStatus');
 if(status){
  const descriptions={not_checked:'لم يبدأ فحص التقارير بعد',checking:'جارٍ فحص التقارير المستحقة',not_due_or_no_recipient:'لا توجد مهمة مستحقة حاليًا أو لا يوجد مستلم مؤهل',rendering:'جارٍ تجهيز PDF في الخلفية',dispatching:'جارٍ تسليم PDF إلى Telegram',delivery_failed:'تعذّر إرسال تقرير واحد أو أكثر؛ راجع سجل المحاولات',sent:'تم إرسال تقرير PDF',no_dispatch:'لم تُرسل ملفات؛ افحص حالات الحجز والمستلمين',error:'تعذّر إكمال التوليد أو الإرسال؛ يلزم تشخيص'};
  status.textContent='حالة الفحص في هذه الجلسة: '+(descriptions[stage]||stage);
 }
}
async function tryAutoDailyPdf(){
 if(AUTO_DAILY_PDF_RUNNING||!APP.token||!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(APP.ctx?.user?.role))return;
 AUTO_DAILY_PDF_RUNNING=true;
 try{
  recordAutoPdfStage('checking');
  const due=await run('telegramSettings','autoPdfDue');
  if(!due?.due){recordAutoPdfStage('not_due_or_no_recipient');return;}
  recordAutoPdfStage('rendering');
  const report=await buildCombinedOverview(true);
  const blob=await buildCurrentPdfBlob(report);
  if(blob.size>6*1024*1024)throw Error('PDF_TOO_LARGE');
  const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('PDF_READ_FAILED'));reader.readAsDataURL(blob);});
  // No bot secret or service_role credentials enter the browser. Worker controls recipients and per-user database claims.
  recordAutoPdfStage('dispatching');
  const outcome=await run('telegramSettings','autoPdfDispatch',{base64});
  if(Number(outcome?.failed||0)>0||Number(outcome?.startRejected||0)>0){recordAutoPdfStage('delivery_failed');console.warn('AUTO_PDF_DELIVERY_FAILED',Number(outcome.failed));}
  else recordAutoPdfStage(Number(outcome?.sent||0)>0?'sent':'no_dispatch');
 }catch(e){recordAutoPdfStage('error');console.warn('AUTO_PDF_FAILED',String(e?.message||'').slice(0,100));}
 finally{AUTO_DAILY_PDF_RUNNING=false;}
}
// Re-check missed schedule while an authorized browser stays open or becomes visible.
// This does NOT render private finance in an unauthorized user's browser.
// The Worker preflight is read-only and the RPC claim prevents duplicate delivery.
function checkOpenAppPdfDue(){
 if(typeof document!=='undefined'&&document.visibilityState==='hidden')return;
 if(!APP.token)return;
 void tryAutoDailyPdf();
}
if(typeof document!=='undefined')document.addEventListener('visibilitychange',()=>{
 if(document.visibilityState==='visible')checkOpenAppPdfDue();
});
if(typeof window!=='undefined')window.addEventListener('focus',checkOpenAppPdfDue);
if(typeof setInterval==='function')setInterval(checkOpenAppPdfDue,60*1000);
// V2.5.11: explicit manual PDF test; no daily job claim, lease or scheduler mutation.
let FINANCIAL_PDF_PREVIEW_BUSY=false;
async function telegramPreviewFinancialPdf(){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role)){toast('هذا التقرير غير متاح لحسابك.','error');return;}
 if(FINANCIAL_PDF_PREVIEW_BUSY)return;
 FINANCIAL_PDF_PREVIEW_BUSY=true;
 const btn=$('telegramPdfPreview');if(btn){btn.disabled=true;btn.textContent='جارٍ تجهيز المعاينة…';}
 try{
  const report=await buildCombinedOverview();
  const blob=await buildCurrentPdfBlob(report);
  // Prefer object URLs where supported; fall back to a data URL in restricted webviews.
  const supportsObjectUrl=typeof URL!=='undefined'&&typeof URL.createObjectURL==='function';
  let url='',isObjectUrl=false;
  if(supportsObjectUrl){try{url=URL.createObjectURL(blob);isObjectUrl=true;}catch(_){/* FileReader fallback */}}
  if(!url){url=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||''));reader.onerror=()=>reject(new Error('تعذر قراءة ملف التقرير.'));reader.readAsDataURL(blob);});}
  const opened=window.open(url,'_blank');
  if(!opened){await downloadBlobSafe(blob,'Tower_Daily_Report_Preview.pdf');toast('تم تنزيل المعاينة؛ المتصفح منع فتح نافذة جديدة.');}
  if(isObjectUrl)setTimeout(()=>URL.revokeObjectURL(url),120000);
 }catch(e){toast('تعذر تجهيز معاينة PDF: '+errText(e),'error');}
 finally{FINANCIAL_PDF_PREVIEW_BUSY=false;const b=$('telegramPdfPreview');if(b){b.disabled=false;b.textContent='معاينة';}}
}
let MANUAL_DAILY_PDF_BUSY=false;
async function telegramSendFinancialPdfNow(){
 if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role)){toast('غير مسموح لهذا الحساب بإرسال التقرير المالي الموحد.','error');return;}
 if(MANUAL_DAILY_PDF_BUSY){toast('إرسال التقرير جارٍ بالفعل.');return;}
 MANUAL_DAILY_PDF_BUSY=true;
 const button=$('telegramPdfSendNow');if(button){button.disabled=true;button.textContent='جارٍ تجهيز التقرير…';}
 try{
  const report=await buildCombinedOverview();
  const fingerprint=await financialPdfFingerprint(report);
  let previous=null;try{previous=localStorage.getItem(financialPdfFingerprintKey());}catch{}
  if(previous===fingerprint&&!window.confirm('التقرير ده اتبعت قبل كده ومفيش بيانات اتغيرت. تحب تبعته تاني؟'))return;
  const blob=await buildCurrentPdfBlob(report);
  if(blob.size>6*1024*1024)throw Error('حجم التقرير يتجاوز الحد المسموح (6 MB).');
  const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('تعذر قراءة ملف PDF'));reader.readAsDataURL(blob);});
  const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  await run('telegramSettings','sendPdf',{reportId:'COMBINED_OVERVIEW',filename:'Tower_Financial_Report_Manual_'+day+'.pdf',base64});
  rememberFinancialPdfFingerprint(fingerprint);
  toast('تم إرسال نسخة التقرير إلى حساب Telegram المرتبط بك فقط.','success',{persistent:true});
 }catch(e){toast('تعذر إرسال PDF: '+errText(e),'error');}
 finally{MANUAL_DAILY_PDF_BUSY=false;const b=$('telegramPdfSendNow');if(b){b.disabled=false;b.textContent='إرسال تجريبي';}}
}
async function telegramSetDailyPdf(enabled){try{await run('telegramSettings','setDailyPdf',{enabled});toast('تم حفظ إعداد PDF الدوري.');await loadTelegramSettings();if(enabled)tryAutoDailyPdf();}catch(e){toast(errText(e),'error');await loadTelegramSettings();}}
async function shareCurrentReportPdf(){try{const blob=await buildCurrentPdfBlob(),file=new File([blob],reportFileName(),{type:'application/pdf'});if(file&&navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title:REPORT_UI.current.title||'Tower App',text:(REPORT_UI.current.building&&REPORT_UI.current.building.name)||'Tower App',files:[file]});return;}toast('المشاركة المباشرة غير متاحة على هذا الجهاز. نزّل PDF ثم شاركه من تطبيق Telegram.','error');}catch(e){if(e&&e.name==='AbortError')return;toast(errText(e),'error');}}





const SYS_UI={registrations:[],resets:[],settings:null};
// V2.4.62 — persistent administration section navigation and scroll tracking.
let adminSectionNavCleanup=null;
function setupAdminSectionNavigation(){
 if(adminSectionNavCleanup){adminSectionNavCleanup();adminSectionNavCleanup=null;}
 const nav=document.querySelector('#content .admin-section-nav');if(!nav)return;
 const links=[...nav.querySelectorAll('a[href^="#admin"]')];
 const entries=links.map(a=>({a,section:document.getElementById(a.getAttribute('href').slice(1))})).filter(x=>x.section);
 if(!entries.length)return;
 const placeholder=document.createElement('div');placeholder.className='admin-nav-placeholder';nav.after(placeholder);
 let frame=0,activeId='';
 function place(){const header=document.querySelector('.topbar');const top=header?Math.max(0,header.getBoundingClientRect().bottom):0;
  const content=document.querySelector('#content');const box=content.getBoundingClientRect();
  nav.style.top=top+'px';nav.style.left=box.left+'px';nav.style.width=box.width+'px';
  placeholder.style.height=nav.offsetHeight+14+'px';
 }
 function select(id){if(activeId===id)return;activeId=id;
  for(const x of entries){const on=x.section.id===id;x.a.classList.toggle('active',on);if(on)x.a.setAttribute('aria-current','location');else x.a.removeAttribute('aria-current');}
  const selected=entries.find(x=>x.section.id===id);if(selected){const a=selected.a;
   const left=a.offsetLeft,width=a.offsetWidth; if(left<nav.scrollLeft)nav.scrollLeft=left-12;else if(left+width>nav.scrollLeft+nav.clientWidth)nav.scrollLeft=left+width-nav.clientWidth+12;
  }
 }
 function update(){frame=0;if(!nav.isConnected)return;place();const threshold=nav.getBoundingClientRect().bottom+25;let current=entries[0];
  for(const x of entries){if(x.section.getBoundingClientRect().top<=threshold)current=x;else break;}select(current.section.id);
 }
 function schedule(){if(!frame)frame=requestAnimationFrame(update);}
 function jump(ev){const link=ev.target.closest('a[href^="#admin"]');if(!link||!nav.contains(link))return;
  const target=entries.find(x=>x.a===link);if(!target)return;ev.preventDefault();place();select(target.section.id);
  window.scrollTo({top:Math.max(0,window.scrollY+target.section.getBoundingClientRect().top-nav.getBoundingClientRect().bottom-12),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
 }
 nav.addEventListener('click',jump);window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule,{passive:true});
 adminSectionNavCleanup=()=>{nav.removeEventListener('click',jump);window.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);if(frame)cancelAnimationFrame(frame);placeholder.remove();nav.style.removeProperty('top');nav.style.removeProperty('left');nav.style.removeProperty('width');};
 update();
}

async function renderAdminRequests(kind){if(!['ADMIN','UNION'].includes(APP.ctx?.user?.role))return go('home');const registration=kind==='registration';const host=$('content');host.innerHTML=pageLoading('جاري تحميل الطلبات…');try{const data=await run(registration?'adminListRegistrationRequests':'adminListPinResetRequests');if(registration)SYS_UI.registrations=Array.isArray(data)?data:[];else SYS_UI.resets=Array.isArray(data)?data:[];const pending=(Array.isArray(data)?data:[]).filter(x=>registration?x.status==='PENDING':['PENDING','ISSUED'].includes(x.status));host.innerHTML=`<section class="panel admin-request-screen"><div class="panel-head"><div><h2>${registration?'طلبات التسجيل والتفعيل':'طلبات استرجاع PIN'}</h2><p>${registration?'مراجعة الطلبات وإصدار بيانات التفعيل.':'إصدار كود استرجاع مؤقت ومشاركته بالطريقة الحالية.'}</p></div><button class="btn-sm" onclick="go('home')">العودة للرئيسية</button></div><div class="admin-request-total">الطلبات القائمة: <strong>${pending.length}</strong></div>${pending.length?`<div class="list-stack">${pending.map(registration?regRow:resetRow).join('')}</div>`:emptyState('لا توجد طلبات معلقة','')}</section>`;}catch(e){host.innerHTML=errorCard(e);}}
// V2.5.88: keep the one-click overview prominent. Individual diagnostic outputs
// remain available on demand, without deleting old controls or changing their IDs.
function setupMaintenanceCompactLayout(){
 const root=$('adminDiagnostics');if(!root)return;
 const advanced=root.querySelector('.system-diag-advanced');
 if(advanced){
  advanced.open=false;
  const names=['تطابق الإصدار','اتساق الحسابات والوحدات','سلامة قاعدة البيانات والصلاحيات','Telegram والطابور'];
  advanced.querySelectorAll('.system-diag-block').forEach((block,i)=>{
   if(block.parentElement?.classList.contains('diag-tool-fold'))return;
   const section=document.createElement('details');section.className='diag-tool-fold';
   const heading=document.createElement('summary');heading.textContent=names[i]||'فحص متقدم';
   heading.setAttribute('aria-label','فتح '+heading.textContent);
   block.parentNode.insertBefore(section,block);section.appendChild(heading);section.appendChild(block);
  });
 }
 // These are special-purpose controls, not additional main diagnostic buttons.
 // Keep the reset control behind an explicit user expansion.
 const reset=$('adminReset');
 if(reset&&!reset.querySelector('.diag-reset-disclosure')){
  const panel=reset.querySelector('.panel-head');
  if(panel){
   const fold=document.createElement('details');fold.className='diag-reset-disclosure';
   const header=document.createElement('summary');header.textContent='فتح أدوات التصفير والنسخ الاحتياطي';
   const button=panel.querySelector('button');if(button)fold.appendChild(button);
   const state=reset.querySelector('.state-card');if(state)fold.appendChild(state);
   fold.insertBefore(header,fold.firstChild);reset.appendChild(fold);
  }
 }
}
async function renderSystemAdmin(){const c=$('content');if(APP.ctx.user.role!=='ADMIN'){renderPlanned('system','إدارة النظام');return;}c.innerHTML=pageLoading('جاري تحميل إدارة النظام…');try{const r=await Promise.allSettled([run('adminListRegistrationRequests'),run('adminListPinResetRequests'),run('adminGetSystemSettings')]);const regOk=r[0].status==='fulfilled',pinOk=r[1].status==='fulfilled',settingsOk=r[2].status==='fulfilled';SYS_UI.registrations=regOk&&Array.isArray(r[0].value)?r[0].value:[];SYS_UI.resets=pinOk&&Array.isArray(r[1].value)?r[1].value:[];SYS_UI.settings=settingsOk?r[2].value:null;const adminLoadProblem=i=>`<div class="state-card warning-state"><strong>تعذر تحميل هذا القسم</strong><span>${esc(errText(r[i].reason))}</span><button class="btn-sm" onclick="renderSystemAdmin()">إعادة المحاولة</button></div>`;const regPending=SYS_UI.registrations.filter(x=>x.status==='PENDING'),resetPending=SYS_UI.resets.filter(x=>['PENDING','ISSUED'].includes(x.status));c.innerHTML=`<nav class="admin-section-nav" aria-label="أقسام إدارة النظام"><a href="#" onclick="event.preventDefault();go('admin-registration')">طلبات التسجيل</a><a href="#" onclick="event.preventDefault();go('admin-pin')">استرجاع PIN</a><a href="#adminDiagnostics">التشخيص</a><a href="#adminReset">العمليات الحساسة</a><a href="#adminBranding">الهوية</a></nav><section class="panel" id="adminDiagnostics"><div class="panel-head"><div><h3>مركز فحص النظام</h3><p>فحص البنية والاتساق مع بيان الاختبارات غير المنفذة. للأدمن فقط.</p></div></div><div class="system-diag-main"><p class="system-diag-note">فحص واحد يجمع سلامة النظام والصلاحيات البنيوية وTelegram ومهام PDF، دون إرسال رسائل أو تغيير بيانات.</p><div id="systemDiagCompleteStatus" class="system-health-result diag-dashboard-result" aria-live="polite"><div class="diag-empty"><strong>جاهز لفحص النظام</strong><span>اضغط الزر لعرض ملخص واضح، ويمكنك فتح تفاصيل أي نتيجة عند الحاجة.</span></div></div><button class="btn-sm primary system-diag-runall" id="systemDiagRunAll" onclick="runCompleteSystemDiagnostics()">فحص النظام بالكامل</button><div class="system-diag-export"><button class="btn-sm" id="systemDiagUnifiedCopy" onclick="copyUnifiedDiagnostics()" disabled>نسخ التقرير الشامل</button><button class="btn-sm" id="systemDiagUnifiedExport" onclick="exportUnifiedDiagnostics()" disabled>تنزيل JSON</button></div></div><details class="system-diag-advanced"><summary>تفاصيل الفحوص والخيارات المتقدمة</summary><div class="system-diag-layout"><div class="system-diag-block"><div class="system-diag-title"><span class="system-diag-icon" aria-hidden="true">↔</span><div><h4>الإصدار المنشور على الرابط الحالي</h4><p>مقارنة نسخة الواجهة المحمّلة بردّ الـWorker المباشر. لا تعتمد على آخر إصدار ذُكر في المحادثة.</p></div></div><div class="system-diag-actions"><button class="btn-sm primary" onclick="checkCurrentDeploymentVersion()">تحقق من الإصدار</button></div><div id="deploymentVersionResult" class="system-health-result system-diag-output" aria-live="polite">لم يُتحقق من إصدار الرابط بعد.</div></div><div class="system-diag-block"><div class="system-diag-title"><span class="system-diag-icon" aria-hidden="true">◎</span><div><h4>اتساق المستخدمين والوحدات</h4><p>فحص قراءة فقط لمعرفات الدخول والعضويات ومديري الوحدات، بدون تعديل البيانات.</p></div></div><div class="system-diag-actions"><button class="btn-sm primary" id="adminConsistencyButton" onclick="runAdminConsistencyCheck()">فحص اتساق الحسابات والوحدات</button></div><div id="adminConsistencyResult" class="system-health-result system-diag-output" aria-live="polite">لم يتم إجراء فحص الاتساق بعد.</div></div><div class="system-diag-block"><div class="system-diag-title"><span class="system-diag-icon" aria-hidden="true">✓</span><div><h4>سلامة النظام</h4><p>فحوص البنية والاتساق؛ نجاح وجود الدوال أو تفعيل RLS لا يعني اختبار عملها أو العزل الفعلي بين الأدوار.</p></div></div><div class="system-diag-actions"><button class="btn-sm primary" onclick="runSystemHealthCheck('read_only')">فحص آمن</button><button class="btn-sm" onclick="runSystemHealthCheck('rollback_probe')">اختبار التراجع الآمن</button></div><div class="system-diag-export"><button class="btn-sm" id="systemDiagCopyAll" onclick="copyCompleteDiagnosticsReport()" disabled>⧉ نسخ كل تقارير التشخيص المتاحة</button><button class="btn-sm" onclick="exportSystemHealthReport()" id="systemDiagExport" disabled>تصدير TXT</button><button class="btn-sm" onclick="copySystemHealthReport()" id="systemDiagCopy" disabled>نسخ</button></div><div id="systemHealthResult" class="system-health-result system-diag-output" aria-live="polite">لم يتم تشغيل فحص النظام بعد.</div></div><div class="system-diag-block"><div class="system-diag-title"><span class="system-diag-icon" aria-hidden="true">↗</span><div><h4>Telegram والطابور</h4><p>راجع عدد الرسائل وحالتها دون إجراء أي تغييرات، أو أنشئ إشعار اختبار غير مالي.</p></div></div><div class="system-diag-actions"><button class="btn-sm primary" onclick="runTelegramDiagnostics()">فحص Telegram والطابور</button><button class="btn-sm" id="telegramQueueProbeButton" onclick="runTelegramQueueProbe()">اختبار</button></div><p class="system-diag-note">اختبار الإشعار متاح مرة واحدة كل دقيقة لحساب الأدمن، بشرط اكتمال الاختبار السابق. وصول الرسالة وسجل الإرسال لا يثبتان وحدهما موعد تشغيل Cron.</p><div class="system-diag-export"><button class="tower-tool-button" id="telegramDiagCopy" title="نسخ نتيجة Telegram" aria-label="نسخ نتيجة Telegram" onclick="copyTelegramDiagnosticsReport()" disabled>${toolIcon('copy')}</button></div><div id="telegramDiagnosticsResult" class="system-health-result system-diag-output" aria-live="polite"><span class="system-diag-muted">لم يتم فحص Telegram بعد.</span></div></div></div></details></section><section class="panel" id="adminDigestSchedule"><div class="panel-head"><div><h3>موعد الملخص اليومي على Telegram</h3><p>ميعاد واحد لرئيس الاتحاد والحارس بتوقيت مصر، مع التحكم الشخصي في تفعيل الملخص.</p></div></div><div class="form-grid"><div class="field digest-clock-field"><span>موعد الإرسال</span><div class="digest-clock" dir="ltr"><select id="digestHour" aria-label="الساعة">${Array.from({length:12},(_,i)=>`<option value="${i+1}">${String(i+1).padStart(2,'0')}</option>`).join('')}</select><span aria-hidden="true">:</span><select id="digestMinute" aria-label="الدقيقة">${Array.from({length:12},(_,i)=>`<option value="${i*5}">${String(i*5).padStart(2,'0')}</option>`).join('')}</select><select id="digestPeriod" aria-label="صباحًا أو مساءً"><option value="AM">ص</option><option value="PM">م</option></select></div></div><div class="form-actions"><button class="btn-sm primary" id="saveDigestTimeButton" onclick="saveDailyDigestTime()" disabled>حفظ الموعد</button></div><p class="muted span-2" id="digestTimeStatus" aria-live="polite">جارٍ تحميل الموعد الحالي…</p></div></section><section class="panel" id="adminReset"><div class="panel-head"><div><h3>التصفير التشغيلي والنسخ الاحتياطي</h3><p>يجب أن تشمل المعاينة اشتراكات الخدمات وطلبات تعديلها. تعريفات الخدمات والحسابات والوحدات والإعدادات محفوظة. النسخ الاحتياطي اختياري.</p></div><button class="btn-sm danger" onclick="openOperationalReset()">معاينة التصفير</button></div><div class="state-card warning-state"><strong>لا يحدث حذف بمجرد فتح الشاشة</strong><span>أنشئ Backup مستقلًا قبل التصفير إن أردت. التصفير لا ينشئ نسخة تلقائيًا ولا يمكن التراجع عنه من داخل التطبيق.</span></div></section><section class="panel" id="adminBranding"><div class="panel-head"><div><h3>هوية النظام</h3><p>اسم النظام وشعاره وصورته وألوانه. صلاحية الأكواد واسترجاع PIN ضمن الأمان والحسابات.</p></div>${settingsOk?`<button class="btn-sm" onclick="openBrandingSettings()">تعديل الإعدادات</button>`:`<button class="btn-sm" onclick="renderSystemAdmin()">تحديث</button>`}</div>${settingsOk?"":adminLoadProblem(2)}</section>`;setupAdminSectionNavigation();setupMaintenanceCompactLayout();loadDailyDigestTime();}catch(e){c.innerHTML=errorCard(e);}}
function regRow(x){return `<article class="data-card"><div class="data-main"><div><strong>${esc(personName(x))}</strong><span>شقة ${esc(unitNo(x.unitNumber))} · دور ${esc(floorNo(x.floor||''))} · ${phoneDisplay(x.phone)}</span></div><span class="badge warning">قيد المراجعة</span></div><div class="state-card"><strong>${x.managerOpinion==='SUPPORT'?'مدير الوحدة يؤيد الانضمام':x.managerOpinion==='OBJECT'?'مدير الوحدة يعترض على الانضمام':'لم يراجع مدير الوحدة الطلب بعد'}</strong>${x.managerOpinionNote?`<span>${esc(x.managerOpinionNote)}</span>`:''}${x.managerOpinionAt?`<small>${esc(displayDateTime12(x.managerOpinionAt))}</small>`:''}</div><div class="compact-actions"><button class="btn-sm primary" onclick="approveRegistration('${esc(x.requestId)}')">موافقة وإصدار كود</button><button class="btn-sm danger" onclick="rejectRegistration('${esc(x.requestId)}')">رفض</button></div></article>`;}
function resetRow(x){return `<article class="data-card"><div class="data-main"><div><strong>${esc(x.displayName||x.loginId)}</strong><span>${ltrId(x.loginId)} · ${esc(displayDateTime12(x.createdAt))}</span></div><span class="badge ${x.status==='ISSUED'?'success':'warning'}">${x.status==='ISSUED'?'تم إصدار كود':'قيد المراجعة'}</span></div><div class="compact-actions"><button class="btn-sm primary" onclick="issueResetCode('${esc(x.requestId)}')">${x.status==='ISSUED'?'إصدار كود جديد':'إصدار الكود'}</button></div></article>`;}
async function approveRegistration(id){try{const r=await run('adminApproveRegistrationRequest',id);openCredentialsResult({loginId:r.loginId,pin:r.activationCode,unitNumber:r.unitNumber,displayName:r.displayName},'بيانات التفعيل — الكود بدل PIN');await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
async function rejectRegistration(id){if(!await confirmAction({title:'رفض طلب الانضمام',message:'سيتم رفض الطلب ولن يتم إنشاء الحساب.',danger:true,confirmLabel:'رفض'}))return;try{await run('adminRejectRegistrationRequest',id,'رفض من الإدارة');toast('تم رفض الطلب.');await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
async function issueResetCode(id){try{const r=await run('adminIssuePinResetCode',id);openCredentialsResult({loginId:r.loginId,pin:r.code},'كود استرجاع PIN');await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
function digestClockFrom24(value){
 const match=/^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(value||''));
 if(!match)throw Error('INVALID_DIGEST_TIME');
 const hour=Number(match[1]),minute=Number(match[2]);
 if(minute%5)throw Error('INVALID_DIGEST_MINUTE');
 return {hour:hour%12||12,minute,period:hour<12?'AM':'PM'};
}
function digestClockTo24(){
 const hour=Number($('digestHour')?.value),minute=Number($('digestMinute')?.value),period=$('digestPeriod')?.value;
 if(!Number.isInteger(hour)||hour<1||hour>12||!Number.isInteger(minute)||minute<0||minute>55||minute%5||!['AM','PM'].includes(period))throw Error('INVALID_DIGEST_TIME');
 const h=hour%12+(period==='PM'?12:0);
 return String(h).padStart(2,'0')+':'+String(minute).padStart(2,'0');
}
async function loadDailyDigestTime(){
 const msg=$('digestTimeStatus'),btn=$('saveDigestTimeButton');
 try{const r=await run('adminGetDigestSchedule');const d=digestClockFrom24(r.time);if(!$('digestHour'))return;
  $('digestHour').value=String(d.hour);$('digestMinute').value=String(d.minute);$('digestPeriod').value=d.period;btn.disabled=false;
  msg.textContent='الموعد بتوقيت مصر؛ يتم فحص الجدولة كل 5 دقائق.';
 }catch(e){if(msg)msg.textContent=errText(e);}
}
async function saveDailyDigestTime(){
 const btn=$('saveDigestTimeButton'),msg=$('digestTimeStatus');if(!btn||btn.disabled)return;
 btn.disabled=true;try{const time=digestClockTo24();const r=await run('adminSaveDigestSchedule',{time});const d=digestClockFrom24(r.time);
 msg.textContent='تم حفظ الموعد: '+String(d.hour).padStart(2,'0')+':'+String(d.minute).padStart(2,'0')+' '+d.period+' بتوقيت مصر.';toast('تم حفظ موعد الملخص.');
 }catch(e){msg.textContent=errText(e);toast(errText(e),'error');}finally{btn.disabled=false;}
}
function adminBrandInlineForm(){
 const b=SYS_UI.settings?.branding||{};
 return `<form class="form-grid" onsubmit="saveSystemSettings(event)"><label class="field span-2"><span>اسم النظام</span><input id="brandName" value="${esc(b.systemName||'Tower App')}" required maxlength="90"></label><label class="field span-2"><span>الشعار النصي</span><input id="brandSlogan" value="${esc(b.slogan||'')}" maxlength="180"></label><label class="field"><span>اللون الأساسي</span><input id="brandPrimary" type="color" value="${esc(b.primaryColor||'#2f80ed')}"></label><label class="field"><span>اللون المساعد</span><input id="brandAccent" type="color" value="${esc(b.accentColor||'#36c68a')}"></label><div class="span-2 brand-image-upload"><strong>لوجو النظام</strong><p class="muted">المقاس الاسترشادي: 512 × 512 بكسل (1:1). PNG أو JPG أو WebP. اللوجو الحالي بديل تلقائي.</p><label class="brand-file-picker" for="brandLogoFile"><span class="brand-file-button">اختيار صورة</span><span class="brand-file-caption" id="brandLogoFileLabel">لم يتم اختيار ملف</span></label><input class="brand-file-native" type="file" id="brandLogoFile" accept="image/png,image/jpeg,image/webp" onchange="previewBrandFile('logo',this)"><img id="brandLogoPreview" alt="معاينة اللوجو" src="${esc(APP.ctx?.branding?.logoUrl||'')}" ${APP.ctx?.branding?.logoUrl?'':'hidden'} onerror="this.hidden=true"><div class="compact-actions"><button type="button" class="btn-sm" onclick="removeBrandImage('logo')">استعادة الافتراضي</button></div></div><div class="span-2 brand-image-upload"><strong>الصورة الرئيسية</strong><p class="muted">المقاس الاسترشادي: 1920 × 1080 بكسل (16:9). للشاشة الترحيبية.</p><label class="brand-file-picker" for="brandMainFile"><span class="brand-file-button">اختيار صورة</span><span class="brand-file-caption" id="brandMainFileLabel">لم يتم اختيار ملف</span></label><input class="brand-file-native" type="file" id="brandMainFile" accept="image/png,image/jpeg,image/webp" onchange="previewBrandFile('main',this)"><img id="brandMainPreview" alt="معاينة الصورة الرئيسية" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" ${APP.ctx?.branding?.mainImageUrl?'':'hidden'} onerror="this.hidden=true"><div class="compact-actions"><button type="button" class="btn-sm" onclick="removeBrandImage('main')">حذف الصورة الرئيسية</button></div><div class="brand-crop-controls"><strong>معاينة الجزء الظاهر في شاشة الترحيب</strong><label>التحريك الأفقي <input id="brandFocusX" type="range" min="0" max="100" value="${Number(b.heroFocusX??50)}" oninput="updateBrandCropPreview()"></label><label>التحريك الرأسي <input id="brandFocusY" type="range" min="0" max="100" value="${Number(b.heroFocusY??50)}" oninput="updateBrandCropPreview()"></label><div class="brand-crop-previews"><div><span>موبايل</span><div class="brand-crop-frame mobile"><img class="brand-crop-photo" style="object-position:${Number(b.heroFocusX??50)}% ${Number(b.heroFocusY??50)}%" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" alt="معاينة موبايل"></div></div><div><span>ديسكتوب</span><div class="brand-crop-frame desktop"><img class="brand-crop-photo" style="object-position:${Number(b.heroFocusX??50)}% ${Number(b.heroFocusY??50)}%" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" alt="معاينة ديسكتوب"></div></div></div><small>تُحفظ مواضع الصورة مع زر حفظ التغييرات الرئيسي.</small></div></div><p id="brandSaveStatus" class="muted span-2" aria-live="polite">اختيار الصور يعرض المعاينة فقط. اضغط حفظ التغييرات لاعتماد النصوص والصور معًا.</p><div class="form-actions span-2"><button id="brandSaveButton" class="btn-sm primary" type="submit">حفظ التغييرات</button></div></form>`;
}
function openBrandingSettings(){
 const b=SYS_UI.settings?.branding||{};BRAND_FILE_PREVIEWS.logo=null;BRAND_FILE_PREVIEWS.main=null;BRAND_PENDING_REMOVALS.logo=false;BRAND_PENDING_REMOVALS.main=false;
 openModal(`<div class="modal-head"><div><h3>هوية النظام</h3><p>اسم النظام والصور والألوان. زر واحد لحفظ كل التغييرات.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="saveSystemSettings(event)"><label class="field span-2"><span>اسم النظام</span><input id="brandName" value="${esc(b.systemName||'Tower App')}" required maxlength="90"></label><label class="field span-2"><span>الشعار النصي</span><input id="brandSlogan" value="${esc(b.slogan||'')}" maxlength="180"></label><label class="field"><span>اللون الأساسي</span><input id="brandPrimary" type="color" value="${esc(b.primaryColor||'#2f80ed')}"></label><label class="field"><span>اللون المساعد</span><input id="brandAccent" type="color" value="${esc(b.accentColor||'#36c68a')}"></label><div class="span-2 brand-image-upload"><strong>لوجو النظام</strong><p class="muted">المقاس الاسترشادي: 512 × 512 بكسل (1:1). PNG أو JPG أو WebP. اللوجو الحالي بديل تلقائي.</p><label class="brand-file-picker" for="brandLogoFile"><span class="brand-file-button">اختيار صورة</span><span class="brand-file-caption" id="brandLogoFileLabel">لم يتم اختيار ملف</span></label><input class="brand-file-native" type="file" id="brandLogoFile" accept="image/png,image/jpeg,image/webp" onchange="previewBrandFile('logo',this)"><img id="brandLogoPreview" alt="معاينة اللوجو" src="${esc(APP.ctx?.branding?.logoUrl||'')}" ${APP.ctx?.branding?.logoUrl?'':'hidden'} onerror="this.hidden=true"><div class="compact-actions"><button type="button" class="btn-sm" onclick="removeBrandImage('logo')">استعادة الافتراضي</button></div></div><div class="span-2 brand-image-upload"><strong>الصورة الرئيسية</strong><p class="muted">المقاس الاسترشادي: 1920 × 1080 بكسل (16:9). للشاشة الترحيبية.</p><label class="brand-file-picker" for="brandMainFile"><span class="brand-file-button">اختيار صورة</span><span class="brand-file-caption" id="brandMainFileLabel">لم يتم اختيار ملف</span></label><input class="brand-file-native" type="file" id="brandMainFile" accept="image/png,image/jpeg,image/webp" onchange="previewBrandFile('main',this)"><img id="brandMainPreview" alt="معاينة الصورة الرئيسية" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" ${APP.ctx?.branding?.mainImageUrl?'':'hidden'} onerror="this.hidden=true"><div class="compact-actions"><button type="button" class="btn-sm" onclick="removeBrandImage('main')">حذف الصورة الرئيسية</button></div><div class="brand-crop-controls"><strong>معاينة الجزء الظاهر في شاشة الترحيب</strong><label>التحريك الأفقي <input id="brandFocusX" type="range" min="0" max="100" value="${Number(b.heroFocusX??50)}" oninput="updateBrandCropPreview()"></label><label>التحريك الرأسي <input id="brandFocusY" type="range" min="0" max="100" value="${Number(b.heroFocusY??50)}" oninput="updateBrandCropPreview()"></label><div class="brand-crop-previews"><div><span>موبايل</span><div class="brand-crop-frame mobile"><img class="brand-crop-photo" style="object-position:${Number(b.heroFocusX??50)}% ${Number(b.heroFocusY??50)}%" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" alt="معاينة موبايل"></div></div><div><span>ديسكتوب</span><div class="brand-crop-frame desktop"><img class="brand-crop-photo" style="object-position:${Number(b.heroFocusX??50)}% ${Number(b.heroFocusY??50)}%" src="${esc(APP.ctx?.branding?.mainImageUrl||'')}" alt="معاينة ديسكتوب"></div></div></div><small>تُحفظ مواضع الصورة مع زر حفظ التغييرات الرئيسي.</small></div></div><p id="brandSaveStatus" class="muted span-2" aria-live="polite">اختيار الصور يعرض المعاينة فقط. اضغط حفظ التغييرات لاعتماد النصوص والصور معًا.</p><div class="form-actions span-2"><button id="brandSaveButton" class="btn-sm primary" type="submit">حفظ التغييرات</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);
}
function updateBrandCropPreview(){const x=Number($('brandFocusX')?.value??50),y=Number($('brandFocusY')?.value??50);document.querySelectorAll('.brand-crop-photo').forEach(img=>{img.style.objectPosition=x+'% '+y+'%';});}
function openSecuritySettings(){
 const s=SYS_UI.settings||{},expiry=s.codeExpiry||{};
 openModal(`<div class="modal-head"><div><h3>الأمان والحسابات</h3><p>مدد صلاحية الأكواد فقط؛ لن تتغير هوية النظام.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form class="form-grid" onsubmit="saveSecuritySettings(event)"><label class="field"><span>صلاحية كود التفعيل</span><select id="activationDays">${[1,3,7].map(n=>`<option value="${n}" ${Number(expiry.activationDays||3)===n?'selected':''}>${n} يوم</option>`).join('')}</select></label><label class="field"><span>صلاحية استرجاع PIN</span><select id="resetDays">${[1,3,7].map(n=>`<option value="${n}" ${Number(expiry.pinResetDays||3)===n?'selected':''}>${n} يوم</option>`).join('')}</select></label><div class="form-actions span-2"><button class="btn-sm primary" type="submit">حفظ إعدادات الأمان</button><button class="btn-sm" type="button" onclick="closeModal()">إلغاء</button></div></form>`);
}
async function saveSecuritySettings(e){e.preventDefault();const s=SYS_UI.settings||{},p={branding:{...(s.branding||{})},activationDays:Number($('activationDays').value),pinResetDays:Number($('resetDays').value)};
 try{const r=await withBackgroundSave(()=>run('adminSaveSystemSettings',p));SYS_UI.settings={...s,...r};closeModal();toast('تم حفظ إعدادات الأمان.');}catch(e){toast('تعذر حفظ إعدادات الأمان: '+errText(e),'error');}}
async function saveSystemSettings(e){
 e.preventDefault();const s=SYS_UI.settings||{},btn=$('brandSaveButton'),status=$('brandSaveStatus');
 const p={branding:{systemName:$('brandName').value,slogan:$('brandSlogan').value,primaryColor:$('brandPrimary').value,accentColor:$('brandAccent').value,heroFocusX:Number($('brandFocusX')?.value??50),heroFocusY:Number($('brandFocusY')?.value??50)},activationDays:Number(s.codeExpiry?.activationDays||3),pinResetDays:Number(s.codeExpiry?.pinResetDays||3)};
 if(btn)btn.disabled=true;
 const saved=[];
 try{
  // Save each changed image centrally; never report overall success before all requests succeed.
  for(const kind of ['logo','main']){
   if(!BRAND_FILE_PREVIEWS[kind]&&!BRAND_PENDING_REMOVALS[kind])continue;
   if(status)status.textContent='جارٍ حفظ '+(kind==='logo'?'اللوجو':'الصورة الرئيسية')+'…';
   await withBackgroundSave(()=>run('adminBrandAsset',BRAND_PENDING_REMOVALS[kind]?{kind,remove:true}:{kind,data:BRAND_FILE_PREVIEWS[kind]}));
   BRAND_FILE_PREVIEWS[kind]=null;saved.push(kind);
   APP.ctx.branding={...(APP.ctx.branding||{}),[kind==='logo'?'logoUrl':'mainImageUrl']:BRAND_PENDING_REMOVALS[kind]?null:'/api/brand/'+kind};BRAND_PENDING_REMOVALS[kind]=false;
  }
  if(status)status.textContent='جارٍ حفظ اسم النظام والألوان…';
  const r=await withBackgroundSave(()=>run('adminSaveSystemSettings',p));SYS_UI.settings={...s,...r};
  APP.ctx.branding={...(APP.ctx.branding||{}),...r.branding};APP.ctx.building.name=r.branding.systemName;
  applyBranding(APP.ctx.branding);
  document.title=(APP.ctx.user.displayName||APP.ctx.user.roleLabel)+' | '+r.branding.systemName;
  if(btn?.closest('.modal'))closeModal();toast('تم حفظ تغييرات الهوية والصور.');await renderAdminCombined();showAdminSettingsGroup('brand');
 }catch(x){
  const msg='تعذر إكمال الحفظ: '+errText(x)+(saved.length?' — تم حفظ '+saved.map(k=>k==='logo'?'اللوجو':'الصورة الرئيسية').join(' و ')+' بالفعل. باقي التغييرات لم تُعتمد بعد.':'');
  if(status)status.textContent=msg;toast(msg,'error');
 }finally{if(btn)btn.disabled=false;}
}

async function runTelegramQueueProbe(){
 const btn=$('telegramQueueProbeButton');if(btn?.disabled)return;
 if(!confirm('سيتم إنشاء إشعار فحص غير مالي لحسابك فقط وإرساله على Telegram بعد تشغيل معالج الطابور. هل تريد المتابعة؟'))return;
 const host=$('telegramDiagnosticsResult');if(btn){btn.disabled=true;btn.textContent='جارٍ طلب الاختبار…';}
 if(host)host.innerHTML='<div class="system-diag-state">جارٍ إضافة إشعار الفحص إلى الطابور…</div>';
 try{
  const result=await run('adminTelegramQueueProbe');
  if(result?.blocked){
   const secs=Number(result.retryAfterSeconds)||0;
   const note=result.reason==='COOLDOWN'?'يمكن إعادة الاختبار بعد '+secs+' ثانية.':'الاختبار السابق لم ينتهِ بعد. افحص حالة الطابور قبل إعادة المحاولة.';
   if(host)host.innerHTML='<div class="system-diag-state diag-wait"><strong>الاختبار غير متاح مؤقتًا</strong><span>'+esc(note)+'</span></div>';
   return;
  }
  if(host)host.innerHTML='<div class="system-diag-state diag-success"><strong>تم إنشاء إشعار الاختبار</strong><span>انتظر دورة معالجة الطابور، ثم اضغط «فحص Telegram والطابور» للتحقق من حالة الإرسال.</span></div>';
  toast('تم إنشاء إشعار الفحص. يمكنك مراجعة الطابور بعد بضع دقائق.');
 }catch(e){
  const raw=String([e?.message,e?.code,e?.details,errText(e)].filter(Boolean).join(' '));
  if(raw.includes('TELEGRAM_PROBE_RATE_LIMIT')){
   if(host)host.innerHTML='<div class="system-diag-state diag-wait"><strong>تم إجراء الاختبار مؤخرًا</strong><span>يمكن إعادة الاختبار بعد دقيقة واحدة، بشرط عدم وجود اختبار سابق معلق. تابع حالة الرسالة السابقة باستخدام «فحص Telegram والطابور».</span></div>';
  }else{
   if(host){host.textContent='تعذر إنشاء إشعار الاختبار: '+errText(e);}
   toast(errText(e),'error');
  }
 }finally{if(btn){btn.disabled=false;btn.textContent='اختبار الإشعار التلقائي';}}
}
async function runTelegramDiagnostics(){
 const host=$('telegramDiagnosticsResult');if(!host)return;
 host.innerHTML='<div class="system-diag-state">جارٍ قراءة حالة Telegram والطابور…</div>';
 try{
  const d=await run('adminTelegramDiagnostics');
  if(d.truncated){TELEGRAM_DIAGNOSTICS_LAST=null;updateDiagnosticsCopyState();host.textContent='البيانات أكبر من حد الفحص (1000 سجل). النتائج الجزئية غير معتمدة.';return;}
  TELEGRAM_DIAGNOSTICS_LAST={data:d,checkedAt:new Date().toISOString()};
  updateDiagnosticsCopyState();
  const c=d.counts||{};
  host.innerHTML=`<div class="diag-overview"><strong>Telegram — فحص قراءة فقط</strong><span>الحسابات المرتبطة: ${Number(d.linkedAccounts)||0} · المفعّلة: ${Number(d.enabledAccounts)||0}</span></div><div class="diag-list"><div class="diag-item"><div class="diag-info"><strong>طابور الإرسال</strong><span>منتظر: ${Number(c.PENDING)||0} · فشل/إعادة محاولة: ${Number(c.FAILED)||0} · مرسل: ${Number(c.SENT)||0} · ملغي: ${Number(c.CANCELLED)||0}</span><span>${Number(d.overdueJobs)>0?`⚠ رسائل تجاوزت موعد إعادة المحاولة: ${Number(d.overdueJobs)} · `:""}${Number(d.retriesExhausted)>0?`⚠ رسائل استنفدت المحاولات: ${Number(d.retriesExhausted)}`:""}</span></div></div><div class="diag-item"><div class="diag-info"><strong>آخر إرسال مؤكد بالسجل</strong><span>${esc(d.latestSent?systemHealthDate(d.latestSent):'لا يوجد')}</span></div></div><div class="diag-item"><div class="diag-info"><strong>حالة Cron</strong><span>${d.cronLastRan?`آخر بدء مسجل: ${esc(systemHealthDate(d.cronLastRan))} · آخر اكتمال: ${esc(d.cronLastFinished?systemHealthDate(d.cronLastFinished):"لم يكتمل بعد")} · الحالة: ${d.cronLastStatus==="SUCCESS"?"اكتمل":d.cronLastStatus==="ERROR"?"حدث خطأ":d.cronLastStatus==="DEGRADED"?"اكتمل مع أخطاء تحتاج مراجعة":"جارٍ التشغيل"} · رسائل ناجحة في الدورة: ${Number(d.cronLastJobsSent)||0} · تعذر إرسالها: ${Number(d.cronLastJobsFailed)||0}${d.cronDigestError?" · فشل تجهيز الملخص اليومي":""}${Number(d.cronLastJobsFailed)>0?" · تحذير: إرسال بعض الرسائل فشل وسيعاد وفق سياسة الطابور":""}${Date.now()-Date.parse(d.cronLastRan)>15*60*1000?" · تحذير: آخر تشغيل أقدم من 15 دقيقة":""}`:"لم يتوفر سجل لتشغيل Cron حتى الآن."} ${esc(d.cronNote||"")}</span></div></div></div>`;
  attachDiagnosticsRowCopyButtons(host);
 }catch(e){TELEGRAM_DIAGNOSTICS_LAST=null;updateDiagnosticsCopyState();host.textContent='تعذر فحص Telegram: '+errText(e);}
}
// DIAG-01: live, recipient-scoped PDF schedule and recent delivery inspection.
// Does not reserve, upload, generate, send or mutate any report.
let PDF_DIAGNOSTICS_LAST=null;
async function runPdfDeliveryDiagnostics(){
 PDF_DIAGNOSTICS_LAST=null;
 const checkedAt=new Date().toISOString();
 const results=await Promise.allSettled([
  run('telegramSettings','getPdfSchedule'),
  run('telegramSettings','dailyPdfStatus'),
  run('telegramSettings','dailyPdfHistory')
 ]);
 const faults=results.map((r,i)=>r.status==='rejected'?{part:['schedule','recipient','history'][i],error:diagnosticsSafeText(errText(r.reason)).slice(0,350)}:null).filter(Boolean);
 const schedule=results[0].status==='fulfilled'?results[0].value:null;
 const recipient=results[1].status==='fulfilled'?results[1].value:null;
 const history=results[2].status==='fulfilled'?results[2].value:null;
 const jobs=Array.isArray(history?.jobs)?history.jobs:[];
 const now=Date.now();
 const overdue=jobs.filter(j=>['CLAIMED','SENDING'].includes(j.status)&&Number.isFinite(Date.parse(j.leaseUntil))&&Date.parse(j.leaseUntil)<now).length;
 const dayParts=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
 const valueOfDay=type=>dayParts.find(part=>part.type===type)?.value||'';
 const currentDay=[valueOfDay('year'),valueOfDay('month'),valueOfDay('day')].join('-');
 const staleJobs=jobs.filter(j=>['CLAIMED','SENDING'].includes(j.status)&&Number.isFinite(Date.parse(j.leaseUntil))&&Date.parse(j.leaseUntil)<now);
 const historicalOverdue=staleJobs.filter(j=>j.day!==currentDay).length;
 const currentOverdue=staleJobs.length-historicalOverdue;
 const failed=jobs.filter(j=>j.status==='FAILED').length;
 const unknown=jobs.filter(j=>!['CLAIMED','SENDING','FAILED','SENT','CANCELLED','PENDING'].includes(j.status)).length;
 const state=faults.length?'FAIL':overdue||failed||unknown?'WARN':'PASS';
 const frequency=String(schedule?.frequency||'');
 const monthlyDay=Number(schedule?.monthlyDay);
 const time=String(schedule?.time||'');
 const configValid=['DAILY','WEEKLY','MONTHLY'].includes(frequency)&&/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)&&Number.isInteger(monthlyDay)&&monthlyDay>=1&&monthlyDay<=31;
 const status=state==='PASS'&&!configValid?'WARN':state;
 const report={checkedAt,scope:'signed_in_admin_only',status,schedule:schedule?{frequency,time,monthlyDay,valid:configValid}:null,recipient:recipient?{enabled:recipient.enabled===true,eligible:recipient.eligible===true}:null,historyLimit:5,historyCount:jobs.length,overdueLeaseCount:overdue,currentOverdueLeaseCount:currentOverdue,historicalOverdueLeaseCount:historicalOverdue,failedCount:failed,unknownStatusCount:unknown,recentJobs:jobs.map(j=>({day:j.day,status:j.status,attempts:j.attempts,leaseUntil:j.leaseUntil,completedAt:j.completedAt})),errors:faults,note:'السجل يخص حساب الأدمن الحالي وآخر خمس محاولات فقط؛ لا يثبت وصول كل PDF ولا صحة البيانات التاريخية أو حالة كل المستلمين.'};
 PDF_DIAGNOSTICS_LAST=report;
 return report;
}
// Migration registry is read-only, a single automatic stage of the existing one-click check.
let MIGRATION_REGISTRY_LAST=null;
async function runMigrationRegistryDiagnostics(){
 try{MIGRATION_REGISTRY_LAST=await run('adminMigrationRegistry');}
 catch(e){MIGRATION_REGISTRY_LAST={status:'NOT_TESTED',registryAvailable:false,reason:String(e?.message||e).slice(0,180)};}
 return MIGRATION_REGISTRY_LAST;
}
// DIAG-01: orchestrates existing read-only diagnostics without broadening backend privileges.
let COMPLETE_DIAGNOSTICS_LAST=null;
async function runCompleteSystemDiagnostics(){
 const button=$('systemDiagRunAll'),status=$('systemDiagCompleteStatus');if(!status||button?.disabled)return;
 if(button)button.disabled=true;
 COMPLETE_DIAGNOSTICS_LAST=null;
 for(const id of ['systemDiagUnifiedCopy','systemDiagUnifiedExport']){const b=$(id);if(b)b.disabled=true;}
 const items=[];
 const stages=[
  ['deployment','تطابق الإصدار',checkCurrentDeploymentVersion,'deploymentVersionResult'],
  ['consistency','اتساق الحسابات والوحدات',runAdminConsistencyCheck,'adminConsistencyResult'],
  ['health','سلامة النظام',()=>runSystemHealthCheck('read_only'),'systemHealthResult'],
  ['telegram','Telegram والطابور',runTelegramDiagnostics,'telegramDiagnosticsResult'],
  ['pdf','PDF الدوري والجدولة',runPdfDeliveryDiagnostics,null],
  ['migrations','ترحيلات قاعدة البيانات',runMigrationRegistryDiagnostics,null]
 ];
 try{
  // Clear cached results so a failed stage cannot inherit a previous PASS.
  SYSTEM_HEALTH_LAST=null;
  TELEGRAM_DIAGNOSTICS_LAST=null;
  PDF_DIAGNOSTICS_LAST=null;
  MIGRATION_REGISTRY_LAST=null;
  for(let i=0;i<stages.length;i++){
   const [id,title,fn,targetId]=stages[i];
   status.textContent=`جارٍ الفحص ${i+1} من ${stages.length}: ${title}…`;
   let error=null;
   try{await fn();}catch(e){error=String(e?.message||e).slice(0,180);}
   const output=$(targetId);
   const detail=id==='pdf'?diagnosticsSafeText(JSON.stringify(PDF_DIAGNOSTICS_LAST||{})):id==='migrations'?diagnosticsSafeText(JSON.stringify(MIGRATION_REGISTRY_LAST||{})):diagnosticsSafeText((output?.innerText||output?.textContent||'').trim()).slice(0,20000);
   const failedText=/^(?:تعذر|البيانات أكبر|حدث خطأ|HTTP\s+\d)/.test(detail);
   let state=error||failedText?'FAIL':'PASS';
   if(id==='deployment'&&(/اختلاف|غير متطابق|لا يمكن تأكيد/.test(detail)||!/الإصداران متطابقان/.test(detail)))state='FAIL';
   if(id==='consistency'&&/ملاحظات تحتاج مراجعة/.test(detail))state='WARN';
   if(id==='health'){
    const checks=Array.isArray(SYSTEM_HEALTH_LAST?.checks)?SYSTEM_HEALTH_LAST.checks:[];
    state=!SYSTEM_HEALTH_LAST?'FAIL':!checks.length?'WARN':checks.some(x=>x.status==='FAIL')?'FAIL':checks.some(x=>x.status==='WARN'||x.status==='NOT_TESTED')?'WARN':'PASS';
   }
   if(id==='telegram'){
    const d=TELEGRAM_DIAGNOSTICS_LAST?.data;
    if(!d)state='FAIL';
    else if(Number(d.overdueJobs)>0||Number(d.retriesExhausted)>0||Number(d.counts?.FAILED)>0||d.cronLastStatus==='ERROR'||d.cronLastStatus==='DEGRADED')state='WARN';
   }
   if(id==='pdf')state=PDF_DIAGNOSTICS_LAST?.status||'FAIL';
   if(id==='migrations')state=MIGRATION_REGISTRY_LAST?.status||'NOT_TESTED';
   if(!detail&&!error)state='WARN';
   items.push({id,title,status:state,detail:error||detail||'لا توجد بيانات متاحة'});
  }
  const skipped=[
   {id:'active-role-scenarios',title:'اختبارات الصلاحيات الحية للأدوار الأربعة',status:'NOT_TESTED',reason:'لم ينفذ اختبار هوية مستقلة لكل دور'},
   {id:'visual-layout',title:'اختبار الواجهة بصريًا على الأجهزة',status:'NOT_TESTED',reason:'يتطلب اختبار متصفح فعليًا'},
   {id:'telegram-test-send',title:'إرسال Telegram تجريبي',status:'SKIP',reason:'لا يُنفذ إرسال خارجي أثناء الفحص الآمن'},
   {id:'rollback-probe',title:'اختبار التراجع الآمن',status:'SKIP',reason:'لا يوجد ضمان عزل بيانات الاختبار حتى الآن'},
   {id:'isolated-business-scenarios',title:'اختبارات السيناريوهات التشغيلية المعزولة',status:'NOT_TESTED',reason:'يتطلب مساحة بيانات اختبار مخصصة وضمان تنظيفها دون المساس ببيانات النظام الموجودة'},
   {id:'historical-pdf-verification',title:'مطابقة محتوى PDF للفترات التاريخية',status:'NOT_TESTED',reason:'التحقق من صحة البيانات التاريخية يحتاج مقارنة مستقلة بلقطات مؤرخة'}
  ];
  const checks=Array.isArray(SYSTEM_HEALTH_LAST?.checks)?SYSTEM_HEALTH_LAST.checks:[];
  const checkCounts={PASS:0,WARN:0,FAIL:0,NOT_TESTED:0};
  for(const c of checks)if(Object.hasOwn(checkCounts,c.status))checkCounts[c.status]++;
  const explicitUntested=skipped.filter(x=>x.status==='NOT_TESTED').length;
  const coverage={completed:checkCounts.PASS+checkCounts.WARN+checkCounts.FAIL,notTested:checkCounts.NOT_TESTED+explicitUntested,optionalSkipped:skipped.length-explicitUntested};
  const coverageTotal=coverage.completed+coverage.notTested;
  coverage.percentage=coverageTotal?Math.round(100*coverage.completed/coverageTotal):0;
  COMPLETE_DIAGNOSTICS_LAST={schema:'tower-diag-01-v2',appVersion:APP_VERSION,checkedAt:new Date().toISOString(),mode:'read_only',items,notExecuted:skipped,coverage,checkSummary:checkCounts,pdfDelivery:PDF_DIAGNOSTICS_LAST,migrationRegistry:MIGRATION_REGISTRY_LAST,healthChecks:checks.map(x=>({id:String(x.id||''),status:String(x.status||'NOT_TESTED'),description:diagnosticsSafeText(String(x.description||x.desc||'')).slice(0,1000)}))};
  const tally=st=>items.filter(x=>x.status===st).length;
  const good=tally('PASS'), warning=tally('WARN'), fail=tally('FAIL');
  const detailText=(item)=>{
   if(item.id==='deployment')return item.status==='PASS'?'نسخة الواجهة والـWorker متطابقتان على الرابط الحالي.':'راجع توافق نسخة الواجهة والـWorker.';
   if(item.id==='consistency')return item.status==='PASS'?'لم تظهر مشكلات في فحوص اتساق الحسابات والوحدات.':'راجع تفاصيل الاتساق.';
   if(item.id==='health')return `${checkCounts.PASS} فحص ناجح · ${checkCounts.NOT_TESTED} لم يُختبر · الفحوص البنيوية لا تثبت صلاحيات الأدوار.`;
   if(item.id==='telegram')return item.status==='PASS'?'فحوص الطابور وCron لم تُظهر مشكلات مسجلة.':'توجد ملاحظات في الطابور أو Cron.';
   if(item.id==='migrations'){const r=MIGRATION_REGISTRY_LAST;return !r?.registryAvailable?'سجل الترحيلات غير متاح؛ لا يمكن تأكيد تنفيذ SQL.':`تم توثيق ${Number(r.checks?.filter(x=>x.status==='APPLIED').length||0)} من ${Number(r.catalogCount||0)} ترحيلات في الكتالوج الحالي.`;}
   if(item.id==='pdf'){
    const pdf=PDF_DIAGNOSTICS_LAST||{};
    return `${Number(pdf.historicalOverdueLeaseCount??pdf.overdueLeaseCount??0)} مهام تاريخية معلقة · ${Number(pdf.currentOverdueLeaseCount||0)} مهام اليوم متأخرة · ${Number(pdf.failedCount||0)} فشل مسجل · نطاق الأدمن الحالي فقط.`;
   }
   return 'افتح التفاصيل للاطلاع على نتيجة هذا الفحص.';
  };
  const labels={PASS:'ناجح',WARN:'تحذير',FAIL:'خطأ',NOT_TESTED:'لم يُختبر'};
  const metric=(label,value,sub,kind)=>`<div class="diag-metric diag-metric-${kind}"><span>${esc(label)}</span><strong dir="ltr">${esc(String(value))}</strong><small>${esc(sub)}</small></div>`;
  const pdf=PDF_DIAGNOSTICS_LAST||{};
  const pdfSummary=items.find(x=>x.id==='pdf');
  const pdfCard=`<section class="diag-pdf-card" aria-label="حالة PDF الدوري"><div class="diag-section-heading"><strong>تشخيص PDF الدوري وحالة المهام</strong><span class="diag-pill ${esc(pdfSummary?.status||'NOT_TESTED')}">${esc(labels[pdfSummary?.status]||'لم يُختبر')}</span></div><div class="diag-pdf-facts"><div><span>الجدولة</span><strong>${esc(pdf.schedule?.valid?((pdf.schedule.frequency==='DAILY'?'يوميًا':pdf.schedule.frequency==='WEEKLY'?'أسبوعيًا':'شهريًا')+' · '+String(pdf.schedule.time||'—')):'غير متاحة')}</strong></div><div><span>السجلات المفحوصة</span><strong>${esc(String(pdf.historyCount??'—'))}</strong></div><div><span>مهام سابقة معلقة</span><strong>${esc(String(pdf.historicalOverdueLeaseCount??pdf.overdueLeaseCount??'—'))}</strong></div></div><p class="system-diag-note">الفحص يخص الأدمن الحالي وآخر 5 مهام فقط، ولا يثبت وصول الملفات لكل المستلمين أو دقة محتوى الفترات التاريخية. المهام التاريخية CLAIMED تحتاج مطابقة سجل Telegram قبل أي إعادة إرسال؛ لن يعيد هذا الفحص إرسالها.</p></section>`;
  status.innerHTML=`<div class="diag-summary-metrics">${metric('ناجح',good,'من أصل '+items.length+' أقسام','pass')}${metric('تحذيرات',warning,'تحتاج مراجعة','warn')}${metric('أخطاء',fail,'فشل الفحص','fail')}${metric('التغطية',coverage.percentage+'%','فحوص محددة النطاق','coverage')}</div><div class="diag-coverage-note">${coverage.notTested} فحوص لم تُنفذ، و${coverage.optionalSkipped} إجراءات اختيارية متروكة. النسبة لا تثبت اكتمال كل وظائف النظام أو سلامة التطبيق كله.</div><section class="diag-results-card"><div class="diag-section-heading"><strong>ملخص النتائج</strong><span>اضغط على أي قسم لعرض التفاصيل</span></div><div class="diag-result-rows">${items.map(x=>`<details class="diag-result-row"><summary><span class="diag-row-title">${esc(x.title)}</span><span class="diag-pill ${esc(x.status)}">${esc(labels[x.status]||x.status)}</span><span class="diag-row-chevron" aria-hidden="true">⌄</span></summary><div class="diag-row-body"><p>${esc(detailText(x))}</p><details class="diag-raw"><summary>المعلومات التقنية لهذا الفحص</summary><pre dir="auto">${esc(x.id==='pdf'?JSON.stringify(PDF_DIAGNOSTICS_LAST||{},null,2):x.detail)}</pre></details></div></details>`).join('')}</div></section>${pdfCard}<p class="diag-check-time">وقت الفحص: ${esc(systemHealthDate(COMPLETE_DIAGNOSTICS_LAST.checkedAt))}</p>`;
  for(const id of ['systemDiagUnifiedCopy','systemDiagUnifiedExport']){const b=$(id);if(b)b.disabled=false;}
 }finally{if(button)button.disabled=false;}
}
function unifiedDiagnosticsJson(){return COMPLETE_DIAGNOSTICS_LAST?JSON.stringify(COMPLETE_DIAGNOSTICS_LAST,null,2):'';}
async function copyUnifiedDiagnostics(){await diagnosticsCopyWithFeedback(unifiedDiagnosticsJson(),$('systemDiagUnifiedCopy'));}
async function exportUnifiedDiagnostics(){const content=unifiedDiagnosticsJson();if(!content){toast('شغّل الفحص أولًا.','error');return;}try{await downloadBlobSafe(new Blob([content],{type:'application/json;charset=utf-8'}),'Tower_App_Diagnostics_V'+APP_VERSION+'.json');toast('تم طلب تنزيل تقرير الفحص.');}catch(e){toast('تعذر تنزيل التقرير: '+errText(e),'error');}}
let SYSTEM_HEALTH_LAST=null;
let TELEGRAM_DIAGNOSTICS_LAST=null;
// Read-only, same-origin verification. Never infer deployment from chat history.
async function checkCurrentDeploymentVersion(){
 const output=$('deploymentVersionResult');if(!output)return;
 output.textContent='جارٍ سؤال الـWorker الموجود على رابط التطبيق…';
 try{
  const response=await fetch('/api/health?check='+encodeURIComponent(String(Date.now())),{method:'GET',cache:'no-store',headers:{Accept:'application/json'}});
  if(!response.ok)throw Error('HTTP '+response.status);
  const data=await response.json();
  const remote=typeof data?.version==='string'&&/^\d+\.\d+\.\d+$/.test(data.version)?data.version:null;
  if(data?.ok!==true||!remote)throw Error('استجابة الإصدار غير صالحة');
  const local=APP_VERSION;const matched=remote===local;
  output.innerHTML=`<div><strong>${matched?'✓ الإصداران متطابقان':'⚠ يوجد اختلاف بين نسختَي الواجهة والخادم'}</strong></div><div>نسخة الواجهة: <bdi>V${esc(local)}</bdi></div><div>نسخة الـWorker على هذا الرابط: <bdi>V${esc(remote)}</bdi></div><div class="muted">${matched?'تم التحقق من الرابط المفتوح الآن، وليس من كل البيئات.':'يُحتمل وجود ملفات واجهة مخزنة أو نشر غير مكتمل؛ جرّب تحديثًا كاملًا وافحص الرابط مرة أخرى.'}</div>`;
 }catch(error){output.textContent='تعذر التحقق من إصدار الرابط الحالي: '+String(error.message||error).slice(0,100)+' — لا يمكن تأكيد الإصدار المنشور.';}
}
async function runSystemHealthCheck(mode){
 const target=$('systemHealthResult');if(!target)return;
 target.textContent='جارٍ فحص النظام…';
 try{
  const result=await run('adminSystemHealthCheck',mode);
  SYSTEM_HEALTH_LAST=result;
  const checks=Array.isArray(result.checks)?result.checks:[];
  const counts={PASS:0,FAIL:0,WARN:0,NOT_TESTED:0};
  for(const item of checks)if(Object.hasOwn(counts,item.status))counts[item.status]++;
  target.innerHTML=`<div class="diag-overview"><strong>نتائج الفحص: ${counts.PASS} ناجح، ${counts.FAIL} خطأ، ${counts.WARN} تحذير، ${counts.NOT_TESTED} لم يُختبر</strong><span>الوقت: ${esc(systemHealthDate(result.checkedAt))} · ${mode==='rollback_probe'?'تراجع تجريبي فقط':'قراءة فقط'}</span></div><p class="system-diag-note">PASS يعني نجاح الفحص المحدد فقط؛ التحقق من وجود دالة أو تفعيل RLS لا يثبت اختبار الوظيفة أو صلاحيات الأدوار عمليًا.</p>${systemHealthGroupedHtml(checks)}<p class="muted">${esc(result.warning||'')}</p>`;
  for(const id of ['systemDiagExport','systemDiagCopy']){const button=$(id);if(button)button.disabled=false;}
  updateDiagnosticsCopyState();
  attachDiagnosticsRowCopyButtons(target);
 }catch(e){target.textContent='تعذر الفحص: '+errText(e);SYSTEM_HEALTH_LAST=null;updateDiagnosticsCopyState();for(const id of ['systemDiagExport','systemDiagCopy']){const b=$(id);if(b)b.disabled=true;}}
}
function systemHealthDate(v){
 if(!v)return '—';const date=new Date(v);if(Number.isNaN(date.getTime()))return 'تاريخ غير متاح';
 const fmt=new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true,timeZone:'Africa/Cairo'});
 return fmt.format(date).replace(/am/i,'ص').replace(/pm/i,'م');
}
function systemHealthSubject(c){
 const id=String(c.id||'');const parts=id.split(':');
 const labels={table:'وجود الجدول',rls:'تفعيل RLS للجدول',rpc:'وجود الدالة (لا يثبت تشغيلها)',finance:'فحص مالي',trips:'المشاوير',security:'الأمان',functional:'فحص وظيفي',transaction:'المعاملات'};
 return {name:labels[parts[0]]||'فحص',code:parts.slice(1).join(':')||id};
}
function systemHealthCategory(c){
 const prefix=String(c.id||'').split(':')[0];
 if(prefix==='table'||prefix==='rpc')return 'البنية والدوال';
 if(prefix==='rls'||prefix==='security')return 'الحماية والصلاحيات';
 if(prefix==='finance'||prefix==='trips')return 'البيانات والحسابات';
 return 'الاختبارات الوظيفية والمعاملات';
}
function systemHealthGroupedChecks(checks){
 const titles=['البنية والدوال','الحماية والصلاحيات','البيانات والحسابات','الاختبارات الوظيفية والمعاملات'];
 return titles.map(title=>({title,items:checks.filter(c=>systemHealthCategory(c)===title)})).filter(g=>g.items.length);
}
function systemHealthGroupedHtml(checks){
 return systemHealthGroupedChecks(checks).map(group=>`<section class="system-diag-group"><h4>${esc(group.title)} <small>(${group.items.length})</small></h4><div class="diag-list">${group.items.map(systemHealthCheckRow).join('')}</div></section>`).join('');
}
function systemHealthCheckRow(c){
 const subject=systemHealthSubject(c),status=String(c.status||'NOT_TESTED');
 return `<details class="diag-item diag-row-${esc(status.toLowerCase())}" ${status==='FAIL'||status==='WARN'||status==='NOT_TESTED'?'open':''}><summary><span class="diag-status">${esc(status)}</span><strong>${esc(subject.name)}</strong><code dir="ltr">${esc(subject.code)}</code>${c.affectedCount!=null?`<small aria-label="عدد السجلات المتأثرة">${esc(c.affectedCount)}</small>`:''}</summary><div class="diag-info"><span>${esc(c.description||'')}</span>${status==='NOT_TESTED'?'<span>الحالة: لم ينفذ الفحص في هذه الجلسة، ولا تُعتبر نتيجته ناجحة أو فاشلة.</span>':''}</div></details>`;
}
function systemHealthReportText(){
 if(!SYSTEM_HEALTH_LAST)return '';
 const r=SYSTEM_HEALTH_LAST,checks=Array.isArray(r.checks)?r.checks:[];
 const counts={PASS:0,FAIL:0,WARN:0,NOT_TESTED:0};for(const c of checks)if(Object.hasOwn(counts,c.status))counts[c.status]++;
 const version=typeof APP_VERSION!=='undefined'?APP_VERSION:'2.4.82';
 const lines=['Tower App — تقرير فحص النظام','App version: '+version,'Mode: '+String(r.mode||''),'Checked at: '+systemHealthDate(r.checkedAt),'',`PASS: ${counts.PASS} | FAIL: ${counts.FAIL} | WARN: ${counts.WARN} | NOT_TESTED: ${counts.NOT_TESTED}`,''];
 lines.push('تنبيه: PASS يؤكد نجاح الفحص المحدد فقط؛ وجود الدالة وتفعيل RLS لا يثبتان عملها أو اختبار صلاحيات الأدوار.','');
 for(const group of systemHealthGroupedChecks(checks)){lines.push('=== '+group.title+' ===');for(const c of group.items){const part=systemHealthSubject(c);lines.push(`[${c.status}] ${part.name}: ${part.code}`,`  ${c.description||''}${c.affectedCount!=null?' | affected: '+c.affectedCount:''}`);if(c.status==='NOT_TESTED')lines.push('  لم يُنفذ في هذا الفحص؛ لا يُحتسب ناجحًا أو فاشلًا.');}lines.push('');}
 lines.push('',r.warning||'','ملاحظة: أي اختبار وظيفي غير منفذ يظل NOT_TESTED، ولا تتحول نتائج اختبارات سابقة إلى PASS تلقائيًا.');return lines.join('\n');
}
// Copy diagnostics only from the sanitized, user-visible result content. Never serialize RPC responses.
function diagnosticsSafeText(value){
 return String(value||'').replace(/(?:postgres(?:ql)?:\/\/|https?:\/\/)[^\s]+/gi,'[رابط محجوب]')
  .replace(/\b(?:bot\d{5,}:[A-Za-z0-9_-]{20,}|Bearer\s+\S+)\b/gi,'[رمز محجوب]')
  .replace(/(?:password|token|secret|authorization|api[_-]?key)\s*[:=]\s*\S+/gi,'[بيانات حساسة محجوبة]');
}
function diagnosticsVisibleLines(element){
 if(!element)return [];
 const texts=[];
 for(const el of element.querySelectorAll('.diag-overview,.diag-item,.system-diag-note,.muted')){
  const copy=el.cloneNode(true);copy.querySelectorAll('.diag-copy-btn').forEach(n=>n.remove());
  const t=copy.innerText||copy.textContent||'';const clean=diagnosticsSafeText(t).trim();if(clean)texts.push(clean);
 }
 return texts;
}
function updateDiagnosticsCopyState(){
 const telegram=$('telegramDiagCopy'),all=$('systemDiagCopyAll');
 if(telegram)telegram.disabled=!TELEGRAM_DIAGNOSTICS_LAST;
 if(all)all.disabled=!TELEGRAM_DIAGNOSTICS_LAST&&!SYSTEM_HEALTH_LAST;
}
function telegramDiagnosticsReportText(){
 if(!TELEGRAM_DIAGNOSTICS_LAST)return '';
 const lines=diagnosticsVisibleLines($('telegramDiagnosticsResult'));
 return ['Tower App — Telegram والطابور',`App version: ${typeof APP_VERSION!=='undefined'?APP_VERSION:'2.4.82'}`,
  `Checked at: ${systemHealthDate(TELEGRAM_DIAGNOSTICS_LAST.checkedAt)}`,'',...lines].join('\n');
}
async function diagnosticsCopyWithFeedback(text,button){
 if(!text){toast('شغّل الفحص أولًا.','error');return;}
 try{
  const result=await copyTextValue(diagnosticsSafeText(text),'تم نسخ نتيجة الفحص.');
  if(result&&button){const original=button.textContent;button.textContent='✓ تم النسخ';setTimeout(()=>{if(button.isConnected)button.textContent=original;},1800);}
 }catch(_){toast('تعذر النسخ التلقائي؛ انسخ النتيجة يدويًا.','error');}
}
async function copyTelegramDiagnosticsReport(){await diagnosticsCopyWithFeedback(telegramDiagnosticsReportText(),$('telegramDiagCopy'));}
async function copyCompleteDiagnosticsReport(){
 const sections=[];
 if(SYSTEM_HEALTH_LAST)sections.push(systemHealthReportText());
 if(TELEGRAM_DIAGNOSTICS_LAST)sections.push(telegramDiagnosticsReportText());
 await diagnosticsCopyWithFeedback(sections.join('\n\n'+'='.repeat(28)+'\n\n'),$('systemDiagCopyAll'));
}
function attachDiagnosticsRowCopyButtons(host){
 if(!host)return;
 host.querySelectorAll('.diag-overview,.diag-item').forEach(row=>{
  if(row.querySelector('.diag-copy-btn'))return;
  const btn=document.createElement('button');btn.type='button';btn.className='diag-copy-btn';
  btn.title='نسخ هذا القسم';btn.setAttribute('aria-label','نسخ هذا القسم');btn.textContent='⧉';
  btn.addEventListener('click',()=>{
   const copy=row.cloneNode(true);copy.querySelectorAll('.diag-copy-btn').forEach(n=>n.remove());
   diagnosticsCopyWithFeedback((copy.innerText||copy.textContent||'').trim(),btn);
  });
  row.appendChild(btn);
 });
}
async function exportSystemHealthReport(){
 const content=systemHealthReportText();if(!content){toast('شغّل الفحص أولًا.','error');return;}
 try{
  const blob=new Blob(['\uFEFF',content],{type:'text/plain;charset=utf-8'});
  await downloadBlobSafe(blob,'Tower_App_Diagnostics_'+Date.now()+'.txt');
  toast('تم طلب تنزيل التقرير. إذا لم يظهر الملف استخدم نسخ التقرير.');
 }catch(e){console.error('System diagnostic TXT export failed:',e);toast('تعذر تنزيل التقرير: '+(e?.message||'المتصفح منع التنزيل')+'؛ استخدم نسخ التقرير.','error');}
}
async function copySystemHealthReport(){
 const content=systemHealthReportText();if(!content){toast('شغّل الفحص أولًا.','error');return;}
 try{await copyTextValue(content,'تم نسخ تقرير الفحص.');}catch(e){toast('تعذر النسخ؛ حاول مرة أخرى.','error');}
}
async function runAdminConsistencyCheck(){
 const host=$('adminConsistencyResult'),btn=$('adminConsistencyButton');if(!host)return;
 if(btn)btn.disabled=true;host.textContent='جارٍ فحص اتساق الحسابات والوحدات…';
 try{const d=await run('adminRunDiagnostics');const issues=Array.isArray(d.issues)?d.issues:[];
  host.innerHTML=`<div class="diag-overview"><strong>${issues.length?'ملاحظات تحتاج مراجعة: '+issues.length:'لم تُكتشف مشاكل في الفحوص المنفذة'}</strong><span>فحص قراءة فقط · ${esc(systemHealthDate(d.checkedAt))}</span></div><p class="system-diag-note">نجاح هذا الفحص لا يعني اكتمال كل اختبارات الصلاحيات أو السلامة المالية.</p>${issues.length?`<div class="diag-list">${issues.map(i=>`<div class="diag-item"><span class="diag-status">${i.severity==='HIGH'?'تحذير مرتفع':'مراجعة'}</span><div class="diag-info"><strong>${esc(i.label||i.type||'ملاحظة')}</strong><code dir="ltr">${esc(i.entityId||'')}</code></div></div>`).join('')}</div>`:''}`;
 }catch(e){host.textContent='تعذر فحص الاتساق: '+errText(e);}finally{if(btn)btn.disabled=false;}
}
async function refreshDiagnostics(){try{const d=await run('adminRunDiagnostics');SYS_UI.settings.diagnostics=d;await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
async function repairManagers(){if(!await confirmAction({title:'إصلاح المدير المفقود',message:'سيتم تعيين أقدم عضو نشط مديرًا للوحدات التي لا يوجد لها مدير.',confirmLabel:'تنفيذ الإصلاح'}))return;try{const r=await withBackgroundSave(()=>run('adminRepairMissingManagers'));toast(`تم إصلاح ${r.repaired} وحدة.`);await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
async function checkBackupReadiness(){
 const target=$('backupReadinessResult');if(target)target.textContent='جاري الفحص…';
 try{const r=await run('adminBackupReadiness');const box=$('backupReadinessResult');if(!box)return;
  const checks=Array.isArray(r.checks)?r.checks:[];
  box.innerHTML=`<strong>${r.ready?'مكتمل':'غير جاهز — لم يتم إنشاء Backup'}</strong><span>${esc(r.message||'')}</span><ul>${checks.map(x=>`<li>${x.passed?'✓':'✕'} ${esc(x.description||'')}</li>`).join('')}</ul>`;
 }catch(e){const box=$('backupReadinessResult');if(box)box.textContent=errText(e);toast(errText(e),'error');}
}
async function createBackupNow(){try{const r=await withBackgroundSave(()=>run('adminCreateBackup'));toast('تم إنشاء النسخة الاحتياطية.');await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}}
async function repairDuplicateUnits(){const ok=await confirmAction({title:'إصلاح الوحدات المكررة',message:'سيتم إنشاء Backup أولًا ثم دمج المراجع على الوحدة الأساسية وتعطيل الصفوف الزائدة.',warning:'راجع Diagnostics بعد التنفيذ.',confirmLabel:'إنشاء Backup والإصلاح'});if(!ok)return;beginBackgroundSave();try{const r=await run('adminRepairDuplicateUnits');toast(`تم إصلاح ${r.merged} وحدة مكررة.`);await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
function openRestoreBackup(fileId,name){openModal(`<div class="modal-head"><div><h3>استعادة نسخة احتياطية</h3><p>${esc(name||'Backup')}</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="state-card warning-state"><strong>إجراء حساس</strong><span>سيُنشئ النظام Backup للحالة الحالية أولًا، ثم يستعيد بيانات النسخة المحددة ويشغّل Migration تلقائيًا.</span></div><label class="field"><span>اكتب العبارة للتأكيد</span><input id="restoreConfirm" class="ltr-id" dir="ltr" placeholder="RESTORE TOWER APP"></label><div class="form-actions"><button class="btn-sm danger" onclick="doRestoreBackup('${esc(fileId)}')">استعادة</button><button class="btn-sm" onclick="closeModal()">إلغاء</button></div>`);}
async function doRestoreBackup(fileId){const text=$('restoreConfirm').value;if(text!=='RESTORE TOWER APP'){toast('عبارة التأكيد غير مطابقة.','error');return;}closeModal();beginBackgroundSave();try{await run('adminRestoreBackup',fileId,text);toast('تمت استعادة النسخة الاحتياطية وترقية البيانات.');await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}finally{endBackgroundSave();}}
const RESET_UI={preview:null,busy:false};
const RESET_TABLE_LABELS={
 tower_payment_attachments:'مرفقات المدفوعات',tower_building_payments:'مدفوعات العمارة',tower_building_allocations:'توزيع المستحقات على الوحدات',tower_building_charges:'مستحقات العمارة',tower_collection_lines:'بنود التحصيل',tower_collection_reports:'تقارير التحصيل',tower_fund_entries:'حركات الصندوق',tower_trip_change_history:'سجل تعديلات المشاوير',tower_trip_payments:'مدفوعات المشاوير',tower_trip_settlement_details:'تفاصيل تسويات المشاوير',tower_trip_settlements:'تسويات المشاوير',tower_trips:'المشاوير',tower_telegram_pdf_jobs:'مهام إرسال تقارير PDF التجريبية'
};
function operationalResetServicesIncluded(preview){
 const tables=new Set((preview?.tables||[]).map(item=>String(item.table||'')));
 return tables.has('tower_service_subscriptions')&&tables.has('tower_service_change_requests');
}
function operationalResetTableLabel(table){return RESET_TABLE_LABELS[String(table||'')]||'جدول تشغيل آخر';}
function openOperationalReset(){RESET_UI.preview=null;RESET_UI.busy=false;openModal(`<div class="modal-head"><div><h3>تصفير بيانات التشغيل</h3><p>الأدمن فقط — لا يشمل الحسابات أو الوحدات أو تعريفات الخدمات أو الإعدادات.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><div class="state-card warning-state"><strong>الحذف النهائي لا يمكن التراجع عنه من هنا</strong><span>نسخة الـBackup اختيارية. لو محتاج ترجع البيانات لاحقًا، احتفظ بنسخة مستقلة قبل التصفير.</span></div><div id="resetPreviewBody"><p>اضغط «معاينة» لعرض عدد السجلات التي ستُحذف قبل التأكيد.</p></div><div class="form-actions"><button id="resetPreviewBtn" class="btn-sm primary" onclick="previewOperationalReset()">معاينة البيانات</button><button class="btn-sm" onclick="closeModal()">إغلاق</button></div>`);}
async function previewOperationalReset(){if(RESET_UI.busy)return;
 const oldPreview=RESET_UI.preview;
 const oldConfirm=$('resetConfirm')?.value||'';
 const oldAck=!!$('resetNoBackup')?.checked;
 const oldWelcome=!!$('resetWelcome')?.checked;
 RESET_UI.busy=true;
 const previewBtn=$('resetPreviewBtn');if(previewBtn)previewBtn.disabled=true;
 try{const r=await run('adminOperationalResetPreview');RESET_UI.preview=r;
 const body=$('resetPreviewBody');if(!body)return;
 const missingServices=!operationalResetServicesIncluded(r);
 body.innerHTML=`<div class="reset-preview-content" dir="rtl">${missingServices?'<div class="state-card warning-state" role="alert"><strong>التصفير غير مكتمل — تم إيقاف التنفيذ لحماية البيانات</strong><span>قاعدة البيانات الحالية لا تُدرج اشتراكات الخدمات وطلبات تعديلها في المعاينة. لن يسمح التطبيق بالتصفير حتى يتم اعتماد تحديث SQL الخاص بها والتحقق من نتيجته.</span></div>':''}<div class="state-card"><strong>سيُحذف ${Number(r.totalRows).toLocaleString('en-GB')} سجل من ${r.tableCount} جدول تشغيل</strong><span>سيُحتفظ بـ${r.protectedCount} جدولًا من بيانات النظام الأساسية وسجلاته.</span></div><div class="reset-table-list" role="list" aria-label="جداول التشغيل التي ستُصفّر">${(r.tables||[]).map(t=>`<div class="reset-table-row"><b class="reset-table-count" dir="ltr">${Number(t.count).toLocaleString('en-US')}</b><span class="reset-table-name">${esc(operationalResetTableLabel(t.table))}<small class="reset-technical-name" dir="ltr">${esc(t.table)}</small></span></div>`).join('')}</div><div class="reset-final-instruction">بعد مراجعة الأعداد، اكتب عبارة التأكيد وفعّل الموافقة، ثم اضغط زر «تصفير بيانات التشغيل نهائيًا» الموجود هنا. زر المعاينة بالأسفل لتحديث الأعداد فقط.</div><label class="field"><span>اكتب RESET TOWER APP للتأكيد</span><input id="resetConfirm" dir="ltr" class="ltr-id" autocomplete="off" placeholder="RESET TOWER APP" oninput="updateOperationalResetButton()"></label><label class="reset-ack"><input type="checkbox" id="resetWelcome"><span>إعادة إظهار معالج الترحيب للمستخدمين (اختياري، غير مفعّل افتراضيًا)</span></label><label class="reset-ack"><input type="checkbox" id="resetNoBackup" onchange="updateOperationalResetButton()"><span>أفهم أن النسخة الاحتياطية اختيارية، ولن تُنشأ نسخة جديدة تلقائيًا.</span></label><div class="form-actions"><button class="btn-sm danger" id="resetExecute" disabled onclick="doOperationalReset()">تصفير بيانات التشغيل نهائيًا</button></div></div>`;
 const sameCounts=!!oldPreview && oldPreview.tableCount===r.tableCount && oldPreview.totalRows===r.totalRows && (oldPreview.tables||[]).every((t,i)=>r.tables?.[i]?.table===t.table && Number(r.tables?.[i]?.count)===Number(t.count));
 if(sameCounts){$('resetConfirm').value=oldConfirm;$('resetNoBackup').checked=oldAck;$('resetWelcome').checked=oldWelcome;}
 else if(oldPreview){toast('أعداد البيانات اتغيّرت؛ راجع المعاينة وأكّد من جديد.','warning');}
 const btn=$('resetPreviewBtn');if(btn){btn.textContent='تحديث أعداد المعاينة';btn.classList.remove('primary');btn.setAttribute('aria-label','تحديث أعداد الجداول دون التصفير');}
 }catch(e){RESET_UI.preview=oldPreview;toast(errText(e),'error');}finally{RESET_UI.busy=false;const btn=$('resetPreviewBtn');if(btn)btn.disabled=false;updateOperationalResetButton();}}
function updateOperationalResetButton(){const b=$('resetExecute');if(b)b.disabled=RESET_UI.busy||!RESET_UI.preview||!operationalResetServicesIncluded(RESET_UI.preview)||$('resetConfirm')?.value!=='RESET TOWER APP'||!$('resetNoBackup')?.checked;}
async function doOperationalReset(){const r=RESET_UI.preview;if(!r||!operationalResetServicesIncluded(r)||RESET_UI.busy||$('resetConfirm')?.value!=='RESET TOWER APP'||!$('resetNoBackup')?.checked){toast('أكمل التأكيد بعد المعاينة.','error');return;}
 if(!await confirmAction({title:'تأكيد التصفير النهائي',message:`سيتم حذف ${r.totalRows} سجل من ${r.tableCount} جدول تشغيل. لن يتم إنشاء Backup تلقائيًا.`,warning:'لا يمكن التراجع عن الحذف من داخل التطبيق. الحسابات والوحدات والاشتراكات والإعدادات محفوظة.',confirmLabel:'تنفيذ التصفير'}))return;
 RESET_UI.busy=true;updateOperationalResetButton();try{const out=await withBackgroundSave(()=>run('adminOperationalReset',{confirmation:'RESET TOWER APP',acknowledgeNoBackup:true,previewToken:r.previewToken,resetWelcome:!!$('resetWelcome')?.checked}));RESET_UI.preview=null;closeModal();toast(`تم تصفير ${out.deletedRows} سجل بنجاح.`, 'success', {persistent:true});await (APP.page==='admin-registration'?renderAdminRequests('registration'):APP.page==='admin-pin'?renderAdminRequests('pin'):renderSystemAdmin());}catch(e){toast(errText(e),'error');}finally{RESET_UI.busy=false;}}



function filterExtraUnits(input){const list=input.closest('.extra-units-picker');if(!list)return;uiFilterCollection(input,'.extra-units-options label',list);}

// Telegram account settings (available for every signed-in role).
function telegramPdfStatusLabel(value){
 return ({SENT:'تم الإرسال',FAILED:'فشلت المحاولة',CLAIMED:'محجوز للتجهيز',SENDING:'جارٍ الإرسال'})[value]||'حالة غير معروفة';
}
async function refreshTelegramPdfHistory(){
 const target=$('telegramPdfHistory');if(!target)return;
 target.textContent='جارٍ تحديث سجل إرسال PDF…';
 try{
  const result=await run('telegramSettings','dailyPdfHistory');
  if(!$('telegramPdfHistory'))return;
  const jobs=Array.isArray(result?.jobs)?result.jobs:[];
  target.innerHTML=jobs.length?`<div class="settings-list">${jobs.map(job=>{
   const state=telegramPdfStatusLabel(job.status);
   const detail=job.status==='CLAIMED'||job.status==='SENDING'?' · قد تُعاد المحاولة بعد انتهاء مهلة الحجز':'';
   return `<div class="setting-row"><div><strong>${esc(job.day||'—')} — ${esc(state)}</strong><span>المحاولات: ${Math.max(0,Number(job.attempts)||0)}${detail}</span></div></div>`;
  }).join('')}</div>`:'لا توجد محاولات إرسال PDF مسجلة لهذا الحساب.';
 }catch(e){if($('telegramPdfHistory'))$('telegramPdfHistory').textContent='تعذر قراءة سجل الإرسال: '+errText(e);}
}
async function loadTelegramSettings(){const host=$('telegramSettingsBody');if(!host)return;
 try{const d=await run('telegramSettings','status');const pdfPref=['ADMIN','UNION'].includes(APP.ctx?.user?.role)?await run('telegramSettings','dailyPdfStatus'):null;const pdfSchedule=APP.ctx?.user?.role==='ADMIN'?await run('telegramSettings','getPdfSchedule'):null;if(!$('telegramSettingsBody'))return;
  host.innerHTML=`<div class="settings-list"><div class="setting-row"><div><strong>${d.linked?'الحساب مربوط':'غير مربوط'}</strong><span>${d.linked?'تتحكم في الرسائل الواردة لحسابك فقط.':'ابدأ الربط من محادثة خاصة مع البوت.'}</span></div><button class="btn-sm" onclick="telegramBeginLink()">${d.linked?'إعادة الربط':'ربط حسابي'}</button></div>${d.linked?`<div class="setting-row"><div><strong>تفعيل الإشعارات</strong></div><label class="tower-switch" title="تفعيل الإشعارات"><input type="checkbox" role="switch" aria-label="تفعيل الإشعارات" ${d.enabled?'checked':''} onchange="telegramSet('enabled',this.checked)"><span class="tower-switch-track" aria-hidden="true"></span></label></div><div class="setting-row"><div><strong>عرض التفاصيل المالية</strong><span>يمكنك إخفاء المبالغ في رسائل Telegram دون تغيير صلاحيات الحساب.</span></div><label class="tower-switch" title="عرض التفاصيل المالية"><input type="checkbox" role="switch" aria-label="عرض التفاصيل المالية" ${d.showAmounts?'checked':''} onchange="telegramSet('showAmounts',this.checked)"><span class="tower-switch-track" aria-hidden="true"></span></label></div>${['UNION','OPERATOR'].includes(APP.ctx?.user?.role)?`<div class="setting-row"><div><strong>الملخص اليومي</strong><span>ملخص يومي لرئيس الاتحاد والحارس فقط، حسب الموعد العام بتوقيت مصر.</span></div><label class="tower-switch" title="الملخص اليومي"><input type="checkbox" role="switch" aria-label="الملخص اليومي" ${d.dailyDigestEnabled?'checked':''} onchange="telegramSet('dailyDigestEnabled',this.checked)"><span class="tower-switch-track" aria-hidden="true"></span></label></div>`:''}${pdfPref?`<div class="setting-row"><div><strong>تقرير PDF المالي الدوري</strong><span>يُفحص تلقائيًا عند فتح أي حساب في النظام. يُولَّد التقرير في الخلفية من لقطة البيانات الحالية، ويُرسل للمستلمين الإداريين المفعّلين فقط. لا يعمل والتطبيق مغلق.</span></div><label class="tower-switch"><input type="checkbox" role="switch" aria-label="تفعيل PDF الدوري" ${pdfPref.enabled?'checked':''} onchange="telegramSetDailyPdf(this.checked)"><span class="tower-switch-track"></span></label></div>`:''}${pdfSchedule?`<div class="setting-row"><div><strong>موعد إرسال PDF الدوري</strong><span>تكرار مستقل عن الملخص النصي؛ اليومي للاختبارات، والأسبوعي يوم الأحد، والشهري في اليوم الذي تحدده؛ لو كان الشهر أقصر يكون الإرسال في آخر يوم منه. يبدأ الفحص عند فتح أي حساب، دون تشغيل مستقل والتطبيق مغلق.</span></div><div><select id="telegramPdfFrequency" aria-label="تكرار PDF الدوري" onchange="towerPdfMonthlyDayVisibility()"><option value="MONTHLY" ${pdfSchedule.frequency==='MONTHLY'?'selected':''}>شهريًا</option><option value="WEEKLY" ${pdfSchedule.frequency==='WEEKLY'?'selected':''}>أسبوعيًا (الأحد)</option><option value="DAILY" ${pdfSchedule.frequency==='DAILY'?'selected':''}>يوميًا (للاختبارات)</option></select><label id="telegramPdfMonthlyDayWrap" class="tower-pdf-month-day" style="display:${pdfSchedule.frequency==='MONTHLY'?'inline-flex':'none'}"><span>يوم الإرسال الشهري</span><select id="telegramPdfMonthlyDay" aria-label="يوم الإرسال الشهري">${Array.from({length:31},(_,i)=>`<option value="${i+1}" ${(Number(pdfSchedule.monthlyDay)||1)===i+1?'selected':''}>${i+1}</option>`).join('')}</select></label><input id="telegramPdfTime" type="time" step="60" value="${pdfSchedule.time}" aria-label="موعد إرسال PDF الدوري"><button class="btn-sm" onclick="adminSetPdfSchedule()">حفظ الموعد والتكرار</button></div></div></div>`:``}${pdfPref?`<section class="telegram-pdf-tools" aria-label="معاينة وإرسال التقرير الدوري"><p id="telegramPdfAutomationStatus" role="status" class="telegram-pdf-automation-status">حالة الفحص في هذه الجلسة: ${AUTO_PDF_LAST_STATUS.stage==='not_checked'?'لم يبدأ فحص التقارير بعد':'تم الفحص؛ راجع سجل المحاولات'}</p><div class="telegram-pdf-tools-head"><strong>التقرير المالي الدوري</strong><span>اعرض نسخة من التقرير الحالي، أو أرسلها لنفسك فقط دون التأثير على إرسال اليوم التلقائي.</span></div><div class="telegram-pdf-actions"><button id="telegramPdfPreview" class="btn-sm" type="button" onclick="telegramPreviewFinancialPdf()">معاينة</button><button id="telegramPdfSendNow" class="btn-sm primary" type="button" onclick="telegramSendFinancialPdfNow()" ${pdfPref.eligible?'':'disabled title="فعّل الإشعارات واربط حساب Telegram أولًا"'}>إرسال تجريبي</button></div><p class="telegram-pdf-tools-hint">المعاينة لا ترسل شيئًا. الإرسال التجريبي لا يُحتسب ضمن الإرسال الدوري.</p><div class="telegram-pdf-tools-head"><strong>آخر محاولات إرسال PDF لحسابك</strong><button class="btn-sm" type="button" onclick="refreshTelegramPdfHistory()">تحديث السجل</button></div><div id="telegramPdfHistory" role="status">جارٍ تحميل سجل الإرسال…</div><p class="telegram-pdf-tools-hint">يعرض آخر 5 محاولات مسجلة لهذا الحساب فقط، ولا يعرض محتوى التقرير.</p></section>`:''}<div class="actions"><button class="btn-sm" onclick="telegramTest()">إرسال رسالة اختبار</button><button class="btn-sm danger" onclick="telegramUnlink()">فصل الحساب</button></div>`:''}</div>`;
  if(pdfPref)void refreshTelegramPdfHistory();
  // Reuse the existing controls and event handlers, and place PDF controls in the PDF section of the same Notifications & Reports workspace.
  const pdfTarget=$('adminPdfSettingsBody');
  if(pdfTarget){
   pdfTarget.innerHTML='';
   const rows=[...host.querySelectorAll('.setting-row')];
   for(const row of rows){if(row.textContent.includes('تقرير PDF المالي الدوري')||row.textContent.includes('موعد إرسال PDF الدوري'))pdfTarget.appendChild(row);}
   const pdfTools=host.querySelector('.telegram-pdf-tools');if(pdfTools)pdfTarget.appendChild(pdfTools);
   if(!pdfTarget.children.length)pdfTarget.innerHTML='<p class="muted">اربط حساب Telegram لتفعيل خيارات التقرير الدوري والمعاينة والإرسال التجريبي.</p>';
  }
 }catch(e){host.textContent=errText(e);}}
async function telegramBeginLink(){try{const d=await run('telegramSettings','begin');openModal(`<div class="modal-head"><h3>ربط Telegram</h3><button class="icon-btn" onclick="closeModal()">×</button></div><p>افتح الرابط وابدأ المحادثة مع البوت خلال 10 دقائق. لا تشارك الرابط مع أي شخص.</p><div class="form-actions"><a class="btn-sm primary" href="${esc(d.url)}" target="_blank" rel="noopener noreferrer">فتح Telegram</a><button class="btn-sm" onclick="closeModal();loadTelegramSettings()">تحديث حالة الربط</button></div>`);}catch(e){toast(errText(e),'error');}}
async function telegramSet(key,value){try{await run('telegramSettings','set',{[key]:value});toast('تم تحديث إعدادات Telegram.');await loadTelegramSettings();}catch(e){toast(errText(e),'error');await loadTelegramSettings();}}
async function telegramTest(){try{await run('telegramSettings','test');toast('تم إرسال رسالة الاختبار.');}catch(e){toast(errText(e),'error');}}
async function telegramUnlink(){if(!await confirmAction({title:'فصل Telegram',message:'هل تريد إلغاء ربط هذا الحساب؟',confirmLabel:'فصل الحساب'}))return;try{await run('telegramSettings','unlink');await loadTelegramSettings();toast('تم فصل الحساب.');}catch(e){toast(errText(e),'error');}}

// V2.5.35: Persistent per-user onboarding with working settings in the wizard itself.
let WELCOME_UI={step:0,opening:false,trip:null,telegram:null,busy:false};
async function checkWelcomeWizard(){if(WELCOME_UI.opening)return;try{const progress=await run('welcomeProgress','get');if(!progress.completed)openWelcomeWizard(Number(progress.step||0));}catch(e){console.warn('WELCOME_CHECK_UNAVAILABLE');}}
function openWelcomeWizard(step=0){WELCOME_UI.step=Math.min(3,Math.max(0,Number(step)||0));WELCOME_UI.opening=true;WELCOME_UI.trip=null;WELCOME_UI.telegram=null;drawWelcomeWizard();}
function drawWelcomeWizard(){const step=WELCOME_UI.step;
 const pages=[
  `<h3>أهلًا بيك في Tower App</h3><div class="welcome-user"><span>مرحبًا</span><strong>${esc(APP.ctx?.user?.displayName||'')}</strong></div><p>هنراجع البيانات والإعدادات الأساسية لحسابك ووحدتك. الإعدادات الحالية محفوظة وهتظهر في الخطوات التالية.</p><p>مدير الوحدة وأعضاؤها لهم نفس صلاحيات الوحدة، باستثناء إضافة الأعضاء.</p><button type="button" class="btn-sm" onclick="welcomeEditProfile()">مراجعة</button>`,
  `<h3>إعدادات مسافة المشاوير وأتعابها</h3><p>اضبط قيم قريب ومتوسط وبعيد، والمسافة الافتراضية. هتتطبق على الوحدة، ومتاح تعديلها من أي عضو فيها.</p><div id="welcomeTripBody" aria-live="polite">جاري تحميل إعدادات الوحدة…</div>`,
  `<h3>إعدادات Telegram</h3><p>تقدر تربط حسابك وتحدد خصوصية الإشعارات، أو تتخطى الخطوة من غير ما تتعطل.</p><div id="welcomeTelegramBody" aria-live="polite">جاري تحميل إعدادات Telegram…</div>`,
  `<h3>جاهز للاستخدام</h3><p>تقدر تستخدم حسابك الآن، وتغيّر أي إعداد من صفحة الإعدادات في أي وقت.</p><p>الترحيب مش هيظهر تلقائيًا تاني بعد الإنهاء، إلا إذا اختار الأدمن إعادة إظهاره أثناء التصفير التشغيلي.</p>`
 ];
 openModal(`<div class="modal-head"><div><h3>معالج الترحيب · ${step+1} / 4</h3><p>مدير الوحدة وأعضاؤها</p></div><button class="icon-btn" onclick="welcomeClose()" aria-label="إغلاق">×</button></div><div class="welcome-wizard-content welcome-fill-image">${APP.ctx?.branding?.mainImageUrl?`<div class="welcome-hero"><img style="object-position:${Math.max(0,Math.min(100,Number(APP.ctx.branding.heroFocusX??50)||50))}% ${Math.max(0,Math.min(100,Number(APP.ctx.branding.heroFocusY??50)||50))}%" src="${esc(APP.ctx.branding.mainImageUrl)}" alt="" onerror="this.remove()"></div>`:''}${pages[step]}</div><div class="form-actions"><button class="btn-sm" onclick="welcomeClose()">لاحقًا</button>${step>0?'<button class="btn-sm" onclick="welcomeAdvance(-1)">السابق</button>':''}<button class="btn-sm primary" id="welcomeNext" onclick="welcomeAdvance(1)">${step===3?'إنهاء':step===1?'حفظ والمتابعة':'التالي'}</button></div>`);
 if(step===1)welcomeLoadTrip();if(step===2)welcomeLoadTelegram();
}
function welcomeClose(){WELCOME_UI.opening=false;closeModal();}
function welcomeEditProfile(){welcomeClose();openProfileModal();}
async function welcomeLoadTrip(){const expected=WELCOME_UI.step;try{const st=WELCOME_UI.trip||await run('getMyTripSettings');WELCOME_UI.trip=st;if(!WELCOME_UI.opening||WELCOME_UI.step!==expected)return;const host=$('welcomeTripBody');if(!host)return;
 host.innerHTML=`<div id="welcomeTripFields" class="form-grid">${[['feeNear','قريب'],['feeMedium','متوسط'],['feeFar','بعيد']].map(([id,label])=>`<label class="field"><span>${label} — أتعاب المشوار</span><input id="welcome_${id}" inputmode="decimal" required value="${esc(st[id]??0)}" aria-label="${label}"></label>`).join('')}<label class="field"><span>المسافة الافتراضية</span><select id="welcome_defaultDistance">${[['NEAR','قريب'],['MEDIUM','متوسط'],['FAR','بعيد']].map(([id,label])=>`<option value="${id}" ${st.defaultDistance===id?'selected':''}>${label}</option>`).join('')}</select></label></div>`;
 }catch(e){if(WELCOME_UI.step===expected&&$('welcomeTripBody'))$('welcomeTripBody').textContent='تعذر تحميل إعدادات المسافة: '+errText(e);}}
async function welcomeSaveTrip(){const st=WELCOME_UI.trip,form=$('welcomeTripFields');if(!st||!form){toast('انتظر تحميل إعدادات الوحدة.','error');return false;}const p={feeNear:$('welcome_feeNear').value.trim(),feeMedium:$('welcome_feeMedium').value.trim(),feeFar:$('welcome_feeFar').value.trim(),defaultDistance:$('welcome_defaultDistance').value};const same=['feeNear','feeMedium','feeFar'].every(k=>Number(p[k])===Number(st[k]))&&p.defaultDistance===st.defaultDistance;if(same)return true;try{await run('updateMyTripSettings',p);WELCOME_UI.trip={...st,...p};toast('تم حفظ إعدادات المسافة للوحدة.');return true;}catch(e){toast(errText(e),'error');return false;}}
async function welcomeLoadTelegram(){const expected=WELCOME_UI.step;try{const status=await run('telegramSettings','status');WELCOME_UI.telegram=status;if(!WELCOME_UI.opening||WELCOME_UI.step!==expected)return;const host=$('welcomeTelegramBody');if(!host)return;
 host.innerHTML=`<div class="settings-list"><div class="setting-row"><div><strong>${status.linked?'حساب Telegram مربوط':'Telegram غير مربوط'}</strong><span>${status.linked?'يمكنك التحكم في الإشعارات والخصوصية.':'اربط حسابك باستخدام رابط مؤقت يُستخدم مرة واحدة.'}</span></div><button type="button" class="btn-sm" onclick="welcomeTelegramLink()">${status.linked?'إعادة الربط':'ربط Telegram'}</button></div><div id="welcomeTelegramLink"></div>${status.linked?`<label class="setting-row"><span>تفعيل الإشعارات</span><input type="checkbox" ${status.enabled?'checked':''} onchange="welcomeTelegramToggle('enabled',this.checked)"></label><label class="setting-row"><span>إظهار المبالغ في Telegram</span><input type="checkbox" ${status.showAmounts?'checked':''} onchange="welcomeTelegramToggle('showAmounts',this.checked)"></label><div class="compact-actions"><button class="btn-sm" type="button" onclick="welcomeTelegramTest()">إرسال رسالة اختبار</button><button class="btn-sm" type="button" onclick="welcomeLoadTelegram()">تحديث حالة الربط</button></div>`:'<button class="btn-sm" type="button" onclick="welcomeLoadTelegram()">تحديث الحالة</button>'}</div>`;
 }catch(e){if(WELCOME_UI.step===expected&&$('welcomeTelegramBody'))$('welcomeTelegramBody').textContent='تعذر تحميل Telegram: '+errText(e);}}
async function welcomeTelegramLink(){try{const result=await run('telegramSettings','begin');const url=String(result?.url||'');if(!/^https:\/\/(?:t\.me|telegram\.me)\//i.test(url))throw Error('رابط Telegram غير صالح.');const el=$('welcomeTelegramLink');if(el)el.innerHTML=`<p>الرابط صالح لمدة 10 دقائق. لا تشاركه مع أي شخص.</p><a class="btn-sm primary" target="_blank" rel="noopener noreferrer" href="${esc(url)}">فتح Telegram</a>`;}catch(e){toast(errText(e),'error');}}
async function welcomeTelegramToggle(key,value){try{await run('telegramSettings','set',{[key]:value});toast('تم تحديث إعداد Telegram.');await welcomeLoadTelegram();}catch(e){toast(errText(e),'error');await welcomeLoadTelegram();}}
async function welcomeTelegramTest(){try{await run('telegramSettings','test');toast('تم إرسال رسالة الاختبار.');}catch(e){toast(errText(e),'error');}}
async function welcomeAdvance(delta){if(WELCOME_UI.busy)return;const current=WELCOME_UI.step;const next=current+delta;WELCOME_UI.busy=true;const button=$('welcomeNext');if(button)button.disabled=true;try{
 if(delta>0&&current===1&&!await welcomeSaveTrip())return;
 if(next>3){await run('welcomeProgress','save',{step:4,complete:true});welcomeClose();toast('تم إعداد حسابك.');return;}
 const step=Math.max(0,next);await run('welcomeProgress','save',{step,complete:false});WELCOME_UI.step=step;drawWelcomeWizard();
 }catch(e){toast(errText(e),'error');}finally{WELCOME_UI.busy=false;const btn=$('welcomeNext');if(btn)btn.disabled=false;}}
async function reviewMemberOpinion(requestId,opinion){const note=await promptAction({title:opinion==='SUPPORT'?'تأييد طلب الانضمام':'الاعتراض على طلب الانضمام',message:'قرارك استشاري، والأدمن يقدر يحسم الطلب من غير انتظار.',label:'ملاحظة اختيارية',confirmLabel:'تسجيل الرأي'});if(note===null)return;try{await run('managerMemberOpinion',{requestId,opinion,note});toast('تم تسجيل رأيك للأدمن.');await renderUnits();}catch(e){toast(errText(e),'error');}}

// Centrally stored brand images; client downsizes uploads before sending to Worker.
const BRAND_FILE_PREVIEWS={logo:null,main:null};
const BRAND_PENDING_REMOVALS={logo:false,main:false};
async function previewBrandFile(kind,input){const label=$(input.id+'Label');if(label)label.textContent=input.files?.[0]?.name||'لم يتم اختيار ملف';const file=input.files?.[0];if(!file)return;if(!['image/png','image/jpeg','image/webp'].includes(file.type)){toast('الصورة لازم تكون PNG أو JPG أو WebP.','error');return;}try{const dataUrl=await fileAsDataUrl(file);const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=dataUrl;});const limits=kind==='logo'?[512,512]:[1920,1080];const scale=Math.min(1,limits[0]/img.width,limits[1]/img.height);const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);let data='';for(const q of [.86,.73,.6,.45]){data=canvas.toDataURL('image/webp',q);if(data.length<620000)break;}if(data.length>=620000)throw Error('الصورة كبيرة جدًا بعد الضغط. اختر صورة أبسط.');BRAND_FILE_PREVIEWS[kind]=data;BRAND_PENDING_REMOVALS[kind]=false;const el=$(kind==='logo'?'brandLogoPreview':'brandMainPreview');el.src=data;el.hidden=false;if(kind==='main'){document.querySelectorAll('.brand-crop-photo').forEach(photo=>photo.src=data);updateBrandCropPreview();}const hint=document.createElement('small');hint.textContent=`الأبعاد: ${img.width} × ${img.height} بكسل · بعد التجهيز: ${canvas.width} × ${canvas.height}`;el.insertAdjacentElement('afterend',hint);}catch(e){toast('تعذر تجهيز الصورة: '+errText(e),'error');}}
async function saveBrandImage(kind){const data=BRAND_FILE_PREVIEWS[kind];if(!data){toast('اختَر صورة أولًا.','error');return;}try{await withBackgroundSave(()=>run('adminBrandAsset',{kind,data}));BRAND_FILE_PREVIEWS[kind]=null;APP.ctx.branding={...(APP.ctx.branding||{}),[kind==='logo'?'logoUrl':'mainImageUrl']:'/api/brand/'+kind};applyBranding(APP.ctx.branding);toast('تم حفظ الصورة لكل المستخدمين.');}catch(e){toast(errText(e),'error');}}
async function removeBrandImage(kind){
 BRAND_PENDING_REMOVALS[kind]=true;BRAND_FILE_PREVIEWS[kind]=null;
 const input=$(kind==='logo'?'brandLogoFile':'brandMainFile');if(input)input.value='';
 const el=$(kind==='logo'?'brandLogoPreview':'brandMainPreview');if(el){el.hidden=true;el.removeAttribute('src');}
 const status=$('brandSaveStatus');if(status)status.textContent=(kind==='logo'?'استعادة اللوجو الافتراضي':'حذف الصورة الرئيسية')+' قيد الانتظار. اضغط «حفظ التغييرات» لاعتمادها، أو إلغاء للتراجع.';
}

async function reviewRegistrationOpinion(requestId,opinion){const note=await promptAction({title:opinion==='SUPPORT'?'تأييد انضمام العضو':'الاعتراض على الانضمام',message:'رأيك يظهر للأدمن كمعلومة استشارية ولا يوقف طلب العضوية.',label:'ملاحظة اختيارية',confirmLabel:'تسجيل الرأي'});if(note===null)return;try{await run('managerRegistrationOpinion',{requestId,opinion,note});toast('تم تسجيل رأيك للأدمن.');await renderUnits();}catch(e){toast(errText(e),'error');}}

async function loadUnitFundVisibility(unitId){
 const select=document.getElementById('unitFundVisibility');if(!select)return;
 try{const state=await run('getUnitFundVisibility',unitId);if(APP.activeUnitId!==unitId)return;
  select.innerHTML='<option value="true">مسموح</option><option value="false">غير مسموح</option>';
  select.value=String(state.membersCanView);select.disabled=false;
 }catch(e){select.innerHTML='<option>تعذر تحميل الإعداد</option>';select.disabled=true;toast(errText(e),'error');}
}
async function saveUnitFundVisibility(unitId){
 const select=document.getElementById('unitFundVisibility');if(!select)return;
 select.disabled=true;
 try{await run('setUnitFundVisibility',unitId,select.value==='true');toast('تم حفظ خصوصية حسابات الاتحاد.');}
 catch(e){toast(errText(e),'error');}finally{if(select.isConnected)await loadUnitFundVisibility(unitId);}
}


// Shared total is finalized server-side. This UI never calculates or submits dues.
// Management must be available before a shared-cost allocation can be previewed.
// The SQL RPC remains the single authority for amounts, eligibility and finalization.
async function openSharedAllocation(id,refresh=false){
 const current=(SERVICE_UI.services||[]).find(x=>x.serviceId===id);if(current?current.pricingMode==='SHARED_TOTAL':TASK_PROJECT_DATA.has(id))return openTaskProject(id,true,'members');
 const item=(SERVICE_UI.services||[]).find(s=>s.serviceId===id);
 if(!item||item.pricingMode!=='SHARED_TOTAL')return;
 // Always load authoritative subscription statuses before opening management.
 // SERVICE_UI is a cached list and can be stale after approving or adding subscribers.
 let context;
 try{context=await towerReadServiceManagerContext(id);}
 catch(e){toast('تعذر تحديث حالة الاشتراكات: '+errText(e),'error');return;}
 const latest=context?.subscriptions||[];
 const active=latest.filter(x=>x.status==='ACTIVE');
 const pending=latest.filter(x=>x.status==='PENDING');
 const freshItem={...item,...(context?.service||{})};
 const isOpen=freshItem.enrollmentStatus==='OPEN';
 const isClosed=freshItem.enrollmentStatus==='CLOSED';
 const isFinal=freshItem.enrollmentStatus==='FINALIZED';
 const estimate=serviceSharedDisplay(freshItem,active);
 const statusLabel=isOpen?'مفتوح لاستقبال الاشتراكات':isClosed?'مغلق — بانتظار الاعتماد':'تم اعتماد التوزيع';
 // Changes to an ACTIVE subscription require a server-side auditable action; do not fake a delete in the UI.

 let summary=`<div class="small muted" role="status">تم تحديث حالة الاشتراكات من النظام.</div>${serviceUiSharedHeadline(freshItem,active)}<p class="service-management-pending">الطلبات المعلقة: <strong>${pending.length}</strong></p>`;

 const noMembers='<div class="state-card">لا يوجد مشتركون نشطون. أضف وحدات لتحديث النصيب التقديري.</div>';
 const pendingMsg=pending.length?'<div class="state-card">توجد طلبات معلقة؛ راجعها قبل إغلاق الاشتراك.</div>':'';
 const canClose=isOpen&&active.length>0&&pending.length===0;
 const canFinalize=isClosed&&active.length>0&&pending.length===0;
 const membersSorted=[...active].sort((a,b)=>Number(a.floor||0)-Number(b.floor||0)||Number(a.unitNumber||0)-Number(b.unitNumber||0));
 const memberRows=membersSorted.map(x=>`<div class="shared-member-card" data-member-search="${esc([x.unitNumber,x.floor,x.managerName||''].join(' ').toLocaleLowerCase())}" data-member-floor="${esc(String(x.floor||''))}" data-member-id="${esc(x.subscriptionId)}"><div class="shared-member-info">${isOpen?`<input type="checkbox" class="shared-member-check" data-subscription-id="${esc(x.subscriptionId)}" aria-label="تحديد الوحدة ${esc(unitNo(x.unitNumber||'—'))}" onchange="towerUpdateMemberSelection()">`:''}<span><strong>الوحدة ${esc(unitNo(x.unitNumber||'—'))}</strong> · الدور ${esc(floorNo(x.floor||'—'))}${x.managerName?' · '+esc(x.managerName):''}</span></div>${isOpen?`<button type="button" class="shared-remove-button" onclick="removeSharedSubscriber('${esc(id)}','${esc(x.subscriptionId)}')" aria-label="إزالة اشتراك الوحدة ${esc(unitNo(x.unitNumber||'—'))}" title="إزالة المشترك">✕</button>`:''}</div>`).join('');
 const floors=[...new Set(membersSorted.map(x=>String(x.floor||'')).filter(Boolean))].sort((a,b)=>Number(a)-Number(b));
 const listRows=active.map(x=>({id:String(x.subscriptionId),unit:String(x.unitNumber||''),floor:String(x.floor||''),manager:String(x.managerName||''),label:unitNo(x.unitNumber||'—')}));
 const previous=refresh&&window.TOWER_SHARED_MEMBERS?.serviceId===String(id)?window.TOWER_SHARED_MEMBERS:null;
 const view=previous?{query:$('towerSharedSearch')?.value||'',floor:$('towerSharedFloor')?.value||'',order:$('towerSharedOrder')?.value||'asc',scrollTop:$('modalSheet')?.scrollTop||0}:null;
 const sharedState={serviceId:String(id),rows:listRows,selected:new Set(previous?[...previous.selected].filter(key=>listRows.some(row=>row.id===key)):[]),isOpen};
 const memberControls=`<section class="shared-members-section" aria-label="مشتركو المهمة"><div class="shared-section-heading"><h3>المشتركون <span class="badge" id="towerSharedMemberTotal">${active.length}</span></h3>${isOpen?`<button type="button" class="btn-sm primary" onclick="towerToggleInlineMemberPicker('${esc(id)}')" aria-controls="towerInlineMemberPicker" aria-expanded="false" id="towerInlinePickerToggle">＋ إضافة مشتركين</button>`:''}</div><div class="tower-shared-member-tools"><input id="towerSharedSearch" type="search" autocomplete="off" placeholder="ابحث برقم الوحدة أو الدور أو الاسم" aria-label="بحث المشتركين" oninput="towerRenderSharedMembers()"><select id="towerSharedFloor" aria-label="فلترة حسب الدور" onchange="towerRenderSharedMembers()"><option value="">جميع الأدوار</option>${[...new Set(listRows.map(x=>x.floor))].sort((a,b)=>Number(a)-Number(b)).map(f=>`<option value="${esc(f)}">الدور ${esc(floorNo(f||'—'))}</option>`).join('')}</select><select id="towerSharedOrder" aria-label="ترتيب المشتركين" onchange="towerRenderSharedMembers()"><option value="asc">الدور ثم الوحدة ↑</option><option value="desc">الدور ثم الوحدة ↓</option></select></div><div class="tower-shared-bulkbar"><label><input id="towerSharedSelectVisible" type="checkbox" onchange="towerSelectSharedVisible(this.checked)" ${isOpen?'':'disabled'}> تحديد النتائج الظاهرة</label><span class="small muted" id="towerSharedSelectionCount">0 محدد</span>${isOpen?`<button type="button" class="btn-sm danger-soft" id="towerSharedRemoveSelected" onclick="towerRemoveSelectedShared('${esc(id)}')" disabled>إزالة المحددين</button><button type="button" class="btn-sm" onclick="towerClearSharedSelection()">إلغاء التحديد</button>`:''}</div><div class="shared-members-grid" id="towerSharedMemberList" role="list"></div><div class="small muted" id="towerSharedVisibleCount" aria-live="polite"></div></section>`;
 const actions=`<div class="form-actions shared-actions">${isOpen?`<button class="btn-sm primary" ${canClose?'':'disabled title="يلزم مشترك نشط وعدم وجود طلبات معلقة"'} onclick="previewCombinedTaskAllocation('${esc(id)}')">إغلاق الاشتراك واعتماد التوزيع</button>`:isClosed?`<button class="btn-sm service-action-secondary" onclick="reopenSharedEnrollment('${esc(id)}')">↺ إعادة فتح الاشتراك</button><button class="btn-sm primary" disabled title="انتظر نجاح معاينة التوزيع" data-shared-finalize="1" onclick="finalizeSharedAllocation('${esc(id)}')">✓ اعتماد التوزيع</button>`:'<span class="badge success">التوزيع معتمد</span>'}<button class="btn-sm" onclick="closeModal();openServiceSubscribers('${esc(id)}')">▤ التقرير</button><button class="btn-sm" onclick="closeModal()">✕ إغلاق</button></div>`;
 openModal(`<div class="modal-head"><div><h3>${esc(freshItem.name||item.name)}</h3><p>${esc(serviceUiSubtitle(freshItem))}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="إغلاق إدارة الاشتراك">×</button></div><div class="shared-flow-status"><span class="badge ${isFinal?'success':''}">${esc(statusLabel)}</span><span class="small muted">الطلبات المعلقة: ${pending.length}</span></div>${serviceUiSharedHeadline(freshItem,active)}${pendingMsg}${memberControls}${isOpen?'<div id="towerInlineMemberPicker" class="tower-inline-member-picker" hidden></div>':''}${!isOpen&&active.length?'<div id="sharedAllocationPreview" class="shared-preview" aria-live="polite"><p class="small muted">جاري التحقق من معاينة التوزيع…</p></div>':!active.length?noMembers:''}<p class="small muted shared-footnote">${isFinal?'المبالغ المالية النهائية تُراجع من دفتر المستحقات.':'النصيب المعروض تقديري، ولا تنشأ مستحقات إلا بعد الاعتماد النهائي.'}</p>${actions}`,true,refresh);
 window.TOWER_SHARED_MEMBERS=sharedState;
 if(view){$('towerSharedSearch').value=view.query;$('towerSharedFloor').value=view.floor;$('towerSharedOrder').value=view.order;}
 towerRenderSharedMembers();
 if(view)$('modalSheet').scrollTop=view.scrollTop;
 if(!active.length||isOpen)return;
 const previewNode=document.getElementById('sharedAllocationPreview');
 try{
  const d=await run('previewSharedServiceAllocation',id);TASK_CLOSE_PREVIEWS.set(id,d.allocations);
  if(!previewNode||!previewNode.isConnected)return;
  const rows=Array.isArray(d.allocations)?d.allocations:[];
  const valid=rows.length===active.length&&rows.every(x=>Number.isFinite(Number(x.amount)));
  previewNode.innerHTML=valid?`<div class="state-card">✓ تمت معاينة ${rows.length} نصيبًا بنجاح. إجمالي التكلفة ${money(Number(d.totalBudget))}. ${isClosed?'يمكن اعتماد التوزيع الآن.':'التوزيع معتمد.'}</div>`:'<div class="state-card">تعذرت مطابقة أنصبة التوزيع مع المشتركين. لا تعتمد التوزيع.</div>';
  const finalizeButton=document.querySelector('[data-shared-finalize="1"]');
  if(canFinalize&&valid&&finalizeButton){finalizeButton.disabled=false;finalizeButton.removeAttribute('title');}
 }catch(e){
  if(previewNode&&previewNode.isConnected)previewNode.innerHTML=`<div class="state-card">تعذرت معاينة التوزيع حاليًا. يمكنك إدارة الاشتراكات، لكن لا تعتمد التوزيع قبل حل المشكلة. <span class="small">${esc(errText(e))}</span></div>`;
 }
}
function towerFilterMembers(){
 const rows=[...document.querySelectorAll('#towerMemberRows .shared-member-card')];
 const q=($('towerMemberSearch')?.value||'').trim().toLocaleLowerCase(),floor=$('towerMemberFloor')?.value||'',desc=$('towerMemberSort')?.value==='desc';
 const grid=$('towerMemberRows');if(grid){rows.sort((a,b)=>{const fa=Number(a.dataset.memberFloor||0),fb=Number(b.dataset.memberFloor||0);return (desc?-1:1)*(fa-fb||Number(a.querySelector('strong')?.textContent.replace(/\D/g,'')||0)-Number(b.querySelector('strong')?.textContent.replace(/\D/g,'')||0));}).forEach(r=>grid.appendChild(r));}
 let count=0;rows.forEach(r=>{r.hidden=!!((q&&!r.dataset.memberSearch.includes(q))||(floor&&r.dataset.memberFloor!==floor));if(!r.hidden)count++;});
 const label=$('towerMemberFilterCount');if(label)label.textContent=`${count} من ${rows.length} مشترك`;
 towerUpdateMemberSelection();
}
function towerUpdateMemberSelection(){
 const boxes=[...document.querySelectorAll('#towerMemberRows .shared-member-check')],selected=boxes.filter(c=>c.checked),visible=boxes.filter(c=>!c.closest('.shared-member-card').hidden),all=$('towerMemberSelectVisible');
 if(all){all.checked=visible.length>0&&visible.every(c=>c.checked);all.indeterminate=visible.some(c=>c.checked)&&!all.checked;}
 const n=$('towerSelectedMemberCount');if(n)n.textContent=`${selected.length} محدد${selected.some(c=>c.closest('.shared-member-card').hidden)?' (بعضها خارج الفلتر)':''}`;
 const btn=$('towerBulkRemove');if(btn)btn.disabled=selected.length===0;
}
function towerSelectVisibleMembers(yes){document.querySelectorAll('#towerMemberRows .shared-member-card:not([hidden]) .shared-member-check').forEach(c=>c.checked=yes);towerUpdateMemberSelection();}
function towerClearMemberSelection(){document.querySelectorAll('#towerMemberRows .shared-member-check').forEach(c=>c.checked=false);towerUpdateMemberSelection();}
async function towerRemoveSelectedMembers(id){
 const boxes=[...document.querySelectorAll('#towerMemberRows .shared-member-check:checked')],ids=[...new Set(boxes.map(c=>c.dataset.subscriptionId))];if(!ids.length)return;
 if(!await confirmAction({title:'إزالة مشتركين',message:`سيتم إنهاء اشتراكات ${ids.length} وحدات، ومنها وحدات قد تكون مخفية بالفلترة. سيتم تحديث النصيب التقديري بعد العملية.`,confirmLabel:`إزالة ${ids.length} مشترك`}))return;
 const btn=$('towerBulkRemove');if(btn)btn.disabled=true;
 let done=0;try{for(const sid of ids){await run('removeSharedServiceSubscriber',id,sid);done++;}toast(`تم إنهاء ${done} اشتراك.`);await renderServices();await openSharedAllocation(id,true);}catch(e){toast(`تمت إزالة ${done} من ${ids.length}. ${errText(e)}`,'error');await renderServices();await openSharedAllocation(id,true);}
}
function towerSharedVisibleRows(){
 const state=window.TOWER_SHARED_MEMBERS;if(!state)return [];
 const query=(document.getElementById('towerSharedSearch')?.value||'').trim();
 const floor=document.getElementById('towerSharedFloor')?.value||'';
 const descending=document.getElementById('towerSharedOrder')?.value==='desc';
 return state.rows.filter(row=>(!floor||row.floor===floor)&&uiSearchMatch([row.unit,row.label,row.floor,row.manager].join(' '),query)).sort((a,b)=>{const cmp=(Number(a.floor)-Number(b.floor))||(Number(a.unit)-Number(b.unit))||a.label.localeCompare(b.label,'ar');return descending?-cmp:cmp;});
}
function towerRenderSharedMembers(){
 const state=window.TOWER_SHARED_MEMBERS,host=document.getElementById('towerSharedMemberList');if(!state||!host)return;
 const rows=towerSharedVisibleRows();
 host.innerHTML=rows.map(x=>`<div class="shared-member-card" role="listitem"><label class="tower-shared-member-label">${state.isOpen?`<input type="checkbox" aria-label="تحديد الوحدة ${esc(x.label)}" ${state.selected.has(x.id)?'checked':''} onchange="towerSelectSharedMember('${esc(x.id)}',this.checked)">`:''}<span class="tower-shared-member-line"><strong>الوحدة ${esc(x.label)}</strong><span>الدور ${esc(floorNo(x.floor||'—'))}</span>${x.manager?`<span>${esc(x.manager)}</span>`:''}</span></label>${x.financial?`<div class="task-member-money"><span><small>${state.finalized?'المستحق':'التقديري'}</small><b>${x.amount==null?'—':taskExactMoney(x.amount)}</b></span>${state.finalized?`<span><small>المدفوع</small><b>${x.paid==null?'—':taskExactMoney(x.paid)}</b></span><span><small>المتبقي</small><b>${x.remaining==null?'—':taskExactMoney(x.remaining)}</b></span>`:''}</div>`:''}${state.isOpen?`<button type="button" class="tower-shared-remove-icon" aria-label="إزالة اشتراك الوحدة ${esc(x.label)}" title="إزالة الوحدة ${esc(x.label)}" onclick="removeSharedSubscriber('${esc(state.serviceId)}','${esc(x.id)}')">×</button>`:''}</div>`).join('')||'<div class="state-card">لا توجد نتائج مطابقة للبحث أو الفلتر.</div>';
 const h=typeof taskProjectCurrentHub==='function'?taskProjectCurrentHub():null;if(h?.view&&h.serviceId===state.serviceId){h.view.selected=new Set(state.selected);h.view.query=$('towerSharedSearch')?.value||'';h.view.floor=$('towerSharedFloor')?.value||'';h.view.order=$('towerSharedOrder')?.value||'asc';}
 const count=document.getElementById('towerSharedSelectionCount');if(count)count.textContent=`${state.selected.size} محدد`;
 const shown=document.getElementById('towerSharedVisibleCount');if(shown)shown.textContent=`الظاهر: ${rows.length} من ${state.rows.length} وحدة`;
 const bulk=document.getElementById('towerSharedRemoveSelected');if(bulk){bulk.disabled=!state.selected.size;bulk.textContent=state.selected.size?`إزالة ${state.selected.size} من المحددين`:'إزالة المحددين';}
 const selectAll=document.getElementById('towerSharedSelectVisible');if(selectAll){selectAll.checked=rows.length>0&&rows.every(r=>state.selected.has(r.id));selectAll.indeterminate=rows.some(r=>state.selected.has(r.id))&&!selectAll.checked;}
}
function towerSelectSharedMember(id,on){const state=window.TOWER_SHARED_MEMBERS;if(!state||!state.isOpen)return;if(on)state.selected.add(id);else state.selected.delete(id);towerRenderSharedMembers();}
function towerSelectSharedVisible(on){const state=window.TOWER_SHARED_MEMBERS;if(!state||!state.isOpen)return;for(const row of towerSharedVisibleRows()){if(on)state.selected.add(row.id);else state.selected.delete(row.id);}towerRenderSharedMembers();}
function towerClearSharedSelection(){const state=window.TOWER_SHARED_MEMBERS;if(!state)return;state.selected.clear();towerRenderSharedMembers();}
async function towerRemoveSelectedShared(id){
 const state=window.TOWER_SHARED_MEMBERS;if(!state||!state.isOpen||state.serviceId!==String(id)||!state.selected.size)return;
 const selected=[...state.selected];
 if(!await confirmAction({title:'إزالة المشتركين المحددين',message:`سيتم إنهاء اشتراكات ${selected.length} وحدة، بما فيها أي وحدات محددة خارج نتائج البحث الحالية. ستتغير التقديرات دون إنشاء مستحقات.`,confirmLabel:`إزالة ${selected.length} وحدة`}))return;
 const button=document.getElementById('towerSharedRemoveSelected');if(button)button.disabled=true;
 let done=0;
 try{for(const subscriptionId of selected){await run('removeSharedServiceSubscriber',id,subscriptionId);done++;}await renderServices();await openSharedAllocation(id,true);toast(`تمت إزالة ${done} وحدة.`);}
 catch(e){await renderServices();await openSharedAllocation(id,true);toast(`تمت إزالة ${done} من ${selected.length}. تعذر استكمال العملية: ${errText(e)}`,'error');}
}
async function towerToggleInlineMemberPicker(id){
 const host=document.getElementById('towerInlineMemberPicker'),toggle=document.getElementById('towerInlinePickerToggle');
 if(!host)return;
 if(!host.hidden){host.hidden=true;if(toggle)toggle.setAttribute('aria-expanded','false');return;}
 host.hidden=false;if(toggle)toggle.setAttribute('aria-expanded','true');host.scrollIntoView({behavior:'smooth',block:'nearest'});
 host.innerHTML='<p class="small muted">جاري تحميل الوحدات المتاحة…</p>';
 try{
  const d=await towerReadServiceManagerContext(id);
  if(!host.isConnected||host.hidden)return;
  if(d.service?.enrollmentStatus!=='OPEN'){host.innerHTML='<p class="service-info-note">الاشتراك مغلق؛ لا يمكن إضافة وحدات.</p>';return;}
  const active=new Set((d.subscriptions||[]).filter(x=>['ACTIVE','PENDING'].includes(x.status)).map(x=>x.unitId));
  window.SERVICE_PICK={...d,active,selected:new Set()};
  host.innerHTML=`<div class="unit-selector-toolbar service-unit-toolbar"><label class="service-unit-search-label" for="serviceUnitSearch">اختيار وحدات جديدة</label><input id="serviceUnitSearch" type="search" autocomplete="off" placeholder="بحث بالوحدة أو الدور أو الاسم" oninput="renderServiceUnitPicker()" aria-controls="serviceUnitPicker"><button class="btn-sm" type="button" onclick="serviceSelectAll(true)">تحديد الظاهر</button><button class="btn-sm" type="button" onclick="serviceSelectAll(false)">إلغاء التحديد</button></div><div id="servicePickerCount" class="selection-count" aria-live="polite"></div><div id="serviceUnitPicker" class="service-unit-picker" role="group" aria-label="الوحدات المتاحة"></div>${d.service.pricingMode==='SHARED_TOTAL'?taskDirectAgreementFields():''}<div class="form-actions"><button type="button" class="btn-sm primary" id="serviceAddSelectedButton" onclick="towerSubmitInlineMembers('${esc(id)}')">إضافة الوحدات المحددة</button><button type="button" class="btn-sm" onclick="towerToggleInlineMemberPicker('${esc(id)}')">إلغاء</button></div>`;
  renderServiceUnitPicker();host.scrollIntoView({behavior:'smooth',block:'nearest'});
 }catch(e){if(host.isConnected)host.innerHTML=`<p class="service-info-note">تعذر تحميل الوحدات: ${esc(errText(e))}</p>`;}
}
async function towerSubmitInlineMembers(id){
 const d=window.SERVICE_PICK,ids=d?Array.from(d.selected):[];
 if(!ids.length){toast('اختر وحدة واحدة على الأقل.','error');return;}
 const btn=document.getElementById('serviceAddSelectedButton');if(btn)btn.disabled=true;
 beginBackgroundSave();
 try{
  const result=await run('addServiceSubscribers',{serviceId:id,unitIds:ids,...taskDirectAgreementPayload(d)});
  toast(`تمت إضافة ${result.created} وحدة${result.skipped?'، وتجاوز '+result.skipped+' وحدة قائمة.':''}`);
  await renderServices();await openSharedAllocation(id,true);
 }catch(e){toast(errText(e),'error');if(btn?.isConnected)btn.disabled=false;}
 finally{endBackgroundSave();}
}
async function reopenSharedEnrollment(id){
 if(!await confirmAction({title:'إعادة فتح الاشتراك',message:'إعادة الفتح تسمح بتعديل المشتركين قبل اعتماد التوزيع فقط. لن تُحذف أي مستحقات.',confirmLabel:'إعادة فتح'}))return;
 try{await run('reopenSharedServiceEnrollment',id);await renderServices();await openSharedAllocation(id,true);toast('تمت إعادة فتح الاشتراك.');}catch(e){toast(errText(e),'error');}
}
async function removeSharedSubscriber(id,subscriptionId){
 if(!await confirmAction({title:'إزالة مشترك',message:'سيُنهى اشتراك هذه الوحدة مع حفظ سجله. ستتغير الأنصبة التقديرية لباقي المشتركين، دون إنشاء مستحقات.',confirmLabel:'إزالة المشترك'}))return;
 try{await run('removeSharedServiceSubscriber',id,subscriptionId);await renderServices();await openSharedAllocation(id,true);toast('تم إنهاء الاشتراك، وتحديث العدد التقديري.');}catch(e){toast(errText(e),'error');}
}
async function closeSharedEnrollment(id){if(!await confirmAction({title:'إغلاق الاشتراك',message:'سيُمنع انضمام وحدات جديدة لهذه المهمة. تأكد من مراجعة جميع الطلبات المعلقة قبل الإغلاق.',confirmLabel:'إغلاق الاشتراك'}))return;try{await run('closeSharedServiceEnrollment',id);await renderServices();await openSharedAllocation(id,true);toast('تم إغلاق باب الاشتراك.');}catch(e){toast(errText(e),'error');}}
async function finalizeSharedAllocation(id){if(!await confirmAction({title:'اعتماد نهائي للتوزيع',message:'سيتم إنشاء مستحقات مالية نهائية لكل مشترك. لا يمكن التراجع بإعادة فتح الاشتراك.',confirmLabel:'تأكيد اعتماد التوزيع'}))return;try{const result=await run('taskProjectAction',id,'close_finalize',{allocations:TASK_CLOSE_PREVIEWS.get(id)});await renderServices();toast(result.replay?'التوزيع معتمد بالفعل.':'تم اعتماد التوزيع وإنشاء المستحقات.');}catch(e){toast(errText(e),'error');}}

// Task lifecycle hub. Isolated from resident/guard trip UI and trip APIs.
let TASK_PROJECT_HUB=null,TASK_PROJECT_HUB_EPOCH=0;
const TASK_PROJECT_DATA=window.TOWER_TASK_PROJECT_DATA=new Map();
window.clearTaskProjectSession=()=>{const sh=$('modalSheet'),hasTask=sh?.querySelector('[data-task-project-id]')||TOWER_MODAL_STACK.some(x=>x.content?.querySelector?.('[data-task-project-id]'));if(hasTask){TOWER_MODAL_STACK.length=0;sh?.replaceChildren();$('modal')?.classList.add('hidden');document.documentElement.classList.remove('modal-open');}TASK_PROJECT_DATA.clear();TASK_CLOSE_PREVIEWS.clear();PERSONAL_COLLECTIONS=[];window.MANAGED_SERVICE_EDIT=null;TASK_PROJECT_HUB=null;++TASK_PROJECT_HUB_EPOCH;};
function taskProjectCurrentHub(){const node=$('modalSheet')?.querySelector('[data-task-project-id]');return node?TASK_PROJECT_DATA.get(node.dataset.taskProjectId):TASK_PROJECT_HUB;}
const TASK_PROJECT_PHASE={PROPOSAL:'فكرة مقترحة — اهتمام بدون التزام',PARTICIPATION:'مشاركة ومتابعة',CANCELLED:'ملغاة',FINANCIAL_CLOSED:'التنفيذ والحساب مقفولين'};
const TASK_PROJECT_FUNDING={UNPAID:'مصروف مستحق ولم يُدفع',PERSONAL:'دفعته من جيبي — مطلوب رده لي',TASK:'مدفوع من عهدتي بحساب المهمة'};
function taskProjectMoneyInput(id,label,value='',extra=''){return `<label class="field"><span>${esc(label)}</span><input id="${id}" type="number" step="0.01" value="${esc(value)}" required ${extra}></label>`;}
function taskProjectHeader(title){return `<div class="modal-head task-project-head"><h3>${esc(title)}</h3><button type="button" class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div>`;}
function taskProjectField(id,label,value='',type='text'){return `<label class="field"><span>${esc(label)}</span><input id="${id}" type="${type}" value="${esc(value)}"></label>`;}
function taskProjectSelect(id,label,choices,selected){return `<label class="field"><span>${esc(label)}</span><select id="${id}">${Object.entries(choices).map(([k,v])=>`<option value="${esc(k)}" ${k===selected?'selected':''}>${esc(v)}</option>`).join('')}</select></label>`;}
function taskProjectFormFooter(label='حفظ'){return `<input type="hidden" data-task-project-id="${esc(taskProjectCurrentHub()?.serviceId||'')}"><div class="form-actions span-2"><button type="submit" class="btn-sm primary">${esc(label)}</button><button type="button" class="btn-sm" onclick="closeModal()">إلغاء</button></div>`;}
async function openTaskIdeaForm(){
 try{const people=await run('listServiceBeneficiaries');const reference=crypto.randomUUID();openModal(`${taskProjectHeader('مهمة جديدة')}<form class="form-grid task-project-form" data-reference="${reference}" onsubmit="submitTaskIdea(event)">${taskProjectField('tpName','اسم المهمة')}${taskProjectField('tpScope','الأدوار ونطاق الشغل')}${taskProjectMoneyInput('tpBudget','التكلفة التقريبية','', 'min="0.01"')}${taskProjectSelect('tpBeneficiary','مسؤول حساب المهمة',Object.fromEntries(people.map(x=>[x.userId,personName(x)])),people[0]?.userId)}<label class="field span-2"><span>وصف المهمة</span><textarea id="tpDescription"></textarea></label><p class="span-2">الاشتراك متاح بمجرد الحفظ. المستحقات تنزل بعد مراجعة المشاركين واعتماد التوزيع.</p>${taskProjectFormFooter('إنشاء المهمة')}</form>`,true);}catch(e){toast(errText(e),'error');}
}
async function submitTaskIdea(event){
 event.preventDefault();const origin={user:APP.ctx?.user?.userId,unit:APP.activeUnitId,page:APP.page};const f=event.target,b=f.querySelector('[type=submit]');if(b.disabled)return;b.disabled=true;
 try{const r=await run('createTaskProject',{reference:f.dataset.reference,name:$('tpName').value,scope:$('tpScope').value,totalBudget:$('tpBudget').value,description:$('tpDescription').value,beneficiaryUserId:$('tpBeneficiary').value});if(APP.ctx?.user?.userId!==origin.user||APP.activeUnitId!==origin.unit||APP.page!==origin.page)return;const reopen=!$('modal').classList.contains('hidden');closeModal();await renderServices();if(reopen&&APP.ctx?.user?.userId===origin.user&&APP.activeUnitId===origin.unit&&APP.page===origin.page)await openTaskProject(r.serviceId);}catch(e){toast(errText(e),'error');}finally{if(b.isConnected)b.disabled=false;}
}
async function openTaskProject(id,replace=false,tab=null){
 const epoch=++TASK_PROJECT_HUB_EPOCH,user=APP.ctx?.user?.userId,unit=APP.activeUnitId;
 const previous=TASK_PROJECT_DATA.get(id),retain=previous&&previous.origin.user===user&&previous.origin.unit===unit;
 if(retain)captureTaskWorkspaceView(previous);
 try{const d=await run('getTaskProject',id);if(epoch!==TASK_PROJECT_HUB_EPOCH||APP.ctx?.user?.userId!==user||APP.activeUnitId!==unit)return;
 let context=null,contextError='';
 if(d.canManage){try{context=await towerReadServiceManagerContext(id);}catch(e){contextError=errText(e);}}
 if(epoch!==TASK_PROJECT_HUB_EPOCH||APP.ctx?.user?.userId!==user||APP.activeUnitId!==unit)return;
 const view=retain?previous.view:{tab:'overview',query:'',floor:'',order:'asc',selected:new Set(),scrolls:{}};
 if(tab)view.tab=tab;
 TASK_PROJECT_HUB={...d,context,contextError,view,origin:{user,unit}};TASK_PROJECT_DATA.set(id,TASK_PROJECT_HUB);
 openModal(taskProjectHtml(TASK_PROJECT_HUB),true,replace||Boolean($('modalSheet')?.querySelector('.task-workspace')));
 mountTaskWorkspace(TASK_PROJECT_HUB);
 }catch(e){toast(errText(e),'error');}
}

function taskProjectLegacyHtml(d){
 const p=d.project||{},admin=d.canManage,closed=['CANCELLED','FINANCIAL_CLOSED'].includes(p.phase),proposal=false,finalized=d.enrollment==='FINALIZED';
 const active=d.subscriptions.filter(x=>x.status==='ACTIVE'),totals=d.subscriptions.reduce((n,s)=>({due:n.due+Number(s.balance?.due||0),paid:n.paid+Number(s.balance?.paid||0),remaining:n.remaining+Number(s.balance?.remaining||0),credit:n.credit+Number(s.balance?.credit||0)}),{due:0,paid:0,remaining:0,credit:0});
 const next=closed?'المهمة مقفولة.':proposal?'راجع نطاق الفكرة وشروطها، وبعدها افتح تأكيد المشاركة.':d.enrollment==='OPEN'?'راجع المشاركين وموافقتهم، ثم اقفل باب الاشتراك.':!finalized?'راجع مساهمة الصندوق إن وجدت، ثم اعتمد الأنصبة.':'تابع التحصيل والمصروفات والتنفيذ. أي فرق تكلفة يحتاج تسوية مستقلة.';
 const action=(label,code,kind='')=>`<button type="button" class="btn-sm ${kind}" onclick="${code}">${esc(label)}</button>`;
 const list=d.subscriptions.map(s=>`<article class="task-project-record"><strong>الوحدة ${esc(unitNo(s.unitNumber))}</strong><span>${esc(subStatusLabel(s.status))}</span>${finalized?`<span>المستحق ${taskExactMoney(s.balance.due)} · المدفوع ${taskExactMoney(s.balance.paid)} · المتبقي ${taskExactMoney(s.balance.remaining)}</span>${Number(s.balance.advance)>0?`<span>مقدم مخصص غير مستخدم ${taskExactMoney(s.balance.advance)}</span>`:''}${Number(s.balance.credit)>0?`<strong>حق رد ${taskExactMoney(s.balance.credit)}${Number(s.balance.refundPending)>0?' — جزء منه قيد التسليم':''}</strong>`:''}`:''}${admin&&s.status==='ACTIVE'&&d.enrollment==='OPEN'&&!closed?action(s.agreement?'تعديل توثيق الاتفاق':'توثيق الاتفاق',`openTaskAgreement('${esc(s.subscriptionId)}')`):''}${admin&&d.canApproveCredit&&Number(s.balance.advanceAvailable)>0?action('اعتماد رد المقدم غير المستخدم',`taskProjectConfirm('refund_authorize',{subscriptionId:'${esc(s.subscriptionId)}',source:'ADVANCE'},'اعتماد رد المقدم غير المستخدم للوحدة. سيتم حجزه ومنع استهلاكه في مستحقات جديدة لحين الرد أو سحب الاعتماد.')`):''}${admin&&d.canApproveCredit&&Number(s.balance.creditAvailable)>0?action('اعتماد حق الرد',`taskProjectConfirm('refund_authorize',{subscriptionId:'${esc(s.subscriptionId)}'},'اعتماد حق رد الوحدة من التخفيض، بدون دفع تلقائي.')`):''}</article>`).join('');
 const expenses=d.expenses.map(e=>`<article class="task-project-record"><strong>${esc(e.description)}</strong><span>${taskExactMoney(e.amount)} · ${e.state==='DRAFT'?'مسودة':e.state==='CANCELLED'?'ملغي':'معتمد'}</span>${admin?`${e.state==='DRAFT'?action('إلغاء المسودة',`taskProjectConfirm('expense_cancel',{expenseId:'${esc(e.expense_id)}'},'إلغاء مسودة المصروف قبل اعتمادها، دون قيد مالي.')`):''}<span>${esc(e.disbursed?(e.funding==='PERSONAL'?'اترد المصروف لدافعه من عهدة المهمة':'مدفوع من عهدة المهمة'):TASK_PROJECT_FUNDING[e.funding]||'')}</span>${e.recipient?`<span>الجهة: ${esc(e.recipient)}</span>`:''}${e.evidence?`<span>الإثبات: ${esc(e.evidence)}</span>`:''}${!closed&&e.state==='DRAFT'?action('اعتماد المصروف',`taskProjectConfirm('expense_approve',{expenseId:'${esc(e.expense_id)}'},'اعتماد المصروف لا يضيف مستحقًا على السكان. المدفوع من العهدة يقلل المتاح عندك.')`):''}${!closed&&e.state==='APPROVED'&&!e.disbursed?action(e.funding==='PERSONAL'?'تسجيل رد المصروف لدافعه':'تسجيل دفع المصروف من عهدتي',`taskProjectConfirm('expense_pay',{expenseId:'${esc(e.expense_id)}'},'أكد دفع المبلغ فعليًا من عهدتك بالمهمة. لن ينشئ ده مستحقًا جديدًا على السكان.')`):''}`:''}</article>`).join('');
 const adjustments=d.adjustments.map(a=>`<article class="task-project-record"><strong>${a.amount<0?'تخفيض':'زيادة'} ${taskExactMoney(Math.abs(a.amount))}</strong><span>${esc(a.reason)} · ${a.state==='DRAFT'?'مسودة — لم تغير المستحقات':a.state==='CANCELLED'?'ملغاة':'معتمدة'}</span><div>${(a.lines||[]).map(l=>`<span class="task-project-allocation">وحدة ${esc(unitNo(l.unitNumber))}: ${l.amount<0?'−':'+'}${taskExactMoney(Math.abs(l.amount))}</span>`).join('')}</div>${admin&&!closed&&a.state==='DRAFT'?action('إلغاء المسودة',`taskProjectConfirm('adjustment_cancel',{adjustmentId:'${esc(a.adjustmentId)}'},'إلغاء معاينة التسوية دون تغيير المستحقات.')`):''}${admin&&!closed&&a.state==='DRAFT'&&(a.amount>0||d.canApproveCredit)?action('اعتماد التسوية',`taskProjectConfirm('adjustment_approve',{adjustmentId:'${esc(a.adjustmentId)}'},'التسوية ستغير مستحقات الوحدات المعروضة فقط، وتحافظ على القيود الأصلية. راجع الأنصبة قبل التأكيد.')`):''}</article>`).join('');
 return `${taskProjectHeader(d.name)}<div class="task-project-hub" data-task-project-id="${esc(d.serviceId)}" dir="rtl"><section class="task-project-next"><strong>${esc((d.execution?.stage==='COMPLETED'&&p.phase==='PARTICIPATION'?'التنفيذ مكتمل — الحساب لسه مفتوح':TASK_PROJECT_PHASE[p.phase])||'مهمة قائمة')}</strong><p>${esc(next)}</p></section>${d.execution?`<p>مرحلة التنفيذ: ${esc(TASK_STAGE_NAMES[d.execution.stage]||d.execution.stage)} · التقدم ${Number(d.execution.percent)||0}%</p>`:''}<div class="task-project-facts"><span>التكلفة الحالية ${taskExactMoney(d.totalBudget)}</span><span>المصروف الفعلي ${taskExactMoney(d.actualExpenseTotal)}</span><span>تبرعات إضافية ${taskExactMoney(d.donationTotal||0)}</span>${admin?`<span>عهدتك المتاحة ${d.holderAvailable==null?'غير متاحة':taskExactMoney(d.holderAvailable)}</span>`:''}</div>${p.scope_text?`<p><strong>نطاق الشغل:</strong> ${esc(p.scope_text)}</p>`:''}${p.closure_note?`<p><strong>سبب الإقفال:</strong> ${esc(p.closure_note)}</p>`:''}${p.policy_text?`<p><strong>شروط المشاركة والتغيير:</strong> ${esc(p.policy_text)}</p>`:''}${p.deadline?`<p>آخر موعد لتأكيد المشاركة: ${esc(p.deadline)}</p>`:''}${!admin&&d.eligible===false?'<p class="task-project-warning">المهمة موجهة لوحدات أخرى؛ تقدر تشوف الفكرة لكن المشاركة غير متاحة للوحدة الحالية.</p>':''}<p><strong>مسؤول حساب المهمة:</strong> ${esc(d.responsibleName||'غير محدد')}</p>${!finalized?`<p><strong>نصيبك التقديري:</strong> ${taskProjectEstimatedShare(d)}</p>`:''}
 <div class="compact-actions">${!admin&&proposal&&d.eligible!==false?action(d.interested?'إلغاء إبداء الاهتمام':'مهتم بالفكرة — بدون التزام مالي',`taskProjectDo('interest',{interested:${!d.interested}})`):''}${admin?action('تعديل المهمة',`openManagedServiceEdit('${esc(d.serviceId)}')`):''}${admin&&!closed&&d.enrollment==='OPEN'?action('نطاق وشروط وقاعدة التوزيع','openTaskTermsForm()'):''}${admin&&proposal?action('فتح تأكيد المشاركة',`taskProjectConfirm('publish',{version:${Number(p.version)}},'سيصبح طلب الاشتراك متاحًا. الاهتمام السابق لن يتحول لاشتراك تلقائيًا.')`,'primary'):''}${admin&&!closed&&!proposal&&d.enrollment==='OPEN'?action('إدارة المشاركين',`openAddServiceSubscribers('${esc(d.serviceId)}')`):''}${admin&&!closed&&!proposal&&!finalized?action('إغلاق الاشتراك واعتماد التوزيع',`openSharedAllocation('${esc(d.serviceId)}')`):''}${admin&&!closed&&!proposal?action('متابعة التنفيذ',`editTaskWorkflow('${esc(d.serviceId)}')`):''}${d.canApproveCredit&&!closed&&d.hasPersonalAccount&&!proposal?action('تسجيل تحصيل للمهمة','openTaskCollectionForm()'):''}${d.canApproveCredit&&!closed&&d.hasPersonalAccount&&!proposal?action('تسجيل تبرع إضافي','openTaskDonationForm()'):''}${admin&&!closed&&d.hasPersonalAccount&&!proposal?action('تسجيل مصروف','openTaskExpenseForm()'):''}${admin&&!closed&&d.hasPersonalAccount&&finalized?action('تسوية زيادة أو تخفيض','openTaskAdjustmentForm()'):''}${admin&&!closed&&d.hasPersonalAccount&&finalized&&d.execution?.stage==='COMPLETED'?action('إقفال الحساب بعد انتهاء التنفيذ',`taskProjectConfirm('close_financial',{},'لن يقفل الحساب إلا بعد انتهاء التنفيذ وتسوية المستحقات وحقوق الرد والمصروفات والعهدة.')`):''}${d.canApproveCredit&&!closed&&d.hasPersonalAccount&&finalized?action('توثيق إلغاء بعد التسوية','openTaskSettledCancellationForm()'):''}${admin&&!closed&&d.enrollment==='OPEN'?action('إلغاء المهمة',`taskProjectConfirm('cancel',{version:${Number(p.version)}},'الإلغاء متاح فقط قبل وجود قيود مالية أو مصروفات؛ لن يسقط حقوقًا أو فلوسًا تلقائيًا.')`):''}</div>
 ${!d.hasPersonalAccount&&admin?'<p class="task-project-warning">المهمة القديمة لا تملك حسابًا مستقلًا. عرضها محفوظ، والمصاريف والتسويات الجديدة تحتاج حساب مهمة مستقلًا؛ لن نغيّر حسابها التاريخي تلقائيًا.</p>':''}
 ${finalized?`<div class="task-project-facts"><span>${admin?'إجمالي المستحقات':'مستحق الوحدة'} ${taskExactMoney(totals.due)}</span><span>المدفوع ${taskExactMoney(totals.paid)}</span><span>المتبقي ${taskExactMoney(totals.remaining)}</span>${totals.credit?`<span>حقوق الرد ${taskExactMoney(totals.credit)}</span>`:''}</div>`:''}
 ${(d.donations||[]).map(r=>`<div class="task-project-record"><span>تبرع وحدة ${esc(unitNo(r.unitNumber))}: ${taskExactMoney(r.amount)}</span>${r.canReturn&&Number(r.available)>0&&!closed?action('طلب رد جزء من التبرع',`openTaskDonationReturnForm('${esc(r.donationId)}',${Number(r.available)})`):''}</div>`).join('')}
 ${(d.donationReturns||[]).map(r=>`<div class="task-project-record"><strong>رد تبرع ${taskExactMoney(r.amount)}</strong>${r.canConfirm?action('تأكيد استلام رد التبرع',`taskProjectConfirm('confirm_donation_return',{returnId:'${esc(r.returnId)}'},'هل استلمت المبلغ فعليًا؟ التأكيد يوثق الرد ولا يغير مستحقات المهمة.')`):''}${r.canCancel?action('إلغاء طلب الرد قبل الاستلام',`taskProjectConfirm('cancel_donation_return',{returnId:'${esc(r.returnId)}'},'إلغاء الطلب قبل تأكيد استلامه فقط.')`):''}</div>`).join('')}
 <details open><summary>${admin?'المشاركون والاتفاقات':'اشتراكات وحدتك'}</summary>${list||'<p>لا يوجد اشتراك بعد.</p>'}</details><details open><summary>مصاريف المهمة</summary><p>تسجيل المصروف لا يغير مستحقات المشاركين. الزيادة تحتاج تسوية معتمدة منفصلة.</p>${expenses||'<p>لا توجد مصروفات مسجلة.</p>'}</details><details open><summary>تسويات التكلفة</summary>${adjustments||'<p>لا توجد تسويات.</p>'}</details>
 ${d.canApproveCredit?(d.refundAuthorizations||[]).filter(r=>Number(r.amount)>0).map(r=>`<div class="task-project-record"><span>اعتماد رد ${taskExactMoney(r.amount)}</span>${action('سحب اعتماد الرد قبل التسليم',`taskProjectConfirm('revoke_refund',{authorizationId:'${esc(r.authorizationId)}'},'سحب الاعتماد متاح فقط قبل أي تسليم معلق أو مؤكد، ولا يلغي فلوسًا تم استلامها.')`)}${action('طلب تسليم الرد من عهدتي',`taskProjectConfirm('refund_request',{authorizationId:'${esc(r.authorizationId)}'},'أكد المبلغ بعد تسليمه لمدير الوحدة. سيظل محجوزًا حتى تأكيد استلامه؛ لا يتصرف فيه مرتين.')`)}</div>`).join(''):''}
 ${(d.pendingSentRefunds||[]).map(r=>`<div class="task-project-record"><span>رد قيد تأكيد الاستلام ${taskExactMoney(r.amount)}</span>${action('إلغاء طلب التسليم قبل التأكيد',`taskProjectConfirm('cancel_refund',{movementId:'${esc(r.movementId)}'},'هل تريد إلغاء الطلب قبل تأكيد الاستلام؟ سيعود المبلغ متاحًا في عهدتك، ويظل اعتماد حق الرد محفوظًا.')`)}</div>`).join('')}
 ${!admin?(d.pendingRefunds||[]).filter(r=>r.canConfirm).map(r=>`<div class="task-project-record"><strong>مبلغ رد لك: ${taskExactMoney(r.amount)}</strong>${action('تأكيد استلام الرد',`confirmTaskProjectRefund('${esc(r.movementId)}')`,'primary')}</div>`).join(''):''}</div>`;
}
function taskProjectOriginMatches(h){return h&&APP.ctx?.user?.userId===h.origin.user&&APP.activeUnitId===h.origin.unit;}
async function taskProjectDo(action,payload={}){
 const h=taskProjectCurrentHub();if(!taskProjectOriginMatches(h)){toast('الحساب أو الوحدة اتغيروا. افتح المهمة من جديد.','error');return;}
 const pageKey=APP.page;
 const sh=$('modalSheet');if(sh.dataset.projectBusy==='1')return;sh.dataset.projectBusy='1';sh.querySelectorAll('button').forEach(b=>b.disabled=true);
 try{const r=await run('taskProjectAction',h.serviceId,action,payload);if(!taskProjectOriginMatches(h))return r;
  const reopen=!$('modal').classList.contains('hidden');
  if(sh.querySelector('form.task-project-form'))closeModal();
  if(APP.page===pageKey){if(pageKey==='unit'||pageKey==='units')await renderUnits();else if(pageKey==='services')await renderServices();}
  if(reopen&&taskProjectOriginMatches(h)&&APP.page===pageKey)await openTaskProject(h.serviceId,true);return r;
 }catch(e){toast(errText(e),'error');}finally{delete sh.dataset.projectBusy;sh.querySelectorAll('button').forEach(b=>b.disabled=false);}
}
async function taskProjectConfirm(action,payload,message){if(await confirmAction({title:'مراجعة إجراء المهمة',message,confirmLabel:'تأكيد'}))await taskProjectDo(action,payload);}
function openTaskTermsForm(){
 const d=taskProjectCurrentHub(),p=d.project;const active=d.subscriptions.filter(x=>x.status==='ACTIVE');
 openModal(`${taskProjectHeader('شروط المشاركة والتوزيع')}<form class="form-grid task-project-form" data-project-version="${Number(p.version)}" onsubmit="submitTaskTerms(event)">${taskProjectField('tpScope','الأدوار ونطاق الشغل',p.scope_text||'')}<fieldset class="span-2 task-project-targets"><legend>الوحدات المستهدفة — ترك الكل بدون تحديد يعني كل الوحدات</legend>${(d.availableUnits||[]).map(u=>`<label><input type="checkbox" data-task-target="${esc(u.unitId)}" ${(p.target_units||[]).includes(u.unitId)?'checked':''}> وحدة ${esc(unitNo(u.unitNumber))} · الدور ${esc(floorNo(u.floor))}</label>`).join('')}</fieldset>${taskProjectField('tpDeadline','آخر موعد لتأكيد المشاركة',p.deadline||'','date')}${taskProjectMoneyInput('tpMinimum','مبلغ التحصيل المطلوب لبدء التنفيذ، أو صفر للشرط المعتاد',p.minimum_start_amount||0,'min="0"')}<label class="field span-2"><span>الاتفاق على المشاركة والزيادة والانسحاب والإلغاء وأي متبقٍ</span><textarea id="tpPolicy">${esc(p.policy_text||'')}</textarea></label>${taskProjectSelect('tpDistribution','توزيع التكلفة',d.hasPersonalAccount?{EQUAL:'بالتساوي',CUSTOM:'مبلغ متفق عليه لكل وحدة'}:{EQUAL:'بالتساوي'},p.distribution||'EQUAL')}<div class="span-2 task-project-custom"><p>حدّد نصيب كل وحدة. هنوضح لك أي فرق ونساعدك توزّعه قبل الاعتماد.</p><p id="tpAllocationTotals" aria-live="polite"></p><button type="button" class="btn-sm" onclick="taskSplitRemainder()">توزيع المتبقي بالتساوي</button>${active.map(s=>taskProjectMoneyInput('tpShare_'+s.subscriptionId,'وحدة '+unitNo(s.unitNumber),(p.agreed_amounts||[]).find(x=>x.subscriptionId===s.subscriptionId)?.amount??'','min="0" data-task-share="'+esc(s.subscriptionId)+'"')).join('')||'<p>أضف المشاركين أولًا قبل إدخال أنصبتهم الخاصة.</p>'}</div>${taskProjectFormFooter()}</form>`,true);
 const select=$('tpDistribution');const update=()=>{const custom=select.value==='CUSTOM';document.querySelector('.task-project-custom').hidden=!custom;document.querySelectorAll('[data-task-share]').forEach(x=>x.required=custom);};select.addEventListener('change',update);update();document.querySelectorAll('[data-task-share]').forEach(x=>x.addEventListener('input',taskAllocationTotals));taskAllocationTotals();towerTrackOtherForm();
}
function submitTaskTerms(e){e.preventDefault();taskProjectDo('terms',{version:Number(e.target.dataset.projectVersion),scope:$('tpScope').value,targetUnits:[...document.querySelectorAll('[data-task-target]:checked')].map(x=>x.dataset.taskTarget),deadline:$('tpDeadline').value,policy:$('tpPolicy').value,minimumStartAmount:$('tpMinimum').value,distribution:$('tpDistribution').value,agreedAmounts:[...document.querySelectorAll('[data-task-share]')].filter(x=>x.value!=='').map(x=>({subscriptionId:x.dataset.taskShare,amount:x.value}))});}
function openTaskAgreement(id){const s=taskProjectCurrentHub().subscriptions.find(x=>x.subscriptionId===id);openModal(`${taskProjectHeader('توثيق موافقة الوحدة '+unitNo(s.unitNumber))}<form class="form-grid task-project-form" onsubmit="event.preventDefault();taskProjectDo('agreement',{subscriptionId:'${esc(id)}',source:$('tpSource').value,note:$('tpNote').value})">${taskProjectSelect('tpSource','مصدر الاتفاق',{APP:'من التطبيق',WHATSAPP:'واتساب',MEETING:'اجتماع',PHONE:'مكالمة',OTHER:'اتفاق آخر'},s.agreement?.source||'WHATSAPP')}<label class="field span-2"><span>ملاحظة الاتفاق، بدون بيانات دخول</span><textarea id="tpNote">${esc(s.agreement?.note||'')}</textarea></label>${taskProjectFormFooter()}</form>`);}
function openTaskExpenseForm(){const ref=crypto.randomUUID();openModal(`${taskProjectHeader('تسجيل مصروف المهمة')}<form class="form-grid task-project-form" data-reference="${ref}" onsubmit="submitTaskExpense(event)">${taskProjectField('tpExpenseDescription','بند المصروف')}${taskProjectMoneyInput('tpExpenseAmount','المبلغ الفعلي','','min="0.01"')}${taskProjectField('tpExpenseDate','تاريخ المصروف',towerLocalDate(),'date')}${taskProjectSelect('tpFunding','حالة الدفع',TASK_PROJECT_FUNDING,'UNPAID')}${taskProjectField('tpRecipient','المورد أو المستفيد')}${taskProjectField('tpEvidence','مرجع أو رابط إثبات، اختياري')}<p class="span-2">الحفظ ينشئ مسودة للمراجعة. اعتماد المصروف لا ينشئ مديونية إضافية على السكان. المصروف الشخصي مطالبة تُرد لدافعها، والمدفوع من العهدة يقلل المتاح عند حامله.</p>${taskProjectFormFooter('حفظ مسودة المصروف')}</form>`,true);}
function submitTaskExpense(e){e.preventDefault();taskProjectDo('expense_draft',{reference:e.target.dataset.reference,date:$('tpExpenseDate').value,amount:$('tpExpenseAmount').value,description:$('tpExpenseDescription').value,funding:$('tpFunding').value,recipient:$('tpRecipient').value,evidence:$('tpEvidence').value});}
function openTaskAdjustmentForm(){openModal(`${taskProjectHeader('تسوية تكلفة مستقلة')}<form class="form-grid task-project-form" data-reference="${crypto.randomUUID()}" onsubmit="submitTaskAdjustment(event)">${taskProjectMoneyInput('tpAdjustmentAmount','فرق التكلفة: موجب للزيادة، وسالب للتخفيض')}<label class="field span-2"><span>سبب الزيادة أو التخفيض</span><textarea id="tpAdjustmentReason" required></textarea></label><p class="span-2">هتظهر معاينة أنصبة الوحدات الأصلية قبل الاعتماد. القيود السابقة محفوظة. التخفيض بعد السداد يظهر حق رد مستقل؛ لا يتحول لإيراد للصندوق. اعتماد التخفيض لرئيس الاتحاد.</p>${taskProjectFormFooter('إنشاء معاينة التسوية')}</form>`,true);}
function submitTaskAdjustment(e){e.preventDefault();taskProjectDo('adjustment_draft',{reference:e.target.dataset.reference,amount:$('tpAdjustmentAmount').value,reason:$('tpAdjustmentReason').value});}
async function confirmTaskProjectRefund(id){if(!await confirmAction({title:'تأكيد استلام الرد',message:'هل استلمت المبلغ فعليًا؟ تأكيدك يوثق خروج المبلغ من عهدة المرسل.',confirmLabel:'استلمت المبلغ'}))return;await taskProjectDo('confirm_refund',{movementId:id});}

function taskDirectAgreementFields(){return `<div class="task-project-record">${taskProjectSelect('taskDirectSource','مصدر موافقة الوحدات',{OTHER:'اتفاق مباشر آخر',WHATSAPP:'واتساب',MEETING:'اجتماع',PHONE:'مكالمة',APP:'التطبيق'},'OTHER')}${taskProjectField('taskDirectNote','ملاحظة الاتفاق، اختياري')}</div>`;}
function taskDirectAgreementPayload(d){return d?.service?.pricingMode==='SHARED_TOTAL'?{agreementSource:$('taskDirectSource')?.value||'OTHER',agreementNote:$('taskDirectNote')?.value||''}:{};}

function openTaskDonationForm(){const d=taskProjectCurrentHub();openModal(`${taskProjectHeader('تبرع إضافي مستقل')}<form class="form-grid task-project-form" data-reference="${crypto.randomUUID()}" onsubmit="submitTaskDonation(event)">${taskProjectSelect('tpDonorUnit','الوحدة المتبرعة',Object.fromEntries((d.availableUnits||[]).map(u=>[u.unitId,'وحدة '+unitNo(u.unitNumber)])),d.availableUnits?.[0]?.unitId)}${taskProjectMoneyInput('tpDonationAmount','المبلغ المستلم بالفعل','','min="0.01"')}<label class="field span-2"><span>ملاحظة الاتفاق والإثبات</span><textarea id="tpDonationNote"></textarea></label><p class="span-2">تبرع إضافي مستقل حسب الاتفاق، لا يسدد نصيب الوحدة ولا يغير أنصبة المشاركين تلقائيًا. رد أي جزء منه يحتاج اتفاقًا وطلب رد وتأكيد استلام مستقلًا. يتسجل في عهدتك بحساب المهمة بعد تأكيد الاستلام.</p>${taskProjectFormFooter('مراجعة تسجيل التبرع')}</form>`,true);}
async function submitTaskDonation(e){e.preventDefault();const payload={reference:e.target.dataset.reference,unitId:$('tpDonorUnit').value,amount:$('tpDonationAmount').value,note:$('tpDonationNote').value};if(await confirmAction({title:'تأكيد استلام تبرع إضافي',message:'هل استلمت '+taskExactMoney(payload.amount)+' كتبرع إضافي مستقل؟ لن يسدد نصيب الوحدة أو يغير المستحقات.',confirmLabel:'استلمت التبرع'}))await taskProjectDo('donation',payload);}

function openTaskCollectionForm(){const d=taskProjectCurrentHub(),subs=d.subscriptions.filter(s=>s.status==='ACTIVE');if(!subs.length){toast('مفيش وحدات مشتركة نشطة للتحصيل.','error');return;}openModal(`${taskProjectHeader('تحصيل مخصص للمهمة')}<form class="form-grid task-project-form" data-reference="${crypto.randomUUID()}" onsubmit="submitTaskCollection(event)">${taskProjectSelect('tpCollectUnit','الوحدة',Object.fromEntries(subs.map(s=>[s.unitId,'وحدة '+unitNo(s.unitNumber)])),subs[0].unitId)}${taskProjectMoneyInput('tpCollectAmount','المبلغ المستلم بالفعل','','min="0.01"')}<p class="span-2">المبلغ يخصص لحساب المهمة دي فقط. يسدد المستحقات أولًا، وأي زيادة تتسجل مقدمًا مخصصًا لنفس الاشتراك، مش تبرعًا ولا إيرادًا للصندوق.</p>${taskProjectFormFooter('مراجعة التحصيل')}</form>`,true);}
async function submitTaskCollection(e){e.preventDefault();const payload={reference:e.target.dataset.reference,unitId:$('tpCollectUnit').value,amount:$('tpCollectAmount').value};if(await confirmAction({title:'تأكيد التحصيل',message:'هل استلمت '+taskExactMoney(payload.amount)+' فعلًا للوحدة المختارة؟ هيتسجل في عهدتك بحساب المهمة فقط.',confirmLabel:'استلمت المبلغ'}))await taskProjectDo('collect',payload);}

function openTaskSettledCancellationForm(){openModal(`${taskProjectHeader('إلغاء مهمة بعد تسوية حسابها')}<form class="form-grid task-project-form" onsubmit="submitTaskSettledCancellation(event)"><label class="field span-2"><span>سبب الإلغاء وما تم الاتفاق عليه بخصوص الأعمال المنفذة</span><textarea id="tpCancellationReason" required></textarea></label><p class="span-2">الإجراء لا يلغي ديونًا أو يرد فلوسًا تلقائيًا. راجع تسوية التكلفة وحقوق الرد والمقدمات والمصروفات والعهدة أولًا. لن يتم الإقفال لو فيه أي حساب غير مسوّى.</p>${taskProjectFormFooter('مراجعة الإلغاء')}</form>`,true);}
async function submitTaskSettledCancellation(e){e.preventDefault();const payload={reason:$('tpCancellationReason').value};if(await confirmAction({title:'إلغاء بعد التسوية',message:'هل انتهت مراجعة الحسابات واتفقتم على إنهاء المهمة؟ لن تتغير القيود أو تتسجل دفعات تلقائيًا.',confirmLabel:'تأكيد الإلغاء بعد التسوية'}))await taskProjectDo('cancel_settled',payload);}

function openTaskDonationReturnForm(id,available){openModal(`${taskProjectHeader('رد جزء من تبرع المهمة')}<form class="form-grid task-project-form" data-reference="${crypto.randomUUID()}" data-donation="${esc(id)}" onsubmit="submitTaskDonationReturn(event)">${taskProjectMoneyInput('tpDonationReturnAmount','المبلغ المتفق على رده',available,'min="0.01" max="'+available+'"')}<label class="field span-2"><span>سبب الرد والاتفاق</span><textarea id="tpDonationReturnReason" required></textarea></label><p class="span-2">الرد من عهدة مستلم التبرع، ولا يقلل أنصبة المشاركين أو يسقط مستحقات. يظل المبلغ محجوزًا حتى تأكيد الاستلام أو إلغاء الطلب.</p>${taskProjectFormFooter('مراجعة طلب الرد')}</form>`,true);}
async function submitTaskDonationReturn(e){e.preventDefault();const p={reference:e.target.dataset.reference,donationId:e.target.dataset.donation,amount:$('tpDonationReturnAmount').value,reason:$('tpDonationReturnReason').value};if(await confirmAction({title:'طلب رد تبرع',message:'هل تم الاتفاق وتسليم '+taskExactMoney(p.amount)+' لمدير الوحدة؟ سيظل الرد قيد تأكيد الاستلام.',confirmLabel:'تسجيل طلب الرد'}))await taskProjectDo('donation_return',p);}

const TASK_CLOSE_PREVIEWS=new Map();
// V173: one entry for managed details and scoped personal collections.
function taskExactMoney(value){return Number(value||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+' ج.م';}
function taskProjectEstimatedShare(d){const subs=d.subscriptions.filter(x=>x.status==='ACTIVE');const own=subs.find(x=>x.unitId===APP.activeUnitId);if(!own)return 'يتحدد بعد قبول الاشتراك';if(d.project?.distribution==='CUSTOM'){const a=(d.project.agreed_amounts||[]).find(x=>x.subscriptionId===own.subscriptionId);return a?taskExactMoney(a.amount):'لم يُحدد بعد';}return d.estimatedShare!=null?taskExactMoney(d.estimatedShare):'لم يُحدد بعد';}
function taskAllocationTotals(){const host=$('tpAllocationTotals');if(!host)return;const d=taskProjectCurrentHub(),required=Math.round(Number(d.estimatedNet??d.totalBudget)*100),sum=[...document.querySelectorAll('[data-task-share]')].reduce((n,x)=>n+Math.round(Number(x.value||0)*100),0);host.textContent='المطلوب: '+taskExactMoney(required/100)+' · الأنصبة: '+taskExactMoney(sum/100)+' · الفرق: '+taskExactMoney((required-sum)/100);}
function taskSplitRemainder(){const fields=[...document.querySelectorAll('[data-task-share]')];if(!fields.length)return;const d=taskProjectCurrentHub(),target=Math.round(Number(d.estimatedNet??d.totalBudget)*100),values=fields.map(x=>Math.round(Number(x.value||0)*100));const rest=target-values.reduce((n,x)=>n+x,0);if(rest<0){toast('مجموع الأنصبة أكبر من المطلوب؛ قلل المبالغ الأول.','error');return;}const order=fields.map((x,i)=>({x,i})).sort((a,b)=>a.x.dataset.taskShare.localeCompare(b.x.dataset.taskShare));order.forEach(({x,i},n)=>{x.value=((values[i]+Math.floor(rest/fields.length)+(n<rest%fields.length?1:0))/100).toFixed(2);x.dispatchEvent(new Event('input',{bubbles:true}));});taskAllocationTotals();}
async function previewCombinedTaskAllocation(id){try{const p=await run('previewSharedServiceAllocation',id);const allocations=p.allocations||p.preview?.allocations||[];TASK_CLOSE_PREVIEWS.set(id,allocations);openModal(`${taskProjectHeader('مراجعة إغلاق الاشتراك واعتماد التوزيع')}<p>بعد التأكيد هيتقفل الاشتراك وتتسجل المستحقات معًا.</p><div class="list-stack">${allocations.map(x=>`<div class="task-project-record"><span>وحدة ${esc(unitNo(x.unitNumber||x.unitId))}</span><strong>${taskExactMoney(x.amount)}</strong></div>`).join('')}</div><p>راجع الأنصبة وقاعدة التوزيع قبل التأكيد.</p><div class="form-actions"><button class="btn-sm primary" onclick="finalizeSharedAllocation('${esc(id)}')">تأكيد الإغلاق واعتماد التوزيع</button><button class="btn-sm" onclick="closeModal()">رجوع</button></div>`,true);}catch(e){toast(errText(e),'error');}}
async function openManagedServiceEdit(id){const origin=APP.ctx?.user?.userId;try{const [d,people]=await Promise.all([run('getServiceEditContext',id),run('listServiceBeneficiaries')]);if(APP.ctx?.user?.userId!==origin)return;window.MANAGED_SERVICE_EDIT={...d,origin};const shared=d.pricingMode==='SHARED_TOTAL';openModal(`${taskProjectHeader(shared?'تعديل المهمة':'تعديل الخدمة')}<form class="form-grid task-project-form managed-service-edit" data-reference="${crypto.randomUUID()}" onsubmit="submitManagedServiceEdit(event)">${taskProjectField('meName','الاسم',d.name)}${shared?taskProjectMoneyInput('meBudget','التكلفة الإجمالية',d.totalBudget,'min="0.01"'):taskProjectMoneyInput('mePrice','سعر الاشتراك الجديد',d.price,'min="0"')}${!shared?taskProjectSelect('meTiming','توقيت السداد',{PREPAID:'مقدم',POSTPAID:'مؤخر'},d.billingTiming||'PREPAID')+taskProjectSelect('meQuantity','السماح بكمية',{'0':'لا','1':'نعم'},d.allowQuantity?'1':'0')+taskProjectSelect('meCancelable','قابلة للإلغاء',{'0':'لا','1':'نعم'},d.cancelable?'1':'0'):''}${shared?taskProjectField('meScope','الأدوار ونطاق الشغل',d.scope||''):''}${d.beneficiaryUserId?taskProjectSelect('meOwner','مسؤول حساب المهمة أو الخدمة',Object.fromEntries(people.map(x=>[x.userId,personName(x)])),d.beneficiaryUserId):''}<label class="field span-2"><span>الوصف</span><textarea id="meDescription">${esc(d.description||'')}</textarea></label><label class="field span-2"><span>سبب التعديل — مطلوب عند تغيير مبلغ أو مسؤول الحساب</span><textarea id="meReason"></textarea></label><p class="span-2">تعديل التكلفة بعد الاعتماد ينشئ تسوية مستقلة بالفرق. المدفوعات والعهدة السابقة محفوظة. تعديل مالي لمهمة مقفولة يعيد فتح حسابها مع تسجيل السبب.</p>${taskProjectFormFooter('مراجعة وحفظ التعديل')}</form>`,true);towerTrackOtherForm();}catch(e){toast(errText(e),'error');}}
async function submitManagedServiceEdit(e){e.preventDefault();const d=window.MANAGED_SERVICE_EDIT;if(d?.origin!==APP.ctx?.user?.userId)return;const payload={reference:e.target.dataset.reference,serviceId:d.serviceId,expectedUpdatedAt:d.updatedAt,expectedProjectVersion:d.projectVersion,name:$('meName').value,description:$('meDescription').value,scope:$('meScope')?.value??d.scope,totalBudget:$('meBudget')?.value??null,price:$('mePrice')?.value??d.price,beneficiaryUserId:$('meOwner')?.value??null,reason:$('meReason').value,billingTiming:$('meTiming')?.value??d.billingTiming,allowQuantity:$('meQuantity')?$('meQuantity').value==='1':d.allowQuantity,cancelable:$('meCancelable')?$('meCancelable').value==='1':d.cancelable};let preview;try{preview=await run('previewManagedServiceEdit',payload);}catch(err){toast(errText(err),'error');return;}if(d.origin!==APP.ctx?.user?.userId)return;const diff=Number(payload.totalBudget)-Number(d.totalBudget);if(!await confirmAction({title:'مراجعة التعديل',rows:(preview.allocations||[]).map(x=>({label:'فرق وحدة '+unitNo(x.unitNumber),value:taskExactMoney(x.amount)})),warning:preview.reopensAccount?'التعديل المالي هيعيد فتح حساب المهمة المقفولة.':'',message:'حفظ التعديلات'+(d.pricingMode==='SHARED_TOTAL'&&diff?' بفرق تكلفة '+taskExactMoney(diff):'')+'؟ القيود السابقة هتفضل محفوظة.',confirmLabel:'حفظ'}))return;if(d.origin!==APP.ctx?.user?.userId)return;const button=e.target.querySelector('[type=submit]');button.disabled=true;try{await run('editManagedService',payload);if(d.origin!==APP.ctx?.user?.userId)return;closeModal();await renderServices();await refreshOpenServiceWorkspace(d.serviceId);if(taskProjectCurrentHub()?.serviceId===d.serviceId&&taskProjectCurrentHub()?.origin?.user===APP.ctx?.user?.userId)await openTaskProject(d.serviceId,true);toast('تم حفظ التعديل.');}catch(err){toast(errText(err),'error');}finally{if(button.isConnected)button.disabled=false;}}
let PERSONAL_COLLECTIONS=[];
async function loadPersonalCollectionDues(){const host=$('personalCollectionDues'),origin=APP.ctx?.user?.userId;if(!host)return;try{const d=await run('getPersonalCollectionDues');if(!host.isConnected||origin!==APP.ctx?.user?.userId)return;PERSONAL_COLLECTIONS=d.rows||[];host.innerHTML='<div class="panel-head"><h3>مستحقات الخدمات والمهمات</h3></div>'+(PERSONAL_COLLECTIONS.length?PERSONAL_COLLECTIONS.map((x,i)=>`<article class="task-project-record"><div><strong>وحدة ${esc(unitNo(x.unitNumber))} · الدور ${esc(floorNo(x.floor))}</strong><p>${esc(x.managerName||'غير محدد')} · ${esc(x.serviceName)}</p><p>المستحق ${taskExactMoney(x.due)} · المدفوع ${taskExactMoney(x.paid)} · المتبقي ${taskExactMoney(x.remaining)}</p></div>${d.canCollect&&(!x.accountStatus||x.accountStatus==='ACTIVE')&&(!x.unitStatus||x.unitStatus==='ACTIVE')?`<button class="btn-sm primary" onclick="openPersonalDueCollection(${i})">تحصيل</button>`:(x.accountStatus&&x.accountStatus!=='ACTIVE'||x.unitStatus&&x.unitStatus!=='ACTIVE')?'<span>الحساب أو الوحدة موقوفة؛ الإدارة تراجع التفعيل قبل التحصيل.</span>':''}</article>`).join(''):'<p>لا توجد مستحقات متبقية للخدمات أو المهمات.</p>');}catch(e){if(host.isConnected)host.innerHTML=errorCard(e)+'<button class="btn-sm" onclick="loadPersonalCollectionDues()">إعادة المحاولة</button>';}}
function openPersonalDueCollection(i){const x=PERSONAL_COLLECTIONS[i];if(!x)return;openModal(`${taskProjectHeader('تحصيل '+x.serviceName)}<form class="form-grid task-project-form" data-reference="${crypto.randomUUID()}" data-user-id="${esc(APP.ctx?.user?.userId)}" data-unit-id="${esc(x.unitId)}" data-account-id="${esc(x.accountId)}" data-unit-number="${esc(x.unitNumber)}" data-service-name="${esc(x.serviceName)}" onsubmit="submitPersonalDueCollection(event)"><p class="span-2">وحدة ${esc(unitNo(x.unitNumber))} · ${esc(x.managerName||'')} · المتبقي ${taskExactMoney(x.remaining)}</p>${taskProjectMoneyInput('pcAmount','المبلغ المستلم بالفعل',x.remaining,'min="0.01" max="'+Number(x.remaining)+'"')}<p class="span-2">يتسجل على حساب الخدمة أو المهمة وفي عهدتك، بشكل مستقل عن الصندوق العام.</p>${taskProjectFormFooter('مراجعة التحصيل')}</form>`,true);}
async function submitPersonalDueCollection(e){e.preventDefault();const form=e.target;if(form.dataset.userId!==APP.ctx?.user?.userId)return;const pageKey=APP.page,x={unitId:form.dataset.unitId,accountId:form.dataset.accountId,unitNumber:form.dataset.unitNumber,serviceName:form.dataset.serviceName},p={unitId:x.unitId,accountId:x.accountId,amount:$('pcAmount').value,reference:form.dataset.reference};if(!await confirmAction({title:'تأكيد استلام المبلغ',message:'استلمت '+taskExactMoney(p.amount)+' للوحدة '+unitNo(x.unitNumber)+' مقابل '+x.serviceName+'؟',confirmLabel:'استلمت'}))return;if(form.dataset.userId!==APP.ctx?.user?.userId)return;const button=form.querySelector('[type=submit]');button.disabled=true;try{await run('collectPersonalDue',p);if(form.dataset.userId!==APP.ctx?.user?.userId||APP.page!==pageKey)return;closeModal();await renderCollections();toast('تم تسجيل التحصيل على حسابه وفي عهدتك.');}catch(err){toast(errText(err),'error');}finally{if(button.isConnected)button.disabled=false;}}

function fitTowerTextarea(el){if(!(el instanceof HTMLTextAreaElement))return;el.style.height='auto';el.style.height=Math.max(96,el.scrollHeight)+'px';}
document.addEventListener('input',e=>fitTowerTextarea(e.target));
new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)if(node instanceof Element){if(node.matches('textarea'))requestAnimationFrame(()=>fitTowerTextarea(node));node.querySelectorAll('textarea').forEach(x=>requestAnimationFrame(()=>fitTowerTextarea(x)));}}).observe(document.body,{childList:true,subtree:true});
// One task workspace: data and filters survive tab changes and writes.
function personName(person){if(!person)return 'غير محدد';if(typeof person==='string')return person;const raw=String(person.name||person.rawName||'').trim(),title=String(person.customTitle||person.custom_title||person.preferredTitle||person.title||'').trim();if(person.displayName&&(!raw||person.displayName!==raw))return person.displayName;if(!title)return 'لقب غير مسجل';return raw.startsWith(title+' ')?raw:[title,raw].filter(Boolean).join(' ');}
function captureTaskWorkspaceView(h){if(!h?.view||!$('modalSheet')?.querySelector('.task-workspace'))return;h.view.scrolls[h.view.tab]=$('modalSheet').scrollTop;if($('towerSharedSearch')){h.view.query=$('towerSharedSearch').value;h.view.floor=$('towerSharedFloor')?.value||'';h.view.order=$('towerSharedOrder')?.value||'asc';h.view.selected=new Set(window.TOWER_SHARED_MEMBERS?.selected||[]);}}
function taskWorkspaceMembers(h){const subs=h.subscriptions||[],context=h.context?.subscriptions||[],info=new Map(context.map(x=>[x.subscriptionId,x]));const active=subs.filter(x=>x.status==='ACTIVE'),sorted=[...active].sort((a,b)=>String(a.unitId).localeCompare(String(b.unitId))),cents=Math.round(Number(h.estimatedNet??h.totalBudget)*100),base=sorted.length?Math.floor(cents/sorted.length):0,left=sorted.length?cents%sorted.length:0;return active.map(x=>{const meta=info.get(x.subscriptionId)||{},index=sorted.findIndex(a=>a.subscriptionId===x.subscriptionId),agreed=(h.project?.agreed_amounts||[]).find(a=>a.subscriptionId===x.subscriptionId),finalized=h.enrollment==='FINALIZED',balance=x.balance,recorded=balance&&balance.state==='RECORDED'&&Number.isFinite(Number(balance.due));return {id:String(x.subscriptionId),unit:String(x.unitNumber||meta.unitNumber||''),floor:String(x.floor||meta.floor||''),manager:x.managerName||meta.managerName||'غير محدد',label:unitNo(x.unitNumber||meta.unitNumber||'—'),amount:finalized?(recorded?Number(balance.due):null):h.project?.distribution==='CUSTOM'?(agreed?Number(agreed.amount):null):h.canManage?(base+(index<left?1:0))/100:h.estimatedShare??null,paid:recorded?Number(balance.paid):null,remaining:recorded?Number(balance.remaining):null,financial:true};});}
function taskWorkspaceMemberSection(h){const closed=['CANCELLED','FINANCIAL_CLOSED'].includes(h.project?.phase),open=h.enrollment==='OPEN'&&!['CANCELLED','FINANCIAL_CLOSED'].includes(h.project?.phase),admin=h.canManage,rows=taskWorkspaceMembers(h),pending=(h.context?.subscriptions||h.subscriptions||[]).filter(x=>x.status==='PENDING'),floors=[...new Set(rows.map(x=>x.floor))].sort((a,b)=>Number(a)-Number(b));return `<section class="task-workspace-members"><div class="task-section-head"><div><h4>المشتركون والتوزيع <span class="badge">${rows.length}</span></h4><span class="muted">${h.enrollment==='FINALIZED'?'أنصبة مسجلة من دفتر المستحقات':'أنصبة تقديرية لحين الاعتماد'}</span></div><div class="task-tools">${admin&&open?`<button class="btn-sm primary" id="towerInlinePickerToggle" ${h.contextError?'disabled':''} onclick="towerToggleInlineMemberPicker('${esc(h.serviceId)}')" aria-controls="towerInlineMemberPicker" aria-expanded="false">إضافة وحدات</button>`:''}<button class="btn-sm" onclick="copyTaskWorkspaceReport()">نسخ</button><button class="btn-sm" onclick="printTaskWorkspaceReport()">طباعة</button><button class="btn-sm" onclick="downloadTaskWorkspacePdf()">تصدير PDF</button></div></div>${h.contextError?`<div class="task-inline-warning">تعذر تحديث بيانات الإدارة: ${esc(h.contextError)} <button class="btn-sm" onclick="openTaskProject('${esc(h.serviceId)}',true,'members')">إعادة المحاولة</button></div>`:''}<div class="task-member-filters"><input id="towerSharedSearch" type="search" placeholder="بحث بالوحدة أو الدور أو الاسم" aria-label="بحث المشتركين" oninput="towerRenderSharedMembers()"><select id="towerSharedFloor" aria-label="فلترة حسب الدور" onchange="towerRenderSharedMembers()"><option value="">كل الأدوار</option>${floors.map(f=>`<option value="${esc(f)}">الدور ${esc(floorNo(f||'—'))}</option>`).join('')}</select><select id="towerSharedOrder" aria-label="ترتيب المشتركين" onchange="towerRenderSharedMembers()"><option value="asc">الدور ثم الوحدة ↑</option><option value="desc">الدور ثم الوحدة ↓</option></select></div>${admin&&open?`<div class="task-member-selection"><label><input type="checkbox" id="towerSharedSelectVisible" onchange="towerSelectSharedVisible(this.checked)"> تحديد الظاهر</label><span id="towerSharedSelectionCount">0 محدد</span><button class="btn-sm danger-soft" id="towerSharedRemoveSelected" disabled onclick="towerRemoveSelectedShared('${esc(h.serviceId)}')">إزالة المحددين</button><button class="btn-sm" onclick="towerClearSharedSelection()">إلغاء التحديد</button></div>`:''}<div id="towerSharedMemberList" class="task-member-list" role="list"></div><div id="towerSharedVisibleCount" class="muted" aria-live="polite"></div><div id="towerInlineMemberPicker" class="tower-inline-member-picker" hidden></div>${admin&&!closed&&pending.length?`<details class="task-pending-requests" open><summary>طلبات الاشتراك <span class="badge">${pending.length}</span></summary>${pending.map(x=>serviceAdminPendingCard({...x,serviceName:h.name})).join('')}</details>`:pending.length?'<p class="task-inline-warning">طلبك قيد المراجعة.</p>':''}${admin&&!closed&&h.enrollment!=='FINALIZED'?`<div class="task-panel-actions"><button class="btn-sm primary" ${!rows.length||pending.length||h.contextError?'disabled':''} onclick="previewCombinedTaskAllocation('${esc(h.serviceId)}')">مراجعة واعتماد التوزيع</button>${h.enrollment==='CLOSED'?`<button class="btn-sm" onclick="reopenSharedEnrollment('${esc(h.serviceId)}')">إعادة فتح الاشتراك</button>`:''}</div>`:''}</section>`;}
function taskWorkspaceLegacyParts(h){const template=document.createElement('template');template.innerHTML=taskProjectLegacyHtml(h);const old=template.content.querySelector('.task-project-hub'),details=old?Array.from(old.children).filter(x=>x.tagName==='DETAILS'):[];const section=index=>{const copy=details[index]?.cloneNode(true);if(!copy)return '';copy.querySelector('summary')?.remove();copy.querySelectorAll(':scope>p').forEach(x=>x.remove());return copy.innerHTML;};const buttons=old?Array.from(old.querySelector('.compact-actions')?.children||[]):[];const find=text=>buttons.filter(x=>x.textContent.trim()===text).map(x=>x.outerHTML).join('');return {expenses:section(1),adjustments:section(2),find,extras:old?Array.from(old.children).filter(x=>x.classList.contains('task-project-record')).map(x=>x.outerHTML).join(''):''};}
function taskWorkspaceOverview(h,parts){const p=h.project||{},phase=h.execution?.stage||TASK_WORKFLOW_META[h.serviceId]?.stage||'',progress=Number(h.execution?.percent||TASK_WORKFLOW_META[h.serviceId]?.executionPercent||0),stages=['تجميع المشتركين','تجميع التكلفة','جاهز للتنفيذ','جار التنفيذ','مكتملة'];let stage=Object.keys(TASK_STAGE_NAMES).indexOf(phase);if(stage<0)stage=h.enrollment==='FINALIZED'?1:0;return `<section class="task-overview"><div class="task-overview-grid"><div><span>نطاق الشغل</span><strong>${esc(p.scope_text||'غير محدد')}</strong></div><div><span>موعد المشاركة</span><strong>${esc(p.deadline?taskDisplayDate(p.deadline):'بدون موعد محدد')}</strong></div></div>${h.description?`<details class="task-description"><summary>وصف المهمة</summary><p>${esc(h.description)}</p></details>`:''}${p.policy_text?`<details class="task-description"><summary>شروط المشاركة</summary><p>${esc(p.policy_text)}</p></details>`:''}<section class="task-compact-workflow" aria-label="سير المهمة"><div class="task-section-head"><h4>سير المهمة</h4><span>${Number.isFinite(progress)?progress:0}% تنفيذ</span></div><ol>${stages.map((label,i)=>`<li class="${i===stage?'is-current':i<stage?'is-done':''}"><span>${i<stage?'✓':i+1}</span><small>${label}</small></li>`).join('')}</ol><progress max="100" value="${Math.max(0,Math.min(100,progress))}" aria-label="تقدم تنفيذ المهمة"></progress></section>${p.closure_note?`<p class="task-inline-warning">${esc(p.closure_note)}</p>`:''}<div class="task-panel-actions">${taskWorkspaceResidentActions(h)}${parts.find('نطاق وشروط وقاعدة التوزيع')}${parts.find('متابعة التنفيذ')}${parts.find('إقفال الحساب بعد انتهاء التنفيذ')}${parts.find('توثيق إلغاء بعد التسوية')}${parts.find('إلغاء المهمة')}</div></section>`;}
function taskProjectHtml(h){if(!h.view)h.view={tab:'overview',query:'',floor:'',order:'asc',selected:new Set(),scrolls:{}};const p=h.project||{},parts=taskWorkspaceLegacyParts(h),finalized=h.enrollment==='FINALIZED',rows=(h.subscriptions||[]).filter(x=>x.status==='ACTIVE'),valid=rows.length>0&&rows.every(x=>x.balance?.state==='RECORDED'&&['due','paid','remaining'].every(k=>Number.isFinite(Number(x.balance[k])))),totals=rows.reduce((n,x)=>({due:n.due+Number(x.balance?.due||0),paid:n.paid+Number(x.balance?.paid||0),remaining:n.remaining+Number(x.balance?.remaining||0),credit:n.credit+Number(x.balance?.credit||0)}),{due:0,paid:0,remaining:0,credit:0}),scope=h.canManage?'المهمة':'الوحدة',tab=h.view.tab;const nav=[['overview','إدارة المهمة'],['members','الاشتراك والتوزيع'],['payments','الأقساط'],['expenses','المصاريف'],['adjustments','التسويات']];let body=tab==='members'?taskWorkspaceMemberSection(h):tab==='expenses'?`<section><div class="task-section-head"><h4>المصاريف <span class="badge">${(h.expenses||[]).length}</span></h4><div class="task-tools">${parts.find('تسجيل مصروف')}</div></div><div class="task-inline-facts"><span>الفعلي <b>${taskExactMoney(h.actualExpenseTotal||0)}</b></span>${h.canManage?`<span>عهدتك <b>${h.holderAvailable==null?'—':taskExactMoney(h.holderAvailable)}</b></span>`:''}</div>${h.canManage&&!h.hasPersonalAccount?'<p class="task-inline-warning">المهمة على حساب الصندوق؛ المصاريف المخصصة تحتاج حساب مهمة مستقل.</p>':''}${parts.expenses.trim()||'<div class="task-empty">مفيش مصاريف مسجلة.</div>'}</section>`:tab==='adjustments'?`<section><div class="task-section-head"><h4>تسويات التكلفة <span class="badge">${(h.adjustments||[]).length}</span></h4><div class="task-tools">${parts.find('تسوية زيادة أو تخفيض')}</div></div>${parts.adjustments.trim()||'<div class="task-empty">مفيش تسويات مسجلة.</div>'}</section>`:tab==='payments'?`<section><div class="task-section-head"><h4>السداد والأقساط</h4><div class="task-tools">${parts.find('تسجيل تحصيل للمهمة')}${parts.find('تسجيل تبرع إضافي')}</div></div><div id="taskWorkspaceInstallments" aria-live="polite">${finalized?'<div class="task-empty">جاري تحميل الأقساط…</div>':'<div class="task-empty">الأقساط متاحة بعد اعتماد التوزيع.</div>'}</div>${Number(h.donationTotal)>0?`<div class="task-inline-facts">تبرعات مستقلة <b>${taskExactMoney(h.donationTotal)}</b></div>`:''}${parts.extras}</section>`:taskWorkspaceOverview(h,parts);return `<div class="task-workspace" data-task-project-id="${esc(h.serviceId)}" dir="rtl"><header class="task-workspace-header"><div><div class="task-workspace-title"><h3>${esc(h.name)}</h3><span class="badge ${finalized?'success':''}">${esc(['CANCELLED','FINANCIAL_CLOSED'].includes(p.phase)?TASK_PROJECT_PHASE[p.phase]:finalized?'التوزيع معتمد':h.enrollment==='CLOSED'?'بانتظار الاعتماد':'الاشتراك مفتوح')}</span></div><p>مسؤول الحساب: <strong>${esc(h.responsibleName||'غير محدد')}</strong>${!h.canManage?`<span class="task-workspace-unit">تفاصيل المهمة · الوحدة ${esc(unitNo(h.unitNumber||(APP.unitChoices||[]).find(x=>(x.unit?.unitId||x.unitId)===h.origin?.unit)?.unit?.unitNumber||(h.subscriptions||[]).find(x=>x.unitId===h.origin?.unit)?.unitNumber||'—'))}</span>`:''}</p></div><div class="task-header-tools">${h.canManage?`<button class="btn-sm" onclick="openManagedServiceEdit('${esc(h.serviceId)}')">تعديل</button>`:''}<button class="icon-btn" type="button" onclick="closeModal()" aria-label="إغلاق المهمة">×</button></div></header>${workspaceFinanceHtml([{label:finalized?'مستحق '+scope:'التكلفة الحالية',value:finalized?(valid?taskExactMoney(totals.due):'غير مسجل'):taskExactMoney(h.totalBudget)},{label:'المدفوع',value:finalized&&valid?taskExactMoney(totals.paid):'—'},{label:'المتبقي',value:finalized&&valid?taskExactMoney(totals.remaining):'—'}],finalized&&valid&&totals.remaining===0)}<div class="task-workspace-meta">${finalized?`<span>تكلفة المهمة <b>${taskExactMoney(h.totalBudget)}</b></span>`:''}<span>الوحدات <b>${h.canManage?rows.filter(x=>x.status==='ACTIVE').length:Number(h.activeCount)||0}</b></span>${Number(TASK_WORKFLOW_META[h.serviceId]?.fundContributionPosted)>0?`<span>مساهمة الصندوق <b>${taskExactMoney(TASK_WORKFLOW_META[h.serviceId].fundContributionPosted)}</b></span>`:''}${totals.credit?`<span>حقوق رد <b>${taskExactMoney(totals.credit)}</b></span>`:''}${!h.canManage&&!finalized?`<span>نصيبك التقديري <b>${taskProjectEstimatedShare(h)}</b></span>`:''}</div>${!h.canManage&&h.eligible===false?'<p class="task-inline-warning">المهمة موجهة لوحدات أخرى؛ المشاركة غير متاحة للوحدة الحالية.</p>':''}<div class="task-workspace-body" id="taskWorkspacePanel" role="tabpanel" aria-labelledby="taskTab-${tab}">${body}</div>${workspaceTabsHtml(nav,tab,'task')}</div>`;}
function mountTaskWorkspace(h){if(h.view.tab==='members'){const rows=taskWorkspaceMembers(h),allowed=new Set(rows.map(x=>x.id)),open=h.canManage&&h.enrollment==='OPEN'&&!['CANCELLED','FINANCIAL_CLOSED'].includes(h.project?.phase);window.TOWER_SHARED_MEMBERS={serviceId:h.serviceId,rows,selected:new Set([...h.view.selected].filter(x=>allowed.has(x))),isOpen:open,finalized:h.enrollment==='FINALIZED'};if($('towerSharedSearch')){$('towerSharedSearch').value=h.view.query;$('towerSharedFloor').value=h.view.floor;$('towerSharedOrder').value=h.view.order;}towerRenderSharedMembers();}if(h.view.tab==='payments'&&h.enrollment==='FINALIZED')loadTaskWorkspacePayments(h);$('modalSheet').scrollTop=h.view.scrolls[h.view.tab]||0;}
function selectTaskWorkspaceTab(tab){const h=taskProjectCurrentHub();if(!h||!taskProjectOriginMatches(h)||!['overview','members','payments','expenses','adjustments'].includes(tab))return;captureTaskWorkspaceView(h);h.view.tab=tab;openModal(taskProjectHtml(h),true,true);mountTaskWorkspace(h);$('taskTab-'+tab)?.focus({preventScroll:true});}
function taskWorkspaceTabKey(e,tab){if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const keys=['overview','members','payments','expenses','adjustments'];selectTaskWorkspaceTab(e.key==='Home'?keys[0]:e.key==='End'?keys.at(-1):keys[(keys.indexOf(tab)+(e.key==='ArrowLeft'?1:-1)+keys.length)%keys.length]);}
async function loadTaskWorkspacePayments(h){const host=$('taskWorkspaceInstallments');if(!host)return;try{const plan=await run('listTaskInstallments',h.serviceId);if(!host.isConnected||!taskProjectOriginMatches(h)||h.view.tab!=='payments')return;const rows=(plan.rows||[]).filter(x=>h.canManage||x.unitId===h.origin.unit);host.innerHTML=rows.length?`<div class="task-installment-grid">${rows.map(x=>{const unit=(h.context?.units||h.availableUnits||[]).find(u=>u.unitId===x.unitId)||h.subscriptions.find(u=>u.unitId===x.unitId);return `<div class="task-installment-row"><span>وحدة ${esc(unitNo(unit?.unitNumber||'—'))}</span><span>${Number(x.installment)>0?'قسط '+Number(x.installment):'تسوية إضافية'}</span><span>${esc(x.dueDate?taskDisplayDate(x.dueDate):'بدون موعد')}</span><strong>${taskExactMoney(x.amount)}</strong><span>متبقي ${taskExactMoney(x.remaining)}</span></div>`;}).join('')}</div>`:`<div class="task-empty"><strong>${plan.noPlanNeeded?'مفيش مستحقات محتاجة أقساط':plan.hasPayments?'السداد بدأ بدون خطة أقساط':'مفيش خطة أقساط'}</strong>${h.canManage&&!plan.noPlanNeeded&&!plan.hasPayments?`<button class="btn-sm primary" onclick="installTaskInstallments('${esc(h.serviceId)}')">إعداد الأقساط</button>`:''}</div>`;}catch(e){if(host.isConnected)host.innerHTML=`<div class="task-inline-warning">تعذر تحميل الأقساط. <button class="btn-sm" onclick="loadTaskWorkspacePayments(taskProjectCurrentHub())">إعادة المحاولة</button></div>`;}}
function taskWorkspaceReport(){const h=taskProjectCurrentHub();if(!h||!taskProjectOriginMatches(h))throw Error('TASK_CHANGED_REFRESH');captureTaskWorkspaceView(h);const all=taskWorkspaceMembers(h),needle=normAr(h.view.query||''),rows=$('towerSharedMemberList')&&window.TOWER_SHARED_MEMBERS?.serviceId===h.serviceId?towerSharedVisibleRows():all.filter(x=>(!h.view.floor||x.floor===h.view.floor)&&uiSearchMatch([x.unit,x.label,x.floor,x.manager].join(' '),h.view.query||'')).sort((a,b)=>(h.view.order==='desc'?-1:1)*(Number(a.floor)-Number(b.floor)||Number(a.unit)-Number(b.unit))),finalized=h.enrollment==='FINALIZED';return {reportClass:'service-subscribers-paper',title:'المشتركون والتوزيع',subtitle:h.name+' · '+(finalized?'مستحقات معتمدة':'أنصبة تقديرية'),building:APP.ctx?.building||{},footer:'نفس الوحدات الظاهرة في قائمة المهمة · '+rows.length+' وحدة',sections:[{type:'table',title:'الوحدات المشتركة',columns:[{label:'الوحدة'},{label:'الدور'},{label:'مدير الوحدة'},{label:finalized?'المستحق':'التقديري'},...(finalized?[{label:'المدفوع'},{label:'المتبقي'}]:[])],rows:rows.map(x=>[unitNo(x.unit),floorNo(x.floor),x.manager,x.amount==null?'—':taskExactMoney(x.amount),...(finalized?[x.paid==null?'—':taskExactMoney(x.paid),x.remaining==null?'—':taskExactMoney(x.remaining)]:[])])}]};}
async function copyTaskWorkspaceReport(){try{const r=taskWorkspaceReport(),table=r.sections[0];await copyTextValue([r.subtitle,table.columns.map(x=>x.label).join(' | '),...table.rows.map(x=>x.join(' | '))].join('\n'),'تم نسخ الوحدات الظاهرة.');}catch(e){toast(errText(e),'error');}}
function printTaskWorkspaceReport(){try{const r=taskWorkspaceReport(),w=towerOpenPrintWindow();if(!w){toast('اسمح بفتح نافذة الطباعة.','error');return;}w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(r.title)}</title><style>${reportStandaloneCss()}</style></head><body>${reportDocumentHtml(r)}<script>window.onload=()=>setTimeout(()=>window.print(),200)<\/script></body></html>`);w.document.close();}catch(e){toast(errText(e),'error');}}
async function downloadTaskWorkspacePdf(){try{const blob=await buildCurrentPdfBlob(taskWorkspaceReport());await downloadBlobSafe(blob,'Tower_Task_'+cairoDateStamp()+'.pdf');}catch(e){toast(errText(e),'error');}}

function taskDisplayDate(value){const s=String(value||'').slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(s)?s.split('-').reverse().join('/'):s;}

function taskWorkspaceResidentActions(h){if(h.canManage||APP.ctx?.user?.role!=='RESIDENT'||h.enrollment!=='OPEN'||['CANCELLED','FINANCIAL_CLOSED'].includes(h.project?.phase))return '';const service={...(SERVICE_UI.services||[]).find(x=>x.serviceId===h.serviceId),serviceId:h.serviceId,name:h.name,serviceKind:'ONE_TIME',pricingMode:'SHARED_TOTAL',totalBudget:h.totalBudget,enrollmentStatus:h.enrollment,allowQuantity:false,cancelable:false,activeSubscriberCount:h.activeCount,project:{phase:h.project?.phase,eligible:h.eligible,ownEstimatedShare:h.estimatedShare}};SERVICE_UI.services=[...(SERVICE_UI.services||[]).filter(x=>x.serviceId!==h.serviceId),service];const own=(h.subscriptions||[]).find(x=>x.unitId===h.origin.unit&&['ACTIVE','PENDING'].includes(x.status));return residentServiceActions(service,own?{...own,quantity:1}:null);}

// Reusable task/service presentation; financial data is supplied by scoped read models.
function workspaceFinanceHtml(items,settled=false){return `<div class="task-workspace-finance ${settled?'is-settled':''}" aria-label="ملخص الحساب">${items.map(x=>`<div><span>${esc(x.label)}</span><strong>${esc(x.value)}</strong></div>`).join('')}</div>`;}
function workspaceTabsHtml(nav,tab,kind='service'){
 const task=kind==='task',prefix=task?'task':'service',select=task?'selectTaskWorkspaceTab':'selectServiceWorkspaceTab',key=task?'taskWorkspaceTabKey':'serviceWorkspaceTabKey';
 return `<nav class="task-workspace-tabs ${task?'':'service-workspace-tabs'}" style="--workspace-tab-count:${nav.length}" role="tablist" aria-label="${task?'أقسام المهمة':'أقسام الخدمة'}">${nav.map(([id,label])=>`<button type="button" id="${prefix}Tab-${id}" class="btn-sm task-workspace-tab ${tab===id?'is-active':''}" role="tab" aria-selected="${tab===id}" aria-controls="${prefix}WorkspacePanel" tabindex="${tab===id?'0':'-1'}" onclick="${select}('${id}')" onkeydown="${key}(event,'${id}')">${esc(label)}</button>`).join('')}</nav>`;
}
function towerTaskTransitionBlock(payload,service,saved){
 if(!['READY','IN_PROGRESS','COMPLETED'].includes(payload.stage))return '';
 if(['IN_PROGRESS','COMPLETED'].includes(saved.stage)&&['IN_PROGRESS','COMPLETED'].includes(payload.stage))return '';
 if(service.enrollmentStatus!=='FINALIZED')return 'لا يمكن بدء التنفيذ قبل اعتماد توزيع تكلفة المهمة.';
 const proposed={...saved,...payload},minimum=Number(saved.minimumStartAmount||0);
 if(payload.startRule==='MANUAL'&&minimum<=0)return '';
 const ready=towerTaskReadiness(proposed,service);
 return ready.ready?'':ready.message;
}
let SERVICE_WORKSPACE=null,SERVICE_WORKSPACE_EPOCH=0;
window.clearServiceWorkspaceSession=()=>{
 const selector='.service-workspace,[data-service-loading],[data-service-workspace-form]',sheet=$('modalSheet');
 if(sheet?.querySelector(selector)||TOWER_MODAL_STACK.some(x=>x.content?.querySelector?.(selector))){TOWER_MODAL_STACK.length=0;sheet?.replaceChildren();$('modal')?.classList.add('hidden');document.documentElement.classList.remove('modal-open');}
 if(window.SERVICE_PICK?.service?.serviceId===SERVICE_WORKSPACE?.serviceId)window.SERVICE_PICK=null;
 SERVICE_WORKSPACE=null;++SERVICE_WORKSPACE_EPOCH;
};
function serviceWorkspaceOriginMatches(h){return Boolean(h&&h.origin.user===APP.ctx?.user?.userId&&h.origin.unit===APP.activeUnitId&&h.origin.page===APP.page);}
function serviceWorkspacePresent(id){
 if($('modal')?.classList.contains('hidden'))return false;
 const match=node=>node?.querySelector?.('.service-workspace')?.dataset.serviceId===id;
 return match($('modalSheet'))||TOWER_MODAL_STACK.some(x=>match(x.content));
}
function captureServiceWorkspaceView(h){
 const sheet=$('modalSheet');if(!sheet?.querySelector('.service-workspace')||!h)return;
 h.view.scrolls[h.view.tab]=sheet.scrollTop;
 if($('serviceWorkspaceSearch'))h.view.query=$('serviceWorkspaceSearch').value;
 if($('serviceWorkspaceFloor'))h.view.floor=$('serviceWorkspaceFloor').value;
 if($('serviceWorkspaceStatus'))h.view.status=$('serviceWorkspaceStatus').value;
 if($('serviceWorkspaceOrder'))h.view.order=$('serviceWorkspaceOrder').value;
}
async function openServiceWorkspaceOrTask(id,tab='overview',replace=false){
 const current=(SERVICE_UI.services||[]).find(s=>s.serviceId===id);
 if(current?.pricingMode==='SHARED_TOTAL')return openTaskProject(id,replace,tab==='members'?'members':null);
 return openServiceWorkspace(id,tab,replace);
}
async function openServiceWorkspace(id,tab=null,replace=false){
 const origin={user:APP.ctx?.user?.userId,unit:APP.activeUnitId,page:APP.page},epoch=++SERVICE_WORKSPACE_EPOCH;
 const previous=SERVICE_WORKSPACE?.serviceId===id&&serviceWorkspaceOriginMatches(SERVICE_WORKSPACE)?SERVICE_WORKSPACE:null;
 if(previous)captureServiceWorkspaceView(previous);
 const view=previous?.view||{tab:'overview',query:'',floor:'',status:'all',order:'asc',selected:new Set(),scrolls:{}};
 if(tab&&['overview','members','account'].includes(tab))view.tab=tab;
 openModal(`<div data-service-loading="${esc(id)}"><div class="modal-head"><h3>تفاصيل الخدمة</h3><button type="button" class="icon-btn" onclick="closeModal()" aria-label="إغلاق الخدمة">×</button></div>${pageLoading('جاري تحميل الخدمة وحسابها…')}</div>`,true,replace||Boolean($('modalSheet')?.querySelector('.service-workspace')));
 const stillLoading=()=>epoch===SERVICE_WORKSPACE_EPOCH&&serviceWorkspaceOriginMatches({origin})&&$('modalSheet')?.querySelector('[data-service-loading]')?.dataset.serviceLoading===id;
 try{
  const d=await run('getServiceWorkspace',id);
  if(!stillLoading())return;
  if(d.serviceId!==id||!d.service||d.service.pricingMode==='SHARED_TOTAL'||!Array.isArray(d.subscriptions)||!Array.isArray(d.records)||!Array.isArray(d.balances)||!d.totals||!['due','paid','remaining'].every(k=>Number.isFinite(Number(d.totals[k]))))throw Error('بيانات حساب الخدمة ناقصة؛ حاول التحديث.');
  let context=null,contextError='';
  if(d.canManage){try{context=await towerReadServiceManagerContext(id);}catch(e){contextError=errText(e);}}
  if(!stillLoading())return;
  if(!d.canManage&&view.tab==='members')view.tab='overview';
  const h={...d,context,contextError,view,origin};SERVICE_WORKSPACE=h;
  if(APP.ctx?.user?.role==='RESIDENT'){
   SERVICE_UI.services=[...(SERVICE_UI.services||[]).filter(s=>s.serviceId!==id),d.service];
   SERVICE_UI.subscriptions=[...(SERVICE_UI.subscriptions||[]).filter(s=>s.serviceId!==id),...d.subscriptions];
  }
  openModal(serviceWorkspaceHtml(h),true,true);mountServiceWorkspace(h);
 }catch(e){if(stillLoading())openModal(`<div class="modal-head"><h3>تعذر تحميل الخدمة</h3><button type="button" class="icon-btn" onclick="closeModal()" aria-label="إغلاق الخدمة">×</button></div>${errorCard(e)}<button type="button" class="btn-sm primary" onclick="openServiceWorkspace('${esc(id)}','${view.tab}',true)">إعادة المحاولة</button>`,true,true);}
}
async function refreshOpenServiceWorkspace(id=null){
 const h=SERVICE_WORKSPACE;
 if(h&&(!id||id===h.serviceId)&&serviceWorkspaceOriginMatches(h)&&serviceWorkspacePresent(h.serviceId))await openServiceWorkspace(h.serviceId,null,true);
}
function serviceWorkspaceRows(h){
 const byUnit=new Map(),balances=new Map((h.balances||[]).map(b=>[b.unitId,b]));
 const rank={ACTIVE:0,PENDING:1};
 const sorted=[...h.subscriptions].sort((a,b)=>(rank[a.status]??2)-(rank[b.status]??2)||(Date.parse(b.requestedAt)||0)-(Date.parse(a.requestedAt)||0));
 for(const x of sorted){if(byUnit.has(x.unitId)){byUnit.get(x.unitId).historyCount++;continue;}
  byUnit.set(x.unitId,{...x,historyCount:0,balance:balances.get(x.unitId)||{state:'NOT_RECORDED'}});
 }
 // Historical service-level allocations can outlive the subscription record.
 for(const b of h.balances||[])if(!byUnit.has(b.unitId)){const item=h.records.find(x=>x.unitId===b.unitId)||{};byUnit.set(b.unitId,{unitId:b.unitId,unitNumber:item.unitNumber,floor:item.floor,managerName:'غير محدد',status:'ENDED',quantity:0,historyCount:0,balance:b});}
 return [...byUnit.values()];
}
function serviceWorkspaceVisibleRows(h){
 return serviceWorkspaceRows(h).filter(x=>(!h.view.floor||x.floor===h.view.floor)&&(h.view.status==='all'||(h.view.status==='history'?!['ACTIVE','PENDING'].includes(x.status):x.status===h.view.status))&&uiSearchMatch([x.unitNumber,x.floor,x.managerName].join(' '),h.view.query||''))
  .sort((a,b)=>(h.view.order==='desc'?-1:1)*(String(a.floor||'').localeCompare(String(b.floor||''),'en',{numeric:true})||String(a.unitNumber||'').localeCompare(String(b.unitNumber||''),'en',{numeric:true})));
}
function serviceWorkspaceStatus(status){return ({ACTIVE:'نشط',PENDING:'قيد المراجعة',REJECTED:'مرفوض',CANCELLED:'ملغي',CANCELED:'ملغي',ENDED:'منتهي'})[status]||'منتهي';}
function serviceWorkspaceStats(h){
 const active=h.subscriptions.filter(s=>s.status==='ACTIVE'),pending=h.subscriptions.filter(s=>s.status==='PENDING');
 const renewal=active.filter(s=>s.autoRenew&&s.nextRenewalAt),next=renewal.map(s=>s.nextRenewalAt).sort()[0]||null;
 return {active:active.length,pending:pending.length,quantity:active.reduce((n,s)=>n+Number(s.quantity||1),0),scheduled:active.reduce((n,s)=>n+Math.round(Number(s.amountSnapshot??Number(s.unitPriceSnapshot??h.service.price)*Number(s.quantity||1))*100),0)/100,renewal:renewal.length,next};
}
function serviceWorkspaceWorkflow(h){
 const stats=serviceWorkspaceStats(h),own=h.subscriptions.find(x=>['ACTIVE','PENDING'].includes(x.status));
 const steps=h.canManage?[['طلبات الاشتراك',stats.pending],['اشتراكات نشطة',stats.active],[h.service.serviceKind==='RECURRING'?'التجديد القادم':'استحقاق مرة واحدة',h.service.serviceKind==='RECURRING'?stats.renewal:'—'],['طلبات التعديل',h.changes.filter(x=>x.status==='PENDING').length]]:
  [['طلب الاشتراك',own?'✓':'1'],['تفعيل الاشتراك',own?.status==='ACTIVE'?'✓':'2'],[h.service.serviceKind==='RECURRING'?'التجديد':'الاستحقاق',own?.status==='ACTIVE'&&own.autoRenew?'دوري':'3'],['السداد',Number(h.totals.remaining)===0&&h.totals.state==='RECORDED'?'✓':'4']];
 return `<section class="task-compact-workflow service-subscription-workflow" aria-label="دورة الاشتراك"><div class="task-section-head"><h4>دورة الاشتراك</h4><span class="muted">${h.canManage?'حالة الاشتراكات الحالية':esc(own?serviceWorkspaceStatus(own.status):'غير مشترك')}</span></div><ol>${steps.map(([label,value])=>`<li><span>${esc(value)}</span><small>${esc(label)}</small></li>`).join('')}</ol></section>`;
}
function serviceWorkspaceOverview(h){
 const s=h.service,stats=serviceWorkspaceStats(h),own=h.subscriptions.find(x=>['ACTIVE','PENDING'].includes(x.status));
 const actions=!h.canManage&&(s.status==='ACTIVE'||own?.status==='PENDING')?residentServiceActions(s,own):'';
 return `<section><div class="task-overview-grid"><div><span>${s.serviceKind==='RECURRING'?'قيمة الاشتراك الشهرية':'قيمة الاشتراك'}</span><strong>${taskExactMoney(s.price)}</strong></div><div><span>الاستحقاق</span><strong>${s.serviceKind==='RECURRING'?serviceTimingLabel(s.billingTiming):'مرة واحدة'}</strong></div><div><span>${h.canManage?'الكمية النشطة':'كمية اشتراك الوحدة'}</span><strong>${h.canManage?stats.quantity:own?Number(own.quantity||1):'—'}</strong></div><div><span>${h.canManage?'أقرب تجديد':'تجديد الاشتراك'}</span><strong>${s.serviceKind!=='RECURRING'?'لا يوجد تجديد':!h.canManage&&own?.autoRenew===false?'التجديد التلقائي متوقف':stats.next?esc(taskDisplayDate(stats.next)):'لم يتحدد بعد'}</strong></div></div>${serviceWorkspaceWorkflow(h)}${s.description?`<details class="task-description"><summary>وصف الخدمة</summary><p>${esc(s.description)}</p></details>`:''}<div class="task-inline-facts"><span>تعدد الكمية <b>${s.allowQuantity?'متاح':'اشتراك واحد'}</b></span><span>طلب الإلغاء <b>${s.cancelable?'متاح':'غير متاح'}</b></span></div>${actions?`<div class="task-panel-actions">${actions}</div>`:''}${!h.canManage?h.changes.filter(x=>x.status==='PENDING').map(x=>`<p class="task-inline-warning">طلب ${x.type==='ADD'?'زيادة':'تقليل'} الكمية قيد المراجعة.</p>`).join(''):''}${h.canManage?`<div class="task-panel-actions"><button type="button" class="btn-sm primary" ${s.status!=='ACTIVE'||h.contextError?'disabled':''} onclick="openServiceWorkspacePicker()">إضافة وحدات</button><button type="button" class="btn-sm ${s.status==='ACTIVE'?'danger-soft':''}" onclick="confirmServiceWorkspaceStatus()">${s.status==='ACTIVE'?'إيقاف الخدمة':'تفعيل الخدمة'}</button></div>${h.contextError?'<p class="task-inline-warning">إضافة المشتركين غير متاحة حتى تحديث بيانات الوحدات.</p>':''}`:''}</section>`;
}
function serviceWorkspaceMembers(h){
 const floors=[...new Set(serviceWorkspaceRows(h).map(x=>x.floor).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),'en',{numeric:true}));
 return `<section><div class="task-section-head"><h4>المشتركون <span class="badge">${serviceWorkspaceRows(h).length}</span></h4><div class="task-tools"><button type="button" class="btn-sm" onclick="copyServiceWorkspaceReport()">نسخ</button><button type="button" class="btn-sm" onclick="printServiceWorkspaceReport()">طباعة</button><button type="button" class="btn-sm" onclick="downloadServiceWorkspacePdf()">تصدير PDF</button>${h.canManage?`<button type="button" class="btn-sm primary" ${h.service.status!=='ACTIVE'||h.contextError?'disabled':''} onclick="openServiceWorkspacePicker()">إضافة وحدات</button>`:''}</div></div><div class="task-member-filters service-member-filters"><input id="serviceWorkspaceSearch" type="search" aria-label="بحث المشتركين" placeholder="الوحدة أو الدور أو الاسم" oninput="filterServiceWorkspaceMembers()"><select id="serviceWorkspaceFloor" aria-label="فلترة حسب الدور" onchange="filterServiceWorkspaceMembers()"><option value="">كل الأدوار</option>${floors.map(f=>`<option value="${esc(f)}">الدور ${esc(floorNo(f))}</option>`).join('')}</select><select id="serviceWorkspaceStatus" aria-label="حالة الاشتراك" onchange="filterServiceWorkspaceMembers()"><option value="all">كل الحالات</option><option value="ACTIVE">نشط</option><option value="PENDING">قيد المراجعة</option><option value="history">منتهي أو ملغي</option></select><select id="serviceWorkspaceOrder" aria-label="ترتيب المشتركين" onchange="filterServiceWorkspaceMembers()"><option value="asc">الدور ثم الوحدة ↑</option><option value="desc">الدور ثم الوحدة ↓</option></select></div><div id="serviceWorkspaceMemberList" class="task-member-list"></div><p id="serviceWorkspaceVisibleCount" class="muted" aria-live="polite"></p><div id="serviceWorkspaceInlinePicker" class="tower-inline-member-picker" hidden></div>${h.canManage?serviceWorkspaceRequests(h):''}</section>`;
}
function serviceWorkspaceRequests(h){
 const pending=h.subscriptions.filter(s=>s.status==='PENDING'),changes=h.changes.filter(x=>x.status==='PENDING');
 return `${pending.length?`<details open><summary>طلبات الاشتراك <span class="badge">${pending.length}</span></summary>${pending.map(x=>serviceAdminPendingCard({...x,serviceName:h.service.name})).join('')}</details>`:''}${changes.length?`<details open><summary>طلبات التعديل <span class="badge">${changes.length}</span></summary>${changes.map(x=>serviceAdminChangeCard({...x,serviceName:h.service.name})).join('')}</details>`:''}`;
}
function renderServiceWorkspaceMemberRows(h){
 const host=$('serviceWorkspaceMemberList');if(!host||!serviceWorkspaceOriginMatches(h))return;
 const rows=serviceWorkspaceVisibleRows(h);
 host.innerHTML=rows.length?rows.map(x=>`<article class="shared-member-card"><div class="tower-shared-member-label"><div class="tower-shared-member-line"><strong>الوحدة ${esc(unitNo(x.unitNumber||'—'))}</strong><span>الدور ${esc(floorNo(x.floor||'—'))} · ${esc(x.managerName||'غير محدد')}</span><span>${serviceWorkspaceStatus(x.status)}${x.status==='ACTIVE'?' · الكمية '+Number(x.quantity||1):''}</span></div></div><div class="task-member-money">${['due','paid','remaining'].map((k,i)=>`<span><small>${['المستحق','المدفوع','المتبقي'][i]}</small><b>${x.balance.state==='RECORDED'?taskExactMoney(x.balance[k]):'—'}</b></span>`).join('')}</div></article>`).join(''):'<div class="task-empty">مفيش وحدات مطابقة للبحث.</div>';
 $('serviceWorkspaceVisibleCount').textContent=`الظاهر: ${rows.length} من ${serviceWorkspaceRows(h).length} وحدة`;
}
function serviceWorkspaceAccount(h){
 const rows=h.records,personal=h.service.revenueKind==='PERSONAL_SERVICE';
 return `<section><div class="task-section-head"><h4>المستحقات والسداد <span class="badge">${rows.length}</span></h4><button type="button" class="btn-sm" onclick="refreshOpenServiceWorkspace()">تحديث الحساب</button></div><p class="muted service-account-note">${personal?'التحصيل على حساب الخدمة، بشكل مستقل عن صندوق العمارة.':'المستحقات والتحصيل تابعين لصندوق العمارة.'}</p>${rows.length?`<div class="service-ledger-list">${rows.map(x=>`<article class="service-ledger-row"><div><strong>وحدة ${esc(unitNo(x.unitNumber))}</strong><span>${esc(x.period||taskDisplayDate(x.dueDate)||'بدون موعد')}</span></div><div class="task-member-money">${['amount','paid','remaining'].map((k,i)=>`<span><small>${['المستحق','المدفوع','المتبقي'][i]}</small><b>${taskExactMoney(x[k])}</b></span>`).join('')}</div>${h.canManage&&x.remaining>0&&x.unitStatus==='ACTIVE'&&(x.source!=='PERSONAL'||rows.find(r=>r.source==='PERSONAL'&&r.unitId===x.unitId&&r.accountId===x.accountId&&r.remaining>0)?.recordId===x.recordId)&&((x.source==='PERSONAL'&&APP.ctx?.user?.role==='UNION'&&x.accountStatus==='ACTIVE')||x.source==='FUND')?`<button type="button" class="btn-sm primary" onclick="openServiceWorkspaceCollection('${esc(x.recordId)}')">تحصيل</button>`:''}</article>`).join('')}</div>`:'<div class="task-empty">لسه مفيش مستحقات مسجلة للخدمة.</div>'}</section>`;
}
function serviceWorkspaceHtml(h){
 const s=h.service,stats=serviceWorkspaceStats(h),t=h.totals,recorded=t.state==='RECORDED',tab=h.view.tab;
 const tabs=h.canManage?[['overview','إدارة الخدمة'],['members','المشتركون'],['account','الحساب']]:[['overview','اشتراكي'],['account','الحساب']];
 const panel=tab==='members'&&h.canManage?serviceWorkspaceMembers(h):tab==='account'?serviceWorkspaceAccount(h):serviceWorkspaceOverview(h);
 return `<div class="task-workspace service-workspace" data-service-id="${esc(h.serviceId)}" dir="rtl"><header class="task-workspace-header"><div><div class="task-workspace-title"><h3>${esc(s.name)}</h3><span class="badge ${s.status==='ACTIVE'?'success':''}">${s.status==='ACTIVE'?'نشطة':'موقوفة'}</span></div><p>${s.revenueKind==='PERSONAL_SERVICE'?'مسؤول الحساب: <strong>'+esc(s.beneficiaryName||'غير محدد')+'</strong>':'الحساب: <strong>صندوق العمارة</strong>'}${!h.canManage?`<span class="task-workspace-unit">الوحدة ${esc(unitNo(h.unitNumber||'—'))}</span>`:''}</p></div><div class="task-header-tools">${h.canManage?`<button type="button" class="btn-sm" onclick="openManagedServiceEdit('${esc(h.serviceId)}')">تعديل</button>`:''}<button type="button" class="icon-btn" onclick="closeModal()" aria-label="إغلاق الخدمة">×</button></div></header>${workspaceFinanceHtml([{label:h.canManage?'مستحقات الخدمة':'مستحق الوحدة',value:recorded?taskExactMoney(t.due):'غير مسجل'},{label:'المدفوع',value:recorded?taskExactMoney(t.paid):'—'},{label:'المتبقي',value:recorded?taskExactMoney(t.remaining):'—'}],recorded&&Number(t.remaining)===0)}<div class="task-workspace-meta"><span>${s.serviceKind==='RECURRING'?'قيمة الاشتراك الشهرية':'قيمة الاشتراك'} <b>${taskExactMoney(s.price)}</b></span>${h.canManage?`<span>اشتراكات نشطة <b>${stats.active}</b></span><span>${s.serviceKind==='RECURRING'?'قيمة الاشتراكات الشهرية':'قيمة الاشتراكات النشطة'} <b>${taskExactMoney(stats.scheduled)}</b></span>`:''}</div><div class="task-workspace-body" id="serviceWorkspacePanel" role="tabpanel" aria-labelledby="serviceTab-${tab}">${panel}</div>${workspaceTabsHtml(tabs,tab)}</div>`;
}
function mountServiceWorkspace(h){
 if(h.view.tab==='members'&&h.canManage){for(const [id,key]of [['serviceWorkspaceSearch','query'],['serviceWorkspaceFloor','floor'],['serviceWorkspaceStatus','status'],['serviceWorkspaceOrder','order']])if($(id))$(id).value=h.view[key];renderServiceWorkspaceMemberRows(h);}
 $('modalSheet').scrollTop=h.view.scrolls[h.view.tab]||0;
}
function filterServiceWorkspaceMembers(){const h=SERVICE_WORKSPACE;if(!serviceWorkspaceOriginMatches(h))return;captureServiceWorkspaceView(h);renderServiceWorkspaceMemberRows(h);}
function selectServiceWorkspaceTab(tab){
 const h=SERVICE_WORKSPACE;if(!serviceWorkspaceOriginMatches(h)||!['overview','account',...(h.canManage?['members']:[])].includes(tab))return;
 captureServiceWorkspaceView(h);h.view.tab=tab;openModal(serviceWorkspaceHtml(h),true,true);mountServiceWorkspace(h);
}
function serviceWorkspaceTabKey(event,key){
 const h=SERVICE_WORKSPACE;if(!h)return;const keys=h.canManage?['overview','members','account']:['overview','account'];let index=keys.indexOf(key);
 if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();index=event.key==='Home'?0:event.key==='End'?keys.length-1:(index+(event.key==='ArrowLeft'?1:-1)+keys.length)%keys.length;selectServiceWorkspaceTab(keys[index]);$('serviceTab-'+keys[index])?.focus();}
}
async function confirmServiceWorkspaceStatus(){
 const h=SERVICE_WORKSPACE;if(!h?.canManage||!serviceWorkspaceOriginMatches(h))return;
 const active=h.service.status==='ACTIVE';if(!await confirmAction({title:active?'إيقاف الخدمة':'تفعيل الخدمة',message:active?'إيقاف الخدمة لا يلغي المستحقات السابقة أو يمسح المدفوعات. متأكد؟':'تفعيل الخدمة لاستقبال الاشتراكات حسب إعداداتها؟',confirmLabel:active?'إيقاف':'تفعيل',danger:active}))return;
 if(serviceWorkspaceOriginMatches(h))await toggleService(h.serviceId,active?'INACTIVE':'ACTIVE');
}
function openServiceWorkspacePicker(){
 const h=SERVICE_WORKSPACE;if(!h?.canManage||h.contextError||!h.context||h.service.status!=='ACTIVE'||!serviceWorkspaceOriginMatches(h))return;
 if(h.view.tab!=='members')selectServiceWorkspaceTab('members');
 const active=new Set(h.subscriptions.filter(x=>['ACTIVE','PENDING'].includes(x.status)).map(x=>x.unitId));
 // The same picker and save handler used by the existing service enrollment flow.
 window.SERVICE_PICK={...h.context,service:h.service,active,selected:h.view.selected};
 const host=$('serviceWorkspaceInlinePicker');host.hidden=!host.hidden;
 if(host.hidden)return;
 host.innerHTML=`<div class="task-section-head"><h4>إضافة وحدات</h4><div class="task-tools"><button type="button" class="btn-sm" onclick="serviceSelectAll(true)">تحديد الظاهر</button><button type="button" class="btn-sm" onclick="serviceSelectAll(false)">إلغاء التحديد</button></div></div><input id="serviceUnitSearch" type="search" placeholder="الوحدة أو الدور أو اسم أي عضو" aria-label="بحث الوحدات للإضافة" oninput="renderServiceUnitPicker()"><div id="servicePickerCount" class="selection-count" aria-live="polite"></div><div id="serviceUnitPicker" class="service-unit-picker"></div><div class="task-panel-actions"><button type="button" class="btn-sm primary" id="serviceAddSelectedButton" onclick="submitServiceWorkspaceSubscribers('${esc(h.serviceId)}')">إضافة المشتركين</button></div>`;
 renderServiceUnitPicker();
}
function serviceWorkspaceReport(){
 const h=SERVICE_WORKSPACE;if(!serviceWorkspaceOriginMatches(h)||!h.canManage)throw Error('افتح قائمة المشتركين من جديد.');captureServiceWorkspaceView(h);
 const rows=serviceWorkspaceVisibleRows(h),columns=['الوحدة','الدور','مدير الوحدة','الحالة','الكمية','المستحق','المدفوع','المتبقي'];
 return {reportClass:'service-subscribers-paper',title:'مشتركو الخدمة',subtitle:h.service.name,building:APP.ctx?.building||{},footer:`نفس النتائج الظاهرة · ${rows.length} وحدة`,sections:[{type:'table',title:'المشتركون والحساب',columns:columns.map(label=>({label})),rows:rows.map(x=>[unitNo(x.unitNumber),floorNo(x.floor||'—'),x.managerName||'غير محدد',serviceWorkspaceStatus(x.status),x.status==='ACTIVE'?Number(x.quantity||1):'—',...['due','paid','remaining'].map(k=>x.balance.state==='RECORDED'?taskExactMoney(x.balance[k]):'غير مسجل')])}]};
}
async function copyServiceWorkspaceReport(){try{const r=serviceWorkspaceReport(),table=r.sections[0];await copyTextValue([r.subtitle,table.columns.map(x=>x.label).join(' | '),...table.rows.map(x=>x.join(' | '))].join('\n'),'تم نسخ الوحدات الظاهرة.');}catch(e){toast(errText(e),'error');}}
function printServiceWorkspaceReport(){try{const r=serviceWorkspaceReport(),w=towerOpenPrintWindow();if(!w){toast('اسمح بفتح نافذة الطباعة.','error');return;}w.document.open();w.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(r.title)}</title><style>${reportStandaloneCss()}</style></head><body>${reportDocumentHtml(r)}<script>window.onload=()=>setTimeout(()=>window.print(),200)<\/script></body></html>`);w.document.close();}catch(e){toast(errText(e),'error');}}
async function downloadServiceWorkspacePdf(){try{const blob=await buildCurrentPdfBlob(serviceWorkspaceReport());await downloadBlobSafe(blob,'Tower_Service_'+cairoDateStamp()+'.pdf');}catch(e){toast(errText(e),'error');}}
function openServiceWorkspaceCollection(recordId){
 const h=SERVICE_WORKSPACE,r=serviceWorkspaceCollectionTarget(h,recordId);
 if(!h?.canManage||!serviceWorkspaceOriginMatches(h)||!r||Number(r.remaining)<=0||r.unitStatus!=='ACTIVE'||r.source==='PERSONAL'&&(APP.ctx?.user?.role!=='UNION'||r.accountStatus!=='ACTIVE'))return;
 openModal(`<div class="modal-head"><h3>تحصيل ${esc(h.service.name)}</h3><button type="button" class="icon-btn" onclick="closeModal()" aria-label="إغلاق">×</button></div><form class="form-grid" data-service-workspace-form="${esc(h.serviceId)}" data-user="${esc(h.origin.user)}" data-unit="${esc(h.origin.unit)}" data-page="${esc(h.origin.page)}" data-record="${esc(recordId)}" data-reference="${crypto.randomUUID()}" onsubmit="submitServiceWorkspaceCollection(event)"><p class="span-2">الوحدة ${esc(unitNo(r.unitNumber))} · المتبقي ${taskExactMoney(r.remaining)}</p>${taskProjectMoneyInput('swCollectAmount','المبلغ المستلم بالفعل',r.remaining,`min="0.01" max="${Number(r.remaining)}"`)}${r.source==='PERSONAL'?'<p class="span-2 muted">السداد يخصم من أقدم مستحقات الوحدة في الخدمة.</p>':''}${r.source==='FUND'?taskProjectSelect('swCollectMethod','طريقة السداد',{'نقدي':'نقدي','تحويل':'تحويل','محفظة إلكترونية':'محفظة إلكترونية','أخرى':'أخرى'},'نقدي'):''}${r.source==='FUND'?'<label class="field"><span>ملاحظة</span><input id="swCollectNote" maxlength="500"></label>':'<input id="swCollectNote" type="hidden" value="">'}<div class="form-actions span-2"><button type="submit" class="btn-sm primary">مراجعة التحصيل</button><button type="button" class="btn-sm" onclick="closeModal()">إلغاء</button></div></form>`,true);
}
async function submitServiceWorkspaceCollection(event){
 event.preventDefault();const form=event.target,h=SERVICE_WORKSPACE,r=serviceWorkspaceCollectionTarget(h,form.dataset.record),amount=Number($('swCollectAmount').value),note=$('swCollectNote').value,method=$('swCollectMethod')?.value||'نقدي',button=form.querySelector('[type=submit]');
 if(button.disabled||!serviceWorkspaceOriginMatches(h)||!r||form.dataset.serviceWorkspaceForm!==h.serviceId||form.dataset.user!==h.origin.user||form.dataset.unit!==h.origin.unit||form.dataset.page!==h.origin.page)return;
 if(!Number.isFinite(amount)||amount<=0||Math.abs(amount*100-Math.round(amount*100))>0.000001||Math.round(amount*100)>Math.round(r.remaining*100)){toast('راجع المبلغ؛ لازم يكون أكبر من صفر وفي حدود المتبقي وبدقة قرشين.','error');return;}
 button.disabled=true;
 try{
  if(!await confirmAction({title:'تأكيد التحصيل',message:`استلمت ${taskExactMoney(amount)} للوحدة ${unitNo(r.unitNumber)} مقابل ${h.service.name}؟`,confirmLabel:'استلمت'}))return;
  if(!serviceWorkspaceOriginMatches(h)||!serviceWorkspacePresent(h.serviceId))return;
  beginBackgroundSave();
  try{
   if(r.source==='PERSONAL')await run('collectPersonalDue',{unitId:r.unitId,accountId:r.accountId,amount:amount.toFixed(2),reference:form.dataset.reference});
   else await run('recordBuildingPayment',{unitId:r.unitId,chargeId:r.chargeId,amount:amount.toFixed(2),method,note});
   if(!serviceWorkspaceOriginMatches(h))return;
   if(serviceWorkspacePresent(h.serviceId)){closeModal();await openServiceWorkspace(h.serviceId,'account',true);}toast('تم تسجيل التحصيل على حساب الخدمة.','success');
  }finally{endBackgroundSave();}
 }catch(e){toast(errText(e),'error');}finally{if(button.isConnected)button.disabled=false;}
}

async function submitServiceWorkspaceSubscribers(id){
 const h=SERVICE_WORKSPACE,pick=window.SERVICE_PICK,button=$('serviceAddSelectedButton');
 if(!h?.canManage||!serviceWorkspaceOriginMatches(h)||!serviceWorkspacePresent(id)||h.serviceId!==id||pick?.service?.serviceId!==id||button?.disabled)return;
 const ids=[...pick.selected];if(!ids.length)return;
 button.disabled=true;beginBackgroundSave();
 try{const result=await run('addServiceSubscribers',{serviceId:id,unitIds:ids,quantity:1});
  if(!serviceWorkspaceOriginMatches(h))return;h.view.selected.clear();
  if(APP.page==='services')await renderServices();
  await refreshOpenServiceWorkspace(id);toast(`تمت إضافة ${Number(result.created)||0} وحدة.`,'success');
 }catch(e){toast(errText(e),'error');}finally{endBackgroundSave();if(button?.isConnected)button.disabled=false;}
}

function serviceWorkspaceCollectionTarget(h,recordId){
 const row=h?.records.find(x=>x.recordId===recordId);if(!row)return null;
 if(row.source!=='PERSONAL')return row;
 const cents=h.records.filter(x=>x.unitId===row.unitId&&x.accountId===row.accountId&&x.source==='PERSONAL').reduce((n,x)=>n+Math.round(Number(x.remaining)*100),0);
 return {...row,remaining:cents/100};
}
