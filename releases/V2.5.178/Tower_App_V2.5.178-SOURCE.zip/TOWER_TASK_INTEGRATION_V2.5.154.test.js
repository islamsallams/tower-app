const fs=require('fs'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/app.js','utf8');
const css=fs.readFileSync(__dirname+'/styles.css','utf8');
const checks={
 'task modal from whole card':s.includes("if(card.dataset.kind==='tasks')openAdminTaskDetails(id)"),
 'task modal markup':s.includes('class="tower-task-modal-body"'),
 'no task inline expansion content':s.includes("const taskContent=isTask?'':'';"),
 'provisional fund deduction':s.includes('money(taskEstimatedNetBudget(s)/count)'),
 'provisional calculator':s.includes('function taskEstimatedNetBudget(s)'),
 'save form validation':s.includes("تقدم الأعمال يجب أن يكون بين 0 و100%"),
 'workflow date conditional':s.includes('function updateTaskRuleFields'),
 'task modal styles':css.includes('.tower-task-modal-body'),
 'public app sync':s===fs.readFileSync(__dirname+'/public/app.js','utf8'),
 'public css sync':css===fs.readFileSync(__dirname+'/public/styles.css','utf8'),
 'modal history support':s.includes('towerModal:true'),
 'page history support':s.includes('popstate'),
 'version stamp':s.includes("const APP_VERSION='2.5.178'")};
for(const [k,v] of Object.entries(checks)){assert(v,k);console.log('PASS',k)};
