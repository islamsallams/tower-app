const fs = require('node:fs');
const assert = require('node:assert/strict');
const app=fs.readFileSync(__dirname+'/app.js','utf8');
const publicApp=fs.readFileSync(__dirname+'/public/app.js','utf8');
const css=fs.readFileSync(__dirname+'/styles.css','utf8');
const pubCss=fs.readFileSync(__dirname+'/public/styles.css','utf8');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const pubHtml=fs.readFileSync(__dirname+'/public/index.html','utf8');
const worker=fs.readFileSync(__dirname+'/worker.js','utf8');
const checks=[
 ['one source for app and public',()=>assert.equal(app,publicApp)],
 ['one source for styles and public',()=>assert.equal(css,pubCss)],
 ['one source for html and public',()=>assert.equal(html,pubHtml)],
 ['tab handler retains visibility switching',()=>assert.match(app,/function towerSelectServiceTab\(tab,fromHistory=false\).*?data-tower-service-kind/s)],
 ['admin renders cards of both types',()=>assert.match(app,/SERVICE_UI\.services\.map\(s=>`<div data-tower-service-kind=/)],
 ['admin empty has stable DOM id',()=>assert.match(app,/id=\\?"tower-service-empty/)],
 ['hidden state has CSS priority',()=>assert.ok(css.includes('.service-admin-list>[data-tower-service-kind][hidden]{display:none!important}'))],
 ['readiness uses actual return field',()=>{assert.match(app,/towerTaskStageHtml\(s\)/);assert.doesNotMatch(app,/readiness\?readiness\.statusText/)}],
 ['tab selection contrasts in dark theme',()=>assert.match(css,/\.tower-service-tab\.active\{[^}]*background:color-mix/)],
 ['server and frontend version aligned',()=>{assert.match(app,/APP_VERSION='2\.5\.180'/);assert.match(worker,/APP_VERSION='2\.5\.180'/);assert.match(html,/styles\.css\?v=2\.5\.180/)}],
];
let bad=0;for(const [name,fn] of checks){try{fn();console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);bad++}}if(bad)process.exit(1);
