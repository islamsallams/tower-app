const assert=require('node:assert/strict');
const fs=require('node:fs');
const src=fs.readFileSync(__dirname+'/app.js','utf8');
const pub=fs.readFileSync(__dirname+'/public/app.js','utf8');
const worker=fs.readFileSync(__dirname+'/worker.js','utf8');
const cases=[
 ['version',()=>assert.match(src,/APP_VERSION='2\.5\.181'/)],
 ['public mirror',()=>assert.equal(src,pub)],
 ['worker version',()=>assert.match(worker,/APP_VERSION='2\.5\.181'/)],
 ['stage options scoped to enrollment',()=>assert.match(src,/stages=h\.enrollment==='FINALIZED'\?Object\.keys\(TASK_STAGE_NAMES\)/)],
 ['stage invalid before finalized guarded',()=>assert.match(src,/service\.enrollmentStatus!=='FINALIZED'&&\['READY','IN_PROGRESS','COMPLETED'\]/)],
 ['closed enrollment guarded',()=>assert.match(src,/service\.enrollmentStatus!=='OPEN'&&payload\.stage==='COLLECT_SUBSCRIBERS'/)],
 ['contribution locked after approval',()=>assert.match(src,/service\.enrollmentStatus==='FINALIZED'&&Math\.round/)],
 ['threshold universally validated',()=>assert.match(src,/!Number\.isInteger\(payload\.collectionThreshold\)/)],
 ['stage validated before saving',()=>assert.match(src,/مرحلة المهمة غير صالحة/)],
 ['save form persists on error',()=>assert.match(src,/catch\(e\)\{toast\('تعذر حفظ خطة المهمة:/)],
 ['modal back uses browser history',()=>assert.match(src,/function closeModal\(fromHistory=false\)\{[\s\S]*?if\(!fromHistory&&history\.state\?\.towerModal\)history\.back\(\)/)],
 ['popstate avoids recursive back',()=>assert.match(src,/while\(towerModalDepth\(\)>expectedDepth\)\{const before=towerModalDepth\(\);closeModal\(true\);if\(towerModalDepth\(\)===before\)return;/)],
 ['navigation permission before history push',()=>assert.match(src,/if\(!allowedPage\(key,role\)\).*?if\(!fromHistory&&history\.state\?\.towerPage!==key\)/)],
];
for(const [name,fn] of cases){fn();console.log('PASS',name)}
console.log('PASS',cases.length,'regressions');
