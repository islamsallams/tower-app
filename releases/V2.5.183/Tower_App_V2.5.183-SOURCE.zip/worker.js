function towerPdfFrequencyDue(frequency,year,month,day,monthlyDay=1){
 const mode=String(frequency||'MONTHLY').toUpperCase();
 if(mode==='DAILY')return true;
 if(mode==='MONTHLY'){
  const requested=Number(monthlyDay);
  if(!Number.isInteger(requested)||requested<1||requested>31)return false;
  const lastDay=new Date(Date.UTC(Number(year),Number(month),0)).getUTCDate();
  return Number(day)===Math.min(requested,lastDay);
 }
 if(mode==='WEEKLY')return new Date(Date.UTC(Number(year),Number(month)-1,Number(day))).getUTCDay()===0;
 return false;
}
const APP_VERSION='2.5.183';
// MIGRATION CATALOG: generated from supabase/*.sql; update via tools_build_migration_catalog.py, not by editing diagnostics.
const MIGRATION_CATALOG=[{"id":138,"filename":"138_pdf_claim_safe_release.sql"},{"id":139,"filename":"139_migration_registry.sql"},{"id":140,"filename":"140_operational_reset_test_pdf_jobs.sql"},{"id":141,"filename":"141_resident_trip_unpriced_items.sql"},{"id":142,"filename":"142_guard_open_trip_history.sql"}];
// Tower App clean Worker foundation. All sensitive Supabase requests originate server-side.
const JSON_HEADERS={'content-type':'application/json; charset=utf-8','cache-control':'no-store'};
function respond(body,status=200){return new Response(JSON.stringify(body),{status,headers:JSON_HEADERS});}
function fail(message,status=400,extra={}){return respond({error:message,...extra},status);}
async function db(env,path,{method='GET',body}={}){
  const root=String(env.SUPABASE_URL||'').replace(/\/+$/,'');
  const key=env.SUPABASE_SERVICE_ROLE_KEY;
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(root)||!key)throw Error('SUPABASE_SERVER_ENV_MISSING');
  const response=await fetch(root+'/rest/v1/'+path,{method,headers:{apikey:key,Authorization:'Bearer '+key,'content-type':'application/json',Accept:'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json().catch(()=>null);
  if(!response.ok){
    // Diagnostics never log request bodies, auth headers, session tokens or PINs.
    const rawCode=typeof data?.code==='string'?data.code:'';
    const code=/^[A-Z0-9]{4,8}$/.test(rawCode)?rawCode:'UNKNOWN';
    const resource=String(path).split('?')[0];
    const diagnostic={resource,httpStatus:response.status,dbCode:code};
    // A PostgreSQL 42883 can mean a missing RPC *or* an unresolved call inside an existing function.
    // Log only bounded, allowlisted SQL identifiers/signatures, never raw DB message/detail/hint.
    if(code==='42883'&&resource==='rpc/tower_service_shared_allocation_action'){
      const msg=String(data?.message||'');
      const m=/\b(function|procedure|operator)\s+([a-zA-Z_][a-zA-Z0-9_.]*(?:\s*\([^()\\'";\r\n]{0,200}\))?)\s+does not exist\b/i.exec(msg);
      if(m)diagnostic.missingSignature=(m[1]+' '+m[2]).slice(0,220);
      // Supabase PostgREST returns PGRST202 when its RPC signature is absent from schema cache.
      diagnostic.errorSource=msg.includes('schema cache')?'schema-cache':m?'postgres-function-resolution':'unknown';
    }
    console.error('SUPABASE_REQUEST_ERROR',JSON.stringify(diagnostic));
    const err=new Error(safeDbMessage(data,code));err.dbCode=code;err.httpStatus=response.status;throw err;
  }
  return data;
}
async function enrichTaskProjects(env,services,unitId=null){
 const tasks=(services||[]).filter(x=>x.serviceKind==='ONE_TIME'&&x.pricingMode==='SHARED_TOTAL');
 if(!tasks.length)return;
 try{
  const byId=new Map();
  for(let i=0;i<tasks.length;i+=80){
   const ids=tasks.slice(i,i+80).map(x=>String(x.serviceId)).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
   if(!ids.length)continue;
   const rows=await db(env,'tower_task_projects?select=service_id,phase,scope_text,deadline,distribution,target_units,agreed_amounts&service_id=in.('+ids.join(',')+')');
   if(!Array.isArray(rows))throw Error('INVALID_TASK_PROJECTS');
   for(const row of rows)byId.set(String(row.service_id),row);
  }
  for(const task of tasks){const p=byId.get(String(task.serviceId));if(p)task.project={phase:p.phase,scope:p.scope_text,deadline:p.deadline,distribution:p.distribution,eligible:!unitId||!p.target_units?.length||p.target_units.includes(unitId),...(!unitId?{agreedAmounts:p.agreed_amounts||[]}:{} )};}
 }catch(e){for(const task of tasks)task.taskProjectUnavailable=true;console.warn('TASK_PROJECTS_UNAVAILABLE');}
}
const DB_USER_ERRORS={INVALID_TASK_DEADLINE:"موعد الاشتراك لازم يكون تاريخ صحيح من النهارده أو بعده.",INVALID_FUND_FILTER:"راجع البحث والفترة الزمنية المطلوبة.",UNIT_ACCOUNT_ACCESS_DENIED:"حساب الوحدة متاح لمديرها فقط؛ المشاوير ومالية العمارة العامة متاحين كالمعتاد.",LATER_ACCOUNT_ACTIVITY:"في مشاوير جديدة اتسجلت بعد التسوية؛ لا يمكن التراجع عنها مع وجود النشاط ده.",INVALID_FUND_CONTRIBUTION:"مساهمة الصندوق لازم تكون صفر أو مبلغ موجب بدقة قرشين.",TASK_WORKFLOW_CHANGED_REFRESH:"إعدادات المهمة اتغيرت؛ افتح المهمة تاني وراجع القيم قبل الحفظ.",INSTALLMENT_SETUP_CHANGED:"موعد أول قسط اتغير مع بداية الشهر؛ افتح مراجعة الأقساط تاني.",INSTALLMENT_PLAN_ALREADY_INSTALLED:"جدول الأقساط مثبت بالفعل؛ حدّث الأقساط لعرضه.",INSTALLMENTS_REQUIRE_UNPAID_DUES:"السداد بدأ بالفعل؛ لا يمكن تثبيت جدول أقساط جديد على المستحقات دي.",INSTALLMENTS_EXCEED_AMOUNT_CENTS:"عدد الأقساط أكبر من المبلغ القابل للتقسيم؛ قلّل عدد الأقساط.",INSTALLMENT_START_DATE_REQUIRED:"تاريخ أول قسط غير متاح؛ حدّث التطبيق لاستخدام الموعد التلقائي.",NO_APPROVED_DUES:"مفيش مستحقات معتمدة محتاجة جدول أقساط.",EXECUTION_DATE_REQUIRED:"حدد موعد التنفيذ للشرط اللي اخترته.",INVALID_TASK_CONTROLS:"راجع إعدادات المهمة؛ النسب وعدد الأقساط لازم تكون أعداد صحيحة.",SQL234_REQUIRED:"شغّل SQL234 ثم SQL235 قبل استخدام الإعدادات الجديدة.",INVALID_TASK_REQUEST:'راجع نوع الطلب وسببه والمبلغ المقترح.',INVALID_RELATION:'اختار صلة القرابة أو اكتبها في أخرى، بحد أقصى80 حرف.',MEMBERSHIP_CHANGED_REFRESH:'صلة القرابة اتغيرت بعد فتح التعديل؛ حدّث بيانات الوحدة وافتح التعديل تاني.',TRANSFER_NOT_COMPLETED:'نقل الإدارة لم يكتمل، ولم يتم حفظ أي جزء من العملية.',INVALID_COLLECTION_BATCH:'راجع بنود التحصيل؛ الحد الأقصى100 بند وكل مبلغ لازم يكون موجبًا وبدقة قرشين.',COLLECTION_BATCH_REFERENCE_CONFLICT:'مراجعة التحصيل اتغيرت؛ حدّث نتيجة العملية السابقة قبل تسجيل عملية جديدة.',COLLECTION_BATCH_DEPENDENCY_REQUIRED:'شغّل ملف تحديث التحصيل المطلوب أولًا.',TASK_START_DATE_NOT_REACHED:'موعد بدء التنفيذ لسه ماجاش؛ راجع تاريخ التنفيذ قبل تغيير المرحلة.',TASK_START_COLLECTION_NOT_REACHED:'التحصيل أقل من المطلوب لبدء التنفيذ؛ راجع النسبة أو المبلغ المحدد.',USE_TASK_WORKSPACE:'افتح المهمة من نافذة إدارة المهمات.',ALLOCATION_CHANGED_REFRESH:'المشتركون أو الأنصبة اتغيروا بعد المعاينة؛ افتح المعاينة وراجعها من جديد.',EDIT_REASON_REQUIRED:'اكتب سبب التعديل المالي قبل الحفظ.',COLLECTION_EXCEEDS_REMAINING:'المبلغ أكبر من المتبقي الحالي؛ حدّث المستحقات وراجع المبلغ.',
 CUSTOM_ZERO_BASE_REQUIRES_NEW_AGREEMENT:'أنصبة الاتفاق الأصلي كلها صفر؛ الزيادة تحتاج اتفاق أنصبة جديد بدل افتراض توزيع من عندنا.',PENDING_DONATION_RETURN:'لسه فيه رد تبرع محتاج تأكيد استلام أو إلغاء قبل قفل الحساب.',UNIQUE_CURRENT_UNIT_MANAGER_REQUIRED:'لازم يبقى فيه مدير واحد نشط للوحدة لتحديد مستلم الرد.',FUND_CONTRIBUTION_RECEIPT_PENDING:'مساهمة الصندوق مسجلة لكن استلامها في حساب المهمة لسه محتاج تأكيد.',UNION_CANCELLATION_REASON_REQUIRED:'سجّل سبب الإلغاء والاتفاق قبل إقفال حساب المهمة.',
 ONLY_RECORDED_HOLDER_CAN_CONFIRM_EXPENSE:'اللي سجل دفع المصروف من عهدته هو اللي يؤكد خروجه منها.',
 UNIT_OUTSIDE_TASK_SCOPE:'الوحدة دي مش ضمن نطاق المهمة المحدد.',EXISTING_PARTICIPANT_OUTSIDE_SCOPE:'فيه مشاركون خارج النطاق الجديد. راجع القائمة قبل تعديل النطاق.',TASK_PARTICIPATION_DEADLINE_PASSED:'موعد تأكيد المشاركة انتهى؛ الإدارة تراجع تمديد المهلة.',ONLY_DRAFT_CAN_BE_CANCELLED:'الإلغاء ده متاح للمسودات فقط؛ السجلات المعتمدة محفوظة.',UNSETTLED_ADVANCES:'لسه فيه مقدمات غير مستخدمة محتاجة تسوية قبل قفل الحساب.',
"TASK_NOT_OPEN_FOR_PARTICIPATION":"المهمة لم تفتح للمشاركة أو اتقفلت.","TASK_CHANGED_REFRESH":"بيانات المهمة اتغيرت. افتحها تاني قبل الحفظ.","TASK_CLOSED":"المهمة ملغاة أو حسابها مقفول.","TASK_TERMS_REQUIRED":"اكتب نطاق الشغل وشروط المشاركة الأول.","VALID_DEADLINE_REQUIRED":"حدد آخر موعد صحيح لتأكيد المشاركة.","TERMS_LOCKED":"الشروط اتثبتت بعد قفل الاشتراك.","ALLOCATION_SUM_MISMATCH":"مجموع أنصبة الوحدات لازم يساوي صافي تكلفة المهمة.","PARTICIPANTS_CHANGED":"قائمة المشاركين اتغيرت. راجع مبالغ الوحدات.","DEDICATED_TASK_ACCOUNT_REQUIRED":"العملية دي محتاجة حساب مهمة مستقل؛ الحسابات القديمة لا تتحول تلقائيًا.","CREDIT_EXCEEDS_APPROVED_DUES":"التخفيض أكبر من المستحق المعتمد المتبقي بعد التسويات.","INSUFFICIENT_HOLDER_BALANCE":"المبلغ أكبر من العهدة المتاحة عندك في حساب المهمة.","REFERENCE_CONFLICT":"مرجع العملية مستخدم ببيانات مختلفة.","UNSETTLED_UNIT_BALANCES":"لسه فيه مستحقات أو مبالغ واجبة الرد للسكان.","UNSETTLED_EXPENSES":"لسه فيه مصروفات أو مطالبات ما اتسوتش.","UNSETTLED_CUSTODY":"لسه فيه عهدة محتاجة تسوية قبل قفل الحساب.","EXECUTION_NOT_COMPLETED":"استلم الشغل وسجّل اكتمال التنفيذ الأول.","SETTLE_AUTHORIZED_REFUNDS_FIRST":"سوّي طلبات رد المبالغ المعتمدة قبل أي تسوية تكلفة جديدة.","TASK_NOT_ACCEPTING_FINANCIAL_POSTS":"المهمة لا تستقبل قيودًا مالية في حالتها الحالية.","REFUND_UNAVAILABLE_OR_ALREADY_AUTHORIZED":"مفيش مبلغ متاح للرد أو فيه اعتماد رد قائم بالفعل.","UNIT_ACCESS_DENIED":"حسابك مش مرتبط بعضوية نشطة في الوحدة المطلوبة.",

 INVALID_DIGEST_TIME:'اختَر موعدًا صحيحًا بفواصل 5 دقائق.',DIGEST_SCHEDULE_NOT_INSTALLED:'إعداد موعد الملخص غير مثبت. نفّذ ملف SQL 104 أولًا.',
 INVALID_IMAGE:'تعذر حفظ الصورة. استخدم JPG أو PNG أو WebP بحجم مناسب.',UNIT_MEMBERSHIP_REQUIRED:'حسابك غير مرتبط بعضوية نشطة في وحدة.',
 SESSION_REQUIRED:'انتهت جلسة الدخول. سجّل الدخول مرة أخرى.',PIN_CHANGE_REQUIRED:'يجب تغيير الرقم السري أولًا.',
 FORBIDDEN:'ليس لديك صلاحية لتنفيذ هذا الإجراء.',REQUEST_NOT_FOUND:'الطلب غير موجود أو لم يعد متاحًا.',
 REQUEST_ALREADY_REVIEWED:'لا يمكن تعديل طلب تمت الموافقة عليه أو رفضه.',
 INVALID_REQUEST_ID:'معرّف الطلب غير صالح.',INVALID_MEMBER_NAME:'اكتب اسم العضو (من 1 إلى 80 حرفًا).',
 INVALID_MEMBER_DETAILS:'راجع رقم الهاتف وكود الدولة وصلة القرابة.',INVALID_TITLE_ID:'اختيار اللقب غير صالح.',
 TITLE_NOT_FOUND:'اللقب المختار لم يعد متاحًا.',INVALID_CUSTOM_TITLE:'اكتب اللقب المخصص (من 1 إلى 40 حرفًا).',
 SETTLEMENT_CHANGED_REFRESH:'آخر تسوية اتغيرت؛ حدّث الحساب وراجعها قبل التراجع.',ONLY_LATEST_SETTLEMENT:'آخر تسوية اتلغت بالفعل أو مفيش تسوية قابلة للتراجع. مسموح الرجوع تسوية واحدة بس.',
 CREDIT_ALREADY_USED:'لا يمكن التراجع عن هذه التسوية لأن جزءًا من رصيدها المرحّل استُخدم في تسوية لاحقة.',
 SETTLEMENT_NOT_FOUND:'التسوية المطلوبة غير موجودة أو غير متاحة لهذه الوحدة.',
 PAYMENT_NOT_CANCELABLE:'لا يمكن إلغاء دفعة مستخدمة في تسوية أو سبق إلغاؤها.',
 INVALID_AMOUNT:'أدخل مبلغًا صحيحًا وأكبر من الصفر.',
 INVALID_TRIP_PRICE:'اكتب السعر بالأرقام، أو اتركه فارغًا لتحديده لاحقًا.',
 INVALID_TRIP_ITEMS:'راجع أسماء المشتريات وأسعارها ثم حاول مجددًا.',
 TRIP_ALREADY_SETTLED:'تمت تسوية المشوار، لذلك لا يمكن تعديل مشترياته.',
 TRIP_NOT_FOUND:'المشوار غير موجود أو غير متاح، حدّث القائمة.',
 NO_OPEN_TRIPS:'لا توجد مشاوير مفتوحة لإجراء تسوية.',
 NO_ACTIVE_UNIT:'حسابك غير مرتبط بوحدة نشطة. تواصل مع مدير النظام.',
 UNIT_NOT_FOUND:'لم يتم العثور على وحدة نشطة مرتبطة بهذا الحساب.',
 INVALID_OPERATION:'الإجراء المطلوب غير متاح.',
 RESET_PREVIEW_STALE:'تغيرت البيانات منذ المعاينة. أعد المعاينة قبل التصفير.',
 RESET_SCHEMA_CHANGED:'تغير مخطط قاعدة البيانات. التصفير متوقف لحين مراجعة الأمان.',
 RESET_PROTECTED_DEPENDENCY:'هناك علاقة جديدة بجداول محمية تمنع التصفير.',
 RESET_CONFIRMATION_REQUIRED:'يجب كتابة عبارة التأكيد والموافقة على المتابعة بدون نسخة جديدة.',
 INVALID_FEE:'راجع قيم أتعاب المشاوير المدخلة.',
 INVALID_PAYMENT:'راجع بيانات الدفعة واختر وحدة وبند تحصيل صالحين.',
 INVALID_EXPENSE:'راجع بيانات المصروف والبند والمبلغ المدخل.',
 INVALID_PAYMENT_AMOUNT:'أدخل مبلغ دفعة أكبر من صفر.',
 INVALID_EXPENSE_AMOUNT:'أدخل مبلغ مصروف أكبر من صفر.',
 INSUFFICIENT_BALANCE:'الرصيد المتاح غير كافٍ لتنفيذ العملية.',
 DUPLICATE_PAYMENT:'هذه الدفعة مسجلة بالفعل. راجع سجل الدفعات قبل المحاولة مجددًا.',
 EXPENSE_NOT_FOUND:'المصروف المطلوب غير موجود أو لم يعد متاحًا.',
 CHARGE_NOT_FOUND:'بند التحصيل غير موجود أو غير نشط.',
 INVALID_UNIT_ID:'اختر وحدة صحيحة قبل الحفظ.',
 PHONE_REQUIRED_FOR_MANAGER:'لا يمكن تولي إدارة الوحدة بدون رقم موبايل؛ أضفه من الإعدادات أولًا.',
 INVALID_PHONE:'رقم الموبايل غير صحيح؛ راجع الرقم.',
 INVALID_EMAIL:'صيغة البريد الإلكتروني غير صحيحة.',
 INVALID_REGISTRATION:'راجع الاسم ورقم الموبايل الاختياري ثم أعد المحاولة.',
 REQUEST_NOT_PENDING:'الطلب تمت مراجعته بالفعل؛ حدّث القائمة.'
};
function safeDbMessage(data,code){
 const msg=typeof data?.message==='string'?data.message.trim():'';
 if(Object.hasOwn(DB_USER_ERRORS,msg))return DB_USER_ERRORS[msg];
 // Database exception text is untrusted: only a bounded, explicitly approved code prefix is exposed.
 const prefix=/^([A-Z][A-Z0-9_]{2,65})(?=[:\s]|$)/.exec(msg);
 if(prefix&&Object.hasOwn(DB_USER_ERRORS,prefix[1]))return DB_USER_ERRORS[prefix[1]];
 if(/^RESET_STAGE_[A-Z0-9_]+$/.test(msg))return 'تعذر التصفير في خطوة '+msg.slice(12)+'. تم إلغاء العملية بالكامل. انسخ رمز المرحلة للدعم.';
 if(code==='23505')return 'هذه البيانات مسجلة بالفعل. راجع السجل قبل المحاولة مجددًا.';
 if(code==='23502')return 'هناك حقل مطلوب لم يتم إدخاله. راجع بيانات النموذج.';
 if(code==='23513')return 'هناك قيمة غير مسموح بها في البيانات المدخلة.';
 if(code==='23503')return 'لا يمكن تنفيذ العملية بسبب بيانات مرتبطة بها.';
 if(code==='23514')return 'البيانات لا تستوفي الشروط المطلوبة.';
 if(code==='22003')return 'الرقم المدخل خارج الحدود المسموح بها.';
 if(code==='22P02'||code==='22001')return 'راجع صيغة البيانات المدخلة وطولها.';
 if(code==='22007'||code==='22008')return 'التاريخ أو الوقت المدخل غير صحيح؛ راجع البيانات.';
 if(code==='23502')return 'أكمل الحقول المطلوبة قبل الحفظ.';
 if(code==='PGRST202')return 'وظيفة مطلوبة غير متاحة على قاعدة البيانات. تواصل مع الإدارة.';
 if(code==='42501')return 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';
 return 'تعذر إتمام العملية. حاول مرة أخرى أو انسخ تفاصيل الخطأ للدعم.';
}
function strictName(v){return /^[a-zA-Z][a-zA-Z0-9_]{0,70}$/.test(String(v||''));}
async function rpc(env,name,params){if(!strictName(name))throw Error('INVALID_OPERATION');return db(env,'rpc/'+name,{method:'POST',body:params});}
async function readUiPreferences(env,token){
 if(!token)return {fontFamily:'Cairo'};
 try{return await rpc(env,'tower_ui_preferences_action',{p_token:token,p_action:'get',p_payload:{}});}
 catch(e){ if(String(e.message||'').includes('DATABASE_REQUEST_FAILED 404'))return {fontFamily:'Cairo'};throw e;}
}
const PERSON_LABEL_KEYS=new Set(['actorDisplayName','actorName','actor_display_name','actor_name','approvedByName','approved_by_name','beneficiaryName','beneficiary_name','candidateName','candidate_name','collectorName','collector_name','confirmedByName','confirmed_by_name','counterpartyName','counterparty_name','createdByName','created_by_name','deliveredByName','delivered_by_name','displayName','display_name','managerDisplayName','managerName','manager_display_name','manager_name','memberName','memberNames','member_name','member_names','ownerName','owner_name','payerName','payer_name','receiverName','receiver_name','recipientName','recipient_name','recordedByName','recorded_by_name','requestedByName','requested_by_name','requesterName','requester_name','responsibleName','responsible_name','reviewedByName','reviewed_by_name','senderName','sender_name','userName','user_name']);
function hasPersonLabels(value){if(!value||typeof value!=='object')return false;if(Array.isArray(value))return value.some(hasPersonLabels);if(value.notificationId||value.notification_id||value.notificationType)return true;if(value.columns&&value.rows)return true;if(value.name&&(value.userId||value.user_id||value.loginId||value.login_id||value.title&&('phone'in value||'relation'in value||'memberRole'in value||'preferredTitle'in value)||['ADMIN','UNION','RESIDENT','OPERATOR'].includes(value.role)))return true;return Object.entries(value).some(([k,v])=>PERSON_LABEL_KEYS.has(k)&&Boolean(v)||hasPersonLabels(v));}
function personLabelsFallback(value){if(!value||typeof value!=='object')return value;if(Array.isArray(value))return value.map(personLabelsFallback);const out={};for(const [key,v]of Object.entries(value)){out[key]=PERSON_LABEL_KEYS.has(key)?(Array.isArray(v)?v.map(()=> 'اللقب غير متاح'):'اللقب غير متاح'):personLabelsFallback(v);}if(value.name&&(value.userId||value.user_id||value.loginId||value.login_id||value.title&&('phone'in value||'relation'in value||'memberRole'in value||'preferredTitle'in value)||['ADMIN','UNION','RESIDENT','OPERATOR'].includes(value.role)))out.displayName=workerPersonName({...value,title:value.preferredTitle||value.title,custom_title:value.customTitle||value.custom_title});if(value.notificationId||value.notification_id||value.notificationType){for(const key of ['title','body','message','text'])if(typeof value[key]==='string')out[key]='تعذر عرض أسماء الإشعار؛ حاول لاحقًا.';}if(Array.isArray(value.columns)&&Array.isArray(value.rows))out.rows=value.rows.map(row=>Array.isArray(row)?row.map((cell,i)=>/مدير الوحدة|اسم الشخص|اسم العضو|المسؤول|المحصّل|المحصل|المستلم|المستخدم|مدير الحساب/.test(String(value.columns[i]?.label||value.columns[i]||''))?'اللقب غير متاح':cell):personLabelsFallback(row));return out;}
async function presentPersonLabels(env,value){if(!hasPersonLabels(value))return value;try{return await db(env,'rpc/tower_present_names_231',{method:'POST',body:{p_value:value}});}catch(_){console.warn('PERSON_LABELS_UNAVAILABLE');return personLabelsFallback(value);}}
function workerPersonName(person){const name=String(person?.name||'').trim(),title=[person?.custom_title,person?.customTitle,person?.preferredTitle,person?.title].map(x=>String(x||'').trim()).find(Boolean)||'أ.';return !name?'غير محدد':title==='بدون لقب'?name:name===title||name.startsWith(title+' ')?name:title+' '+name;}
function canonicalUser(u){return {authenticated:true,userId:u.user_id,loginId:u.login_id,name:u.name,titleId:u.title_id||'',customTitle:u.custom_title||'',preferredTitle:[u.custom_title,u.title].map(x=>String(x||'').trim()).find(Boolean)||'أ.',displayName:workerPersonName(u),role:u.role,roleLabel:({ADMIN:'إدارة النظام',UNION:'رئيس اتحاد الشاغلين',RESIDENT:'ساكن',OPERATOR:'حارس'})[u.role],mustChangePin:u.must_change_pin,phone:u.phone||'',email:u.email||'',isUnitManager:Boolean(u.is_unit_manager)};}
async function sessionUser(env,token){if(!token)return null;const rows=await rpc(env,'tower_session_user',{p_token:token});return Array.isArray(rows)?rows[0]||null:rows;}

// Telegram integration: service-role only; chat binding requires a fresh, one-use random challenge.
const tgHex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
async function tgHash(value){return tgHex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));}
function tgChallenge(){return tgHex(crypto.getRandomValues(new Uint8Array(24)));}
async function telegramSend(env,chatId,message){
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 message=await db(env,'rpc/tower_present_text_231',{method:'POST',body:{p_message:message}});
 const r=await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/sendMessage',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({chat_id:chatId,text:message,disable_web_page_preview:true}),signal:AbortSignal.timeout(20000)});
 const result=await r.json().catch(()=>null);
 if(r.status===429){const sec=Number(result?.parameters?.retry_after||r.headers.get('retry-after')||600);const e=Error('TELEGRAM_RATE_LIMITED');e.retryAfterSeconds=Math.min(86400,Math.max(60,Number.isFinite(sec)?Math.ceil(sec):600));throw e;}
 if(r.status===403){throw Error('TELEGRAM_RECIPIENT_BLOCKED');}
 if(!r.ok||result?.ok!==true)throw Error('TELEGRAM_DELIVERY_FAILED');return result;
}
// Cron heartbeat is diagnostic-only: failure to record it must never stop delivery.
async function recordTelegramCron(env,fields){
 try{await db(env,'tower_telegram_cron_health?health_id=eq.1',{method:'PATCH',body:fields});}
 catch(e){console.error('TELEGRAM_CRON_HEALTH_UNAVAILABLE',String(e.message||e).slice(0,60));}
}
async function scheduledTelegramRun(env){
 const started=new Date().toISOString();
 await recordTelegramCron(env,{last_started_at:started,last_status:'RUNNING'});
 try{
  const result=await telegramProcessQueue(env);
  await recordTelegramCron(env,{last_finished_at:new Date().toISOString(),last_status:(result.digestEnqueueFailed||result.failed>0)?'DEGRADED':'SUCCESS',last_jobs_sent:result.sent,last_jobs_failed:result.failed,last_digest_error:result.digestEnqueueFailed});
 }catch(e){
  await recordTelegramCron(env,{last_finished_at:new Date().toISOString(),last_status:'ERROR',last_digest_error:false});
  throw e;
 }
}
// V2.5.12: role-limited daily digest data comes from current authoritative tables.
// Do not substitute zero when a database query fails: let the queue retry instead.
function digestAmount(value){
 const n=Number(value);
 if(!Number.isFinite(n))throw Error('DIGEST_AMOUNT_UNAVAILABLE');
 return Math.ceil(n).toLocaleString('en-US',{maximumFractionDigits:0})+' ج.م';
}
function digestCairoDay(){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',day:'2-digit',month:'2-digit',year:'numeric'}).formatToParts(new Date());
 const part=k=>parts.find(p=>p.type===k)?.value||'';
 return part('day')+'/'+part('month')+'/'+part('year');
}
function telegramRoleDigestText(m){
 if(!m||m.eligible!==true)throw Error('DIGEST_NOT_ELIGIBLE');
 const count=(v)=>{const n=Number(v);if(!Number.isInteger(n)||n<0)throw Error('DIGEST_COUNT_UNAVAILABLE');return String(n);};
 if(m.role==='UNION'){
  const out=['📊 Tower App — الملخص المالي لرئيس الاتحاد — '+digestCairoDay()];
  if(m.showAmounts===true)out.push('رصيد الصندوق: '+digestAmount(m.balance),
   'تحصيلات اليوم: '+digestAmount(m.collectedToday),
   'مصروفات اليوم: '+digestAmount(m.expensesToday),
   'المستحقات غير المسددة: '+digestAmount(m.outstandingDues));
  else out.push('التفاصيل المالية مخفية حسب إعداد حسابك.');
  out.push('تقارير التحصيل المعلقة: '+count(m.pendingCollectionReports));
  return out.join('\n');
 }
 if(m.role==='OPERATOR')return ['🛎️ Tower App — الملخص التشغيلي للحارس — '+digestCairoDay(),
  'المشاوير المفتوحة: '+count(m.openTrips),
  'المشاوير الجديدة اليوم: '+count(m.newTripsToday),
  'المشاوير التي تمت تسويتها اليوم: '+count(m.settledTripsToday),
  'وحدات لديها مشاوير مفتوحة: '+count(m.unitsWithOpenTrips),
  'دفعات ساكن لم تُطبّق بعد: '+count(m.openResidentPayments)].join('\n');
 throw Error('DIGEST_ROLE_FORBIDDEN');
}
function telegramDeepLink(env,role,type){
 // Default to this deployment's public app URL when the optional override is absent.
 const base=String(env.TOWER_APP_PUBLIC_URL||'https://tower-app.islamsallams.workers.dev').replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9.-]+(?::443)?(?:\/[a-z0-9_/-]*)?$/i.test(base))return '';
 const route={
  ADMIN:{COLLECTION:'collections',EXPENSE:'finance',INCOME:'finance',TRIP:'reports',SETTLEMENT:'reports',SERVICE:'home'},
  UNION:{COLLECTION:'collections',EXPENSE:'finance',INCOME:'finance',TRIP:'reports',SETTLEMENT:'reports',SERVICE:'services'},
  OPERATOR:{COLLECTION:'collections',TRIP:'trips',SETTLEMENT:'trips'},
  RESIDENT:{COLLECTION:'building-fund',EXPENSE:'building-fund',INCOME:'building-fund',TRIP:'trips',SETTLEMENT:'account',SERVICE:'building'}
 };
 const page=route[role]?.[type];
 return page?base+'/?view='+encodeURIComponent(page):'';
}
async function telegramDispatchMessage(env,job){
 const msg=String(job.message||'');
 const needsDigest=msg.includes('الملخص اليومي:');
 const needsLink=msg.includes('افتح التطبيق');
 if(!needsDigest&&!needsLink)return msg;
 const records=await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id)+'&select=user_id,event_key&limit=1');
 const log=records[0],key=String(log?.event_key||'');
 if(!log)throw Error('TELEGRAM_EVENT_NOT_FOUND');
 if(needsDigest){
  if(!/^digest:\d{4}-\d{2}-\d{2}$/.test(key))throw Error('DIGEST_EVENT_INVALID');
  const metrics=await rpc(env,'tower_telegram_digest_metrics',{p_user_id:log.user_id});
  return telegramRoleDigestText(metrics);
 }
 if(!/^notification:[0-9a-f-]{36}$/i.test(key))return msg;
 const notificationId=key.slice('notification:'.length);
 const [userRows,eventRows]=await Promise.all([
  db(env,'tower_users?user_id=eq.'+encodeURIComponent(log.user_id)+'&select=role&limit=1'),
  db(env,'tower_notifications?notification_id=eq.'+encodeURIComponent(notificationId)+'&select=type&limit=1')
 ]);
 const link=telegramDeepLink(env,String(userRows[0]?.role||''),String(eventRows[0]?.type||''));
 return link?msg+'\nافتح القسم المناسب: '+link:msg;
}
// Outbox processing is independent of financial actions. Daily digest requires explicit account consent at enqueue and dispatch. Cron is best-effort and
// delivery is at-least-once across process crashes; event keys prevent queue duplicates.
async function telegramProcessQueue(env){
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 let sent=0,failed=0,digestEnqueueFailed=false;
 // Daily summary enqueue is database-gated to 09:00 Africa/Cairo and
 // deduplicated per Tower account per local calendar day.
 try{await rpc(env,'tower_telegram_enqueue_daily_digest',{});}catch(e){
  digestEnqueueFailed=true;console.error('TELEGRAM_DIGEST_ENQUEUE_FAILED',String(e.message||e).slice(0,70));
 }
 const jobs=await rpc(env,'tower_telegram_claim',{p_limit:15});
 for(const job of Array.isArray(jobs)?jobs:[]){
  try{
   const message=await telegramDispatchMessage(env,job);
   await telegramSend(env,job.chat_id,message);
   await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),
    {method:'PATCH',body:{status:'SENT',sent_at:new Date().toISOString()}});
   sent++;
  }catch(error){
   // The SQL claim already scheduled a retry. Telegram's explicit 429 and 403
   // are classified without logging the chat ID, message or Telegram response body.
   failed++;
   const reason=String(error?.message||'TELEGRAM_DELIVERY_FAILED');
   if(reason==='TELEGRAM_RECIPIENT_BLOCKED'){
    try{await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),{method:'PATCH',body:{status:'CANCELLED'}});}catch{console.error('TELEGRAM_CANCEL_UPDATE_FAILED');}
   }else if(reason==='TELEGRAM_RATE_LIMITED'){
    const seconds=Math.min(86400,Math.max(60,Number(error.retryAfterSeconds)||600));
    try{await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),{method:'PATCH',body:{next_attempt_at:new Date(Date.now()+seconds*1000).toISOString()}});}catch{console.error('TELEGRAM_RETRY_UPDATE_FAILED');}
   }
   console.error('TELEGRAM_OUTBOX_DELIVERY_FAILED',/^(TELEGRAM_RATE_LIMITED|TELEGRAM_RECIPIENT_BLOCKED)$/.test(reason)?reason:'TELEGRAM_DELIVERY_FAILED');
  }
 }
 return {sent,failed,digestEnqueueFailed};
}
// Manual PDF export: the report was generated in the authenticated client's preview;
// the Worker verifies the Tower user's CURRENT reporting rights before forwarding it
// only to this same user's linked Telegram chat. The bot token never reaches the browser.
async function telegramSendPdf(env,chatId,pdfBytes,fileName,caption){
 caption=await db(env,'rpc/tower_present_text_231',{method:'POST',body:{p_message:caption||''}});
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 const form=new FormData();
 form.set('chat_id',String(chatId));
 form.set('caption',caption);
 form.set('document',new Blob([pdfBytes],{type:'application/pdf'}),fileName);
 const response=await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/sendDocument',{method:'POST',body:form,signal:AbortSignal.timeout(30000)});
 if(!response.ok)throw Error('TELEGRAM_PDF_FAILED');
 const result=await response.json().catch(()=>null);
 if(result?.ok!==true)throw Error('TELEGRAM_PDF_REJECTED');
 return {success:true};
}
async function telegramManualPdf(env,u,account,options){
 if(!account?.chat_id||!account.enabled)throw Error('TELEGRAM_NOT_LINKED');
 if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
 const reportId=String(options?.reportId||'');
 if(!/^[A-Z][A-Z0-9_]{1,55}$/.test(reportId))throw Error('INVALID_REPORT');
 // Report-specific access must be checked again, not trusted from a client-supplied ID.
 if(reportId==='COMBINED_OVERVIEW'){
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  // This report relies on the existing privileged snapshot API.
  await rpc(env,'tower_building_financial_snapshot',{p_token:u._tg_session_token});
 }else{
  const catalog=await rpc(env,'tower_report_action',{p_token:u._tg_session_token,p_action:'catalog',p_payload:{}});
  if(!Array.isArray(catalog)||!catalog.some(x=>x?.id===reportId))throw Error('FORBIDDEN');
 }
 const b64=String(options?.base64||'');
 if(b64.length<80||b64.length>8*1024*1024||!/^[A-Za-z0-9+/]+={0,2}$/.test(b64))throw Error('INVALID_PDF');
 let binary;try{binary=atob(b64);}catch{throw Error('INVALID_PDF');}
 if(binary.length<50||binary.length>6*1024*1024||binary.slice(0,5)!=='%PDF-')throw Error('INVALID_PDF');
 const rawName=String(options?.filename||'Tower_Report.pdf');
 const safeName=Array.from(rawName.normalize('NFC').replace(/[\\/\x00-\x1f<>:"|?*]/g,'_').replace(/\s+/g,' ').trim()).slice(0,95).join('');
 if(!safeName.toLowerCase().endsWith('.pdf'))throw Error('INVALID_PDF');
 const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 const role=({ADMIN:'إدارة النظام',UNION:'رئيس الاتحاد',OPERATOR:'الحارس',RESIDENT:'الساكن'})[u.role];
 return telegramSendPdf(env,account.chat_id,bytes,safeName,'📄 Tower App — '+role+'\nتم إرسال تقرير PDF يدويًا من حسابك.');
}
// The opening user's role does not select or authorize PDF recipients.
// Read-only preflight; database RPCs serialize claims per eligible recipient.
async function towerPdfDispatchTargets(env){
 const sched=(await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day'))[0];
 if(!sched)return {day:null,recipients:[]};
 const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
 const val=n=>parts.find(x=>x.type===n)?.value;
 const day=[val('year'),val('month'),val('day')].join('-');
 const [sh,sm]=String(sched.send_time).split(':').map(Number);
 if(Number(val('hour'))*60+Number(val('minute'))<sh*60+sm||!towerPdfFrequencyDue(sched.frequency,val('year'),val('month'),val('day'),sched.monthly_day))return {day,recipients:[]};
 const prefs=await db(env,'tower_telegram_pdf_preferences?enabled=eq.true&select=user_id');
 if(!prefs.length)return {day,recipients:[]};
 const ids=prefs.map(p=>p.user_id).filter(x=>/^[a-f0-9-]{36}$/i.test(x));
 if(!ids.length)return {day,recipients:[]};
 const users=await db(env,'tower_users?user_id=in.('+ids.join(',')+')&role=in.(ADMIN,UNION)&status=eq.ACTIVE&must_change_pin=eq.false&select=user_id');
 const valid=new Set(users.map(x=>x.user_id));
 const accts=await db(env,'tower_telegram_accounts?user_id=in.('+ids.join(',')+')&enabled=eq.true&chat_id=not.is.null&select=user_id,chat_id');
 const jobs=await db(env,'tower_telegram_pdf_jobs?report_day=eq.'+day+'&user_id=in.('+ids.join(',')+')&select=user_id,status,attempts,lease_until,updated_at');
 const now=Date.now(),byId=new Map(jobs.map(j=>[j.user_id,j]));
 const recipients=accts.filter(r=>valid.has(r.user_id)).filter(r=>{
  const j=byId.get(r.user_id);if(!j)return true;
  if(j.status==='SENT'||j.attempts>=5)return false;
  if(['CLAIMED','SENDING'].includes(j.status)&&j.lease_until&&Date.parse(j.lease_until)>now)return false;
  if(j.status==='FAILED'&&Date.parse(j.updated_at||0)+600000>now)return false;
  return true;
 });
 return {day,recipients};
}
async function towerPdfDispatch(env,opts){
 const info=await towerPdfDispatchTargets(env);
 if(!info.recipients.length)return {sent:0,failed:0};
 const b64=String(opts?.base64||'');
 if(b64.length<80||b64.length>8*1024*1024||!/^[A-Za-z0-9+/]+={0,2}$/.test(b64))throw Error('INVALID_PDF');
 let binary;try{binary=atob(b64);}catch{throw Error('INVALID_PDF');}
 if(binary.length<50||binary.length>6*1024*1024||binary.slice(0,5)!=='%PDF-')throw Error('INVALID_PDF');
 const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 const filename='Tower_Periodic_Finance_'+info.day+'.pdf';
 let sent=0,failed=0,startRejected=0,claimRejected=0;
 for(const r of info.recipients){
  const nonce=crypto.randomUUID();
  const claimed=await rpc(env,'tower_telegram_pdf_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce});
  if(claimed!==true){claimRejected++;continue;}
  try{
   const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce});
   if(started!==true){startRejected++;console.warn('TELEGRAM_PDF_START_REJECTED');await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce}).catch(e=>console.warn('PDF_CLAIM_RELEASE_FAILED',String(e?.message||e).slice(0,100)));continue;}
   try{
    await telegramSendPdf(env,r.chat_id,bytes,filename,'📄 Tower App — التقرير المالي الدوري');
    await rpc(env,'tower_telegram_pdf_finish',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce,p_success:true});sent++;
   }catch(e){failed++;await rpc(env,'tower_telegram_pdf_finish',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce,p_success:false}).catch(()=>{});}
  }catch(e){failed++;console.error('TELEGRAM_PDF_JOB_ERROR',String(e?.message||e).slice(0,120));await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce}).catch(()=>{});}
 }
 return {sent,failed,startRejected,claimRejected};
}
async function telegramUserAction(env,u,action,opts={}){
 if(!['ADMIN','UNION','OPERATOR','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
 if(!env.TELEGRAM_BOT_USERNAME||!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 const userId=u.user_id;
 const rows=await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId)+'&select=user_id,chat_id,enabled,show_amounts,daily_digest_enabled,linked_at');
 const item=rows[0]||null;
 if(action==='status')return {linked:!!item?.chat_id,enabled:item?.enabled??false,showAmounts:item?.show_amounts??false,dailyDigestEnabled:['UNION','OPERATOR'].includes(u.role)&&(item?.daily_digest_enabled??false),linkedAt:item?.linked_at||null};
 if(action==='begin'){
  const code=tgChallenge(),hash=await tgHash(code);
  await db(env,'tower_telegram_links?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_links',{method:'POST',body:{user_id:userId,challenge_hash:hash,expires_at:new Date(Date.now()+10*60*1000).toISOString()}});
  return {url:'https://t.me/'+env.TELEGRAM_BOT_USERNAME.replace(/^@/,'')+'?start='+code,expiresMinutes:10};
 }
 if(action==='set'){
  if(!item?.chat_id)throw Error('TELEGRAM_NOT_LINKED');
  const body={};if(typeof opts.enabled==='boolean')body.enabled=opts.enabled;if(typeof opts.showAmounts==='boolean')body.show_amounts=opts.showAmounts;if(typeof opts.dailyDigestEnabled==='boolean'){if(!['UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');body.daily_digest_enabled=opts.dailyDigestEnabled;}
  if(!Object.keys(body).length)throw Error('INVALID_OPERATION');
  await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId),{method:'PATCH',body});return {success:true};
 }
 if(action==='getPdfSchedule'||action==='setPdfSchedule'){
  if(u.role!=='ADMIN')throw Error('FORBIDDEN');
  if(action==='setPdfSchedule'){
   const time=String(opts.time||''),frequency=String(opts.frequency||'MONTHLY'),monthlyDay=Number(opts.monthlyDay??1);
   if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('INVALID_PDF_TIME');
   if(!['DAILY','WEEKLY','MONTHLY'].includes(frequency))throw Error('INVALID_PDF_FREQUENCY');
   if(!Number.isInteger(monthlyDay)||monthlyDay<1||monthlyDay>31)throw Error('INVALID_PDF_MONTHLY_DAY');
   const changed=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true',{method:'PATCH',body:{send_time:time+':00',frequency,monthly_day:monthlyDay}});
   if(!changed.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
   return {time:String(changed[0].send_time).slice(0,5),frequency:changed[0].frequency,monthlyDay:changed[0].monthly_day};
  }
  const rows=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!rows.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
  return {time:String(rows[0].send_time).slice(0,5),frequency:rows[0].frequency||'MONTHLY',monthlyDay:rows[0].monthly_day||1};
 }
 if(action==='setDailyPdf'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.chat_id)throw Error('FORBIDDEN');
  if(typeof opts.enabled!=='boolean')throw Error('INVALID_OPERATION');
  await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_pdf_preferences',{method:'POST',body:{user_id:userId,enabled:opts.enabled}});
  return {success:true};
 }
 if(action==='dailyPdfStatus'){
  if(!['ADMIN','UNION'].includes(u.role))return {enabled:false,eligible:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&select=enabled');
  return {enabled:pref[0]?.enabled===true,eligible:!!item?.enabled&&!!item?.chat_id};
 }
 if(action==='dailyPdfHistory'){
  // Only the signed-in finance recipient can inspect their own delivery attempts.
  // Return operational metadata, never report content, balances or other users' jobs.
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  const rows=await db(env,'tower_telegram_pdf_jobs?user_id=eq.'+encodeURIComponent(userId)+'&select=report_day,status,attempts,updated_at,completed_at,lease_until&order=report_day.desc&limit=5');
  return {jobs:rows.map(j=>({day:j.report_day,status:j.status,attempts:j.attempts,updatedAt:j.updated_at,completedAt:j.completed_at,leaseUntil:j.lease_until}))};
 }
 if(action==='autoPdfDue'){
  const plan=await towerPdfDispatchTargets(env);
  return {due:plan.recipients.length>0};
 }
 if(action==='autoPdfDispatch')return towerPdfDispatch(env,opts);
 if(action==='dailyPdfDue'){
  // Pure eligibility preflight: NEVER reserve a job before browser rendering succeeds.
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)return {due:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pref.length)return {due:false};
  const schedules=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!schedules.length)return {due:false};
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
  const value=n=>parts.find(x=>x.type===n)?.value;
  const [hour,minute]=String(schedules[0].send_time).split(':').map(Number);
  if(Number(value('hour'))*60+Number(value('minute'))<hour*60+minute)return {due:false};
  if(!towerPdfFrequencyDue(schedules[0].frequency,value('year'),value('month'),value('day'),schedules[0].monthly_day))return {due:false};
  const day=[value('year'),value('month'),value('day')].join('-');
  const jobs=await db(env,'tower_telegram_pdf_jobs?user_id=eq.'+encodeURIComponent(userId)+'&report_day=eq.'+day+'&select=status,attempts,lease_until,updated_at');
  const job=jobs[0];
  if(job){
   if(job.status==='SENT'||job.attempts>=5)return {due:false};
   if(['CLAIMED','SENDING'].includes(job.status)&&job.lease_until&&Date.parse(job.lease_until)>Date.now())return {due:false};
   if(job.status==='FAILED'&&Date.parse(job.updated_at||0)+10*60*1000>Date.now())return {due:false};
  }
  return {due:true};
 }
 if(action==='dailyPdfClaim'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)return {claimed:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pref.length)return {claimed:false};
  const cairo=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
  const value=n=>cairo.find(x=>x.type===n)?.value;
  const schedules=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!schedules.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
  const [hour,minute]=String(schedules[0].send_time).split(':').map(Number);
  if(Number(value('hour'))*60+Number(value('minute'))<hour*60+minute)return {claimed:false};
  if(!towerPdfFrequencyDue(schedules[0].frequency,value('year'),value('month'),value('day'),schedules[0].monthly_day))return {claimed:false};
  const day=[value('year'),value('month'),value('day')].join('-');
  const nonce=crypto.randomUUID();
  const claimed=await rpc(env,'tower_telegram_pdf_claim',{p_user_id:userId,p_day:day,p_nonce:nonce});
  return {claimed:claimed===true,day,nonce};
 }
 if(action==='failDailyPdf'){
  // A browser-side render failure must not leave the scheduled job silently CLAIMED.
  // Both RPCs validate the signed-in user, current day and matching nonce.
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  const nonce=String(opts.nonce||''),day=String(opts.day||'');
  if(!/^[a-f0-9-]{36}$/i.test(nonce)||!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('INVALID_OPERATION');
  const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:userId,p_day:day,p_nonce:nonce});
  if(started!==true){const released=await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:userId,p_day:day,p_nonce:nonce});return {updated:released===true};}
  const finished=await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:false});
  return {updated:finished===true};
 }
 if(action==='sendDailyPdf'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)throw Error('FORBIDDEN');
  const nonce=String(opts.nonce||'');const day=String(opts.day||'');
  if(!/^[a-f0-9-]{36}$/i.test(nonce)||!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('INVALID_OPERATION');
  const pdfPref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pdfPref.length)throw Error('FORBIDDEN');
  // One database transaction owns the CLAIMED -> SENDING transition. Never
  // substitute a REST check followed by PATCH: concurrent requests can both send.
  const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:userId,p_day:day,p_nonce:nonce});
  if(started!==true){await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:userId,p_day:day,p_nonce:nonce}).catch(()=>{});throw Error('PDF_START_REJECTED');}
  try{
   const sent=await telegramManualPdf(env,u,item,{...opts,reportId:'COMBINED_OVERVIEW'});
   await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:true});
   return sent;
  }catch(e){await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:false}).catch(()=>{});throw e;}
 }
 if(action==='unlink'){
  await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_links?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});return {success:true};
 }
 if(action==='sendPdf'){
  // Manual, opt-in transfer. Content rendered by the user's browser; the Worker
  // independently authorizes report access and sends only to this user's linked chat.
  return telegramManualPdf(env,u,item,opts);
 }
 if(action==='test'){
  if(!item?.chat_id||!item.enabled)throw Error('TELEGRAM_NOT_LINKED');
  await telegramSend(env,item.chat_id,'✅ Tower App — '+(({ADMIN:'إدارة النظام',UNION:'رئيس الاتحاد',OPERATOR:'الحارس',RESIDENT:'الساكن'})[u.role]||'الحساب')+'\nتم اختبار ربط حسابك بنجاح. لا تتضمن هذه الرسالة أي بيانات مالية.');
  return {success:true};
 }
 throw Error('INVALID_OPERATION');
}
async function telegramWebhook(env,request){
 if(!env.TELEGRAM_WEBHOOK_SECRET||request.headers.get('X-Telegram-Bot-Api-Secret-Token')!==env.TELEGRAM_WEBHOOK_SECRET)return fail('FORBIDDEN',403);
 if(Number(request.headers.get('content-length')||0)>16384)return fail('REQUEST_TOO_LARGE',413);
 let update;
 try{
  const reader=request.body?.getReader();
  if(!reader)return fail('INVALID_JSON');
  const chunks=[];let byteCount=0;
  while(true){
   const {done,value}=await reader.read();
   if(done)break;
   byteCount+=value.byteLength;
   if(byteCount>16384){await reader.cancel().catch(()=>{});return fail('REQUEST_TOO_LARGE',413);}
   chunks.push(value);
  }
  const bytes=new Uint8Array(byteCount);let at=0;
  for(const part of chunks){bytes.set(part,at);at+=part.byteLength;}
  const raw=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  update=JSON.parse(raw);
 }catch(_){return fail('INVALID_JSON');}
 const m=update?.message,chat=m?.chat;
 if(chat?.type!=='private'||typeof m?.text!=='string')return respond({ok:true});
 const match=/^\/start ([0-9a-f]{48})$/.exec(m.text.trim());
 if(!match)return respond({ok:true});
 const hash=await tgHash(match[1]);
 // SQL SECURITY DEFINER function atomically consumes the challenge and binds the private chat.
 const bound=await rpc(env,'tower_telegram_bind',{p_challenge_hash:hash,p_chat_id:String(chat.id)});
 if(bound===true||bound?.success===true)await telegramSend(env,String(chat.id),'✅ تم ربط حساب Tower App. يمكنك التحكم في التنبيهات والخصوصية من إعدادات حسابك.');
 return respond({ok:true});
}

async function readBrandingContext(env){
 try{const [settings,assets]=await Promise.all([db(env,'tower_system_settings?select=settings&singleton=eq.true&limit=1'),db(env,'tower_brand_assets?select=kind,updated_at')]);
  const branding=settings[0]?.settings?.branding||{};
  return {...branding,logoUrl:assets.some(x=>x.kind==='logo')?'/api/brand/logo':null,mainImageUrl:assets.some(x=>x.kind==='main')?'/api/brand/main':null};
 }catch(e){console.warn('BRAND_ASSETS_UNAVAILABLE');return {};}
}
async function serveBrandImage(env,kind){
 try{const rows=await db(env,'tower_brand_assets?select=mime,encoded&kind=eq.'+kind+'&limit=1');if(!rows.length)return new Response('',{status:404,headers:{'cache-control':'no-store'}});
  const x=rows[0],bytes=Uint8Array.from(atob(x.encoded),c=>c.charCodeAt(0));
  return new Response(bytes,{headers:{'content-type':x.mime,'cache-control':'no-cache, max-age=0','x-content-type-options':'nosniff'}});
 }catch(e){return new Response('',{status:404});}
}
async function dispatch(env,p){const method=p.method||p.name;const args=Array.isArray(p.args)?p.args:[];const token=String(p.token||'');
 if(method==='getBootstrapContext'){
  const authToken=String(args[0]||token);const u=await sessionUser(env,authToken);
  const uiPreferences=u?await readUiPreferences(env,authToken):{fontFamily:'Cairo'};
  const branding=await readBrandingContext(env);
  return {version:APP_VERSION,configured:true,building:{name:branding.systemName||'Tower App'},branding,uiPreferences,titles:[],user:u?canonicalUser(u):{authenticated:false}};
 }
 if(method==='loginWithCredentials'){
  const [login,pin]=args;if(!/^[a-z0-9_-]{1,32}$/i.test(String(login||''))||!/^[0-9]{4,8}$/.test(String(pin||'')))throw Error('بيانات الدخول غير صحيحة.');
  const result=await rpc(env,'tower_login',{p_login:String(login).toLowerCase(),p_pin:String(pin)});
  const item=Array.isArray(result)?result[0]:result;if(!item||!item.token)throw Error('بيانات الدخول غير صحيحة.');
  const user=await sessionUser(env,item.token);
  const uiPreferences=await readUiPreferences(env,item.token);
  const branding=await readBrandingContext(env);
  return {token:item.token,context:{version:APP_VERSION,configured:true,building:{name:branding.systemName||'Tower App'},branding,uiPreferences,titles:[],user:canonicalUser(user)}};
 }
 if(['getPublicRegistrationContext','submitRegistrationRequest','activateRegistration','submitPinResetRequest','completePinReset'].includes(method)){
  const actions={getPublicRegistrationContext:'registrationContext',submitRegistrationRequest:'registrationSubmit',activateRegistration:'registrationActivate',submitPinResetRequest:'resetSubmit',completePinReset:'resetComplete'};
  const payload=method==='activateRegistration'||method==='completePinReset'?{loginId:args[0],code:args[1],newPin:args[2]}:method==='submitPinResetRequest'?{loginId:args[0]}:args[0]||{};
  return rpc(env,'tower_onboarding',{p_action:actions[method],p_token:'',p_payload:payload});
 }
 if(method==='logoutCurrentSession'){await rpc(env,'tower_logout',{p_token:String(args[0]||token)});return {success:true};}
 if(method==='apiCall'){const inner=args[0]||{};if(!strictName(inner.name))throw Error('INVALID_OPERATION');const u=await sessionUser(env,inner.token);if(!u)throw Error('SESSION_REQUIRED');
  if(u.must_change_pin&&inner.name!=='changeMyPin')throw Error('PIN_CHANGE_REQUIRED');
  // Explicit allowlist only. Missing workflows must never fall through to unsafe DB CRUD.
  if(inner.name==='telegramSettings')return telegramUserAction(env,{...u,_tg_session_token:inner.token},String(inner.args?.[0]||''),inner.args?.[1]||{});
  if(inner.name==='changeMyPin'){const out=await rpc(env,'tower_change_pin',{p_token:inner.token,p_old:String(inner.args?.[0]||''),p_new:String(inner.args?.[1]||'')});if(out!==true)throw Error('تعذر تغيير PIN');return {success:true};}
  if(inner.name==='getResidentDuesPage'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   const mode=String(payload.mode||'page'),group=String(payload.group||'current'),status=String(payload.status||''),search=String(payload.search||'');
   const offset=Number(payload.offset??0),limit=Number(payload.limit??10);
   if(!['page','summary'].includes(mode)||!['current','archive'].includes(group)||
      !['','OPEN','PARTIAL','OVERDUE','PAID'].includes(status)||search.length>100||
      !Number.isSafeInteger(offset)||offset<0||offset>1000000||!Number.isSafeInteger(limit)||limit<1||limit>20)
     throw Error('INVALID_OPERATION');
   const target=String(payload.unitId||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(target))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_resident_dues_page_for_unit',{p_token:inner.token,p_unit_id:target,p_mode:mode,p_group:group,
    p_search:search,p_status:status,p_offset:offset,p_limit:limit});
  }
  if(['getUnitFundVisibility','setUnitFundVisibility','getResidentBuildingFundSummary'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const unitId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   if(inner.name==='getResidentBuildingFundSummary')
    return rpc(env,'tower_resident_fund_overview_for_unit',{p_token:inner.token,p_unit_id:unitId});
   if(inner.name==='setUnitFundVisibility'&&typeof inner.args?.[1]!=='boolean')throw Error('INVALID_OPERATION');
   return rpc(env,'tower_unit_fund_visibility_action',{
    p_token:inner.token,p_unit_id:unitId,
    p_action:inner.name==='getUnitFundVisibility'?'get':'set',
    p_allow:inner.name==='setUnitFundVisibility'?inner.args[1]:null
   });
  }
  if(['getBuildingFinancialSnapshot','getPdfAutomationSnapshot'].includes(inner.name)){
   if(inner.name==='getBuildingFinancialSnapshot'&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='getPdfAutomationSnapshot'){const plan=await towerPdfDispatchTargets(env);if(!plan.recipients.length)throw Error('PDF_NOT_DUE');}
   const snapshot=await rpc(env,inner.name==='getPdfAutomationSnapshot'?'tower_pdf_automation_snapshot':'tower_building_financial_snapshot',{p_token:inner.token});
   // Add presentation-only unit type labels. Financial values remain from the privileged atomic RPC.
   // This lookup is read-only and can differ from the snapshot if unit metadata changes concurrently.
   const dueRows=snapshot?.buildingDues?.rows;
   const subRows=snapshot?.subscriptions?.rows;
   if(Array.isArray(dueRows)&&Array.isArray(subRows)){
    const unitIds=[...new Set([...dueRows,...subRows].map(r=>String(r?.unitId||'')).filter(Boolean))];
    if(unitIds.length){
     const unitTypes=new Map();
     // Chunk to avoid long PostgREST URLs on large buildings.
     for(let i=0;i<unitIds.length;i+=100){
      const ids=unitIds.slice(i,i+100).map(encodeURIComponent).join(',');
      const units=await db(env,'tower_units?select=unit_id,unit_type_id,tower_unit_types(name)&unit_id=in.('+ids+')');
      for(const unit of units||[])unitTypes.set(String(unit.unit_id),String(unit.tower_unit_types?.name||''));
     }
     for(const row of [...dueRows,...subRows]){
      const name=unitTypes.get(String(row?.unitId||''));
      if(name)row.unitTypeName=name;
     }
    }
   }
   return snapshot;
  }
  if(['getReportCatalog','getReportData'].includes(inner.name)){
   if(u.role==='RESIDENT')throw Error('FORBIDDEN');
   const action=inner.name==='getReportCatalog'?'catalog':'data';
   const payload=action==='catalog'?{}:{reportId:inner.args?.[0]};
   return rpc(env,'tower_report_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['listMyNotifications','markNotificationRead'].includes(inner.name)){
   const action=inner.name==='listMyNotifications'?'list':'read';
   const payload=action==='list'?{limit:inner.args?.[0]}:{notificationId:inner.args?.[0]};
   return rpc(env,'tower_notification_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['getUiPreferences','adminUpdateUiPreferences'].includes(inner.name)){
   if(inner.name==='adminUpdateUiPreferences'&&u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_ui_preferences_action',{p_token:inner.token,p_action:inner.name==='getUiPreferences'?'get':'update',p_payload:inner.name==='getUiPreferences'?{}:(inner.args?.[0]||{})});
  }
  if(inner.name==='getMyCoreProfile'){
   const membership=u.role==='RESIDENT'?await db(env,'tower_members?select=unit_id,member_role,relation&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null&limit=1'):[];
   return {userId:u.user_id,displayName:workerPersonName(u),preferredTitle:u.title,name:u.name,role:u.role,roleLabel:canonicalUser(u).roleLabel,loginId:u.login_id,membership:membership[0]||null};
  }
  if(inner.name==='adminListRegistrationRequests'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const records=await rpc(env,'tower_onboarding',{p_action:'registrationList',p_token:inner.token,p_payload:{}});
   const opinions=await db(env,'tower_registration_requests?select=request_id,manager_opinion,manager_opinion_at,manager_opinion_note,manager_opinion_by');
   const index=new Map(opinions.map(x=>[x.request_id,x]));
   return (Array.isArray(records)?records:[]).map(x=>({...x,managerOpinion:index.get(x.requestId)?.manager_opinion||null,managerOpinionAt:index.get(x.requestId)?.manager_opinion_at||null,managerOpinionNote:index.get(x.requestId)?.manager_opinion_note||'',managerOpinionBy:index.get(x.requestId)?.manager_opinion_by||null}));
  }
  if(['adminListRegistrationRequests','adminApproveRegistrationRequest','adminRejectRegistrationRequest','adminListPinResetRequests','adminIssuePinResetCode'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const actions={adminListRegistrationRequests:'registrationList',adminApproveRegistrationRequest:'registrationApprove',adminRejectRegistrationRequest:'registrationReject',adminListPinResetRequests:'resetList',adminIssuePinResetCode:'resetIssue'};
   const payload=inner.name==='adminRejectRegistrationRequest'?{requestId:inner.args?.[0],notes:inner.args?.[1]}:inner.name.includes('List')?{}:{requestId:inner.args?.[0]};
   return rpc(env,'tower_onboarding',{p_action:actions[inner.name],p_token:inner.token,p_payload:payload});
  }
  if(['createResidentTrip','createGuardTrip','updateMyTrip','updateGuardTrip','updateMyTripDistance','deleteMyTrip','cancelGuardTrip','listTrips'].includes(inner.name)){
   if(inner.name==='listTrips'&&!['RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const action=({createResidentTrip:'create',createGuardTrip:'create',updateMyTrip:'update',updateGuardTrip:'update',updateMyTripDistance:'distance',deleteMyTrip:'cancel',cancelGuardTrip:'cancel',listTrips:'list'})[inner.name];
   if(inner.name==='createResidentTrip'&&u.role!=='RESIDENT'||inner.name==='createGuardTrip'&&u.role!=='OPERATOR'||inner.name==='updateMyTrip'&&u.role!=='RESIDENT'||inner.name==='updateGuardTrip'&&u.role!=='OPERATOR'||inner.name==='updateMyTripDistance'&&u.role!=='RESIDENT'||inner.name==='deleteMyTrip'&&u.role!=='RESIDENT'||inner.name==='cancelGuardTrip'&&u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const payload=inner.name==='updateMyTripDistance'?{tripId:inner.args?.[0],distance:inner.args?.[1]}:
    ['deleteMyTrip','cancelGuardTrip'].includes(inner.name)?{tripId:inner.args?.[0]}:
    inner.name==='listTrips'?{unitId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_trip_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='getOpenTripChangeHistory'){
   if(!['RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const fn=u.role==='OPERATOR'?'tower_guard_open_trip_change_history':'tower_open_trip_change_history';
   return rpc(env,fn,{p_token:inner.token,p_trip_id:inner.args?.[0]});
  }
  if(['getResidentAccountData','addResidentPayment','cancelResidentPayment','closeMyAccount','undoMyLastSettlement','getSettlementDetails'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const actions={getResidentAccountData:'summary',addResidentPayment:'addPayment',cancelResidentPayment:'cancelPayment',closeMyAccount:'close',undoMyLastSettlement:'undo',getSettlementDetails:'details'};
   const payload=inner.name==='addResidentPayment'?{amount:inner.args?.[0],reference:inner.args?.[1]}:
    inner.name==='cancelResidentPayment'?{paymentId:inner.args?.[0],reason:inner.args?.[1]}:
    inner.name==='undoMyLastSettlement'?{reason:inner.args?.[0],expectedSettlementId:typeof inner.args?.[1]==='string'?inner.args[1]:null}:
    inner.name==='getSettlementDetails'?{settlementId:inner.args?.[0]}:{};
   const unitId=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_trip_account',{p_token:inner.token,p_action:actions[inner.name],p_payload:{...payload,unitId}});
  }
  if(['addPaymentAttachment','getPaymentAttachments','readPaymentAttachment'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action={addPaymentAttachment:'add',getPaymentAttachments:'list',readPaymentAttachment:'read'}[inner.name];
   const payload=action==='add'?{paymentId:inner.args?.[0],...(inner.args?.[1]||{})}:
     action==='list'?{paymentId:inner.args?.[0]}:{attachmentId:inner.args?.[0]};
   if(action==='add'&&JSON.stringify(payload).length>1500000)throw Error('ATTACHMENT_TOO_LARGE');
   return rpc(env,'tower_payment_attachment_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='setCollectionCategoryStatus'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const categoryId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,36}$/i.test(categoryId))throw Error('INVALID_CATEGORY_ID');
   const status=String(inner.args?.[1]||'').toUpperCase()==='INACTIVE'?'INACTIVE':'ACTIVE';
   return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:'categoryStatus',p_payload:{categoryId,status}});
  }
  if(inner.name==='getFinancialAudit'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const n=Number(inner.args?.[0]);
   const limit=Number.isFinite(n)&&n>0?Math.max(10,Math.min(300,Math.trunc(n))):150;
   // Matches the legacy finance audit filters without exposing unrelated audit records.
   const financialActions=['CREATE_BUILDING_CHARGE','RECORD_BUILDING_PAYMENT','CREATE_FINANCE_ENTRY','CANCEL_FINANCE_ENTRY','APPROVE_COLLECTION_REPORT','ADD_PAYMENT_ATTACHMENT'];
   const filters='or=('+financialActions.map(a=>'action.eq.'+a).join(',')+',entity.like.BUILDING_*,entity.like.FINANCE_*,entity.like.COLLECTION_*,entity.like.SERVICE_*)';
   const rows=await db(env,'tower_audit?select=audit_id,actor_id,action,entity,entity_id,at&'+filters+'&order=at.desc&limit='+limit);
   return rows.map(a=>({auditId:a.audit_id,timestamp:a.at,actorUserId:a.actor_id||'',role:'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',unitId:'',before:'',after:'',notes:''}));
  }
  if(['saveCollectionCategory','deactivateCollectionCategory','reactivateCollectionCategory','recordBuildingPayment','getUnitBuildingStatement'].includes(inner.name)){
   if(inner.name==='getUnitBuildingStatement'){
    if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
    if(u.role==='RESIDENT'){const visibility=await rpc(env,'tower_unit_fund_visibility_action',{p_token:inner.token,p_unit_id:inner.args?.[0],p_action:'get',p_allow:null});if(visibility?.canViewAccount!==true){const error=new Error(DB_USER_ERRORS.UNIT_ACCOUNT_ACCESS_DENIED);error.dbCode='UNIT_ACCOUNT_ACCESS_DENIED';throw error;}}
    return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:'statement',p_payload:{unitId:inner.args?.[0]}});
   }
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=inner.name==='saveCollectionCategory'?'saveCategory':inner.name==='recordBuildingPayment'?'recordPayment':'categoryStatus';
   const payload=action==='categoryStatus'?{categoryId:inner.args?.[0],status:inner.name==='deactivateCollectionCategory'?'INACTIVE':'ACTIVE'}:(inner.args?.[0]||{});
   return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['cancelMyServiceSubscription','updatePendingServiceSubscription','requestServiceChange','listServiceChangeRequests','reviewServiceChangeRequest'].includes(inner.name)){
   const action={cancelMyServiceSubscription:'cancelPending',updatePendingServiceSubscription:'updatePending',requestServiceChange:'requestChange',listServiceChangeRequests:'list',reviewServiceChangeRequest:'review'}[inner.name];
   if(['cancelPending','updatePending','requestChange'].includes(action)&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(u.role==='RESIDENT'&&['cancelPending','updatePending','requestChange'].includes(action)){const chosen=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(chosen))throw Error('UNIT_REQUIRED');}
   if(['list','review'].includes(action)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=action==='cancelPending'?{subscriptionId:inner.args?.[0]}:action==='updatePending'?{subscriptionId:inner.args?.[0],quantity:inner.args?.[1]}:
    action==='requestChange'?{subscriptionId:inner.args?.[0],type:inner.args?.[1],quantity:inner.args?.[2]}:
    action==='review'?{requestId:inner.args?.[0],decision:inner.args?.[1],notes:inner.args?.[2]}:{};
   if(u.role==='RESIDENT'&&['cancelPending','updatePending','requestChange'].includes(action))payload.unitId=String(inner.args?.at(-1)?.__activeUnitId||'');
   return rpc(env,'tower_service_change_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='adminArchiveResident'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const residentId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(residentId))throw Error('INVALID_RESIDENT_ID');
   return rpc(env,'tower_admin_archive_resident',{p_token:inner.token,p_user_id:residentId});
  }
  if(inner.name==='addServiceSubscribers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||!Array.isArray(payload.unitIds)||payload.unitIds.length<1||payload.unitIds.length>500)throw Error('INVALID_UNIT_IDS');
   if(payload.agreementSource)return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:'enroll',p_service:payload.serviceId,p_payload:{unitIds:payload.unitIds,source:payload.agreementSource,note:payload.agreementNote||''}});
   return rpc(env,'tower_add_service_subscribers',{p_token:inner.token,p_payload:{serviceId:payload.serviceId,unitIds:payload.unitIds,quantity:payload.quantity}});
  }
  if(inner.name==='getServiceWorkspace'){
   const admin=['ADMIN','UNION'].includes(u.role),resident=u.role==='RESIDENT';
   if(!admin&&!resident)throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||''),unit=resident?String(inner.args?.at(-1)?.__activeUnitId||''):null;
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(resident&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unit))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_service_workspace_read_232',{p_token:inner.token,p_service:serviceId,p_unit:unit});
  }
  if(inner.name==='getServiceManagerContext'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   // Use the same authorized service read model as listServices. The old partial
   // table projection silently dropped task classification and finance metadata.
   const services=await rpc(env,'tower_service_finance_action',{p_token:inner.token,p_action:'list',p_payload:{}});
   if(!Array.isArray(services))throw Error('INVALID_SERVICE_CONTEXT');
   const service=services.find(row=>String(row.serviceId)===serviceId);
   if(!service)throw Error('SERVICE_NOT_FOUND');
   const [unitRows,memberships,subRows]=await Promise.all([
    db(env,'tower_units?select=unit_id,unit_number,floor&order=unit_number.asc'),
    db(env,'tower_members?select=unit_id,member_role,tower_users(name,title)&ended_at=is.null'),
    db(env,'tower_service_subscriptions?select=subscription_id,service_id,unit_id,requested_by,status,quantity,unit_price_snapshot,amount_snapshot,billing_timing,auto_renew,requested_at,reviewed_at,started_at,ended_at,next_renewal_at&service_id=eq.'+encodeURIComponent(serviceId)+'&order=requested_at.desc')
   ]);
   if(!Array.isArray(unitRows)||!Array.isArray(memberships)||!Array.isArray(subRows))throw Error('INVALID_SERVICE_CONTEXT');
   const perUnit=new Map();
   for(const m of memberships){
    const entry=perUnit.get(String(m.unit_id))||{managerName:'',memberNames:[]};
    const name=workerPersonName(m.tower_users);
    if(name){entry.memberNames.push(name);if(m.member_role==='MANAGER')entry.managerName=name;}
    perUnit.set(String(m.unit_id),entry);
   }
   const units=unitRows.map(x=>({unitId:x.unit_id,unitNumber:x.unit_number,floor:x.floor||'',managerName:perUnit.get(String(x.unit_id))?.managerName||'',memberNames:perUnit.get(String(x.unit_id))?.memberNames||[]}));
   const unitMap=new Map(units.map(x=>[String(x.unitId),x]));
   const subscriptions=subRows.map(x=>({subscriptionId:x.subscription_id,serviceId:x.service_id,unitId:x.unit_id,requestedByUserId:x.requested_by,status:x.status,quantity:x.quantity,unitPriceSnapshot:Number(x.unit_price_snapshot),amountSnapshot:Number(x.amount_snapshot),billingTiming:x.billing_timing,autoRenew:x.auto_renew,requestedAt:x.requested_at,reviewedAt:x.reviewed_at,startedAt:x.started_at,endedAt:x.ended_at,nextRenewalAt:x.next_renewal_at,unitNumber:unitMap.get(String(x.unit_id))?.unitNumber||'—',floor:unitMap.get(String(x.unit_id))?.floor||'',managerName:unitMap.get(String(x.unit_id))?.managerName||''}));
   await enrichTaskProjects(env,[service]);
   return {service,units,subscriptions};
  }
  if(inner.name==='listServiceBeneficiaries'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const rows=await db(env,'tower_users?select=user_id,name,title,custom_title,role&status=eq.ACTIVE&order=name.asc&limit=300');
   return (rows||[]).map(x=>({userId:x.user_id,name:x.name,title:x.title,customTitle:x.custom_title,displayName:workerPersonName(x),role:x.role}));
  }
  if(['listServices','getMyServices','saveService','setServiceStatus','requestServiceSubscription','listServiceSubscriptionRequests','reviewServiceSubscription'].includes(inner.name)){
   const action=({listServices:'list',getMyServices:'mine',saveService:'save',setServiceStatus:'status',requestServiceSubscription:'request',listServiceSubscriptionRequests:'requests',reviewServiceSubscription:'review'})[inner.name];
   if(['save','status','requests','review'].includes(action)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(['mine','request'].includes(action)&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(action==='mine'){
    const unitId=String(inner.args?.[0]?.__activeUnitId||'');
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
    const result=await rpc(env,'tower_unit_services_read_for_unit',{p_token:inner.token,p_unit_id:unitId});
   const visibility=await rpc(env,'tower_unit_fund_visibility_action',{p_token:inner.token,p_unit_id:unitId,p_action:'get',p_allow:null});
   const accountVisible=visibility?.canViewAccount===true;result.unitAccountVisible=accountVisible;

   // Public ACTIVE services only; financial allocation amounts remain server-authoritative.
   if(Array.isArray(result?.services)&&result.services.length){
    const ids=result.services.map(x=>String(x.serviceId||'')).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
    for(let z=0;z<ids.length;z+=80){
     const rows=await db(env,'tower_services?select=service_id,service_kind,pricing_mode,total_budget,enrollment_status&status=eq.ACTIVE&service_id=in.('+ids.slice(z,z+80).map(encodeURIComponent).join(',')+')');
     const byId=new Map((rows||[]).map(x=>[String(x.service_id),x]));
     for(const svc of result.services){const row=byId.get(String(svc.serviceId));if(!row)continue;svc.serviceKind=row.service_kind;svc.pricingMode=row.pricing_mode;svc.totalBudget=row.total_budget;svc.enrollmentStatus=row.enrollment_status;}
    }
   }
   // Snapshot scope is enforced by SQL membership. Enrich only identities tied to subscriptions in that snapshot.
   const subscriptions=Array.isArray(result?.subscriptions)?result.subscriptions:[];
   const subIds=[...new Set(subscriptions.map(x=>String(x.subscriptionId||'')).filter(x=>/^[0-9a-f-]{36}$/i.test(x)))];
   if(subIds.length){
    const byId=new Map();
    for(let i=0;i<subIds.length;i+=80){
     const chunk=subIds.slice(i,i+80);
     const rows=await db(env,'tower_service_subscriptions?select=subscription_id,unit_id,requested_by&unit_id=eq.'+encodeURIComponent(unitId)+'&subscription_id=in.('+chunk.map(encodeURIComponent).join(',')+')');
     for(const row of rows||[])if(String(row.unit_id)===unitId)byId.set(String(row.subscription_id),String(row.requested_by||''));
    }
    const userIds=[...new Set([...byId.values()].filter(x=>/^[0-9a-f-]{36}$/i.test(x)))];
    const users=new Map();
    for(let i=0;i<userIds.length;i+=80){
     const rows=await db(env,'tower_users?select=user_id,name,title,role&user_id=in.('+userIds.slice(i,i+80).map(encodeURIComponent).join(',')+')');
     for(const x of rows||[])users.set(String(x.user_id),x);
    }
    for(const sub of subscriptions){
     const id=byId.get(String(sub.subscriptionId));const person=users.get(id);
     if(person){sub.requestedByName=[person.title,person.name].filter(Boolean).join(' ');sub.requestedByRole=person.role==='RESIDENT'?'ساكن':person.role==='ADMIN'?'إدارة النظام':person.role==='UNION'?'الاتحاد':person.role==='OPERATOR'?'حارس':'';}
    }
   }
   await enrichTaskProjects(env,result.services,unitId);
   for(const svc of result.services||[]){if(!accountVisible||svc.pricingMode!=='SHARED_TOTAL')continue;try{const detail=await rpc(env,'tower_task_project_read_230',{p_token:inner.token,p_service:svc.serviceId,p_unit:unitId});svc.totalBudget=detail.totalBudget;svc.activeSubscriberCount=detail.activeCount;svc.responsibleName=detail.responsibleName;if(svc.project)svc.project.ownEstimatedShare=detail.estimatedShare;const own=(detail.project?.agreed_amounts||[])[0];if(own&&svc.project)svc.project.ownAgreedAmount=own.amount;}catch(_){svc.taskProjectUnavailable=true;}}

   for(const svc of result.services||[]){svc.unitAccountVisible=accountVisible;if(!accountVisible){delete svc.unitTaskFinance;if(svc.project){delete svc.project.ownEstimatedShare;delete svc.project.ownAgreedAmount;}}}
   if(!accountVisible){for(const sub of result.subscriptions||[]){delete sub.amountSnapshot;delete sub.unitPriceSnapshot;delete sub.balance;}return result;}
   // Read balances only after the existing unit-scoped RPC authorizes membership.
   const tasks=(result.services||[]).filter(s=>s.serviceKind==='ONE_TIME'&&s.pricingMode==='SHARED_TOTAL'&&s.enrollmentStatus==='FINALIZED');
   if(tasks.length){
    for(const task of tasks)task.unitTaskFinance={state:'UNAVAILABLE'};
    try{
     const ledger=await rpc(env,'tower_unit_task_balances_read_for_unit',{p_token:inner.token,p_unit_id:unitId});
     if(ledger?.unitId!==unitId||ledger.scope!=='UNIT_TASK_DUES'||ledger.readOnly!==true||!Array.isArray(ledger.rows))throw Error('INVALID_UNIT_TASK_LEDGER');
     const balances=new Map();
     for(const row of ledger.rows){
      const cents=value=>{if(value===null||value===''||typeof value==='boolean')throw Error('INVALID_TASK_AMOUNT');const n=Number(value),c=Math.round(n*100);if(!Number.isFinite(n)||!Number.isSafeInteger(c)||Math.abs(n*100-c)>0.001)throw Error('INVALID_TASK_AMOUNT');return c;};
      const due=cents(row.due),paid=cents(row.paid),remaining=cents(row.remaining),credit=cents(row.credit??0),refunded=cents(row.refunded??0);
      if(!/^[0-9a-f-]{36}$/i.test(String(row.serviceId))||balances.has(row.serviceId)||due<0||paid<0||remaining<0||credit<0||refunded<0||due-paid!==remaining-credit||!Number.isSafeInteger(Number(row.dueCount))||(Number(row.dueCount)<0||(Number(row.dueCount)===0&&(due!==0||paid!==0))))throw Error('INVALID_UNIT_TASK_LEDGER');
      balances.set(row.serviceId,{state:'RECORDED',due:due/100,paid:paid/100,remaining:remaining/100,...(credit?{credit:credit/100}:{}),...(refunded?{refunded:refunded/100}:{})});
     }
     for(const task of tasks)task.unitTaskFinance=balances.get(task.serviceId)||{state:'NOT_RECORDED'};
    }catch(e){console.warn('UNIT_TASK_BALANCES_UNAVAILABLE');}
   }
   return result;
   }
   if(u.role==='RESIDENT'&&action==='request'&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(inner.args?.at(-1)?.__activeUnitId||'')))throw Error('UNIT_REQUIRED');
   const payload=action==='request'?{serviceId:inner.args?.[0],quantity:inner.args?.[2]}:
    action==='status'?{serviceId:inner.args?.[0],status:inner.args?.[1]}:
    action==='review'?{subscriptionId:inner.args?.[0],decision:inner.args?.[1],notes:inner.args?.[2]}:
    action==='save'?(inner.args?.[0]||{}):{};
   if(u.role==='RESIDENT'&&action==='request')payload.unitId=String(inner.args?.at(-1)?.__activeUnitId||'');
   if(action==='requests')return rpc(env,'tower_service_requests_230',{p_token:inner.token});
   const output=await rpc(env,(['save','list'].includes(action)?'tower_service_finance_action':'tower_services_action'),{p_token:inner.token,p_action:action,p_payload:payload});
   if(action==='list'&&Array.isArray(output)){await enrichTaskProjects(env,output);for(const svc of output){if(!svc.project)continue;try{const detail=await rpc(env,'tower_service_edit_context_230',{p_token:inner.token,p_service:svc.serviceId});svc.totalBudget=detail.totalBudget;}catch(_){svc.taskProjectUnavailable=true;}}}
   return output;
  }
  if(['getServiceEditContext','editManagedService','previewManagedServiceEdit','getPersonalCollectionDues','collectPersonalDue'].includes(inner.name)){
   const edit=['getServiceEditContext','editManagedService','previewManagedServiceEdit'].includes(inner.name);
   if(edit&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(!edit&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='getServiceEditContext')return rpc(env,'tower_service_edit_context_230',{p_token:inner.token,p_service:inner.args[0]});
   if(inner.name==='previewManagedServiceEdit')return rpc(env,'tower_service_edit_preview_230',{p_token:inner.token,p_payload:inner.args[0]});
   if(inner.name==='editManagedService')return rpc(env,'tower_service_edit_230',{p_token:inner.token,p_payload:inner.args[0]});
   return rpc(env,'tower_personal_collections_230',{p_token:inner.token,p_action:inner.name==='collectPersonalDue'?'collect':'read',p_payload:inner.args?.[0]||{}});
  }
  if(['getTaskProject','createTaskProject','taskProjectAction'].includes(inner.name)){
   const admin=['ADMIN','UNION'].includes(u.role),resident=u.role==='RESIDENT';
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const create=inner.name==='createTaskProject',read=inner.name==='getTaskProject';
   if(create&&!admin)throw Error('FORBIDDEN');
   const id=create?null:String(inner.args?.[0]||'');
   if(!create&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(id))throw Error('INVALID_SERVICE_ID');
   const scope=String(inner.args?.at(-1)?.__activeUnitId||'');
   if(resident&&!read&&['interest','confirm_refund','confirm_donation_return'].includes(String(inner.args?.[1]||''))&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(scope))throw Error('UNIT_REQUIRED');
   if(read)return rpc(env,'tower_task_workspace_read_231',{p_token:inner.token,p_service:id,p_unit:resident?(scope||null):null});
   const action=create?'create':String(inner.args?.[1]||'');
   const allowed=['close_finalize','create','interest','terms','publish','cancel','agreement','enroll','preview','finalize','expense_draft','expense_approve','expense_pay','expense_cancel','adjustment_cancel','donation','collect','confirm_refund','confirm_donation_return','donation_return','cancel_donation_return','cancel_refund','revoke_refund','adjustment_draft','adjustment_approve','refund_authorize','refund_request','close_financial','cancel_settled'];
   if(!allowed.includes(action)||(!admin&&!['interest','confirm_refund','confirm_donation_return','preview','expense_draft','expense_cancel','expense_pay','adjustment_draft','adjustment_cancel','collect'].includes(action)))throw Error('FORBIDDEN');
   if(['donation','donation_return','cancel_donation_return','refund_authorize','refund_request','cancel_refund','revoke_refund','cancel_settled'].includes(action)&&!admin)throw Error('UNION_ONLY');
   const payload=create?{...(inner.args?.[0]||{})}:{...(inner.args?.[2]||{})};
   if(resident&&['interest','confirm_refund','confirm_donation_return'].includes(action))payload.unitId=scope;
   if(create)return rpc(env,'tower_task_create_239',{p_token:inner.token,p_payload:payload});
   return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:action,p_service:id,p_payload:payload});
  }
  if(['listTaskNotices','markTaskNoticeRead'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const isRead=inner.name==='markTaskNoticeRead';
   const id=isRead?String(inner.args?.[0]||''):null;
   if(isRead&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(id))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_notice_action',{p_token:inner.token,p_action:isRead?'read':'list',p_service_id:id});
  }
  if(['listManagedTasks','taskManagementAction','getTaskManagementRequests','saveTaskSchedule'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='saveTaskSchedule'){
    if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
    if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(inner.args?.[0]||'')))throw Error('INVALID_SERVICE_ID');
    return rpc(env,'tower_task_schedule_save_236',{p_token:inner.token,p_service:inner.args?.[0],p_payload:inner.args?.[1]||{}});
   }
   const assigned=inner.name==='listManagedTasks',action=assigned?'assigned':inner.name==='getTaskManagementRequests'?'requests':String(inner.args?.[1]||'');
   if(!['assigned','requests','request','review_request','member_enroll','member_review','member_remove'].includes(action))throw Error('INVALID_ACTION');
   return rpc(env,'tower_task_management_236',{p_token:inner.token,p_action:action,p_service:assigned?null:inner.args?.[0],p_payload:inner.name==='taskManagementAction'?(inner.args?.[2]||{}):{}});
  }
  if(['getTaskControls','saveTaskControls','getTaskInstallmentSetup'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_controls_235',{p_token:inner.token,p_service:serviceId,p_action:({getTaskControls:'read',saveTaskControls:'save',getTaskInstallmentSetup:'preview'})[inner.name],p_payload:inner.name==='saveTaskControls'?(inner.args?.[1]||{}):{}});
  }
  if(['listTaskInstallments','installTaskInstallments'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const install=inner.name==='installTaskInstallments';
   if(install&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(!install){const unit=u.role==='RESIDENT'?String(inner.args?.at(-1)?.__activeUnitId||''):null;if(u.role==='RESIDENT'&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unit))throw Error('UNIT_REQUIRED');return rpc(env,'tower_task_workspace_installments_231',{p_token:inner.token,p_service:serviceId,p_unit:unit});}
   return rpc(env,'tower_task_controls_235',{p_token:inner.token,p_service:serviceId,p_action:'install',p_payload:inner.args?.[1]||{}});
  }
  if(inner.name==='postTaskFundContribution'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_fund_contribute_216',{p_token:inner.token,p_service_id:serviceId});
  }
  if(['confirmTaskFundReceipt','getTaskFundReceiptStatus'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_fund_receipt_action_217',{p_token:inner.token,p_service_id:serviceId,p_action:inner.name==='confirmTaskFundReceipt'?'confirm':'status'});
  }
  if(['listTaskWorkflows','saveTaskWorkflow'].includes(inner.name)){
   const isSave=inner.name==='saveTaskWorkflow';
   if(isSave&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_task_workflow_action',{p_token:inner.token,p_action:isSave?'save':'list',p_payload:isSave?(inner.args?.[0]||{}):{}});
  }
  if(['previewSharedServiceAllocation','finalizeSharedServiceAllocation','closeSharedServiceEnrollment'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(['finalizeSharedServiceAllocation','previewSharedServiceAllocation'].includes(inner.name)){
    const projects=await db(env,'tower_task_projects?select=service_id&service_id=eq.'+encodeURIComponent(serviceId));
    if(projects?.length)return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:inner.name==='previewSharedServiceAllocation'?'preview':'finalize',p_service:serviceId,p_payload:{}});
   }
   if(inner.name==='closeSharedServiceEnrollment')return rpc(env,'tower_service_shared_enrollment_close',{p_token:inner.token,p_service_id:serviceId});
   return rpc(env,'tower_service_shared_allocation_action',{p_token:inner.token,p_action:inner.name==='previewSharedServiceAllocation'?'preview':'finalize',p_service_id:serviceId});
  }
  if(['reopenSharedServiceEnrollment','removeSharedServiceSubscriber'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   const subscriptionId=inner.name==='removeSharedServiceSubscriber'?String(inner.args?.[1]||''):null;
   const validId=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
   if(!validId.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(subscriptionId&&!validId.test(subscriptionId))throw Error('INVALID_SUBSCRIPTION_ID');
   return rpc(env,'tower_shared_subscriber_admin_action',{p_token:inner.token,p_action:inner.name==='reopenSharedServiceEnrollment'?'reopen':'remove',p_service_id:serviceId,p_subscription_id:subscriptionId});
  }
  if(inner.name==='generateServiceDues'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_generate_service_dues',{p_token:inner.token,p_as_of:null});
  }
  // V2.5.96 staged personal-service finance integration. Fail closed until a
  // reviewed token-bound database API is installed and tested. Never call the
  // draft *_internal functions with user identifiers supplied by clients.
  if(inner.name==='getPersonalFinanceIntegrationStatus'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   // Read-only API can be tested independently; never infer write readiness.
   try {
    const overview=await rpc(env,'tower_finance_personal_overview',{p_token:inner.token});
    if(!overview||overview.readOnly!==true||overview.scope!=='PERSONAL_SERVICE')throw Error('PERSONAL_FINANCE_INVALID_OVERVIEW');
    const receiptTestEnabled=['ADMIN','UNION'].includes(u.role)&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'
     &&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'
     &&String(env.PERSONAL_FINANCE_RECEIPT_TEST_ENABLED||'')==='true';
    return {available:true,mode:'READ_ONLY_TEST',canRead:true,canMutate:false,canPostPersonalReceipt:receiptTestEnabled,canPostMixedCollection:u.role==='UNION'&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'&&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'&&String(env.PERSONAL_FINANCE_MIXED_COLLECTION_TEST_ENABLED||'')==='true',canRequestPersonalHandover:['ADMIN','UNION'].includes(u.role)&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'&&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'&&String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')==='true',
     components:{schema:'TEST_DEPLOYED',trustedApi:'SESSION_BOUND_READ',worker:'READ_ONLY',ui:'READ_ONLY',postgresTests:'NOT_VERIFIED'},
     message:'كشف الخدمات الشخصية متاح للقراءة فقط؛ المعاملات المالية غير مفعّلة.'};
   } catch(error) {
    // Do not swallow an actual credential error, only absence of the optional API.
    const code=String(error?.message||error||'');
    if(/SESSION_REQUIRED|FORBIDDEN|INVALID_TOKEN/.test(code))throw error;
    return {available:false,mode:'NOT_DEPLOYED',canRead:false,canMutate:false,
     components:{schema:'DRAFT',trustedApi:'NOT_READY',worker:'GUARDED',ui:'READ_ONLY',postgresTests:'NOT_RUN'},
     message:'الحسابات الشخصية للخدمات قيد التجهيز ولم تُفعّل على قاعدة البيانات.'};
   }
  }
  if(inner.name==='getPersonalFinanceLedger'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const overview=await rpc(env,'tower_finance_personal_overview',{p_token:inner.token});
   if(overview?.scope!=='PERSONAL_SERVICE'||overview?.readOnly!==true||!Array.isArray(overview.accounts))throw Error('PERSONAL_FINANCE_INVALID_OVERVIEW');
   return overview;
  }
  // Read-only, session-bound pending handovers: the database filters rows to the
  // actual sender or recipient. No user/account selection supplied by client.
  if(inner.name==='listMyPersonalPendingHandovers'){
   if(!['ADMIN','UNION','OPERATOR','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   if(String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()!=='staging'
      ||String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')!=='ISOLATED_TEST_DATABASE'
      ||String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   return rpc(env,'tower_finance_my_pending_handovers',{p_token:inner.token});
  }
  // Staging read API for pending UNIT_REFUND movements. PostgreSQL enforces
  // designated recipient + sole current unit manager; never accept unitId.
  if(inner.name==='listMyPendingPersonalRefunds'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()!=='staging'
      ||String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')!=='ISOLATED_TEST_DATABASE'
      ||String(env.PERSONAL_FINANCE_REFUND_RESOLUTION_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   return rpc(env,'tower_finance_my_pending_refunds',{p_token:inner.token});
  }
  // A single finance feature flag is NEVER enough to enable money movement.
  // Require an explicit isolated staging deployment declaration as well.
  const financeStaging=String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'
    && String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE';
  // Stage 1 trusted handover RPC: explicitly opt-in ONLY on isolated test deployments.
  // Both Worker and database check roles; session identity is resolved in PostgreSQL.
  if(['requestPersonalCashHandover','confirmPersonalCashHandover','cancelPersonalCashHandover'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')==='true'){
   const action={requestPersonalCashHandover:'request',confirmPersonalCashHandover:'confirm',cancelPersonalCashHandover:'cancel'}[inner.name];
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
   if(action==='request'&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   // Strict staging request contract; the database remains the authority for balances,
   // identity, account ownership and concurrent movement locks.
   const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
   if(action==='request'){
    if(Object.keys(payload).some(k=>!['accountId','recipientId','amount','kind'].includes(k))
      ||!uuid.test(payload.accountId||'')||!uuid.test(payload.recipientId||'')
      ||typeof payload.amount!=='string'||!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(payload.amount)
      ||Number(payload.amount)<=0||!Number.isFinite(Number(payload.amount))
      ||!['BENEFICIARY_DELIVERY','BENEFICIARY_HANDOVER'].includes(payload.kind))throw Error('INVALID_HANDOVER_FIELDS');
   }else{
    if(Object.keys(payload).some(k=>k!=='movementId')||!uuid.test(payload.movementId||''))throw Error('INVALID_MOVEMENT_ID');
   }
   return rpc(env,'tower_finance_handover_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  // Session-bound personal receipt posting, test deployment only. NEVER enabled by default.
  if(inner.name==='postPersonalServiceReceipt'
      && financeStaging && String(env.PERSONAL_FINANCE_RECEIPT_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
   if(Object.keys(payload).some(k=>!['unitId','amount','portions','externalReference'].includes(k)))throw Error('INVALID_RECEIPT_FIELDS');
   // Reject malformed money instructions BEFORE the database RPC. PostgreSQL
   // remains authoritative for account ownership, concurrency and ledger writes.
   const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
   const cents=v=>{
    if(typeof v!=='string'||!/^\d+(?:\.\d{1,2})?$/.test(v))return null;
    const parts=v.split('.');const n=Number(parts[0])*100+Number((parts[1]||'').padEnd(2,'0'));
    return Number.isSafeInteger(n)&&n>0?n:null;
   };
   if(typeof payload.unitId!=='string'||!uuid.test(payload.unitId))throw Error('INVALID_RECEIPT_FIELDS');
   const total=cents(payload.amount);
   if(total===null||!Array.isArray(payload.portions)||!payload.portions.length||payload.portions.length>100)
    throw Error('INVALID_RECEIPT_FIELDS');
   const ids=new Set();let allocated=0;
   for(const portion of payload.portions){
    if(!portion||typeof portion!=='object'||Array.isArray(portion)||
       Object.keys(portion).some(k=>!['account_id','amount'].includes(k))||
       !uuid.test(String(portion.account_id||'')))throw Error('INVALID_PORTION');
    const amount=cents(portion.amount);
    if(amount===null)throw Error('INVALID_PORTION');
    const id=portion.account_id.toLowerCase();
    if(ids.has(id))throw Error('DUPLICATE_ACCOUNT');
    ids.add(id);allocated+=amount;
    if(!Number.isSafeInteger(allocated))throw Error('INVALID_RECEIPT_AMOUNT');
   }
   if(allocated!==total)throw Error('RECEIPT_SUM_MISMATCH');
   if(typeof payload.externalReference!=='string'||payload.externalReference.trim().length<16||payload.externalReference.trim().length>128)
    throw Error('RECEIPT_REFERENCE_REQUIRED');
   return rpc(env,'tower_finance_personal_receipt_action',{p_token:inner.token,p_payload:payload});
  }
  // Staging-only UNION approval. Never enabled for production by default.
  if(['listPersonalRefundApprovals','approvePersonalUnitRefund'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_APPROVAL_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='listPersonalRefundApprovals')
    return rpc(env,'tower_finance_refund_approval_action',{p_token:inner.token,p_action:'list',p_payload:{}});
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(payload.subscriptionId||''))
      ||!/^\d+(\.\d{1,2})?$/.test(String(payload.amount||''))
      ||!/^\d{4}-\d{2}-\d{2}$/.test(String(payload.effectiveDate||'')))throw Error('INVALID_APPROVAL_FIELDS');
   return rpc(env,'tower_finance_refund_approval_action',{p_token:inner.token,p_action:'approve',
    p_payload:{subscriptionId:payload.subscriptionId,amount:String(payload.amount),effectiveDate:payload.effectiveDate}});
  }
  // STAGING ONLY: exact advance-attributed refund request. Authorization is not minted here.
  if(inner.name==='requestPersonalUnitRefund'
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_REQUEST_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||typeof payload.authorizationId!=='string'
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(payload.authorizationId)
      ||!/^([0-9]+)(\.[0-9]{1,2})?$/.test(String(payload.amount??'')))throw Error('INVALID_REFUND_FIELDS');
   return rpc(env,'tower_finance_request_unit_refund_action',{p_token:inner.token,p_payload:{authorizationId:payload.authorizationId,amount:String(payload.amount)}});
  }
  // Staging-only refund resolution. Creation/approval remain blocked until exact
  // unused subscription prepayment and UNION-approved eligibility are proven.
  if(['confirmPersonalUnitRefund','cancelPersonalUnitRefund'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_RESOLUTION_TEST_ENABLED||'')==='true'){
   const action=inner.name==='confirmPersonalUnitRefund'?'confirm':'cancel';
   if(action==='confirm'&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(action==='cancel'&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||typeof payload.movementId!=='string'
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(payload.movementId))throw Error('INVALID_MOVEMENT_ID');
   return rpc(env,'tower_finance_refund_action',{p_token:inner.token,p_action:action,p_payload:{movementId:payload.movementId}});
  }
  if(['listPersonalRefundApprovals','approvePersonalUnitRefund',
      'postPersonalServiceReceipt',
      'requestPersonalCashHandover','confirmPersonalCashHandover',
      'cancelPersonalCashHandover','requestPersonalUnitRefund',
      'confirmPersonalUnitRefund','cancelPersonalUnitRefund'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
  }
  if(inner.name==='getFundPage'){if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');return rpc(env,'tower_fund_page_239',{p_token:inner.token,p_payload:inner.args?.[0]||{}});}
  if(inner.name==='getFinanceContext'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_finance_context',{p_token:inner.token});
  }
  if(inner.name==='listCollectionCategories'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_collection_categories_list',{p_token:inner.token,p_include_inactive:inner.args?.[0]===true});
  }
  if(['previewBuildingCharge','createBuildingCharge','listBuildingCharges'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action={previewBuildingCharge:'preview',createBuildingCharge:'create',listBuildingCharges:'list'}[inner.name];
   return rpc(env,'tower_charges_action',{p_token:inner.token,p_action:action,p_payload:inner.args?.[0]||{}});
  }
  if(['getFinanceDashboard','addFinanceEntry','cancelFinanceEntry'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=inner.name==='getFinanceDashboard'?'dashboard':inner.name==='addFinanceEntry'?'entry':'cancel';
   const payload=action==='entry'?(inner.args?.[0]||{}):action==='cancel'?{entryId:inner.args?.[0],reason:inner.args?.[1]}:{};
   return rpc(env,'tower_finance_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  // Atomic mixed collection: no client-side two-RPC fallback and no production enablement.
  if(inner.name==='createAndApproveMixedCollection'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   if(!financeStaging||String(env.PERSONAL_FINANCE_MIXED_COLLECTION_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
    ||Object.keys(payload).sort().join(',')!=='externalReference,fund,personal'
    ||typeof payload.externalReference!=='string'||payload.externalReference.trim().length<16
    ||payload.externalReference.trim().length>128
    ||!payload.fund||typeof payload.fund!=='object'||Array.isArray(payload.fund)
    ||Object.keys(payload.fund).some(k=>!['lines','notes'].includes(k))
    ||!Array.isArray(payload.fund.lines)||!payload.fund.lines.length||payload.fund.lines.length>100
    ||payload.fund.lines.some(x=>!x||typeof x!=='object'||Array.isArray(x)
       ||Object.keys(x).some(k=>!['unitId','amount','method','note'].includes(k)))
    ||!payload.personal||typeof payload.personal!=='object'||Array.isArray(payload.personal)
    ||Object.keys(payload.personal).some(k=>!['unitId','amount','portions'].includes(k)))
    throw Error('INVALID_MIXED_FIELDS');
   return rpc(env,'tower_finance_mixed_collect_action',{p_token:inner.token,p_payload:payload});
  }
  if(['submitCollectionBatch','getCollectionBatchStatus','listCollectionBatches'].includes(inner.name)){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role)||inner.name==='submitCollectionBatch'&&u.role==='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='submitCollectionBatch'?'post':inner.name==='getCollectionBatchStatus'?'status':'list';
   const payload=action==='list'?(inner.args?.[0]||{}):inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_COLLECTION_BATCH');
   if(action!=='list'&&(!/^[A-Za-z0-9_-]{16,64}$/.test(String(payload.reference||''))))throw Error('INVALID_COLLECTION_BATCH');
   if(action==='post'&&(!Array.isArray(payload.lines)||!payload.lines.length||payload.lines.length>100))throw Error('INVALID_COLLECTION_BATCH');
   return rpc(env,'tower_collection_batch_233',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='createAndApproveUnionCollection'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   // FUND collection and PERSONAL services are separate ledgers. Never silently
   // accept a mixed payment through the FUND-only RPC; an atomic mixed RPC
   // must be implemented and audited before enabling such transactions.
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||Object.keys(payload).some(k=>!['lines','notes'].includes(k))
      ||!Array.isArray(payload.lines)||!payload.lines.length
      ||(payload.notes!==undefined&&typeof payload.notes!=='string')
      ||payload.lines.some(line=>!line||typeof line!=='object'||Array.isArray(line)
        ||Object.keys(line).some(k=>!['unitId','amount','method'].includes(k))))
    throw Error('FUND_COLLECTION_ONLY');
   return rpc(env,'tower_union_collect_approve',{p_token:inner.token,p_payload:payload});
  }
  if(['getCollectionContext','getCollectionReport','createCollectionReport','updateCollectionReport','submitCollectionReport','returnCollectionReport','approveCollectionReport'].includes(inner.name)){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(['createCollectionReport','updateCollectionReport','submitCollectionReport'].includes(inner.name)&&u.role==='ADMIN')throw Error('FORBIDDEN');
   if(['returnCollectionReport','approveCollectionReport'].includes(inner.name)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const actions={getCollectionContext:'context',getCollectionReport:'details',createCollectionReport:'create',updateCollectionReport:'update',submitCollectionReport:'submit',returnCollectionReport:'return',approveCollectionReport:'approve'};
   const payload=inner.name==='getCollectionContext'?{}:
    inner.name==='getCollectionReport'||inner.name==='submitCollectionReport'?{reportId:inner.args?.[0]}:
    inner.name==='createCollectionReport'?(inner.args?.[0]||{}):
    inner.name==='updateCollectionReport'?{reportId:inner.args?.[0],...(inner.args?.[1]||{})}:
    inner.name==='returnCollectionReport'?{reportId:inner.args?.[0],notes:inner.args?.[1]}:
    {reportId:inner.args?.[0],...(inner.args?.[1]||{})};
   const result=await rpc(env,'tower_collection_action',{p_token:inner.token,p_action:actions[inner.name],p_payload:payload});
   return inner.name==='getCollectionContext'?{...result,isUnionCollector:u.role==='UNION'}:result;
  }
  if(inner.name==='getGuardAccounts'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   // Derive current balances from the existing role-checked RPC rather than
   // trusting a unit id from the client or duplicating database permissions.
   const ctx=await rpc(env,'tower_guard_trip_context',{p_token:inner.token});
   const units=new Map((Array.isArray(ctx?.units)?ctx.units:[]).map(unit=>[String(unit.unitId),unit]));
   const accounts=new Map();
   for(const trip of (Array.isArray(ctx?.trips)?ctx.trips:[])){
    const id=String(trip.unitId||'');
    if(!id)continue;
    const unit=units.get(id)||{};
    const existing=accounts.get(id)||{
      unitId:id,unitNumber:unit.unitNumber||trip.unitNumber||'—',
      managerName:unit.managerName||trip.managerName||'—',
      openTripCount:0,purchasesTotal:0
    };
    existing.openTripCount++;
    const amount=Number(trip.purchasesTotal);
    if(!Number.isFinite(amount)||amount<0)throw Error('INVALID_TRIP_AMOUNT');
    existing.purchasesTotal=Math.round((existing.purchasesTotal+amount)*100)/100;
    accounts.set(id,existing);
   }
   return [...accounts.values()].sort((a,b)=>String(a.unitNumber).localeCompare(String(b.unitNumber),'ar',{numeric:true}));
  }
  if(inner.name==='getGuardSettlements'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   // Read-only summary of the latest 30 settlements. Keep the original guard
   // permission; never expose resident-only distance calculations here.
   const records=await db(env,'tower_trip_settlements?select=settlement_id,unit_id,sequence_no,status,settled_by,manager_display_name,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after,settled_at,canceled_at,canceled_by,cancel_reason&order=settled_at.desc&limit=30');
   if(!Array.isArray(records))throw Error('INVALID_SETTLEMENT_RESPONSE');
   const unitIds=[...new Set(records.map(r=>String(r.unit_id||'')).filter(Boolean))];
   const units=unitIds.length?await db(env,'tower_units?select=unit_id,unit_number&unit_id=in.('+unitIds.map(encodeURIComponent).join(',')+')'):[];
   const unitNumbers=new Map((Array.isArray(units)?units:[]).map(x=>[String(x.unit_id),x.unit_number]));
   const num=(v)=>v===null||v===undefined?null:Number(v);
   return records.map(s=>({
    settlementId:s.settlement_id,unitId:s.unit_id,sequenceNo:s.sequence_no,status:s.status,
    settledAt:s.settled_at,settledByUserId:s.settled_by,
    purchasesTotal:num(s.purchases_total),feesTotal:num(s.fees_total),grossTotal:num(s.gross_total),
    priorPayments:num(s.prior_payments),closingPayment:num(s.closing_payment),
    creditAfter:num(s.credit_after),
    managerDisplayName:s.manager_display_name,managerName:s.manager_display_name||'—',
    unitNumber:unitNumbers.get(String(s.unit_id))||'—',
    canceledAt:s.canceled_at,canceledByUserId:s.canceled_by,cancelReason:s.cancel_reason
   }));
  }
  if(inner.name==='getGuardSettlementDetails'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const settlementId=String(inner.args?.[0]||'');
   if(!/^[a-f0-9-]{36}$/i.test(settlementId))throw Error('INVALID_SETTLEMENT_ID');
   const result=await db(env,'tower_trip_settlements?select=settlement_id,unit_id,sequence_no,manager_display_name,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after,settled_at&settlement_id=eq.'+encodeURIComponent(settlementId)+'&limit=1');
   if(!Array.isArray(result)||!result.length)throw Error('SETTLEMENT_NOT_FOUND');
   const s=result[0];
   const [details,units]=await Promise.all([
    db(env,'tower_trip_settlement_details?select=detail_type,snapshot,amount&settlement_id=eq.'+encodeURIComponent(settlementId)+'&detail_type=eq.TRIP'),
    db(env,'tower_units?select=unit_number&unit_id=eq.'+encodeURIComponent(s.unit_id)+'&limit=1')
   ]);
   const safeDetails=(Array.isArray(details)?details:[]).map(d=>{
    const snapshot=d.snapshot||{};
    const items=Array.isArray(snapshot.items)?snapshot.items.map(it=>({name:String(it.name||''),price:Number(it.price||0)})):[];
    return {type:'TRIP',snapshot:{items,createdAt:snapshot.createdAt,purchasesTotal:Number(snapshot.purchasesTotal||0)},amount:Number(d.amount||0)};
   });
   return {settlement:{sequenceNo:s.sequence_no,unitNumber:(Array.isArray(units)&&units[0]?.unit_number)||'—',settledAt:s.settled_at,managerDisplayName:s.manager_display_name,purchasesTotal:Number(s.purchases_total||0),feesTotal:Number(s.fees_total||0),grossTotal:Number(s.gross_total||0),priorPayments:Number(s.prior_payments||0),closingPayment:Number(s.closing_payment||0),creditAfter:Number(s.credit_after||0)},details:safeDetails};
  }
  if(inner.name==='getGuardTripContext'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const context=await rpc(env,'tower_guard_trip_context',{p_token:inner.token});
   if(!Array.isArray(context?.trips)||!context.trips.length)return context;
   // The existing authorized trip read includes notes; enrich only current open
   // trip IDs, without exposing its resident-only distance/fee/account fields.
   try{
    const rows=await rpc(env,'tower_trip_action',{p_token:inner.token,p_action:'list',p_payload:{}});
    if(!Array.isArray(rows))throw Error('INVALID_TRIP_NOTES_RESPONSE');
    const byId=new Map(rows.map(row=>[String(row.tripId),row]));
    return {...context,trips:context.trips.map(trip=>{
     const row=byId.get(String(trip.tripId));
     return {...trip,notes:typeof row?.notes==='string'?row.notes:'',notesUnavailable:!row};
    })};
   }catch(e){
    console.warn('GUARD_TRIP_NOTES_UNAVAILABLE',String(e.dbCode||'UNAVAILABLE').slice(0,16));
    return {...context,trips:context.trips.map(trip=>({...trip,notes:'',notesUnavailable:true}))};
   }
  }
  if(['getMyTripSettings','updateMyTripSettings'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const unitId=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_resident_trip_settings',{p_token:inner.token,p_action:inner.name==='getMyTripSettings'?'get':'update',p_payload:{...(inner.name==='updateMyTripSettings'?(inner.args?.[0]||{}):{}),unitId}});
  }
  if(inner.name==='adminCreateUser'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_admin_create_user',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  // UNION needs unit-member names for the units screen, not the admin account directory.
  if(inner.name==='listUnitPeople'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const users=await db(env,'tower_users?select=user_id,name,title,role,status&order=name.asc');
   const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null');
   const memberships=new Map();for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,name:x.name,title:x.title,titleId:x.title_id||'',customTitle:x.custom_title||'',phone:x.phone||'',email:x.email||'',displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,status:x.status,membership:(memberships.get(x.user_id)||[])[0]||null,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='adminBrandAsset'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};const kind=String(payload.kind||'');
   if(!['logo','main'].includes(kind))throw Error('INVALID_OPERATION');
   if(payload.remove===true){await db(env,'tower_brand_assets?kind=eq.'+kind,{method:'DELETE'});return {success:true};}
   const data=String(payload.data||'');const match=/^data:(image\/(?:webp|jpeg|png));base64,([A-Za-z0-9+/]+={0,2})$/.exec(data);
   if(!match||match[2].length>650000||match[2].length<16)throw Error('INVALID_IMAGE');
   const head=atob(match[2].slice(0,32));const mime=match[1];
   if(!((mime==='image/png'&&head.startsWith('\x89PNG\r\n\x1a\n'))||(mime==='image/jpeg'&&head.startsWith('\xff\xd8\xff'))||(mime==='image/webp'&&head.slice(0,4)==='RIFF'&&head.slice(8,12)==='WEBP')))throw Error('INVALID_IMAGE');
   const prev=await db(env,'tower_brand_assets?select=kind&kind=eq.'+kind+'&limit=1');
   if(prev.length)await db(env,'tower_brand_assets?kind=eq.'+kind,{method:'PATCH',body:{mime,encoded:match[2],updated_at:new Date().toISOString()}});
   else await db(env,'tower_brand_assets',{method:'POST',body:{kind,mime,encoded:match[2]}});
   return {success:true};
  }
  if(inner.name==='welcomeProgress'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const action=String(inner.args?.[0]||'get');
   if(!['get','save'].includes(action))throw Error('INVALID_OPERATION');
   return rpc(env,'tower_welcome_action',{p_token:inner.token,p_action:action,p_payload:inner.args?.[1]||{}});
  }
  if(inner.name==='managerRegistrationOpinion'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_registration_manager_advisory',{p_token:inner.token,p_request_id:payload.requestId,p_opinion:payload.opinion,p_note:payload.note||''});
  }
  if(inner.name==='managerMemberOpinion'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_member_advisory',{p_token:inner.token,p_request_id:payload.requestId,p_opinion:payload.opinion,p_note:payload.note||''});
  }
  if(['adminGetHealthAlertSettings','adminSaveHealthAlertSettings'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   return inner.name==='adminGetHealthAlertSettings'?{settings:await readHealthPrefs(env),monitorEnabled:healthBool(env.HEALTH_MONITOR_ENABLED,false),hasRecipient:!!env.HEALTH_TELEGRAM_CHAT_ID}: {settings:await saveHealthPrefs(env,inner.args?.[0])};
  }
  if(inner.name==='adminSetResidentUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_admin_set_resident_units',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(['adminGetSystemSettings','adminSaveSystemSettings'].includes(inner.name)){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='adminGetSystemSettings'?'get':'save';
   const payload=action==='get'?{}:(inner.args?.[0]||{});
   return rpc(env,'tower_admin_system_settings',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['adminGetDigestSchedule','adminSaveDigestSchedule'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   if(inner.name==='adminSaveDigestSchedule'){
    const v=String(inner.args?.[0]?.time||'');
    if(!/^(?:[01]\d|2[0-3]):(?:[0-5][05])$/.test(v))throw Error('INVALID_DIGEST_TIME');
    const changed=await db(env,'tower_daily_digest_schedule?singleton=eq.true',{method:'PATCH',body:{send_time:v+':00'}});
    if(!changed.length)throw Error('DIGEST_SCHEDULE_NOT_INSTALLED');
    return {time:String(changed[0].send_time).slice(0,5)};
   }
   const rows=await db(env,'tower_daily_digest_schedule?singleton=eq.true&select=send_time&limit=1');
   if(!rows.length)throw Error('DIGEST_SCHEDULE_NOT_INSTALLED');
   return {time:String(rows[0].send_time).slice(0,5)};
  }
  if(inner.name==='adminRepairMissingManagers'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_admin_repair_missing_managers',{p_token:inner.token});
  }
  if(['adminOperationalResetPreview','adminOperationalReset'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const execute=inner.name==='adminOperationalReset';
   return rpc(env,'tower_operational_reset',{p_token:inner.token,p_action:execute?'execute':'preview',p_payload:execute?(inner.args?.[0]||{}):{}});
  }
  if(inner.name==='adminBackupReadiness'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   // A preflight only: never report a backup as created, and never return secrets.
   const durableStore=Boolean(env.TOWER_BACKUP_BUCKET);
   const protectedBackup=Boolean(env.TOWER_BACKUP_ENCRYPTION_KEY);
   return {
    ready:false, backupCreated:false,
    checks:[
     {id:'storage',passed:durableStore,description:'مخزن نسخ احتياطية دائم ومعزول'},
     {id:'encryption',passed:protectedBackup,description:'تشفير مستقل لملفات النسخ الاحتياطي'},
     {id:'snapshot',passed:false,description:'تنفيذ Snapshot متسق لكل الجداول والبيانات والمرفقات'},
     {id:'restore',passed:false,description:'استعادة ذرية مع نسخة أمان واختبار الرجوع'},
     {id:'verification',passed:false,description:'اختبار استعادة كامل على قاعدة تجريبية'}
    ],
    message:'النسخ الاحتياطي الكامل والاستعادة والتصفير غير متاحة بعد. لا توجد نسخة احتياطية تم إنشاؤها بهذا الفحص.'
   };
  }
  if(inner.name==='adminTelegramQueueProbe'){
   // Creates ONLY a personal INFO notification for the authenticated admin.
   // A real notification trigger and the scheduled queue must deliver it.
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   const linked=await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(u.user_id)+'&enabled=eq.true&select=user_id&limit=1');
   if(!linked.length)throw Error('TELEGRAM_NOT_LINKED');
   // Keep a short cooldown, but do not duplicate a still-pending test delivery.
   const recent=await db(env,'tower_notifications?user_id=eq.'+encodeURIComponent(u.user_id)+'&type=eq.SYSTEM_TELEGRAM_PROBE&created_at=gte.'+encodeURIComponent(new Date(Date.now()-60*1000).toISOString())+'&select=notification_id,created_at&order=created_at.desc&limit=1');
   if(recent.length){
    const remaining=Math.max(1,Math.ceil((new Date(recent[0].created_at).getTime()+60*1000-Date.now())/1000));
    return {success:false,blocked:true,reason:'COOLDOWN',retryAfterSeconds:remaining,message:'تم تنفيذ الاختبار مؤخرًا. انتظر قليلًا ثم حاول مجددًا.'};
   }
   const outstanding=await db(env,'tower_telegram_delivery_log?user_id=eq.'+encodeURIComponent(u.user_id)+'&status=in.(PENDING,FAILED)&event_key=like.notification:*&select=event_key,status&order=created_at.desc&limit=30');
   if(outstanding.length){
    const ids=outstanding.map(x=>String(x.event_key||'').split(':')[1]).filter(x=>/^[0-9a-f-]{16,}$/i.test(x));
    if(ids.length){
     const probes=await db(env,'tower_notifications?user_id=eq.'+encodeURIComponent(u.user_id)+'&type=eq.SYSTEM_TELEGRAM_PROBE&notification_id=in.('+ids.map(encodeURIComponent).join(',')+')&select=notification_id&limit=1');
     if(probes.length)return {success:false,blocked:true,reason:'PENDING',message:'يوجد اختبار سابق قيد المعالجة. راجع الطابور قبل إعادة الإرسال.'};
    }
   }
   const inserted=await db(env,'tower_notifications',{method:'POST',body:{user_id:u.user_id,type:'SYSTEM_TELEGRAM_PROBE',title:'اختبار إرسال Telegram التلقائي',body:'هذا إشعار فحص إداري، دون عمليات مالية أو بيانات خاصة.',entity:'',entity_id:''}});
   return {success:true,notificationId:inserted?.[0]?.notification_id||null,message:'تم إنشاء الإشعار. انتظر دورة Cron ثم أعد فحص الطابور.'};
  }
  if(inner.name==='adminTelegramDiagnostics'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   // Read-only aggregate operational health. No Telegram chat ID, token or personal content.
   // Return a sampling warning if the queue exceeds the safe PostgREST page cap.
   const [accounts,jobs]=await Promise.all([
    db(env,'tower_telegram_accounts?select=user_id,enabled&limit=1001'),
    db(env,'tower_telegram_delivery_log?select=status,attempts,created_at,sent_at,next_attempt_at&order=created_at.desc&limit=1001')
   ]);
   // The health record is optional during staged SQL rollout; absence is explicitly shown.
   let cronHealth=null;
   try{const r=await db(env,'tower_telegram_cron_health?health_id=eq.1&select=last_started_at,last_finished_at,last_status,last_jobs_sent,last_jobs_failed,last_digest_error&limit=1');cronHealth=r[0]||null;}
   catch(e){console.error('TELEGRAM_CRON_HEALTH_READ_UNAVAILABLE');}
   const counts={PENDING:0,FAILED:0,SENT:0,CANCELLED:0};
   for(const job of jobs)if(Object.hasOwn(counts,job.status))counts[job.status]++;
   const nowMs=Date.now();
   const overdue=jobs.filter(x=>['PENDING','FAILED'].includes(x.status)&&Number.isFinite(Date.parse(x.next_attempt_at))&&Date.parse(x.next_attempt_at)<nowMs-15*60*1000).length;
   const retriesExhausted=jobs.filter(x=>x.status==='FAILED'&&Number(x.attempts)>=6).length;
   const latestSent=jobs.filter(x=>x.status==='SENT'&&x.sent_at).map(x=>x.sent_at).sort().at(-1)||null;
   return {checkedAt:new Date().toISOString(),linkedAccounts:accounts.length,enabledAccounts:accounts.filter(x=>x.enabled).length,
    totalJobs:jobs.length,counts,latestSent,overdueJobs:overdue,retriesExhausted,
    truncated:accounts.length>=1000||jobs.length>=1000,
    cronConfiguredInSource:true,cronLastRan:cronHealth?.last_started_at||null,cronLastFinished:cronHealth?.last_finished_at||null,cronLastStatus:cronHealth?.last_status||null,cronLastJobsSent:cronHealth?.last_jobs_sent??null,cronLastJobsFailed:cronHealth?.last_jobs_failed??null,cronDigestError:cronHealth?.last_digest_error??null,
    cronNote:cronHealth?'توقيت التنفيذ مسجل من مهمة Cloudflare المجدولة، ولا يثبت بمفرده نجاح تسليم Telegram.':'لا يوجد سجل تشغيل Cron قابل للقراءة. راجع Cloudflare Triggers/Logs.'};
  }
  if(inner.name==='adminMigrationRegistry'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   // Generic migration coverage from the generated source catalog and Supabase's append-only execution ledger.
   // The registry's presence never proves arbitrary legacy SQL was run; missing table is NOT_TESTED, not PASS.
   let rows;
   try{rows=await rpc(env,'tower_migration_registry_read',{});}
   catch(e){return {status:'NOT_TESTED',registryAvailable:false,reason:'REGISTRY_UNAVAILABLE',catalog:MIGRATION_CATALOG,rows:[]};}
   if(!Array.isArray(rows))return {status:'NOT_TESTED',registryAvailable:false,reason:'REGISTRY_BAD_RESPONSE',catalog:MIGRATION_CATALOG,rows:[]};
   const installed=new Map(rows.map(x=>[Number(x.migration_id),x]));
   const checks=MIGRATION_CATALOG.map(x=>{
    const r=installed.get(x.id);
    if(!r)return {...x,status:'NOT_RECORDED',reason:'No execution record; this does not prove it is missing'};
    if(r.filename!==x.filename)return {...x,status:'WARN',reason:'Recorded filename differs',recordedFilename:r.filename};
    return {...x,status:r.verification_state==='APPLIED'?'APPLIED':'DETECTED_UNVERIFIED',appliedAt:r.applied_at||null};
   });
   return {registryAvailable:true,status:checks.some(x=>x.status!=='APPLIED')?'WARN':'PASS',catalogCount:checks.length,checks,recordCount:rows.length,unknownHistorical:'SQL before the registry is not automatically certified; no historical backfill was assumed. SQL 138 needs independent read-only evidence (AUDIT_138_READ_ONLY.sql).'};
  }
  if(inner.name==='adminSystemHealthCheck'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const mode=String(inner.args?.[0]||'read_only');
   if(!['read_only','rollback_probe'].includes(mode))throw Error('INVALID_OPERATION');
   return rpc(env,'tower_system_diagnostics',{p_token:inner.token,p_mode:mode});
  }
  if(inner.name==='adminRunDiagnostics'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const [users,units,members]=await Promise.all([
    db(env,'tower_users?select=user_id,login_id,role,status&order=user_id.asc&limit=10001'),
    db(env,'tower_units?select=unit_id,unit_number,floor,status&order=unit_id.asc&limit=10001'),
    db(env,'tower_members?select=unit_id,user_id,member_role,ended_at&order=member_id.asc&limit=10001')
   ]);
   if(!Array.isArray(users)||!Array.isArray(units)||!Array.isArray(members))throw Error('DIAGNOSTICS_DATA_ERROR');
   // Never report a clean result from a possibly truncated PostgREST result set.
   if(users.length>=10000||units.length>=10000||members.length>=10000)throw Error('DIAGNOSTICS_TOO_MANY_ROWS');
   const issues=[],logins=new Set(),activeByUser=new Set(),membersByUnit=new Map(),unitKeys=new Set();
   for(const m of members){
    if(m.ended_at!=null)continue;
    activeByUser.add(String(m.user_id));
    const key=String(m.unit_id),a=membersByUnit.get(key)||[];a.push(m);membersByUnit.set(key,a);
   }
   for(const x of users){
    const login=String(x.login_id||'').trim().toLowerCase();
    if(login){
     if(logins.has(login))issues.push({type:'DUPLICATE_LOGIN',severity:'HIGH',label:'معرف دخول مكرر: '+login,entityId:x.user_id});
     logins.add(login);
    }
    if(x.role==='RESIDENT'&&x.status==='ACTIVE'&&!activeByUser.has(String(x.user_id)))
     issues.push({type:'RESIDENT_WITHOUT_UNIT',severity:'HIGH',label:'ساكن نشط بدون عضوية وحدة',entityId:x.user_id});
   }
   for(const x of units){
    if(x.status!=='ACTIVE')continue;
    const key=String(x.floor||'').trim()+'|'+String(x.unit_number||'').trim();
    if(unitKeys.has(key))issues.push({type:'DUPLICATE_UNIT',severity:'HIGH',label:'وحدة مكررة: '+key.replace('|',' / '),entityId:x.unit_id});
    unitKeys.add(key);
    const activeMembers=membersByUnit.get(String(x.unit_id))||[];
    if(activeMembers.length&&!activeMembers.some(m=>m.member_role==='MANAGER'))
     issues.push({type:'MISSING_MANAGER',severity:'MEDIUM',label:'وحدة بها أعضاء بدون مدير',entityId:x.unit_id});
   }
   return {checkedAt:new Date().toISOString(),issueCount:issues.length,issues};
  }
  if(inner.name==='adminPreviewResidentLoginId'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const unitId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(unitId))throw Error('INVALID_UNIT_ID');
   const units=await db(env,'tower_units?select=unit_id,floor,unit_number,status&unit_id=eq.'+encodeURIComponent(unitId)+'&limit=1');
   const unit=Array.isArray(units)?units[0]:null;
   if(!unit)throw Error('اختر وحدة صحيحة للساكن.');
   const floor=String(unit.floor??'').trim(),number=String(unit.unit_number??'').trim();
   if(!/^[0-9]{1,2}$/.test(floor)||!/^[0-9]{1,2}$/.test(number)||Number(number)<1)throw Error('INVALID_RESIDENT_UNIT_NUMBERING');
   const prefix=floor.padStart(2,'0')+number.padStart(2,'0');
   const users=await db(env,'tower_users?select=login_id&login_id=like.'+prefix+'*&order=login_id.desc&limit=100');
   if(!Array.isArray(users))throw Error('INVALID_LOGIN_CONTEXT');
   let max=0;
   for(const row of users){const login=String(row.login_id||'');if(new RegExp('^'+prefix+'[0-9]{2}$').test(login))max=Math.max(max,Number(login.slice(-2)));}
   if(max>=99)throw Error('RESIDENT_IDS_EXHAUSTED');
   // Preview is advisory: account creation calculates its own ID under a database lock.
   return {loginId:prefix+String(max+1).padStart(2,'0')};
  }
  // Read-only user directory for UNION. Mutating user accounts still requires
  // separately reviewed DB-side authorization, and is NOT enabled here.
  if(inner.name==='unionListUsers'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   const [users,members]=await Promise.all([
    db(env,'tower_users?select=user_id,login_id,name,title,role,status&order=name.asc'),
    db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null')
   ]);
   const memberships=new Map();
   for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,loginId:x.login_id,name:x.name,title:x.title,displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,roleLabel:canonicalUser(x).roleLabel,status:x.status,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='adminListUsers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   let users;
   try{users=await db(env,'tower_users?select=user_id,login_id,name,title,title_id,custom_title,phone,email,role,status,created_at&order=created_at.desc');}
   catch(e){
    if(!String(e.message||'').includes('[42703]'))throw e;
    // Optional contact columns may be absent until migration 038 is installed.
    try{users=await db(env,'tower_users?select=user_id,login_id,name,title,title_id,custom_title,role,status,created_at&order=created_at.desc');}
    catch(e2){if(!String(e2.message||'').includes('[42703]'))throw e2;users=await db(env,'tower_users?select=user_id,login_id,name,title,role,status,created_at&order=created_at.desc');}
   }
   const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null');
   const memberships=new Map();for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,loginId:x.login_id,name:x.name,title:x.title,titleId:x.title_id||'',customTitle:x.custom_title||'',phone:x.phone||'',email:x.email||'',displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,roleLabel:canonicalUser(x).roleLabel,status:x.status,membership:(memberships.get(x.user_id)||[])[0]||null,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='updateMyContacts')return rpc(env,'tower_update_my_contacts',{p_token:inner.token,p_phone:inner.args?.[0]?.phone??'',p_email:inner.args?.[0]?.email??''});
  if(['adminUpdateUser','adminResetUserPin','updateMyProfile'].includes(inner.name)){
   const action=({adminUpdateUser:'update',adminResetUserPin:'resetPin',updateMyProfile:'profile'})[inner.name];
   if(action!=='profile'&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=action==='resetPin'?{userId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_user_account_mutate',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='listTitles'){
   const includeInactive=Boolean(inner.args?.[0]);
   const rows=await db(env,'tower_titles?select=title_id,label,status&order=label.asc'+(includeInactive?'':'&status=eq.ACTIVE'));
   return rows.map(t=>({titleId:t.title_id,label:t.label,normalized:t.label||'',status:t.status,sortOrder:0}));
  }
  if(['adminCreateTitle','adminUpdateTitle','adminSetTitleStatus'].includes(inner.name)){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='adminCreateTitle'?'create':inner.name==='adminUpdateTitle'?'update':'status';
   const payload=action==='status'?{titleId:inner.args?.[0],status:inner.args?.[1]}:(inner.args?.[0]||{});
   return rpc(env,'tower_title_mutate',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='listUnitTypes'){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const inactive=Boolean(inner.args?.[0]);
   const path='tower_unit_types?select=unit_type_id,name,collection_weight,status,sort_order&order=sort_order.asc,name.asc'+(inactive?'':'&status=eq.ACTIVE');
   let rows;
   try{rows=await db(env,path);}
   catch(e){if(!String(e.message||'').includes('[42703]'))throw e;
    rows=await db(env,'tower_unit_types?select=unit_type_id,name,collection_weight,status&order=name.asc'+(inactive?'':'&status=eq.ACTIVE'));
   }
   return rows.map(t=>({unitTypeId:t.unit_type_id,name:t.name,collectionWeight:Number(t.collection_weight),status:t.status,sortOrder:t.sort_order??0}));
  }
  if(['adminCreateUnitType','adminUpdateUnitType','adminDeactivateUnitType','adminReactivateUnitType'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=({adminCreateUnitType:'create',adminUpdateUnitType:'update',adminDeactivateUnitType:'deactivate',adminReactivateUnitType:'reactivate'})[inner.name];
   const payload=(action==='deactivate')?{unitTypeId:inner.args?.[0],replacementUnitTypeId:inner.args?.[1]}:(action==='reactivate')?{unitTypeId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_unit_type_mutate',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='adminBulkUpdateResidents'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_bulk_update_residents',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='adminBulkUpdateUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_bulk_update_units',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='adminBulkCreateResidents'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const items=inner.args?.[0];
   if(!Array.isArray(items)||items.length<1||items.length>50)throw Error('INVALID_BULK_RESIDENTS');
   return rpc(env,'tower_bulk_create_residents',{p_token:inner.token,p_items:items});
  }
  if(inner.name==='adminBulkCreateUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const items=inner.args?.[0];
   if(!Array.isArray(items)||items.length<1||items.length>200)throw Error('INVALID_BULK_UNITS');
   return rpc(env,'tower_bulk_create_units',{p_token:inner.token,p_items:items});
  }
  if(['adminCreateUnit','adminUpdateUnit','adminAssignUnitManager','adminAddExistingMember'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=({adminCreateUnit:'create',adminUpdateUnit:'update',adminAssignUnitManager:'assignManager',adminAddExistingMember:'addMember'})[inner.name];
   const payload=action==='assignManager'?{unitId:inner.args?.[0],userId:inner.args?.[1]}:action==='addMember'?{unitId:inner.args?.[0],userId:inner.args?.[1],relation:inner.args?.[2]}:(inner.args?.[0]||{});
   return rpc(env,'tower_unit_mutate',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='requestUnitMember'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload={...(inner.args?.[0]||{})};
   const titleId=String(payload.titleId||'').trim();
   if(titleId==='__OTHER__'){
    const custom=String(payload.customTitle||'').trim();
    if(!custom||custom.length>40)throw Error('اكتب اللقب المخصص (بحد أقصى 40 حرفًا).');
    payload.titleId='';
    payload.customTitle=custom;
    payload.title=custom;
   }else if(titleId){
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(titleId))throw Error('اللقب المختار غير صالح.');
    const rows=await db(env,'tower_titles?select=label&title_id=eq.'+encodeURIComponent(titleId)+'&status=eq.ACTIVE&limit=1');
    if(!rows.length)throw Error('اللقب المختار غير متاح.');
    payload.title=rows[0].label;
    payload.customTitle='';
   }else{
    payload.title=String(payload.title||'').trim();
    payload.customTitle='';
   }
   return rpc(env,'tower_member_request_mutate',{p_token:inner.token,p_action:'request',p_payload:payload});
  }
  if(inner.name==='updatePendingMemberRequest'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload={...(inner.args?.[0]||{})};
   const titleId=String(payload.titleId||'').trim();
   if(titleId==='__OTHER__'){
    const custom=String(payload.customTitle||'').trim();
    if(!custom||custom.length>40)throw Error('اكتب اللقب المخصص (بحد أقصى 40 حرفًا).');
    payload.titleId='';payload.title=custom;payload.customTitle=custom;
   }else if(titleId){
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(titleId))throw Error('اللقب المختار غير صالح.');
    const rows=await db(env,'tower_titles?select=label&title_id=eq.'+encodeURIComponent(titleId)+'&status=eq.ACTIVE&limit=1');
    if(!rows.length)throw Error('اللقب المختار غير متاح.');
    payload.title=rows[0].label;payload.customTitle='';
   }else throw Error('اختر لقبًا صالحًا.');
   return rpc(env,'tower_member_request_update_pending',{p_token:inner.token,p_payload:payload});
  }
  if(inner.name==='adminApproveMemberRequest'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_approve_member_request',{p_token:inner.token,p_payload:payload});
  }
  if(inner.name==='adminRejectMemberRequest'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_member_request_mutate',{p_token:inner.token,p_action:'reject',p_payload:{requestId:inner.args?.[0],notes:inner.args?.[1]||''}});
  }
  if(inner.name==='listUnitMembersForEdit'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'list',p_payload:{unitId:inner.args?.[0]}});
  }
  if(inner.name==='updateUnitMemberRelation'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'relation',p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='transferUnitManager'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'transfer',p_payload:{unitId:inner.args?.[0],userId:inner.args?.[1]}});
  }
  if(inner.name==='listMemberRequests'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   let scope='';
   if(u.role==='RESIDENT'){
     const managed=await db(env,'tower_members?select=unit_id&user_id=eq.'+encodeURIComponent(u.user_id)+'&member_role=eq.MANAGER&ended_at=is.null');
     if(!managed.length)throw Error('FORBIDDEN');
     scope='&unit_id=in.('+managed.map(x=>x.unit_id).join(',')+')';
   }
   const rows=await db(env,'tower_member_requests?select=request_id,unit_id,requested_by,candidate_name,candidate_title,phone,phone_country,relation,status,created_at,reviewed_at,resulting_user_id,manager_opinion,manager_opinion_at,manager_opinion_note,manager_opinion_by&order=created_at.desc'+scope);
   return rows.map(r=>({requestId:r.request_id,unitId:r.unit_id,requestedByUserId:r.requested_by,name:r.candidate_name,title:r.candidate_title,phone:r.phone,phoneCountry:r.phone_country,relation:r.relation,status:r.status,createdAt:r.created_at,reviewedAt:r.reviewed_at,resultingUserId:r.resulting_user_id,managerOpinion:r.manager_opinion||null,managerOpinionAt:r.manager_opinion_at||null,managerOpinionNote:r.manager_opinion_note||"",managerOpinionBy:r.manager_opinion_by||null}));
  }
  if(inner.name==='listFormerUnitMembers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const rows=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at,ended_at,tower_users(name,title),tower_units(unit_number,floor)&ended_at=not.is.null&order=ended_at.desc');
   return rows.map(m=>({
    unitMemberId:m.member_id,userId:m.user_id,unitId:m.unit_id,
    unitNumber:m.tower_units?.unit_number||String(m.unit_id),floor:m.tower_units?.floor||'',
    displayName:workerPersonName(m.tower_users),
    memberRole:m.member_role,relation:m.relation||'',status:'INACTIVE',
    joinedAt:m.joined_at||'',endedAt:m.ended_at||''
   }));
  }
  if(['getActivityFeed','getActivityDetails','searchActivityFeed'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const select='audit_id,actor_id,action,entity,entity_id,at';
   const base='tower_audit?select='+select;
   // Actor display labels are supplementary: an unavailable profile never blocks the audit feed.
   async function enrichActivityActors(rows){
    const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const ids=[...new Set(rows.map(a=>String(a.actor_id||'')).filter(x=>uuid.test(x)))];
    const unitIds=[...new Set(rows.filter(a=>String(a.entity||'').toUpperCase()==='UNIT').map(a=>String(a.entity_id||'')).filter(x=>uuid.test(x)))];
    let profiles=new Map(),memberships=new Map(),units=new Map();
    if(ids.length){
     try{const users=await db(env,'tower_users?select=user_id,name,title,role&user_id=in.('+ids.join(',')+')');profiles=new Map(users.map(x=>[String(x.user_id),x]));}catch(_ignored){}
     try{const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null&user_id=in.('+ids.join(',')+')');for(const m of members){const id=String(m.user_id);if(!memberships.has(id))memberships.set(id,[]);memberships.get(id).push(m);}}catch(_ignored){}
    }
    if(unitIds.length){try{const found=await db(env,'tower_units?select=unit_id,unit_number&unit_id=in.('+unitIds.join(',')+')');units=new Map(found.map(x=>[String(x.unit_id),String(x.unit_number||'')]));}catch(_ignored){}}
    return rows.map(a=>{
     const actor=profiles.get(String(a.actor_id))||{};
     const actorUnits=memberships.get(String(a.actor_id))||[];
     const explicit=String(a.entity||'').toUpperCase()==='UNIT'&&units.has(String(a.entity_id));
     // A member's unit is not automatically the unit of this action. Only show context
     // for events whose entity explicitly identifies a unit.
     return {...a,actorDisplayName:workerPersonName(actor),actorRole:actor.role||'',unitId:explicit?String(a.entity_id):'',unitNumber:explicit?units.get(String(a.entity_id)):'',actorMembershipCount:actorUnits.length};
    });
   }
   if(inner.name==='searchActivityFeed'){
    const input=inner.args?.[0]||{};
    const term=String(input.term||'').trim().slice(0,80);
    const limit=50;
    const page=Math.min(200,Math.max(0,Math.trunc(Number(input.page)||0)));
    const escapeValue=v=>encodeURIComponent(v);
    let filter='';
    if(term){
     // PostgREST logical filters must not accept arbitrary syntax from the client.
     const safe=term.replace(/[*,().\\]/g,' ').trim();
     if(safe){
      let actors=[];
      try{
       const matches=await db(env,'tower_users?select=user_id&or=(name.ilike.*'+escapeValue(safe)+'*,title.ilike.*'+escapeValue(safe)+'*)&limit=100');
       actors=matches.map(x=>x.user_id).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
      }catch(_ignored){}
      const conditions=['action.ilike.*'+safe+'*','entity.ilike.*'+safe+'*'];
      if(actors.length)conditions.push('actor_id.in.('+actors.join(',')+')');
      filter='&or=('+escapeValue(conditions.join(','))+')';
     }
    }
    const rows=await db(env,base+filter+'&order=at.desc,audit_id.desc&limit='+(limit+1)+'&offset='+(page*limit));
    const hasMore=rows.length>limit;
    const enriched=await enrichActivityActors(rows.slice(0,limit));
    return {rows:enriched.map(a=>({auditId:a.audit_id,timestamp:a.at,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',actorDisplayName:a.actorDisplayName,unitId:a.unitId||'',unitNumber:a.unitNumber||''})),hasMore,page};
   }
   if(inner.name==='getActivityFeed'){
    const raw=Number(inner.args?.[0]);
    const limit=Number.isFinite(raw)?Math.min(200,Math.max(1,Math.trunc(raw))):100;
    const rows=await db(env,base+'&order=at.desc&limit='+limit);
    const enriched=await enrichActivityActors(rows);
    return enriched.map(a=>({auditId:a.audit_id,timestamp:a.at,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',actorDisplayName:a.actorDisplayName,unitId:a.unitId||'',unitNumber:a.unitNumber||''}));
   }
   const id=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))throw Error('INVALID_AUDIT_ID');
   const rows=await db(env,base+'&audit_id=eq.'+encodeURIComponent(id)+'&limit=1');
   if(!rows.length)throw Error('AUDIT_NOT_FOUND');
   const a=(await enrichActivityActors(rows))[0];
   return {auditId:a.audit_id,timestamp:a.at,actorDisplayName:a.actorDisplayName,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',unitId:a.unitId||'',unitNumber:a.unitNumber||'',before:'',after:''};
  }
  if(inner.name==='getCoreHomeData'){
   // Core home intentionally reads only migrated core tables; no fictitious finance figures.
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const result={notifications:[]};
   if(['ADMIN','UNION','OPERATOR'].includes(u.role)){
    const units=await db(env,'tower_units?select=unit_id&status=eq.ACTIVE');
    result.unitCount=units.length;
   }
   if(u.role==='ADMIN'){
    const users=await db(env,'tower_users?select=user_id&status=eq.ACTIVE');
    result.userCount=users.length;
    // Member request migration isn't installed yet, so do not claim zero pending requests.
    result.pendingMemberRequests=null;
   }
   if(u.role==='RESIDENT'){
    const memberships=await db(env,'tower_members?select=unit_id,member_role&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null');
    const m=memberships[0];
    result.membership=m?{unitId:m.unit_id,memberRole:m.member_role}:null;
    // No account balances until the ledger migration is installed.
    result.account=null;
   }
   return result;
  }
  if(inner.name==='getMyUnitGovernance'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   // Never accept a unit ID supplied by the browser; derive scope from the authenticated user.
   const memberships=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null&order=joined_at.asc');
   if(!memberships.length)return {hasUnit:false,units:[],members:[],requests:[]};
   const ids=[...new Set(memberships.map(m=>m.unit_id))];
   const units=await db(env,'tower_units?select=unit_id,unit_number,floor,unit_type_id,status,tower_unit_types(name,status)&unit_id=in.('+ids.join(',')+')');
   const allMembers=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at,tower_users(name,title,title_id,custom_title)&ended_at=is.null&unit_id=in.('+ids.join(',')+')');
   const managedIds=memberships.filter(m=>m.member_role==='MANAGER').map(m=>m.unit_id);
   const reqs=ids.length?await db(env,'tower_member_requests?select=request_id,unit_id,requested_by,candidate_name,candidate_title,candidate_title_id,candidate_custom_title,phone,phone_country,relation,status,created_at,manager_opinion,manager_opinion_at,manager_opinion_note&unit_id=in.('+ids.join(',')+')&order=created_at.desc'):[];
   const joinRequests=managedIds.length?await db(env,'tower_registration_requests?select=request_id,unit_id,name,title,phone,relation,status,created_at,manager_opinion,manager_opinion_at,manager_opinion_note&status=eq.PENDING&unit_id=in.('+[...new Set(managedIds)].join(',')+')&order=created_at.desc'):[];
   const membershipsByUnit=new Map(memberships.map(m=>[m.unit_id,m]));
   const results=units.map(unit=>{
    const m=membershipsByUnit.get(unit.unit_id);
    const members=allMembers.filter(row=>row.unit_id===unit.unit_id).map(row=>({unitMemberId:row.member_id,userId:row.user_id,unitId:row.unit_id,memberRole:row.member_role,relation:row.relation||'',name:row.tower_users?.name||'',title:row.tower_users?.title||'',customTitle:row.tower_users?.custom_title||'',displayName:workerPersonName(row.tower_users)}));
    return {unit:{unitId:unit.unit_id,unitNumber:unit.unit_number,floor:unit.floor,unitTypeId:unit.unit_type_id,unitTypeName:unit.tower_unit_types?.name||'',status:unit.status},membership:{unitId:m.unit_id,memberRole:m.member_role,relation:m.relation||''},members,registrationRequests:m.member_role==='MANAGER'?joinRequests.filter(x=>x.unit_id===unit.unit_id).map(x=>({requestId:x.request_id,unitId:x.unit_id,name:x.name,title:x.title,phone:x.phone,relation:x.relation,createdAt:x.created_at,managerOpinion:x.manager_opinion||null,managerOpinionAt:x.manager_opinion_at||null,managerOpinionNote:x.manager_opinion_note||''})):[],requests:reqs.filter(r=>r.unit_id===unit.unit_id).map(r=>({requestId:r.request_id,unitId:r.unit_id,name:r.candidate_name,title:r.candidate_title,titleId:r.candidate_title_id||'',customTitle:r.candidate_custom_title||'',phone:r.phone||'',phoneCountry:r.phone_country||'',relation:r.relation||'',status:r.status,createdAt:r.created_at,managerOpinion:r.manager_opinion||null,managerOpinionAt:r.manager_opinion_at||null,managerOpinionNote:r.manager_opinion_note||""}))};
   });
   // Preserve V1.13.0 screen contract, and include all linked units for future multi-unit UI.
   const requested=String(inner.args?.[0]||'');const first=results.find(x=>x.unit.unitId===requested&&x.unit.status==='ACTIVE')||results.find(x=>x.unit.status==='ACTIVE'&&x.membership.memberRole==='MANAGER')||results.find(x=>x.unit.status==='ACTIVE')||results[0];return {hasUnit:true,...first,units:results};
  }
  if(inner.name==='listUnits'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const unitIds=u.role==='RESIDENT'?await db(env,'tower_members?select=unit_id&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null'):null;
   if(unitIds&&!unitIds.length)return [];
   const restriction=unitIds?'&unit_id=in.('+unitIds.map(x=>x.unit_id).join(',')+')':'';
   // Active membership only: embedded tower_members without ended_at filtering can select a former manager.
   const [base,types,members]=await Promise.all([
    db(env,'tower_units?select=unit_id,unit_number,floor,unit_type_id,status&order=unit_number.asc'+restriction),
    db(env,'tower_unit_types?select=unit_type_id,name,status'),
    db(env,'tower_members?select=unit_id,user_id,member_role&ended_at=is.null&member_role=eq.MANAGER')
   ]);
   const typeMap=new Map(types.map(t=>[String(t.unit_type_id),t]));
   const baseIds=new Set(base.map(x=>String(x.unit_id)));
   const managers=members.filter(m=>baseIds.has(String(m.unit_id)));
   const userIds=[...new Set(managers.map(m=>m.user_id))];
   const names=[];
   for(let i=0;i<userIds.length;i+=80){
    const chunk=await db(env,'tower_users?select=user_id,name,title&user_id=in.('+userIds.slice(i,i+80).map(encodeURIComponent).join(',')+')');
    names.push(...chunk);
   }
   const userMap=new Map(names.map(n=>[String(n.user_id),n]));
   const rows=base.map(x=>({...x,tower_unit_types:typeMap.get(String(x.unit_type_id))||null,tower_members:managers.filter(m=>String(m.unit_id)===String(x.unit_id)).map(m=>({...m,tower_users:userMap.get(String(m.user_id))||null}))}));
   return rows.map(x=>{const manager=x.tower_members?.find(m=>m.member_role==='MANAGER');return {unitId:x.unit_id,unitNumber:x.unit_number,floor:x.floor,unitTypeId:x.unit_type_id,unitTypeName:x.tower_unit_types?.name||'—',unitTypeStatus:x.tower_unit_types?.status||'',status:x.status,managerUserId:manager?.user_id||'',managerName:manager?[manager.tower_users?.title,manager.tower_users?.name].filter(Boolean).join(' '):'غير معين'};});
  }
  throw Error('OPERATION_NOT_MIGRATED: '+inner.name);
 }
 throw Error('UNKNOWN_METHOD');
}

// Admin-only Cloudflare KV preferences; no access to stored Telegram chat IDs.
const HEALTH_PREF_KEY='health:preferences:v1';
const healthPrefDefaults=env=>({alertsEnabled:healthBool(env.HEALTH_TELEGRAM_ENABLED,true),failure:healthBool(env.HEALTH_ALERT_FAILURE,true),recovery:healthBool(env.HEALTH_ALERT_RECOVERY,true),reminder:healthBool(env.HEALTH_ALERT_REMINDER,true),dailyOk:healthBool(env.HEALTH_TELEGRAM_DAILY_OK,false),reminderHours:Math.max(6,Math.min(48,Number(env.HEALTH_REMINDER_HOURS)||24))});
async function readHealthPrefs(env){const defaults=healthPrefDefaults(env);if(!env.HEALTH_MONITOR_KV)return defaults;try{const data=JSON.parse(await env.HEALTH_MONITOR_KV.get(HEALTH_PREF_KEY)||'{}');return {...defaults,...Object.fromEntries(Object.keys(defaults).filter(k=>typeof data[k]===typeof defaults[k]).map(k=>[k,data[k]]))};}catch(_){return defaults;}}
async function saveHealthPrefs(env,input){if(!env.HEALTH_MONITOR_KV)throw Error('HEALTH_MONITOR_KV_NOT_BOUND');if(!input||typeof input!=='object'||Array.isArray(input))throw Error('INVALID_HEALTH_SETTINGS');const keys=['alertsEnabled','failure','recovery','reminder','dailyOk'];if(keys.some(k=>typeof input[k]!=='boolean')||![6,12,24,48].includes(Number(input.reminderHours)))throw Error('INVALID_HEALTH_SETTINGS');const value={...Object.fromEntries(keys.map(k=>[k,input[k]])),reminderHours:Number(input.reminderHours)};await env.HEALTH_MONITOR_KV.put(HEALTH_PREF_KEY,JSON.stringify(value));return value;}
// Independent health monitor: cloud-side check, no DB write, no financial data.
// Requires HEALTH_MONITOR_KV (Cloudflare KV) for durable throttle and outage recovery alerts.
const healthBool=(v,defaultValue=false)=>v==null?defaultValue:['true','1','yes','on'].includes(String(v).toLowerCase());
async function towerHealthProbe(env){
 const root=String(env.SUPABASE_URL||'').replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(root)||!env.SUPABASE_SERVICE_ROLE_KEY)return {ok:false,reason:'CONFIG_MISSING'};
 try{
  const r=await fetch(root+'/rest/v1/tower_units?select=unit_id&limit=1',{
   headers:{apikey:env.SUPABASE_SERVICE_ROLE_KEY,Authorization:'Bearer '+env.SUPABASE_SERVICE_ROLE_KEY,Accept:'application/json'},
   signal:AbortSignal.timeout(8000),cache:'no-store'});
  return {ok:r.ok,reason:r.ok?'OK':'HTTP_'+r.status};
 }catch(_){return {ok:false,reason:'UNREACHABLE'};}
}
async function towerHealthMonitorRun(env){
 if(!healthBool(env.HEALTH_MONITOR_ENABLED,false))return;
 const kv=env.HEALTH_MONITOR_KV;
 if(!kv){console.warn('HEALTH_MONITOR_KV_NOT_BOUND');return;}
 const now=Date.now(),interval=Math.max(15,Math.min(1440,Number(env.HEALTH_CHECK_MINUTES)||60))*60000;
 const last=Number(await kv.get('health:last_probe_ms')||0);
 if(now-last<interval)return;
 // A brief lease avoids overlapping Cloudflare cron executions.
 await kv.put('health:last_probe_ms',String(now),{expirationTtl:86400});
 const prior=JSON.parse(await kv.get('health:state')||'{}');
 const p=await towerHealthProbe(env);
 const count=p.ok?0:(Number(prior.failures||0)+1);
 const threshold=Math.max(1,Math.min(10,Number(env.HEALTH_FAILURE_THRESHOLD)||2));
 const outage=!p.ok&&count>=threshold;
 const recovery=p.ok&&prior.down===true;
 const firstFailure=outage&&!prior.down;
 const prefsForReminder=await readHealthPrefs(env);
 const reminderHours=prefsForReminder.reminderHours;
 const reminder=outage&&prior.down&&(now-Number(prior.lastAlertAt||0)>=reminderHours*3600000);
 const dailyOk=p.ok&&prefsForReminder.dailyOk&&now-Number(prior.lastDailyOkAt||0)>=86400000;
 const prefs=await readHealthPrefs(env);
 const send=prefs.alertsEnabled&&!!env.HEALTH_TELEGRAM_CHAT_ID&&!!env.TELEGRAM_BOT_TOKEN;
 let lastAlertAt=Number(prior.lastAlertAt||0),lastDailyOkAt=Number(prior.lastDailyOkAt||0);
 const events=[];
 if(firstFailure&&prefs.failure)events.push('🚨 Tower App — تعذر الاتصال بقاعدة Supabase بعد '+count+' فحوصات متتالية. افحص Supabase Dashboard. السبب التقني: '+p.reason);
 else if(reminder&&prefs.reminder)events.push('⚠️ Tower App — مشكلة اتصال Supabase مستمرة. افحص لوحة Supabase.');
 if(recovery&&prefs.recovery)events.push('✅ Tower App — عاد اتصال Supabase للعمل بنجاح.');
 if(dailyOk)events.push('✅ Tower App — الفحص الدوري لاتصال Supabase ناجح.');
 if(send){for(const message of events){try{await telegramSend(env,env.HEALTH_TELEGRAM_CHAT_ID,message);if(message.includes('الفحص الدوري'))lastDailyOkAt=now;else lastAlertAt=now;}catch(e){console.warn('HEALTH_TELEGRAM_SEND_FAILED',String(e.message||e).slice(0,60));}}}
 await kv.put('health:state',JSON.stringify({down:outage,failures:count,lastCheckAt:new Date(now).toISOString(),lastResult:p.ok?'OK':p.reason,lastAlertAt,lastDailyOkAt}),{expirationTtl:31536000});
}

export default {
 async scheduled(event,env,ctx){ctx.waitUntil(scheduledTelegramRun(env).catch(e=>console.error('TELEGRAM_QUEUE_RUN_FAILED',String(e.message||e).slice(0,70))));ctx.waitUntil(towerHealthMonitorRun(env).catch(e=>console.error('HEALTH_MONITOR_RUN_FAILED',String(e.message||e).slice(0,70))));ctx.waitUntil(db(env,'rpc/tower_task_scheduled_ready_214',{method:'POST',body:{}}).catch(e=>console.error('TASK_SCHEDULED_READY_FAILED',String(e.dbCode||e.message||e).slice(0,80))));},
 async fetch(request,env){
 const u=new URL(request.url);
 if(request.method==='GET'&&['/api/brand/logo','/api/brand/main'].includes(u.pathname))return serveBrandImage(env,u.pathname.endsWith('logo')?'logo':'main');
 if(u.pathname==='/api/telegram/webhook'&&request.method==='POST'){try{return await telegramWebhook(env,request);}catch(e){console.error('TELEGRAM_WEBHOOK_FAILED',String(e.message||e).slice(0,80));return fail('WEBHOOK_ERROR',500);}}
 if(u.pathname==='/api/tower'&&request.method==='POST'){
  // Bound the input stream before parsing. PDF uploads are larger because of Base64,
  // while ordinary API calls retain the previous request limits.
  const maxPdfRequestBytes=9*1024*1024;
  if(Number(request.headers.get('content-length')||0)>maxPdfRequestBytes)return fail('REQUEST_TOO_LARGE',413);
  let p, requestBytes=0;
  try{
   const reader=request.body?.getReader();if(!reader)return fail('INVALID_JSON');
   const parts=[];
   while(true){const {done,value}=await reader.read();if(done)break;
    requestBytes+=value.byteLength;
    if(requestBytes>maxPdfRequestBytes){await reader.cancel().catch(()=>{});return fail('REQUEST_TOO_LARGE',413);}
    parts.push(value);
   }
   const data=new Uint8Array(requestBytes);let offset=0;
   for(const part of parts){data.set(part,offset);offset+=part.byteLength;}
   p=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(data));
  }catch(_){return fail('INVALID_JSON');}
  const pdfUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='telegramSettings'&&['sendPdf','autoPdfDispatch'].includes(p?.args?.[0]?.args?.[0]);
  const attachmentUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='addPaymentAttachment';
  const brandUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='adminBrandAsset';
  if(!pdfUpload && requestBytes>1500000)return fail('REQUEST_TOO_LARGE',413);
  if(!pdfUpload && !attachmentUpload && !brandUpload && JSON.stringify(p).length>65536)return fail('REQUEST_TOO_LARGE',413);
  try{const result=await dispatch(env,p);return respond({ok:true,result:await presentPersonLabels(env,result)});}catch(e){
   const raw=String(e.message||e);const code=typeof e.dbCode==='string'?e.dbCode:(/^[A-Z][A-Z0-9_]{2,45}$/.test(raw)?raw:'UNKNOWN');
   // Only explicit server-known errors may be displayed directly; raw exceptions can contain sensitive data.
   const known=Object.hasOwn(DB_USER_ERRORS,raw)||(/^[A-Z][A-Z0-9_]{2,45}$/.test(raw)&&/^(FORBIDDEN|SESSION_REQUIRED|INVALID_[A-Z0-9_]+|TELEGRAM_[A-Z0-9_]+|OPERATION_NOT_MIGRATED)$/.test(raw));
   const message=e.dbCode?raw:(known?raw:'حدث خطأ غير متوقع. تحقق من سجل العملية قبل إعادة المحاولة لتجنب التكرار.');
   const trace=crypto.randomUUID().slice(0,8).toUpperCase();
   console.error('TOWER_OPERATION_FAILED',JSON.stringify({ref:trace,operation:String(p?.method==='apiCall'?p?.args?.[0]?.name||'apiCall':p?.method||'unknown').slice(0,65),dbCode:code}));
   return fail(message,raw==='SUPABASE_SERVER_ENV_MISSING'?503:raw.includes('SESSION_REQUIRED')?401:raw.includes('NOT_MIGRATED')?501:400,{code,reference:trace});
  }
 }
 if(u.pathname==='/api/health')return respond({ok:true,version:APP_VERSION,scope:'auth foundation'});
 return env.ASSETS.fetch(request);
}};
