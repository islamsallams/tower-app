# Tower App V2.5.111 — UI/UX Stage Work

Source: V2.5.110. This is a focused first integrated UI/UX work batch, not the complete UI/UX stage acceptance.

- Preserved source of guard/resident trip screens unchanged.
- Shared Arabic tokenized filtering.
- Service subscriber unit picker: matching by unit, floor, manager or members; live result/available/selected count; select only visible eligible units; preserve previous selection when filtering; clear all; prevent selecting already-subscribed units; selected and locked states; empty-result status; disable add action unless selection exists; responsive toolbar and list; accessible labels and status announcement.
- Service beneficiary results: improved count and visible choices; retained original selection behavior.
- Service details: semantic grouped identity and grouped actions.
- No SQL or Worker business logic changes; Worker version updated only.

NOT TESTED: browser/device QA, Postgres E2E, Windows Updater, role-by-role visual verification.
NOT COMPLETE: All-screen UI/UX unification; stages remain open.
