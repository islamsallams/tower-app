# Tower App V2.5.122 — Shared-Cost Task Display and Reports

- Estimated unit shares appear while enrollment is open; they are NOT posted dues.
- Unit-level estimates use integer cents, unit UUID ordering and remainder logic matching SQL 200.
- Service details, manager panel, summary, detailed report, copy and PDF share the same view model.
- Summary view hides subscriber rows; detailed view shows the units.
- Both PDF modes include total task budget, quantity count, enrollment state, and explicit accounting caveats.
- Management uses live service context to avoid stale enrollment status.
- No Worker business-logic or SQL changes. No trip UI changes.
- E2E/browser/Postgres tests remain required.
