# Tower App V2.5.128 — Unified Shared Task Flow

## Implemented
- Unified subscriber management rows: unit, manager, estimated share and the matching Remove action together on mobile and desktop.
- Removed duplicate per-unit allocation preview (server preview shows an aggregate confirmation, not a second disconnected list).
- Explicit workflow status and pending-request count; actions include Add, Close/Reopen, Finalize and Report in one place.
- Subscriber report tabs renamed to ملخص / تفاصيل الوحدات; shared-cost total and estimated share are labeled separately from paid/approved dues.
- After closing enrollment, remain in management for inspection rather than losing context.
- Preserved guards, SQL60 prerequisites and untouched accounting RPCs; no new SQL.

## Validation
- Syntax/ZIP/source mirror checks; real browser and Supabase E2E pending.
- Existing financial preview failure is not claimed fixed; finalization is gated on successful server preview.
