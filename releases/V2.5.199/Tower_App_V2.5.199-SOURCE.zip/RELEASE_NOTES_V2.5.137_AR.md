# Tower App V2.5.137 — One cumulative task work package

## Delivered
- Per-user, server-authorized unread-task event ledger, read acknowledgements, and actual red alert in resident task cards/tabs.
- Automatically generated workflow change events via database trigger.
- Preserves existing V2.5.136 stage/plan/collection views.

## Not yet genuinely implemented
- Financial installment installment-level settlement and legally effective due dates; prior projection remains advisory.
- Fund-to-task real transfer and reallocation of approved dues: needs a safe ledger debit/credit transaction, plus finance integrity tests.
- Persisted automatic stage change from financial conditions; current readiness display remains advisory.
- Comprehensive navigation-wide notifications, including push or proactive event-based finance updates (current task-event read ledger covers workflow changes only).

## Installation order
1. SQL 64/211 if not already installed.
2. SQL 65/212; review its four PASS outputs.
3. Upload this complete ZIP.

## Tests
Syntax check and archive integrity only. No live Supabase or browser acceptance was carried out.
