# Tower App V2.5.147 — Dark theme form controls

- Unified native date/time/select/text inputs in dark-mode administrative/content surfaces using existing theme tokens.
- Fixed native file chooser contrast, option background and placeholder colors.
- Explicit light-mode native-control scheme; no modifications to financial workflows, guard/trip UI, or printable document colors.
- Source-level tests only; a precise screenshot-to-DOM mapping and browser visual test remain unverified.
