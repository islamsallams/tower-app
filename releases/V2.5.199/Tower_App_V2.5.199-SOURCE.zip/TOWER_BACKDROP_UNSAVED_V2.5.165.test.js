const fs=require('fs'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/app.js','utf8');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const tests=[
 ['backdrop centralized',html.includes('onclick="towerDismissBackdrop(event)"')],
 ['only true backdrop triggers',s.includes('if(event.target!==event.currentTarget)return;')],
 ['backdrop marks intent',s.includes('TOWER_BACKDROP_DISMISS=true;')],
 ['backdrop reset in finally',s.includes('finally{TOWER_BACKDROP_DISMISS=false;}')],
 ['unsaved guard sees backdrop',s.includes('fromHistory||TOWER_ESCAPE_DISMISS||TOWER_BACKDROP_DISMISS')],
 ['unsaved confirmation before close',s.indexOf('towerOtherFormChanged()&&towerExplicitDismiss(fromHistory)')<s.indexOf('if(!fromHistory&&history.state?.towerModal)history.back();')],
 ['source synchronized',s===fs.readFileSync(__dirname+'/public/app.js','utf8')],
 ['html synchronized',html===fs.readFileSync(__dirname+'/public/index.html','utf8')]
];for(const [label,ok] of tests){assert.ok(ok,label);console.log('PASS',label)}console.log(`${tests.length}/${tests.length} PASS`);
