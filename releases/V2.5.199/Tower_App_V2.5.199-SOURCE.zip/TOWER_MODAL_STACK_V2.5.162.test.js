const fs=require('fs'), assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/app.js','utf8');
const checks=[
 ['Stack has actual parent DOM',s.includes('document.createDocumentFragment()')&&s.includes('preserved.appendChild(sh.firstChild)')],
 ['Nested modal snapshots parent classes',s.includes('TOWER_MODAL_STACK.push({content:preserved,wide:')],
 ['Close returns actual parent nodes',s.includes('sh.replaceChildren(parent.content)')],
 ['Cancel confirmation resolves false',s.includes('done(false)')],
 ['Cancel prompt resolves null',s.includes('done(null)')],
 ['Back depth reconciles stack',s.includes('while(towerModalDepth()>expectedDepth)')&&s.includes('if(towerModalDepth()===before)return;')],
 ['Nested modal history depth',s.includes('towerModalDepth:depth')],
 ['Escape only dismisses top dialog',s.includes("event.key==='Escape'&&towerModalDepth()")],
 ['Single remove uses confirmation',s.includes("async function removeSharedSubscriber(id,subscriptionId){")&&s.includes("await confirmAction({title:'إزالة مشترك'")],
 ['Bulk remove uses confirmation',s.includes('async function towerRemoveSelectedShared(id){')&&s.includes('قد تكون')],
 ['Shared subscribers remain viewable',s.includes('function towerRenderSharedMembers(){')],
 ['Original server action untouched',s.includes("await run('removeSharedServiceSubscriber',id,subscriptionId)")],
 ['Public mirror identical',s===fs.readFileSync(__dirname+'/public/app.js','utf8')]
];for(const [name,pass] of checks){assert(pass,name);console.log('PASS',name);}console.log(`${checks.length}/${checks.length} PASS`);
