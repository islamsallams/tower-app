// Superseded by the V2.5.152 full-card interaction contract.
require('./TOWER_SERVICES_INTEGRATION_V2.5.152.test.js');
