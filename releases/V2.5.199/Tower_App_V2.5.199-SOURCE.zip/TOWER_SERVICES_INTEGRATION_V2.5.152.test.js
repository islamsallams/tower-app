const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const src=fs.readFileSync(__dirname+'/app.js','utf8');
const segment=(a,b)=>{const i=src.indexOf(a),j=src.indexOf(b,i+a.length);assert(i>=0&&j>i,`Missing ${a}`);return src.slice(i,j)};
const cardSrc=segment('function serviceAdminServiceCard(', '\nfunction openServiceAdminEdit(');
const taskDetails=segment('function openAdminTaskDetails(', '\nfunction towerAdminCardKeyboard(');
const openSvc=segment('async function openServiceModal(', '\nfunction filterServiceBeneficiaries(');
const checks=[
 ['card opens task modal',src.includes("if(card.dataset.kind==='tasks')openAdminTaskDetails(id)")],
 ['task detail uses modal',taskDetails.includes('openModal(')],
 ['task details one subscription control',taskDetails.includes('openSharedAllocation')],
 ['task details progress accessible',taskDetails.includes('editTaskWorkflow')],
 ['task details edit accessible',taskDetails.includes('openServiceAdminEditById')],
 ['task details no obsolete add button',!taskDetails.includes('openAddServiceSubscribers')],
 ['task cards clickable',cardSrc.includes('towerAdminCardOpen(event,this)')],
 ['recurring card routes to unified workspace',src.includes('else openServiceDetails(id)')&&src.includes('return openServiceWorkspaceOrTask(id);')],
 ['edit modal full form',openSvc.includes('id="srvName"')&&openSvc.includes('submitService(')],
 ['full service edit fields',openSvc.includes('srvPricingMode')],
 ['task modal whole card handler',src.includes("if(card.dataset.kind==='tasks')openAdminTaskDetails(id)")],
 ['task inline content absent',cardSrc.includes("const taskContent=isTask?'':'';")]
];for(const [label,ok] of checks){assert.ok(ok,label);console.log('PASS',label)}console.log(`${checks.length}/${checks.length} PASS`);
