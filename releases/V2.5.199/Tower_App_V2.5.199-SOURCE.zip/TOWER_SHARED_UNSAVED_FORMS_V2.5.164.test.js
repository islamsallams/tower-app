const fs=require('fs'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/app.js','utf8');
const cases=[
 ['generic form snapshot',s.includes('function towerOtherFormSnapshot()')],
 ['excludes task form',s.includes("sh.querySelector('#taskStageInput')")],
 ['compares snapshot',s.includes('function towerOtherFormChanged()')],
 ['saves snapshot on nested stack',s.includes('otherFormBaseline:TOWER_OTHER_FORM_BASELINE')],
 ['restores nested parent snapshot',s.includes('TOWER_OTHER_FORM_BASELINE=parent.otherFormBaseline')],
 ['starts snapshot on open',s.includes('towerTrackOtherForm();')],
 ['warns when leaving edited form',s.includes("towerOtherFormChanged()&&towerExplicitDismiss(fromHistory)")],
 ['protects browser navigation',s.includes('ACTIVE_SAVES>0||towerTaskFormChanged()||towerOtherFormChanged()')],
 ['esc key sets intentional dismissal',s.includes('TOWER_ESCAPE_DISMISS=true;try{closeModal();}finally{TOWER_ESCAPE_DISMISS=false;}')],
 ['source matches public',s===fs.readFileSync(__dirname+'/public/app.js','utf8')],
];
for(const [n,v] of cases){assert.ok(v,n);console.log('PASS',n)}console.log(`${cases.length}/${cases.length} PASS`)
