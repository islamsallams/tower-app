const fs=require('fs'),assert=require('assert');const s=fs.readFileSync(__dirname+'/app.js','utf8'),css=fs.readFileSync(__dirname+'/styles.css','utf8');
const cases=[
['single picker in unified workspace',()=>{const part=s.slice(s.indexOf('function taskWorkspaceMemberSection('),s.indexOf('function taskWorkspaceLegacyParts('));assert.equal((part.match(/id="towerInlineMemberPicker"/g)||[]).length,1);assert(s.includes("return openTaskProject(id,true,'members')"));}],
['picker appears before list',()=>assert(s.includes('id="towerInlineMemberPicker"')&&s.includes('id="towerSharedMemberList"'))],
['picker scrolls into view',()=>assert(s.includes("host.scrollIntoView({behavior:'smooth',block:'nearest'})"))],
['search and floor filters',()=>assert(s.includes('function towerFilterMembers()')&&s.includes('towerMemberFloor'))],
['selection retained across filter',()=>assert(!s.slice(s.indexOf('function towerFilterMembers()'),s.indexOf('function towerUpdateMemberSelection()')).includes('checked=false'))],
['bulk confirmation includes hidden selection',()=>assert(s.includes('قد تكون مخفية بالفلترة'))],
['bulk operations use existing auditable server action',()=>assert(s.includes("await run('removeSharedServiceSubscriber',id,sid)"))],
['inline financial duplication removed',()=>assert(!s.slice(s.indexOf('const memberRows='),s.indexOf('const floors=')).includes('serviceSubscriptionDisplay'))],
['red icon with accessible label',()=>assert(s.includes('class="shared-remove-button"')&&s.includes('title="إزالة المشترك">✕'))],
['compact layout and hidden rows',()=>assert(css.includes('.shared-member-card[hidden]{display:none!important}'))],
['read only when enrollment finalized',()=>assert(s.includes('${isOpen?`<button type="button" class="shared-remove-button"'))],
['public mirror',()=>assert.equal(s,fs.readFileSync(__dirname+'/public/app.js','utf8'))]
];let n=0;for(const [name,fn] of cases){fn();n++;console.log('PASS',name);}console.log(`${n}/${cases.length} PASS`);
