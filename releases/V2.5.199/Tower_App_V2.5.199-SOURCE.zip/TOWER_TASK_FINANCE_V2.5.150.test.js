const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const src=fs.readFileSync(__dirname+'/app.js','utf8');
function fn(name){const st=src.indexOf('function '+name+'(');assert(st>=0);let depth=0;let start=src.indexOf('{',st);for(let i=start;i<src.length;i++){if(src[i]==='{')depth++;if(src[i]==='}'&&!--depth)return src.slice(st,i+1)}throw Error(name)}
const ctx={Date,Math,Number,String};vm.createContext(ctx);vm.runInContext(['towerTaskInstallmentProjection','towerLocalDate','towerTaskFinancialSnapshot','towerTaskReadiness'].map(fn).join('\n'),ctx);
const service={totalBudget:1900,enrollmentStatus:'FINALIZED'},meta={collected:699.99,fundContributionPosted:500,collectionThreshold:50,startRule:'COLLECTION'};
function check(label,fun){fun();console.log('PASS',label)}
check('fund net balance in cents',()=>{const f=ctx.towerTaskFinancialSnapshot(meta,service);assert.equal(f.net,140000);assert.equal(f.remaining,70001)});
check('ready at exact threshold',()=>assert.equal(ctx.towerTaskReadiness({...meta,collected:700},service).ready,true));
check('not ready one piaster before threshold',()=>assert.equal(ctx.towerTaskReadiness(meta,service).ready,false));
check('no readiness before finalization',()=>assert.equal(ctx.towerTaskReadiness(meta,{...service,enrollmentStatus:'CLOSED'}).ready,false));
check('no negative fund snapshot',()=>assert.equal(ctx.towerTaskFinancialSnapshot({...meta,fundContributionPosted:2000},service),null));
check('no invalid dates',()=>assert.equal(ctx.towerTaskReadiness({...meta,startRule:'DATE',executionDate:'2026-02-31'},service).ready,false));
check('no zero cent installments',()=>assert.equal(ctx.towerTaskInstallmentProjection({approvedDues:0.03,installmentCount:4,firstDueDate:'2026-10-01'}).length,0));
check('exact installments',()=>{let rows=ctx.towerTaskInstallmentProjection({approvedDues:1900,installmentCount:7,firstDueDate:'2026-01-31'});assert.equal(rows.length,7);assert.equal(Math.round(rows.reduce((s,r)=>s+r.amount,0)*100),190000)});
check('reject excessive installments',()=>assert.equal(ctx.towerTaskInstallmentProjection({approvedDues:100,installmentCount:37,firstDueDate:'2026-10-01'}).length,0));
check('public mirror',()=>assert.equal(src,fs.readFileSync(__dirname+'/public/app.js','utf8')));
check('financial UI present',()=>assert.match(src,/tower-task-finance-summary/));
