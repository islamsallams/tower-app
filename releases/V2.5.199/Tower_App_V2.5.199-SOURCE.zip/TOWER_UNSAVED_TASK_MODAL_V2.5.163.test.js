const fs=require('fs'),assert=require('node:assert/strict');
const s=fs.readFileSync(__dirname+'/app.js','utf8');
const cases=[
 ['snapshot records form values',s.includes('function towerTaskFormSnapshot()')&&s.includes("querySelectorAll('input,select,textarea')")],
 ['only task plan is guarded',s.includes("querySelector('#taskStageInput')")],
 ['dirty state checks original values',s.includes('JSON.stringify(current)!==JSON.stringify(TOWER_TASK_FORM_BASELINE)')],
 ['cancel prompts before dropping changes',s.includes("window.confirm('فيه تعديلات في خطة المهمة لم يتم حفظها")],
 ['Back cancellation stops loop',s.includes('if(towerModalDepth()===before)return;')],
 ['Back restores modal history on declined exit',s.includes('if(fromHistory&&history.state?.towerPage)history.pushState(')],
 ['parent state survives nested confirmation',s.includes('taskFormBaseline:TOWER_TASK_FORM_BASELINE')&&s.includes('TOWER_TASK_FORM_BASELINE=parent.taskFormBaseline')],
 ['success bypasses unsaved confirmation',s.includes("await run('saveTaskWorkflow',payload);towerAcceptTaskFormChanges();closeModal()")],
 ['refresh warning includes unsaved task values',s.includes('ACTIVE_SAVES>0||towerTaskFormChanged()')],
 ['public app matches source',s===fs.readFileSync(__dirname+'/public/app.js','utf8')],
];
for(const [label,pass] of cases){assert.ok(pass,label);console.log('PASS',label);}console.log(`${cases.length}/${cases.length} PASS`);
