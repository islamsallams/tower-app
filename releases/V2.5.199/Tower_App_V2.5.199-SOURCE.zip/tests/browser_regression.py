"""Real Chromium + actual app assets, isolated test API fixtures; never contacts Supabase."""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(os.environ.get('TOWER_TEST_ROOT', Path(__file__).resolve().parents[1]))

def run():
    outcomes = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
        for width, height in [(390, 844), (1366, 900)]:
            page = browser.new_page(viewport={'width': width, 'height': height})
            page.set_default_timeout(2500)
            dialog_policy={"accept":False}
            page.on("dialog", lambda d: d.accept() if dialog_policy["accept"] else d.dismiss())
            def route(req):
                name = req.request.url.split('?')[0].rsplit('/', 1)[-1] or 'index.html'
                if req.request.url.startswith('http://tower.test/'):
                    if name in ['index.html', 'app.js', 'styles.css']:
                        req.fulfill(path=str(ROOT / name))
                    else:
                        req.fulfill(json={'ok': True, 'result': {'configured': False}})
                else:
                    req.abort()
            page.route('**/*', route)
            page.goto('http://tower.test/')
            page.wait_for_function("typeof openModal==='function'")
            page.evaluate("history.replaceState({towerPage:'services'},'', '#services'); APP.page='services'; APP.ctx={user:{role:'ADMIN'}}")
            def check(name, fn):
                print("RUN", width, name, flush=True)
                try:
                    fn()
                    outcomes.append({'viewport': width, 'check': name, 'status': 'PASS'}); print('PASS',flush=True)
                except Exception as e:
                    outcomes.append({'viewport': width, 'check': name, 'status': 'FAIL', 'details': str(e)})
                finally:
                    dialog_policy['accept']=True
                    page.evaluate("TOWER_OTHER_FORM_BASELINE=null; TOWER_TASK_FORM_BASELINE=null; towerResetModalStack(); history.replaceState({towerPage:'services'},'', '#services')")
                    page.wait_for_timeout(80)
            def nested():
                page.evaluate("openModal('<input id=parent value=kept><button onclick=closeModal()>إغلاق</button>'); document.querySelector('#parent').focus(); window.answer=null; confirmAction({message:'test'}).then(v=>window.answer=v); void 0")
                page.get_by_text('إلغاء', exact=True).click()
                assert page.locator('#parent').input_value() == 'kept'
                assert page.evaluate('window.answer') is False
                assert page.evaluate('document.activeElement.id') == 'parent', 'parent focus was lost'
            check('nested confirmation cancel keeps input and focus', nested)
            def dirty():
                page.evaluate("openModal('<form><input id=dirty value=old><button type=button onclick=closeModal()>إلغاء</button></form>')")
                page.locator('#dirty').fill('new')
                dialog_policy['accept']=False
                page.get_by_text('إلغاء', exact=True).click()
                assert page.locator('#dirty').input_value() == 'new'
                dialog_policy['accept']=True
                page.keyboard.press('Escape')
                assert page.evaluate('towerModalDepth()') == 0
            check('dirty form cancel stays and Escape discard closes', dirty)
            def refresh():
                page.evaluate("openModal('<h3>parent</h3>'); openModal('<h3>list</h3>'); openModal('<h3>refreshed list</h3>',true,true)")
                assert page.evaluate('towerModalDepth()') == 2, 'refresh adds another modal layer'
            check('refresh replaces current modal without stacking', refresh)
            def scroll():
                page.evaluate("openModal('<input id=scrollFocus><div style=height:2000px></div>'); $('modalSheet').scrollTop=240; $('scrollFocus').focus({preventScroll:true}); window.beforeScroll=$('modalSheet').scrollTop; confirmAction({message:'scroll'}); void 0")
                page.get_by_text('إلغاء', exact=True).click()
                assert page.evaluate("$('modalSheet').scrollTop===window.beforeScroll"), 'scroll position lost'
            check('confirmation restores parent scroll', scroll)
            def backdrop():
                page.evaluate("openModal('<form><input id=backdropValue value=old></form>')")
                page.locator('#backdropValue').fill('edited')
                dialog_policy['accept']=False
                page.locator('#modal').click(position={'x':2,'y':2})
                assert page.locator('#backdropValue').input_value()=='edited'
                dialog_policy['accept']=True
                page.locator('#modal').click(position={'x':2,'y':2})
                assert page.evaluate('towerModalDepth()')==0
            check('backdrop warns and respects stay or discard', backdrop)
            def browser_back():
                page.evaluate("openModal('<input id=backParent value=kept>'); confirmAction({message:'back'});void 0")
                page.go_back()
                page.wait_for_function('towerModalDepth()===1')
                assert page.locator('#backParent').input_value()=='kept'
            check('browser Back closes confirmation only', browser_back)
            def file_dirty():
                page.evaluate("openModal('<form><input id=fileEdit type=file></form>')")
                page.locator('#fileEdit').set_input_files({'name':'test.txt','mimeType':'text/plain','buffer':b'fixture'})
                assert page.evaluate('towerOtherFormChanged()'), 'file selection ignored'
            check('file selection is an unsaved change', file_dirty)
            def multi_form():
                page.evaluate("openModal('<form><input value=one></form><form><input id=second value=two></form>')")
                page.locator('#second').fill('changed')
                assert page.evaluate('towerOtherFormChanged()'), 'second form ignored'
            check('unsaved protection includes second form', multi_form)
            def disabled():
                page.evaluate("openModal('<form><input id=conditional value=one></form>'); $('conditional').disabled=true")
                assert not page.evaluate('towerOtherFormChanged()'), 'disabled toggle falsely marks form dirty'
            check('conditional disable does not invent edits', disabled)
            def fixture():
                page.evaluate("""window.fixtureOriginalRun=run;window.fixtureOriginalRender=renderServices;
                window.fixtureService={serviceId:'s1',serviceKind:'ONE_TIME',pricingMode:'SHARED_TOTAL',revenueKind:'PERSONAL_SERVICE',totalBudget:1900,enrollmentStatus:'OPEN',name:'مهمة تجريبية'};
                window.fixtureUnits=[{unitId:'u1',unitNumber:'01',floor:'1',managerName:'أحمد حسن'},{unitId:'u2',unitNumber:'02',floor:'2',managerName:'يوسف علي'},{unitId:'u3',unitNumber:'03',floor:'3',managerName:'سارة محمد'}];
                window.fixtureSubs=fixtureUnits.slice(0,2).map((u,i)=>({...u,serviceId:'s1',subscriptionId:'sub'+(i+1),status:'ACTIVE',quantity:1}));
                SERVICE_UI.services=[fixtureService];SERVICE_UI.units=fixtureUnits;
                window.fixtureCalls=[];renderServices=async()=>{};
                run=async(name,...args)=>{fixtureCalls.push(name);
                  if(name==='getServiceManagerContext')return {service:fixtureService,subscriptions:fixtureSubs,units:fixtureUnits};
                  if(name==='addServiceSubscribers'){for(const uid of args[0].unitIds){const u=fixtureUnits.find(x=>x.unitId===uid);fixtureSubs.push({...u,serviceId:'s1',subscriptionId:'sub-'+uid,status:'ACTIVE',quantity:1})}return {created:args[0].unitIds.length,skipped:0}}
                  if(name==='removeSharedServiceSubscriber'){fixtureSubs=fixtureSubs.filter(x=>x.subscriptionId!==args[1]);return {ok:true}}
                  if(name==='previewSharedServiceAllocation')return {allocations:fixtureSubs.map(x=>({amount:950})),totalBudget:1900};
                  throw Error('Unexpected fixture operation '+name);
                };openModal('<h3>تفاصيل المهمة</h3>');""")
                page.evaluate("openSharedAllocation('s1')")
            def members():
                fixture()
                try:
                    page.locator('#towerSharedSearch').fill('حسن احمد')
                    assert page.locator('#towerSharedMemberList .shared-member-card').count()==1
                    page.locator('#towerSharedSelectVisible').check()
                    page.locator('#towerSharedSearch').fill('يوسف')
                    page.locator('#towerSharedSelectVisible').check()
                    assert page.locator('#towerSharedSelectionCount').inner_text()=='2 محدد'
                    page.locator('#towerSharedRemoveSelected').click()
                    page.get_by_text('إلغاء',exact=True).click()
                    assert page.locator('#towerSharedSearch').input_value()=='يوسف'
                    assert page.locator('#towerSharedSelectionCount').inner_text()=='2 محدد'
                    page.locator('#towerSharedRemoveSelected').click()
                    page.get_by_role('button',name='إزالة 2 وحدة',exact=True).click()
                    page.wait_for_function('fixtureSubs.length===0')
                    page.wait_for_timeout(150)
                    assert page.evaluate('towerModalDepth()')==2, 'refresh retained stale list layer'
                    assert page.locator('#towerSharedMemberTotal').inner_text()=='0'
                finally:
                    page.evaluate('run=fixtureOriginalRun;renderServices=fixtureOriginalRender;void 0')
            check('subscriber Arabic search selection cancel and bulk remove (fixture API)', members)
            def single_remove():
                fixture()
                try:
                    page.locator('.tower-shared-remove-icon').first.click()
                    page.get_by_role('button',name='إزالة المشترك',exact=True).click()
                    page.wait_for_function('fixtureSubs.length===1')
                    page.wait_for_timeout(150)
                    assert page.locator('#towerSharedMemberTotal').inner_text()=='1'
                    assert page.evaluate('towerModalDepth()')==2
                finally:
                    page.evaluate('run=fixtureOriginalRun;renderServices=fixtureOriginalRender;void 0')
            check('single subscriber remove refresh (fixture API)', single_remove)
            def addition():
                fixture()
                try:
                    page.locator('#towerInlinePickerToggle').click()
                    page.get_by_role('checkbox',name='إضافة وحدة 03',exact=True).check()
                    page.locator('#serviceAddSelectedButton').click()
                    page.wait_for_function('fixtureSubs.length===3')
                    page.wait_for_timeout(150)
                    assert page.locator('#towerSharedMemberTotal').inner_text()=='3'
                    assert page.evaluate('towerModalDepth()')==2
                    page.evaluate('closeModal()')
                    page.wait_for_timeout(100)
                    assert page.evaluate('towerModalDepth()')==1
                    assert page.locator('#modalSheet h3').inner_text()=='تفاصيل المهمة'
                    page.evaluate("openSharedAllocation('s1')")
                    assert page.locator('#towerSharedMemberTotal').inner_text()=='3'
                finally:
                    page.evaluate('run=fixtureOriginalRun;renderServices=fixtureOriginalRender;void 0')
            check('subscriber add refresh reopen (fixture API)', addition)
            def readonly():
                fixture()
                try:
                    page.evaluate("fixtureService.enrollmentStatus='CLOSED';openSharedAllocation('s1',true)")
                    assert page.locator('#towerInlinePickerToggle').count()==0
                    assert page.locator('#towerSharedMemberList input').count()==0
                    assert page.locator('#towerSharedRemoveSelected').count()==0
                finally:
                    page.evaluate('run=fixtureOriginalRun;renderServices=fixtureOriginalRender;void 0')
            check('closed enrollment has read-only subscribers (fixture API)', readonly)
            def finalized_report():
                result=page.evaluate("""() => {TASK_WORKFLOW_META.s1={fundContributionProposed:500,fundContributionPosted:300};const d=serviceSubscriberSnapshot({service:{...fixtureService,enrollmentStatus:'FINALIZED'},subscriptions:fixtureSubs});const r=serviceSubscribersReport(d);return r.sections[0].items}""")
                values={r['label']:r['value'] for r in result}
                assert any('المسجلة' in k and '300' in v for k,v in values.items())
                assert any('الصافي' in k and '1,600' in v for k,v in values.items()), str(values)
            check('finalized report uses posted fund not proposal', finalized_report)
            def mutation_cache():
                result=page.evaluate("['postTaskFundContribution','confirmTaskFundReceipt','installTaskInstallments','finalizeSharedServiceAllocation','reopenSharedServiceEnrollment'].every(x=>RPC_MUTATION.test(x))")
                assert result, 'task mutations leave stale RPC cache'
            check('task mutations invalidate cached data', mutation_cache)
            def keyboard():
                page.evaluate("window.testOpen=0; window.testAction=0; openResidentServiceDetails=()=>window.testOpen++; requestService=()=>window.testAction++; document.querySelector('#root').classList.remove('hidden'); document.querySelector('#root').innerHTML=residentServiceCard({serviceId:'s',pricingMode:'SHARED_TOTAL',enrollmentStatus:'OPEN',totalBudget:1900,name:'test'},null)")
                page.get_by_role('button', name='طلب اشتراك', exact=True).focus()
                page.keyboard.press('Enter')
                assert page.evaluate('window.testOpen') == 0, 'button Enter bubbles to card'
                assert page.evaluate('window.testAction') == 1, 'button activation missing'
            check('resident action Enter does not open details', keyboard)
            page.close()
        browser.close()
    output=Path(os.environ.get('TOWER_BROWSER_RESULTS','/tmp/tower-browser-results.json')); output.write_text(json.dumps(outcomes,ensure_ascii=False,indent=2)); print(json.dumps(outcomes, ensure_ascii=False, indent=2))
    return outcomes
if __name__ == '__main__':
    results = run()
    raise SystemExit(any(x['status'] == 'FAIL' for x in results))
