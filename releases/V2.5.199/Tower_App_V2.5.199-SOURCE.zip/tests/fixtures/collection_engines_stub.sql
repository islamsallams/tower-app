-- Isolated contract doubles for legacy FUND routines whose full implementation is not in SQL228.
-- These are NEVER deployed. PERSONAL functions in this suite use the original fixture implementations.
CREATE TABLE fixture_fund_limits(unit_id uuid PRIMARY KEY,amount numeric NOT NULL);
CREATE TABLE fixture_fund_reports(report_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),collector uuid,status text,amount numeric,lines jsonb);
CREATE OR REPLACE FUNCTION public.tower_collection_action(p_token text,p_action text,p_payload jsonb DEFAULT '{}') RETURNS jsonb
LANGUAGE plpgsql AS $f$
DECLARE actor public.tower_users;rid uuid;total numeric;
BEGIN
 SELECT * INTO actor FROM tower_session_user(p_token);
 IF p_action='context' THEN RETURN jsonb_build_object('canCollect',actor.role IN ('UNION','OPERATOR'),'units',
 (SELECT coalesce(jsonb_agg(jsonb_build_object('unitId',f.unit_id,'available',f.amount-coalesce((SELECT sum((x->>'amount')::numeric) FROM fixture_fund_reports r CROSS JOIN jsonb_array_elements(r.lines) x WHERE x->>'unitId'=f.unit_id::text),0))),'[]') FROM fixture_fund_limits f)); END IF;
 IF p_action<>'create' OR actor.role<>'OPERATOR' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 SELECT sum((x->>'amount')::numeric) INTO total FROM jsonb_array_elements(p_payload->'lines') x;
 INSERT INTO fixture_fund_reports(collector,status,amount,lines) VALUES(actor.user_id,'PENDING_APPROVAL',total,p_payload->'lines') RETURNING report_id INTO rid;
 RETURN jsonb_build_object('reportId',rid,'status','PENDING_APPROVAL');
END $f$;
CREATE OR REPLACE FUNCTION public.tower_union_collect_approve(p_token text,p_payload jsonb) RETURNS jsonb
LANGUAGE plpgsql AS $f$
DECLARE actor public.tower_users;rid uuid;total numeric;
BEGIN
 SELECT * INTO actor FROM tower_session_user(p_token);IF actor.role<>'UNION' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 SELECT sum((x->>'amount')::numeric) INTO total FROM jsonb_array_elements(p_payload->'lines') x;
 INSERT INTO fixture_fund_reports(collector,status,amount,lines) VALUES(actor.user_id,'APPROVED',total,p_payload->'lines') RETURNING report_id INTO rid;
 RETURN jsonb_build_object('reportId',rid,'success',true,'approvedTotal',total);
END $f$;
