-- Original SQL228 function definition; no user data. Used by the isolated service accounting test.
CREATE OR REPLACE FUNCTION public.tower_finance_issue_personal_due_internal(p_subscription_id uuid, p_account_id uuid, p_due_date date, p_amount numeric)
 RETURNS TABLE(due_id uuid, advance_applied numeric, amount_outstanding numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_unit_id uuid;
 v_service_id uuid;
 v_due_id uuid;
 v_existing uuid;
 v_amount numeric(16,2);
 v_applied numeric(16,2);
 v_paid_direct numeric(16,2);
 v_paid_adv numeric(16,2);
BEGIN
 IF p_subscription_id IS NULL OR p_account_id IS NULL OR p_due_date IS NULL
  OR p_amount IS NULL OR p_amount<=0 OR p_amount<>round(p_amount,2) THEN
  RAISE EXCEPTION 'INVALID_DUE_REQUEST';
 END IF;
 -- This is an internal function only; RLS tables are not granted to app roles.
 SELECT s.unit_id,s.service_id INTO v_unit_id,v_service_id
  FROM public.tower_service_subscriptions s
  WHERE s.subscription_id=p_subscription_id AND s.status='ACTIVE';
 IF v_unit_id IS NULL THEN RAISE EXCEPTION 'SUBSCRIPTION_NOT_ACTIVE'; END IF;
 -- Serialize every posting and advance application for this unit.
 PERFORM 1 FROM public.tower_units u WHERE u.unit_id=v_unit_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'UNIT_NOT_FOUND'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts a
  WHERE a.account_id=p_account_id AND a.account_kind='PERSONAL_SERVICE'
   AND a.service_id=v_service_id AND a.status='ACTIVE' FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'ACCOUNT_SERVICE_MISMATCH'; END IF;
 -- Fail closed if a caller attempted to bill a historical period to the wrong beneficiary.
 PERFORM 1 FROM public.tower_finance_service_beneficiaries b
  WHERE b.service_id=v_service_id AND b.account_id=p_account_id
   AND b.effective_from<=p_due_date
   AND (b.effective_until IS NULL OR p_due_date<b.effective_until);
 IF NOT FOUND THEN RAISE EXCEPTION 'BENEFICIARY_NOT_EFFECTIVE'; END IF;
 -- Refuse ambiguous beneficiary periods instead of choosing arbitrary one.
 IF (SELECT count(*) FROM public.tower_finance_service_beneficiaries b
      WHERE b.service_id=v_service_id AND b.effective_from<=p_due_date
      AND (b.effective_until IS NULL OR p_due_date<b.effective_until)) <> 1 THEN
  RAISE EXCEPTION 'AMBIGUOUS_BENEFICIARY_PERIOD';
 END IF;
 SELECT d.due_id INTO v_existing FROM public.tower_finance_dues d
  WHERE d.subscription_id=p_subscription_id AND d.due_date=p_due_date
  FOR UPDATE;
 IF v_existing IS NOT NULL THEN RAISE EXCEPTION 'DUPLICATE_SUBSCRIPTION_DUE'; END IF;
 INSERT INTO public.tower_finance_dues(unit_id,account_id,subscription_id,due_date,amount)
  VALUES(v_unit_id,p_account_id,p_subscription_id,p_due_date,p_amount)
  RETURNING tower_finance_dues.due_id INTO v_due_id;
 -- Same DB transaction: no separate advance-consumption step can be forgotten.
 v_applied := public.tower_finance_apply_advances_internal(v_unit_id,p_account_id);
 SELECT COALESCE(sum(app.amount),0) INTO v_paid_direct
  FROM public.tower_finance_applications app
  JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=app.portion_id
  JOIN public.tower_finance_receipts rr ON rr.receipt_id=rp.receipt_id
  WHERE app.due_id=v_due_id AND app.application_kind='DUE' AND rr.receipt_status='POSTED';
 SELECT COALESCE(sum(au.amount),0) INTO v_paid_adv
  FROM public.tower_finance_advance_uses au
  JOIN public.tower_finance_applications ap ON ap.application_id=au.advance_application_id
  JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
  JOIN public.tower_finance_receipts rr ON rr.receipt_id=rp.receipt_id
  WHERE au.due_id=v_due_id AND rr.receipt_status='POSTED';
 v_amount := p_amount-v_paid_direct-v_paid_adv;
 IF v_amount<0 THEN RAISE EXCEPTION 'DUE_OVERPAID'; END IF;
 RETURN QUERY SELECT v_due_id,v_paid_adv,v_amount;
END;$function$
