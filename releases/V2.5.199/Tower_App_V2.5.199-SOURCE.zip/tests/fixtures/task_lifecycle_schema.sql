-- Synthetic test schema generated from SQL228 metadata. No user rows or credentials.
-- Defaults below are explicit fixture defaults; original catalog omitted default expressions.
CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role;
CREATE TABLE public.tower_fund_entries(entry_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),status text DEFAULT 'ACTIVE',entry_type text,amount numeric);
CREATE TABLE public.tower_audit("audit_id" uuid DEFAULT gen_random_uuid() NOT NULL,"actor_id" uuid,"action" text DEFAULT '' NOT NULL,"entity" text,"entity_id" text,"at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_audit_pkey" PRIMARY KEY (audit_id));
CREATE TABLE public.tower_building_allocations("allocation_id" uuid DEFAULT gen_random_uuid() NOT NULL,"charge_id" uuid NOT NULL,"unit_id" uuid NOT NULL,"amount" numeric(14,2) DEFAULT 0 NOT NULL,"paid" numeric(14,2) DEFAULT 0 NOT NULL,"base_amount" numeric(14,2) DEFAULT 0 NOT NULL,"deferred" boolean DEFAULT false NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,CONSTRAINT "tower_building_allocations_amount_check" CHECK (amount >= 0::numeric),CONSTRAINT "tower_building_allocations_charge_id_unit_id_key" UNIQUE (charge_id, unit_id),CONSTRAINT "tower_building_allocations_check" CHECK (paid >= 0::numeric AND paid <= amount),CONSTRAINT "tower_building_allocations_pkey" PRIMARY KEY (allocation_id));
CREATE TABLE public.tower_building_charges("charge_id" uuid DEFAULT gen_random_uuid() NOT NULL,"title" text DEFAULT '' NOT NULL,"category" text DEFAULT '' NOT NULL,"due_date" date,"status" text DEFAULT 'ACTIVE' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,"total_amount" numeric(14,2) DEFAULT 0 NOT NULL,"distribution" text DEFAULT '' NOT NULL,"category_id" uuid,"policy_snapshot" jsonb NOT NULL,"notes" text DEFAULT '' NOT NULL,"period_label" text DEFAULT '' NOT NULL,"created_by" uuid,"service_id" uuid,"subscription_id" uuid,CONSTRAINT "tower_building_charges_pkey" PRIMARY KEY (charge_id),CONSTRAINT "tower_building_charges_status_check" CHECK (status = ANY (ARRAY['ACTIVE'::text, 'CANCELED'::text])));
CREATE TABLE public.tower_building_payments("payment_id" uuid DEFAULT gen_random_uuid() NOT NULL,"charge_id" uuid NOT NULL,"unit_id" uuid NOT NULL,"amount" numeric(14,2) DEFAULT 0 NOT NULL,"method" text DEFAULT '' NOT NULL,"note" text DEFAULT '' NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"report_id" uuid,"fund_entry_id" uuid NOT NULL,"created_by" uuid,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_building_payments_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_building_payments_fund_entry_id_key" UNIQUE (fund_entry_id),CONSTRAINT "tower_building_payments_pkey" PRIMARY KEY (payment_id));
CREATE TABLE public.tower_finance_accounts("account_id" uuid DEFAULT gen_random_uuid() NOT NULL,"account_kind" text DEFAULT '' NOT NULL,"service_id" uuid,"beneficiary_user_id" uuid,"status" text DEFAULT 'ACTIVE' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "finance_account_scope" CHECK (account_kind = 'FUND'::text AND service_id IS NULL AND beneficiary_user_id IS NULL OR account_kind = 'PERSONAL_SERVICE'::text AND service_id IS NOT NULL AND beneficiary_user_id IS NOT NULL),CONSTRAINT "tower_finance_accounts_account_kind_check" CHECK (account_kind = ANY (ARRAY['FUND'::text, 'PERSONAL_SERVICE'::text])),CONSTRAINT "tower_finance_accounts_pkey" PRIMARY KEY (account_id),CONSTRAINT "tower_finance_accounts_status_check" CHECK (status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text])));
CREATE TABLE public.tower_finance_advance_subscription_links("link_id" uuid DEFAULT gen_random_uuid() NOT NULL,"advance_application_id" uuid NOT NULL,"subscription_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"linked_by" uuid NOT NULL,"linked_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_advance_subscri_advance_application_id_subscr_key" UNIQUE (advance_application_id, subscription_id),CONSTRAINT "tower_finance_advance_subscription_links_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_advance_subscription_links_pkey" PRIMARY KEY (link_id));
CREATE TABLE public.tower_finance_advance_use_subscriptions("use_id" uuid DEFAULT gen_random_uuid() NOT NULL,"link_id" uuid NOT NULL,"subscription_id" uuid NOT NULL,"attributed_by" uuid NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_advance_use_subscriptions_pkey" PRIMARY KEY (use_id));
CREATE TABLE public.tower_finance_advance_uses("use_id" uuid DEFAULT gen_random_uuid() NOT NULL,"advance_application_id" uuid NOT NULL,"due_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_advance_uses_advance_application_id_due_id_key" UNIQUE (advance_application_id, due_id),CONSTRAINT "tower_finance_advance_uses_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_advance_uses_pkey" PRIMARY KEY (use_id));
CREATE TABLE public.tower_finance_applications("application_id" uuid DEFAULT gen_random_uuid() NOT NULL,"portion_id" uuid NOT NULL,"due_id" uuid,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"application_kind" text DEFAULT '' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_applications_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_applications_application_kind_check" CHECK (application_kind = ANY (ARRAY['DUE'::text, 'ADVANCE'::text])),CONSTRAINT "tower_finance_applications_check" CHECK (application_kind = 'DUE'::text AND due_id IS NOT NULL OR application_kind = 'ADVANCE'::text AND due_id IS NULL),CONSTRAINT "tower_finance_applications_pkey" PRIMARY KEY (application_id));
CREATE TABLE public.tower_finance_cash_movements("movement_id" uuid DEFAULT gen_random_uuid() NOT NULL,"account_id" uuid NOT NULL,"unit_id" uuid,"movement_kind" text DEFAULT '' NOT NULL,"sender_user_id" uuid NOT NULL,"recipient_user_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"movement_status" text DEFAULT 'PENDING' NOT NULL,"requested_at" timestamp with time zone DEFAULT now() NOT NULL,"confirmed_at" timestamp with time zone,"confirmed_by" uuid,CONSTRAINT "tower_finance_cash_movements_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_cash_movements_check" CHECK (movement_status = 'CONFIRMED'::text AND confirmed_at IS NOT NULL AND confirmed_by IS NOT NULL OR movement_status <> 'CONFIRMED'::text AND confirmed_at IS NULL AND confirmed_by IS NULL),CONSTRAINT "tower_finance_cash_movements_check1" CHECK (sender_user_id <> recipient_user_id),CONSTRAINT "tower_finance_cash_movements_movement_kind_check" CHECK (movement_kind = ANY (ARRAY['BENEFICIARY_DELIVERY'::text, 'BENEFICIARY_HANDOVER'::text, 'UNIT_REFUND'::text])),CONSTRAINT "tower_finance_cash_movements_movement_status_check" CHECK (movement_status = ANY (ARRAY['PENDING'::text, 'CONFIRMED'::text, 'DISPUTED'::text, 'CANCELLED'::text])),CONSTRAINT "tower_finance_cash_movements_pkey" PRIMARY KEY (movement_id));
CREATE TABLE public.tower_finance_dues("due_id" uuid DEFAULT gen_random_uuid() NOT NULL,"unit_id" uuid NOT NULL,"account_id" uuid NOT NULL,"subscription_id" uuid,"due_date" date NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_dues_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_dues_pkey" PRIMARY KEY (due_id),CONSTRAINT "tower_finance_dues_status_check" CHECK (status = ANY (ARRAY['OPEN'::text, 'CANCELLED'::text])));
CREATE TABLE public.tower_finance_mixed_collections("mixed_id" uuid DEFAULT gen_random_uuid() NOT NULL,"external_reference" text DEFAULT '' NOT NULL,"collector_id" uuid NOT NULL,"request_payload" jsonb NOT NULL,"fund_report_id" uuid NOT NULL,"personal_receipt_id" uuid NOT NULL,"fund_amount" numeric(16,2) DEFAULT 0 NOT NULL,"personal_amount" numeric(16,2) DEFAULT 0 NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_mixed_collections_external_reference_key" UNIQUE (external_reference),CONSTRAINT "tower_finance_mixed_collections_fund_amount_check" CHECK (fund_amount > 0::numeric),CONSTRAINT "tower_finance_mixed_collections_personal_amount_check" CHECK (personal_amount > 0::numeric),CONSTRAINT "tower_finance_mixed_collections_pkey" PRIMARY KEY (mixed_id),CONSTRAINT "tower_mixed_reference_size" CHECK (length(external_reference) >= 16 AND length(external_reference) <= 128));
CREATE TABLE public.tower_finance_receipt_portions("portion_id" uuid DEFAULT gen_random_uuid() NOT NULL,"receipt_id" uuid NOT NULL,"account_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,CONSTRAINT "tower_finance_receipt_portions_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_receipt_portions_pkey" PRIMARY KEY (portion_id),CONSTRAINT "tower_finance_receipt_portions_receipt_id_account_id_key" UNIQUE (receipt_id, account_id));
CREATE TABLE public.tower_finance_receipts("receipt_id" uuid DEFAULT gen_random_uuid() NOT NULL,"unit_id" uuid NOT NULL,"collector_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"receipt_status" text DEFAULT 'POSTED' NOT NULL,"external_reference" text DEFAULT '' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_receipts_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_finance_receipts_pkey" PRIMARY KEY (receipt_id),CONSTRAINT "tower_finance_receipts_receipt_status_check" CHECK (receipt_status = ANY (ARRAY['POSTED'::text, 'REVERSED'::text])));
CREATE TABLE public.tower_finance_refund_authorizations("refund_authorization_id" uuid DEFAULT gen_random_uuid() NOT NULL,"unit_id" uuid NOT NULL,"account_id" uuid NOT NULL,"subscription_id" uuid NOT NULL,"max_amount" numeric(16,2) DEFAULT 0 NOT NULL,"approved_by" uuid NOT NULL,"approved_at" timestamp with time zone DEFAULT now() NOT NULL,"effective_date" date NOT NULL,"authorization_status" text DEFAULT 'APPROVED' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_refund_authorizations_authorization_status_check" CHECK (authorization_status = ANY (ARRAY['APPROVED'::text, 'REVOKED'::text])),CONSTRAINT "tower_finance_refund_authorizations_max_amount_check" CHECK (max_amount > 0::numeric),CONSTRAINT "tower_finance_refund_authorizations_pkey" PRIMARY KEY (refund_authorization_id));
CREATE TABLE public.tower_finance_refund_movements("movement_id" uuid DEFAULT gen_random_uuid() NOT NULL,"refund_authorization_id" uuid NOT NULL,CONSTRAINT "tower_finance_refund_movements_pkey" PRIMARY KEY (movement_id));
CREATE TABLE public.tower_finance_service_beneficiaries("beneficiary_period_id" uuid DEFAULT gen_random_uuid() NOT NULL,"service_id" uuid NOT NULL,"account_id" uuid NOT NULL,"effective_from" date NOT NULL,"effective_until" date,"assigned_by" uuid NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_finance_service_beneficiaries_check" CHECK (effective_until IS NULL OR effective_until > effective_from),CONSTRAINT "tower_finance_service_beneficiaries_pkey" PRIMARY KEY (beneficiary_period_id));
CREATE TABLE public.tower_members("member_id" uuid DEFAULT gen_random_uuid() NOT NULL,"unit_id" uuid NOT NULL,"user_id" uuid NOT NULL,"member_role" text DEFAULT '' NOT NULL,"ended_at" timestamp with time zone,"relation" text DEFAULT '' NOT NULL,"joined_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_members_member_role_check" CHECK (member_role = ANY (ARRAY['MANAGER'::text, 'MEMBER'::text])),CONSTRAINT "tower_members_pkey" PRIMARY KEY (member_id),CONSTRAINT "tower_members_unit_id_user_id_key" UNIQUE (unit_id, user_id));
CREATE TABLE public.tower_service_change_requests("request_id" uuid DEFAULT gen_random_uuid() NOT NULL,"subscription_id" uuid NOT NULL,"service_id" uuid NOT NULL,"unit_id" uuid NOT NULL,"requested_by" uuid NOT NULL,"type" text DEFAULT '' NOT NULL,"quantity_delta" integer DEFAULT 0 NOT NULL,"requested_quantity" integer DEFAULT 0 NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"requested_at" timestamp with time zone DEFAULT now() NOT NULL,"reviewed_at" timestamp with time zone,"reviewed_by" uuid,"notes" text DEFAULT '' NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_service_change_requests_pkey" PRIMARY KEY (request_id),CONSTRAINT "tower_service_change_requests_quantity_delta_check" CHECK (quantity_delta <> 0),CONSTRAINT "tower_service_change_requests_requested_quantity_check" CHECK (requested_quantity >= 0 AND requested_quantity <= 99),CONSTRAINT "tower_service_change_requests_status_check" CHECK (status = ANY (ARRAY['PENDING'::text, 'APPROVED'::text, 'REJECTED'::text])),CONSTRAINT "tower_service_change_requests_type_check" CHECK (type = ANY (ARRAY['ADD'::text, 'REDUCE'::text])));
CREATE TABLE public.tower_service_subscriptions("subscription_id" uuid DEFAULT gen_random_uuid() NOT NULL,"service_id" uuid NOT NULL,"unit_id" uuid NOT NULL,"requested_by" uuid NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"quantity" integer DEFAULT 1 NOT NULL,"unit_price_snapshot" numeric(14,2) DEFAULT 0 NOT NULL,"amount_snapshot" numeric(14,2) DEFAULT 0 NOT NULL,"billing_timing" text DEFAULT 'POSTPAID' NOT NULL,"auto_renew" boolean DEFAULT false NOT NULL,"requested_at" timestamp with time zone DEFAULT now() NOT NULL,"reviewed_at" timestamp with time zone,"reviewed_by" uuid,"started_at" timestamp with time zone,"ended_at" timestamp with time zone,"next_renewal_at" date,"notes" text DEFAULT '' NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_service_subscriptions_amount_snapshot_check" CHECK (amount_snapshot >= 0::numeric),CONSTRAINT "tower_service_subscriptions_billing_timing_check" CHECK (billing_timing = ANY (ARRAY['PREPAID'::text, 'POSTPAID'::text])),CONSTRAINT "tower_service_subscriptions_pkey" PRIMARY KEY (subscription_id),CONSTRAINT "tower_service_subscriptions_quantity_check" CHECK (status = 'ENDED'::text AND quantity >= 0 AND quantity <= 99 OR status <> 'ENDED'::text AND quantity >= 1 AND quantity <= 99),CONSTRAINT "tower_service_subscriptions_status_check" CHECK (status = ANY (ARRAY['PENDING'::text, 'ACTIVE'::text, 'REJECTED'::text, 'ENDED'::text])),CONSTRAINT "tower_service_subscriptions_unit_price_snapshot_check" CHECK (unit_price_snapshot >= 0::numeric));
CREATE TABLE public.tower_services("service_id" uuid DEFAULT gen_random_uuid() NOT NULL,"name" text DEFAULT '' NOT NULL,"description" text DEFAULT '' NOT NULL,"price" numeric(14,2) DEFAULT 0 NOT NULL,"billing_timing" text DEFAULT 'POSTPAID' NOT NULL,"allow_quantity" boolean DEFAULT false NOT NULL,"cancelable" boolean DEFAULT false NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,"service_kind" text DEFAULT 'RECURRING' NOT NULL,"pricing_mode" text DEFAULT 'PER_SUBSCRIPTION' NOT NULL,"total_budget" numeric(14,2),"enrollment_status" text DEFAULT 'OPEN' NOT NULL,CONSTRAINT "tower_services_billing_timing_check" CHECK (billing_timing = ANY (ARRAY['PREPAID'::text, 'POSTPAID'::text])),CONSTRAINT "tower_services_budget_guard_199" CHECK (pricing_mode = 'PER_SUBSCRIPTION'::text AND total_budget IS NULL OR pricing_mode = 'SHARED_TOTAL'::text AND service_kind = 'ONE_TIME'::text AND total_budget > 0::numeric),CONSTRAINT "tower_services_enrollment_guard_199" CHECK (enrollment_status = ANY (ARRAY['OPEN'::text, 'CLOSED'::text, 'FINALIZED'::text])),CONSTRAINT "tower_services_kind_guard_199" CHECK (service_kind = ANY (ARRAY['RECURRING'::text, 'ONE_TIME'::text])),CONSTRAINT "tower_services_pkey" PRIMARY KEY (service_id),CONSTRAINT "tower_services_price_check" CHECK (price >= 0::numeric),CONSTRAINT "tower_services_pricing_guard_199" CHECK (pricing_mode = ANY (ARRAY['PER_SUBSCRIPTION'::text, 'SHARED_TOTAL'::text])),CONSTRAINT "tower_services_status_check" CHECK (status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text])));
CREATE TABLE public.tower_sessions("session_id" uuid DEFAULT gen_random_uuid() NOT NULL,"user_id" uuid NOT NULL,"token_hash" text DEFAULT '' NOT NULL,"credential_version" integer DEFAULT 0 NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"expires_at" timestamp with time zone DEFAULT now() NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_sessions_pkey" PRIMARY KEY (session_id),CONSTRAINT "tower_sessions_token_hash_key" UNIQUE (token_hash));
CREATE TABLE public.tower_task_due_installments("due_id" uuid NOT NULL,"installment_no" integer DEFAULT 0 NOT NULL,"due_date" date NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_task_due_installments_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_task_due_installments_installment_no_check" CHECK (installment_no >= 1 AND installment_no <= 36),CONSTRAINT "tower_task_due_installments_pkey" PRIMARY KEY (due_id, installment_no));
CREATE TABLE public.tower_task_event_reads("user_id" uuid NOT NULL,"service_id" uuid NOT NULL,"last_read_event_id" bigint DEFAULT 0 NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_task_event_reads_last_read_event_id_check" CHECK (last_read_event_id >= 0),CONSTRAINT "tower_task_event_reads_pkey" PRIMARY KEY (user_id, service_id));
CREATE TABLE public.tower_task_events("event_id" bigint GENERATED BY DEFAULT AS IDENTITY NOT NULL,"service_id" uuid NOT NULL,"event_kind" text DEFAULT '' NOT NULL,"message" text DEFAULT '' NOT NULL,"occurred_at" timestamp with time zone DEFAULT now() NOT NULL,"actor_id" uuid,CONSTRAINT "tower_task_events_event_kind_check" CHECK (event_kind = ANY (ARRAY['STAGE_CHANGED'::text, 'EXECUTION_UPDATED'::text, 'PLAN_UPDATED'::text, 'READY_FOR_EXECUTION'::text, 'FINANCE_UPDATED'::text])),CONSTRAINT "tower_task_events_pkey" PRIMARY KEY (event_id));
CREATE TABLE public.tower_task_fund_contributions("service_id" uuid DEFAULT gen_random_uuid() NOT NULL,"fund_entry_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"posted_by" uuid NOT NULL,"posted_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_task_fund_contributions_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_task_fund_contributions_fund_entry_id_key" UNIQUE (fund_entry_id),CONSTRAINT "tower_task_fund_contributions_pkey" PRIMARY KEY (service_id));
CREATE TABLE public.tower_task_fund_receipts("service_id" uuid DEFAULT gen_random_uuid() NOT NULL,"account_id" uuid NOT NULL,"amount" numeric(16,2) DEFAULT 0 NOT NULL,"confirmed_by" uuid NOT NULL,"confirmed_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_task_fund_receipts_amount_check" CHECK (amount > 0::numeric),CONSTRAINT "tower_task_fund_receipts_pkey" PRIMARY KEY (service_id));
CREATE TABLE public.tower_task_workflow("service_id" uuid DEFAULT gen_random_uuid() NOT NULL,"stage" text DEFAULT 'COLLECT_SUBSCRIBERS' NOT NULL,"execution_date" date,"start_rule" text DEFAULT 'MANUAL' NOT NULL,"collection_threshold" integer DEFAULT 100 NOT NULL,"execution_percent" integer DEFAULT 0 NOT NULL,"installment_count" integer DEFAULT 1 NOT NULL,"first_due_date" date,"fund_contribution_proposed" numeric(16,2) DEFAULT 0 NOT NULL,"revision" bigint DEFAULT 0 NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,"updated_by" uuid,CONSTRAINT "tower_task_workflow_collection_threshold_check" CHECK (collection_threshold >= 1 AND collection_threshold <= 100),CONSTRAINT "tower_task_workflow_execution_percent_check" CHECK (execution_percent >= 0 AND execution_percent <= 100),CONSTRAINT "tower_task_workflow_fund_contribution_proposed_check" CHECK (fund_contribution_proposed >= 0::numeric),CONSTRAINT "tower_task_workflow_installment_count_check" CHECK (installment_count >= 1 AND installment_count <= 36),CONSTRAINT "tower_task_workflow_pkey" PRIMARY KEY (service_id),CONSTRAINT "tower_task_workflow_stage_check" CHECK (stage = ANY (ARRAY['COLLECT_SUBSCRIBERS'::text, 'COLLECT_FUNDS'::text, 'READY'::text, 'IN_PROGRESS'::text, 'COMPLETED'::text])),CONSTRAINT "tower_task_workflow_start_rule_check" CHECK (start_rule = ANY (ARRAY['MANUAL'::text, 'DATE'::text, 'COLLECTION'::text, 'DATE_AND_COLLECTION'::text])));
CREATE TABLE public.tower_telegram_accounts("user_id" uuid DEFAULT gen_random_uuid() NOT NULL,"chat_id" text DEFAULT '' NOT NULL,"enabled" boolean DEFAULT false NOT NULL,"show_amounts" boolean DEFAULT false NOT NULL,"linked_at" timestamp with time zone DEFAULT now() NOT NULL,"daily_digest_enabled" boolean DEFAULT false NOT NULL,CONSTRAINT "tower_telegram_accounts_pkey" PRIMARY KEY (user_id));
CREATE TABLE public.tower_units("unit_id" uuid DEFAULT gen_random_uuid() NOT NULL,"unit_number" text DEFAULT '' NOT NULL,"floor" text,"unit_type_id" uuid NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"updated_at" timestamp with time zone DEFAULT now() NOT NULL,CONSTRAINT "tower_units_pkey" PRIMARY KEY (unit_id),CONSTRAINT "tower_units_unit_number_key" UNIQUE (unit_number));
CREATE TABLE public.tower_users("user_id" uuid DEFAULT gen_random_uuid() NOT NULL,"login_id" text DEFAULT '' NOT NULL,"name" text DEFAULT '' NOT NULL,"title" text DEFAULT '' NOT NULL,"role" text DEFAULT '' NOT NULL,"status" text DEFAULT 'ACTIVE' NOT NULL,"pin_hash" text DEFAULT '' NOT NULL,"must_change_pin" boolean DEFAULT false NOT NULL,"credential_version" integer DEFAULT 0 NOT NULL,"created_at" timestamp with time zone DEFAULT now() NOT NULL,"title_id" uuid,"custom_title" text DEFAULT '' NOT NULL,"phone" text,"email" text,CONSTRAINT "tower_users_login_id_key" UNIQUE (login_id),CONSTRAINT "tower_users_pkey" PRIMARY KEY (user_id),CONSTRAINT "tower_users_role_check" CHECK (role = ANY (ARRAY['ADMIN'::text, 'UNION'::text, 'RESIDENT'::text, 'OPERATOR'::text])),CONSTRAINT "tower_users_status_check" CHECK (status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'ARCHIVED'::text])));
ALTER TABLE public.tower_audit ADD CONSTRAINT "tower_audit_actor_id_fkey" FOREIGN KEY (actor_id) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_building_allocations ADD CONSTRAINT "tower_building_allocations_charge_id_fkey" FOREIGN KEY (charge_id) REFERENCES tower_building_charges(charge_id);
ALTER TABLE public.tower_building_allocations ADD CONSTRAINT "tower_building_allocations_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id);
ALTER TABLE public.tower_building_charges ADD CONSTRAINT "tower_building_charges_created_by_fkey" FOREIGN KEY (created_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_building_charges ADD CONSTRAINT "tower_building_charges_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id);
ALTER TABLE public.tower_building_charges ADD CONSTRAINT "tower_building_charges_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id);
CREATE UNIQUE INDEX tower_service_due_once_per_period ON public.tower_building_charges USING btree (subscription_id, period_label) WHERE (subscription_id IS NOT NULL);
ALTER TABLE public.tower_building_payments ADD CONSTRAINT "tower_building_payments_charge_id_fkey" FOREIGN KEY (charge_id) REFERENCES tower_building_charges(charge_id);
ALTER TABLE public.tower_building_payments ADD CONSTRAINT "tower_building_payments_created_by_fkey" FOREIGN KEY (created_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_building_payments ADD CONSTRAINT "tower_building_payments_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id);
ALTER TABLE public.tower_finance_accounts ADD CONSTRAINT "tower_finance_accounts_beneficiary_user_id_fkey" FOREIGN KEY (beneficiary_user_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_accounts ADD CONSTRAINT "tower_finance_accounts_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
CREATE UNIQUE INDEX tower_finance_one_fund_idx ON public.tower_finance_accounts USING btree (account_kind) WHERE (account_kind = 'FUND'::text);
ALTER TABLE public.tower_finance_advance_subscription_links ADD CONSTRAINT "tower_finance_advance_subscription__advance_application_id_fkey" FOREIGN KEY (advance_application_id) REFERENCES tower_finance_applications(application_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_subscription_links ADD CONSTRAINT "tower_finance_advance_subscription_links_linked_by_fkey" FOREIGN KEY (linked_by) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_subscription_links ADD CONSTRAINT "tower_finance_advance_subscription_links_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_use_subscriptions ADD CONSTRAINT "tower_finance_advance_use_subscriptions_attributed_by_fkey" FOREIGN KEY (attributed_by) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_use_subscriptions ADD CONSTRAINT "tower_finance_advance_use_subscriptions_link_id_fkey" FOREIGN KEY (link_id) REFERENCES tower_finance_advance_subscription_links(link_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_use_subscriptions ADD CONSTRAINT "tower_finance_advance_use_subscriptions_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_use_subscriptions ADD CONSTRAINT "tower_finance_advance_use_subscriptions_use_id_fkey" FOREIGN KEY (use_id) REFERENCES tower_finance_advance_uses(use_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_uses ADD CONSTRAINT "tower_finance_advance_uses_advance_application_id_fkey" FOREIGN KEY (advance_application_id) REFERENCES tower_finance_applications(application_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_advance_uses ADD CONSTRAINT "tower_finance_advance_uses_due_id_fkey" FOREIGN KEY (due_id) REFERENCES tower_finance_dues(due_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_applications ADD CONSTRAINT "tower_finance_applications_due_id_fkey" FOREIGN KEY (due_id) REFERENCES tower_finance_dues(due_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_applications ADD CONSTRAINT "tower_finance_applications_portion_id_fkey" FOREIGN KEY (portion_id) REFERENCES tower_finance_receipt_portions(portion_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_cash_movements ADD CONSTRAINT "tower_finance_cash_movements_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_cash_movements ADD CONSTRAINT "tower_finance_cash_movements_confirmed_by_fkey" FOREIGN KEY (confirmed_by) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_cash_movements ADD CONSTRAINT "tower_finance_cash_movements_recipient_user_id_fkey" FOREIGN KEY (recipient_user_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_cash_movements ADD CONSTRAINT "tower_finance_cash_movements_sender_user_id_fkey" FOREIGN KEY (sender_user_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_cash_movements ADD CONSTRAINT "tower_finance_cash_movements_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_dues ADD CONSTRAINT "tower_finance_dues_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_dues ADD CONSTRAINT "tower_finance_dues_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_dues ADD CONSTRAINT "tower_finance_dues_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id) ON DELETE RESTRICT;
CREATE UNIQUE INDEX tower_finance_subscription_due_once_idx ON public.tower_finance_dues USING btree (subscription_id, due_date) WHERE (subscription_id IS NOT NULL);
ALTER TABLE public.tower_finance_mixed_collections ADD CONSTRAINT "tower_finance_mixed_collections_collector_id_fkey" FOREIGN KEY (collector_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_mixed_collections ADD CONSTRAINT "tower_finance_mixed_collections_personal_receipt_id_fkey" FOREIGN KEY (personal_receipt_id) REFERENCES tower_finance_receipts(receipt_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_receipt_portions ADD CONSTRAINT "tower_finance_receipt_portions_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_receipt_portions ADD CONSTRAINT "tower_finance_receipt_portions_receipt_id_fkey" FOREIGN KEY (receipt_id) REFERENCES tower_finance_receipts(receipt_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_receipts ADD CONSTRAINT "tower_finance_receipts_collector_id_fkey" FOREIGN KEY (collector_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_receipts ADD CONSTRAINT "tower_finance_receipts_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id) ON DELETE RESTRICT;
CREATE UNIQUE INDEX tower_finance_receipt_external_ref_once_idx ON public.tower_finance_receipts USING btree (btrim(external_reference)) WHERE ((btrim(external_reference) <> ''::text) AND (receipt_status = ANY (ARRAY['POSTED'::text, 'REVERSED'::text])));
ALTER TABLE public.tower_finance_refund_authorizations ADD CONSTRAINT "tower_finance_refund_authorizations_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_refund_authorizations ADD CONSTRAINT "tower_finance_refund_authorizations_approved_by_fkey" FOREIGN KEY (approved_by) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_refund_authorizations ADD CONSTRAINT "tower_finance_refund_authorizations_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_refund_authorizations ADD CONSTRAINT "tower_finance_refund_authorizations_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_refund_movements ADD CONSTRAINT "tower_finance_refund_movements_movement_id_fkey" FOREIGN KEY (movement_id) REFERENCES tower_finance_cash_movements(movement_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_refund_movements ADD CONSTRAINT "tower_finance_refund_movements_refund_authorization_id_fkey" FOREIGN KEY (refund_authorization_id) REFERENCES tower_finance_refund_authorizations(refund_authorization_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_service_beneficiaries ADD CONSTRAINT "tower_finance_service_beneficiaries_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_service_beneficiaries ADD CONSTRAINT "tower_finance_service_beneficiaries_assigned_by_fkey" FOREIGN KEY (assigned_by) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_finance_service_beneficiaries ADD CONSTRAINT "tower_finance_service_beneficiaries_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_members ADD CONSTRAINT "tower_members_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id);
ALTER TABLE public.tower_members ADD CONSTRAINT "tower_members_user_id_fkey" FOREIGN KEY (user_id) REFERENCES tower_users(user_id);
CREATE UNIQUE INDEX tower_one_manager_per_unit ON public.tower_members USING btree (unit_id) WHERE ((member_role = 'MANAGER'::text) AND (ended_at IS NULL));
CREATE UNIQUE INDEX tower_one_active_membership_pair ON public.tower_members USING btree (user_id, unit_id) WHERE (ended_at IS NULL);
ALTER TABLE public.tower_service_change_requests ADD CONSTRAINT "tower_service_change_requests_requested_by_fkey" FOREIGN KEY (requested_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_service_change_requests ADD CONSTRAINT "tower_service_change_requests_reviewed_by_fkey" FOREIGN KEY (reviewed_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_service_change_requests ADD CONSTRAINT "tower_service_change_requests_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id);
ALTER TABLE public.tower_service_change_requests ADD CONSTRAINT "tower_service_change_requests_subscription_id_fkey" FOREIGN KEY (subscription_id) REFERENCES tower_service_subscriptions(subscription_id);
ALTER TABLE public.tower_service_change_requests ADD CONSTRAINT "tower_service_change_requests_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id);
CREATE UNIQUE INDEX tower_one_pending_service_change ON public.tower_service_change_requests USING btree (subscription_id) WHERE (status = 'PENDING'::text);
ALTER TABLE public.tower_service_subscriptions ADD CONSTRAINT "tower_service_subscriptions_requested_by_fkey" FOREIGN KEY (requested_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_service_subscriptions ADD CONSTRAINT "tower_service_subscriptions_reviewed_by_fkey" FOREIGN KEY (reviewed_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_service_subscriptions ADD CONSTRAINT "tower_service_subscriptions_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id);
ALTER TABLE public.tower_service_subscriptions ADD CONSTRAINT "tower_service_subscriptions_unit_id_fkey" FOREIGN KEY (unit_id) REFERENCES tower_units(unit_id);
CREATE UNIQUE INDEX tower_service_one_live_subscription ON public.tower_service_subscriptions USING btree (service_id, unit_id) WHERE (status = ANY (ARRAY['PENDING'::text, 'ACTIVE'::text]));
ALTER TABLE public.tower_sessions ADD CONSTRAINT "tower_sessions_user_id_fkey" FOREIGN KEY (user_id) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_task_due_installments ADD CONSTRAINT "tower_task_due_installments_due_id_fkey" FOREIGN KEY (due_id) REFERENCES tower_finance_dues(due_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_event_reads ADD CONSTRAINT "tower_task_event_reads_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_event_reads ADD CONSTRAINT "tower_task_event_reads_user_id_fkey" FOREIGN KEY (user_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_events ADD CONSTRAINT "tower_task_events_actor_id_fkey" FOREIGN KEY (actor_id) REFERENCES tower_users(user_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_events ADD CONSTRAINT "tower_task_events_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_fund_contributions ADD CONSTRAINT "tower_task_fund_contributions_posted_by_fkey" FOREIGN KEY (posted_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_task_fund_contributions ADD CONSTRAINT "tower_task_fund_contributions_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_fund_receipts ADD CONSTRAINT "tower_task_fund_receipts_account_id_fkey" FOREIGN KEY (account_id) REFERENCES tower_finance_accounts(account_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_fund_receipts ADD CONSTRAINT "tower_task_fund_receipts_confirmed_by_fkey" FOREIGN KEY (confirmed_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_task_fund_receipts ADD CONSTRAINT "tower_task_fund_receipts_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_task_fund_contributions(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_workflow ADD CONSTRAINT "tower_task_workflow_service_id_fkey" FOREIGN KEY (service_id) REFERENCES tower_services(service_id) ON DELETE RESTRICT;
ALTER TABLE public.tower_task_workflow ADD CONSTRAINT "tower_task_workflow_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES tower_users(user_id);
ALTER TABLE public.tower_telegram_accounts ADD CONSTRAINT "tower_telegram_accounts_user_id_fkey" FOREIGN KEY (user_id) REFERENCES tower_users(user_id) ON DELETE CASCADE;
CREATE OR REPLACE FUNCTION public.tower_finance_apply_advances_internal(p_unit_id uuid, p_account_id uuid)
 RETURNS numeric
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_due record;
 v_advance record;
 v_link record;
 v_due_left numeric(16,2);
 v_advance_left numeric(16,2);
 v_link_left numeric(16,2);
 v_apply numeric(16,2);
 v_total numeric(16,2):=0;
 v_use_id uuid;
BEGIN
 IF p_unit_id IS NULL OR p_account_id IS NULL THEN RAISE EXCEPTION 'MISSING_SCOPE'; END IF;
 PERFORM 1 FROM public.tower_units WHERE unit_id=p_unit_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'UNIT_NOT_FOUND'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts
  WHERE account_id=p_account_id AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE' FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_PERSONAL_ACCOUNT'; END IF;
 -- Abort rather than silently trusting earlier advance uses lacking an exact subscription.
 IF EXISTS (
  SELECT 1 FROM public.tower_finance_advance_uses u
  JOIN public.tower_finance_applications a ON a.application_id=u.advance_application_id
  JOIN public.tower_finance_receipt_portions p ON p.portion_id=a.portion_id
  JOIN public.tower_finance_receipts r ON r.receipt_id=p.receipt_id
  LEFT JOIN public.tower_finance_advance_use_subscriptions x ON x.use_id=u.use_id
  WHERE r.unit_id=p_unit_id AND p.account_id=p_account_id AND x.use_id IS NULL
 ) THEN RAISE EXCEPTION 'UNATTRIBUTED_HISTORIC_ADVANCE_USE'; END IF;
 FOR v_due IN
  SELECT d.due_id,d.subscription_id,d.amount FROM public.tower_finance_dues d
  WHERE d.unit_id=p_unit_id AND d.account_id=p_account_id AND d.status='OPEN'
  ORDER BY d.due_date,d.due_id FOR UPDATE OF d
 LOOP
  IF v_due.subscription_id IS NULL THEN RAISE EXCEPTION 'DUE_SUBSCRIPTION_REQUIRED'; END IF;
  SELECT v_due.amount
   - COALESCE((SELECT sum(a.amount) FROM public.tower_finance_applications a
     JOIN public.tower_finance_receipt_portions p ON p.portion_id=a.portion_id
     JOIN public.tower_finance_receipts r ON r.receipt_id=p.receipt_id
     WHERE a.due_id=v_due.due_id AND a.application_kind='DUE' AND r.receipt_status='POSTED'),0)
   - COALESCE((SELECT sum(u.amount) FROM public.tower_finance_advance_uses u
     WHERE u.due_id=v_due.due_id),0) INTO v_due_left;
  IF v_due_left<0 THEN RAISE EXCEPTION 'OVERPAID_DUE_IN_LEDGER'; END IF;
  IF v_due_left=0 THEN CONTINUE; END IF;
  FOR v_advance IN
   SELECT a.application_id,a.amount,r.created_at,r.receipt_id
   FROM public.tower_finance_applications a
   JOIN public.tower_finance_receipt_portions p ON p.portion_id=a.portion_id
   JOIN public.tower_finance_receipts r ON r.receipt_id=p.receipt_id
   WHERE a.application_kind='ADVANCE' AND a.due_id IS NULL
    AND p.account_id=p_account_id AND r.unit_id=p_unit_id AND r.receipt_status='POSTED'
   ORDER BY r.created_at,r.receipt_id,a.application_id FOR UPDATE OF a
  LOOP
   SELECT v_advance.amount-COALESCE(sum(u.amount),0) INTO v_advance_left
   FROM public.tower_finance_advance_uses u
   WHERE u.advance_application_id=v_advance.application_id;
   IF v_advance_left<0 THEN RAISE EXCEPTION 'OVERUSED_ADVANCE_IN_LEDGER'; END IF;
   IF v_advance_left=0 THEN CONTINUE; END IF;
   -- Link eligibility is subscription-specific; never spend another subscription's advance.
   FOR v_link IN
    SELECT l.link_id,l.amount,l.linked_by FROM public.tower_finance_advance_subscription_links l
    WHERE l.advance_application_id=v_advance.application_id
     AND l.subscription_id=v_due.subscription_id ORDER BY l.link_id FOR UPDATE OF l
   LOOP
    SELECT v_link.amount-COALESCE(sum(u.amount),0) INTO v_link_left
     FROM public.tower_finance_advance_use_subscriptions x
     JOIN public.tower_finance_advance_uses u ON u.use_id=x.use_id
     WHERE x.link_id=v_link.link_id;
    IF v_link_left<0 THEN RAISE EXCEPTION 'ATTRIBUTION_LINK_OVERUSED'; END IF;
    v_apply:=LEAST(v_due_left,v_advance_left,v_link_left);
    IF v_apply>0 THEN
     INSERT INTO public.tower_finance_advance_uses(advance_application_id,due_id,amount)
      VALUES(v_advance.application_id,v_due.due_id,v_apply) RETURNING use_id INTO v_use_id;
     -- Any trigger failure rolls back the use as part of this very same transaction.
     INSERT INTO public.tower_finance_advance_use_subscriptions(use_id,link_id,subscription_id,attributed_by)
      VALUES(v_use_id,v_link.link_id,v_due.subscription_id,v_link.linked_by);
     v_total:=v_total+v_apply;
     v_due_left:=v_due_left-v_apply;
     v_advance_left:=v_advance_left-v_apply;
    END IF;
    EXIT WHEN v_due_left=0 OR v_advance_left=0;
   END LOOP;
   EXIT WHEN v_due_left=0;
  END LOOP;
 END LOOP;
 RETURN v_total;
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_cancel_unit_refund_internal(p_movement_id uuid, p_sender_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_account_id uuid;
 v_m public.tower_finance_cash_movements%ROWTYPE;
BEGIN
 IF p_movement_id IS NULL OR p_sender_id IS NULL THEN RAISE EXCEPTION 'INVALID_REFUND_CANCELLATION'; END IF;
 SELECT account_id INTO v_account_id FROM public.tower_finance_cash_movements WHERE movement_id=p_movement_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_MOVEMENT_NOT_FOUND'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts WHERE account_id=v_account_id
  AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'PERSONAL_ACCOUNT_NOT_FOUND'; END IF;
 SELECT * INTO v_m FROM public.tower_finance_cash_movements WHERE movement_id=p_movement_id FOR UPDATE;
 IF NOT FOUND OR v_m.account_id<>v_account_id OR v_m.movement_kind<>'UNIT_REFUND' THEN
  RAISE EXCEPTION 'INVALID_REFUND_MOVEMENT'; END IF;
 PERFORM 1 FROM public.tower_finance_refund_movements WHERE movement_id=p_movement_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_APPROVAL_LINK_MISSING'; END IF;
 IF v_m.sender_user_id<>p_sender_id THEN RAISE EXCEPTION 'REFUND_ONLY_SENDER_CAN_CANCEL'; END IF;
 IF v_m.movement_status<>'PENDING' THEN RAISE EXCEPTION 'REFUND_CANNOT_CANCEL_AFTER_CONFIRMATION'; END IF;
 UPDATE public.tower_finance_cash_movements SET movement_status='CANCELLED' WHERE movement_id=p_movement_id;
 RETURN 'CANCELLED';
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_confirm_movement_internal(p_movement_id uuid, p_confirmed_user_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_account_id uuid;
 v public.tower_finance_cash_movements%ROWTYPE;
BEGIN
 IF p_movement_id IS NULL OR p_confirmed_user_id IS NULL THEN
   RAISE EXCEPTION 'INVALID_MOVEMENT_CONFIRMATION';
 END IF;
 -- Read account pointer WITHOUT a movement row lock; account->movement order
 -- avoids deadlocks with the account-locked reservation writer.
 SELECT account_id INTO v_account_id
 FROM public.tower_finance_cash_movements WHERE movement_id=p_movement_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'MOVEMENT_NOT_FOUND'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts
 WHERE account_id=v_account_id AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE'
 FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'PERSONAL_ACCOUNT_NOT_FOUND'; END IF;
 SELECT * INTO v FROM public.tower_finance_cash_movements
 WHERE movement_id=p_movement_id FOR UPDATE;
 IF NOT FOUND OR v.account_id<>v_account_id THEN
   RAISE EXCEPTION 'MOVEMENT_CHANGED_DURING_CONFIRMATION';
 END IF;
 IF v.movement_status<>'PENDING' THEN RAISE EXCEPTION 'MOVEMENT_NOT_PENDING'; END IF;
 IF v.recipient_user_id<>p_confirmed_user_id THEN
   RAISE EXCEPTION 'MOVEMENT_CONFIRMATION_NOT_RECIPIENT';
 END IF;
 IF v.movement_kind='UNIT_REFUND' THEN
   RAISE EXCEPTION 'REFUND_REQUIRES_UNIT_MANAGER_CONFIRMATION';
 END IF;
 IF v.movement_kind NOT IN ('BENEFICIARY_DELIVERY','BENEFICIARY_HANDOVER') THEN
   RAISE EXCEPTION 'UNSUPPORTED_MOVEMENT_KIND';
 END IF;
 IF v.sender_user_id=v.recipient_user_id THEN
   RAISE EXCEPTION 'MOVEMENT_SELF_TRANSFER_FORBIDDEN';
 END IF;
 UPDATE public.tower_finance_cash_movements SET
  movement_status='CONFIRMED', confirmed_at=now(), confirmed_by=p_confirmed_user_id
 WHERE movement_id=p_movement_id;
 RETURN 'CONFIRMED';
END;
$function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_confirm_unit_refund_internal(p_movement_id uuid, p_manager_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_account_id uuid;
 v_m public.tower_finance_cash_movements%ROWTYPE;
BEGIN
 IF p_movement_id IS NULL OR p_manager_id IS NULL THEN RAISE EXCEPTION 'INVALID_REFUND_CONFIRMATION'; END IF;
 SELECT account_id INTO v_account_id FROM public.tower_finance_cash_movements WHERE movement_id=p_movement_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_MOVEMENT_NOT_FOUND'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts WHERE account_id=v_account_id AND account_kind='PERSONAL_SERVICE'
 AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'PERSONAL_ACCOUNT_NOT_FOUND'; END IF;
 SELECT * INTO v_m FROM public.tower_finance_cash_movements WHERE movement_id=p_movement_id FOR UPDATE;
 IF NOT FOUND OR v_m.account_id<>v_account_id OR v_m.movement_kind<>'UNIT_REFUND' THEN
   RAISE EXCEPTION 'INVALID_REFUND_MOVEMENT'; END IF;
 IF v_m.movement_status<>'PENDING' THEN RAISE EXCEPTION 'REFUND_NOT_PENDING'; END IF;
 IF v_m.recipient_user_id<>p_manager_id THEN RAISE EXCEPTION 'REFUND_ONLY_DESIGNATED_MANAGER'; END IF;
 PERFORM 1 FROM public.tower_finance_refund_movements WHERE movement_id=p_movement_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_APPROVAL_LINK_MISSING'; END IF;
 -- Trusted wrapper must verify p_manager_id is CURRENT unit MANAGER, not simply recipient.
 UPDATE public.tower_finance_cash_movements
 SET movement_status='CONFIRMED',confirmed_at=now(),confirmed_by=p_manager_id
 WHERE movement_id=p_movement_id;
 RETURN 'CONFIRMED';
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_holder_available_internal(p_account_id uuid, p_holder_id uuid)
 RETURNS numeric
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_receipts numeric(16,2);
 v_fund_cash numeric(16,2);
 v_incoming numeric(16,2);
 v_outgoing numeric(16,2);
 v_account_kind text;
BEGIN
 IF p_account_id IS NULL OR p_holder_id IS NULL THEN
   RAISE EXCEPTION 'INVALID_HOLDER_ACCOUNT';
 END IF;
 -- Serialize all money movements for this account when used inside a writer.
 -- This is a read helper, not an authorization endpoint.
 SELECT account_kind INTO v_account_kind FROM public.tower_finance_accounts
 WHERE account_id=p_account_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND OR v_account_kind<>'PERSONAL_SERVICE' THEN
   RAISE EXCEPTION 'PERSONAL_ACCOUNT_NOT_FOUND';
 END IF;
 SELECT COALESCE(SUM(p.amount),0) INTO v_receipts
 FROM public.tower_finance_receipt_portions p
 JOIN public.tower_finance_receipts r ON r.receipt_id=p.receipt_id
 WHERE p.account_id=p_account_id AND r.collector_id=p_holder_id
 AND r.receipt_status='POSTED';
 SELECT COALESCE(SUM(fr.amount),0) INTO v_fund_cash
 FROM public.tower_task_fund_receipts fr
 JOIN public.tower_task_fund_contributions fc ON fc.service_id=fr.service_id
 JOIN public.tower_fund_entries fe ON fe.entry_id=fc.fund_entry_id
 WHERE fr.account_id=p_account_id AND fr.confirmed_by=p_holder_id
 AND fe.status='ACTIVE' AND fe.entry_type='EXPENSE' AND fe.amount=fr.amount;
 -- Only transfers between custodians create an inbound holder balance.
 -- UNIT_REFUND exits the service cash ledger; the resident manager does not
 -- become a new custodian of this money after confirming the refund.
 SELECT COALESCE(SUM(m.amount),0) INTO v_incoming
 FROM public.tower_finance_cash_movements m
 WHERE m.account_id=p_account_id AND m.recipient_user_id=p_holder_id
 AND m.movement_status='CONFIRMED'
 AND m.movement_kind IN ('BENEFICIARY_DELIVERY','BENEFICIARY_HANDOVER');
 -- Pending/disputed outgoing cash is already reserved and cannot be promised again.
 SELECT COALESCE(SUM(m.amount),0) INTO v_outgoing
 FROM public.tower_finance_cash_movements m
 WHERE m.account_id=p_account_id AND m.sender_user_id=p_holder_id
 AND m.movement_status IN ('PENDING','DISPUTED','CONFIRMED');
 IF v_receipts+v_fund_cash+v_incoming<v_outgoing THEN
   RAISE EXCEPTION 'NEGATIVE_HOLDER_BALANCE';
 END IF;
 RETURN v_receipts+v_fund_cash+v_incoming-v_outgoing;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_personal_receipt_action(p_token text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_actor public.tower_users%ROWTYPE;
 v_unit uuid;
 v_amount numeric(16,2);
 v_ref text;
 v_portions jsonb;
 v_expected jsonb;
 v_existing jsonb;
 v_receipt public.tower_finance_receipts%ROWTYPE;
 v_id uuid;
 v_item jsonb;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin THEN
  RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF v_actor.role NOT IN ('UNION','OPERATOR') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' THEN
  RAISE EXCEPTION 'INVALID_PAYLOAD'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_object_keys(p_payload) AS k(key)
   WHERE k.key NOT IN ('unitId','amount','portions','externalReference')) THEN
  RAISE EXCEPTION 'INVALID_RECEIPT_FIELDS'; END IF;
 IF coalesce(p_payload->>'unitId','') !~* '^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$'
  OR coalesce(p_payload->>'amount','') !~ '^([0-9]+)(\.[0-9]{1,2})?$'
  OR jsonb_typeof(p_payload->'portions')<>'array'
  OR jsonb_array_length(p_payload->'portions')=0
 THEN RAISE EXCEPTION 'INVALID_RECEIPT_FIELDS'; END IF;
 v_ref:=btrim(coalesce(p_payload->>'externalReference',''));
 IF length(v_ref)<16 OR length(v_ref)>128 THEN RAISE EXCEPTION 'RECEIPT_REFERENCE_REQUIRED'; END IF;
 v_unit:=(p_payload->>'unitId')::uuid;
 v_amount:=(p_payload->>'amount')::numeric;
 IF v_amount<=0 THEN RAISE EXCEPTION 'INVALID_RECEIPT_AMOUNT'; END IF;
 v_portions:=p_payload->'portions';
 -- Strict canonical shape; rejects accidental extra keys and duplicate account IDs.
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(v_portions) x(value)
   WHERE jsonb_typeof(x.value)<>'object'
   OR NOT (x.value ? 'account_id' AND x.value ? 'amount')
   OR (SELECT count(*) FROM jsonb_object_keys(x.value))<>2
   OR coalesce(x.value->>'account_id','') !~* '^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$'
   OR coalesce(x.value->>'amount','') !~ '^([0-9]+)(\.[0-9]{1,2})?$'
   OR (x.value->>'amount')::numeric<=0)
 THEN RAISE EXCEPTION 'INVALID_PORTION'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(v_portions) x(value)
   GROUP BY lower(x.value->>'account_id') HAVING count(*)>1)
 THEN RAISE EXCEPTION 'DUPLICATE_ACCOUNT'; END IF;
 SELECT coalesce(jsonb_agg(jsonb_build_object(
   'account_id', (x.value->>'account_id')::uuid,
   'amount', (x.value->>'amount')::numeric) ORDER BY x.value->>'account_id'),'[]'::jsonb)
 INTO v_expected FROM jsonb_array_elements(v_portions) x(value);
 IF (SELECT sum((x.value->>'amount')::numeric) FROM jsonb_array_elements(v_portions) x(value))<>v_amount
 THEN RAISE EXCEPTION 'RECEIPT_SUM_MISMATCH'; END IF;
 -- Serialize requests for the same upstream collection event (even concurrent retries).
 PERFORM pg_advisory_xact_lock(hashtextextended('personal-receipt:'||v_ref,0));
 SELECT * INTO v_receipt FROM public.tower_finance_receipts
  WHERE btrim(external_reference)=v_ref AND receipt_status IN ('POSTED','REVERSED') FOR UPDATE;
 IF FOUND THEN
  SELECT coalesce(jsonb_agg(jsonb_build_object('account_id',rp.account_id,'amount',rp.amount)
    ORDER BY rp.account_id),'[]'::jsonb) INTO v_existing
  FROM public.tower_finance_receipt_portions rp WHERE rp.receipt_id=v_receipt.receipt_id;
  IF v_receipt.unit_id<>v_unit OR v_receipt.collector_id<>v_actor.user_id
    OR v_receipt.amount<>v_amount OR v_expected<>v_existing
  THEN RAISE EXCEPTION 'RECEIPT_REFERENCE_CONFLICT'; END IF;
  IF v_receipt.receipt_status<>'POSTED' THEN RAISE EXCEPTION 'RECEIPT_ALREADY_REVERSED'; END IF;
  RETURN jsonb_build_object('receiptId',v_receipt.receipt_id,'status','POSTED','replayed',true);
 END IF;
 -- Identity is NEVER supplied by client. Allocation and inserts are one SQL transaction.
 v_id:=public.tower_finance_post_personal_receipt_internal(
   v_unit,v_actor.user_id,v_amount,v_portions,v_ref);
 RETURN jsonb_build_object('receiptId',v_id,'status','POSTED','replayed',false);
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_post_personal_receipt_internal(p_unit_id uuid, p_collector_id uuid, p_amount numeric, p_portions jsonb, p_external_reference text DEFAULT ''::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
  v_receipt uuid;
  v_item jsonb;
  v_account uuid;
  v_amount numeric(16,2);
  v_portion uuid;
  v_due record;
  v_remaining numeric(16,2);
  v_unpaid numeric(16,2);
  v_take numeric(16,2);
  v_total numeric(16,2) := 0;
  v_seen uuid[] := ARRAY[]::uuid[];
BEGIN
  IF p_unit_id IS NULL OR p_collector_id IS NULL OR p_amount IS NULL
    OR p_amount<=0 OR p_amount<>round(p_amount,2)
    OR p_portions IS NULL OR jsonb_typeof(p_portions)<>'array'
    OR jsonb_array_length(p_portions)=0 THEN
    RAISE EXCEPTION 'INVALID_RECEIPT';
  END IF;
  -- Serialize updates for a unit (protect concurrent transactions allocating same dues).
  PERFORM 1 FROM public.tower_units WHERE unit_id=p_unit_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNIT_NOT_FOUND'; END IF;
  PERFORM 1 FROM public.tower_users WHERE user_id=p_collector_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'COLLECTOR_NOT_FOUND'; END IF;
  FOR v_item IN SELECT value FROM jsonb_array_elements(p_portions)
  LOOP
    IF jsonb_typeof(v_item)<>'object' OR
       NOT (v_item ? 'account_id' AND v_item ? 'amount') OR
       coalesce(v_item->>'account_id','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' OR
       coalesce(v_item->>'amount','') !~ '^([0-9]+)(\.[0-9]{1,2})?$' THEN
      RAISE EXCEPTION 'INVALID_PORTION';
    END IF;
    v_account := (v_item->>'account_id')::uuid;
    v_amount := (v_item->>'amount')::numeric;
    IF v_amount<=0 OR v_account=ANY(v_seen) THEN
      RAISE EXCEPTION 'INVALID_OR_DUPLICATE_ACCOUNT';
    END IF;
    PERFORM 1 FROM public.tower_finance_accounts
     WHERE account_id=v_account AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE'
     FOR SHARE;
    IF NOT FOUND THEN RAISE EXCEPTION 'ACCOUNT_NOT_PERSONAL_OR_INACTIVE'; END IF;
    v_seen:=array_append(v_seen,v_account);
    v_total:=v_total+v_amount;
  END LOOP;
  IF v_total<>p_amount THEN RAISE EXCEPTION 'RECEIPT_SUM_MISMATCH'; END IF;
  -- The caller's SQL transaction makes the receipt, portions and allocations indivisible.
  INSERT INTO public.tower_finance_receipts(unit_id,collector_id,amount,external_reference)
  VALUES(p_unit_id,p_collector_id,p_amount,coalesce(p_external_reference,''))
  RETURNING receipt_id INTO v_receipt;
  FOR v_item IN SELECT value FROM jsonb_array_elements(p_portions)
  LOOP
    v_account:=(v_item->>'account_id')::uuid;
    v_remaining:=(v_item->>'amount')::numeric;
    INSERT INTO public.tower_finance_receipt_portions(receipt_id,account_id,amount)
    VALUES(v_receipt,v_account,v_remaining) RETURNING portion_id INTO v_portion;
    FOR v_due IN
      SELECT d.due_id,d.amount,
       (COALESCE((SELECT sum(a.amount) FROM public.tower_finance_applications a
                   JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=a.portion_id
                   JOIN public.tower_finance_receipts rr ON rr.receipt_id=rp.receipt_id
                   WHERE a.due_id=d.due_id AND a.application_kind='DUE'
                     AND rr.receipt_status='POSTED'),0)
        + COALESCE((SELECT sum(au.amount) FROM public.tower_finance_advance_uses au
                   JOIN public.tower_finance_applications aa ON aa.application_id=au.advance_application_id
                   JOIN public.tower_finance_receipt_portions ap ON ap.portion_id=aa.portion_id
                   JOIN public.tower_finance_receipts ar ON ar.receipt_id=ap.receipt_id
                   WHERE au.due_id=d.due_id AND ar.receipt_status='POSTED'),0)) AS paid
       FROM public.tower_finance_dues d
       WHERE d.unit_id=p_unit_id AND d.account_id=v_account AND d.status='OPEN'
       ORDER BY d.due_date,d.due_id FOR UPDATE OF d
    LOOP
      EXIT WHEN v_remaining<=0;
      v_unpaid:=v_due.amount-v_due.paid;
      IF v_unpaid<0 THEN RAISE EXCEPTION 'OVERPAID_DUE_IN_LEDGER'; END IF;
      v_take:=least(v_remaining,v_unpaid);
      IF v_take>0 THEN
        INSERT INTO public.tower_finance_applications(portion_id,due_id,amount,application_kind)
        VALUES(v_portion,v_due.due_id,v_take,'DUE');
        v_remaining:=v_remaining-v_take;
      END IF;
    END LOOP;
    IF v_remaining>0 THEN
      INSERT INTO public.tower_finance_applications(portion_id,due_id,amount,application_kind)
      VALUES(v_portion,NULL,v_remaining,'ADVANCE');
    END IF;
  END LOOP;
  RETURN v_receipt;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_refund_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_actor public.tower_users%ROWTYPE;
 v_m public.tower_finance_cash_movements%ROWTYPE;
 v_id uuid;
 v_status text;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin THEN
  RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' THEN
  RAISE EXCEPTION 'INVALID_PAYLOAD'; END IF;
 IF p_action NOT IN ('confirm','cancel') OR p_action IS NULL THEN
  RAISE EXCEPTION 'REFUND_REQUEST_REQUIRES_TRUSTED_ELIGIBILITY'; END IF;
 IF coalesce(p_payload->>'movementId','') !~* '^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$' THEN
  RAISE EXCEPTION 'INVALID_MOVEMENT_ID'; END IF;
 v_id:=(p_payload->>'movementId')::uuid;
 -- Primitives acquire account/movement locks and recheck pending state atomically.
 SELECT * INTO v_m FROM public.tower_finance_cash_movements WHERE movement_id=v_id;
 IF NOT FOUND OR v_m.movement_kind<>'UNIT_REFUND' THEN
  RAISE EXCEPTION 'REFUND_MOVEMENT_NOT_FOUND'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.tower_finance_refund_movements
   WHERE movement_id=v_id) THEN RAISE EXCEPTION 'REFUND_APPROVAL_LINK_MISSING'; END IF;
 IF p_action='confirm' THEN
  IF v_actor.role<>'RESIDENT' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  IF v_m.recipient_user_id<>v_actor.user_id THEN RAISE EXCEPTION 'REFUND_ONLY_DESIGNATED_MANAGER'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.tower_members m
   WHERE m.user_id=v_actor.user_id AND m.unit_id=v_m.unit_id
    AND m.member_role='MANAGER' AND m.ended_at IS NULL)
  THEN RAISE EXCEPTION 'REFUND_ONLY_CURRENT_UNIT_MANAGER'; END IF;
  -- Do not confirm while multiple active managers make unit authority ambiguous.
  IF (SELECT count(*) FROM public.tower_members m
      JOIN public.tower_users u ON u.user_id=m.user_id
      WHERE m.unit_id=v_m.unit_id AND m.member_role='MANAGER'
       AND m.ended_at IS NULL AND u.role='RESIDENT' AND u.status='ACTIVE')<>1
  THEN RAISE EXCEPTION 'UNIQUE_CURRENT_UNIT_MANAGER_REQUIRED'; END IF;
  v_status:=public.tower_finance_confirm_unit_refund_internal(v_id,v_actor.user_id);
 ELSE
  IF v_actor.role NOT IN ('UNION','OPERATOR') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  IF v_m.sender_user_id<>v_actor.user_id THEN RAISE EXCEPTION 'REFUND_ONLY_SENDER_CAN_CANCEL'; END IF;
  v_status:=public.tower_finance_cancel_unit_refund_internal(v_id,v_actor.user_id);
 END IF;
 RETURN jsonb_build_object('movementId',v_id,'status',v_status);
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_request_unit_refund_action(p_token text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_actor public.tower_users%ROWTYPE;
 v_auth public.tower_finance_refund_authorizations%ROWTYPE;
 v_sub public.tower_service_subscriptions%ROWTYPE;
 v_manager uuid;
 v_manager_count integer;
 v_auth_id uuid;
 v_amount numeric(16,2);
 v_exact numeric(16,2);
 v_reserved numeric(16,2);
 v_id uuid;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF v_actor.role NOT IN ('UNION','OPERATOR') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_payload IS NULL OR jsonb_typeof(p_payload)<>'object' THEN RAISE EXCEPTION 'INVALID_PAYLOAD'; END IF;
 IF coalesce(p_payload->>'authorizationId','') !~* '^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$'
   OR coalesce(p_payload->>'amount','') !~ '^[0-9]+(\.[0-9]{1,2})?$'
 THEN RAISE EXCEPTION 'INVALID_REFUND_FIELDS'; END IF;
 v_auth_id:=(p_payload->>'authorizationId')::uuid;
 v_amount:=(p_payload->>'amount')::numeric;
 IF v_amount<=0 THEN RAISE EXCEPTION 'INVALID_REFUND_AMOUNT'; END IF;
 -- Serialize across ALL authorizations sharing an account, then lock the particular authorization.
 PERFORM 1 FROM public.tower_finance_accounts a
 JOIN public.tower_finance_refund_authorizations r ON r.account_id=a.account_id
 WHERE r.refund_authorization_id=v_auth_id AND a.account_kind='PERSONAL_SERVICE'
  AND a.status='ACTIVE' FOR UPDATE OF a;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_ACCOUNT_UNAVAILABLE'; END IF;
 SELECT * INTO v_auth FROM public.tower_finance_refund_authorizations
 WHERE refund_authorization_id=v_auth_id FOR UPDATE;
 IF NOT FOUND OR v_auth.authorization_status<>'APPROVED' THEN RAISE EXCEPTION 'REFUND_NOT_APPROVED'; END IF;
 SELECT * INTO v_sub FROM public.tower_service_subscriptions
 WHERE subscription_id=v_auth.subscription_id AND unit_id=v_auth.unit_id
  AND status='ENDED' AND ended_at IS NOT NULL FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SUBSCRIPTION_NOT_ENDED'; END IF;
 IF v_auth.effective_date < v_sub.ended_at::date THEN RAISE EXCEPTION 'INVALID_CANCELLATION_EFFECTIVE_DATE'; END IF;
 PERFORM 1 FROM public.tower_finance_accounts a
 WHERE a.account_id=v_auth.account_id AND a.service_id=v_sub.service_id
  AND a.account_kind='PERSONAL_SERVICE' AND a.status='ACTIVE';
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_ACCOUNT_SUBSCRIPTION_MISMATCH'; END IF;
 PERFORM 1 FROM public.tower_users u WHERE u.user_id=v_auth.approved_by
  AND u.role='UNION' AND u.status='ACTIVE';
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_REQUIRES_UNION_APPROVAL'; END IF;
 -- Fail closed on ambiguous current managers, rather than refunding to an arbitrary UUID.
 SELECT count(*),min(m.user_id) INTO v_manager_count,v_manager
 FROM public.tower_members m
 JOIN public.tower_users u ON u.user_id=m.user_id
 WHERE m.unit_id=v_auth.unit_id AND m.member_role='MANAGER'
  AND m.ended_at IS NULL AND u.role='RESIDENT' AND u.status='ACTIVE';
 IF v_manager_count<>1 THEN RAISE EXCEPTION 'UNIQUE_CURRENT_UNIT_MANAGER_REQUIRED'; END IF;
 IF v_manager IS NULL THEN RAISE EXCEPTION 'CURRENT_UNIT_MANAGER_REQUIRED'; END IF;
 IF v_manager=v_actor.user_id THEN RAISE EXCEPTION 'SELF_REFUND_NOT_ALLOWED'; END IF;
 -- Missing exact attributions make the whole account/UNIT unsafe, not just this subscription.
 IF EXISTS (
  SELECT 1 FROM public.tower_finance_advance_uses x
  JOIN public.tower_finance_applications ap ON ap.application_id=x.advance_application_id
  JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
  JOIN public.tower_finance_receipts r ON r.receipt_id=rp.receipt_id
  LEFT JOIN public.tower_finance_advance_use_subscriptions e ON e.use_id=x.use_id
  WHERE rp.account_id=v_auth.account_id AND r.unit_id=v_auth.unit_id AND e.use_id IS NULL
 ) THEN RAISE EXCEPTION 'UNATTRIBUTED_HISTORIC_ADVANCE_USE'; END IF;
 -- Exact link-specific remaining prepayment. Exclude REVERSED original receipts.
 SELECT COALESCE(sum(l.amount),0) INTO v_exact
 FROM public.tower_finance_advance_subscription_links l
 JOIN public.tower_finance_applications ap ON ap.application_id=l.advance_application_id
 JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
 JOIN public.tower_finance_receipts r ON r.receipt_id=rp.receipt_id
 WHERE l.subscription_id=v_auth.subscription_id AND rp.account_id=v_auth.account_id
  AND r.unit_id=v_auth.unit_id AND r.receipt_status='POSTED';
 SELECT v_exact-COALESCE(sum(x.amount),0) INTO v_exact
 FROM public.tower_finance_advance_use_subscriptions e
 JOIN public.tower_finance_advance_uses x ON x.use_id=e.use_id
 JOIN public.tower_finance_advance_subscription_links l ON l.link_id=e.link_id
 WHERE l.subscription_id=v_auth.subscription_id
  AND EXISTS (
   SELECT 1 FROM public.tower_finance_applications ap
   JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
   JOIN public.tower_finance_receipts r ON r.receipt_id=rp.receipt_id
   WHERE ap.application_id=l.advance_application_id AND rp.account_id=v_auth.account_id
    AND r.unit_id=v_auth.unit_id AND r.receipt_status='POSTED');
 IF v_exact<0 THEN RAISE EXCEPTION 'REFUND_LEDGER_INCONSISTENT'; END IF;
 SELECT COALESCE(sum(m.amount),0) INTO v_reserved
 FROM public.tower_finance_refund_movements rm
 JOIN public.tower_finance_cash_movements m ON m.movement_id=rm.movement_id
 JOIN public.tower_finance_refund_authorizations a ON a.refund_authorization_id=rm.refund_authorization_id
 WHERE a.subscription_id=v_auth.subscription_id AND a.account_id=v_auth.account_id
  AND a.unit_id=v_auth.unit_id AND m.movement_status IN ('PENDING','DISPUTED','CONFIRMED');
 IF v_amount>v_exact-v_reserved THEN RAISE EXCEPTION 'REFUND_EXCEEDS_EXACT_UNUSED_ADVANCE'; END IF;
 -- Underlying function additionally locks/checks authorization max and sender cash availability.
 v_id:=public.tower_finance_request_unit_refund_internal(v_auth_id,v_actor.user_id,v_manager,v_amount);
 RETURN jsonb_build_object('movementId',v_id,'status','PENDING','amount',v_amount,'unitId',v_auth.unit_id);
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_request_unit_refund_internal(p_refund_authorization_id uuid, p_holder_id uuid, p_manager_id uuid, p_amount numeric)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_a public.tower_finance_refund_authorizations%ROWTYPE;
 v_account public.tower_finance_accounts%ROWTYPE;
 v_reserved numeric(16,2);
 v_available numeric(16,2);
 v_movement uuid;
BEGIN
 IF p_refund_authorization_id IS NULL OR p_holder_id IS NULL OR p_manager_id IS NULL
    OR p_amount IS NULL OR p_amount<=0 OR p_amount<>round(p_amount,2) THEN
   RAISE EXCEPTION 'INVALID_REFUND_REQUEST'; END IF;
 IF p_holder_id=p_manager_id THEN RAISE EXCEPTION 'SELF_REFUND_REQUIRES_INDEPENDENT_REVIEW'; END IF;
 -- Read pointer before taking account lock, then recheck authorization under lock.
 SELECT account_id INTO v_account.account_id FROM public.tower_finance_refund_authorizations
 WHERE refund_authorization_id=p_refund_authorization_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_AUTHORIZATION_NOT_FOUND'; END IF;
 SELECT * INTO v_account FROM public.tower_finance_accounts
 WHERE account_id=v_account.account_id AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'PERSONAL_ACCOUNT_NOT_FOUND'; END IF;
 SELECT * INTO v_a FROM public.tower_finance_refund_authorizations
 WHERE refund_authorization_id=p_refund_authorization_id FOR UPDATE;
 IF NOT FOUND OR v_a.account_id<>v_account.account_id OR v_a.authorization_status<>'APPROVED'
 THEN RAISE EXCEPTION 'REFUND_AUTHORIZATION_UNAVAILABLE'; END IF;
 PERFORM 1 FROM public.tower_service_subscriptions s
 JOIN public.tower_finance_accounts a ON a.service_id=s.service_id
 WHERE s.subscription_id=v_a.subscription_id AND s.unit_id=v_a.unit_id
 AND a.account_id=v_a.account_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'REFUND_SUBSCRIPTION_SCOPE_MISMATCH'; END IF;
 -- Ledger-reserved refunds (pending/disputed/confirmed) all consume the authorization.
 SELECT COALESCE(sum(m.amount),0) INTO v_reserved
 FROM public.tower_finance_refund_movements rm
 JOIN public.tower_finance_cash_movements m ON m.movement_id=rm.movement_id
 WHERE rm.refund_authorization_id=p_refund_authorization_id
   AND m.movement_status IN ('PENDING','DISPUTED','CONFIRMED');
 IF v_reserved+p_amount>v_a.max_amount THEN RAISE EXCEPTION 'REFUND_AUTHORIZATION_EXCEEDED'; END IF;
 -- Holder-availability calculation also reserves every pending refund movement.
 v_available:=public.tower_finance_holder_available_internal(v_a.account_id,p_holder_id);
 IF p_amount>v_available THEN RAISE EXCEPTION 'INSUFFICIENT_HOLDER_BALANCE'; END IF;
 INSERT INTO public.tower_finance_cash_movements
 (account_id,unit_id,movement_kind,sender_user_id,recipient_user_id,amount,movement_status)
 VALUES(v_a.account_id,v_a.unit_id,'UNIT_REFUND',p_holder_id,p_manager_id,p_amount,'PENDING')
 RETURNING movement_id INTO v_movement;
 INSERT INTO public.tower_finance_refund_movements(movement_id,refund_authorization_id)
 VALUES(v_movement,p_refund_authorization_id);
 RETURN v_movement;
END; $function$
;
CREATE OR REPLACE FUNCTION public.tower_service_finance_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_actor public.tower_users; v_result jsonb; v_service uuid;
 v_kind text; v_beneficiary uuid; v_old_account public.tower_finance_accounts;
 v_existing_count integer; v_valid boolean; v_service_kind text; v_pricing_mode text; v_budget numeric; v_old_service public.tower_services;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin THEN
  RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF p_action='list' THEN
  v_result := public.tower_services_action(p_token,'list', '{}'::jsonb);
  RETURN COALESCE((
   SELECT jsonb_agg(x.s || jsonb_build_object(
     'revenueKind', CASE WHEN a.account_id IS NULL THEN 'FUND' ELSE 'PERSONAL_SERVICE' END,
     'beneficiaryUserId',a.beneficiary_user_id,
     'beneficiaryName',concat_ws(' ',u.title,u.name),
     'financeAccountId',a.account_id, 'serviceKind',COALESCE(svc.service_kind,'RECURRING'), 'pricingMode',COALESCE(svc.pricing_mode,'PER_SUBSCRIPTION'), 'totalBudget',svc.total_budget, 'enrollmentStatus',svc.enrollment_status) ORDER BY x.ordinality)
   FROM jsonb_array_elements(v_result) WITH ORDINALITY AS x(s,ordinality)
   LEFT JOIN LATERAL (
    SELECT account_id,beneficiary_user_id FROM public.tower_finance_accounts
    WHERE service_id=(x.s->>'serviceId')::uuid AND account_kind='PERSONAL_SERVICE'
      AND status='ACTIVE' ORDER BY created_at DESC, account_id DESC LIMIT 1
   ) a ON true
   LEFT JOIN public.tower_users u ON u.user_id=a.beneficiary_user_id
   LEFT JOIN public.tower_services svc ON svc.service_id=(x.s->>'serviceId')::uuid
  ),'[]'::jsonb);
 END IF;
 IF p_action<>'save' THEN RAISE EXCEPTION 'UNKNOWN_ACTION'; END IF;
 IF v_actor.role NOT IN ('ADMIN','UNION') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 v_kind:=upper(coalesce(nullif(p_payload->>'revenueKind',''),'FUND'));
 IF v_kind NOT IN ('FUND','PERSONAL_SERVICE') THEN RAISE EXCEPTION 'INVALID_REVENUE_KIND'; END IF;
 IF v_kind='PERSONAL_SERVICE' THEN
  BEGIN v_beneficiary:=nullif(p_payload->>'beneficiaryUserId','')::uuid;
  EXCEPTION WHEN invalid_text_representation THEN RAISE EXCEPTION 'INVALID_BENEFICIARY'; END;
  IF v_beneficiary IS NULL THEN RAISE EXCEPTION 'BENEFICIARY_REQUIRED'; END IF;
  SELECT EXISTS(SELECT 1 FROM public.tower_users
    WHERE user_id=v_beneficiary AND status='ACTIVE') INTO v_valid;
  IF NOT v_valid THEN RAISE EXCEPTION 'BENEFICIARY_NOT_ACTIVE'; END IF;
 END IF;
 BEGIN v_service:=nullif(p_payload->>'serviceId','')::uuid;
 EXCEPTION WHEN invalid_text_representation THEN RAISE EXCEPTION 'INVALID_SERVICE_ID'; END;
 v_service_kind:=upper(coalesce(nullif(p_payload->>'serviceKind',''),'RECURRING'));
 v_pricing_mode:=upper(coalesce(nullif(p_payload->>'pricingMode',''),'PER_SUBSCRIPTION'));
 IF v_service_kind NOT IN ('RECURRING','ONE_TIME') OR v_pricing_mode NOT IN ('PER_SUBSCRIPTION','SHARED_TOTAL') THEN RAISE EXCEPTION 'INVALID_SERVICE_PRICING'; END IF;
 IF v_pricing_mode='SHARED_TOTAL' THEN
  IF v_service_kind<>'ONE_TIME' THEN RAISE EXCEPTION 'SHARED_COST_REQUIRES_ONE_TIME_SERVICE'; END IF;
  BEGIN v_budget:=(p_payload->>'totalBudget')::numeric; EXCEPTION WHEN others THEN RAISE EXCEPTION 'INVALID_TOTAL_BUDGET'; END;
  IF v_budget IS NULL OR v_budget<=0 OR v_budget<>round(v_budget,2) THEN RAISE EXCEPTION 'INVALID_TOTAL_BUDGET'; END IF;
 ELSE v_budget:=NULL; END IF;
 IF v_service IS NOT NULL THEN
  SELECT * INTO v_old_service FROM public.tower_services WHERE service_id=v_service FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SERVICE_NOT_FOUND'; END IF;
  IF (v_old_service.service_kind,v_old_service.pricing_mode) IS DISTINCT FROM (v_service_kind,v_pricing_mode) THEN
   IF EXISTS(SELECT 1 FROM public.tower_service_subscriptions WHERE service_id=v_service) OR EXISTS(SELECT 1 FROM public.tower_finance_dues d JOIN public.tower_service_subscriptions sub ON d.subscription_id=sub.subscription_id WHERE sub.service_id=v_service) OR EXISTS(SELECT 1 FROM public.tower_building_charges WHERE service_id=v_service) THEN
    RAISE EXCEPTION 'SERVICE_PRICING_CHANGE_REQUIRES_MIGRATION'; END IF;
  END IF;
  IF v_old_service.enrollment_status<>'OPEN' AND (v_old_service.total_budget IS DISTINCT FROM v_budget OR v_old_service.service_kind IS DISTINCT FROM v_service_kind OR v_old_service.pricing_mode IS DISTINCT FROM v_pricing_mode) THEN
   RAISE EXCEPTION 'LOCKED_SERVICE_PRICING'; END IF;
  IF v_old_service.pricing_mode='SHARED_TOTAL' AND v_old_service.enrollment_status='OPEN' AND v_old_service.total_budget IS DISTINCT FROM v_budget AND EXISTS(SELECT 1 FROM public.tower_finance_dues d JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id WHERE sub.service_id=v_service) THEN
   RAISE EXCEPTION 'SERVICE_ALREADY_HAS_DUES'; END IF;
  PERFORM 1 FROM public.tower_services WHERE service_id=v_service FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SERVICE_NOT_FOUND'; END IF;
  SELECT count(*) INTO v_existing_count FROM public.tower_finance_accounts
   WHERE service_id=v_service AND account_kind='PERSONAL_SERVICE';
  IF v_existing_count>1 THEN RAISE EXCEPTION 'SERVICE_ACCOUNT_CONFLICT'; END IF;
  SELECT * INTO v_old_account FROM public.tower_finance_accounts
   WHERE service_id=v_service AND account_kind='PERSONAL_SERVICE' LIMIT 1;
  IF v_old_account.account_id IS NOT NULL THEN
   IF v_kind='FUND' THEN RAISE EXCEPTION 'SERVICE_ACCOUNT_CHANGE_REQUIRES_MIGRATION'; END IF;
   IF v_old_account.beneficiary_user_id<>v_beneficiary THEN
    RAISE EXCEPTION 'SERVICE_BENEFICIARY_CHANGE_REQUIRES_MIGRATION'; END IF;
   IF v_old_account.status<>'ACTIVE' THEN RAISE EXCEPTION 'SERVICE_ACCOUNT_INACTIVE'; END IF;
  ELSIF v_kind='PERSONAL_SERVICE' THEN
   IF EXISTS(SELECT 1 FROM public.tower_service_subscriptions WHERE service_id=v_service) THEN
    RAISE EXCEPTION 'SERVICE_ACCOUNT_CHANGE_REQUIRES_MIGRATION'; END IF;
   IF EXISTS(SELECT 1 FROM public.tower_building_charges WHERE service_id=v_service) THEN
    RAISE EXCEPTION 'SERVICE_ACCOUNT_CHANGE_REQUIRES_MIGRATION'; END IF;
  END IF;
 END IF;
 -- This call and both INSERTs participate in ONE PostgreSQL transaction.
 v_result := public.tower_services_action(p_token,'save',p_payload);
 v_service := (v_result->>'serviceId')::uuid;
 UPDATE public.tower_services SET service_kind=v_service_kind, pricing_mode=v_pricing_mode,total_budget=v_budget,
 billing_timing=CASE WHEN v_service_kind='ONE_TIME' THEN 'POSTPAID' ELSE billing_timing END,
 allow_quantity=CASE WHEN v_pricing_mode='SHARED_TOTAL' THEN false ELSE allow_quantity END,
 cancelable=CASE WHEN v_pricing_mode='SHARED_TOTAL' THEN false ELSE cancelable END,
 updated_at=now() WHERE service_id=v_service;

 IF v_kind='PERSONAL_SERVICE' AND v_old_account.account_id IS NULL THEN
  INSERT INTO public.tower_finance_accounts(account_kind,service_id,beneficiary_user_id,status)
  VALUES('PERSONAL_SERVICE',v_service,v_beneficiary,'ACTIVE')
  RETURNING * INTO v_old_account;
  INSERT INTO public.tower_finance_service_beneficiaries
  (service_id,account_id,effective_from,assigned_by)
  VALUES(v_service,v_old_account.account_id,current_date,v_actor.user_id);
 END IF;
 RETURN v_result || jsonb_build_object('revenueKind',v_kind,
    'financeAccountId',v_old_account.account_id);
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_service_shared_allocation_action(p_token text, p_action text, p_service_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
 v_actor public.tower_users;
 v_service public.tower_services;
 v_account uuid;
 v_accounts int;
 v_units int;
 v_total_cents bigint;
 v_base_cents bigint;
 v_remainder bigint;
 v_existing int;
 v_result jsonb;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status <> 'ACTIVE' OR v_actor.must_change_pin THEN
   RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF v_actor.role NOT IN ('ADMIN','UNION') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action NOT IN ('preview','finalize') THEN RAISE EXCEPTION 'INVALID_ACTION'; END IF;
 IF p_service_id IS NULL THEN RAISE EXCEPTION 'INVALID_SERVICE_ID'; END IF;
 SELECT * INTO v_service FROM public.tower_services WHERE service_id=p_service_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SERVICE_NOT_FOUND'; END IF;
 IF v_service.service_kind <> 'ONE_TIME' OR v_service.pricing_mode <> 'SHARED_TOTAL' THEN
   RAISE EXCEPTION 'NOT_SHARED_COST_SERVICE'; END IF;
 IF v_service.status <> 'ACTIVE' THEN RAISE EXCEPTION 'SERVICE_NOT_ACTIVE'; END IF;
 IF v_service.enrollment_status NOT IN ('OPEN','CLOSED','FINALIZED') THEN
   RAISE EXCEPTION 'INVALID_ENROLLMENT_STATE'; END IF;
 SELECT count(DISTINCT unit_id), count(*) INTO v_units,v_existing
 FROM public.tower_service_subscriptions
 WHERE service_id=p_service_id AND status='ACTIVE';
 IF v_existing <> v_units THEN RAISE EXCEPTION 'MULTIPLE_ACTIVE_SUBSCRIPTIONS_PER_UNIT'; END IF;
 IF v_units=0 THEN RAISE EXCEPTION 'NO_ACTIVE_SUBSCRIBERS'; END IF;
 IF EXISTS(SELECT 1 FROM public.tower_service_subscriptions
           WHERE service_id=p_service_id AND status='PENDING') THEN
   RAISE EXCEPTION 'PENDING_SUBSCRIPTIONS_EXIST'; END IF;
 IF EXISTS(SELECT 1 FROM public.tower_service_subscriptions
           WHERE service_id=p_service_id AND status='ACTIVE' AND quantity<>1) THEN
   RAISE EXCEPTION 'SHARED_COST_REQUIRES_UNIT_QUANTITY_ONE'; END IF;
 -- If a service has any historical personal account, never fall back to FUND.
 IF EXISTS(SELECT 1 FROM public.tower_finance_accounts
           WHERE service_id=p_service_id AND account_kind='PERSONAL_SERVICE') THEN
   SELECT count(*),min(account_id::text)::uuid INTO v_accounts,v_account
   FROM public.tower_finance_accounts
   WHERE service_id=p_service_id AND account_kind='PERSONAL_SERVICE' AND status='ACTIVE';
 ELSE
   SELECT count(*),min(account_id::text)::uuid INTO v_accounts,v_account
   FROM public.tower_finance_accounts WHERE account_kind='FUND' AND status='ACTIVE';
 END IF;
 IF v_accounts<>1 THEN RAISE EXCEPTION 'EXACTLY_ONE_ACTIVE_FINANCE_ACCOUNT_REQUIRED'; END IF;
 v_total_cents := round((v_service.total_budget - coalesce((SELECT amount FROM public.tower_task_fund_contributions WHERE service_id=p_service_id),0))*100)::bigint;
 IF v_total_cents<=0 THEN RAISE EXCEPTION 'INVALID_TOTAL_BUDGET'; END IF;
 v_base_cents := v_total_cents/v_units;
 v_remainder := v_total_cents%v_units;
 -- Stable allocation order by unit_id; integer cents sum exactly to budget.
 SELECT jsonb_agg(jsonb_build_object('unitId', t.unit_id,'subscriptionId',t.subscription_id,
     'amount', (v_base_cents + CASE WHEN t.rn<=v_remainder THEN 1 ELSE 0 END)::numeric/100)
     ORDER BY t.unit_id) INTO v_result
 FROM (SELECT unit_id,subscription_id,row_number() OVER(ORDER BY unit_id) rn
       FROM public.tower_service_subscriptions
       WHERE service_id=p_service_id AND status='ACTIVE') t;
 IF p_action='preview' THEN
   RETURN jsonb_build_object('status',v_service.enrollment_status,'accountId',v_account,
    'subscriberCount',v_units,'totalBudget',v_service.total_budget,'allocations',v_result);
 END IF;
 IF v_service.enrollment_status='FINALIZED' THEN
   IF (SELECT count(*) FROM public.tower_finance_dues d JOIN public.tower_service_subscriptions s ON s.subscription_id=d.subscription_id WHERE s.service_id=p_service_id) <> v_units THEN
      RAISE EXCEPTION 'FINALIZED_ALLOCATION_INTEGRITY_FAILURE'; END IF;
   RETURN jsonb_build_object('status','FINALIZED','replay',true,'subscriberCount',v_units,
      'totalBudget',v_service.total_budget,'allocations',v_result);
 END IF;
 IF v_service.enrollment_status <> 'CLOSED' THEN RAISE EXCEPTION 'ENROLLMENT_MUST_BE_CLOSED'; END IF;
 IF EXISTS(SELECT 1 FROM public.tower_finance_dues d
           JOIN public.tower_service_subscriptions s ON s.subscription_id=d.subscription_id
           WHERE s.service_id=p_service_id) THEN
   RAISE EXCEPTION 'SERVICE_ALREADY_HAS_DUES'; END IF;
 IF EXISTS(SELECT 1 FROM public.tower_building_charges WHERE service_id=p_service_id) THEN
   RAISE EXCEPTION 'SERVICE_ALREADY_HAS_CHARGES'; END IF;
 -- The row is locked above: concurrent finalize requests serialize.
 INSERT INTO public.tower_finance_dues(unit_id,account_id,subscription_id,due_date,amount,status)
 SELECT t.unit_id,v_account,t.subscription_id,current_date,
        (v_base_cents + CASE WHEN t.rn<=v_remainder THEN 1 ELSE 0 END)::numeric/100,'OPEN'
 FROM (SELECT unit_id,subscription_id,row_number() OVER(ORDER BY unit_id) rn
       FROM public.tower_service_subscriptions
       WHERE service_id=p_service_id AND status='ACTIVE') t;
 UPDATE public.tower_services SET enrollment_status='FINALIZED',updated_at=now()
 WHERE service_id=p_service_id;
 INSERT INTO public.tower_audit(actor_id,action,entity,entity_id)
 VALUES(v_actor.user_id,'FINALIZE_SHARED_SERVICE_ALLOCATION','SERVICE',p_service_id::text);
 RETURN jsonb_build_object('status','FINALIZED','replay',false,
  'subscriberCount',v_units,'totalBudget',v_service.total_budget,'allocations',v_result);
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_service_shared_enrollment_close(p_token text, p_service_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE a public.tower_users; s public.tower_services;
BEGIN
 SELECT * INTO a FROM public.tower_session_user(p_token);
 IF NOT FOUND OR a.status<>'ACTIVE' OR a.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF a.role NOT IN ('ADMIN','UNION') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 SELECT * INTO s FROM public.tower_services WHERE service_id=p_service_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SERVICE_NOT_FOUND'; END IF;
 IF s.service_kind<>'ONE_TIME' OR s.pricing_mode<>'SHARED_TOTAL' THEN RAISE EXCEPTION 'NOT_SHARED_COST_SERVICE'; END IF;
 IF s.status<>'ACTIVE' THEN RAISE EXCEPTION 'SERVICE_NOT_ACTIVE'; END IF;
 IF s.enrollment_status='FINALIZED' THEN RAISE EXCEPTION 'ALLOCATION_ALREADY_FINALIZED'; END IF;
 IF EXISTS(SELECT 1 FROM public.tower_service_subscriptions WHERE service_id=p_service_id AND status='PENDING') THEN RAISE EXCEPTION 'PENDING_SUBSCRIPTIONS_EXIST'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.tower_service_subscriptions WHERE service_id=p_service_id AND status='ACTIVE') THEN RAISE EXCEPTION 'NO_ACTIVE_SUBSCRIBERS'; END IF;
 UPDATE public.tower_services SET enrollment_status='CLOSED',updated_at=now() WHERE service_id=p_service_id AND enrollment_status='OPEN';
 RETURN jsonb_build_object('success',true,'status','CLOSED');
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_services_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare a public.tower_users; s public.tower_services; sub public.tower_service_subscriptions;
 v_service uuid; v_unit uuid; v_sub uuid; v_quantity integer; v_name text; v_price numeric(14,2); v_timing text; v_decision text;
begin
 select * into a from public.tower_session_user(p_token);
 if not found or a.status<>'ACTIVE' or a.must_change_pin then raise exception 'SESSION_REQUIRED'; end if;
 if p_action='list' then
  return coalesce((select jsonb_agg(jsonb_build_object('serviceId',service_id,'name',name,'description',description,'price',price,
   'billingCycle','MONTHLY','billingTiming',billing_timing,'autoRenewDefault',true,'allowQuantity',allow_quantity,
   'cancelable',cancelable,'status',status) order by name)
   from public.tower_services where status='ACTIVE' or a.role in ('ADMIN','UNION')),'[]'::jsonb);
 end if;
 if p_action='mine' then
  if a.role<>'RESIDENT' then raise exception 'FORBIDDEN'; end if;
  select m.unit_id into v_unit from public.tower_members m WHERE m.user_id=a.user_id AND m.ended_at IS NULL AND m.unit_id=(p_payload->>'unitId')::uuid AND EXISTS (SELECT 1 FROM public.tower_units z WHERE z.unit_id=m.unit_id AND z.status='ACTIVE') /*TOWER_EXPLICIT_SERVICE_UNIT_120*/
     limit 1;
  if v_unit is null then raise exception 'UNIT_MEMBERSHIP_REQUIRED'; end if;
  return jsonb_build_object('unitId',v_unit,'isManager',true,
   'services',coalesce((select jsonb_agg(jsonb_build_object('serviceId',service_id,'name',name,'description',description,'price',price,
     'billingCycle','MONTHLY','billingTiming',billing_timing,'allowQuantity',allow_quantity,'cancelable',cancelable,'status',status)
     order by name) from public.tower_services where status='ACTIVE'),'[]'::jsonb),
   'subscriptions',coalesce((select jsonb_agg(jsonb_build_object('subscriptionId',x.subscription_id,'serviceId',x.service_id,
     'unitId',x.unit_id,'status',x.status,'quantity',x.quantity,'unitPriceSnapshot',x.unit_price_snapshot,
     'amountSnapshot',x.amount_snapshot,'billingCycle','MONTHLY','billingTiming',x.billing_timing,'autoRenew',x.auto_renew,
     'nextRenewalAt',x.next_renewal_at,'requestedAt',x.requested_at,'startedAt',x.started_at,'endedAt',x.ended_at))
     from public.tower_service_subscriptions x where x.unit_id=v_unit),'[]'::jsonb),
   'changeRequests','[]'::jsonb);
 end if;
 if p_action='request' then
  if a.role<>'RESIDENT' then raise exception 'FORBIDDEN'; end if;
  select m.unit_id into v_unit from public.tower_members m WHERE m.user_id=a.user_id AND m.ended_at IS NULL AND m.unit_id=(p_payload->>'unitId')::uuid AND EXISTS (SELECT 1 FROM public.tower_units z WHERE z.unit_id=m.unit_id AND z.status='ACTIVE') /*TOWER_EXPLICIT_SERVICE_UNIT_120*/
    limit 1;
  if v_unit is null then raise exception 'UNIT_MEMBERSHIP_REQUIRED'; end if;
  begin v_service:=(p_payload->>'serviceId')::uuid; exception when invalid_text_representation then raise exception 'INVALID_SERVICE_ID'; end;
  select * into s from public.tower_services where service_id=v_service and status='ACTIVE' for share;
  if not found then raise exception 'SERVICE_NOT_AVAILABLE'; end if;
  if coalesce(p_payload->>'quantity','1') !~ '^[0-9]{1,2}$' then raise exception 'INVALID_QUANTITY'; end if;
  v_quantity:=least(99,greatest(1,(p_payload->>'quantity')::integer));
  if not s.allow_quantity then v_quantity:=1; end if;
  insert into public.tower_service_subscriptions(service_id,unit_id,requested_by,quantity,unit_price_snapshot,amount_snapshot,billing_timing)
  values(s.service_id,v_unit,a.user_id,v_quantity,s.price,s.price*v_quantity,s.billing_timing)
  returning subscription_id into v_sub;
  insert into public.tower_audit(actor_id,action,entity,entity_id) values(a.user_id,'REQUEST_SERVICE_SUBSCRIPTION','SERVICE_SUBSCRIPTION',v_sub::text);
  return jsonb_build_object('success',true,'subscriptionId',v_sub);
 end if;
 if a.role not in ('ADMIN','UNION') then raise exception 'FORBIDDEN'; end if;
 if p_action='save' then
  v_name:=btrim(coalesce(p_payload->>'name',''));
  if length(v_name)<1 or length(v_name)>120 then raise exception 'INVALID_SERVICE_NAME'; end if;
  if coalesce(p_payload->>'price','') !~ '^[0-9]{1,10}(\.[0-9]{1,2})?$' then raise exception 'INVALID_PRICE'; end if;
  v_price:=(p_payload->>'price')::numeric;
  v_timing:=upper(coalesce(p_payload->>'billingTiming','PREPAID'));
  if v_timing not in ('PREPAID','POSTPAID') then raise exception 'INVALID_BILLING_TIMING'; end if;
  begin v_service:=nullif(p_payload->>'serviceId','')::uuid; exception when invalid_text_representation then raise exception 'INVALID_SERVICE_ID'; end;
  if v_service is null then
   insert into public.tower_services(name,description,price,billing_timing,allow_quantity,cancelable)
   values(v_name,coalesce(p_payload->>'description',''),v_price,v_timing,coalesce((p_payload->>'allowQuantity')::boolean,false),
    coalesce((p_payload->>'cancelable')::boolean,true)) returning service_id into v_service;
  else
   update public.tower_services set name=v_name,description=coalesce(p_payload->>'description',''),price=v_price,
    billing_timing=v_timing,allow_quantity=coalesce((p_payload->>'allowQuantity')::boolean,false),
    cancelable=coalesce((p_payload->>'cancelable')::boolean,true),updated_at=now() where service_id=v_service;
   if not found then raise exception 'SERVICE_NOT_FOUND'; end if;
  end if;
  insert into public.tower_audit(actor_id,action,entity,entity_id) values(a.user_id,'SAVE_SERVICE','SERVICE',v_service::text);
  return jsonb_build_object('success',true,'serviceId',v_service);
 end if;
 if p_action='status' then
  begin v_service:=(p_payload->>'serviceId')::uuid; exception when invalid_text_representation then raise exception 'INVALID_SERVICE_ID'; end;
  v_decision:=upper(coalesce(p_payload->>'status',''));
  if v_decision not in ('ACTIVE','INACTIVE') then raise exception 'INVALID_STATUS'; end if;
  update public.tower_services set status=v_decision,updated_at=now() where service_id=v_service;
  if not found then raise exception 'SERVICE_NOT_FOUND'; end if;
  insert into public.tower_audit(actor_id,action,entity,entity_id) values(a.user_id,'SET_SERVICE_STATUS','SERVICE',v_service::text);
  return jsonb_build_object('success',true);
 end if;
 if p_action='requests' then
  return coalesce((select jsonb_agg(jsonb_build_object('subscriptionId',x.subscription_id,'serviceId',x.service_id,
   'unitId',x.unit_id,'unitNumber',u.unit_number,'serviceName',svc.name,'status',x.status,
   'quantity',x.quantity,'amountSnapshot',x.amount_snapshot,'requestedAt',x.requested_at,'notes',x.notes)
   order by x.requested_at desc) from public.tower_service_subscriptions x
   join public.tower_units u on u.unit_id=x.unit_id join public.tower_services svc on svc.service_id=x.service_id),'[]'::jsonb);
 end if;
 if p_action='review' then
  begin v_sub:=(p_payload->>'subscriptionId')::uuid; exception when invalid_text_representation then raise exception 'INVALID_SUBSCRIPTION_ID'; end;
  v_decision:=upper(coalesce(p_payload->>'decision',''));
  if v_decision not in ('APPROVE','REJECT') then raise exception 'INVALID_DECISION'; end if;
  select * into sub from public.tower_service_subscriptions where subscription_id=v_sub for update;
  if not found or sub.status<>'PENDING' then raise exception 'REQUEST_NOT_PENDING'; end if;
  update public.tower_service_subscriptions set status=case when v_decision='APPROVE' then 'ACTIVE' else 'REJECTED' end,
   reviewed_at=now(),reviewed_by=a.user_id,started_at=case when v_decision='APPROVE' then now() else null end,
   next_renewal_at=case when v_decision='APPROVE' then (date_trunc('month',now())+interval '1 month')::date else null end,
   notes=left(coalesce(p_payload->>'notes',''),1000),updated_at=now() where subscription_id=v_sub;
  insert into public.tower_audit(actor_id,action,entity,entity_id) values(a.user_id,'REVIEW_SERVICE_SUBSCRIPTION','SERVICE_SUBSCRIPTION',v_sub::text);
  return jsonb_build_object('success',true,'status',case when v_decision='APPROVE' then 'ACTIVE' else 'REJECTED' end);
 end if;
 raise exception 'UNKNOWN_ACTION';
end $function$
;
CREATE OR REPLACE FUNCTION public.tower_task_installments_action(p_token text, p_service_id uuid, p_action text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE a public.tower_users; s public.tower_services; w public.tower_task_workflow;
  v_dues int; v_installed int; v_paid numeric; v_count int; v_first date; v_sum numeric;
  v_d public.tower_finance_dues; v_i int; v_cents bigint; v_base bigint; v_extra bigint; v_part numeric;
  v_date date; v_result jsonb;
BEGIN
 SELECT * INTO a FROM public.tower_session_user(p_token);
 IF NOT FOUND OR a.status<>'ACTIVE' OR a.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF a.role NOT IN ('ADMIN','UNION','RESIDENT') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 SELECT * INTO s FROM public.tower_services WHERE service_id=p_service_id;
 IF NOT FOUND OR s.service_kind<>'ONE_TIME' OR s.pricing_mode<>'SHARED_TOTAL' THEN RAISE EXCEPTION 'INVALID_TASK'; END IF;
 IF a.role='RESIDENT' AND NOT EXISTS(
   SELECT 1 FROM public.tower_members m JOIN public.tower_service_subscriptions sub ON sub.unit_id=m.unit_id
   WHERE m.user_id=a.user_id AND m.ended_at IS NULL AND sub.service_id=p_service_id
 ) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action NOT IN ('list','install') THEN RAISE EXCEPTION 'INVALID_ACTION'; END IF;
 IF p_action='install' THEN
  IF a.role NOT IN ('ADMIN','UNION') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  SELECT * INTO s FROM public.tower_services WHERE service_id=p_service_id FOR UPDATE;
  IF s.enrollment_status<>'FINALIZED' THEN RAISE EXCEPTION 'ALLOCATION_NOT_FINALIZED'; END IF;
  SELECT * INTO w FROM public.tower_task_workflow WHERE service_id=p_service_id FOR UPDATE;
  IF NOT FOUND OR w.first_due_date IS NULL THEN RAISE EXCEPTION 'INSTALLMENT_START_DATE_REQUIRED'; END IF;
  v_count:=w.installment_count; v_first:=w.first_due_date;
  SELECT count(*) INTO v_installed FROM public.tower_task_due_installments i
  JOIN public.tower_finance_dues d ON d.due_id=i.due_id
  JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id WHERE sub.service_id=p_service_id;
  IF v_installed>0 THEN RAISE EXCEPTION 'INSTALLMENT_PLAN_ALREADY_INSTALLED'; END IF;
  SELECT count(*) INTO v_dues FROM public.tower_finance_dues d
  JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
  WHERE sub.service_id=p_service_id AND d.status='OPEN';
  IF v_dues=0 THEN RAISE EXCEPTION 'NO_APPROVED_DUES'; END IF;
  SELECT coalesce(sum(ap.amount),0) INTO v_paid FROM public.tower_finance_applications ap
   JOIN public.tower_finance_dues d ON d.due_id=ap.due_id
   JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
   JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
   JOIN public.tower_finance_receipts rec ON rec.receipt_id=rp.receipt_id
   WHERE sub.service_id=p_service_id AND rec.receipt_status='POSTED' AND ap.application_kind='DUE';
  IF v_paid>0 THEN RAISE EXCEPTION 'INSTALLMENTS_REQUIRE_UNPAID_DUES'; END IF;
  FOR v_d IN SELECT d.* FROM public.tower_finance_dues d
    JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
    WHERE sub.service_id=p_service_id AND d.status='OPEN' ORDER BY d.due_id FOR UPDATE OF d
  LOOP
    v_cents:=round(v_d.amount*100)::bigint; v_base:=v_cents/v_count; v_extra:=v_cents%v_count;
    IF v_base=0 THEN RAISE EXCEPTION 'INSTALLMENTS_EXCEED_AMOUNT_CENTS'; END IF;
    FOR v_i IN 1..v_count LOOP
      v_part:=(v_base+CASE WHEN v_i<=v_extra THEN 1 ELSE 0 END)::numeric/100;
      v_date:=(v_first + make_interval(months=>(v_i-1)))::date;
      INSERT INTO public.tower_task_due_installments(due_id,installment_no,due_date,amount) VALUES(v_d.due_id,v_i,v_date,v_part);
    END LOOP;
  END LOOP;
  INSERT INTO public.tower_audit(actor_id,action,entity,entity_id) VALUES(a.user_id,'INSTALL_TASK_DUE_SCHEDULE','SERVICE',p_service_id::text);
  INSERT INTO public.tower_task_events(service_id,event_kind,message,actor_id)
  VALUES(p_service_id,'PLAN_UPDATED','تم تثبيت جدول أقساط المهمة',a.user_id);
 END IF;
 SELECT coalesce(jsonb_agg(jsonb_build_object('dueId',q.due_id,'unitId',q.unit_id,'installment',q.installment_no,
   'dueDate',q.due_date,'amount',q.amount,'paid',greatest(0,least(q.amount,q.paid_total-coalesce(q.prior_amount,0))),
   'remaining',q.amount-greatest(0,least(q.amount,q.paid_total-coalesce(q.prior_amount,0))))
  ORDER BY q.unit_id,q.installment_no),'[]'::jsonb) INTO v_result
 FROM (
  SELECT d.due_id,d.unit_id,i.installment_no,i.due_date,i.amount,
   sum(i.amount) OVER(PARTITION BY d.due_id ORDER BY i.installment_no ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) prior_amount,
   (SELECT coalesce(sum(ap.amount),0) FROM public.tower_finance_applications ap
    JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
    JOIN public.tower_finance_receipts rec ON rec.receipt_id=rp.receipt_id
    WHERE ap.due_id=d.due_id AND ap.application_kind='DUE' AND rec.receipt_status='POSTED') paid_total
  FROM public.tower_task_due_installments i
  JOIN public.tower_finance_dues d ON d.due_id=i.due_id
  JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
  WHERE sub.service_id=p_service_id AND d.status='OPEN'
  AND (a.role IN ('ADMIN','UNION') OR EXISTS(SELECT 1 FROM public.tower_members m
    WHERE m.user_id=a.user_id AND m.unit_id=d.unit_id AND m.ended_at IS NULL))
 ) q;
 RETURN jsonb_build_object('success',true,'rows',v_result);
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_task_recompute_ready_213(p_service_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE w public.tower_task_workflow; svc public.tower_services; v_paid numeric; v_ok_date boolean; v_ok_money boolean;
BEGIN
 SELECT * INTO svc FROM public.tower_services WHERE service_id=p_service_id FOR UPDATE;
 IF NOT FOUND OR svc.enrollment_status<>'FINALIZED' THEN RETURN; END IF;
 SELECT * INTO w FROM public.tower_task_workflow WHERE service_id=p_service_id FOR UPDATE;
 IF NOT FOUND OR w.stage<>'COLLECT_FUNDS' OR w.start_rule='MANUAL' THEN RETURN; END IF;
 SELECT coalesce(sum(ap.amount),0) INTO v_paid FROM public.tower_finance_applications ap
 JOIN public.tower_finance_dues d ON d.due_id=ap.due_id
 JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
 JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
 JOIN public.tower_finance_receipts r ON r.receipt_id=rp.receipt_id
 WHERE sub.service_id=p_service_id AND ap.application_kind='DUE' AND r.receipt_status='POSTED';
 v_ok_date:=w.execution_date IS NOT NULL AND w.execution_date<=current_date;
 v_ok_money:=(svc.total_budget-coalesce((SELECT c.amount FROM public.tower_task_fund_contributions c WHERE c.service_id=p_service_id),0))>0 AND v_paid*100 >= (svc.total_budget-coalesce((SELECT c.amount FROM public.tower_task_fund_contributions c WHERE c.service_id=p_service_id),0))*w.collection_threshold;
 IF (w.start_rule='DATE' AND v_ok_date) OR (w.start_rule='COLLECTION' AND v_ok_money)
 OR (w.start_rule='DATE_AND_COLLECTION' AND v_ok_date AND v_ok_money) THEN
  UPDATE public.tower_task_workflow SET stage='READY',revision=revision+1,updated_at=now()
  WHERE service_id=p_service_id AND stage='COLLECT_FUNDS';
 END IF;
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_task_workflow_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_actor public.tower_users; v_service public.tower_services; v_id uuid; v_w public.tower_task_workflow; v_data jsonb; v_rows jsonb; v_admin boolean;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status <> 'ACTIVE' OR v_actor.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 v_admin := v_actor.role IN ('ADMIN','UNION');
 IF p_action='list' THEN
  IF NOT v_admin AND v_actor.role<>'RESIDENT' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  SELECT coalesce(jsonb_agg(jsonb_build_object(
     'serviceId',s.service_id,'stage',coalesce(w.stage,CASE WHEN s.enrollment_status='OPEN' THEN 'COLLECT_SUBSCRIBERS' ELSE 'COLLECT_FUNDS' END),
     'executionDate',w.execution_date,'startRule',coalesce(w.start_rule,'MANUAL'),
     'collectionThreshold',coalesce(w.collection_threshold,100),'executionPercent',coalesce(w.execution_percent,0),
     'installmentCount',coalesce(w.installment_count,1),'firstDueDate',w.first_due_date,
     'fundContributionProposed',coalesce(w.fund_contribution_proposed,0),
     'revision',coalesce(w.revision,0),
     'collected',coalesce(fin.collected,0),'approvedDues',coalesce(fin.due_total,0),
     'fundContributionPosted',coalesce((SELECT c.amount FROM public.tower_task_fund_contributions c WHERE c.service_id=s.service_id),0),
     'financialNote','مساهمة الصندوق المقترحة لا تدخل في التحصيل إلا بعد تنفيذ تحويل مالي موثق') ORDER BY s.name),'[]'::jsonb)
   INTO v_rows
   FROM public.tower_services s
   LEFT JOIN public.tower_task_workflow w ON w.service_id=s.service_id
   LEFT JOIN LATERAL (
      SELECT coalesce(sum(d.amount),0) due_total,
      coalesce(sum((SELECT coalesce(sum(a.amount),0)
        FROM public.tower_finance_applications a
        JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=a.portion_id
        JOIN public.tower_finance_receipts r ON r.receipt_id=rp.receipt_id AND r.receipt_status='POSTED'
        WHERE a.due_id=d.due_id AND a.application_kind='DUE')),0) collected
      FROM public.tower_finance_dues d
      JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
      WHERE sub.service_id=s.service_id AND d.status='OPEN'
   ) fin ON true
   WHERE s.service_kind='ONE_TIME' AND s.pricing_mode='SHARED_TOTAL'
     AND (v_admin OR EXISTS(
       SELECT 1 FROM public.tower_members m JOIN public.tower_service_subscriptions ss ON ss.unit_id=m.unit_id
       WHERE m.user_id=v_actor.user_id AND m.ended_at IS NULL AND ss.service_id=s.service_id
     ) OR s.status='ACTIVE');
  RETURN v_rows;
 END IF;
 IF NOT v_admin THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action<>'save' THEN RAISE EXCEPTION 'INVALID_ACTION'; END IF;
 BEGIN v_id:=(p_payload->>'serviceId')::uuid; EXCEPTION WHEN others THEN RAISE EXCEPTION 'INVALID_SERVICE_ID'; END;
 SELECT * INTO v_service FROM public.tower_services WHERE service_id=v_id FOR UPDATE;
 IF NOT FOUND OR v_service.service_kind<>'ONE_TIME' OR v_service.pricing_mode<>'SHARED_TOTAL' THEN RAISE EXCEPTION 'INVALID_TASK'; END IF;
 IF (p_payload->>'stage') NOT IN ('COLLECT_SUBSCRIBERS','COLLECT_FUNDS','READY','IN_PROGRESS','COMPLETED') THEN RAISE EXCEPTION 'INVALID_STAGE'; END IF;
 IF v_service.enrollment_status<>'OPEN' AND p_payload->>'stage'='COLLECT_SUBSCRIBERS' THEN RAISE EXCEPTION 'ENROLLMENT_NOT_OPEN'; END IF;
 IF v_service.enrollment_status<>'FINALIZED' AND p_payload->>'stage' IN ('READY','IN_PROGRESS','COMPLETED') THEN RAISE EXCEPTION 'ALLOCATION_NOT_FINALIZED'; END IF;
 IF coalesce((p_payload->>'executionPercent')::int,-1) NOT BETWEEN 0 AND 100 THEN RAISE EXCEPTION 'INVALID_EXECUTION_PERCENT'; END IF;
 IF coalesce((p_payload->>'installmentCount')::int,-1) NOT BETWEEN 1 AND 36 THEN RAISE EXCEPTION 'INVALID_INSTALLMENTS'; END IF;
 IF coalesce((p_payload->>'collectionThreshold')::int,-1) NOT BETWEEN 1 AND 100 THEN RAISE EXCEPTION 'INVALID_THRESHOLD'; END IF;
 IF p_payload->>'startRule' NOT IN ('MANUAL','DATE','COLLECTION','DATE_AND_COLLECTION') THEN RAISE EXCEPTION 'INVALID_START_RULE'; END IF;
 IF (p_payload->>'fundContributionProposed')::numeric < 0 OR (p_payload->>'fundContributionProposed')::numeric > v_service.total_budget THEN RAISE EXCEPTION 'INVALID_FUND_CONTRIBUTION'; END IF;
 IF v_service.enrollment_status='FINALIZED' AND (p_payload->>'fundContributionProposed')::numeric <> coalesce((SELECT fund_contribution_proposed FROM public.tower_task_workflow WHERE service_id=v_id),0) THEN RAISE EXCEPTION 'CONTRIBUTION_LOCKED_AFTER_FINALIZATION'; END IF;
 INSERT INTO public.tower_task_workflow(service_id,stage,execution_date,start_rule,collection_threshold,execution_percent,installment_count,first_due_date,fund_contribution_proposed,updated_by)
 VALUES(v_id,p_payload->>'stage',nullif(p_payload->>'executionDate','')::date,p_payload->>'startRule',(p_payload->>'collectionThreshold')::int,(p_payload->>'executionPercent')::int,(p_payload->>'installmentCount')::int,nullif(p_payload->>'firstDueDate','')::date,(p_payload->>'fundContributionProposed')::numeric,v_actor.user_id)
 ON CONFLICT(service_id) DO UPDATE SET stage=excluded.stage,execution_date=excluded.execution_date,start_rule=excluded.start_rule,
 collection_threshold=excluded.collection_threshold,execution_percent=excluded.execution_percent,installment_count=excluded.installment_count,
 first_due_date=excluded.first_due_date,fund_contribution_proposed=excluded.fund_contribution_proposed,updated_by=v_actor.user_id,
 revision=tower_task_workflow.revision+1,updated_at=now();
 INSERT INTO public.tower_audit(actor_id,action,entity,entity_id) VALUES(v_actor.user_id,'UPDATE_TASK_WORKFLOW','SERVICE',v_id::text);
 RETURN jsonb_build_object('success',true,'serviceId',v_id);
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_unit_task_balances_read_for_unit(p_token text, p_unit_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE a public.tower_users; v_rows jsonb;
BEGIN
 SELECT * INTO a FROM public.tower_session_user(p_token);
 IF NOT FOUND OR a.status <> 'ACTIVE' OR a.must_change_pin THEN
  RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF a.role <> 'RESIDENT' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_unit_id IS NULL THEN RAISE EXCEPTION 'UNIT_REQUIRED'; END IF;
 IF NOT EXISTS (
  SELECT 1 FROM public.tower_members m
  JOIN public.tower_units u ON u.unit_id=m.unit_id
  WHERE m.user_id=a.user_id AND m.unit_id=p_unit_id
    AND m.ended_at IS NULL AND u.status='ACTIVE'
 ) THEN RAISE EXCEPTION 'UNIT_ACCESS_DENIED'; END IF;
 -- One SQL snapshot. Only applications to this unit's OPEN dues count as paid;
 -- unapplied advances, reversed receipts and fund contributions are excluded.
 SELECT coalesce(jsonb_agg(jsonb_build_object(
   'serviceId',q.service_id,'due',q.due,'paid',q.paid,
   'remaining',q.due-q.paid,'dueCount',q.due_count
 ) ORDER BY q.service_id),'[]'::jsonb) INTO v_rows
 FROM (
  SELECT sub.service_id, sum(d.amount) AS due, sum(p.paid) AS paid, count(*) AS due_count
  FROM public.tower_finance_dues d
  JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id
    AND sub.unit_id=d.unit_id
  JOIN public.tower_services s ON s.service_id=sub.service_id
  CROSS JOIN LATERAL (
   SELECT coalesce(sum(ap.amount),0) AS paid
   FROM public.tower_finance_applications ap
   JOIN public.tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id
     AND rp.account_id=d.account_id
   JOIN public.tower_finance_receipts rec ON rec.receipt_id=rp.receipt_id
     AND rec.unit_id=d.unit_id AND rec.receipt_status='POSTED'
   WHERE ap.due_id=d.due_id AND ap.application_kind='DUE'
  ) p
  WHERE d.unit_id=p_unit_id AND d.status='OPEN'
    AND s.service_kind='ONE_TIME' AND s.pricing_mode='SHARED_TOTAL'
    AND s.enrollment_status='FINALIZED'
  GROUP BY sub.service_id
 ) q;
 RETURN jsonb_build_object('unitId',p_unit_id,'scope','UNIT_TASK_DUES','readOnly',true,'rows',v_rows);
END $function$
;
CREATE OR REPLACE FUNCTION public.tower_finance_prevent_link_mutation_internal()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
 IF EXISTS (SELECT 1 FROM public.tower_finance_advance_use_subscriptions x WHERE x.link_id=OLD.link_id)
 THEN RAISE EXCEPTION 'ATTRIBUTED_LINK_IMMUTABLE'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 IF NEW.advance_application_id IS DISTINCT FROM OLD.advance_application_id
 OR NEW.subscription_id IS DISTINCT FROM OLD.subscription_id
 OR NEW.amount IS DISTINCT FROM OLD.amount THEN
  RAISE EXCEPTION 'ADVANCE_LINK_REASSIGNMENT_FORBIDDEN'; END IF;
 RETURN NEW;
END; $function$
;
CREATE TRIGGER tower_finance_prevent_link_mutation BEFORE DELETE OR UPDATE ON tower_finance_advance_subscription_links FOR EACH ROW EXECUTE FUNCTION tower_finance_prevent_link_mutation_internal();
CREATE OR REPLACE FUNCTION public.tower_finance_validate_advance_subscription_link_internal()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_advance record; v_sub record; v_total numeric(16,2);
BEGIN
 SELECT app.amount, app.application_kind, p.account_id, r.unit_id, a.service_id
 INTO v_advance FROM public.tower_finance_applications app
 JOIN public.tower_finance_receipt_portions p ON p.portion_id=app.portion_id
 JOIN public.tower_finance_receipts r ON r.receipt_id=p.receipt_id
 JOIN public.tower_finance_accounts a ON a.account_id=p.account_id
 WHERE app.application_id=NEW.advance_application_id FOR UPDATE OF app;
 IF NOT FOUND OR v_advance.application_kind<>'ADVANCE' THEN
  RAISE EXCEPTION 'ATTRIBUTION_REQUIRES_ADVANCE'; END IF;
 SELECT unit_id,service_id INTO v_sub FROM public.tower_service_subscriptions
 WHERE subscription_id=NEW.subscription_id FOR SHARE;
 IF NOT FOUND OR v_sub.unit_id<>v_advance.unit_id OR v_sub.service_id<>v_advance.service_id THEN
  RAISE EXCEPTION 'ADVANCE_SUBSCRIPTION_SCOPE_MISMATCH'; END IF;
 SELECT COALESCE(sum(amount),0) INTO v_total
 FROM public.tower_finance_advance_subscription_links
 WHERE advance_application_id=NEW.advance_application_id
 AND (TG_OP='INSERT' OR link_id<>NEW.link_id);
 IF v_total+NEW.amount>v_advance.amount THEN RAISE EXCEPTION 'ADVANCE_ATTRIBUTION_OVERFLOW'; END IF;
 RETURN NEW;
END; $function$
;
CREATE TRIGGER tower_finance_validate_advance_subscription_link BEFORE INSERT OR UPDATE ON tower_finance_advance_subscription_links FOR EACH ROW EXECUTE FUNCTION tower_finance_validate_advance_subscription_link_internal();
CREATE OR REPLACE FUNCTION public.tower_finance_validate_advance_use_subscription_internal()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_use record; v_link record; v_due record; v_total numeric(16,2);
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'EXACT_ATTRIBUTION_IMMUTABLE'; END IF;
 SELECT advance_application_id,due_id,amount INTO v_use
 FROM public.tower_finance_advance_uses WHERE use_id=NEW.use_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'ADVANCE_USE_MISSING'; END IF;
 SELECT advance_application_id,subscription_id,amount INTO v_link
 FROM public.tower_finance_advance_subscription_links WHERE link_id=NEW.link_id FOR UPDATE;
 IF NOT FOUND OR v_link.advance_application_id<>v_use.advance_application_id
    OR v_link.subscription_id<>NEW.subscription_id THEN RAISE EXCEPTION 'ATTRIBUTION_LINK_MISMATCH'; END IF;
 SELECT subscription_id INTO v_due FROM public.tower_finance_dues WHERE due_id=v_use.due_id FOR SHARE;
 IF NOT FOUND OR v_due.subscription_id IS DISTINCT FROM NEW.subscription_id THEN
  RAISE EXCEPTION 'ADVANCE_USED_FOR_DIFFERENT_SUBSCRIPTION'; END IF;
 SELECT COALESCE(sum(x.amount),0) INTO v_total
 FROM public.tower_finance_advance_use_subscriptions s
 JOIN public.tower_finance_advance_uses x ON x.use_id=s.use_id
 WHERE s.link_id=NEW.link_id;
 IF v_total+v_use.amount>v_link.amount THEN RAISE EXCEPTION 'LINK_CONSUMPTION_OVERFLOW'; END IF;
 RETURN NEW;
END; $function$
;
CREATE TRIGGER tower_finance_exact_advance_use_guard BEFORE INSERT OR DELETE OR UPDATE ON tower_finance_advance_use_subscriptions FOR EACH ROW EXECUTE FUNCTION tower_finance_validate_advance_use_subscription_internal();
CREATE OR REPLACE FUNCTION public.tower_task_receipt_auto_ready_213()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_service_id uuid;
BEGIN
 IF TG_OP='INSERT' AND NEW.application_kind='DUE' THEN
  SELECT sub.service_id INTO v_service_id FROM public.tower_finance_dues d
  JOIN public.tower_service_subscriptions sub ON sub.subscription_id=d.subscription_id WHERE d.due_id=NEW.due_id;
  IF v_service_id IS NOT NULL THEN PERFORM public.tower_task_recompute_ready_213(v_service_id); END IF;
 END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_task_receipt_auto_ready_213 AFTER INSERT ON tower_finance_applications FOR EACH ROW EXECUTE FUNCTION tower_task_receipt_auto_ready_213();
CREATE OR REPLACE FUNCTION public.tower_finance_validate_beneficiary_period_internal()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_service uuid;
BEGIN
 IF NEW.effective_until IS NOT NULL AND NEW.effective_until<=NEW.effective_from THEN
  RAISE EXCEPTION 'INVALID_BENEFICIARY_PERIOD';
 END IF;
 SELECT a.service_id INTO v_service
   FROM public.tower_finance_accounts a
  WHERE a.account_id=NEW.account_id AND a.account_kind='PERSONAL_SERVICE'
    AND a.status='ACTIVE';
 IF v_service IS NULL OR v_service<>NEW.service_id THEN
  RAISE EXCEPTION 'BENEFICIARY_ACCOUNT_SERVICE_MISMATCH';
 END IF;
 -- Serialize writes affecting the same service to avoid write skew.
 PERFORM pg_advisory_xact_lock(hashtextextended(NEW.service_id::text, 73125));
 IF EXISTS (
  SELECT 1 FROM public.tower_finance_service_beneficiaries b
  WHERE b.service_id=NEW.service_id
    AND b.beneficiary_period_id<>NEW.beneficiary_period_id
    AND daterange(b.effective_from,b.effective_until,'[)')
       && daterange(NEW.effective_from,NEW.effective_until,'[)')
 ) THEN RAISE EXCEPTION 'OVERLAPPING_BENEFICIARY_PERIOD'; END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_finance_beneficiary_overlap_guard BEFORE INSERT OR UPDATE OF service_id, account_id, effective_from, effective_until ON tower_finance_service_beneficiaries FOR EACH ROW EXECUTE FUNCTION tower_finance_validate_beneficiary_period_internal();
CREATE OR REPLACE FUNCTION public.tower_require_manager_phone()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions', 'pg_temp'
AS $function$
BEGIN
 IF NEW.member_role='MANAGER' AND NEW.ended_at IS NULL
    AND (TG_OP='INSERT' OR OLD.member_role IS DISTINCT FROM 'MANAGER' OR OLD.ended_at IS NOT NULL OR NEW.user_id IS DISTINCT FROM OLD.user_id)
    AND NOT EXISTS (SELECT 1 FROM public.tower_users u WHERE u.user_id=NEW.user_id AND length(btrim(coalesce(u.phone,''))) BETWEEN 5 AND 40) THEN
    RAISE EXCEPTION 'PHONE_REQUIRED_FOR_MANAGER';
 END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_require_manager_phone BEFORE INSERT OR UPDATE ON tower_members FOR EACH ROW EXECUTE FUNCTION tower_require_manager_phone();
CREATE OR REPLACE FUNCTION public.tower_notify_business_event()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare v_title text; v_body text; v_kind text; v_user uuid; v_unit uuid; v_role text; v_entity text; v_id text;
begin
 if tg_op <> 'UPDATE' or new.status is not distinct from old.status then return new; end if;
 if tg_table_name='tower_registration_requests' then
  if new.status not in ('APPROVED','REJECTED','ACTIVATED') then return new; end if;
  v_kind:='REGISTRATION'; v_unit:=new.unit_id; v_entity:='registration'; v_id:=new.request_id::text;
  if new.status='APPROVED' then
   -- User can read their activation notification after obtaining an active session.
   v_user:=new.resulting_user_id; v_title:='تمت الموافقة على طلب التسجيل';
  elsif new.status='REJECTED' then
   -- No authenticated account exists for a rejected applicant: only admins receive a status audit notice.
   v_role:='ADMIN'; v_unit:=null; v_title:='تم رفض طلب تسجيل';
  else
   v_user:=new.resulting_user_id; v_title:='تم تفعيل الحساب';
  end if;
 elsif tg_table_name='tower_collection_reports' then
  v_kind:='COLLECTION'; v_entity:='collection_report'; v_id:=new.report_id::text;
  if new.status='PENDING_APPROVAL' then v_role:='UNION'; v_title:='تقرير تحصيل بانتظار الاعتماد';
  elsif new.status in ('APPROVED','NEEDS_CHANGES') then v_user:=new.collector_id; v_title:=case when new.status='APPROVED' then 'تم اعتماد تقرير التحصيل' else 'تقرير تحصيل بحاجة لتعديل' end;
  else return new; end if;
 elsif tg_table_name='tower_service_subscriptions' then
  v_kind:='SERVICE'; v_entity:='service_subscription'; v_id:=new.subscription_id::text;
  if new.status in ('ACTIVE','REJECTED','ENDED') then
   v_user:=new.requested_by; v_title:=case new.status when 'ACTIVE' then 'تم اعتماد اشتراك الخدمة' when 'REJECTED' then 'تم رفض طلب اشتراك الخدمة' else 'انتهى اشتراك الخدمة' end;
  else return new; end if;
 elsif tg_table_name='tower_service_change_requests' then
  if new.status not in ('APPROVED','REJECTED') then return new; end if;
  v_kind:='SERVICE'; v_entity:='service_change'; v_id:=new.request_id::text;
  v_user:=new.requested_by; v_title:=case when new.status='APPROVED' then 'تم اعتماد تعديل الاشتراك' else 'تم رفض تعديل الاشتراك' end;
 else return new; end if;
 if v_user is null and v_unit is null and v_role is null then return new; end if;
 insert into public.tower_notifications(user_id,unit_id,target_role,type,title,body,entity,entity_id)
 values(v_user,v_unit,v_role,v_kind,v_title,'',v_entity,v_id);
 return new;
end $function$
;
CREATE TRIGGER tower_notify_service_change AFTER UPDATE OF status ON tower_service_change_requests FOR EACH ROW EXECUTE FUNCTION tower_notify_business_event();
CREATE OR REPLACE FUNCTION public.tower_notify_business_event()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare v_title text; v_body text; v_kind text; v_user uuid; v_unit uuid; v_role text; v_entity text; v_id text;
begin
 if tg_op <> 'UPDATE' or new.status is not distinct from old.status then return new; end if;
 if tg_table_name='tower_registration_requests' then
  if new.status not in ('APPROVED','REJECTED','ACTIVATED') then return new; end if;
  v_kind:='REGISTRATION'; v_unit:=new.unit_id; v_entity:='registration'; v_id:=new.request_id::text;
  if new.status='APPROVED' then
   -- User can read their activation notification after obtaining an active session.
   v_user:=new.resulting_user_id; v_title:='تمت الموافقة على طلب التسجيل';
  elsif new.status='REJECTED' then
   -- No authenticated account exists for a rejected applicant: only admins receive a status audit notice.
   v_role:='ADMIN'; v_unit:=null; v_title:='تم رفض طلب تسجيل';
  else
   v_user:=new.resulting_user_id; v_title:='تم تفعيل الحساب';
  end if;
 elsif tg_table_name='tower_collection_reports' then
  v_kind:='COLLECTION'; v_entity:='collection_report'; v_id:=new.report_id::text;
  if new.status='PENDING_APPROVAL' then v_role:='UNION'; v_title:='تقرير تحصيل بانتظار الاعتماد';
  elsif new.status in ('APPROVED','NEEDS_CHANGES') then v_user:=new.collector_id; v_title:=case when new.status='APPROVED' then 'تم اعتماد تقرير التحصيل' else 'تقرير تحصيل بحاجة لتعديل' end;
  else return new; end if;
 elsif tg_table_name='tower_service_subscriptions' then
  v_kind:='SERVICE'; v_entity:='service_subscription'; v_id:=new.subscription_id::text;
  if new.status in ('ACTIVE','REJECTED','ENDED') then
   v_user:=new.requested_by; v_title:=case new.status when 'ACTIVE' then 'تم اعتماد اشتراك الخدمة' when 'REJECTED' then 'تم رفض طلب اشتراك الخدمة' else 'انتهى اشتراك الخدمة' end;
  else return new; end if;
 elsif tg_table_name='tower_service_change_requests' then
  if new.status not in ('APPROVED','REJECTED') then return new; end if;
  v_kind:='SERVICE'; v_entity:='service_change'; v_id:=new.request_id::text;
  v_user:=new.requested_by; v_title:=case when new.status='APPROVED' then 'تم اعتماد تعديل الاشتراك' else 'تم رفض تعديل الاشتراك' end;
 else return new; end if;
 if v_user is null and v_unit is null and v_role is null then return new; end if;
 insert into public.tower_notifications(user_id,unit_id,target_role,type,title,body,entity,entity_id)
 values(v_user,v_unit,v_role,v_kind,v_title,'',v_entity,v_id);
 return new;
end $function$
;
CREATE TRIGGER tower_notify_subscription AFTER UPDATE OF status ON tower_service_subscriptions FOR EACH ROW EXECUTE FUNCTION tower_notify_business_event();
CREATE OR REPLACE FUNCTION public.tower_shared_service_subscription_guard_201()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_service uuid; v_mode text; v_status text;
BEGIN
 v_service:=CASE WHEN TG_OP='DELETE' THEN OLD.service_id ELSE NEW.service_id END;
 SELECT pricing_mode,enrollment_status INTO v_mode,v_status FROM public.tower_services WHERE service_id=v_service FOR UPDATE;
 IF v_mode='SHARED_TOTAL' THEN
  IF v_status<>'OPEN' THEN RAISE EXCEPTION 'SHARED_ENROLLMENT_CLOSED'; END IF;
  IF TG_OP='UPDATE' AND NEW.service_id IS DISTINCT FROM OLD.service_id THEN RAISE EXCEPTION 'SHARED_SUBSCRIPTION_TRANSFER_FORBIDDEN'; END IF;
  IF TG_OP<>'DELETE' AND (NEW.quantity<>1 OR NEW.auto_renew=true) THEN
   -- Legacy request defaults to auto_renew=true: adjust to false server-side for ONE_TIME shared tasks.
   NEW.quantity:=1; NEW.auto_renew:=false;
  END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_shared_service_sub_guard_201 BEFORE INSERT OR DELETE OR UPDATE ON tower_service_subscriptions FOR EACH ROW EXECUTE FUNCTION tower_shared_service_subscription_guard_201();
CREATE OR REPLACE FUNCTION public.tower_task_fund_plan_guard_216()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
 IF OLD.fund_contribution_proposed IS DISTINCT FROM NEW.fund_contribution_proposed
   AND EXISTS (SELECT 1 FROM public.tower_task_fund_contributions WHERE service_id=OLD.service_id)
 THEN RAISE EXCEPTION 'POSTED_FUND_CONTRIBUTION_LOCKED'; END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_task_fund_plan_guard_216 BEFORE UPDATE OF fund_contribution_proposed ON tower_task_workflow FOR EACH ROW EXECUTE FUNCTION tower_task_fund_plan_guard_216();
CREATE OR REPLACE FUNCTION public.tower_task_workflow_notify_212()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
BEGIN
 IF TG_OP='INSERT' OR NEW.stage IS DISTINCT FROM OLD.stage THEN
  INSERT INTO public.tower_task_events(service_id,event_kind,message,actor_id)
  VALUES(NEW.service_id,'STAGE_CHANGED','تغيرت مرحلة المهمة',NEW.updated_by);
 ELSIF NEW.execution_percent IS DISTINCT FROM OLD.execution_percent THEN
  INSERT INTO public.tower_task_events(service_id,event_kind,message,actor_id)
  VALUES(NEW.service_id,'EXECUTION_UPDATED','تحدثت نسبة إنجاز الأعمال',NEW.updated_by);
 ELSIF NEW.installment_count IS DISTINCT FROM OLD.installment_count OR NEW.execution_date IS DISTINCT FROM OLD.execution_date
 OR NEW.first_due_date IS DISTINCT FROM OLD.first_due_date THEN
  INSERT INTO public.tower_task_events(service_id,event_kind,message,actor_id)
  VALUES(NEW.service_id,'PLAN_UPDATED','تغيرت خطة المهمة',NEW.updated_by);
 END IF;
 RETURN NEW;
END $function$
;
CREATE TRIGGER tower_task_workflow_notice_212 AFTER INSERT OR UPDATE ON tower_task_workflow FOR EACH ROW EXECUTE FUNCTION tower_task_workflow_notify_212();
CREATE FUNCTION public.tower_session_user(p_token text) RETURNS SETOF public.tower_users LANGUAGE sql STABLE AS $$SELECT * FROM public.tower_users WHERE user_id::text=p_token$$;