-- Synthetic local schema inferred from the supplied SQL237 function and known legacy statuses.
-- This is not a complete export of unknown live constraints. No real users or outbound notifications.
CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean DEFAULT false,name text,title text DEFAULT 'أ.',custom_title text);
CREATE TABLE tower_units(unit_id uuid PRIMARY KEY,status text DEFAULT 'ACTIVE');
CREATE TABLE tower_members(unit_id uuid REFERENCES tower_units,user_id uuid REFERENCES tower_users,member_role text,ended_at timestamptz);
CREATE TABLE tower_audit(audit_id uuid DEFAULT gen_random_uuid(),actor_id uuid,action text,entity text,entity_id text);
CREATE TABLE tower_notifications(notification_id uuid DEFAULT gen_random_uuid(),user_id uuid,unit_id uuid,target_role text,type text,title text,body text,entity text,entity_id text);
CREATE TABLE tower_trip_settlements(settlement_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid REFERENCES tower_units,
 sequence_no integer,status text DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','CANCELED')),settled_at timestamptz DEFAULT now(),settled_by uuid,
 manager_display_name text,purchases_total numeric(14,2),fees_total numeric(14,2),gross_total numeric(14,2),prior_payments numeric(14,2),closing_payment numeric(14,2),credit_after numeric(14,2),
 canceled_at timestamptz,canceled_by uuid,cancel_reason text,UNIQUE(unit_id,sequence_no),
 CHECK(gross_total=purchases_total+fees_total),CHECK(closing_payment=greatest(0,gross_total-prior_payments)),CHECK(credit_after=greatest(0,prior_payments-gross_total)));
CREATE TABLE tower_trips(trip_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid REFERENCES tower_units,status text DEFAULT 'OPEN',settlement_id uuid REFERENCES tower_trip_settlements,
 purchases_total numeric(14,2),distance_fee numeric(14,2),extra_fee numeric(14,2),total_due numeric(14,2),distance text DEFAULT 'NEAR',items jsonb DEFAULT '[]',notes text DEFAULT '',actor_role text DEFAULT 'RESIDENT',
 created_at timestamptz DEFAULT now(),updated_at timestamptz DEFAULT now());
CREATE TABLE tower_trip_payments(payment_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid REFERENCES tower_units,amount numeric(14,2) CHECK(amount>0),
 status text DEFAULT 'OPEN' CHECK(status IN ('OPEN','APPLIED','CANCELED','REVERSED')),settlement_id uuid REFERENCES tower_trip_settlements,
 source text CHECK(source IN ('RESIDENT_PAYMENT','SETTLEMENT_CLOSING','SETTLEMENT_CREDIT')),reference text DEFAULT '',reversal_reason text,created_by uuid,
 created_at timestamptz DEFAULT now(),updated_at timestamptz DEFAULT now());
CREATE TABLE tower_trip_settlement_details(settlement_id uuid REFERENCES tower_trip_settlements,unit_id uuid,detail_type text CHECK(detail_type IN ('TRIP','PAYMENT','CREDIT_CARRY')),entity_id uuid,snapshot jsonb,amount numeric(14,2),status text DEFAULT 'ACTIVE');
CREATE FUNCTION tower_session_user(p_token text) RETURNS SETOF tower_users LANGUAGE sql STABLE AS $$SELECT * FROM tower_users WHERE user_id::text=p_token$$;
CREATE FUNCTION tower_person_label_231(p_name text,p_title text,p_user uuid) RETURNS text LANGUAGE sql STABLE AS $$SELECT coalesce(nullif(p_title,''),'أ.')||' '||p_name$$;
CREATE FUNCTION tower_notify_settlement() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN IF NEW.status='ACTIVE' THEN INSERT INTO tower_notifications(unit_id,type,title,body,entity,entity_id) VALUES(NEW.unit_id,'SETTLEMENT','تم اعتماد تسوية المشاوير','','trip_settlement',NEW.settlement_id::text);END IF;RETURN NEW;END$$;
CREATE TRIGGER tower_notify_settlement_created AFTER INSERT ON tower_trip_settlements FOR EACH ROW EXECUTE FUNCTION tower_notify_settlement();
-- A local marker verifies that pre-existing snapshot INSERT triggers remain active.
CREATE FUNCTION fixture_attach_history() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN IF NEW.detail_type='TRIP' THEN NEW.snapshot:=NEW.snapshot||'{"changeHistory":[{"type":"fixture-existing-history"}]}'::jsonb;END IF;RETURN NEW;END$$;
CREATE TRIGGER fixture_trip_history BEFORE INSERT ON tower_trip_settlement_details FOR EACH ROW EXECUTE FUNCTION fixture_attach_history();
