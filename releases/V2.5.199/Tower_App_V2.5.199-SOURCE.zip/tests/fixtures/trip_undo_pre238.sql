-- Local tables and the genuine undo branch supplied by the user in SQL237.
-- This fixture does NOT reproduce unknown production constraints or the other account actions.
CREATE TABLE tower_trips(trip_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid,status text,settlement_id uuid,created_at timestamptz DEFAULT now(),updated_at timestamptz DEFAULT now());
CREATE TABLE tower_trip_payments(payment_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid,amount numeric,status text,settlement_id uuid,source text,reference text,reversal_reason text,updated_at timestamptz DEFAULT now());
CREATE TABLE tower_trip_settlements(settlement_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),unit_id uuid,sequence_no integer,status text,settled_at timestamptz DEFAULT now(),canceled_at timestamptz,canceled_by uuid,cancel_reason text);
CREATE TABLE tower_trip_settlement_details(settlement_id uuid,unit_id uuid,detail_type text,entity_id uuid,snapshot jsonb,status text);
CREATE FUNCTION tower_trip_account(p_token text,p_action text,p_payload jsonb DEFAULT '{}') RETURNS jsonb LANGUAGE plpgsql AS $function$
declare actor public.tower_users; uid uuid; v_set public.tower_trip_settlements;
begin
 select * into actor from public.tower_session_user(p_token);
 if not found or actor.must_change_pin then raise exception 'SESSION_REQUIRED'; end if;
 if actor.role<>'RESIDENT' then raise exception 'FORBIDDEN'; end if;
 uid:=(p_payload->>'unitId')::uuid;
 if not exists(select 1 from public.tower_members m join public.tower_units un on un.unit_id=m.unit_id where m.user_id=actor.user_id and m.unit_id=uid and m.ended_at is null and un.status='ACTIVE') then raise exception 'UNIT_ACCESS_DENIED'; end if;
 perform 1 from public.tower_units where unit_id=uid for update;
 if p_action='undo' then
  select * into v_set from public.tower_trip_settlements where unit_id=uid order by sequence_no desc limit 1 for update;
  if not found or v_set.status<>'ACTIVE' then raise exception 'ONLY_LATEST_SETTLEMENT'; end if;
  if exists(select 1 from public.tower_trip_payments where unit_id=uid and source='SETTLEMENT_CREDIT' and reference=v_set.settlement_id::text and (status<>'OPEN' or settlement_id is not null)) then
    raise exception 'CREDIT_ALREADY_USED'; end if;
  if exists(select 1 from public.tower_trips where unit_id=uid and status='OPEN' and created_at>v_set.settled_at) then
    raise exception 'LATER_ACCOUNT_ACTIVITY'; end if;
  update public.tower_trips set status='OPEN',settlement_id=null,updated_at=now() where settlement_id=v_set.settlement_id;
  update public.tower_trip_payments set status='REVERSED',reversal_reason='UNDO '||v_set.settlement_id::text,updated_at=now() where settlement_id=v_set.settlement_id and source='SETTLEMENT_CLOSING';
  update public.tower_trip_payments set status='OPEN',settlement_id=null,updated_at=now() where settlement_id=v_set.settlement_id and source<>'SETTLEMENT_CLOSING';
  update public.tower_trip_payments set status='CANCELED',reversal_reason='UNDO '||v_set.settlement_id::text,updated_at=now() where source='SETTLEMENT_CREDIT' and reference=v_set.settlement_id::text and status='OPEN';
  update public.tower_trip_settlement_details set status='CANCELED' where settlement_id=v_set.settlement_id;
  update public.tower_trip_settlements set status='CANCELED',canceled_at=now(),canceled_by=actor.user_id,cancel_reason=left(coalesce(p_payload->>'reason','UNDO_LATEST'),500) where settlement_id=v_set.settlement_id;
  insert into public.tower_audit(actor_id,action,entity,entity_id) values(actor.user_id,'UNDO_SETTLEMENT','TRIP_SETTLEMENT',v_set.settlement_id::text);
  return jsonb_build_object('success',true,'settlementId',v_set.settlement_id);
 end if;
 raise exception 'INVALID_OPERATION';
end $function$;
