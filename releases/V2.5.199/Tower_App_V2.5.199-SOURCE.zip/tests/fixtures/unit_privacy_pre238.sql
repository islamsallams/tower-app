-- Synthetic local visibility storage and legacy read contracts; no production rows.
-- Dues arithmetic itself is exercised by the project's existing real task engines, not these reader stand-ins.
CREATE TABLE tower_unit_fund_visibility(unit_id uuid PRIMARY KEY REFERENCES tower_units, members_can_view boolean NOT NULL DEFAULT true, changed_by uuid,updated_at timestamptz DEFAULT now());
CREATE FUNCTION tower_resident_dues_page(p_token text,p_mode text,p_group text,p_search text,p_status text,p_offset integer,p_limit integer) RETURNS jsonb LANGUAGE plpgsql AS $f$
BEGIN
 RETURN jsonb_build_object('fixture','legacy automatic-unit reader');
END $f$;
CREATE FUNCTION tower_resident_dues_page_for_unit(p_token text,p_unit_id uuid,p_mode text,p_group text,p_search text,p_status text,p_offset integer,p_limit integer) RETURNS jsonb LANGUAGE plpgsql AS $f$
BEGIN
 RETURN jsonb_build_object('fixture','explicit unit reader','unitId',p_unit_id);
END $f$;
-- Exact membership + old visibility clause from the user's SQL237 metadata, restricted aggregate stub.
CREATE FUNCTION tower_resident_fund_overview_for_unit(p_token text,p_unit_id uuid) RETURNS jsonb LANGUAGE plpgsql AS $f$
DECLARE v_actor tower_users;
BEGIN
 SELECT * INTO v_actor FROM tower_session_user(p_token);
 IF NOT FOUND OR v_actor.role<>'RESIDENT' OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF NOT EXISTS (
    SELECT 1 FROM public.tower_members m
    JOIN public.tower_units unit ON unit.unit_id=m.unit_id
    LEFT JOIN public.tower_unit_fund_visibility vis ON vis.unit_id=m.unit_id
    WHERE m.user_id=v_actor.user_id AND m.unit_id=p_unit_id
      AND m.ended_at IS NULL AND unit.status='ACTIVE'
      AND (m.member_role='MANAGER' OR COALESCE(vis.members_can_view,true))
 ) THEN RAISE EXCEPTION 'UNION_FINANCE_ACCESS_DENIED'; END IF;
 RETURN jsonb_build_object('scope','RESIDENT_BUILDING_FUND_PUBLIC','fixture',true);
END $f$;
