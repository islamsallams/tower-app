import json, os, subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=Path(os.environ.get('TOWER_QA_OUTPUT','/tmp/tower-v169-qa'))
subprocess.run(['node','tests/guard_notes_contract.mjs'],cwd=ROOT,check=True,env={**os.environ,'TOWER_QA_OUTPUT':str(OUT)})
fixtures=json.loads((OUT/'guard-notes-fixtures.json').read_text());results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900})
  def route(req):
   name=req.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if req.request.url.startswith('http://tower.test/') and name in ['index.html','app.js','styles.css']:req.fulfill(path=str(ROOT/name))
   elif req.request.url.startswith('http://tower.test/'):req.fulfill(json={'ok':True,'result':{'configured':False}})
   else:req.abort()
  page.route('**/*',route);page.goto('http://tower.test/');page.wait_for_function("typeof renderGuardTripRows==='function'")
  def mount(key):page.evaluate("rows=>{APP.ctx={user:{role:'OPERATOR'}};$('root').classList.remove('hidden');$('root').innerHTML=renderGuardTripRows(rows)}",fixtures[key]['trips'])
  def check(name,fn):
   try:fn();results.append({'viewport':width,'check':name,'status':'PASS'})
   except Exception as e:results.append({'viewport':width,'check':name,'status':'FAIL','details':str(e)})
  def normal():
   mount('normal');note=page.locator('.trip-card').first.locator('.guard-trip-notes');assert 'ملاحظة الساكن\nتجربة' in note.inner_text()
   assert note.evaluate("e=>e.previousElementSibling.classList.contains('trip-orders')")
   assert page.locator('.trip-card').first.get_by_role('button',name='إلغاء المشوار',exact=True).count()==1
   assert 'المسافة' not in page.locator('.trip-card').first.inner_text()
  check('notes below purchases preserve guard actions and hide distance',normal)
  page.screenshot(path=str(OUT/f'guard-notes-{width}.png'),full_page=True)
  def blank():
   mount('normal');assert page.locator('.trip-card').nth(1).locator('.guard-trip-notes').count()==0
  check('empty note adds no blank component',blank)
  def unsafe():
   mount('unsafe');assert page.locator('.guard-trip-notes img').count()==0;assert page.evaluate('window.badNotes===undefined');assert '<img' in page.locator('.guard-trip-notes').first.inner_text()
  check('note HTML is escaped and cannot execute',unsafe)
  def unavailable():
   mount('unavailable');assert page.locator('.trip-card').count()==2;assert page.locator('.guard-trip-notes.is-unavailable').count()==2;assert page.get_by_role('button',name='إلغاء المشوار',exact=True).count()==2
  check('notes failure keeps existing trip controls usable',unavailable)
  page.close()
 browser.close()
(OUT/'guard-notes-browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2));raise SystemExit(any(r['status']=='FAIL' for r in results))
