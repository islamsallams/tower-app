// Tower App V2.5.187 — navigation/history logic only; no browser or screen tests.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const src=fs.readFileSync('app.js','utf8'),results=[];
const fn=name=>{const start=src.indexOf('function '+name+'('),end=src.indexOf('\n}',start);return src.slice(start,end+2);};
function fixture(role='UNION',page='home'){
 const nodes={modal:{style:{removeProperty(){}},classList:{contains:()=>!c.visible,add:()=>{c.visible=false;}}},modalSheet:{replaceChildren(){},style:{removeProperty(){}}},mobileMoreMenu187:{}};
 const entries=[{towerPage:page,towerModal:false},{towerPage:page,towerModal:true,towerModalDepth:1}],pending=[];
 const c={APP:{page,managedTasks:[{serviceId:"fixture"}],ctx:{user:{role}}},visible:true,entries,pending,calls:[],blocked:false,window:{},TOWER_MODAL_STACK:[],TOWER_TASK_FORM_BASELINE:null,TOWER_TASK_FORM_ACCEPTED:false,TOWER_OTHER_FORM_BASELINE:null,
 document:{documentElement:{classList:{remove(){}}}},$:id=>id==='mobileMoreMenu187'&&!c.visible?null:nodes[id],towerModalDepth:()=>c.visible?1:0,
 towerTaskFormChanged:()=>c.blocked,towerOtherFormChanged:()=>false,towerExplicitDismiss:()=>true,
 restoreCatalogPosition183(){},restoreFundPosition183(){},toast(){},
 roleMenu:r=>r==='RESIDENT'?[['home','h','الرئيسية'],['settings','s','الإعدادات'],['managed-tasks','m','مسؤولياتي']]:[['home','h','الرئيسية'],['finance','f','المالية'],['reports','r','التقارير'],['settings','s','الإعدادات']],
 mobilePrimaryKeys:()=>['home'],allowedPage:(key,r)=>!!r&&c.roleMenu(r).some(x=>x[0]===key),
 go:async(key,fromHistory)=>{c.calls.push({key,fromHistory});c.APP.page=key;},
 history:{pushState(state){entries.push(state);},get state(){return entries.at(-1);},replaceState(state,_unused,url){entries[entries.length-1]=state;c.url=url;},back(){pending.push(()=>{entries.pop();c.APP.page=entries.at(-1).towerPage;});}}
 };c.window.confirm=()=>false;vm.createContext(c);vm.runInContext(src.split('\n').filter(line=>/^function (roleMenu|mobilePrimaryKeys)\(/.test(line)).join('\n'),c);vm.runInContext(fn('closeModal')+'\nasync '+fn('navigateFromMore187'),c);return c;
}
async function check(name,test){await test();results.push({check:name,status:'PASS'});}
await check('old close plus navigation reproduces delayed return to previous page',async()=>{const c=fixture();c.closeModal();await c.go('reports',false);assert.equal(c.APP.page,'reports');c.pending.forEach(f=>f());assert.equal(c.APP.page,'home');});
for(const role of ['ADMIN','UNION','RESIDENT','OPERATOR'])await check(`${role} every overflow destination replaces menu entry without deferred Back`,async()=>{const sample=fixture(role);for(const [key] of sample.roleMenu(role).filter(x=>!sample.mobilePrimaryKeys(role).includes(x[0]))){const c=fixture(role);await c.navigateFromMore187(key);assert.equal(c.APP.page,key);assert.equal(c.visible,false);assert.equal(c.pending.length,0);assert.equal(c.entries.length,2);assert.equal(c.entries[1].towerPage,key);assert.equal(c.entries[1].towerModal,false);assert.equal(c.calls[0].fromHistory,true);c.history.back();c.pending.shift()();assert.equal(c.APP.page,'home');}});
await check('forbidden or primary destination does not close menu or navigate',async()=>{for(const key of ['system-invalid','home']){const c=fixture();await c.navigateFromMore187(key);assert.equal(c.visible,true);assert.equal(c.calls.length,0);}});
await check('stale click after dismissal does not navigate twice',async()=>{const c=fixture();await c.navigateFromMore187('reports');await c.navigateFromMore187('settings');assert.equal(c.calls.length,1);assert.equal(c.APP.page,'reports');});
await check('rejected dismissal leaves history and destination unchanged',async()=>{const c=fixture();c.blocked=true;await c.navigateFromMore187('reports');assert.equal(c.calls.length,0);assert.equal(c.entries[1].towerModal,true);});
await check('logged out or nested modal cannot consume menu navigation',async()=>{for(const mode of ['logout','nested']){const c=fixture();if(mode==='logout')c.APP.ctx=null;else c.towerModalDepth=()=>2;await c.navigateFromMore187('reports');assert.equal(c.calls.length,0);}});
await check('menu template routes every item through guarded handler',()=>{const line=src.split('\n').find(x=>x.startsWith('function openMoreMenu('));assert(line.includes('id="mobileMoreMenu187"'));assert(line.includes("navigateFromMore187('${x[0]}')"));assert(!line.includes('closeModal();go('));});
fs.mkdirSync('qa/v2.5.187',{recursive:true});fs.writeFileSync('qa/v2.5.187/mobile-more-model-results.json',JSON.stringify(results,null,2));console.log(`${results.length} navigation logic checks PASS (no browser)`);
