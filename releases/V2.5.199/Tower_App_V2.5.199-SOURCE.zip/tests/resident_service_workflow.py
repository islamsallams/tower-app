"""Real Chromium and application service handlers; API dependency is an isolated stateful fixture."""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(os.environ.get('TOWER_TEST_ROOT',Path(__file__).resolve().parents[1]))
OUT=Path(os.environ.get('TOWER_QA_OUTPUT','/tmp/tower-v169-qa'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900});page.set_default_timeout(3000)
  state={'status':None,'quantity':1,'changes':0,'requests':0};calls=[]
  service={'serviceId':'task','serviceKind':'ONE_TIME','pricingMode':'SHARED_TOTAL','revenueKind':'PERSONAL_SERVICE','name':'مهمة اختبار','totalBudget':1900,'enrollmentStatus':'OPEN','price':0,'allowQuantity':False,'cancelable':True}
  recurring={'serviceId':'monthly','serviceKind':'RECURRING','pricingMode':'PER_SUBSCRIPTION','revenueKind':'FUND','name':'خدمة اختبار دورية','price':20,'allowQuantity':True,'cancelable':True}
  def route(req):
   if not req.request.url.startswith('http://tower.test/'):
    req.abort();return
   name=req.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if name in ['index.html','app.js','styles.css']:req.fulfill(path=str(ROOT/name));return
   data=req.request.post_data_json or {}
   if data.get('method')=='getBootstrapContext':req.fulfill(json={'ok':True,'result':{'configured':False}});return
   inner=data['args'][0];op=inner['name'];args=inner.get('args',[]);calls.append(op)
   if op=='getMyUnitGovernance':
    unit=args[0];result={'hasUnit':True,'unit':{'unitId':unit,'unitNumber':'26' if unit=='u26' else '01','unitTypeName':'سكني'},'membership':{'unitId':unit,'memberRole':'MEMBER'},'members':[],'requests':[]}
   elif op=='getMyServices':
    unit=args[0]['__activeUnitId'];subs=[]
    if state['status']:subs=[{'subscriptionId':'sub','serviceId':state.get('service','task'),'unitId':unit,'status':state['status'],'quantity':state['quantity'],'unitPriceSnapshot':20,'amountSnapshot':20*state['quantity']}]
    result={'services':[service,recurring],'subscriptions':subs,'isManager':False}
   elif op=='requestServiceSubscription':state.update(status='PENDING',service=args[0]);state['requests']+=1;result={'success':True}
   elif op=='cancelMyServiceSubscription':state['status']=None;result={'success':True}
   elif op=='updatePendingServiceSubscription':state['quantity']=args[1];result={'success':True}
   elif op=='requestServiceChange':state['changes']+=1;result={'success':True}
   elif op in ['listTaskWorkflows','listTaskNotices','listMyPersonalHandovers','listMyRefundRequests']:result=[]
   else:raise AssertionError('Unexpected operation '+op)
   req.fulfill(json={'ok':True,'result':result})
  page.route('**/*',route);page.goto('http://tower.test/');page.wait_for_function("typeof renderUnits==='function'")
  page.evaluate("APP.ctx={user:{role:'RESIDENT',userId:'resident'}};APP.token='fixture';APP.page='unit';APP.activeUnitId='u26';APP.unitChoices=[{unit:{unitId:'u26',unitNumber:'26'}},{unit:{unitId:'u01',unitNumber:'01'}}];APP.home={membership:{unitId:'u26'}};$('root').classList.remove('hidden');$('root').innerHTML='<div id=content></div>';history.replaceState({towerPage:'unit'},'','#unit')")
  def check(name,fn):
   try:fn();results.append({'viewport':width,'check':name,'status':'PASS'})
   except Exception as e:results.append({'viewport':width,'check':name,'status':'FAIL','details':str(e)})
   finally:page.evaluate("TOWER_TASK_FORM_BASELINE=null;TOWER_OTHER_FORM_BASELINE=null;towerResetModalStack();void 0");page.wait_for_timeout(80)
  def reset(status=None,svc='task'):
   state.update(status=status,quantity=1,service=svc)
   page.evaluate("APP.page='unit';APP.activeUnitId='u26';invalidateRpcCache();void 0")
   page.evaluate('renderUnits()')
  def request():
   reset();page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_role('button',name='طلب اشتراك',exact=True).click()
   assert 'الوحدة: 26' in page.locator('#modalSheet').inner_text()
   page.get_by_role('button',name='إرسال الطلب',exact=True).click()
   page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_text('طلبك قيد المراجعة',exact=True).wait_for()
   assert page.evaluate('APP.page')=='unit'
   assert page.locator('#content .page-refresh-note').count()==0
  check('request on Unit refreshes to PENDING and names selected unit',request)
  def cancel():
   reset('PENDING');page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_role('button',name='إلغاء الطلب',exact=True).click()
   page.get_by_role('button',name='إلغاء الطلب',exact=True).last.click()
   page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_role('button',name='طلب اشتراك',exact=True).wait_for()
   assert state['status'] is None
  check('cancel on Unit refreshes to no subscription',cancel)
  def approval():
   reset('PENDING');before=calls.count('getMyServices');state['status']='ACTIVE';page.evaluate('renderUnits()')
   page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_text('أنت مشترك',exact=True).wait_for()
   assert calls.count('getMyServices')>before
  check('revisit Unit fetches approval instead of cached PENDING',approval)
  def edit_quantity():
   reset('PENDING','monthly');page.locator('.resident-service-card').filter(has_text='خدمة اختبار دورية').get_by_role('button',name='تعديل الطلب',exact=True).click()
   page.locator('#sharedPromptInput').fill('2');page.get_by_role('button',name='حفظ التعديل',exact=True).click()
   page.wait_for_function("SERVICE_UI.subscriptions[0]?.quantity===2")
   assert page.evaluate('APP.page')=='unit' and state['quantity']==2
  check('pending quantity edit refreshes originating Unit',edit_quantity)
  def change_quantity():
   reset('ACTIVE','monthly');before=state['changes'];page.locator('.resident-service-card').filter(has_text='خدمة اختبار دورية').get_by_role('button',name='زيادة الكمية',exact=True).click()
   page.locator('#sharedPromptInput').fill('1');page.get_by_role('button',name='إرسال الطلب',exact=True).click()
   page.wait_for_timeout(150)
   assert state['changes']==before+1 and page.evaluate('APP.page')=='unit'
   assert page.locator('.resident-service-card').count()==2
  check('service change request refreshes originating Unit',change_quantity)
  def switched_confirmation():
   reset();before=state['requests'];page.locator('.resident-service-card').filter(has_text='مهمة اختبار').get_by_role('button',name='طلب اشتراك',exact=True).click()
   page.evaluate("APP.activeUnitId='u01';void 0");page.get_by_role('button',name='إرسال الطلب',exact=True).click();page.wait_for_timeout(100)
   assert state['requests']==before and 'الوحدة أو الحساب اتغير' in page.locator('#toast').inner_text()
  check('unit change during confirmation prevents wrong-unit submission',switched_confirmation)
  def unrelated_view():
   reset();page.evaluate("window.serviceOrigin=towerResidentServiceOrigin();APP.page='trips';$('content').innerHTML='<div id=trip-preserved>Trip view unchanged</div>';towerRefreshResidentServices(serviceOrigin)")
   assert page.locator('#trip-preserved').inner_text()=='Trip view unchanged'
  check('service refresh cannot replace Trip view after navigation',unrelated_view)
  def render_race(next_unit=False):
   reset()
   kept=page.evaluate("""async nextUnit=>{
    const original=run;let release;
    run=(name,...args)=>name==='getMyUnitGovernance'?new Promise(resolve=>release=resolve):original(name,...args);
    try{
     const pending=renderUnits();
     if(nextUnit)APP.activeUnitId='u01';else APP.page='trips';
     $('content').innerHTML='<div id=preserved-next-view>next view</div>';
     release({hasUnit:true,unit:{unitId:'u26',unitNumber:'26'},membership:{unitId:'u26',memberRole:'MEMBER'},members:[],requests:[]});
     await pending;
     return !!document.getElementById('preserved-next-view');
    }finally{run=original;}
   }""",next_unit)
   assert kept, 'late Unit response overwrote selected view'
  check('late Unit response cannot overwrite Trip view',lambda:render_race(False))
  check('late Unit response cannot overwrite switched unit',lambda:render_race(True))
  page.close()
 browser.close()
(OUT/'resident-service-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
raise SystemExit(any(r['status']=='FAIL' for r in results))
