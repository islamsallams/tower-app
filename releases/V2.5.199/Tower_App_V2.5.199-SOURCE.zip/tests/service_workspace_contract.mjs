import fs from 'node:fs';import assert from 'node:assert/strict';import worker from '../worker.js';
const sid='11111111-1111-4111-8111-111111111111',unit='22222222-2222-4222-8222-222222222222',results=[];
async function request({role='ADMIN',args=[sid],method='getServiceWorkspace',noSession=false,pin=false,failure=null}={}){
 const original=globalThis.fetch,calls=[];
 globalThis.fetch=async(url,opts={})=>{const key=new URL(url).pathname.split('/').pop(),body=JSON.parse(opts.body||'{}');calls.push({key,body});
  if(key==='tower_session_user')return Response.json(noSession?[]:[{user_id:sid,role,must_change_pin:pin,status:'ACTIVE'}]);
  if(key==='tower_service_workspace_read_232')return Response.json({serviceId:body.p_service,unitId:body.p_unit,service:{name:'خدمة fixture'},managerName:'م. اسم fixture',totals:{due:20,paid:5,remaining:15}});
  if(key==='tower_task_workflow_action'){if(failure)return Response.json({code:'P0001',message:failure},{status:400});return Response.json({success:true});}
  if(key==='tower_present_names_231')return Response.json(body.p_value);
  throw Error('Unexpected '+key);
 };
 try{const response=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{token:'fixture',name:method,args}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture'});return{status:response.status,body:await response.json(),calls};}finally{globalThis.fetch=original;}
}
async function check(name,fn){await fn();results.push({check:name,status:'PASS'});console.log('PASS',name);}
for(const role of ['ADMIN','UNION'])await check(role+' reads service-wide financial context',async()=>{const r=await request({role,args:[sid,{__activeUnitId:unit}]});assert.equal(r.status,200);assert.equal(r.calls[1].key,'tower_service_workspace_read_232');assert.equal(r.calls[1].body.p_unit,null);assert.equal(r.body.result.totals.remaining,15)});
await check('resident forwards only explicit active unit',async()=>{const r=await request({role:'RESIDENT',args:[sid,{__activeUnitId:unit,unitId:sid}]});assert.equal(r.calls[1].body.p_unit,unit);assert.equal(r.body.result.unitId,unit)});
for(const args of [[sid],[sid,{__activeUnitId:'bad'}]])await check('resident missing or malformed unit stops before read '+JSON.stringify(args),async()=>{const r=await request({role:'RESIDENT',args});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('guard blocked before any service data access',async()=>{const r=await request({role:'OPERATOR'});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('invalid service ID blocked before database read',async()=>{const r=await request({args:['bad']});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('session required before service workspace read',async()=>{const r=await request({noSession:true});assert.equal(r.status,401);assert.equal(r.calls.length,1)});
await check('temporary PIN restriction retained',async()=>{const r=await request({pin:true});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('authorized service labels use existing presentation boundary',async()=>{const r=await request();assert.equal(r.calls.at(-1).key,'tower_present_names_231');assert.deepEqual(r.body.result.totals,{due:20,paid:5,remaining:15})});
for(const failure of ['TASK_START_DATE_NOT_REACHED','TASK_START_COLLECTION_NOT_REACHED'])await check('start guard returns clear Arabic error '+failure,async()=>{const r=await request({method:'saveTaskWorkflow',args:[{serviceId:sid}],failure});assert(r.body.error);assert(/[\u0600-\u06ff]/.test(r.body.error));assert(!r.body.error.includes('تعذر إتمام العملية'));assert.equal(r.calls.filter(x=>x.key==='tower_task_workflow_action').length,1)});
fs.mkdirSync('qa/v2.5.175',{recursive:true});fs.writeFileSync('qa/v2.5.175/service-workspace-worker-results.json',JSON.stringify(results,null,2));
