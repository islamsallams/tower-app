import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE||'@electric-sql/pglite');
const db=new PGlite(),results=[],id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`;
const migration='sql/STAGING_85_Original_SQL232_SERVICE_WORKSPACE_AND_TASK_START_GUARD.sql';
async function check(name,fn){try{await fn();results.push({check:name,status:'PASS'});console.log('PASS',name)}catch(e){console.log('FAIL',name,e.message,e.detail||'',e.where||'');throw e}}
const rpc=async(name,args)=>(await db.query('SELECT public.'+name+'('+args.map((_,i)=>'$'+(i+1)).join(',')+') v',args)).rows[0].v;
const read=(role,service,unit=null)=>rpc('tower_service_workspace_read_232',[id(role),service,unit===null?null:id(unit)]);
const denied=(fn,rx)=>assert.rejects(fn,rx);
let personal,fund,empty,task,account;
try{
await db.exec(fs.readFileSync('tests/fixtures/task_lifecycle_schema.sql','utf8'));
for(const file of ['STAGING_82_Original_SQL229_TASK_LIFECYCLE.sql','STAGING_83_Original_SQL230_TASK_SIMPLIFICATION.sql','STAGING_84_Original_SQL231_TASK_WORKSPACE_AND_PERSON_LABELS.sql'])await db.exec(fs.readFileSync('sql/'+file,'utf8'));
await db.exec(fs.readFileSync(migration,'utf8'));
await db.exec(fs.readFileSync('tests/fixtures/service_issue_personal_due.sql','utf8'));
await db.exec("ALTER TABLE tower_finance_dues ALTER COLUMN status SET DEFAULT 'OPEN'"); // Explicit fixture default, not an online catalog claim.
await db.exec(`INSERT INTO tower_users(user_id,login_id,name,title,role,status,must_change_pin) VALUES
('${id(1)}','101010','fixture union','أ.','UNION','ACTIVE',false),('${id(2)}','000000','fixture admin','د.','ADMIN','ACTIVE',false),
('${id(3)}','092601','fixture resident','م.','RESIDENT','ACTIVE',false),('${id(4)}','092602','fixture other','أ.','RESIDENT','ACTIVE',false),
('${id(5)}','1','fixture guard','أ.','OPERATOR','ACTIVE',false),('${id(6)}','666666','fixture unrelated','أ.','RESIDENT','ACTIVE',false);
INSERT INTO tower_units(unit_id,unit_number,unit_type_id,floor) VALUES('${id(10)}','01','${id(90)}','1'),('${id(11)}','02','${id(90)}','1'),('${id(12)}','03','${id(90)}','2');
UPDATE tower_users SET phone='+201000000001';
INSERT INTO tower_members(member_id,unit_id,user_id,member_role) VALUES('${id(20)}','${id(10)}','${id(3)}','MANAGER'),('${id(21)}','${id(11)}','${id(4)}','MANAGER'),('${id(22)}','${id(11)}','${id(3)}','MEMBER'),('${id(23)}','${id(12)}','${id(6)}','MANAGER');`);
const create=async(name,kind='FUND')=>(await rpc('tower_service_finance_action',[id(1),'save',{name,description:'fixture only',price:'10',billingTiming:'POSTPAID',allowQuantity:true,cancelable:true,revenueKind:kind,beneficiaryUserId:id(1),serviceKind:'RECURRING',pricingMode:'PER_SUBSCRIPTION'}])).serviceId;
fund=await create('صندوق fixture');personal=await create('شخصي fixture','PERSONAL_SERVICE');empty=await create('بدون مستحقات fixture');
account=(await db.query('SELECT account_id FROM tower_finance_accounts WHERE service_id=$1',[personal])).rows[0].account_id;
const subscribe=async(service,unit,status='ACTIVE')=>(await db.query("INSERT INTO tower_service_subscriptions(service_id,unit_id,requested_by,status,billing_timing,quantity,unit_price_snapshot,amount_snapshot,auto_renew,next_renewal_at) VALUES($1,$2,$3,$4,'POSTPAID',2,10,20,true,current_date+30) RETURNING subscription_id",[service,id(unit),id(3),status])).rows[0].subscription_id;
const p1=await subscribe(personal,10),p2=await subscribe(personal,11),f1=await subscribe(fund,10),f2=await subscribe(fund,11,'PENDING');await subscribe(empty,10);
let charge=(await db.query("INSERT INTO tower_building_charges(title,service_id,subscription_id,policy_snapshot,due_date,period_label) VALUES('fixture charge',$1,$2,'{}',current_date,'شهر الاختبار') RETURNING charge_id",[fund,f1])).rows[0].charge_id;
await db.query("INSERT INTO tower_building_allocations(charge_id,unit_id,amount,paid) VALUES($1,$2,30,4)",[charge,id(10)]);
const oldCharge=(await db.query("INSERT INTO tower_building_charges(title,service_id,subscription_id,policy_snapshot,due_date) VALUES('old fixture',$1,$2,'{}',current_date-30) RETURNING charge_id",[fund,f1])).rows[0].charge_id;
await db.query("INSERT INTO tower_building_allocations(charge_id,unit_id,amount,paid) VALUES($1,$2,20,20)",[oldCharge,id(10)]);
const ignored=(await db.query("INSERT INTO tower_building_charges(title,service_id,policy_snapshot,status) VALUES('cancelled fixture',$1,'{}','CANCELED') RETURNING charge_id",[fund])).rows[0].charge_id;
await db.query("INSERT INTO tower_building_allocations(charge_id,unit_id,amount,paid) VALUES($1,$2,99,0)",[ignored,id(10)]);
await db.query("INSERT INTO tower_finance_dues(unit_id,account_id,subscription_id,due_date,amount,status) VALUES($1,$2,$3,current_date,40,'OPEN'),($4,$2,$5,current_date,60,'OPEN')",[id(10),account,p1,id(11),p2]);
await rpc('tower_finance_post_personal_receipt_internal',[id(10),id(1),15,[{account_id:account,amount:'15'}],'fixture-service232-receipt']);
await check('FUND service reads approved allocations not monthly estimates',async()=>{const d=await read(1,fund);assert.equal(d.totals.due,50);assert.equal(d.totals.paid,24);assert.equal(d.totals.remaining,26);assert.equal(d.records.length,2);assert.equal(d.service.price,10);assert.equal(d.service.revenueKind,'FUND')});
await check('personal service reads direct posted receipts and correct total',async()=>{const d=await read(1,personal);assert.equal(d.totals.due,100);assert.equal(d.totals.paid,15);assert.equal(d.totals.remaining,85);assert.equal(d.service.revenueKind,'PERSONAL_SERVICE')});
await check('manager names and beneficiary include their stored honorifics',async()=>{const d=await read(1,personal);assert.equal(d.service.beneficiaryName,'أ. fixture union');assert.equal(d.subscriptions.find(x=>x.unitId===id(10)).managerName,'م. fixture resident')});
await check('active monthly subscription without a posting is NOT_RECORDED',async()=>{const d=await read(1,empty);assert.equal(d.totals.state,'NOT_RECORDED');assert.equal(d.totals.due,0);assert.equal(d.subscriptions.length,1);assert.equal(d.balances.length,0)});
await check('multi unit resident sees only explicit own unit and ledger',async()=>{const d=await read(3,personal,10);assert.equal(d.subscriptions.length,1);assert.equal(d.records.length,1);assert.equal(d.unitNumber,'01');assert.equal(d.totals.due,40);assert.equal(d.totals.paid,15);assert(d.records.every(x=>x.unitId===id(10)));const other=await read(3,personal,11);assert.equal(other.totals.due,60);assert.equal(other.isUnitManager,false)});
await check('resident cannot request foreign or omitted unit',async()=>{await denied(()=>read(4,personal,10),/UNIT_ACCESS_DENIED/);await denied(()=>read(3,personal),/UNIT_REQUIRED/)});
await check('guard cannot use management workspace',async()=>await denied(()=>read(5,fund),/FORBIDDEN/));
await check('admin scope cannot be narrowed or impersonated by caller unit',async()=>{const d=await read(2,personal,10);assert.equal(d.unitId,null);assert.equal(d.subscriptions.length,2);assert.equal(d.totals.due,100)});
await check('zero paid-off remainder remains a recorded balance',async()=>{await db.query('UPDATE tower_building_allocations SET paid=amount WHERE charge_id=$1',[charge]);const d=await read(1,fund);assert.equal(d.totals.state,'RECORDED');assert.equal(d.totals.remaining,0);assert.equal(d.totals.due,50)});
await check('inactive service remains readable to subscribed resident only',async()=>{await db.query("UPDATE tower_services SET status='INACTIVE' WHERE service_id=$1",[personal]);assert.equal((await read(3,personal,10)).totals.due,40);await denied(()=>read(6,personal,12),/SERVICE_NOT_FOUND/);await db.query("UPDATE tower_services SET status='ACTIVE' WHERE service_id=$1",[personal])});
await check('inactive unit denied before any balances are returned',async()=>{await db.query("UPDATE tower_units SET status='INACTIVE' WHERE unit_id=$1",[id(10)]);await denied(()=>read(3,personal,10),/UNIT_ACCESS_DENIED/);await db.query("UPDATE tower_units SET status='ACTIVE' WHERE unit_id=$1",[id(10)])});
await check('cancelled due never appears as active debt',async()=>{await db.query("UPDATE tower_finance_dues SET status='CANCELLED' WHERE subscription_id=$1",[p2]);const d=await read(1,personal);assert.equal(d.totals.due,40);assert.equal(d.totals.paid,15)});
await check('inactive personal account keeps its classification and historical debt',async()=>{await db.query("UPDATE tower_finance_accounts SET status='INACTIVE' WHERE account_id=$1",[account]);const d=await read(1,personal);assert.equal(d.service.revenueKind,'PERSONAL_SERVICE');assert.equal(d.service.accountStatus,'INACTIVE');assert.equal(d.totals.due,40);await db.query("UPDATE tower_finance_accounts SET status='ACTIVE' WHERE account_id=$1",[account])});
await check('RPC privileges deny public roles and allow service role',async()=>{for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_service_workspace_read_232(text,uuid,uuid)','EXECUTE') good",[role])).rows[0].good,false);assert.equal((await db.query("SELECT has_function_privilege('service_role','tower_service_workspace_read_232(text,uuid,uuid)','EXECUTE') good")).rows[0].good,true)});
const act=(action,payload={})=>rpc('tower_task_project_action_229',[id(1),action,task,payload]);
task=(await rpc('tower_task_project_action_229',[id(1),'create',null,{reference:'fixture-232-task-create',name:'مهمة حارس البدء',scope:'fixture',totalBudget:'100',beneficiaryUserId:id(1)}])).serviceId;
const sub=await subscribe(task,10);await rpc('tower_service_shared_enrollment_close',[id(1),task]);
const today=(await db.query('SELECT current_date::text today')).rows[0].today;
const workflow={serviceId:task,stage:'COLLECT_FUNDS',startRule:'DATE_AND_COLLECTION',executionDate:today,collectionThreshold:20,executionPercent:0,installmentCount:3,firstDueDate:today,fundContributionProposed:0};
const save=(patch={})=>rpc('tower_task_workflow_action',[id(1),'save',{...workflow,...patch}]);
await save();await act('finalize');
await check('shared tasks use their own workspace and never service ledger',async()=>await denied(()=>read(1,task),/USE_TASK_WORKSPACE/));
for(const stage of ['READY','IN_PROGRESS','COMPLETED'])await check('zero collection cannot enter '+stage,async()=>await denied(()=>save({stage}),/TASK_START_COLLECTION_NOT_REACHED/));
await check('direct workflow write cannot bypass start gate',async()=>await denied(()=>db.query("UPDATE tower_task_workflow SET stage='IN_PROGRESS' WHERE service_id=$1",[task]),/TASK_START_COLLECTION_NOT_REACHED/));
const taskAccount=(await db.query('SELECT account_id FROM tower_finance_accounts WHERE service_id=$1',[task])).rows[0].account_id;
await rpc('tower_finance_post_personal_receipt_internal',[id(10),id(1),20,[{account_id:taskAccount,amount:'20'}],'fixture-service232-task-paid']);
await check('receipt reaching threshold still promotes READY automatically',async()=>assert.equal((await db.query('SELECT stage FROM tower_task_workflow WHERE service_id=$1',[task])).rows[0].stage,'READY'));
await save({executionDate:'2099-01-01'});
for(const stage of ['READY','IN_PROGRESS','COMPLETED'])await check('future execution date cannot enter '+stage,async()=>await denied(()=>save({executionDate:'2099-01-01',stage}),/TASK_START_DATE_NOT_REACHED/));
await check('DATE_AND_COLLECTION checks date independently of valid receipts',async()=>assert.equal((await db.query('SELECT stage FROM tower_task_workflow WHERE service_id=$1',[task])).rows[0].stage,'COLLECT_FUNDS'));
await db.query('UPDATE tower_task_projects SET minimum_start_amount=30 WHERE service_id=$1',[task]);
await check('minimum amount overrides percentage when explicitly configured',async()=>await denied(()=>save({stage:'IN_PROGRESS'}),/TASK_START_COLLECTION_NOT_REACHED/));
await db.query('UPDATE tower_task_projects SET minimum_start_amount=0 WHERE service_id=$1',[task]);
await check('manual start retains explicit administration decision',async()=>{await save({startRule:'MANUAL',stage:'IN_PROGRESS',collectionThreshold:100});await save()});
await check('DATE rule ignores collection percentage without a minimum',async()=>{await save({startRule:'DATE',collectionThreshold:100,stage:'READY'});await save()});
await check('threshold exactly met permits start and progress persistence',async()=>{await save({stage:'IN_PROGRESS',executionPercent:25});assert.equal((await db.query('SELECT execution_percent FROM tower_task_workflow WHERE service_id=$1',[task])).rows[0].execution_percent,25)});
await check('progress on work already started survives later financial threshold changes',async()=>{await save({stage:'IN_PROGRESS',collectionThreshold:100,executionPercent:50});await save({stage:'COMPLETED',collectionThreshold:100,executionPercent:100});assert.equal((await db.query('SELECT stage FROM tower_task_workflow WHERE service_id=$1',[task])).rows[0].stage,'COMPLETED')});
await check('read model and migration rerun do not create or edit money',async()=>{const before=await db.query('SELECT receipt_id,amount FROM tower_finance_receipts ORDER BY receipt_id');const current=await read(1,personal);await db.exec(fs.readFileSync(migration,'utf8'));assert.deepEqual((await db.query('SELECT receipt_id,amount FROM tower_finance_receipts ORDER BY receipt_id')).rows,before.rows);assert.deepEqual(await read(1,personal),current)});
await check('applied advances count as payment without counting unused cash as paid dues',async()=>{await rpc('tower_finance_post_personal_receipt_internal',[id(10),id(1),50,[{account_id:account,amount:'50'}],'fixture-service232-advance']);const advance=(await db.query("SELECT ap.application_id FROM tower_finance_applications ap JOIN tower_finance_receipt_portions rp ON rp.portion_id=ap.portion_id JOIN tower_finance_receipts r ON r.receipt_id=rp.receipt_id WHERE r.external_reference='fixture-service232-advance' AND ap.application_kind='ADVANCE'")).rows[0].application_id;await db.query('INSERT INTO tower_finance_advance_subscription_links(advance_application_id,subscription_id,amount,linked_by) VALUES($1,$2,25,$3)',[advance,p1,id(1)]);await rpc('tower_finance_issue_personal_due_internal',[p1,account,(await db.query("SELECT (current_date+30)::text date")).rows[0].date,20]);const d=await read(1,personal);assert.equal(d.totals.due,60);assert.equal(d.totals.paid,60);assert.equal(d.totals.remaining,0)});
await check('reversed receipt is not counted as posted payment',async()=>{await db.query("UPDATE tower_finance_receipts SET receipt_status='REVERSED' WHERE external_reference='fixture-service232-receipt'");const d=await read(1,personal);assert.equal(d.totals.due,60);assert.equal(d.totals.paid,45);assert.equal(d.totals.remaining,15)});
}finally{fs.mkdirSync('qa/v2.5.175',{recursive:true});fs.writeFileSync('qa/v2.5.175/service-workspace-sql-results.json',JSON.stringify(results,null,2));await db.close()}
