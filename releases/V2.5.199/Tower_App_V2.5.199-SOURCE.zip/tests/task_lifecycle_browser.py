"""Actual Chromium and app handlers; isolated synthetic API responses, no live Supabase."""
import json,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa/v2.5.174';OUT.mkdir(parents=True,exist_ok=True);results=[]
SID='11111111-1111-4111-8111-111111111111';UID='22222222-2222-4222-8222-222222222222'
base={'serviceId':SID,'name':'دهان اختبار <img src=x onerror="window.unsafeTask=1">','totalBudget':100,'enrollment':'FINALIZED','project':{'phase':'PARTICIPATION','version':1,'scope_text':'الدور الأول','policy_text':'المشاركة اختيارية','distribution':'EQUAL','target_units':[],'deadline':'2099-12-31','agreed_amounts':[]},'eligible':True,'canManage':True,'canApproveCredit':True,'hasPersonalAccount':True,'holderAvailable':20,'actualExpenseTotal':0,'interestCount':0,'subscriptions':[{'subscriptionId':'33333333-3333-4333-8333-333333333333','unitId':UID,'unitNumber':'01','status':'ACTIVE','balance':{'due':50,'paid':20,'remaining':30,'credit':0}}],'expenses':[],'adjustments':[],'refundAuthorizations':[],'pendingRefunds':[],'availableUnits':[{'unitId':UID,'unitNumber':'01','floor':'1'}]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900});page.set_default_timeout(4000);state={'data':copy.deepcopy(base),'calls':[],'fail':False}
  def route(r):
   if not r.request.url.startswith('https://tower.test/'):r.abort();return
   name=r.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if name in ['index.html','app.js','styles.css']:r.fulfill(path=str(ROOT/name));return
   body=r.request.post_data_json or {}
   if body.get('method')=='getBootstrapContext':r.fulfill(json={'ok':True,'result':{'configured':False}});return
   inner=body.get('args',[{}])[0];op=inner.get('name');args=inner.get('args',[]);state['calls'].append({'name':op,'args':args})
   if op=='getTaskProject':
    for sub in state['data']['subscriptions']:
     if 'balance' in sub:sub['balance']['state']='RECORDED' if state['data']['enrollment']=='FINALIZED' else 'NOT_RECORDED'
    value=state['data']
   elif op=='taskProjectAction':
    if state['fail']:r.fulfill(status=400,json={'error':'تعذر حفظ الاختبار'});return
    action=args[1];payload=args[2]
    if action=='collect':
     for sub in state['data']['subscriptions']:
      if sub.get('unitId')==payload['unitId']:sub['balance']['paid']+=float(payload['amount']);sub['balance']['remaining']-=float(payload['amount'])
     state['data']['holderAvailable']+=float(payload['amount'])
    elif action=='donation':state['data']['donationTotal']=float(payload['amount'])
    elif action=='confirm_refund':state['data']['pendingRefunds']=[]
    elif action=='interest':state['data']['interested']=payload['interested']
    elif action=='expense_draft':state['data']['expenses'].append({'expense_id':'expense-fixture','description':payload['description'],'amount':float(payload['amount']),'funding':payload['funding'],'state':'DRAFT'})
    elif action=='adjustment_draft':state['data']['adjustments'].append({'adjustmentId':'adjustment-fixture','reason':payload['reason'],'amount':float(payload['amount']),'state':'DRAFT','lines':[{'unitNumber':'01','amount':float(payload['amount'])}]})
    value={'success':True}
   elif op=='getServiceManagerContext':value={'service':{'serviceId':SID,'name':'مهمة اختبار','serviceKind':'ONE_TIME','pricingMode':'SHARED_TOTAL','revenueKind':'PERSONAL_SERVICE','totalBudget':100,'enrollmentStatus':state['data']['enrollment']},'units':state['data'].get('availableUnits',[]),'subscriptions':state['data']['subscriptions']}
   elif op=='listTaskInstallments':value={'rows':[],'hasPayments':True}
   elif op=='getMyServices':value={'services':[{'serviceId':SID,'name':'مهمة اختبار','price':0,'serviceKind':'ONE_TIME','pricingMode':'SHARED_TOTAL','enrollmentStatus':state['data']['enrollment'],'totalBudget':100,'project':{'phase':state['data']['project']['phase']}}],'subscriptions':state['data']['subscriptions'],'unitId':UID}
   elif op=='listServiceBeneficiaries':value=[{'userId':UID,'name':'مسؤول اختبار'}]
   elif op in ['listTaskWorkflows','listTaskNotices','listServices','listServiceSubscriptionRequests','listServiceChangeRequests']:value=[]
   else:value=[]
   r.fulfill(json={'ok':True,'result':value})
  page.route('**/*',route);page.goto('https://tower.test/');page.wait_for_function('typeof openTaskProject==="function"')
  page.evaluate("APP.ctx={user:{userId:'fixture-union',role:'UNION'}};APP.token='fixture';APP.activeUnitId='';APP.page='services';$('root').classList.remove('hidden');$('root').innerHTML='<div id=content></div>';history.replaceState({towerPage:'services'},'','#services')")
  def check(name,fn):
   fn();results.append({'viewport':width,'check':name,'status':'PASS'});print('PASS',width,name,flush=True)
  def assert_true(ok):assert ok
  page.evaluate('(id)=>openTaskProject(id)',SID)
  check('hub shows unit ledger and no horizontal overflow',lambda:assert_true('30.00' in page.locator('.task-workspace-finance').inner_text() and page.evaluate('document.documentElement.scrollWidth<=innerWidth')))
  check('untrusted task name is plain text',lambda:assert_true(page.evaluate('!window.unsafeTask') and page.locator('#modalSheet img').count()==0))
  page.get_by_role('tab',name='المصاريف',exact=True).click();page.get_by_role('button',name='تسجيل مصروف',exact=True).click();page.locator('#tpExpenseDescription').fill('فرشة دهان');page.locator('#tpExpenseAmount').fill('10');page.locator('#tpFunding').select_option('PERSONAL');page.get_by_role('button',name='حفظ مسودة المصروف',exact=True).click();page.get_by_text('فرشة دهان',exact=True).wait_for()
  check('expense form posts draft with stable reference and funding',lambda:assert_true(any(c['name']=='taskProjectAction' and c['args'][1]=='expense_draft' and c['args'][2]['funding']=='PERSONAL' and len(c['args'][2]['reference'])>=16 for c in state['calls'])))
  check('expense draft does not imply unit charge',lambda:assert_true('30.00' in page.locator('.task-workspace-finance').inner_text() and 'مسودة' in page.locator('#modalSheet').inner_text()))
  page.get_by_role('tab',name='التسويات',exact=True).click();page.get_by_role('button',name='تسوية زيادة أو تخفيض',exact=True).click();page.locator('#tpAdjustmentAmount').fill('-10');page.locator('#tpAdjustmentReason').fill('خصم المورد');page.get_by_role('button',name='إنشاء معاينة التسوية',exact=True).click();page.get_by_text('خصم المورد · مسودة — لم تغير المستحقات',exact=True).wait_for()
  check('negative adjustment remains preview before approval',lambda:assert_true(not any(c['name']=='taskProjectAction' and c['args'][1]=='adjustment_approve' for c in state['calls'])))
  page.get_by_role('tab',name='الأقساط',exact=True).click();page.get_by_role('button',name='تسجيل تحصيل للمهمة',exact=True).click();page.locator('#tpCollectAmount').fill('5');page.get_by_role('button',name='مراجعة التحصيل',exact=True).click();page.get_by_role('button',name='استلمت المبلغ',exact=True).click();page.wait_for_function('document.querySelector(".task-workspace-finance")?.innerText.includes("25.00")')
  check('collection goes through scoped task action',lambda:assert_true(any(c['name']=='taskProjectAction' and c['args'][1]=='collect' and c['args'][2]['unitId']==UID for c in state['calls'])))
  page.get_by_role('button',name='تسجيل تبرع إضافي',exact=True).click();page.locator('#tpDonationAmount').fill('3');page.get_by_role('button',name='مراجعة تسجيل التبرع',exact=True).click();page.get_by_role('button',name='استلمت التبرع',exact=True).click();page.wait_for_function('document.querySelector(".task-inline-facts")?.innerText.includes("3.00")')
  check('donation does not lower unit balance',lambda:assert_true('25.00' in page.locator('.task-workspace-finance').inner_text()))
  state['data']['enrollment']='OPEN';state['data']['project']['phase']='PARTICIPATION';page.evaluate('(id)=>openTaskProject(id,true)',SID)
  page.get_by_role('tab',name='إدارة المهمة',exact=True).click();page.get_by_role('button',name='نطاق وشروط وقاعدة التوزيع',exact=True).click();page.locator('#tpScope').fill('النطاق المعدل');state['fail']=True;page.get_by_role('button',name='حفظ',exact=True).click();page.get_by_text('تعذر حفظ الاختبار',exact=False).first.wait_for()
  check('failed save retains typed scope',lambda:assert_true(page.locator('#tpScope').input_value()=='النطاق المعدل'))
  page.get_by_role('button',name='إغلاق الرسالة',exact=True).click()
  page.once('dialog',lambda d:d.dismiss());page.keyboard.press('Escape')
  check('dirty terms cancel preserves input',lambda:assert_true(page.locator('#tpScope').input_value()=='النطاق المعدل'))
  page.once('dialog',lambda d:d.accept());page.keyboard.press('Escape');state['fail']=False
  state['data']['canManage']=False;state['data']['canApproveCredit']=False;state['data']['project']['phase']='PARTICIPATION';state['data']['subscriptions']=[]
  page.evaluate('(id)=>{APP.ctx.user={userId:"fixture-resident",role:"RESIDENT"};APP.activeUnitId="'+UID+'";return openTaskProject(id,true)}',SID)
  check('resident has no proposal or interest step',lambda:assert_true(page.get_by_role('button',name='مهتم بالفكرة — بدون التزام مالي',exact=True).count()==0 and page.get_by_role('button',name='تسجيل مصروف',exact=True).count()==0))
  check('resident cannot edit task',lambda:assert_true(page.get_by_role('button',name='تعديل',exact=True).count()==0))
  state['data']['eligible']=False;page.evaluate('(id)=>openTaskProject(id,true)',SID)
  check('out of scope resident sees scope explanation',lambda:assert_true('المهمة موجهة لوحدات أخرى' in page.locator('#modalSheet').inner_text()))
  state['data']['eligible']=True;state['data']['project']['phase']='PARTICIPATION';state['data']['enrollment']='FINALIZED';state['data']['pendingRefunds']=[{'movementId':SID,'amount':5,'canConfirm':True}]
  page.evaluate('(id)=>openTaskProject(id,true,"payments")',SID);page.get_by_role('button',name='تأكيد استلام الرد',exact=True).click();page.get_by_role('button',name='استلمت المبلغ',exact=True).click();page.wait_for_function('!document.querySelector("#modalSheet")?.innerText.includes("مبلغ رد لك:")')
  check('refund confirmation uses scoped route and active unit',lambda:assert_true(any(c['name']=='taskProjectAction' and c['args'][1]=='confirm_refund' and c['args'][-1].get('__activeUnitId')==UID for c in state['calls']) and not any(c['name']=='confirmPersonalUnitRefund' for c in state['calls'])))
  page.screenshot(path=str(OUT/f'lifecycle-{width}.png'));page.close()
 browser.close()
(OUT/'lifecycle-browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
