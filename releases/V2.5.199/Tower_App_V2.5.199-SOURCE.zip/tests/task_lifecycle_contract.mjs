import fs from 'node:fs';import assert from 'node:assert/strict';import worker from '../worker.js';
const uuid='11111111-1111-4111-8111-111111111111',unit='22222222-2222-4222-8222-222222222222';
const original=globalThis.fetch,results=[];
async function request({role='ADMIN',method='taskProjectAction',args=[uuid,'expense_draft',{reference:'fixture-reference',amount:'10'}],missing=false,pin=false}={}){
 const calls=[];globalThis.fetch=async(url,opts)=>{if(new URL(url).pathname.endsWith('/rpc/tower_present_names_231'))return Response.json(JSON.parse(opts.body).p_value);const name=new URL(url).pathname.split('/').pop(),body=JSON.parse(opts.body||'{}');calls.push({name,body});
  if(name==='tower_session_user')return Response.json(missing?[]:[{user_id:uuid,role,must_change_pin:pin}]);
  if(name==='tower_task_workspace_read_231')return Response.json({serviceId:body.p_service,unitId:body.p_unit,canManage:role!=='RESIDENT',subscriptions:[]});
  if(['tower_personal_collections_230','tower_service_edit_context_230','tower_service_edit_230'].includes(name))return Response.json({success:true,payload:body.p_payload});
  if(name==='tower_task_project_action_229')return Response.json({success:true,action:body.p_action,payload:body.p_payload});
  throw Error('Unexpected upstream '+name);
 };
 try{const r=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{name:method,token:'fixture-token',args}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture'});return {status:r.status,body:await r.json(),calls}}finally{globalThis.fetch=original}
}
async function check(name,f){await f();results.push({check:name,status:'PASS'});console.log('PASS',name)}
for(const role of ['ADMIN','UNION'])await check(role+' mutation uses session identity',async()=>{const r=await request({role});assert.equal(r.status,200);assert.equal(r.calls[1].name,'tower_task_project_action_229');assert.equal(r.calls[1].body.p_token,'fixture-token')});
for(const role of ['RESIDENT','OPERATOR'])await check(role+' cannot post expenses',async()=>{const r=await request({role,args:[uuid,'expense_draft',{amount:'10'},{__activeUnitId:unit}]});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('resident interest scope overrides forged payload unit',async()=>{const r=await request({role:'RESIDENT',args:[uuid,'interest',{unitId:uuid,interested:true},{__activeUnitId:unit}]});assert.equal(r.body.result.payload.unitId,unit)});
await check('resident read forwards only explicit active unit',async()=>{const r=await request({role:'RESIDENT',method:'getTaskProject',args:[uuid,{__activeUnitId:unit}]});assert.equal(r.body.result.unitId,unit)});
await check('resident read requires scope',async()=>{const r=await request({role:'RESIDENT',method:'getTaskProject',args:[uuid]});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('admin read does not impersonate resident scope',async()=>{const r=await request({method:'getTaskProject',args:[uuid,{__activeUnitId:unit}]});assert.equal(r.body.result.unitId,null)});
await check('create accepts no caller service ID',async()=>{const r=await request({method:'createTaskProject',args:[{reference:'fixture-reference',name:'test'}]});assert.equal(r.calls[1].body.p_service,null);assert.equal(r.calls[1].body.p_action,'create')});
for(const action of ['adjustment_approve','refund_authorize','close_financial','enroll','finalize'])await check('resident forbidden '+action,async()=>{const r=await request({role:'RESIDENT',args:[uuid,action,{}, {__activeUnitId:unit}]});assert(r.body.error);assert.equal(r.calls.length,1)});
for(const args of [['bad','expense_draft',{}],[uuid,'arbitrary_sql',{}]])await check('invalid action/ID rejected '+args[0]+'/'+args[1],async()=>{const r=await request({args});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('missing session rejected before RPC',async()=>{const r=await request({missing:true});assert.equal(r.status,401);assert.equal(r.calls.length,1)});
await check('temporary PIN cannot mutate project',async()=>{const r=await request({pin:true});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('agreement enrollment preserves same SQL transaction',async()=>{const r=await request({method:'addServiceSubscribers',args:[{serviceId:uuid,unitIds:[unit],agreementSource:'WHATSAPP',agreementNote:'fixture agreement'}]});assert.equal(r.calls[1].name,'tower_task_project_action_229');assert.equal(r.calls[1].body.p_action,'enroll');assert.deepEqual(r.calls[1].body.p_payload,{unitIds:[unit],source:'WHATSAPP',note:'fixture agreement'})});
await check('resident scoped refund confirmation overrides forged unit',async()=>{const r=await request({role:'RESIDENT',args:[uuid,'confirm_refund',{unitId:uuid,movementId:uuid},{__activeUnitId:unit}]});assert.equal(r.body.result.payload.unitId,unit)});
for(const action of ['collect','donation','refund_authorize','refund_request','cancel_settled'])await check('ADMIN cannot execute UNION financial action '+action,async()=>{const r=await request({args:[uuid,action,{}]});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('old general finance gate remains unchanged',async()=>{const r=await request({role:'RESIDENT',method:'confirmPersonalUnitRefund',args:[{movementId:uuid}]});assert(r.body.error);assert.equal(r.calls.length,1)});
for(const role of ['ADMIN','UNION'])await check(role+' edits through authoritative service RPC',async()=>{const r=await request({role,method:'editManagedService',args:[{serviceId:uuid,reference:'fixture-edit-reference'}]});assert.equal(r.status,200);assert.equal(r.calls[1].name,'tower_service_edit_230')});
for(const role of ['RESIDENT','OPERATOR'])await check(role+' cannot edit managed service',async()=>{const r=await request({role,method:'editManagedService',args:[{}]});assert(r.body.error);assert.equal(r.calls.length,1)});
for(const role of ['UNION','OPERATOR'])await check(role+' has scoped collection endpoint',async()=>{const r=await request({role,method:'collectPersonalDue',args:[{unitId:unit,accountId:uuid,amount:'5',reference:'fixture-collection-reference'}]});assert.equal(r.status,200);assert.equal(r.calls[1].name,'tower_personal_collections_230');assert.equal(r.calls[1].body.p_action,'collect')});
await check('resident cannot list collector balances',async()=>{const r=await request({role:'RESIDENT',method:'getPersonalCollectionDues',args:[]});assert(r.body.error);assert.equal(r.calls.length,1)});
await check('combined finalize delegates one SQL transaction',async()=>{const r=await request({args:[uuid,'close_finalize',{}]});assert.equal(r.status,200);assert.equal(r.calls[1].body.p_action,'close_finalize')});
fs.mkdirSync('qa/v2.5.174',{recursive:true});fs.writeFileSync('qa/v2.5.174/lifecycle-worker-results.json',JSON.stringify(results,null,2));
