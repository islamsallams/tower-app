"""V173 real Chromium handlers with explicit synthetic API, no online requests."""
import json,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa/v2.5.174';OUT.mkdir(parents=True,exist_ok=True);results=[]
SID='11111111-1111-4111-8111-111111111111';UID='22222222-2222-4222-8222-222222222222';SUB='33333333-3333-4333-8333-333333333333'
service={'serviceId':SID,'name':'دهان اختبار','description':'وصف المهمة','scope':'الدور الأول','totalBudget':100.01,'price':0,'pricingMode':'SHARED_TOTAL','serviceKind':'ONE_TIME','beneficiaryUserId':SID,'updatedAt':'2026-10-26T10:00:00Z','enrollment':'FINALIZED'}
hub={'serviceId':SID,'name':'دهان اختبار','description':'وصف المهمة','totalBudget':100.01,'estimatedNet':100.01,'estimatedShare':50.01,'activeCount':2,'responsibleName':'مسؤول اختبار','enrollment':'OPEN','project':{'phase':'PARTICIPATION','version':1,'scope_text':'الدور الأول','distribution':'CUSTOM','agreed_amounts':[]},'canManage':True,'canApproveCredit':False,'hasPersonalAccount':True,'subscriptions':[{'subscriptionId':SUB,'unitId':UID,'unitNumber':'01','status':'ACTIVE','balance':{'due':0,'paid':0,'remaining':0}},{'subscriptionId':SID,'unitId':SID,'unitNumber':'02','status':'ACTIVE','balance':{'due':0,'paid':0,'remaining':0}}],'expenses':[],'adjustments':[],'availableUnits':[]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900});page.set_default_timeout(5000);calls=[]
  def route(r):
   if not r.request.url.startswith('https://tower.test/'):r.abort();return
   name=r.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if name=='fixture-hero.png':r.fulfill(path=str(ROOT/'qa/v2.5.172/lifecycle-390.png'));return
   if name in ['index.html','app.js','styles.css']:r.fulfill(path=str(ROOT/name));return
   body=r.request.post_data_json or {};inner=body.get('args',[{}])[0] if body.get('args') else {};inner=inner if isinstance(inner,dict) else {};op=inner.get('name');args=inner.get('args',[]);calls.append({'name':op,'args':args})
   if body.get('method')=='getBootstrapContext':value={'configured':False}
   elif op=='getServiceEditContext':value=service
   elif op=='listServiceBeneficiaries':value=[{'userId':SID,'name':'مسؤول اختبار','title':'أ.'},{'userId':UID,'name':'مسؤول آخر','title':'أ.'}]
   elif op=='getTaskProject':
    for sub in hub['subscriptions']:
     if 'balance' in sub:sub['balance']['state']='RECORDED' if hub['enrollment']=='FINALIZED' else 'NOT_RECORDED'
    value=hub
   elif op=='getServiceManagerContext':value={'service':{**service,'enrollmentStatus':hub['enrollment'],'revenueKind':'PERSONAL_SERVICE'},'units':hub['availableUnits'],'subscriptions':hub['subscriptions']}
   elif op=='listTaskInstallments':value={'rows':[],'hasPayments':True}
   elif op=='getPersonalCollectionDues':value={'rows':[{'unitId':UID,'accountId':SID,'unitNumber':'01','floor':'1','managerName':'مدير اختبار','serviceName':'دهان اختبار','due':50.01,'paid':20,'remaining':30.01}],'canCollect':True}
   elif op=='getCollectionContext':value={'reports':[],'units':[],'canApprove':False}
   elif op=='collectPersonalDue':value={'receiptId':SID}
   elif op=='editManagedService':value={'success':True}
   elif op=='getMyTripSettings':value={'feeNear':5,'feeMedium':10,'feeFar':15,'defaultDistance':'NEAR'}
   elif op=='getMyTelegramSettings':value={'linked':False}
   else:value=[]
   r.fulfill(json={'ok':True,'result':value})
  page.route('**/*',route);page.goto('https://tower.test/');page.wait_for_function('APP.ctx!==null');page.evaluate("APP.ctx={user:{userId:'fixture-admin',role:'ADMIN',displayName:'اختبار'},branding:{mainImageUrl:'/fixture-hero.png'}};APP.page='services';if(!$('content')){const content=document.createElement('main');content.id='content';document.body.appendChild(content);}document.documentElement.dataset.theme='dark'")
  def check(name,ok):
   assert ok,name;results.append({'viewport':width,'check':name,'status':'PASS'});print('PASS',width,name)
  page.evaluate('(id)=>openTaskProject(id)',SID);page.get_by_role('button',name='تعديل',exact=True).wait_for()
  check('responsible person visible in hub','مسؤول اختبار' in page.locator('#modalSheet').inner_text())
  check('no proposal publish or interest steps','إبداء الاهتمام' not in page.locator('#modalSheet').inner_text() and page.get_by_role('button',name='فتح تأكيد المشاركة',exact=True).count()==0)
  check('dark fact backgrounds use theme surface',page.locator('.task-workspace-finance').evaluate("x=>getComputedStyle(x).backgroundColor===getComputedStyle(document.documentElement).getPropertyValue('--surface-2').trim()||getComputedStyle(x).backgroundColor==='rgb(29, 42, 60)'"))
  page.get_by_role('button',name='نطاق وشروط وقاعدة التوزيع',exact=True).click();page.get_by_role('button',name='توزيع المتبقي بالتساوي',exact=True).click()
  amounts=page.locator('[data-task-share]').evaluate_all('xs=>xs.map(x=>Math.round(Number(x.value)*100))');check('custom split handles odd cent and exact sum',sum(amounts)==10001 and sorted(amounts)==[5000,5001])
  check('allocation total and difference visible','100.01' in page.locator('#tpAllocationTotals').inner_text() and '0.00' in page.locator('#tpAllocationTotals').inner_text())
  page.evaluate('TOWER_OTHER_FORM_BASELINE=null;TOWER_OTHER_FORM_ACCEPTED=true;closeModal()');page.get_by_role('button',name='تعديل',exact=True).click();page.locator('#meName').wait_for();page.locator('#meDescription').fill('تفاصيل اختبار طويلة '*50)
  page.wait_for_timeout(100)
  check('textarea fills field and grows with content',page.locator('#meDescription').evaluate('x=>x.getBoundingClientRect().width>=x.parentElement.getBoundingClientRect().width-4&&x.getBoundingClientRect().height>96'))
  check('form input respects dark theme',page.locator('#meName').evaluate("x=>getComputedStyle(x).backgroundColor==='rgb(29, 42, 60)'&&getComputedStyle(x).color==='rgb(237, 243, 248)'"))
  page.screenshot(path=str(OUT/f'edit-dark-{width}.png'))
  page.locator('#meName').fill('مهمة معدلة');page.locator('#meBudget').fill('120.01');page.locator('#meReason').fill('خامات إضافية');page.get_by_role('button',name='مراجعة وحفظ التعديل',exact=True).click();page.get_by_role('button',name='حفظ',exact=True).click();page.wait_for_function('!document.querySelector("#meName")')
  edit=next(c for c in calls if c['name']=='editManagedService')['args'][0]
  page.get_by_text('تم حفظ التعديل.',exact=True).wait_for()
  check('managed edit posts expected version reason and target amount',edit['expectedUpdatedAt']==service['updatedAt'] and edit['totalBudget']=='120.01' and edit['name']=='مهمة معدلة' and edit['reason']=='خامات إضافية')
  page.evaluate("while(towerModalDepth())closeModal();APP.ctx.user={userId:'fixture-guard',role:'OPERATOR'};APP.page='collections';if(!$('content')){const content=document.createElement('main');content.id='content';document.body.appendChild(content);}renderCollections()")
  page.get_by_role('button',name='تحصيل',exact=True).wait_for();check('guard page automatically lists task due and unit manager','مدير اختبار' in page.locator('#personalCollectionDues').inner_text() and '30.01' in page.locator('#personalCollectionDues').inner_text())
  page.get_by_role('button',name='تحصيل',exact=True).click();page.locator('#pcAmount').fill('10');page.get_by_role('button',name='مراجعة التحصيل',exact=True).click();page.get_by_role('button',name='استلمت',exact=True).click();page.wait_for_function('!document.querySelector("#pcAmount")')
  col=next(c for c in calls if c['name']=='collectPersonalDue')['args'][0];check('guard posts to exact unit and dedicated account',col['unitId']==UID and col['accountId']==SID and col['amount']=='10' and len(col['reference'])>=16)
  check('mobile layout has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  for step in range(4):
   welcome=browser.new_page(viewport={'width':width,'height':900});welcome.route('**/*',route);welcome.goto('https://tower.test/');welcome.wait_for_function('APP.ctx!==null')
   welcome.evaluate("APP.ctx={user:{userId:'fixture-resident',role:'RESIDENT'},branding:{mainImageUrl:'/fixture-hero.png'}};document.documentElement.dataset.theme='dark'")
   welcome.evaluate('(s)=>openWelcomeWizard(s)',step);welcome.locator('.welcome-hero img').wait_for();welcome.wait_for_timeout(100)
   check('welcome image fills remaining height step '+str(step+1),welcome.locator('.welcome-hero img').evaluate('x=>Math.abs(x.getBoundingClientRect().height-x.parentElement.getBoundingClientRect().height)<2') and welcome.locator('.welcome-hero').evaluate('x=>x.getBoundingClientRect().height>=100'))
   check('welcome buttons stay within sheet step '+str(step+1),welcome.locator('#welcomeNext').evaluate('x=>x.getBoundingClientRect().bottom<=innerHeight'))
   if step==3:welcome.screenshot(path=str(OUT/f'welcome-dark-{width}.png'))
   welcome.close()
  page.close()
 browser.close()
(OUT/'simplification-browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
