"""Real Chromium/app handlers; explicit synthetic API; no live site or financial postings."""
import json,copy,base64
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa/v2.5.174';OUT.mkdir(parents=True,exist_ok=True);results=[]
SID='11111111-1111-4111-8111-111111111111';U1='22222222-2222-4222-8222-222222222222';U2='44444444-4444-4444-8444-444444444444';S1='33333333-3333-4333-8333-333333333333';S2='55555555-5555-4555-8555-555555555555'
BASE={'serviceId':SID,'name':'دهان بير السلم','description':'وصف شغل تجريبي','totalBudget':1000,'estimatedNet':1000,'activeCount':2,'responsibleName':'د. مسؤول اختبار','enrollment':'FINALIZED','project':{'phase':'PARTICIPATION','version':1,'scope_text':'من الدور الثالث إلى الأخير','deadline':'2099-12-31','policy_text':'اشتراك اختياري موثق','distribution':'EQUAL','agreed_amounts':[]},'execution':{'stage':'COLLECTING_FUNDS','percent':20},'canManage':True,'canApproveCredit':True,'hasPersonalAccount':True,'holderAvailable':100,'actualExpenseTotal':0,'expenses':[],'adjustments':[],'refundAuthorizations':[],'pendingRefunds':[],'subscriptions':[{'subscriptionId':S1,'unitId':U1,'unitNumber':'01','floor':'1','managerName':'أ. محمد أحمد','status':'ACTIVE','balance':{'state':'RECORDED','due':500,'paid':100,'remaining':400}},{'subscriptionId':S2,'unitId':U2,'unitNumber':'24','floor':'9','managerName':'م. علي حسن','status':'ACTIVE','balance':{'state':'RECORDED','due':500,'paid':0,'remaining':500}}],'availableUnits':[{'unitId':U1,'unitNumber':'01','floor':'1','managerName':'أ. محمد أحمد'},{'unitId':U2,'unitNumber':'24','floor':'9','managerName':'م. علي حسن'}]}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  for theme in ['dark','light']:
   page=browser.new_page(viewport={'width':width,'height':920});page.set_default_timeout(6000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));state={'data':copy.deepcopy(BASE),'calls':[],'plan':{'rows':[],'hasPlan':False,'hasPayments':True},'fail':False}
   def route(r):
    if not r.request.url.startswith('https://tower.test/'):r.abort();return
    name=r.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
    if name in ['index.html','app.js','styles.css']:r.fulfill(path=str(ROOT/name));return
    body=r.request.post_data_json or {}
    if body.get('method')=='getBootstrapContext':r.fulfill(json={'ok':True,'result':{'configured':False}});return
    inner=body.get('args',[{}])[0];inner=inner if isinstance(inner,dict) else {};op=inner.get('name');args=inner.get('args',[]);state['calls'].append({'name':op,'args':args});d=state['data']
    service={'serviceId':SID,'name':d['name'],'description':d['description'],'price':0,'totalBudget':d['totalBudget'],'serviceKind':'ONE_TIME','pricingMode':'SHARED_TOTAL','revenueKind':'PERSONAL_SERVICE' if d['hasPersonalAccount'] else 'FUND','enrollmentStatus':d['enrollment']}
    if op=='getTaskProject':
     for sub in d['subscriptions']:
      if 'balance' in sub:sub['balance'].setdefault('state','RECORDED' if d['enrollment']=='FINALIZED' else 'NOT_RECORDED')
     value=d
    elif op=='getServiceManagerContext':value={'service':service,'units':d['availableUnits'],'subscriptions':d['subscriptions']}
    elif op=='listTaskInstallments':value=state['plan']
    elif op=='listServices':value=[service]
    elif op=='getMyServices':value={'unitId':U1,'services':[service],'subscriptions':d['subscriptions']}
    elif op=='getServiceEditContext':value={**service,'beneficiaryUserId':SID,'updatedAt':'2026-10-26T00:00:00Z','projectVersion':1,'scope':d['project']['scope_text']}
    elif op=='listServiceBeneficiaries':value=[{'userId':SID,'name':'مسؤول اختبار','title':'د.','displayName':'د. مسؤول اختبار'}]
    elif op in ['listTaskWorkflows','listTaskNotices','listServiceSubscriptionRequests','listServiceChangeRequests']:value=[]
    elif op=='removeSharedServiceSubscriber':
     for sub in d['subscriptions']:
      if sub['subscriptionId']==args[1]:sub['status']='ENDED'
     value={'success':True}
    elif op=='taskProjectAction':
     if state['fail']:r.fulfill(status=400,json={'error':'تعذر حفظ الاختبار'});return
     action=args[1];p=args[2]
     if action=='expense_draft':d['expenses'].append({'expense_id':'fixture-expense','description':p['description'],'amount':float(p['amount']),'funding':p['funding'],'state':'DRAFT'})
     if action=='adjustment_draft':d['adjustments'].append({'adjustmentId':'fixture-adjustment','amount':float(p['amount']),'reason':p['reason'],'state':'DRAFT','lines':[{'unitNumber':'01','amount':float(p['amount'])}]})
     value={'success':True}
    else:value=[]
    r.fulfill(json={'ok':True,'result':value})
   page.route('**/*',route);page.goto('https://tower.test/');page.wait_for_function('APP.ctx!==null')
   page.evaluate("APP.ctx={user:{userId:'fixture-union',role:'UNION',displayName:'أ. تجربة'},building:{name:'عمارة اختبار'}};APP.token='fixture';APP.activeUnitId='';APP.page='services';$('root').classList.remove('hidden');$('root').innerHTML='<main id=content></main>';history.replaceState({towerPage:'services'},'','/');document.documentElement.dataset.theme='"+theme+"'")
   def check(name,ok):
    assert ok,(width,theme,name,errors);results.append({'viewport':width,'theme':theme,'check':name,'status':'PASS'});print('PASS',width,theme,name,flush=True)
   def tab(label):page.get_by_role('tab',name=label,exact=True).click()
   page.evaluate('(id)=>openTaskProject(id)',SID);page.locator('.task-workspace').wait_for()
   check('single compact task workspace',page.locator('.task-workspace').count()==1 and page.locator('.task-workspace').bounding_box()['height']<(850 if width==390 else 740))
   check('titles visible and unwanted prose removed','د. مسؤول اختبار' in page.locator('.task-workspace-header').inner_text() and 'خصم محاسبي مسجل' not in page.locator('#modalSheet').inner_text() and 'راجع الأنصبة الدقيقة' not in page.locator('#modalSheet').inner_text())
   check('official summary reads due paid remaining',all(s in page.locator('.task-workspace-finance').inner_text() for s in ['1,000.00','100.00','900.00']))
   check('all navigation lives in one footer',page.locator('.task-workspace-tabs [role=tab]').count()==5 and page.locator('.task-workspace-tabs').evaluate('e=>e.getBoundingClientRect().bottom<=innerHeight'))
   page.screenshot(path=str(OUT/f'workspace-overview-{theme}-{width}.png'))
   tab('الاشتراك والتوزيع');page.locator('#towerSharedMemberList .shared-member-card').first.wait_for()
   check('members show titles and exact official balances',all(s in page.locator('#towerSharedMemberList').inner_text() for s in ['أ. محمد أحمد','م. علي حسن','500.00','400.00']) and 'تقديري' not in page.locator('#towerSharedMemberList').inner_text())
   check('filter and export share one list',page.get_by_role('button',name='تصدير PDF',exact=True).count()==1 and page.get_by_role('button',name='طباعة',exact=True).count()==1)
   page.locator('#towerSharedSearch').fill('24');page.wait_for_function('document.querySelectorAll("#towerSharedMemberList .shared-member-card").length===1')
   report=page.evaluate('taskWorkspaceReport()');check('export uses visible filtered unit and titled manager',len(report['sections'][0]['rows'])==1 and report['sections'][0]['rows'][0][0]=='24' and report['sections'][0]['rows'][0][2]=='م. علي حسن')
   tab('إدارة المهمة');tab('الاشتراك والتوزيع');check('query preserved across tabs',page.locator('#towerSharedSearch').input_value()=='24' and page.locator('#towerSharedMemberList .shared-member-card').count()==1)
   page.evaluate('(id)=>openServiceSubscribers(id)',SID);page.locator('#towerSharedSearch').wait_for();check('report entry reuses workspace without another modal',page.evaluate('towerModalDepth()')==1 and page.locator('.task-workspace').count()==1 and page.locator('#towerSharedSearch').input_value()=='24')
   page.screenshot(path=str(OUT/f'workspace-members-{theme}-{width}.png'))
   if theme=='dark':
    page.add_script_tag(path='/tmp/tower-browser-tools/node_modules/html2canvas/dist/html2canvas.min.js');page.add_script_tag(path='/tmp/tower-browser-tools/node_modules/jspdf/dist/jspdf.umd.min.js')
    pdf=page.evaluate("async()=>{const b=await buildCurrentPdfBlob(taskWorkspaceReport());return await new Promise(resolve=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.readAsDataURL(b)})}")
    content=base64.b64decode(pdf.split(',',1)[1]);(OUT/f'workspace-filtered-{width}.pdf').write_bytes(content);check('actual workspace PDF generated',content.startswith(b'%PDF-') and len(content)>1000)
   state['data']['hasPersonalAccount']=False;page.evaluate('(id)=>openTaskProject(id,true,"members")',SID);page.locator('.task-workspace').wait_for()
   check('FUND account still shows official recorded balances','1,000.00' in page.locator('.task-workspace-finance').inner_text() and '900.00' in page.locator('.task-workspace-finance').inner_text())
   state['data']['hasPersonalAccount']=True;state['data']['subscriptions'][0]['balance']['state']='NOT_RECORDED';page.evaluate('(id)=>openTaskProject(id,true,"members")',SID)
   check('missing financial record never appears as an official zero','غير مسجل' in page.locator('.task-workspace-finance').inner_text() and page.evaluate('taskWorkspaceMembers(taskProjectCurrentHub()).find(x=>x.unit==="01").amount===null'))
   state['data']['subscriptions'][0]['balance']['state']='RECORDED';page.evaluate('(id)=>openTaskProject(id,true,"members")',SID)
   tab('الأقساط');page.get_by_text('السداد بدأ بدون خطة أقساط',exact=True).wait_for();check('no misleading install after payments',page.get_by_role('button',name='إعداد الأقساط',exact=True).count()==0)
   state['plan']={'rows':[],'hasPlan':False,'hasPayments':False};page.evaluate("selectTaskWorkspaceTab('payments')");page.get_by_role('button',name='إعداد الأقساط',exact=True).wait_for()
   check('installment button uses system component in both themes',page.get_by_role('button',name='إعداد الأقساط',exact=True).evaluate("e=>e.classList.contains('btn-sm')&&getComputedStyle(e).backgroundColor==='rgb(2, 115, 251)'"))
   page.screenshot(path=str(OUT/f'workspace-payments-{theme}-{width}.png'))
   tab('المصاريف');page.get_by_role('button',name='تسجيل مصروف',exact=True).click();page.locator('#tpExpenseDescription').fill('فرشة دهان');page.locator('#tpExpenseAmount').fill('10');page.locator('#tpFunding').select_option('PERSONAL');page.get_by_role('button',name='حفظ مسودة المصروف',exact=True).click();page.get_by_text('فرشة دهان',exact=True).wait_for()
   check('expense draft works in same tab without charging residents',page.get_by_role('tab',name='المصاريف',exact=True).get_attribute('aria-selected')=='true' and '1,000.00' in page.locator('.task-workspace-finance').inner_text() and any(c['name']=='taskProjectAction' and c['args'][1]=='expense_draft' for c in state['calls']))
   page.screenshot(path=str(OUT/f'workspace-expenses-{theme}-{width}.png'))
   tab('التسويات');page.get_by_role('button',name='تسوية زيادة أو تخفيض',exact=True).click();page.locator('#tpAdjustmentAmount').fill('-10');page.locator('#tpAdjustmentReason').fill('خصم مورد');page.get_by_role('button',name='إنشاء معاينة التسوية',exact=True).click();page.get_by_text('خصم مورد · مسودة — لم تغير المستحقات',exact=True).wait_for();check('adjustment still needs independent approval',not any(c['name']=='taskProjectAction' and c['args'][1]=='adjustment_approve' for c in state['calls']))
   page.screenshot(path=str(OUT/f'workspace-adjustments-{theme}-{width}.png'))
   tab('إدارة المهمة');page.get_by_role('button',name='تعديل',exact=True).click();page.locator('#meName').wait_for();check('account picker contains title',page.locator('#meOwner option').inner_text()=='د. مسؤول اختبار');page.evaluate('closeModal(true)')
   state['data']['enrollment']='OPEN';page.evaluate('(id)=>openSharedAllocation(id,true)',SID);page.locator('#towerSharedSelectVisible').wait_for()
   page.locator('#towerSharedSearch').fill('24');page.locator('#towerSharedSelectVisible').check();page.locator('#towerSharedSearch').fill('01');page.locator('#towerSharedSelectVisible').check()
   check('selection spans hidden search results',page.locator('#towerSharedSelectionCount').inner_text()=='2 محدد')
   tab('إدارة المهمة');tab('الاشتراك والتوزيع');check('selection and search preserved together',page.locator('#towerSharedSelectionCount').inner_text()=='2 محدد' and page.locator('#towerSharedSearch').input_value()=='01')
   page.get_by_role('button',name='إزالة 2 من المحددين',exact=True).click();page.get_by_role('button',name='إلغاء',exact=True).click();page.locator('#towerSharedSearch').wait_for()
   check('cancel bulk removal keeps selection and posts nothing',page.locator('#towerSharedSelectionCount').inner_text()=='2 محدد' and not any(c['name']=='removeSharedServiceSubscriber' for c in state['calls']))
   state['data']['enrollment']='FINALIZED'
   state['data']['project']['phase']='FINANCIAL_CLOSED';page.evaluate('(id)=>openTaskProject(id,true)',SID);page.get_by_role('button',name='تعديل',exact=True).wait_for();check('edit remains available after closure',page.get_by_role('button',name='تعديل',exact=True).count()==1)
   # Resident scope is represented by the server fixture, never by hiding other units in the DOM.
   state['data']['canManage']=False;state['data']['canApproveCredit']=False;state['data']['subscriptions']=[copy.deepcopy(BASE['subscriptions'][0])];state['data']['project']['phase']='PARTICIPATION'
   page.evaluate("APP.ctx.user={userId:'fixture-resident',role:'RESIDENT'};APP.activeUnitId='"+U1+"'")
   page.evaluate('(id)=>openTaskProject(id,true,"members")',SID);page.locator('#towerSharedMemberList').wait_for();check('resident sees only own unit and no management controls',page.locator('#towerSharedMemberList .shared-member-card').count()==1 and page.get_by_role('button',name='إضافة وحدات',exact=True).count()==0 and page.get_by_role('button',name='تعديل',exact=True).count()==0)
   state['data']['enrollment']='OPEN';state['data']['subscriptions'][0]['status']='PENDING';page.evaluate('(id)=>openTaskProject(id,true,"members")',SID);page.get_by_text('طلبك قيد المراجعة.',exact=True).wait_for()
   check('resident pending request never exposes approval buttons',page.get_by_role('button',name='موافقة',exact=True).count()==0 and page.get_by_role('button',name='رفض',exact=True).count()==0)
   state['data']['enrollment']='FINALIZED';state['data']['subscriptions'][0]['status']='ACTIVE';state['data']['subscriptions'][0]['balance']={'due':500,'paid':500,'remaining':0};page.evaluate('(id)=>openTaskProject(id,true,"members")',SID);page.locator('.task-workspace-finance.is-settled').wait_for()
   check('zero remaining uses settled financial state',page.locator('.task-workspace-finance.is-settled').count()==1)
   state['data']['enrollment']='OPEN';state['data']['subscriptions']=[];state['data']['unitNumber']='01';page.evaluate('(id)=>openResidentServiceDetails(id)',SID);page.get_by_role('tab',name='إدارة المهمة',exact=True).click();page.get_by_role('button',name='طلب اشتراك',exact=True).wait_for()
   check('resident task details open the same workspace with participation action',page.locator('.task-workspace').count()==1 and page.evaluate('towerModalDepth()')==1 and 'الوحدة 01' in page.locator('.task-workspace-header').inner_text())
   page.get_by_role('button',name='طلب اشتراك',exact=True).click();page.get_by_role('button',name='إلغاء',exact=True).click();page.locator('.task-workspace').wait_for()
   check('cancel participation posts no request and keeps task open',not any(c['name']=='requestServiceSubscription' for c in state['calls']) and page.locator('.task-workspace').count()==1)
   tab('الاشتراك والتوزيع')
   check('keyboard tab navigation keeps focus and selection',page.get_by_role('tab',name='الاشتراك والتوزيع',exact=True).evaluate("e=>{e.focus();e.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true}))}") is None and page.get_by_role('tab',name='الأقساط',exact=True).get_attribute('aria-selected')=='true')
   check('no horizontal page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   check('no uncaught application error',not errors)
   page.close()
 browser.close()
(OUT/'workspace-browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
