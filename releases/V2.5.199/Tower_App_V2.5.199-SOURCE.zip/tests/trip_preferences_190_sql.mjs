// SQL242 local integration. The installed distance function is represented by an explicit test double.
// No live database, resident records, notifications, browser, or screen acceptance.
import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const unit='10000000-1111-4111-8111-111111111111',other='20000000-1111-4111-8111-111111111111';
async function check(name,fn){await fn();results.push({check:name,status:'PASS'});console.log('PASS',name);}
const call=async(token,action,p={})=>(await db.query('SELECT tower_resident_trip_preferences_242($1,$2,$3) v',[token,action,{unitId:unit,...p}])).rows[0].v;
try{
await db.exec(`CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean);
CREATE TABLE tower_units(unit_id uuid PRIMARY KEY,status text);
CREATE TABLE tower_members(user_id uuid,unit_id uuid,member_role text,ended_at timestamptz);
CREATE TABLE fixture_distance_settings(unit_id uuid PRIMARY KEY,fee_near numeric NOT NULL DEFAULT 10);
CREATE FUNCTION tower_session_user(p_token text) RETURNS SETOF tower_users LANGUAGE sql AS $$SELECT * FROM tower_users WHERE user_id=p_token::uuid$$;
CREATE FUNCTION tower_resident_trip_settings(p_token text,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE uid uuid:=(p_payload->>'unitId')::uuid; v numeric;
BEGIN
 IF p_action='update' THEN
  IF NOT EXISTS(SELECT 1 FROM tower_members WHERE user_id=p_token::uuid AND unit_id=uid AND member_role='MANAGER' AND ended_at IS NULL) THEN RAISE EXCEPTION 'ORIGINAL_SETTINGS_FORBIDDEN';END IF;
  v:=(p_payload->>'feeNear')::numeric;
  IF v<0 THEN RAISE EXCEPTION 'ORIGINAL_INVALID_FEE';END IF;
  INSERT INTO fixture_distance_settings(unit_id,fee_near) VALUES(uid,v) ON CONFLICT(unit_id) DO UPDATE SET fee_near=EXCLUDED.fee_near;
 END IF;
 SELECT fee_near INTO v FROM fixture_distance_settings WHERE unit_id=uid;
 RETURN jsonb_build_object('feeNear',coalesce(v,10),'feeMedium',20,'feeFar',30,'defaultDistance','NEAR');
END$$;
INSERT INTO tower_units VALUES('${unit}','ACTIVE'),('${other}','ACTIVE');
INSERT INTO tower_users VALUES('00000001-1111-4111-8111-111111111111','RESIDENT','ACTIVE',false),('00000002-1111-4111-8111-111111111111','RESIDENT','ACTIVE',false),('00000003-1111-4111-8111-111111111111','ADMIN','ACTIVE',false);
INSERT INTO tower_members VALUES('00000001-1111-4111-8111-111111111111','${unit}','MANAGER',null),('00000002-1111-4111-8111-111111111111','${unit}','MEMBER',null);`);
const manager='00000001-1111-4111-8111-111111111111',member='00000002-1111-4111-8111-111111111111',admin='00000003-1111-4111-8111-111111111111';
const body=async()=>(await db.query("SELECT pg_get_functiondef('tower_resident_trip_settings(text,text,jsonb)'::regprocedure) v")).rows[0].v;
const original=await body(),sql=fs.readFileSync('sql/STAGING_94_Original_SQL242_TRIP_ALERT_PREFERENCES.sql','utf8');await db.exec(sql);
await check('new preferences default disabled; existing fee response retained',async()=>{const r=await call(manager,'get');assert.equal(r.alertAmount,null);assert.equal(r.alertDays,null);assert.equal(r.feeNear,10);});
await check('amount and duration persist per unit with fees in one RPC',async()=>{const r=await call(manager,'update',{feeNear:'12.25',alertAmount:200,alertDays:7});assert.equal(r.feeNear,12.25);assert.equal(r.alertAmount,200);assert.equal(r.alertDays,7);const read=await call(member,'get');assert.equal(read.alertAmount,200);assert.equal(read.feeNear,12.25);});
await check('blank or null disables each limit and omitted fields preserve it',async()=>{await call(manager,'update',{feeNear:20,alertAmount:null});let r=await call(manager,'get');assert.equal(r.alertAmount,null);assert.equal(r.alertDays,7);await call(manager,'update',{feeNear:20,alertAmount:200,alertDays:''});r=await call(manager,'get');assert.equal(r.alertAmount,200);assert.equal(r.alertDays,null);});
await check('invalid zero negative fractional huge boolean and object thresholds rejected',async()=>{for(const value of [0,-1,1.2,'1e2','999999999999999999',true,{},[]])await assert.rejects(()=>call(manager,'update',{feeNear:20,alertAmount:value}),/INVALID_TRIP_ALERT/);for(const value of [0,-1,1.2,3651,'9999999999'])await assert.rejects(()=>call(manager,'update',{feeNear:20,alertDays:value}),/INVALID_TRIP_ALERT/);});
await check('original update authorization and fee validation still authoritative',async()=>{await assert.rejects(()=>call(member,'update',{feeNear:20,alertAmount:30}),/ORIGINAL_SETTINGS_FORBIDDEN/);await assert.rejects(()=>call(manager,'update',{feeNear:-1,alertAmount:30}),/ORIGINAL_INVALID_FEE/);const r=await call(manager,'get');assert.equal(r.alertAmount,200);assert.equal(r.feeNear,20);});
await check('preference storage failure rolls back old distance update too',async()=>{await db.exec(`CREATE FUNCTION fixture_reject_preferences() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN IF NEW.alert_days=13 THEN RAISE EXCEPTION 'FIXTURE_STORAGE_FAILURE'; END IF;RETURN NEW;END$$;
CREATE TRIGGER fixture_reject BEFORE INSERT OR UPDATE ON tower_trip_alert_preferences_242 FOR EACH ROW EXECUTE FUNCTION fixture_reject_preferences();`);await assert.rejects(()=>call(manager,'update',{feeNear:999,alertDays:13}),/FIXTURE_STORAGE_FAILURE/);const r=await call(manager,'get');assert.equal(r.feeNear,20);assert.equal(r.alertDays,null);});
await check('cross unit unauthorized roles inactive membership and changed PIN denied',async()=>{await assert.rejects(()=>call(manager,'get',{unitId:other}),/UNIT_ACCESS_DENIED/);await assert.rejects(()=>call(admin,'get'),/FORBIDDEN/);await db.query('UPDATE tower_users SET must_change_pin=true WHERE user_id=$1',[manager]);await assert.rejects(()=>call(manager,'get'),/FORBIDDEN/);await db.query("UPDATE tower_users SET must_change_pin=false,status='INACTIVE' WHERE user_id=$1",[manager]);await assert.rejects(()=>call(manager,'get'),/FORBIDDEN/);await db.query("UPDATE tower_users SET status='ACTIVE' WHERE user_id=$1",[manager]);await db.query('UPDATE tower_members SET ended_at=now() WHERE user_id=$1',[manager]);await assert.rejects(()=>call(manager,'get'),/UNIT_ACCESS_DENIED/);await db.query('UPDATE tower_members SET ended_at=null WHERE user_id=$1',[manager]);});
await check('invalid unit action and payload rejected without writes',async()=>{await assert.rejects(()=>call(manager,'get',{unitId:'bad'}),/INVALID_UNIT_ID/);await assert.rejects(()=>call(manager,'delete'),/INVALID_OPERATION/);await assert.rejects(()=>db.query('SELECT tower_resident_trip_preferences_242($1,$2,$3)',[manager,'get',[]]),/INVALID_OPERATION/);});
await check('repeat migration preserves preferences and leaves original function byte identical',async()=>{await db.exec(sql);const r=await call(manager,'get');assert.equal(r.alertAmount,200);assert.equal(r.feeNear,20);assert.equal(await body(),original);});
await check('all direct table access revoked; only service role can execute wrapper',async()=>{for(const role of ['anon','authenticated','service_role'])assert.equal((await db.query("SELECT has_table_privilege($1,'tower_trip_alert_preferences_242','SELECT') v",[role])).rows[0].v,false);for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_resident_trip_preferences_242(text,text,jsonb)','EXECUTE') v",[role])).rows[0].v,false);assert.equal((await db.query("SELECT has_function_privilege('service_role','tower_resident_trip_preferences_242(text,text,jsonb)','EXECUTE') v")).rows[0].v,true);});
fs.mkdirSync('qa/v2.5.190',{recursive:true});fs.writeFileSync('qa/v2.5.190/trip-sql-results.json',JSON.stringify(results,null,2));console.log(`${results.length} local SQL checks PASS; old distance function is a test double`);
}finally{await db.close();}
