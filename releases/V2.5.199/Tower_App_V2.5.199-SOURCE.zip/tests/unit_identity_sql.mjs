// Real SQL234 in isolated PGlite. Legacy transfer is an explicit destructive contract double.
// No claim about the unavailable legacy engine implementation or a live database.
import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE||'@electric-sql/pglite'),db=new PGlite(),results=[];
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`,file='sql/STAGING_87_Original_SQL234_TITLES_AND_UNIT_RELATIONS.sql';
const rpc=async(name,args)=>(await db.query('SELECT '+name+'('+args.map((_,i)=>'$'+(i+1)).join(',')+') v',args)).rows[0].v;
const act=(actor,action,payload)=>rpc('tower_unit_membership_234',[id(actor),action,payload]);
async function check(name,f){await f();results.push({check:name,status:'PASS'});console.log('PASS',name)}
try{
await db.exec(fs.readFileSync('tests/fixtures/task_lifecycle_schema.sql','utf8'));
for(const name of ['STAGING_82_Original_SQL229_TASK_LIFECYCLE.sql','STAGING_83_Original_SQL230_TASK_SIMPLIFICATION.sql','STAGING_84_Original_SQL231_TASK_WORKSPACE_AND_PERSON_LABELS.sql'])await db.exec(fs.readFileSync('sql/'+name,'utf8'));
await db.exec(`CREATE TABLE tower_titles(title_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),label text UNIQUE NOT NULL,status text NOT NULL,normalized text NOT NULL);
CREATE FUNCTION tower_collection_batch_233(text,text,jsonb) RETURNS jsonb LANGUAGE sql AS $$SELECT '{}'::jsonb$$;
CREATE FUNCTION tower_member_request_mutate(p_token text,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE target uuid:=(p_payload->>'userId')::uuid; unit uuid:=(p_payload->>'unitId')::uuid;
BEGIN
 IF coalesce((SELECT phone FROM tower_users WHERE user_id=target),'')='' THEN RAISE EXCEPTION 'PHONE_REQUIRED_FOR_MANAGER';END IF;
 -- Deliberately reproduces the reported role/relationship conflation in a contract double.
 UPDATE tower_members SET member_role='MEMBER',relation='' WHERE unit_id=unit AND member_role='MANAGER' AND ended_at IS NULL;
 UPDATE tower_members SET member_role='MANAGER',relation='' WHERE unit_id=unit AND user_id=target AND ended_at IS NULL;
 IF (SELECT login_id FROM tower_users WHERE user_id=target)='reject' THEN RAISE EXCEPTION 'FIXTURE_REJECT_TRANSFER';END IF;
 RETURN jsonb_build_object('success',true);
END$$;
INSERT INTO tower_users(user_id,login_id,name,title,role,status,must_change_pin,phone) VALUES
('${id(1)}','admin','fixture admin','','ADMIN','ACTIVE',false,'100000'),('${id(2)}','union','fixture union','د.','UNION','ACTIVE',false,'100000'),
('${id(3)}','father','fixture father','الحاج','RESIDENT','ACTIVE',false,'100000'),('${id(4)}','son','fixture son','','RESIDENT','ACTIVE',false,'100000'),
('${id(5)}','guard','fixture guard','أ.','OPERATOR','ACTIVE',false,'100000'),('${id(6)}','outsider','fixture outsider','أ.','RESIDENT','ACTIVE',false,'100000'),
('${id(7)}','reject','fixture reject','أ.','RESIDENT','ACTIVE',false,'100000'),('${id(8)}','pin','fixture pin','أ.','UNION','ACTIVE',true,'100000');
INSERT INTO tower_units(unit_id,unit_number,floor,unit_type_id) VALUES('${id(10)}','01','1','${id(90)}'),('${id(11)}','02','2','${id(90)}');
INSERT INTO tower_members(unit_id,user_id,member_role,relation) VALUES('${id(10)}','${id(3)}','MANAGER','أب'),('${id(10)}','${id(4)}','MEMBER','ابن'),('${id(10)}','${id(7)}','MEMBER','ابنة'),('${id(11)}','${id(6)}','MANAGER','مالك');`);
await db.exec(fs.readFileSync(file,'utf8'));
const rows=async()=> (await db.query('SELECT user_id,member_role,relation FROM tower_members WHERE unit_id=$1 ORDER BY user_id',[id(10)])).rows;
await check('migration seeds real active choices and defaults blank existing titles',async()=>{assert.deepEqual((await db.query('SELECT label FROM tower_titles ORDER BY label')).rows.map(x=>x.label).sort(),['أ.','بدون لقب'].sort());assert.equal((await db.query('SELECT title FROM tower_users WHERE user_id=$1',[id(1)])).rows[0].title,'أ.');assert.equal((await db.query('SELECT title FROM tower_users WHERE user_id=$1',[id(3)])).rows[0].title,'الحاج')});
await check('central names use default and preserve registered titles without doubling',async()=>{assert.equal(await rpc('tower_person_label_231',['محمد','',null]),'أ. محمد');assert.equal(await rpc('tower_person_label_231',['د. محمد','د.',null]),'د. محمد');assert.equal(await rpc('tower_person_label_231',['ignored',null,id(3)]),'الحاج fixture father')});
await check('explicit no-title is the only bare-name case including custom title',async()=>{assert.equal(await rpc('tower_person_label_231',['محمد','بدون لقب',null]),'محمد');await db.query("UPDATE tower_users SET custom_title='بدون لقب' WHERE user_id=$1",[id(4)]);assert.equal(await rpc('tower_person_label_231',['ignored',null,id(4)]),'fixture son');assert.equal(await rpc('tower_person_label_231',['fixture son',null,null]),'fixture son')});
await check('real SQL231 recursive presentation honors no-title and defaults in nested identity objects',async()=>{const out=await rpc('tower_present_names_231',[{user:{userId:id(4),name:'fixture son',title:'أ.'},managerName:'fixture father'}]);assert.equal(out.user.displayName,'fixture son');assert.equal(out.managerName,'الحاج fixture father');const bare=await rpc('tower_present_names_231',[{userId:id(1),name:'fixture admin',preferredTitle:''}]);assert.equal(bare.displayName,'أ. fixture admin')});
await check('manager transfer keeps every prior relation despite destructive legacy contract',async()=>{await act(3,'transfer',{unitId:id(10),userId:id(4)});const r=await rows();assert.equal(r[0].member_role,'MEMBER');assert.equal(r[0].relation,'أب');assert.equal(r[1].member_role,'MANAGER');assert.equal(r[1].relation,'ابن');assert.equal(r[2].relation,'ابنة')});
await check('transfer back restores roles while relations stay independently stored',async()=>{await act(4,'transfer',{unitId:id(10),userId:id(3)});const r=await rows();assert.equal(r[0].member_role,'MANAGER');assert.equal(r[1].relation,'ابن')});
await check('old manager loses authority immediately',async()=>{await assert.rejects(()=>act(4,'relation',{unitId:id(10),userId:id(3),relation:'قريب',expectedRelation:'أب'}),/FORBIDDEN/)});
await check('resident manager can correct a member relation and stale edits are rejected',async()=>{await act(3,'relation',{unitId:id(10),userId:id(4),relation:'ابن بالتبني',expectedRelation:'ابن'});await assert.rejects(()=>act(3,'relation',{unitId:id(10),userId:id(4),relation:'ابن',expectedRelation:'ابن'}),/MEMBERSHIP_CHANGED_REFRESH/)});
await check('admin and union can correct relation independently of role',async()=>{await act(1,'relation',{unitId:id(10),userId:id(4),relation:'ابن',expectedRelation:'ابن بالتبني'});await act(2,'relation',{unitId:id(10),userId:id(3),relation:'أب',expectedRelation:'أب'});assert.equal((await rows())[0].member_role,'MANAGER')});
await check('guard and unrelated resident cannot list or mutate memberships',async()=>{await assert.rejects(()=>act(5,'list',{unitId:id(10)}),/FORBIDDEN/);await assert.rejects(()=>act(6,'transfer',{unitId:id(10),userId:id(4)}),/FORBIDDEN/)});
await check('missing session and forced PIN are blocked before mutation',async()=>{await assert.rejects(()=>act(99,'list',{unitId:id(10)}),/SESSION_REQUIRED/);await assert.rejects(()=>act(8,'list',{unitId:id(10)}),/PIN_CHANGE_REQUIRED/)});
await check('another unit member cannot be targeted even by administration',async()=>{await assert.rejects(()=>act(1,'relation',{unitId:id(10),userId:id(6),relation:'ابن',expectedRelation:'مالك'}),/TARGET_MUST_BE_ACTIVE_UNIT_MEMBER/)});
await check('legacy phone requirement remains enforced and no role changes survive failure',async()=>{const before=await rows();await db.query("UPDATE tower_users SET phone='' WHERE user_id=$1",[id(4)]);await assert.rejects(()=>act(3,'transfer',{unitId:id(10),userId:id(4)}),/PHONE_REQUIRED_FOR_MANAGER/);assert.deepEqual(await rows(),before)});
await check('later legacy failure rolls back role and relation writes atomically',async()=>{const before=await rows();await assert.rejects(()=>act(3,'transfer',{unitId:id(10),userId:id(7)}),/FIXTURE_REJECT_TRANSFER/);assert.deepEqual(await rows(),before)});
await check('relation rejects empty oversized and control-character values',async()=>{for(const relation of ['', 'x'.repeat(81),'ab\ncd'])await assert.rejects(()=>act(1,'relation',{unitId:id(10),userId:id(4),relation,expectedRelation:'ابن'}),/INVALID_RELATION/)});
await check('scoped membership list contains titled identities and current relations',async()=>{const r=await act(1,'list',{unitId:id(10)});assert.equal(r.length,3);assert(r.find(x=>x.userId===id(4)).displayName==='fixture son');assert(!r.some(x=>x.userId===id(6)))});
await check('only service role can execute new RPC directly',async()=>{for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_unit_membership_234(text,text,jsonb)','EXECUTE') v",[role])).rows[0].v,false);assert((await db.query("SELECT has_function_privilege('service_role','tower_unit_membership_234(text,text,jsonb)','EXECUTE') v")).rows[0].v)});
await check('migration rerun preserves explicit choices and corrected relations',async()=>{const before=await rows();await db.exec(fs.readFileSync(file,'utf8'));assert.deepEqual(await rows(),before);assert.equal((await db.query('SELECT count(*) n FROM tower_titles')).rows[0].n,2);assert.equal((await db.query('SELECT custom_title FROM tower_users WHERE user_id=$1',[id(4)])).rows[0].custom_title,'بدون لقب')});
fs.mkdirSync('qa/v2.5.179',{recursive:true});fs.writeFileSync('qa/v2.5.179/unit-identity-sql-results.json',JSON.stringify(results,null,2));
}finally{await db.close()}
