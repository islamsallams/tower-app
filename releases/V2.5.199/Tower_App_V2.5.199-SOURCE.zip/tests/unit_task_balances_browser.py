"""Actual Chromium/app assets; synthetic API data, not online Supabase testing."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900})
  def route(r):
   name=r.request.url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if r.request.url.startswith('http://tower.test/') and name in ['index.html','app.js','styles.css']:r.fulfill(path=str(root/name))
   elif r.request.url.startswith('http://tower.test/'):
    body=r.request.post_data_json or {};inner=(body.get('args') or [{}])[0];inner=inner if isinstance(inner,dict) else {};op=inner.get('name')
    if op=='getTaskProject':
     current=inner.get('args',[{}])[-1].get('__activeUnitId','unit');f=service['unitTaskFinance'];number='26' if current=='other' else '01'
     value={'serviceId':'task','name':service['name'],'totalBudget':1900,'unitNumber':number,'enrollment':'FINALIZED','project':{'phase':'PARTICIPATION'},'canManage':False,'hasPersonalAccount':True,'responsibleName':'أ. مسؤول اختبار','subscriptions':[{'subscriptionId':'sub','unitId':current,'unitNumber':number,'status':'ACTIVE','balance':f}],'expenses':[],'adjustments':[],'activeCount':1}
    else:value={'configured':False}
    r.fulfill(json={'ok':True,'result':value})
   else:r.abort()
  page.route('**/*',route);page.goto('http://tower.test/');page.wait_for_function('APP.ctx!==null')
  page.evaluate("APP.ctx={user:{role:'RESIDENT',userId:'resident'}}; APP.page='units'; APP.activeUnitId='unit'; APP.home={unit:{unitNumber:'26'}};APP.unitChoices=[{unit:{unitId:'unit',unitNumber:'01'}},{unit:{unitId:'other',unitNumber:'26'}}];$('root').classList.remove('hidden');$('root').innerHTML='<div id=content></div>'")
  service={'serviceId':'task','serviceKind':'ONE_TIME','pricingMode':'SHARED_TOTAL','enrollmentStatus':'FINALIZED','name':'مهمة اختبار دفتر الوحدة','totalBudget':1900,'unitTaskFinance':{'state':'RECORDED','due':271.43,'paid':100.01,'remaining':171.42}}
  sub={'subscriptionId':'sub','serviceId':'task','unitId':'unit','status':'ACTIVE','amountSnapshot':9999}
  def render(state):
   service['unitTaskFinance']=state
   page.evaluate('(d)=>{window.balanceFixture=d;SERVICE_UI.services=[d.service];SERVICE_UI.subscriptions=[d.sub];$("content").innerHTML=residentServiceCard(d.service,d.sub)}',{'service':service,'sub':sub})
  def check(name,fn):
   fn();results.append({'viewport':width,'check':name,'status':'PASS'});print('PASS',width,name)
  render(service['unitTaskFinance'])
  def recorded():
   text=page.locator('#content').inner_text();assert 'المستحق المعتمد: 272' in text and 'المدفوع للمستحق: 101' in text and 'المتبقي: 172' in text;assert '9,999' not in text
  check('official cents follow existing whole-pound display rule',recorded)
  page.locator('.resident-service-card').click()
  page.locator('.task-workspace').wait_for()
  check('details use same ledger values',lambda: (lambda t: (_ for _ in ()).throw(AssertionError(t)) if not all(x in t for x in ['271.43','100.01','171.42']) else None)(page.locator('#modalSheet').inner_text()))
  check('details identify active unit01 despite stale home26',lambda: page.get_by_text('تفاصيل المهمة · الوحدة 01',exact=True).wait_for())
  page.evaluate('closeModal(true)')
  page.evaluate("APP.activeUnitId='other';APP.home={unit:{unitNumber:'01'}};openResidentServiceDetails('task')")
  check('details identify active unit26 despite stale home01',lambda: page.get_by_text('تفاصيل المهمة · الوحدة 26',exact=True).wait_for())
  page.evaluate("closeModal(true);APP.activeUnitId='unit'")
  render({'state':'UNAVAILABLE'})
  check('unavailable is explicit instead of zero',lambda: (lambda t: (_ for _ in ()).throw(AssertionError(t)) if 'غير متاحين' not in t or 'المدفوع للمستحق: 0' in t else None)(page.locator('#content').inner_text()))
  render({'state':'NOT_RECORDED'})
  check('absent ledger has distinct message',lambda: page.get_by_text('لم يُسجل مستحق رسمي للوحدة لهذه المهمة.',exact=True).wait_for())
  render({'state':'RECORDED','due':271.43,'paid':271.43,'remaining':0})
  check('fully paid remaining zero is displayed',lambda: page.get_by_text('المتبقي:',exact=False).filter(has_text='0 ج.م').wait_for())
  check('no horizontal viewport overflow',lambda: (lambda ok: (_ for _ in ()).throw(AssertionError('overflow')) if not ok else None)(page.evaluate('document.documentElement.scrollWidth<=innerWidth')))
  page.close()
 browser.close()
(root/'qa/v2.5.174').mkdir(parents=True,exist_ok=True)
(root/'qa/v2.5.174/browser-balances-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
