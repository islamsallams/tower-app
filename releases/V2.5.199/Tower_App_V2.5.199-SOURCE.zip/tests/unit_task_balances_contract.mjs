import fs from 'node:fs';import assert from 'node:assert/strict';import worker from '../worker.js';
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`,unit=id(1),service=id(2),sub=id(3);
async function request({role='RESIDENT',denied=false,fail=false,rows=[{serviceId:service,due:271.43,paid:100.01,remaining:171.42,dueCount:1}],scope='UNIT_TASK_DUES',ledgerUnit=unit,stage='FINALIZED'}={}){
 const original=globalThis.fetch,calls=[];
 globalThis.fetch=async(url,opts={})=>{if(new URL(url).pathname.endsWith('/rpc/tower_present_names_231'))return Response.json(JSON.parse(opts.body).p_value);const u=new URL(url),resource=u.pathname.replace('/rest/v1/','');calls.push(resource);const p=JSON.parse(opts.body||'{}');let data;
 if(resource==='rpc/tower_session_user')data=[{user_id:id(9),role}];
 else if(resource==='rpc/tower_unit_services_read_for_unit'){
 assert.equal(p.p_unit_id,unit);if(denied)return Response.json({code:'P0001',message:'UNIT_ACCESS_DENIED'},{status:400});
 data={unitId:unit,services:[{serviceId:service}],subscriptions:[{subscriptionId:sub,unitId:unit,serviceId:service,status:'ACTIVE'}]};
 }else if(resource==='tower_services')data=[{service_id:service,service_kind:'ONE_TIME',pricing_mode:'SHARED_TOTAL',total_budget:1900,enrollment_status:stage}];
 else if(resource==='rpc/tower_task_project_read_230'){assert.equal(p.p_unit,unit);data={totalBudget:1900,activeCount:7,responsibleName:'fixture manager',estimatedShare:271.43,project:{agreed_amounts:[]}};}
 else if(resource==='tower_task_projects')data=[];
 else if(resource==='tower_service_subscriptions')data=[{subscription_id:sub,unit_id:unit,requested_by:null}];
 else if(resource==='rpc/tower_unit_task_balances_read_for_unit'){
 assert.deepEqual(p,{p_token:'fixture',p_unit_id:unit});if(fail)return Response.json({code:'P0001',message:'fixture'},{status:500});data={unitId:ledgerUnit,scope,readOnly:true,rows};
 }else throw Error('Unexpected '+resource);
 return Response.json(data)};
 try{const response=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{name:'getMyServices',token:'fixture',args:[{__activeUnitId:unit}]}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture'});return {status:response.status,body:await response.json(),calls}}finally{globalThis.fetch=original}
}
const results=[];async function check(name,fn){await fn();results.push({check:name,status:'PASS'});console.log('PASS',name)}
const finance=r=>r.body.result.services[0].unitTaskFinance;
await check('authorized exact ledger balance',async()=>assert.deepEqual(finance(await request()),{state:'RECORDED',due:271.43,paid:100.01,remaining:171.42}));
await check('missing due differs from zero payment',async()=>assert.deepEqual(finance(await request({rows:[]})),{state:'NOT_RECORDED'}));
await check('backend failure preserves services without fake zero',async()=>{const r=await request({fail:true});assert.equal(r.status,200);assert.equal(finance(r).state,'UNAVAILABLE')});
for(const [name,opts] of [['foreign scope',{scope:'ALL_UNITS'}],['foreign unit',{ledgerUnit:id(7)}],['invalid arithmetic',{rows:[{serviceId:service,due:100,paid:10,remaining:100,dueCount:1}]}],['null amount',{rows:[{serviceId:service,due:null,paid:0,remaining:0,dueCount:1}]}],['duplicate service',{rows:Array(2).fill({serviceId:service,due:100,paid:0,remaining:100,dueCount:1})}]])await check(name+' rejected',async()=>assert.equal(finance(await request(opts)).state,'UNAVAILABLE'));
await check('denied membership prevents ledger read',async()=>{const r=await request({denied:true});assert(r.body.error);assert(!r.calls.includes('rpc/tower_unit_task_balances_read_for_unit'))});
for(const role of ['ADMIN','UNION','OPERATOR'])await check(role+' cannot read resident balance',async()=>{const r=await request({role});assert(r.body.error);assert.deepEqual(r.calls,['rpc/tower_session_user'])});
await check('unfinalized task skips ledger read',async()=>{const r=await request({stage:'OPEN'});assert(!finance(r));assert(!r.calls.includes('rpc/tower_unit_task_balances_read_for_unit'))});
fs.mkdirSync('qa/v2.5.174',{recursive:true});fs.writeFileSync('qa/v2.5.174/worker-balances-results.json',JSON.stringify(results,null,2));
