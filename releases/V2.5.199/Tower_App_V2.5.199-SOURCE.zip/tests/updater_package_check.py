"""Exercise the real Updater's local inspect/prepare code. Never deploy or access credentials."""
import argparse,ast,json,os,shutil,tempfile,types,zipfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--updater-source',required=True);parser.add_argument('--zip',required=True);parser.add_argument('--output',default='qa/v2.5.174/updater-package-results.json');args=parser.parse_args()
source=Path(args.updater_source);tree=ast.parse(source.read_text(encoding='utf-8-sig'));allowed={'os','re','sys','json','time','shutil','zipfile','subprocess','webbrowser','ctypes','threading','tempfile','urllib.request','urllib.error','socket','pathlib','urllib.parse','http.server'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) or isinstance(n,ast.Import) and all(x.name in allowed for x in n.names) or isinstance(n,ast.ImportFrom) and n.module in allowed];method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_prepare_cloudflare_assets');method.name='prepare_assets';nodes.append(method);ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),ns)
results=[]
def check(name,value):
 assert value,name;results.append({'check':name,'status':'PASS'});print('PASS',name)
package=Path(args.zip).resolve();info=ns['inspect_zip'](package);check('release inspection accepts root-only package',len(info['members'])==5 and not info['root_parts'])
# Config synchronization is deliberately a no-op: this test never reads user setup or secrets.
fake=types.SimpleNamespace(selected_zip=package,worker_name_var=types.SimpleNamespace(get=lambda:'tower-app'),_sync_public_supabase_config=lambda _:None)
deploy_root=None
try:
 deploy_root,version,copied=ns['prepare_assets'](fake)
 with zipfile.ZipFile(package) as z:
  check('generated public assets exactly match root sources',all((deploy_root/'public'/n).read_bytes()==z.read(n) for n in ['app.js','index.html','styles.css']))
  check('worker backend retained exactly', (deploy_root/'worker.js').read_bytes()==z.read('worker.js'))
 check('backend never exposed as public asset',not (deploy_root/'public/worker.js').exists())
 cfg=json.loads((deploy_root/'wrangler.jsonc').read_text());check('assets binding and API routing preserved',cfg['assets']['binding']=='ASSETS' and cfg['assets']['run_worker_first'] is True and cfg['main']=='./worker.js')
 check('cron and existing variables preserved',cfg['keep_vars'] is True and cfg['triggers']['crons']==['*/5 * * * *'])
 check('all three startup assets generated',set(copied)=={'app.js','index.html','styles.css'})
finally:
 if deploy_root:shutil.rmtree(deploy_root,ignore_errors=True)
out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(results,ensure_ascii=False,indent=2))
