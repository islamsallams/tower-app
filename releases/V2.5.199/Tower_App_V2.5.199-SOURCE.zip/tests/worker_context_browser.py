"""Actual frontend consumes JSON produced by the real Worker HTTP handler.
Only the Worker's Supabase dependency uses synthetic fixtures. No online writes.
"""
import json, os, subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(os.environ.get('TOWER_CONTRACT_OUTPUT','/tmp/tower-v169-contract'))
OUT.mkdir(parents=True,exist_ok=True)
subprocess.run(['node','tests/worker_context_contract.mjs'],cwd=ROOT,env={**os.environ,'TOWER_CONTRACT_OUTPUT':str(OUT)},check=True)
fixtures=json.loads((OUT/'worker-context-fixtures.json').read_text());sid=fixtures['OPEN']['service']['serviceId']
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [390,1366]:
  page=browser.new_page(viewport={'width':width,'height':900});page.set_default_timeout(4000)
  state={'stage':'OPEN','incomplete':False};calls=[]
  def route(req):
   url=req.request.url
   if not url.startswith('http://tower.test/'):
    req.abort();return
   name=url.split('?')[0].rsplit('/',1)[-1] or 'index.html'
   if name in ['index.html','app.js','styles.css']:
    req.fulfill(path=str(ROOT/name));return
   payload=req.request.post_data_json or {};method=payload.get('method');inner=(payload.get('args') or [{}])[0]
   if method=='getBootstrapContext':result={'configured':False}
   elif method=='apiCall':
    op=inner.get('name');calls.append(op)
    if op=='getServiceManagerContext':
     result=json.loads(json.dumps(fixtures[state['stage']]))
     if state['incomplete']:
      for key in ['serviceKind','pricingMode','revenueKind','totalBudget','enrollmentStatus']:result['service'].pop(key,None)
    elif op=='getTaskProject':
     d=fixtures[state['stage']];service=d['service'];subs=[{**x,'balance':{'state':'RECORDED' if state['stage']=='FINALIZED' else 'NOT_RECORDED','due':1600 if state['stage']=='FINALIZED' else 0,'paid':0,'remaining':1600 if state['stage']=='FINALIZED' else 0}} for x in d['subscriptions']]
     result={'serviceId':sid,'name':service['name'],'totalBudget':1900,'estimatedNet':1900,'description':service.get('description',''),'responsibleName':'أ. مستفيد تجريبي','enrollment':state['stage'],'project':{'phase':'PARTICIPATION','version':1,'distribution':'EQUAL'},'canManage':True,'canApproveCredit':False,'hasPersonalAccount':True,'subscriptions':subs,'availableUnits':d['units'],'expenses':[],'adjustments':[]}
    elif op=='listTaskInstallments':result={'rows':[],'hasPayments':True}
    elif op=='previewSharedServiceAllocation':result={'totalBudget':1900,'allocations':[{'amount':1900}]}
    else:raise AssertionError('Unexpected API operation '+str(op))
   else:raise AssertionError('Unexpected request '+str(method))
   req.fulfill(json={'ok':True,'result':result})
  page.route('**/*',route);page.goto('http://tower.test/');page.wait_for_function("typeof towerReadServiceManagerContext==='function'")
  page.evaluate("APP.ctx={user:{role:'ADMIN',userId:'fixture-admin'}};APP.page='services';history.replaceState({towerPage:'services'},'', '#services')")
  def reset(stage):
   state.update(stage=stage,incomplete=False)
   page.evaluate("TOWER_OTHER_FORM_BASELINE=null;TOWER_TASK_FORM_BASELINE=null;towerResetModalStack()")
   page.wait_for_timeout(80)
   page.evaluate('(service)=>{SERVICE_UI.services=[service];TASK_WORKFLOW_META[service.serviceId]={fundContributionProposed:500,fundContributionPosted:0}}',fixtures[stage]['service'])
  def check(name,fn):
   try:fn();results.append({'viewport':width,'check':name,'status':'PASS'})
   except Exception as e:results.append({'viewport':width,'check':name,'status':'FAIL','details':str(e)})
  def open_picker():
   reset('OPEN');page.evaluate('(id)=>openSharedAllocation(id)',sid)
   page.locator('#towerInlinePickerToggle').click()
   page.get_by_role('checkbox',name='إضافة وحدة 02',exact=True).wait_for()
   assert page.locator('#serviceAddSelectedButton').is_disabled()
   page.get_by_role('checkbox',name='إضافة وحدة 02',exact=True).check()
   assert not page.locator('#serviceAddSelectedButton').is_disabled()
  check('OPEN context from Worker enables actual inline picker',open_picker)
  for stage in ['CLOSED','FINALIZED']:
   def locked(stage=stage):
    reset(stage);page.evaluate('(id)=>openSharedAllocation(id)',sid)
    assert page.locator('#towerInlinePickerToggle').count()==0
    assert page.locator('#towerSharedMemberList input').count()==0
   check(stage+' context remains read only',locked)
  def report():
   reset('OPEN');page.evaluate('(id)=>openServiceSubscribers(id)',sid)
   text=page.locator('#modalSheet').inner_text()
   assert '1,900.00' in text and 'المشتركون والتوزيع' in text
   report=page.evaluate('taskWorkspaceReport()')
   assert 'أنصبة تقديرية' in report['subtitle']
   assert len(report['sections'][-1]['rows'])==1
   assert page.evaluate('towerModalDepth()')==1
  check('task report shares the authoritative member workspace',report)
  def recurring():
   reset('RECURRING');page.evaluate('(id)=>openServiceSubscribers(id)',sid)
   text=page.locator('#modalSheet').inner_text()
   assert 'خدمة دورية' in text and 'صندوق العمارة' in text
   assert 'التكلفة الإجمالية للمهمة' not in text
  check('recurring report retains recurring classification',recurring)
  def details():
   reset('OPEN');page.evaluate('(id)=>openServiceDetails(id)',sid)
   text=page.locator('#modalSheet').inner_text()
   assert page.locator('.task-workspace').count()==1 and '1,900' in text
   assert 'مستفيد تجريبي' in text
  check('service details preserve full task and beneficiary metadata',details)
  def standalone_open():
   reset('OPEN');page.evaluate('(id)=>openAddServiceSubscribers(id)',sid)
   assert page.get_by_role('checkbox',name='إضافة وحدة 02',exact=True).count()==1
   assert 'حساب شخصي' in page.locator('#modalSheet').inner_text()
  check('standalone add picker consumes same complete context',standalone_open)
  def standalone_closed():
   reset('CLOSED');page.evaluate('(id)=>openAddServiceSubscribers(id)',sid)
   assert page.locator('#modalSheet').inner_text()==''
   assert 'باب الاشتراك مقفول' in page.locator('#toast').inner_text()
  check('standalone add blocks closed shared task',standalone_closed)
  def incomplete():
   reset('OPEN');state['incomplete']=True;page.evaluate('(id)=>openServiceSubscribers(id)',sid)
   text=page.locator('#modalSheet').inner_text()
   assert 'تعذر تحديث بيانات الإدارة' in text
   assert page.get_by_role('button',name='مراجعة واعتماد التوزيع',exact=True).is_disabled()
   assert page.locator('#towerInlinePickerToggle').is_disabled()
  check('incomplete management context blocks enrollment changes and finalization',incomplete)
  page.close()
 browser.close()
(OUT/'worker-context-browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
raise SystemExit(any(r['status']=='FAIL' for r in results))
