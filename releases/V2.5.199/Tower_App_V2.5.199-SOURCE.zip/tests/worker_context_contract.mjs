import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const workerFile=process.env.TOWER_WORKER_FILE||path.join(root,'worker.js');
const {default:worker}=await import(pathToFileURL(workerFile));
const sid='11111111-1111-4111-8111-111111111111';
const uid='22222222-2222-4222-8222-222222222222';
const subid='33333333-3333-4333-8333-333333333333';
const service={serviceId:sid,name:'مهمة اختبار العقد',description:'بيانات مصطنعة',price:0,billingTiming:'POSTPAID',billingCycle:'MONTHLY',allowQuantity:false,cancelable:true,status:'ACTIVE',serviceKind:'ONE_TIME',pricingMode:'SHARED_TOTAL',revenueKind:'PERSONAL_SERVICE',beneficiaryUserId:'44444444-4444-4444-8444-444444444444',beneficiaryName:'مستفيد تجريبي',financeAccountId:'55555555-5555-4555-8555-555555555555',totalBudget:1900,enrollmentStatus:'OPEN'};
const units=[{unit_id:uid,unit_number:'01',floor:'1'},{unit_id:'66666666-6666-4666-8666-666666666666',unit_number:'02',floor:'2'}];
const subs=[{subscription_id:subid,service_id:sid,unit_id:uid,status:'ACTIVE',quantity:1,unit_price_snapshot:0,amount_snapshot:0,billing_timing:'POSTPAID'}];
const realFetch=globalThis.fetch;
export async function contextRequest({role='ADMIN',stage='OPEN',recurring=false,missing=false,invalidList=false,noSession=false,mustChange=false,id=sid,failList=false}={}){
 const calls=[];
 const current={...service,enrollmentStatus:stage,...(recurring?{serviceKind:'RECURRING',pricingMode:'PER_SUBSCRIPTION',revenueKind:'FUND',totalBudget:null,price:100}: {})};
 globalThis.fetch=async(url,opts={})=>{if(new URL(url).pathname.endsWith('/rpc/tower_present_names_231'))return Response.json(JSON.parse(opts.body).p_value);
  const u=new URL(url);assert.equal(u.origin,'https://fixture.supabase.co');
  const resource=u.pathname.replace('/rest/v1/','');calls.push(resource);
  const payload=opts.body?JSON.parse(opts.body):{};
  let result;
  if(resource==='rpc/tower_session_user')result=noSession?[]:[{user_id:'u-admin',role,must_change_pin:mustChange}];
  else if(resource==='rpc/tower_service_finance_action'){
   assert.equal(payload.p_action,'list');assert.equal(payload.p_token,'fixture-session');assert.deepEqual(payload.p_payload,{});
   if(failList)return Response.json({code:'P0001',message:'fixture unavailable'},{status:500});
   result=invalidList?{}:missing?[]:[current];
  }else if(resource==='tower_task_projects')result=[];
  else if(resource==='tower_services'){
   // Reproduce PostgREST projection, including the pre-fix partial response.
   const raw={service_id:sid,name:current.name,description:current.description,price:current.price,billing_timing:current.billingTiming,allow_quantity:current.allowQuantity,cancelable:current.cancelable,status:current.status};
   result=missing?[]:[Object.fromEntries(u.searchParams.get('select').split(',').map(k=>[k,raw[k]]))];
  }else if(resource==='tower_units')result=units;
  else if(resource==='tower_members')result=[{unit_id:uid,member_role:'MANAGER',tower_users:{title:'أ.',name:'اسم تجريبي'}}];
  else if(resource==='tower_service_subscriptions')result=subs;
  else throw Error('Unexpected upstream: '+resource);
  return Response.json(result);
 };
 try{
  const response=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{name:'getServiceManagerContext',token:'fixture-session',args:[id]}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture-only'});
  return {status:response.status,body:await response.json(),calls,expected:current};
 }finally{globalThis.fetch=realFetch;}
}
export async function runContract(){
 const results=[];const fixtureOutput={};
 async function check(name,fn){try{await fn();results.push({check:name,status:'PASS'});console.log('PASS',name)}catch(e){results.push({check:name,status:'FAIL',details:e.message});console.error('FAIL',name,e.message)}}
 for(const stage of ['OPEN','CLOSED','FINALIZED'])await check('shared '+stage+' complete Worker HTTP response',async()=>{
  const r=await contextRequest({stage});assert.equal(r.status,200);assert.equal(r.body.ok,true);assert.deepEqual(r.body.result.service,r.expected);
  assert.equal(r.body.result.subscriptions.length,1);assert.equal(r.body.result.units.length,2);assert.equal(r.body.result.subscriptions[0].managerName,'أ. اسم تجريبي');
  assert(r.calls.includes('rpc/tower_service_finance_action'));fixtureOutput[stage]=r.body.result;
 });
 await check('recurring service classification preserved',async()=>{const r=await contextRequest({recurring:true});assert.equal(r.status,200);assert.deepEqual(r.body.result.service,r.expected);fixtureOutput.RECURRING=r.body.result});
 await check('UNION permitted',async()=>assert.equal((await contextRequest({role:'UNION'})).status,200));
 for(const role of ['RESIDENT','OPERATOR'])await check(role+' forbidden before reading service data',async()=>{const r=await contextRequest({role});assert(r.status>=400);assert(r.body.error);assert(!r.calls.includes('rpc/tower_service_finance_action'));assert(!r.calls.includes('tower_units'))});
 await check('session required',async()=>{const r=await contextRequest({noSession:true});assert.equal(r.status,401);assert.deepEqual(r.calls,['rpc/tower_session_user'])});
 await check('temporary PIN restriction retained',async()=>{const r=await contextRequest({mustChange:true});assert(r.status>=400);assert(r.body.error);assert.deepEqual(r.calls,['rpc/tower_session_user'])});
 await check('invalid ID rejected before data access',async()=>{const r=await contextRequest({id:'bad'});assert(r.status>=400);assert(r.body.error);assert.deepEqual(r.calls,['rpc/tower_session_user'])});
 await check('missing service stops dependent reads',async()=>{const r=await contextRequest({missing:true});assert(r.status>=400);assert(r.body.error);assert(!r.calls.includes('tower_units'))});
 await check('invalid service list fails closed',async()=>{const r=await contextRequest({invalidList:true});assert(r.status>=400);assert(r.body.error);assert(!r.calls.includes('tower_units'))});
 await check('service RPC failure does not fall back to partial metadata',async()=>{const r=await contextRequest({failList:true});assert(r.status>=400);assert(r.body.error);assert(!r.calls.includes('tower_units'))});
 const out=process.env.TOWER_CONTRACT_OUTPUT;
 if(out){fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'worker-context-results.json'),JSON.stringify(results,null,2));fs.writeFileSync(path.join(out,'worker-context-fixtures.json'),JSON.stringify(fixtureOutput,null,2));}
 return results;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const results=await runContract();process.exitCode=results.some(r=>r.status==='FAIL')?1:0;}
