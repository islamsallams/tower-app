// Source-only check: duplicated keys produce a bundler warning even when node --check passes.
import fs from 'node:fs';import assert from 'node:assert/strict';
const src=fs.readFileSync('worker.js','utf8');
const start=src.indexOf('const DB_USER_ERRORS={'),end=src.indexOf('\n};',start);
assert(start>=0&&end>start);
const keys=[...src.slice(start,end).matchAll(/(?:\{|,)\s*["']?([A-Z][A-Z0-9_]*)["']?\s*:/g)].map(m=>m[1]);
assert(keys.length>100);
const seen=new Set(),duplicates=[];for(const key of keys){if(seen.has(key))duplicates.push(key);seen.add(key);}
assert.deepEqual(duplicates,[],'Duplicate Worker error keys: '+duplicates.join(', '));
assert.equal(keys.filter(x=>x==='CHARGE_NOT_FOUND').length,1);
fs.mkdirSync('qa/v2.5.184',{recursive:true});fs.writeFileSync('qa/v2.5.184/worker-error-keys-results.json',JSON.stringify({check:'Worker DB_USER_ERRORS keys are unique',keysChecked:keys.length,status:'PASS'},null,2));
console.log('PASS Worker DB_USER_ERRORS keys are unique; checked '+keys.length+' keys');
