// Local PostgreSQL tests with canonical ledger schema and the actual installed helper definitions.
// No live records, browser, UI, deployment, notifications, or financial actions.
import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`;
async function check(name,fn){await fn();results.push({check:name,status:'PASS'});console.log('PASS',name);}
const read=async(who=1,unit=10)=>(await db.query('SELECT tower_resident_unit_dues_summary_243($1,$2) v',[id(who),id(unit)])).rows[0].v;
const remaining=(r,kind)=>r.groups.find(g=>g.kind===kind).remaining;
const insertCharge=async(n,amount,paid=0,service=null,sub=null)=>{await db.query("INSERT INTO tower_building_charges(charge_id,title,status,total_amount,policy_snapshot,service_id,subscription_id) VALUES($1,'fixture','ACTIVE',$2,'{}',$3,$4)",[id(n),amount,service&&id(service),sub&&id(sub)]);await db.query('INSERT INTO tower_building_allocations(charge_id,unit_id,amount,paid) VALUES($1,$2,$3,$4)',[id(n),id(10),amount,paid]);};
try{
await db.exec(fs.readFileSync('tests/fixtures/task_lifecycle_schema.sql','utf8'));
// Use the original239-installed amount/paid helpers, not a money or receipt approximation.
const helperSource=fs.readFileSync('sql/STAGING_82_Original_SQL229_TASK_LIFECYCLE.sql','utf8');
await db.exec(`CREATE TABLE tower_notifications(user_id uuid,unit_id uuid,target_role text,type text,title text,body text,entity text,entity_id text);`); // Synthetic local sink only; no notifications leave this test database.
await db.exec(helperSource);
await db.exec(`CREATE FUNCTION tower_task_responsible_236(uuid,uuid) RETURNS boolean LANGUAGE sql AS $$SELECT false$$;`); // Unused for this ordinary unit summary; no assignee bypass is tested.
await db.exec(`CREATE TABLE tower_unit_fund_visibility(unit_id uuid PRIMARY KEY REFERENCES tower_units,members_can_view boolean DEFAULT true,changed_by uuid,updated_at timestamptz DEFAULT now());`);
const privacy=fs.readFileSync('sql/STAGING_90_Original_SQL238_UNIT_PRIVACY_AND_TASK_FIXES.sql','utf8');
for(const name of ['tower_unit_fund_visibility_action','tower_assert_unit_account_view_238']){const start=privacy.indexOf('CREATE OR REPLACE FUNCTION public.'+name+'('),end=privacy.indexOf('$f$;',privacy.indexOf('AS $f$',start))+5;await db.exec(privacy.slice(start,end));}
await db.exec(`INSERT INTO tower_users(user_id,login_id,name,role,status,must_change_pin) VALUES('${id(1)}','fixture-1','fixture resident','RESIDENT','ACTIVE',false),('${id(2)}','fixture-2','fixture member','RESIDENT','ACTIVE',false),('${id(3)}','fixture-3','fixture union','UNION','ACTIVE',false);
UPDATE tower_users SET phone='01000000000';
INSERT INTO tower_units(unit_id,unit_number,unit_type_id,floor,status) VALUES('${id(10)}','26','${id(90)}','9','ACTIVE'),('${id(11)}','27','${id(90)}','9','ACTIVE');
INSERT INTO tower_members(unit_id,user_id,member_role,relation) VALUES('${id(10)}','${id(1)}','MANAGER','مالك'),('${id(10)}','${id(2)}','MEMBER','ابن');
INSERT INTO tower_services(service_id,name,service_kind,pricing_mode,total_budget,enrollment_status) VALUES('${id(20)}','fixture recurring','RECURRING','PER_SUBSCRIPTION',null,'OPEN'),('${id(21)}','fixture task','ONE_TIME','SHARED_TOTAL',1000,'OPEN');
INSERT INTO tower_service_subscriptions(subscription_id,service_id,unit_id,requested_by) VALUES('${id(30)}','${id(20)}','${id(10)}','${id(1)}'),('${id(31)}','${id(21)}','${id(10)}','${id(1)}');
UPDATE tower_services SET enrollment_status='FINALIZED' WHERE service_id='${id(21)}';
INSERT INTO tower_finance_accounts(account_id,account_kind,service_id,beneficiary_user_id) VALUES('${id(40)}','PERSONAL_SERVICE','${id(20)}','${id(1)}'),('${id(41)}','PERSONAL_SERVICE','${id(21)}','${id(1)}'),('${id(42)}','FUND',null,null);`);
const sql=fs.readFileSync('sql/STAGING_100_Original_SQL250_UNIT_DUES_ALLOCATION_STATUS.sql','utf8');await db.exec(sql);
await check('empty unit gets complete three zero sections without trip queries',async()=>{const r=await read();assert.equal(r.total,0);assert.equal(r.groups.length,3);assert(r.excludesTrips&&r.readOnly);assert.equal(r.scope,'RESIDENT_UNIT_DUES_SUMMARY');});
await check('building services are classified once rather than added again to union',async()=>{await insertCharge(50,100.25,10);await insertCharge(51,80.50,20,20,30);await insertCharge(52,70.25,10,21,31);const r=await read();assert.equal(r.total,211);assert.equal(remaining(r,'UNION'),90.25);assert.equal(remaining(r,'SERVICES'),60.5);assert.equal(remaining(r,'TASKS'),60.25);});
await db.exec(`INSERT INTO tower_finance_dues(due_id,unit_id,account_id,subscription_id,due_date,amount,status) VALUES('${id(60)}','${id(10)}','${id(40)}','${id(30)}','2026-10-01',100,'OPEN'),('${id(61)}','${id(10)}','${id(41)}','${id(31)}','2026-11-01',200,'OPEN');
INSERT INTO tower_finance_receipts(receipt_id,unit_id,collector_id,amount,receipt_status,external_reference) VALUES('${id(70)}','${id(10)}','${id(1)}',75,'POSTED','fixture-70'),('${id(71)}','${id(10)}','${id(1)}',30,'REVERSED','fixture-71');
INSERT INTO tower_finance_receipt_portions(portion_id,receipt_id,account_id,amount) VALUES('${id(80)}','${id(70)}','${id(40)}',50),('${id(81)}','${id(70)}','${id(41)}',25),('${id(82)}','${id(71)}','${id(40)}',30);
INSERT INTO tower_finance_applications(application_id,portion_id,due_id,amount,application_kind) VALUES('${id(90)}','${id(80)}','${id(60)}',30,'DUE'),('${id(91)}','${id(80)}',null,20,'ADVANCE'),('${id(92)}','${id(81)}','${id(61)}',25,'DUE'),('${id(93)}','${id(82)}','${id(60)}',30,'DUE');
INSERT INTO tower_finance_advance_uses(advance_application_id,due_id,amount) VALUES('${id(91)}','${id(60)}',10);`);
await check('posted receipts and used advances reduce dues; reversed receipts and unused advance do not',async()=>{const r=await read();assert.equal(remaining(r,'SERVICES'),120.5);assert.equal(remaining(r,'TASKS'),235.25);assert.equal(r.total,446);});
await check('task credits and credit reversals use real helper arithmetic',async()=>{await db.exec(`INSERT INTO tower_task_adjustments(adjustment_id,service_id,reference,amount,reason,state,proposed_by) VALUES('${id(100)}','${id(21)}','fixture-credit',-50,'fixture credit','APPROVED','${id(1)}');INSERT INTO tower_task_due_credits(adjustment_id,due_id,amount) VALUES('${id(100)}','${id(61)}',50);`);const r=await read();assert.equal(remaining(r,'TASKS'),185.25);assert.equal(r.total,396);await db.exec(`INSERT INTO tower_task_credit_reversals(adjustment_id,due_id,amount) VALUES('${id(100)}','${id(61)}',10);`);assert.equal((await read()).total,406);});
await check('future posted installments included, subscription prices not treated as debt',async()=>{await db.exec(`UPDATE tower_service_subscriptions SET amount_snapshot=99999 WHERE subscription_id='${id(30)}';`);const r=await read();assert.equal(r.total,406);});
await check('inactive service and ended subscription keep valid posted obligations',async()=>{await db.exec(`UPDATE tower_services SET status='INACTIVE' WHERE service_id='${id(20)}';UPDATE tower_service_subscriptions SET status='ENDED' WHERE subscription_id='${id(30)}';`);assert.equal((await read()).total,406);});
await check('canceled obligations and fully paid balances contribute no remaining',async()=>{await db.exec(`UPDATE tower_finance_dues SET status='CANCELLED' WHERE due_id='${id(60)}';UPDATE tower_building_charges SET status='CANCELED' WHERE charge_id='${id(50)}';UPDATE tower_building_allocations SET paid=amount WHERE charge_id='${id(51)}';`);const r=await read();assert.equal(r.total,195.25);assert.equal(remaining(r,'UNION'),0);assert.equal(remaining(r,'SERVICES'),0);});
await check('privacy denies ordinary member but manager keeps totals',async()=>{await db.exec(`INSERT INTO tower_unit_fund_visibility(unit_id,members_can_view) VALUES('${id(10)}',false);`);await assert.rejects(()=>read(2),/UNIT_ACCOUNT_ACCESS_DENIED/);assert.equal((await read()).total,195.25);});
await check('cross unit roles inactive membership and changed PIN cannot read',async()=>{await assert.rejects(()=>read(1,11),/UNIT_ACCESS_DENIED/);await assert.rejects(()=>read(3),/FORBIDDEN/);await db.exec(`UPDATE tower_users SET must_change_pin=true WHERE user_id='${id(1)}';`);await assert.rejects(()=>read(),/SESSION_REQUIRED/);await db.exec(`UPDATE tower_users SET must_change_pin=false WHERE user_id='${id(1)}';UPDATE tower_members SET ended_at=now() WHERE user_id='${id(1)}';`);await assert.rejects(()=>read(),/UNIT_ACCESS_DENIED/);await db.exec(`UPDATE tower_members SET ended_at=null WHERE user_id='${id(1)}';`);});
await check('summary is read only, repeated migration keeps ledger unchanged and RPC ACL restricted',async()=>{const snapshot=async()=>JSON.stringify((await db.query('SELECT * FROM tower_finance_dues ORDER BY due_id')).rows);const before=await snapshot();for(let i=0;i<5;i++)await read();await db.exec(sql);assert.equal(await snapshot(),before);for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_resident_unit_dues_summary_243(text,uuid)','EXECUTE') v",[role])).rows[0].v,false);});
await check('production regression OPEN allocation and three canceled parent duplicates:89.74+166.67-100=156.41',async()=>{
await db.exec(`INSERT INTO tower_units(unit_id,unit_number,unit_type_id,floor,status) VALUES('${id(12)}','28','${id(90)}','9','ACTIVE');
INSERT INTO tower_members(unit_id,user_id,member_role) VALUES('${id(12)}','${id(1)}','MANAGER');
UPDATE tower_services SET enrollment_status='OPEN' WHERE service_id='${id(21)}';
INSERT INTO tower_service_subscriptions(subscription_id,service_id,unit_id,requested_by) VALUES('${id(32)}','${id(21)}','${id(12)}','${id(1)}');
UPDATE tower_services SET enrollment_status='FINALIZED' WHERE service_id='${id(21)}';
INSERT INTO tower_finance_dues(due_id,unit_id,account_id,subscription_id,due_date,amount,status) VALUES('${id(210)}','${id(12)}','${id(41)}','${id(32)}','2026-10-01',166.67,'OPEN');
INSERT INTO tower_finance_receipts(receipt_id,unit_id,collector_id,amount,receipt_status,external_reference) VALUES('${id(211)}','${id(12)}','${id(1)}',100,'POSTED','fixture-211');
INSERT INTO tower_finance_receipt_portions(portion_id,receipt_id,account_id,amount) VALUES('${id(212)}','${id(211)}','${id(41)}',100);
INSERT INTO tower_finance_applications(application_id,portion_id,due_id,amount,application_kind) VALUES('${id(213)}','${id(212)}','${id(210)}',100,'DUE');`);
for(let n=200;n<204;n++){
await db.query("INSERT INTO tower_building_charges(charge_id,title,status,total_amount,policy_snapshot) VALUES($1,'fixture water',$2,89.74,'{}')",[id(n),n===200?'ACTIVE':'CANCELED']);
await db.query("INSERT INTO tower_building_allocations(charge_id,unit_id,amount,paid,status) VALUES($1,$2,89.74,0,'OPEN')",[id(n),id(12)]);
}
const snapshot=async()=>JSON.stringify((await db.query("SELECT (SELECT jsonb_agg(to_jsonb(a)) FROM tower_building_allocations a) allocations,(SELECT jsonb_agg(to_jsonb(d)) FROM tower_finance_dues d) dues,(SELECT jsonb_agg(to_jsonb(r)) FROM tower_finance_receipts r) receipts")).rows);
const before=await snapshot();await db.exec(fs.readFileSync('sql/STAGING_95_Original_SQL243_RESIDENT_UNIT_DUES_SUMMARY.sql','utf8'));assert.equal((await read(1,12)).total,66.67);
await db.exec(sql);const result=await read(1,12);assert.equal(result.total,156.41);assert.equal(remaining(result,'UNION'),89.74);assert.equal(remaining(result,'TASKS'),66.67);assert.equal(remaining(result,'SERVICES'),0);assert.equal(Math.ceil(result.total),157);assert.equal(result.groups.find(x=>x.kind==='UNION').count,1);assert.equal(await snapshot(),before);
await db.exec(sql);assert.equal((await read(1,12)).total,156.41);assert.equal(await snapshot(),before);
});
fs.mkdirSync('qa/v2.5.200',{recursive:true});fs.writeFileSync('qa/v2.5.200/unit-dues-250-sql-results.json',JSON.stringify(results,null,2));
}catch(e){console.error('SQL191 failure:',e.message,e.detail||'',e.where||'');process.exitCode=1;}finally{await db.close();}
