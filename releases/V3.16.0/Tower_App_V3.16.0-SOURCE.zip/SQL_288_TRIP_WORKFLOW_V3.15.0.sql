-- Tower App V3.15.0 | SQL 288 - trip workflow
-- Install in Supabase SQL Editor after a database backup.
BEGIN;
ALTER TABLE public.tower_trip_settings ADD COLUMN IF NOT EXISTS default_deadline text NOT NULL DEFAULT 'TODAY';
DO $chk$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM pg_constraint WHERE conname='tower_trip_settings_deadline_288_check') THEN
 ALTER TABLE public.tower_trip_settings ADD CONSTRAINT tower_trip_settings_deadline_288_check CHECK(default_deadline IN ('TODAY','DAY','WEEK','OPEN'));
 END IF;
END $chk$;
CREATE TABLE IF NOT EXISTS public.tower_trip_workflow_288 (
 trip_id uuid PRIMARY KEY REFERENCES public.tower_trips(trip_id) ON DELETE CASCADE,
 unit_id uuid NOT NULL REFERENCES public.tower_units(unit_id),
 stage text NOT NULL DEFAULT 'ACTIVE' CHECK(stage IN ('ACTIVE','REQUESTED','SEEN','ACCEPTED','DONE','DECLINED','EXPIRED','CANCELLED')),
 deadline_kind text NOT NULL DEFAULT 'OPEN' CHECK(deadline_kind IN ('TODAY','DAY','WEEK','OPEN')),
 deadline_at timestamptz,
 seen_at timestamptz,
 seen_by uuid REFERENCES public.tower_users(user_id),
 accepted_at timestamptz,
 done_at timestamptz,
 declined_at timestamptz,
 archived_at timestamptz,
 archived_by uuid REFERENCES public.tower_users(user_id),
 reason text NOT NULL DEFAULT '',
 hidden_by_resident boolean NOT NULL DEFAULT false,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tower_trip_workflow_288_stage_due ON public.tower_trip_workflow_288(stage,deadline_at) WHERE stage='REQUESTED';
CREATE TABLE IF NOT EXISTS public.tower_trip_workflow_events_288 (
 event_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 trip_id uuid NOT NULL REFERENCES public.tower_trips(trip_id) ON DELETE CASCADE,
 unit_id uuid NOT NULL REFERENCES public.tower_units(unit_id),
 actor_id uuid REFERENCES public.tower_users(user_id),
 previous_stage text NOT NULL,
 new_stage text NOT NULL,
 reason text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tower_trip_workflow_events_288_trip ON public.tower_trip_workflow_events_288(trip_id,created_at);
REVOKE ALL ON public.tower_trip_workflow_288, public.tower_trip_workflow_events_288 FROM PUBLIC, anon, authenticated;
CREATE OR REPLACE FUNCTION public.tower_trip_deadline_288(kind text, start_at timestamptz)
RETURNS timestamptz LANGUAGE sql STABLE SET search_path='public','pg_temp' AS $fn$
 SELECT CASE kind WHEN 'TODAY' THEN (((start_at AT TIME ZONE 'Africa/Cairo')::date+1)::timestamp AT TIME ZONE 'Africa/Cairo')
 WHEN 'DAY' THEN start_at + interval '1 day' WHEN 'WEEK' THEN start_at + interval '7 day' ELSE NULL END;
$fn$;
CREATE OR REPLACE FUNCTION public.tower_trip_eligible_288(v_trip_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
 SELECT coalesce((SELECT stage NOT IN ('REQUESTED','SEEN') FROM public.tower_trip_workflow_288 WHERE trip_id=v_trip_id),true);
$fn$;
CREATE OR REPLACE FUNCTION public.tower_trip_amount_288(v_trip_id uuid, v_amount numeric)
RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
 SELECT CASE WHEN EXISTS(SELECT 1 FROM public.tower_trip_workflow_288
 WHERE trip_id=v_trip_id AND stage IN ('DECLINED','EXPIRED','CANCELLED')) THEN 0 ELSE v_amount END;
$fn$;
CREATE OR REPLACE FUNCTION public.tower_trip_unpriced_288(v_trip_id uuid,v_items jsonb)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
 SELECT public.tower_trip_amount_288(v_trip_id,1)>0 AND public.tower_trip_unpriced_279(v_items);
$fn$;
CREATE OR REPLACE FUNCTION public.tower_trip_workflow_init_288()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
DECLARE v_kind text;
BEGIN
 SELECT default_deadline INTO v_kind FROM public.tower_trip_settings WHERE unit_id=NEW.unit_id;
 v_kind:=coalesce(v_kind,'TODAY');
 INSERT INTO public.tower_trip_workflow_288(trip_id,unit_id,stage,deadline_kind,deadline_at)
 VALUES(NEW.trip_id,NEW.unit_id,CASE WHEN NEW.actor_role='RESIDENT' THEN 'REQUESTED' ELSE 'ACTIVE' END,
 CASE WHEN NEW.actor_role='RESIDENT' THEN v_kind ELSE 'OPEN' END,
 CASE WHEN NEW.actor_role='RESIDENT' THEN public.tower_trip_deadline_288(v_kind,NEW.created_at) ELSE NULL END);
 RETURN NEW;
END $fn$;
DROP TRIGGER IF EXISTS tower_trip_workflow_init_288 ON public.tower_trips;
CREATE TRIGGER tower_trip_workflow_init_288 AFTER INSERT ON public.tower_trips FOR EACH ROW EXECUTE FUNCTION public.tower_trip_workflow_init_288();
-- Existing open trips are legacy-active and must not suddenly await acceptance.
INSERT INTO public.tower_trip_workflow_288(trip_id,unit_id,stage,deadline_kind)
SELECT trip_id,unit_id,'ACTIVE','OPEN' FROM public.tower_trips ON CONFLICT(trip_id) DO NOTHING;
CREATE OR REPLACE FUNCTION public.tower_trip_workflow_notify_288(v_unit uuid,v_role text,v_trip uuid,v_title text,v_body text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
BEGIN
 BEGIN
 INSERT INTO public.tower_notifications(unit_id,target_role,type,title,body,entity,entity_id)
 VALUES(v_unit,v_role,'TRIP',v_title,left(v_body,400),'trip',v_trip::text);
 EXCEPTION WHEN check_violation THEN
 INSERT INTO public.tower_notifications(unit_id,target_role,type,title,body,entity,entity_id)
 VALUES(v_unit,v_role,'SERVICE',v_title,left(v_body,400),'trip',v_trip::text);
 END;
END $fn$;
REVOKE ALL ON FUNCTION public.tower_trip_workflow_notify_288(uuid,text,uuid,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_trip_workflow_notify_288(uuid,text,uuid,text,text) TO service_role;
CREATE OR REPLACE FUNCTION public.tower_trip_expire_288()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
DECLARE r record; v_count int:=0;
BEGIN
 FOR r IN SELECT w.trip_id,w.unit_id FROM public.tower_trip_workflow_288 w
 JOIN public.tower_trips t ON t.trip_id=w.trip_id
 WHERE w.stage='REQUESTED' AND w.deadline_at<=now() AND t.status='OPEN' AND t.settlement_id IS NULL
 FOR UPDATE OF w SKIP LOCKED LOOP
 UPDATE public.tower_trip_workflow_288 SET stage='EXPIRED',archived_at=now(),reason='انتهت المهلة دون مشاهدة',updated_at=now() WHERE trip_id=r.trip_id;
 INSERT INTO public.tower_trip_workflow_events_288(trip_id,unit_id,previous_stage,new_stage,reason) VALUES(r.trip_id,r.unit_id,'REQUESTED','EXPIRED','انتهت المهلة دون مشاهدة');
 PERFORM public.tower_trip_workflow_notify_288(r.unit_id,'RESIDENT',r.trip_id,'انتهت مهلة طلب المشوار','لم يشاهد الأمين الطلب قبل انتهاء المهلة، وتم نقله للسجل.');
 PERFORM public.tower_trip_workflow_notify_288(r.unit_id,'OPERATOR',r.trip_id,'انتهت مهلة طلب مشوار','انتهت مهلة طلب لم يتم فتحه.');
 v_count:=v_count+1;
 END LOOP;
 RETURN v_count;
END $fn$;
CREATE OR REPLACE FUNCTION public.tower_trip_workflow_action_288(p_token text,p_action text,p_payload jsonb DEFAULT '{}'::jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
DECLARE a public.tower_users; t public.tower_trips; w public.tower_trip_workflow_288; v_trip uuid; v_kind text; v_reason text; v_new text; v_rows jsonb;
BEGIN
 SELECT * INTO a FROM public.tower_session_user(p_token);
 IF NOT FOUND OR a.status<>'ACTIVE' OR a.must_change_pin OR a.role NOT IN ('OPERATOR','RESIDENT') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action='list' THEN
  PERFORM public.tower_trip_expire_288();
  SELECT coalesce(jsonb_agg(jsonb_build_object('tripId',w.trip_id,'unitId',w.unit_id,'stage',w.stage,'deadlineKind',w.deadline_kind,'deadlineAt',w.deadline_at,
  'seenAt',w.seen_at,'acceptedAt',w.accepted_at,'doneAt',w.done_at,'archivedAt',w.archived_at,'reason',w.reason,'hidden',w.hidden_by_resident) ORDER BY t.created_at DESC),'[]'::jsonb)
  INTO v_rows FROM public.tower_trip_workflow_288 w JOIN public.tower_trips t ON t.trip_id=w.trip_id
  WHERE (a.role='OPERATOR' OR EXISTS(SELECT 1 FROM public.tower_members m WHERE m.user_id=a.user_id AND m.unit_id=w.unit_id AND m.ended_at IS NULL))
  AND (p_payload->>'unitId' IS NULL OR w.unit_id=(p_payload->>'unitId')::uuid)
  AND t.status='OPEN' AND t.settlement_id IS NULL
  AND (a.role='OPERATOR' OR NOT w.hidden_by_resident);
  RETURN v_rows;
 END IF;
 IF p_action IN ('view','accept','decline','done','cancel','restore') THEN PERFORM public.tower_trip_expire_288();END IF;
 v_trip:=nullif(p_payload->>'tripId','')::uuid;
 SELECT * INTO t FROM public.tower_trips WHERE trip_id=v_trip FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'TRIP_NOT_FOUND'; END IF;
 SELECT * INTO w FROM public.tower_trip_workflow_288 WHERE trip_id=v_trip FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'WORKFLOW_NOT_FOUND'; END IF;
 IF a.role='RESIDENT' AND NOT EXISTS(SELECT 1 FROM public.tower_members m WHERE m.unit_id=t.unit_id AND m.user_id=a.user_id AND m.ended_at IS NULL) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action='hide' AND a.role='RESIDENT' AND w.stage IN ('CANCELLED','DECLINED','EXPIRED') THEN
  UPDATE public.tower_trip_workflow_288 SET hidden_by_resident=true,updated_at=now() WHERE trip_id=v_trip;
  RETURN jsonb_build_object('success',true);
 END IF;
 IF t.settlement_id IS NOT NULL OR t.status='SETTLED' THEN
  IF p_action='hide' AND a.role='RESIDENT' THEN UPDATE public.tower_trip_workflow_288 SET hidden_by_resident=true WHERE trip_id=v_trip; RETURN jsonb_build_object('success',true); END IF;
  RAISE EXCEPTION 'TRIP_ALREADY_SETTLED';
 END IF;
 IF t.status<>'OPEN' THEN RAISE EXCEPTION 'TRIP_NOT_EDITABLE'; END IF;
 v_reason:=left(trim(coalesce(p_payload->>'reason','')),500);
 v_new:=w.stage;
 IF p_action='view' THEN
  IF a.role<>'OPERATOR' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  IF w.stage='EXPIRED' THEN RAISE EXCEPTION 'TRIP_DEADLINE_EXPIRED';END IF;
  IF w.stage='REQUESTED' THEN v_new:='SEEN';UPDATE public.tower_trip_workflow_288 SET seen_at=now(),seen_by=a.user_id WHERE trip_id=v_trip;END IF;
 ELSIF p_action='accept' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('REQUESTED','SEEN') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_new:='ACCEPTED';UPDATE public.tower_trip_workflow_288 SET accepted_at=now() WHERE trip_id=v_trip;
 ELSIF p_action='decline' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('REQUESTED','SEEN') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:='DECLINED';
 ELSIF p_action='done' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('ACCEPTED','ACTIVE') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:='DONE';
  UPDATE public.tower_trip_workflow_288 SET done_at=now() WHERE trip_id=v_trip;
 ELSIF p_action='reopen' THEN
  IF a.role<>'OPERATOR' OR w.stage<>'DONE' THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:=CASE WHEN t.actor_role='RESIDENT' THEN 'ACCEPTED' ELSE 'ACTIVE' END;
 ELSIF p_action='cancel' THEN
  IF w.stage='CANCELLED' THEN RETURN jsonb_build_object('success',true,'stage',w.stage,'unchanged',true);END IF;
  v_new:='CANCELLED';
 ELSIF p_action='restore' THEN
  IF a.role<>'RESIDENT' OR w.stage NOT IN ('CANCELLED','DECLINED','EXPIRED') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_new:='REQUESTED';v_kind:=coalesce(nullif(p_payload->>'deadline',''),w.deadline_kind);
  IF v_kind NOT IN ('TODAY','DAY','WEEK','OPEN') THEN RAISE EXCEPTION 'INVALID_DEADLINE';END IF;
  UPDATE public.tower_trip_workflow_288 SET deadline_kind=v_kind,deadline_at=public.tower_trip_deadline_288(v_kind,now()),seen_at=NULL,seen_by=NULL,accepted_at=NULL,done_at=NULL,archived_at=NULL WHERE trip_id=v_trip;
 ELSIF p_action='setDeadline' THEN
  IF a.role<>'RESIDENT' OR w.stage<>'REQUESTED' THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_kind:=p_payload->>'deadline';IF v_kind NOT IN ('TODAY','DAY','WEEK','OPEN') THEN RAISE EXCEPTION 'INVALID_DEADLINE';END IF;
  UPDATE public.tower_trip_workflow_288 SET deadline_kind=v_kind,deadline_at=public.tower_trip_deadline_288(v_kind,t.created_at),updated_at=now() WHERE trip_id=v_trip;
  RETURN jsonb_build_object('success',true,'stage',w.stage);
 ELSE RAISE EXCEPTION 'INVALID_OPERATION';END IF;
 IF v_new IS DISTINCT FROM w.stage THEN
  UPDATE public.tower_trip_workflow_288 SET stage=v_new,reason=CASE WHEN v_new IN ('DECLINED','CANCELLED','EXPIRED') THEN v_reason ELSE '' END,
  archived_at=CASE WHEN v_new IN ('DECLINED','CANCELLED','EXPIRED') THEN now() ELSE NULL END,
  archived_by=CASE WHEN v_new IN ('DECLINED','CANCELLED') THEN a.user_id ELSE NULL END,updated_at=now() WHERE trip_id=v_trip;
  INSERT INTO public.tower_trip_workflow_events_288(trip_id,unit_id,actor_id,previous_stage,new_stage,reason) VALUES(v_trip,t.unit_id,a.user_id,w.stage,v_new,v_reason);
  IF v_new IN ('ACCEPTED','DECLINED','DONE','CANCELLED') THEN
   PERFORM public.tower_trip_workflow_notify_288(t.unit_id,CASE WHEN a.role='OPERATOR' THEN 'RESIDENT' ELSE 'OPERATOR' END,v_trip,
   CASE v_new WHEN 'ACCEPTED' THEN 'الأمين استلم المشوار' WHEN 'DECLINED' THEN 'الأمين اعتذر عن المشوار' WHEN 'DONE' THEN 'الأمين أنهى تنفيذ المشوار' ELSE 'تم إلغاء المشوار' END,
   CASE WHEN v_reason<>'' THEN v_reason ELSE 'افتح التطبيق لمراجعة حالة المشوار.' END);
  END IF;
 END IF;
 RETURN jsonb_build_object('success',true,'stage',v_new,'changed',v_new IS DISTINCT FROM w.stage);
END $fn$;
REVOKE ALL ON FUNCTION public.tower_trip_workflow_action_288(text,text,jsonb),public.tower_trip_expire_288() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_trip_workflow_action_288(text,text,jsonb),public.tower_trip_expire_288() TO service_role;
REVOKE ALL ON FUNCTION public.tower_trip_amount_288(uuid,numeric),public.tower_trip_eligible_288(uuid),public.tower_trip_unpriced_288(uuid,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_trip_amount_288(uuid,numeric),public.tower_trip_eligible_288(uuid),public.tower_trip_unpriced_288(uuid,jsonb) TO service_role;

CREATE OR REPLACE FUNCTION public.tower_trip_summary_288(v_out jsonb,v_unit uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
DECLARE v_count int;v_purchases numeric;v_fees numeric;v_gross numeric;v_paid numeric;v_trips jsonb;
BEGIN
 SELECT count(*),coalesce(sum(public.tower_trip_amount_288(t.trip_id,t.purchases_total)),0),
  coalesce(sum(public.tower_trip_amount_288(t.trip_id,t.distance_fee+t.extra_fee)),0),
  coalesce(sum(public.tower_trip_amount_288(t.trip_id,t.total_due)),0),
  coalesce(jsonb_agg(jsonb_build_object('tripId',t.trip_id,'items',t.items,'purchasesTotal',public.tower_trip_amount_288(t.trip_id,t.purchases_total),
  'distance',t.distance,'distanceFee',public.tower_trip_amount_288(t.trip_id,t.distance_fee),'extraFee',public.tower_trip_amount_288(t.trip_id,t.extra_fee),
  'feesTotal',public.tower_trip_amount_288(t.trip_id,t.distance_fee+t.extra_fee),'totalDue',public.tower_trip_amount_288(t.trip_id,t.total_due),
  'notes',t.notes,'createdAt',t.created_at,'actorRole',t.actor_role,
  'orders',(select string_agg(x->>'name','، ') from jsonb_array_elements(t.items) x)) ORDER BY t.created_at DESC),'[]'::jsonb)
 INTO v_count,v_purchases,v_fees,v_gross,v_trips
 FROM public.tower_trips t WHERE t.unit_id=v_unit AND t.status='OPEN' AND t.settlement_id IS NULL AND public.tower_trip_eligible_288(t.trip_id);
 v_paid:=coalesce((v_out->>'paymentsTotal')::numeric,0);
 RETURN v_out||jsonb_build_object('openTripCount',v_count,'purchasesTotal',v_purchases,'feesTotal',v_fees,'grossTotal',v_gross,
 'appliedTotal',least(v_paid,v_gross),'dueTotal',greatest(0,v_gross-v_paid),'creditBalance',greatest(0,v_paid-v_gross),'trips',v_trips);
END $fn$;
REVOKE ALL ON FUNCTION public.tower_trip_summary_288(jsonb,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_trip_summary_288(jsonb,uuid) TO service_role;


-- Updated installed core functions (captured from the supplied SQL_287 definitions).
CREATE OR REPLACE FUNCTION public.tower_trip_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare u public.tower_users; v_unit uuid; v_trip public.tower_trips; v_settings public.tower_trip_settings;
 v_items jsonb; v_item jsonb; v_name text; v_price numeric; v_sum numeric:=0; v_distance text; v_fee numeric; v_request text; v_id uuid; v_latest uuid;
begin
 select * into u from public.tower_session_user(p_token);
 if not found or u.must_change_pin then raise exception 'SESSION_REQUIRED'; end if;
 if p_action='list' then
   if u.role not in ('RESIDENT','OPERATOR') then raise exception 'FORBIDDEN'; end if;
   return coalesce((select jsonb_agg(jsonb_build_object('tripId',t.trip_id,'unitId',t.unit_id,
     'items',t.items,'orders',(select string_agg(z->>'name','، ') from jsonb_array_elements(t.items) z),
     'purchasesTotal',t.purchases_total,'totalDue',case when u.role='OPERATOR' then null else t.total_due end,
     'distance',case when u.role='OPERATOR' then null else t.distance end,
     'distanceFee',case when u.role='OPERATOR' then null else t.distance_fee end,
     'status',t.status,'createdAt',t.created_at,'createdByUserId',t.created_by,'notes',t.notes)
     order by t.created_at desc) from public.tower_trips t
     where (u.role = 'OPERATOR' or exists
       (select 1 from public.tower_members m where m.user_id=u.user_id and m.unit_id=t.unit_id and m.ended_at is null))
       and (p_payload->>'unitId' is null or t.unit_id=(p_payload->>'unitId')::uuid)), '[]'::jsonb);
 end if;
 if u.role not in ('RESIDENT','OPERATOR') then raise exception 'FORBIDDEN'; end if;
 if p_action='create' then
   v_unit=nullif(p_payload->>'unitId','')::uuid;
   if u.role='RESIDENT' then
      if v_unit is not null then
        if not exists(select 1 from public.tower_members m join public.tower_units un on un.unit_id=m.unit_id
          where m.user_id=u.user_id and m.unit_id=v_unit and m.ended_at is null and un.status='ACTIVE')
          then raise exception 'UNIT_ACCESS_DENIED'; end if;
      else
        if (select count(*) from public.tower_members m join public.tower_units un on un.unit_id=m.unit_id where m.user_id=u.user_id and m.ended_at is null and un.status='ACTIVE')>1 then raise exception 'UNIT_REQUIRED'; end if;
        select m.unit_id into v_unit from public.tower_members m join public.tower_units un on un.unit_id=m.unit_id
        where m.user_id=u.user_id and m.ended_at is null and un.status='ACTIVE'
        order by (m.member_role='MANAGER') desc,m.joined_at,m.unit_id limit 1;
      end if;
   end if;
   if v_unit is null or not exists(select 1 from public.tower_units where unit_id=v_unit and status='ACTIVE') then raise exception 'UNIT_NOT_FOUND'; end if;
   v_request=trim(coalesce(p_payload->>'requestId',''));
   if length(v_request)<8 or length(v_request)>128 then raise exception 'REQUEST_ID_REQUIRED'; end if;
   select * into v_trip from public.tower_trips where request_id=v_request;
   if found then
     if v_trip.created_by<>u.user_id or v_trip.unit_id<>v_unit then raise exception 'REQUEST_ID_CONFLICT'; end if;
     return jsonb_build_object('success',true,'duplicate',true,'tripId',v_trip.trip_id);
   end if;
 elsif p_action in ('update','distance','cancel') then
   v_id=nullif(p_payload->>'tripId','')::uuid;
   select * into v_trip from public.tower_trips where trip_id=v_id for update;
   if not found or v_trip.status<>'OPEN' or v_trip.settlement_id is not null then raise exception 'TRIP_NOT_EDITABLE'; end if;
   if u.role='RESIDENT' and not exists(select 1 from public.tower_members m where m.user_id=u.user_id and m.unit_id=v_trip.unit_id and m.ended_at is null) then raise exception 'FORBIDDEN'; end if;
   if u.role='OPERATOR' and p_action<>'update' and v_trip.created_by<>u.user_id then raise exception 'FORBIDDEN'; end if;
   if p_action='distance' and u.role<>'RESIDENT' then raise exception 'FORBIDDEN'; end if;
   if p_action='cancel' then
     if u.role='OPERATOR' then
       if v_trip.created_by<>u.user_id then raise exception 'FORBIDDEN'; end if;
       select t.trip_id into v_latest from public.tower_trips t where t.created_by=u.user_id and t.status='OPEN' and t.settlement_id is null order by t.created_at desc,t.trip_id desc limit 1;
       if v_latest<>v_id then raise exception 'ONLY_LATEST_GUARD_TRIP'; end if;
     end if;
     update public.tower_trips set status='CANCELED',updated_at=now() where trip_id=v_id;
     insert into public.tower_audit(actor_id,action,entity,entity_id) values(u.user_id,'CANCEL_TRIP','TRIP',v_id::text);
     return jsonb_build_object('success',true);
   end if;
   v_unit=v_trip.unit_id;
 else raise exception 'INVALID_OPERATION'; end if;
 insert into public.tower_trip_settings(unit_id) values(v_unit) on conflict do nothing;
 select * into v_settings from public.tower_trip_settings where unit_id=v_unit;
 if p_action in ('create','update') then
   v_items=p_payload->'items';
   if jsonb_typeof(v_items)<>'array' or jsonb_array_length(v_items)>30 then raise exception 'INVALID_ITEMS'; end if;
   if u.role='OPERATOR' then
     -- Discard completely empty rows; preserve genuinely missing prices as JSON null.
     select coalesce(jsonb_agg(jsonb_build_object('name',trim(coalesce(x->>'name','')),
       'price',case when nullif(trim(coalesce(x->>'price','')),'') is null then 'null'::jsonb else to_jsonb(trim(x->>'price')) end) order by ord),'[]'::jsonb)
       into v_items
     from jsonb_array_elements(v_items) with ordinality as a(x,ord)
     where trim(coalesce(x->>'name',''))<>'' or trim(coalesce(x->>'price',''))<>'';
   end if;
   if jsonb_array_length(v_items)<1 then raise exception 'INVALID_ITEMS'; end if;
   for v_item in select value from jsonb_array_elements(v_items) loop
     v_name=trim(coalesce(v_item->>'name',''));
     if length(v_name)<1 or length(v_name)>120 then raise exception 'INVALID_ITEM'; end if;
     if u.role in ('RESIDENT','OPERATOR') and nullif(trim(coalesce(v_item->>'price','')),'') is null then
       -- No amount yet: subtotal includes only priced entries. No fake zero-price entry.
       continue;
     end if;
     if coalesce(v_item->>'price','') !~ '^([0-9]+)(\.[0-9]{1,2})?$' then raise exception 'INVALID_ITEM'; end if;
     v_price=(v_item->>'price')::numeric;
     if v_price>100000000 then raise exception 'INVALID_ITEM'; end if;
     v_sum=v_sum+v_price;
   end loop;
 end if;
 if p_action='create' then
   v_distance=case when u.role='OPERATOR' then v_settings.default_distance else coalesce(nullif(p_payload->>'distance',''),v_settings.default_distance) end;
 else
   v_distance=case when u.role='RESIDENT' then coalesce(nullif(p_payload->>'distance',''),v_trip.distance) else v_trip.distance end;
 end if;
 if v_distance not in ('NEAR','MEDIUM','FAR') then raise exception 'INVALID_DISTANCE'; end if;
 v_fee=case v_distance when 'NEAR' then v_settings.fee_near when 'MEDIUM' then v_settings.fee_medium else v_settings.fee_far end;
 if p_action='create' then
   insert into public.tower_trips(request_id,unit_id,created_by,actor_role,items,purchases_total,distance,distance_fee,total_due,notes)
   values(v_request,v_unit,u.user_id,u.role,v_items,v_sum,v_distance,v_fee,v_sum+v_fee,left(coalesce(p_payload->>'notes',''),2000)) returning trip_id into v_id;
    if u.role='RESIDENT' and p_payload ? 'deadline' then
      perform public.tower_trip_workflow_action_288(p_token,'setDeadline',jsonb_build_object('tripId',v_id,'deadline',p_payload->>'deadline'));
    end if;
 elsif p_action='update' then
   update public.tower_trips set items=v_items,purchases_total=v_sum,distance=v_distance,distance_fee=v_fee,total_due=v_sum+v_fee+extra_fee,
     notes=case when u.role='RESIDENT' then left(coalesce(p_payload->>'notes',notes),2000) else notes end,updated_at=now() where trip_id=v_id;
 else
   update public.tower_trips set distance=v_distance,distance_fee=v_fee,total_due=purchases_total+v_fee+extra_fee,updated_at=now() where trip_id=v_id;
 end if;
 insert into public.tower_audit(actor_id,action,entity,entity_id) values(u.user_id,'TRIP_'||upper(p_action),'TRIP',v_id::text);
 -- Immutable before/after record for edits; written atomically with the trip change.
 if p_action in ('update','distance') then
   insert into public.tower_trip_change_history(
     trip_id,unit_id,actor_id,actor_display_name,actor_role,change_type,
     before_state,after_state)
   select v_id,v_trip.unit_id,u.user_id,
     concat_ws(' ',nullif(trim(coalesce(u.custom_title,'')),''),
       nullif(trim(coalesce(u.title,'')),''),u.name),u.role,upper(p_action),
     jsonb_build_object('items',v_trip.items,'purchasesTotal',v_trip.purchases_total,
       'distance',v_trip.distance,'distanceFee',v_trip.distance_fee,
       'extraFee',v_trip.extra_fee,'totalDue',v_trip.total_due,'notes',v_trip.notes),
     jsonb_build_object('items',t.items,'purchasesTotal',t.purchases_total,
       'distance',t.distance,'distanceFee',t.distance_fee,
       'extraFee',t.extra_fee,'totalDue',t.total_due,'notes',t.notes)
   from public.tower_trips t where t.trip_id=v_id
     and (v_trip.items is distinct from t.items
       or v_trip.distance is distinct from t.distance
       or v_trip.distance_fee is distinct from t.distance_fee
       or v_trip.notes is distinct from t.notes
       or v_trip.extra_fee is distinct from t.extra_fee);
 end if;
 select * into v_trip from public.tower_trips where trip_id=v_id;
 return jsonb_build_object('success',true,'tripId',v_id,'purchasesTotal',v_trip.purchases_total,'totalDue',case when u.role='OPERATOR' then null else v_trip.total_due end,
  'distance',case when u.role='OPERATOR' then null else v_trip.distance end,'distanceFee',case when u.role='OPERATOR' then null else v_trip.distance_fee end);
end $function$


CREATE OR REPLACE FUNCTION public.tower_trip_settlement_action_244(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
 actor public.tower_users;uid uuid;sett public.tower_trip_settlements;request_row public.tower_trip_close_requests_244;
 missing_count integer;exclude_missing boolean:=false;
 n integer;purchases numeric(14,2);fees numeric(14,2);gross numeric(14,2);paid numeric(14,2);before_paid numeric(14,2);
 additional numeric(14,2):=0;cash numeric(14,2);closing numeric(14,2);credit numeric(14,2);explicit_cash boolean;
 sid uuid;pid uuid;cash_pid uuid;seq integer;manager_user uuid;manager_name text;revision text;rid text;value_text text;out jsonb;fields jsonb;identity_payload jsonb;
BEGIN
 SELECT * INTO actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR actor.status<>'ACTIVE' OR actor.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF actor.role<>'RESIDENT' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action NOT IN ('preview','close','undo','summary','details','paymentDetails') OR p_action IS NULL OR jsonb_typeof(p_payload) IS DISTINCT FROM 'object' THEN RAISE EXCEPTION 'INVALID_OPERATION'; END IF;
 BEGIN uid:=nullif(p_payload->>'unitId','')::uuid;EXCEPTION WHEN invalid_text_representation THEN RAISE EXCEPTION 'INVALID_UNIT_ID';END;
 IF NOT EXISTS(SELECT 1 FROM public.tower_members m JOIN public.tower_units u ON u.unit_id=m.unit_id
  WHERE m.user_id=actor.user_id AND m.unit_id=uid AND m.ended_at IS NULL AND u.status='ACTIVE') THEN RAISE EXCEPTION 'UNIT_ACCESS_DENIED'; END IF;
 IF p_action IN ('preview','close','undo') THEN PERFORM 1 FROM public.tower_units WHERE unit_id=uid FOR UPDATE; END IF;
 IF p_action IN ('preview','close') THEN
  IF p_payload ? 'excludeUnpriced' AND jsonb_typeof(p_payload->'excludeUnpriced')<>'boolean' THEN RAISE EXCEPTION 'INVALID_OPERATION'; END IF;
  exclude_missing:=coalesce((p_payload->>'excludeUnpriced')::boolean,false);
  PERFORM 1 FROM public.tower_trips WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id) ORDER BY trip_id FOR UPDATE;
  SELECT count(*) INTO missing_count FROM public.tower_trips WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id) AND public.tower_trip_unpriced_288(trip_id,items);
 END IF;
 IF p_action='summary' THEN
  out:=public.tower_trip_summary_288(public.tower_trip_account(p_token,'summary',p_payload),uid);
  fields:=public.tower_trip_settlement_fields_244(p_token,ARRAY(SELECT (x->>'settlementId')::uuid FROM jsonb_array_elements(coalesce(out->'settlements','[]')) x));
  RETURN jsonb_set(out,'{settlements}',coalesce((SELECT jsonb_agg(x||coalesce((SELECT f FROM jsonb_array_elements(fields) f WHERE f->>'settlementId'=x->>'settlementId'),'{}') ORDER BY (x->>'sequenceNo')::int DESC) FROM jsonb_array_elements(out->'settlements') x),'[]'));
 ELSIF p_action='details' THEN
  out:=public.tower_trip_account(p_token,'details',p_payload);
  fields:=public.tower_trip_settlement_fields_244(p_token,ARRAY[(out->'settlement'->>'settlementId')::uuid]);
  RETURN jsonb_set(out,'{settlement}',(out->'settlement')||coalesce(fields->0,'{}'));
 ELSIF p_action='paymentDetails' THEN
  SELECT jsonb_build_object('paymentId',p.payment_id,'amount',p.amount,'source',p.source,'reference',p.reference,
   'createdAt',p.created_at,'status',p.status,'settlementId',p.settlement_id,
   'canCancel',p.status='OPEN' AND p.settlement_id IS NULL AND p.source='RESIDENT_PAYMENT') INTO out
  FROM public.tower_trip_payments p WHERE p.unit_id=uid AND p.payment_id=nullif(p_payload->>'paymentId','')::uuid;
  IF out IS NULL THEN RAISE EXCEPTION 'PAYMENT_NOT_FOUND'; END IF;RETURN out;
 ELSIF p_action='undo' THEN
  SELECT * INTO sett FROM public.tower_trip_settlements WHERE unit_id=uid ORDER BY sequence_no DESC LIMIT 1 FOR UPDATE;
  IF NOT FOUND OR sett.status<>'ACTIVE' THEN RAISE EXCEPTION 'ONLY_LATEST_SETTLEMENT'; END IF;
  IF coalesce(p_payload->>'expectedSettlementId','')<>sett.settlement_id::text THEN RAISE EXCEPTION 'SETTLEMENT_CHANGED_REFRESH'; END IF;
  IF EXISTS(SELECT 1 FROM public.tower_trip_payments WHERE unit_id=uid AND source='SETTLEMENT_CREDIT' AND reference=sett.settlement_id::text AND (status<>'OPEN' OR settlement_id IS NOT NULL)) THEN RAISE EXCEPTION 'CREDIT_ALREADY_USED'; END IF;
  -- SQL246: reverse only the cash created by this approval, not independent advances.
  cash_pid:=public.tower_trip_settlement_cash_246(sett.settlement_id,uid);
  IF cash_pid IS NOT NULL THEN
   PERFORM 1 FROM public.tower_trip_payments WHERE payment_id=cash_pid AND unit_id=uid
    AND status='APPLIED' AND settlement_id=sett.settlement_id FOR UPDATE;
   IF NOT FOUND THEN RAISE EXCEPTION 'SETTLEMENT_PAYMENT_CHANGED'; END IF;
   UPDATE public.tower_trip_settlement_options_244 SET cash_payment_id=cash_pid WHERE settlement_id=sett.settlement_id AND unit_id=uid;
   UPDATE public.tower_trip_payments SET status='CANCELED',reversal_reason='UNDO '||sett.settlement_id::text,updated_at=now()
    WHERE payment_id=cash_pid AND unit_id=uid;
  END IF;
  UPDATE public.tower_trips SET status='OPEN',settlement_id=NULL,updated_at=now() WHERE unit_id=uid AND settlement_id=sett.settlement_id;
  UPDATE public.tower_trip_payments SET status='REVERSED',reversal_reason='UNDO '||sett.settlement_id::text,updated_at=now() WHERE unit_id=uid AND settlement_id=sett.settlement_id AND source='SETTLEMENT_CLOSING';
  UPDATE public.tower_trip_payments SET status='OPEN',settlement_id=NULL,updated_at=now() WHERE unit_id=uid AND settlement_id=sett.settlement_id AND source<>'SETTLEMENT_CLOSING' AND payment_id IS DISTINCT FROM cash_pid;
  UPDATE public.tower_trip_payments SET status='CANCELED',reversal_reason='UNDO '||sett.settlement_id::text,updated_at=now() WHERE unit_id=uid AND source='SETTLEMENT_CREDIT' AND reference=sett.settlement_id::text AND status='OPEN';
  UPDATE public.tower_trip_settlement_details SET status='CANCELED' WHERE unit_id=uid AND settlement_id=sett.settlement_id;
  UPDATE public.tower_trip_settlements SET status='CANCELED',canceled_at=now(),canceled_by=actor.user_id,cancel_reason=left(coalesce(p_payload->>'reason','UNDO_LATEST'),500) WHERE settlement_id=sett.settlement_id;
  UPDATE public.tower_notifications SET title='تم إلغاء تسوية المشاوير',body='تسوية #'||lpad(sett.sequence_no::text,3,'0')||' ملغاة، وعادت مشاويرها والدفعات السابقة للحساب، وأُلغي مدفوع اعتمادها.' WHERE unit_id=uid AND entity='trip_settlement' AND entity_id=sett.settlement_id::text;
  INSERT INTO public.tower_audit(actor_id,action,entity,entity_id) VALUES(actor.user_id,'UNDO_SETTLEMENT','TRIP_SETTLEMENT',sett.settlement_id::text);
  RETURN jsonb_build_object('success',true,'settlementId',sett.settlement_id);
 END IF;
 WITH trips AS (SELECT * FROM public.tower_trips WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id) AND (NOT exclude_missing OR NOT public.tower_trip_unpriced_288(trip_id,items))),
 payments AS (SELECT * FROM public.tower_trip_payments WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL)
 SELECT (SELECT count(*) FROM trips),(SELECT coalesce(sum(public.tower_trip_amount_288(trip_id,purchases_total)),0) FROM trips),
  (SELECT coalesce(sum(public.tower_trip_amount_288(trip_id,distance_fee+extra_fee)),0) FROM trips),(SELECT coalesce(sum(public.tower_trip_amount_288(trip_id,total_due)),0) FROM trips),
  (SELECT coalesce(sum(amount),0) FROM payments),
  md5(jsonb_build_object('trips',(SELECT coalesce(jsonb_agg(to_jsonb(t)||jsonb_build_object('workflowStage',coalesce((SELECT w.stage FROM public.tower_trip_workflow_288 w WHERE w.trip_id=t.trip_id),'ACTIVE')) ORDER BY trip_id),'[]') FROM trips t),
  'excludedTrips',(SELECT coalesce(jsonb_agg(to_jsonb(t) ORDER BY trip_id),'[]') FROM public.tower_trips t WHERE t.unit_id=uid AND t.status='OPEN' AND t.settlement_id IS NULL AND exclude_missing AND public.tower_trip_eligible_288(t.trip_id) AND public.tower_trip_unpriced_288(t.trip_id,t.items)),
  'payments',(SELECT coalesce(jsonb_agg(to_jsonb(p) ORDER BY payment_id),'[]') FROM payments p))::text)
 INTO n,purchases,fees,gross,paid,revision;
 IF p_action='preview' THEN RETURN jsonb_build_object('unitId',uid,'revision',revision,'openTripCount',n,
  'unpricedTripCount',missing_count,'eligibleTripCount',CASE WHEN exclude_missing THEN n ELSE n-missing_count END,'excludeUnpriced',exclude_missing,'purchasesTotal',purchases,'feesTotal',fees,'grossTotal',gross,'paymentsTotal',paid,'dueTotal',greatest(0,gross-paid),'creditBalance',greatest(0,paid-gross)); END IF;
 rid:=coalesce(p_payload->>'requestId','');IF rid !~ '^[a-zA-Z0-9_-]{16,100}$' THEN RAISE EXCEPTION 'SETTLEMENT_REFERENCE_REQUIRED'; END IF;
 identity_payload:=p_payload-'unitId';
 SELECT * INTO request_row FROM public.tower_trip_close_requests_244 WHERE unit_id=uid AND request_id=rid;
 IF FOUND THEN
  IF request_row.actor_id<>actor.user_id OR request_row.payload<>identity_payload THEN RAISE EXCEPTION 'SETTLEMENT_REQUEST_CHANGED'; END IF;
  RETURN request_row.result||jsonb_build_object('replayed',true,'alreadyCanceled',CASE WHEN request_row.result->>'settlementId' IS NOT NULL THEN EXISTS(SELECT 1 FROM public.tower_trip_settlements WHERE settlement_id=(request_row.result->>'settlementId')::uuid AND status='CANCELED') ELSE EXISTS(SELECT 1 FROM public.tower_trip_payments WHERE payment_id=(request_row.result->>'paymentId')::uuid AND status='CANCELED') END);
 END IF;
 IF missing_count>0 AND NOT exclude_missing THEN RAISE EXCEPTION 'UNPRICED_TRIPS_REQUIRE_CHOICE'; END IF;
 IF n=0 THEN RAISE EXCEPTION 'NO_PRICED_TRIPS'; END IF;
 IF coalesce(p_payload->>'expectedRevision','')<>revision THEN RAISE EXCEPTION 'SETTLEMENT_CHANGED_REFRESH'; END IF;
 value_text:=nullif(btrim(p_payload->>'additionalFees'),'');
 IF value_text IS NOT NULL THEN
  IF value_text !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' THEN RAISE EXCEPTION 'INVALID_SETTLEMENT_AMOUNT'; END IF;IF value_text::numeric>100000000 THEN RAISE EXCEPTION 'INVALID_SETTLEMENT_AMOUNT'; END IF;additional:=value_text::numeric;
 END IF;
 value_text:=nullif(btrim(p_payload->>'paidNow'),'');explicit_cash:=value_text IS NOT NULL;
 IF explicit_cash THEN
  IF value_text !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' THEN RAISE EXCEPTION 'INVALID_SETTLEMENT_AMOUNT'; END IF;IF value_text::numeric>100000000 THEN RAISE EXCEPTION 'INVALID_SETTLEMENT_AMOUNT'; END IF;cash:=value_text::numeric;
 ELSE cash:=greatest(0,gross+additional-paid); END IF;
 before_paid:=paid;
 IF explicit_cash AND cash<greatest(0,gross+additional-paid) THEN
  IF cash<=0 THEN RAISE EXCEPTION 'INVALID_SETTLEMENT_AMOUNT'; END IF;
  out:=public.tower_trip_account(p_token,'addPayment',jsonb_build_object('unitId',uid,'amount',cash::text,'reference','دفعة أثناء مراجعة التسوية'));
  out:=out||jsonb_build_object('paymentOnly',true,'additionalFeesApplied',false,'amount',cash);
  INSERT INTO public.tower_trip_close_requests_244(unit_id,request_id,actor_id,payload,result) VALUES(uid,rid,actor.user_id,identity_payload,out);RETURN out;
 END IF;
 IF explicit_cash AND cash>0 THEN
  out:=public.tower_trip_account(p_token,'addPayment',jsonb_build_object('unitId',uid,'amount',cash::text,'reference','مدفوع عند التسوية'));
  cash_pid:=nullif(out->>'paymentId','')::uuid;
  IF cash_pid IS NULL OR NOT EXISTS(SELECT 1 FROM public.tower_trip_payments
   WHERE payment_id=cash_pid AND unit_id=uid AND source='RESIDENT_PAYMENT' AND status='OPEN'
    AND settlement_id IS NULL AND amount=cash AND created_by=actor.user_id) THEN
   RAISE EXCEPTION 'SETTLEMENT_PAYMENT_LINK_UNCLEAR';
  END IF;
  paid:=paid+cash;
 END IF;
 -- Existing accounting columns retain their old meaning: explicit cash is a real resident payment,
 -- implicit closing is a generated closing payment. Separate metadata supplies the human-facing split.
 closing:=greatest(0,gross+additional-paid);credit:=greatest(0,paid-(gross+additional));
 SELECT coalesce(max(sequence_no),0)+1 INTO seq FROM public.tower_trip_settlements WHERE unit_id=uid;
 SELECT m.user_id INTO manager_user FROM public.tower_members m WHERE m.unit_id=uid AND m.member_role='MANAGER' AND m.ended_at IS NULL;
 SELECT public.tower_person_label_231(u.name,coalesce(nullif(u.custom_title,''),u.title),u.user_id) INTO manager_name FROM public.tower_users u WHERE u.user_id=manager_user;
 manager_name:=coalesce(nullif(trim(manager_name),''),'غير معين');
 INSERT INTO public.tower_trip_settlements(unit_id,sequence_no,settled_by,manager_display_name,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after)
 VALUES(uid,seq,actor.user_id,manager_name,purchases,fees+additional,gross+additional,paid,closing,credit) RETURNING settlement_id INTO sid;
 INSERT INTO public.tower_trip_settlement_options_244(settlement_id,unit_id,extra_fee,trip_fees,prior_paid,paid_now,explicit_payment,cash_payment_id)
 VALUES(sid,uid,additional,fees,before_paid,cash,explicit_cash,cash_pid);
 INSERT INTO public.tower_trip_settlement_details(settlement_id,unit_id,detail_type,entity_id,snapshot,amount)
 SELECT sid,uid,'TRIP',trip_id,jsonb_build_object('tripId',trip_id,'items',items,'purchasesTotal',public.tower_trip_amount_288(trip_id,purchases_total),'originalPurchasesTotal',purchases_total,'distance',distance,'distanceFee',public.tower_trip_amount_288(trip_id,distance_fee),'extraFee',public.tower_trip_amount_288(trip_id,extra_fee),'totalDue',public.tower_trip_amount_288(trip_id,total_due),'notes',notes,'createdAt',created_at,'actorRole',actor_role,'orders',(SELECT string_agg(x->>'name','، ') FROM jsonb_array_elements(items) x),'workflowStage',coalesce((SELECT w.stage FROM public.tower_trip_workflow_288 w WHERE w.trip_id=public.tower_trips.trip_id),'ACTIVE'),'originalTotalDue',total_due),public.tower_trip_amount_288(trip_id,total_due)
 FROM public.tower_trips WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id) AND (NOT exclude_missing OR NOT public.tower_trip_unpriced_288(trip_id,items));
 UPDATE public.tower_trips SET status='SETTLED',settlement_id=sid,updated_at=now() WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id) AND (NOT exclude_missing OR NOT public.tower_trip_unpriced_288(trip_id,items));
 INSERT INTO public.tower_trip_settlement_details(settlement_id,unit_id,detail_type,entity_id,snapshot,amount)
 SELECT sid,uid,'PAYMENT',payment_id,jsonb_build_object('paymentId',payment_id,'amount',amount,'source',source,'reference',reference,'createdAt',created_at),amount
 FROM public.tower_trip_payments WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL;
 UPDATE public.tower_trip_payments SET status='APPLIED',settlement_id=sid,updated_at=now() WHERE unit_id=uid AND status='OPEN' AND settlement_id IS NULL;
 IF closing>0 THEN
  INSERT INTO public.tower_trip_payments(unit_id,amount,status,settlement_id,source,reference,created_by)
  VALUES(uid,closing,'APPLIED',sid,'SETTLEMENT_CLOSING',sid::text,actor.user_id) RETURNING payment_id INTO pid;
  INSERT INTO public.tower_trip_settlement_details(settlement_id,unit_id,detail_type,entity_id,snapshot,amount)
  VALUES(sid,uid,'PAYMENT',pid,jsonb_build_object('paymentId',pid,'amount',closing,'source','SETTLEMENT_CLOSING'),closing);
 END IF;
 IF credit>0 THEN
  INSERT INTO public.tower_trip_payments(unit_id,amount,status,source,reference,created_by)
  VALUES(uid,credit,'OPEN','SETTLEMENT_CREDIT',sid::text,actor.user_id) RETURNING payment_id INTO pid;
  INSERT INTO public.tower_trip_settlement_details(settlement_id,unit_id,detail_type,entity_id,snapshot,amount)
  VALUES(sid,uid,'CREDIT_CARRY',pid,jsonb_build_object('paymentId',pid,'amount',credit,'source','SETTLEMENT_CREDIT'),credit);
 END IF;
 INSERT INTO public.tower_audit(actor_id,action,entity,entity_id) VALUES(actor.user_id,'CLOSE_SETTLEMENT','TRIP_SETTLEMENT',sid::text);
 out:=jsonb_build_object('success',true,'settlementId',sid,'sequenceNo',seq,'grossTotal',gross+additional,
  'priorPayments',before_paid,'closingPayment',cash,'additionalFees',additional,'creditAfter',credit,'paymentOnly',false);
 INSERT INTO public.tower_trip_close_requests_244(unit_id,request_id,actor_id,payload,result) VALUES(uid,rid,actor.user_id,identity_payload,out);
 RETURN out;
END $function$


CREATE OR REPLACE FUNCTION public.tower_resident_trip_preferences_242(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
 v_actor public.tower_users;
 v_unit_id uuid;
 v_settings jsonb;
 v_amount numeric;
 v_days integer;
 v_amount_text text;
 v_days_text text;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.role<>'RESIDENT' OR v_actor.must_change_pin THEN
  RAISE EXCEPTION 'FORBIDDEN';
 END IF;
 IF p_action IS NULL OR p_action NOT IN ('get','update') OR jsonb_typeof(p_payload) IS DISTINCT FROM 'object' THEN
  RAISE EXCEPTION 'INVALID_OPERATION';
 END IF;
 BEGIN v_unit_id:=nullif(p_payload->>'unitId','')::uuid;
 EXCEPTION WHEN invalid_text_representation THEN RAISE EXCEPTION 'INVALID_UNIT_ID'; END;
 IF NOT EXISTS(SELECT 1 FROM public.tower_members m JOIN public.tower_units u ON u.unit_id=m.unit_id
  WHERE m.user_id=v_actor.user_id AND m.unit_id=v_unit_id AND m.ended_at IS NULL AND u.status='ACTIVE') THEN
  RAISE EXCEPTION 'UNIT_ACCESS_DENIED';
 END IF;
 IF p_action='update' THEN
  -- Serialize this unit's settings; the original settings function still authorizes the update.
  PERFORM 1 FROM public.tower_units WHERE unit_id=v_unit_id FOR UPDATE;
  SELECT alert_amount,alert_days INTO v_amount,v_days FROM public.tower_trip_alert_preferences_242 WHERE unit_id=v_unit_id;
  IF p_payload ? 'alertAmount' THEN
   v_amount_text:=nullif(btrim(p_payload->>'alertAmount'),'');
   IF v_amount_text IS NULL THEN v_amount:=NULL;
   ELSIF length(v_amount_text)>9 OR v_amount_text !~ '^[0-9]+$' THEN RAISE EXCEPTION 'INVALID_TRIP_ALERT';
   ELSE
    v_amount:=v_amount_text::numeric;
    IF v_amount<1 OR v_amount>100000000 THEN RAISE EXCEPTION 'INVALID_TRIP_ALERT'; END IF;
   END IF;
  END IF;
  IF p_payload ? 'alertDays' THEN
   v_days_text:=nullif(btrim(p_payload->>'alertDays'),'');
   IF v_days_text IS NULL THEN v_days:=NULL;
   ELSIF length(v_days_text)>4 OR v_days_text !~ '^[0-9]+$' THEN RAISE EXCEPTION 'INVALID_TRIP_ALERT';
   ELSE
    v_days:=v_days_text::integer;
    IF v_days<1 OR v_days>3650 THEN RAISE EXCEPTION 'INVALID_TRIP_ALERT'; END IF;
   END IF;
  END IF;
 END IF;
 -- Preserve installed distance validation, permissions, audit, and fee behavior verbatim.
 -- Both parts commit together or both roll back. No trip or settlement data is touched.
 v_settings:=to_jsonb(public.tower_resident_trip_settings(p_token,p_action,p_payload-'alertAmount'-'alertDays'-'defaultDeadline'));
 IF p_action='update' AND p_payload ? 'defaultDeadline' THEN
  IF coalesce(p_payload->>'defaultDeadline','') NOT IN ('TODAY','DAY','WEEK','OPEN') THEN RAISE EXCEPTION 'INVALID_DEADLINE'; END IF;
  UPDATE public.tower_trip_settings SET default_deadline=p_payload->>'defaultDeadline' WHERE unit_id=v_unit_id;
 END IF;
 IF p_action='update' THEN
  INSERT INTO public.tower_trip_alert_preferences_242(unit_id,alert_amount,alert_days)
  VALUES(v_unit_id,v_amount,v_days)
  ON CONFLICT(unit_id) DO UPDATE SET alert_amount=EXCLUDED.alert_amount,alert_days=EXCLUDED.alert_days,updated_at=now();
 ELSE
  SELECT alert_amount,alert_days INTO v_amount,v_days FROM public.tower_trip_alert_preferences_242 WHERE unit_id=v_unit_id;
 END IF;
 RETURN coalesce(v_settings,'{}'::jsonb)||jsonb_build_object('alertAmount',v_amount,'alertDays',v_days,'defaultDeadline',(SELECT default_deadline FROM public.tower_trip_settings WHERE unit_id=v_unit_id));
END $function$


CREATE OR REPLACE FUNCTION public.tower_guard_trip_summary_247(p_token text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE actor public.tower_users;day_cairo date;
 start_at timestamptz;end_at timestamptz;result jsonb;
BEGIN
 SELECT * INTO actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR actor.status<>'ACTIVE' OR actor.must_change_pin THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF actor.role<>'OPERATOR' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 day_cairo:=(statement_timestamp() AT TIME ZONE 'Africa/Cairo')::date;
 start_at:=day_cairo::timestamp AT TIME ZONE 'Africa/Cairo';
 end_at:=(day_cairo+1)::timestamp AT TIME ZONE 'Africa/Cairo';
 -- One statement snapshot; no client date, list limit, or resident fees enter these totals.
 WITH trip_stats AS (
  SELECT coalesce(sum(public.tower_trip_amount_288(trip_id,purchases_total)) FILTER (
    WHERE status IN ('OPEN','SETTLED') AND public.tower_trip_eligible_288(trip_id) AND created_at>=start_at AND created_at<end_at),0) AS today_purchases,
   coalesce(sum(public.tower_trip_amount_288(trip_id,purchases_total)) FILTER (WHERE status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id)),0) AS open_purchases,
   count(*) FILTER (WHERE status='OPEN' AND settlement_id IS NULL AND public.tower_trip_eligible_288(trip_id)) AS open_count
  FROM public.tower_trips
 ), settlement_stats AS (
  SELECT coalesce(sum(purchases_total),0) AS today_purchases,count(*) AS today_count
  FROM public.tower_trip_settlements
  WHERE status='ACTIVE' AND settled_at>=start_at AND settled_at<end_at
 )
 SELECT jsonb_build_object('scope','GUARD_TRIP_SUMMARY','schemaVersion',1,
  'readOnly',true,'purchasesOnly',true,'timeZone','Africa/Cairo','day',day_cairo,
  'asOf',statement_timestamp(),'todayPurchases',t.today_purchases,
  'todaySettlementPurchases',s.today_purchases,'todaySettlementCount',s.today_count,
  'openPurchases',t.open_purchases,'openTripCount',t.open_count)
 INTO result FROM trip_stats t CROSS JOIN settlement_stats s;
 RETURN result;
END $function$


-- The operator notices inbox excludes archived requests.
CREATE OR REPLACE FUNCTION public.tower_trip_notices_257(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE actor public.tower_users;result jsonb;trip public.tower_trips;rev text;
BEGIN
 SELECT * INTO actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR actor.status<>'ACTIVE' OR actor.must_change_pin OR actor.role<>'OPERATOR' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action IS NULL OR p_action NOT IN('list','read') OR jsonb_typeof(p_payload) IS DISTINCT FROM 'object' THEN RAISE EXCEPTION 'INVALID_OPERATION'; END IF;
 IF p_action='read' THEN
  SELECT * INTO trip FROM public.tower_trips WHERE trip_id=(p_payload->>'tripId')::uuid AND status='OPEN' AND settlement_id IS NULL AND actor_role='RESIDENT'
    AND NOT EXISTS(SELECT 1 FROM public.tower_trip_workflow_288 w WHERE w.trip_id=tower_trips.trip_id AND w.stage IN ('DECLINED','EXPIRED','CANCELLED')) FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'TRIP_NOT_AVAILABLE'; END IF;
  rev:=coalesce(trip.updated_at,trip.created_at)::text;
  IF p_payload->>'revision' IS DISTINCT FROM rev THEN RAISE EXCEPTION 'NOTICE_CHANGED'; END IF;
  INSERT INTO public.tower_trip_notice_reads_257(user_id,trip_id,revision) VALUES(actor.user_id,trip.trip_id,rev)
   ON CONFLICT(user_id,trip_id) DO UPDATE SET revision=EXCLUDED.revision,read_at=now();
  RETURN jsonb_build_object('success',true);
 END IF;
 SELECT coalesce(jsonb_agg(n ORDER BY n->>'createdAt' DESC,n->>'entityId'),'[]') INTO result FROM (
  SELECT jsonb_build_object('notificationId','trip:'||t.trip_id::text,'entity','trip','entityId',t.trip_id,'unitId',t.unit_id,
   'title',c.content->>'title','body',c.content->>'body',
   'createdAt',coalesce(t.updated_at,t.created_at),'revision',coalesce(t.updated_at,t.created_at)::text,'source','trip',
   'status',CASE WHEN r.revision=coalesce(t.updated_at,t.created_at)::text THEN 'READ' ELSE 'UNREAD' END) n
  FROM public.tower_trips t JOIN public.tower_units u ON u.unit_id=t.unit_id
  CROSS JOIN LATERAL (SELECT tower_push383.trip_content_386(t.trip_id,actor.user_id) content) c
  LEFT JOIN public.tower_trip_notice_reads_257 r ON r.trip_id=t.trip_id AND r.user_id=actor.user_id
  WHERE t.status='OPEN' AND t.settlement_id IS NULL AND t.actor_role='RESIDENT'
   AND NOT EXISTS(SELECT 1 FROM public.tower_trip_workflow_288 w WHERE w.trip_id=t.trip_id AND w.stage IN ('DECLINED','EXPIRED','CANCELLED'))
 ) rows;
 RETURN result;
END $function$

COMMIT;
-- __________________
-- Code Ended
-- SQL 288
