-- Tower App V3.15.0 | SQL 289 - Fix ambiguous table aliases in workflow list
-- Apply AFTER SQL_288 on the TEST environment. No data changes.
BEGIN;
CREATE OR REPLACE FUNCTION public.tower_trip_workflow_action_288(p_token text,p_action text,p_payload jsonb DEFAULT '{}'::jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','pg_temp' AS $fn$
DECLARE a public.tower_users; t public.tower_trips; w public.tower_trip_workflow_288; v_trip uuid; v_kind text; v_reason text; v_new text; v_rows jsonb;
BEGIN
 SELECT * INTO a FROM public.tower_session_user(p_token);
 IF NOT FOUND OR a.status<>'ACTIVE' OR a.must_change_pin OR a.role NOT IN ('OPERATOR','RESIDENT') THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action='list' THEN
  PERFORM public.tower_trip_expire_288();
  SELECT coalesce(jsonb_agg(jsonb_build_object('tripId',wf.trip_id,'unitId',wf.unit_id,'stage',wf.stage,'deadlineKind',wf.deadline_kind,'deadlineAt',wf.deadline_at,
  'seenAt',wf.seen_at,'acceptedAt',wf.accepted_at,'doneAt',wf.done_at,'archivedAt',wf.archived_at,'reason',wf.reason,'hidden',wf.hidden_by_resident) ORDER BY tr.created_at DESC),'[]'::jsonb)
  INTO v_rows FROM public.tower_trip_workflow_288 wf JOIN public.tower_trips tr ON tr.trip_id=wf.trip_id
  WHERE (a.role='OPERATOR' OR EXISTS(SELECT 1 FROM public.tower_members m WHERE m.user_id=a.user_id AND m.unit_id=wf.unit_id AND m.ended_at IS NULL))
  AND (p_payload->>'unitId' IS NULL OR wf.unit_id=(p_payload->>'unitId')::uuid)
  AND tr.status='OPEN' AND tr.settlement_id IS NULL
  AND (a.role='OPERATOR' OR NOT wf.hidden_by_resident);
  RETURN v_rows;
 END IF;
 IF p_action IN ('view','accept','decline','done','cancel','restore') THEN PERFORM public.tower_trip_expire_288();END IF;
 v_trip:=nullif(p_payload->>'tripId','')::uuid;
 SELECT * INTO t FROM public.tower_trips WHERE trip_id=v_trip FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'TRIP_NOT_FOUND'; END IF;
 SELECT * INTO w FROM public.tower_trip_workflow_288 WHERE trip_id=v_trip FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'WORKFLOW_NOT_FOUND'; END IF;
 IF a.role='RESIDENT' AND NOT EXISTS(SELECT 1 FROM public.tower_members m WHERE m.unit_id=t.unit_id AND m.user_id=a.user_id AND m.ended_at IS NULL) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action='hide' AND a.role='RESIDENT' AND w.stage IN ('CANCELLED','DECLINED','EXPIRED') THEN
  UPDATE public.tower_trip_workflow_288 SET hidden_by_resident=true,updated_at=now() WHERE trip_id=v_trip;
  RETURN jsonb_build_object('success',true);
 END IF;
 IF t.settlement_id IS NOT NULL OR t.status='SETTLED' THEN
  IF p_action='hide' AND a.role='RESIDENT' THEN UPDATE public.tower_trip_workflow_288 SET hidden_by_resident=true WHERE trip_id=v_trip; RETURN jsonb_build_object('success',true); END IF;
  RAISE EXCEPTION 'TRIP_ALREADY_SETTLED';
 END IF;
 IF t.status<>'OPEN' THEN RAISE EXCEPTION 'TRIP_NOT_EDITABLE'; END IF;
 v_reason:=left(trim(coalesce(p_payload->>'reason','')),500);
 v_new:=w.stage;
 IF p_action='view' THEN
  IF a.role<>'OPERATOR' THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
  IF w.stage='EXPIRED' THEN RAISE EXCEPTION 'TRIP_DEADLINE_EXPIRED';END IF;
  IF w.stage='REQUESTED' THEN v_new:='SEEN';UPDATE public.tower_trip_workflow_288 SET seen_at=now(),seen_by=a.user_id WHERE trip_id=v_trip;END IF;
 ELSIF p_action='accept' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('REQUESTED','SEEN') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_new:='ACCEPTED';UPDATE public.tower_trip_workflow_288 SET accepted_at=now() WHERE trip_id=v_trip;
 ELSIF p_action='decline' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('REQUESTED','SEEN') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:='DECLINED';
 ELSIF p_action='done' THEN
  IF a.role<>'OPERATOR' OR w.stage NOT IN ('ACCEPTED','ACTIVE') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:='DONE';
  UPDATE public.tower_trip_workflow_288 SET done_at=now() WHERE trip_id=v_trip;
 ELSIF p_action='reopen' THEN
  IF a.role<>'OPERATOR' OR w.stage<>'DONE' THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;v_new:=CASE WHEN t.actor_role='RESIDENT' THEN 'ACCEPTED' ELSE 'ACTIVE' END;
 ELSIF p_action='cancel' THEN
  IF w.stage='CANCELLED' THEN RETURN jsonb_build_object('success',true,'stage',w.stage,'unchanged',true);END IF;
  v_new:='CANCELLED';
 ELSIF p_action='restore' THEN
  IF a.role<>'RESIDENT' OR w.stage NOT IN ('CANCELLED','DECLINED','EXPIRED') THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_new:='REQUESTED';v_kind:=coalesce(nullif(p_payload->>'deadline',''),w.deadline_kind);
  IF v_kind NOT IN ('TODAY','DAY','WEEK','OPEN') THEN RAISE EXCEPTION 'INVALID_DEADLINE';END IF;
  UPDATE public.tower_trip_workflow_288 SET deadline_kind=v_kind,deadline_at=public.tower_trip_deadline_288(v_kind,now()),seen_at=NULL,seen_by=NULL,accepted_at=NULL,done_at=NULL,archived_at=NULL WHERE trip_id=v_trip;
 ELSIF p_action='setDeadline' THEN
  IF a.role<>'RESIDENT' OR w.stage<>'REQUESTED' THEN RAISE EXCEPTION 'INVALID_TRIP_STAGE';END IF;
  v_kind:=p_payload->>'deadline';IF v_kind NOT IN ('TODAY','DAY','WEEK','OPEN') THEN RAISE EXCEPTION 'INVALID_DEADLINE';END IF;
  UPDATE public.tower_trip_workflow_288 SET deadline_kind=v_kind,deadline_at=public.tower_trip_deadline_288(v_kind,t.created_at),updated_at=now() WHERE trip_id=v_trip;
  RETURN jsonb_build_object('success',true,'stage',w.stage);
 ELSE RAISE EXCEPTION 'INVALID_OPERATION';END IF;
 IF v_new IS DISTINCT FROM w.stage THEN
  UPDATE public.tower_trip_workflow_288 SET stage=v_new,reason=CASE WHEN v_new IN ('DECLINED','CANCELLED','EXPIRED') THEN v_reason ELSE '' END,
  archived_at=CASE WHEN v_new IN ('DECLINED','CANCELLED','EXPIRED') THEN now() ELSE NULL END,
  archived_by=CASE WHEN v_new IN ('DECLINED','CANCELLED') THEN a.user_id ELSE NULL END,updated_at=now() WHERE trip_id=v_trip;
  INSERT INTO public.tower_trip_workflow_events_288(trip_id,unit_id,actor_id,previous_stage,new_stage,reason) VALUES(v_trip,t.unit_id,a.user_id,w.stage,v_new,v_reason);
  IF v_new IN ('ACCEPTED','DECLINED','DONE','CANCELLED') THEN
   PERFORM public.tower_trip_workflow_notify_288(t.unit_id,CASE WHEN a.role='OPERATOR' THEN 'RESIDENT' ELSE 'OPERATOR' END,v_trip,
   CASE v_new WHEN 'ACCEPTED' THEN 'الأمين استلم المشوار' WHEN 'DECLINED' THEN 'الأمين اعتذر عن المشوار' WHEN 'DONE' THEN 'الأمين أنهى تنفيذ المشوار' ELSE 'تم إلغاء المشوار' END,
   CASE WHEN v_reason<>'' THEN v_reason ELSE 'افتح التطبيق لمراجعة حالة المشوار.' END);
  END IF;
 END IF;
 RETURN jsonb_build_object('success',true,'stage',v_new,'changed',v_new IS DISTINCT FROM w.stage);
END $fn$;
COMMIT;
-- __________________
-- Code Ended
-- SQL 289
