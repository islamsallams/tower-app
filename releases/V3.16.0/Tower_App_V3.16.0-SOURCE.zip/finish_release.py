from pathlib import Path
import re,zipfile
p=Path('/mnt/data/tower_work')
a=(p/'app.js').read_text();w=(p/'worker.js').read_text();h=(p/'index.html').read_text()
# Remove accidental repeated UI blocks and duplicate function in RC1
phrase="${!opts.deleteTrips?'<div class=\"state-card\"><strong>المشاوير محفوظة</strong><span>لن تُحذف المشاوير أو مدفوعاتها أو تسوياتها ضمن هذا التصفير. قد يمنع النظام حذف حسابات مرتبطة بها.</span></div>':''}"
assert a.count(phrase)==2
a=a.replace(phrase+phrase,phrase)
match=re.search(r'(function copyResetTechnical400\(\)\{[^\n]+\}\n)\1',a)
assert match
#a duplicate harmless but remove
start=a.index('function copyResetTechnical400()'); end=a.index('\n',start)
assert a[end+1:].startswith('function copyResetTechnical400()')
a=a[:end+1]+a[end+1:].replace(a[start:end+1],'',1)
# Update cached frontend assets to avoid 3.9.9 stale cache
h=h.replace('/styles.css?v=3.9.9','/styles.css?v=3.10.0').replace('/app.js?v=3.9.9','/app.js?v=3.10.0')
# Telegram: fallback generic notification text should explain collection approval, only when event actually signals approval
needle=" const link=telegramDeepLink(env,String(userRows[0]?.role||''),String(eventRows[0]?.type||''));\n return link?msg+'\\nافتح القسم المناسب: '+link:msg;"
assert needle in w
replacement=""" const role=String(userRows[0]?.role||''),type=String(eventRows[0]?.type||'');
 const link=telegramDeepLink(env,role,type);
 // Only reword an explicit collection-approval event. Never imply approval for other notifications.
 const isApproval=/اعتماد|اعتمد|تم قبول/.test(msg) && /تقرير التحصيل|التحصيل/.test(msg);
 const friendly=isApproval?'✅ Tower App — '+(role==='OPERATOR'?'الأمين':'الحساب')+'\\nتم اعتماد تقرير التحصيل الخاص بك من الاتحاد. افتح التطبيق للاطلاع على التفاصيل.':msg;
 return link?friendly+'\\nافتح القسم المناسب: '+link:friendly;"""
w=w.replace(needle,replacement)
(p/'app.js').write_text(a);(p/'worker.js').write_text(w);(p/'index.html').write_text(h)
out=Path('/mnt/data/Tower_App_V3.10.0_DEPLOY.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in ['app.js','index.html','styles.css','worker.js','wrangler.toml']:z.write(p/n,n)
print(out,out.stat().st_size)
