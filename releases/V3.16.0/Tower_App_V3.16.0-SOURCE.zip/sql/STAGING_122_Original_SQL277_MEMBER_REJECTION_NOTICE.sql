/* Tower App V3.9.7 - SQL_277.
___________________________
Member rejection decision notice.
   Requires the established notification schema; does not resend historical decisions. */
BEGIN;
CREATE OR REPLACE FUNCTION public.tower_member_rejection_notice_277() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public AS $notice$
DECLARE decision jsonb:=to_jsonb(NEW);owner_id uuid;unit_label text;reason text;message text;
BEGIN
 IF OLD.status IS DISTINCT FROM 'PENDING' OR NEW.status IS DISTINCT FROM 'REJECTED' THEN RETURN NEW;END IF;
 owner_id:=NEW.requested_by;
 IF owner_id IS NULL THEN RETURN NEW;END IF;
 IF EXISTS(SELECT 1 FROM public.tower_notifications n WHERE n.user_id=owner_id AND n.entity='member_request' AND n.entity_id=NEW.request_id::text AND n.title='تم رفض طلب إضافة عضو') THEN RETURN NEW;END IF;
 SELECT unit_number INTO unit_label FROM public.tower_units WHERE unit_id=NEW.unit_id;
 reason:=btrim(CASE WHEN decision ? 'decision_notes' THEN coalesce(decision->>'decision_notes','') WHEN decision ? 'review_notes' THEN coalesce(decision->>'review_notes','') ELSE coalesce(decision->>'notes','') END);
 message:='تم رفض طلب إضافة '||left(coalesce(nullif(NEW.candidate_name,''),'العضو'),100)||CASE WHEN unit_label IS NOT NULL THEN ' إلى الوحدة '||left(unit_label,40) ELSE '' END||'.';
 IF reason<>'' THEN message:=message||E'\nسبب الرفض: '||left(reason,300);END IF;
 BEGIN
  INSERT INTO public.tower_notifications(user_id,unit_id,type,title,body,entity,entity_id)
   VALUES(owner_id,NEW.unit_id,'MEMBERSHIP','تم رفض طلب إضافة عضو',message,'member_request',NEW.request_id::text);
 EXCEPTION WHEN check_violation THEN
  INSERT INTO public.tower_notifications(user_id,unit_id,type,title,body,entity,entity_id)
   VALUES(owner_id,NEW.unit_id,'SERVICE','تم رفض طلب إضافة عضو',message,'member_request',NEW.request_id::text);
 END;
 RETURN NEW;
END $notice$;
REVOKE ALL ON FUNCTION public.tower_member_rejection_notice_277() FROM PUBLIC,anon,authenticated,service_role;
DROP TRIGGER IF EXISTS tower_member_rejection_notice_277 ON public.tower_member_requests;
CREATE TRIGGER tower_member_rejection_notice_277 AFTER UPDATE OF status ON public.tower_member_requests FOR EACH ROW EXECUTE FUNCTION public.tower_member_rejection_notice_277();
NOTIFY pgrst,'reload schema';
COMMIT;

/*
___________________________
Tower App V3.9.7 - SQL_277.
Code End
*/
