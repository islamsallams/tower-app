/*
Tower App V3.9.8 - SQL_280.

___________________________
*/
BEGIN;
SET LOCAL lock_timeout='10s';
CREATE OR REPLACE FUNCTION public.tower_task_fund_receipt_action_217(p_token text, p_service_id uuid, p_action text DEFAULT 'status'::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE v_actor public.tower_users; v_f public.tower_task_fund_contributions;
 v_r public.tower_task_fund_receipts; v_account uuid; v_count integer;
BEGIN
 SELECT * INTO v_actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR v_actor.status<>'ACTIVE' OR v_actor.must_change_pin
 THEN RAISE EXCEPTION 'SESSION_REQUIRED'; END IF;
 IF p_action='confirm' AND NOT public.tower_task_responsible_236(v_actor.user_id,p_service_id) THEN RAISE EXCEPTION 'TASK_RECEIPT_RECIPIENT_ONLY'; END IF;
 IF p_action='status' AND v_actor.role NOT IN ('ADMIN','UNION') AND NOT public.tower_task_responsible_236(v_actor.user_id,p_service_id) THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;
 IF p_action NOT IN ('status','confirm') OR p_action IS NULL THEN RAISE EXCEPTION 'INVALID_ACTION'; END IF;
 SELECT * INTO v_f FROM public.tower_task_fund_contributions WHERE service_id=p_service_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'FUND_CONTRIBUTION_NOT_POSTED'; END IF;
 SELECT * INTO v_r FROM public.tower_task_fund_receipts WHERE service_id=p_service_id;
 IF p_action='confirm' AND NOT FOUND THEN
  -- Lock funding row to serialize concurrent confirmations.
  PERFORM 1 FROM public.tower_task_fund_contributions WHERE service_id=p_service_id FOR UPDATE;
  SELECT * INTO v_r FROM public.tower_task_fund_receipts WHERE service_id=p_service_id;
  IF FOUND THEN RAISE EXCEPTION 'FUND_RECEIPT_ALREADY_CONFIRMED'; END IF;
  SELECT count(*),min(a.account_id::text)::uuid INTO v_count,v_account
  FROM public.tower_finance_accounts a WHERE a.account_kind='PERSONAL_SERVICE'
   AND a.service_id=p_service_id AND a.status='ACTIVE';
  IF v_count<>1 THEN RAISE EXCEPTION 'UNIQUE_ACTIVE_TASK_ACCOUNT_REQUIRED'; END IF;
  INSERT INTO public.tower_task_fund_receipts(service_id,account_id,amount,confirmed_by)
  VALUES(p_service_id,v_account,v_f.amount,v_actor.user_id);
  INSERT INTO public.tower_audit(actor_id,action,entity,entity_id)
  VALUES(v_actor.user_id,'CONFIRM_TASK_FUND_RECEIPT','SERVICE',p_service_id::text);
  SELECT * INTO v_r FROM public.tower_task_fund_receipts WHERE service_id=p_service_id;
 END IF;
 RETURN jsonb_build_object('serviceId',p_service_id,'fundExpenseId',v_f.fund_entry_id,
  'canConfirm',public.tower_task_responsible_236(v_actor.user_id,p_service_id),'postedAmount',v_f.amount,'confirmed',v_r.service_id IS NOT NULL,
  'confirmedAmount',CASE WHEN v_r.service_id IS NOT NULL THEN v_r.amount ELSE 0 END,
  'accountId',v_r.account_id,'confirmedAt',v_r.confirmed_at);
END $function$;
CREATE OR REPLACE FUNCTION public.tower_telegram_content_395(p_delivery uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public AS $tg$
DECLARE l record;n public.tower_notifications;u public.tower_users;acct record;t public.tower_trips;st public.tower_trip_settlements;unit_label text;sender text;items jsonb;kind text;show_money boolean;
BEGIN
 SELECT user_id,event_key INTO l FROM public.tower_telegram_delivery_log WHERE delivery_id=p_delivery;
 IF NOT FOUND OR l.event_key !~ '^notification:[0-9a-fA-F-]{36}$' THEN RETURN NULL;END IF;
 SELECT * INTO n FROM public.tower_notifications WHERE notification_id=substring(l.event_key FROM 14)::uuid;
 IF NOT FOUND OR lower(coalesce(n.entity,'')) NOT IN ('trip','trip_settlement','settlement') THEN RETURN NULL;END IF;
 SELECT * INTO u FROM public.tower_users WHERE user_id=l.user_id AND status='ACTIVE' AND NOT must_change_pin;
 IF NOT FOUND THEN RETURN jsonb_build_object('skip',true);END IF;
 SELECT chat_id,show_amounts INTO acct FROM public.tower_telegram_accounts WHERE user_id=u.user_id AND enabled;
 IF NOT FOUND THEN RETURN jsonb_build_object('skip',true);END IF;
 IF (n.user_id IS NOT NULL AND n.user_id<>u.user_id) OR (n.target_role IS NOT NULL AND n.target_role<>u.role) THEN RETURN jsonb_build_object('skip',true);END IF;
 IF u.role='RESIDENT' THEN
  IF NOT EXISTS(SELECT 1 FROM public.tower_members m JOIN public.tower_units un USING(unit_id) WHERE m.unit_id=n.unit_id AND m.user_id=u.user_id AND m.ended_at IS NULL AND un.status='ACTIVE') THEN RETURN jsonb_build_object('skip',true);END IF;
 ELSIF u.role<>'OPERATOR' THEN RETURN NULL;
 END IF;
 show_money:=coalesce(acct.show_amounts,false) AND u.role='RESIDENT';
 SELECT unit_number INTO unit_label FROM public.tower_units WHERE unit_id=n.unit_id;
 IF lower(n.entity)='trip' THEN
  SELECT * INTO t FROM public.tower_trips WHERE trip_id=n.entity_id::uuid AND unit_id=n.unit_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('skip',true);END IF;
  SELECT public.tower_person_label_231(p.name,coalesce(nullif(p.custom_title,''),p.title),p.user_id) INTO sender FROM public.tower_users p WHERE p.user_id=t.created_by;
  SELECT coalesce(jsonb_agg(jsonb_build_object('name',left(coalesce(x->>'name','بند'),80))||CASE WHEN show_money THEN jsonb_build_object('price',x->'price') ELSE '{}'::jsonb END ORDER BY ord),'[]'::jsonb) INTO items
   FROM jsonb_array_elements(CASE WHEN jsonb_typeof(t.items)='array' THEN t.items ELSE '[]'::jsonb END) WITH ORDINALITY e(x,ord) WHERE ord<=20;
  kind:=CASE WHEN t.status='CANCELED' THEN 'canceled' WHEN n.title ~ '(حدّث|تعديل|تحديث)' THEN 'updated' ELSE 'created' END;
  RETURN jsonb_build_object('entity','trip','entityId',t.trip_id,'createdAt',t.created_at,'unitId',t.unit_id,'owner',u.user_id,'chatId',acct.chat_id,'unitNumber',unit_label,'sender',sender,'kind',kind,'items',items,'moreItems',greatest(0,jsonb_array_length(CASE WHEN jsonb_typeof(t.items)='array' THEN t.items ELSE '[]'::jsonb END)-20),'note',left(coalesce(t.notes,''),200),'showAmounts',show_money)
   ||CASE WHEN show_money THEN jsonb_build_object('purchases',t.purchases_total,'distance',t.distance,'distanceFee',t.distance_fee,'extraFee',t.extra_fee,'total',t.total_due,
    'missingPrices',EXISTS(SELECT 1 FROM jsonb_array_elements(CASE WHEN jsonb_typeof(t.items)='array' THEN t.items ELSE '[]'::jsonb END) x WHERE x->>'price' IS NULL OR btrim(x->>'price')='')) ELSE '{}'::jsonb END;
 END IF;
 SELECT * INTO st FROM public.tower_trip_settlements WHERE settlement_id=n.entity_id::uuid AND unit_id=n.unit_id;
 IF NOT FOUND THEN RETURN jsonb_build_object('skip',true);END IF;
 RETURN jsonb_build_object('entity','trip_settlement','entityId',st.settlement_id,'unitId',st.unit_id,'owner',u.user_id,'chatId',acct.chat_id,'unitNumber',unit_label,'sequence',st.sequence_no,'kind',CASE WHEN st.status='CANCELED' THEN 'canceled' ELSE 'approved' END,'showAmounts',show_money)
  ||CASE WHEN show_money THEN jsonb_build_object('purchases',st.purchases_total,'fees',st.fees_total,'total',st.gross_total,'priorPayments',st.prior_payments,'closingPayment',st.closing_payment,'credit',st.credit_after) ELSE '{}'::jsonb END;
END $tg$;
REVOKE ALL ON FUNCTION public.tower_telegram_content_395(uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_telegram_content_395(uuid) TO service_role;


COMMIT;
/*
Tower App V3.9.8 - SQL_280.
___________________________
Code End
*/
