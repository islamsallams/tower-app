// Exact V3.9.5 regression fixture; no real configuration.
async function consumeTelegramEntity395(){
 const url=new URL(location.href),entity=url.searchParams.get('tgEntity'),id=url.searchParams.get('tgId'),unit=url.searchParams.get('tgUnit'),owner=url.searchParams.get('tgOwner');if(!entity&&!id&&!unit&&!owner)return;
 for(const key of ['tgEntity','tgId','tgUnit','tgOwner'])url.searchParams.delete(key);history.replaceState(history.state,'',url.pathname+url.search+url.hash);
 const origin=noticeOrigin340(),uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
 if(!['trip','trip_settlement'].includes(entity)||![id,unit,owner].every(x=>uuid.test(String(x)))||owner!==origin.actor||!['RESIDENT','OPERATOR'].includes(origin.role)){toast('رابط الإشعار غير متاح للحساب الحالي.','warning');return;}
 try{await navigateNotice340({entity,entityId:id,unitId:unit,title:entity==='trip'?'تفاصيل المشوار':'تفاصيل التسوية'},origin);}catch(e){if(pendingOrigin300(origin))showNoticeError350(e,'open',()=>navigateNotice340({entity,entityId:id,unitId:unit},origin));}
}