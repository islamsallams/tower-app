import fs from 'node:fs';import assert from 'node:assert/strict';const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE);const db=new PGlite();let checks=0;const check=async(name,fn)=>{await fn();checks++;console.log('PASS',name)};const id=n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
try{
await db.exec(`CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean);
INSERT INTO tower_users VALUES('${id(1)}','RESIDENT','ACTIVE',false),('${id(2)}','OPERATOR','ACTIVE',false),('${id(3)}','RESIDENT','ACTIVE',false);
CREATE FUNCTION tower_session_user(token text) RETURNS SETOF tower_users LANGUAGE sql AS $$ SELECT * FROM tower_users WHERE user_id=token::uuid $$;
CREATE TABLE tower_members(user_id uuid,unit_id uuid,ended_at timestamptz);INSERT INTO tower_members VALUES('${id(1)}','${id(10)}',NULL);
CREATE TABLE tower_trips(trip_id uuid PRIMARY KEY,unit_id uuid,status text,settlement_id uuid,actor_role text,created_at timestamptz);
CREATE TABLE tower_trip_workflow_288(trip_id uuid PRIMARY KEY,unit_id uuid,stage text,deadline_kind text,deadline_at timestamptz,seen_at timestamptz,seen_by uuid,accepted_at timestamptz,done_at timestamptz,declined_at timestamptz,archived_at timestamptz,archived_by uuid,reason text DEFAULT '',hidden_by_resident boolean DEFAULT false,updated_at timestamptz);
CREATE TABLE tower_trip_workflow_events_288(trip_id uuid,unit_id uuid,actor_id uuid,previous_stage text,new_stage text,reason text);
CREATE FUNCTION tower_trip_expire_288() RETURNS int LANGUAGE sql AS $$ SELECT 0 $$;
CREATE FUNCTION tower_trip_workflow_notify_288(uuid,text,uuid,text,text) RETURNS void LANGUAGE sql AS $$ SELECT $$;
INSERT INTO tower_trips VALUES('${id(20)}','${id(10)}','OPEN',NULL,'RESIDENT','2026-11-14T10:00:00Z');
INSERT INTO tower_trip_workflow_288(trip_id,unit_id,stage,deadline_kind) VALUES('${id(20)}','${id(10)}','REQUESTED','TODAY');`);
const original=fs.readFileSync('SQL_288_TRIP_WORKFLOW_V3.15.0.sql','utf8');await db.exec(original.match(/CREATE OR REPLACE FUNCTION public.tower_trip_deadline_288[\s\S]*?\$fn\$;/)[0]);
await db.exec(fs.readFileSync('SQL_289_TRIP_WORKFLOW_42702_FIX.sql','utf8'));
const act=async(who,action,payload={})=>(await db.query('SELECT tower_trip_workflow_action_288($1,$2,$3) value',[id(who),action,{tripId:id(20),...payload}])).rows[0].value;
await check('actual SQL289 list executes without alias ambiguity and scopes residents',async()=>{assert.equal((await act(1,'list')).length,1);assert.equal((await act(3,'list')).length,0);});
await check('actual SQL289 deadline update uses creation time and open clears deadline',async()=>{await act(1,'setDeadline',{deadline:'DAY'});assert.equal((await db.query('SELECT deadline_at FROM tower_trip_workflow_288')).rows[0].deadline_at.toISOString(),'2026-11-15T10:00:00.000Z');await act(1,'setDeadline',{deadline:'OPEN'});assert.equal((await db.query('SELECT deadline_at FROM tower_trip_workflow_288')).rows[0].deadline_at,null);});
await check('actual SQL289 forbids operator deadline edits and another resident access',async()=>{await assert.rejects(()=>act(2,'setDeadline',{deadline:'WEEK'}),/INVALID_TRIP_STAGE/);await assert.rejects(()=>act(3,'setDeadline',{deadline:'WEEK'}),/FORBIDDEN/);});
await check('view prevents deadline edits; acceptance done and reopen keep existing stages',async()=>{await act(2,'view');await assert.rejects(()=>act(1,'setDeadline',{deadline:'WEEK'}),/INVALID_TRIP_STAGE/);assert.equal((await act(2,'accept')).stage,'ACCEPTED');assert.equal((await act(2,'done')).stage,'DONE');assert.equal((await act(2,'reopen')).stage,'ACCEPTED');});
await check('hidden resident archive excluded by actual list and restore renews request',async()=>{await act(1,'cancel');await act(1,'hide');assert.equal((await act(1,'list')).length,0);assert.equal((await act(2,'list')).length,1);await db.exec('UPDATE tower_trip_workflow_288 SET hidden_by_resident=false');assert.equal((await act(1,'restore')).stage,'REQUESTED');});
fs.mkdirSync('qa/v3.16.0',{recursive:true});fs.writeFileSync('qa/v3.16.0/sql289-compatibility.json',JSON.stringify({checks,passed:checks,scope:'Actual SQL289 function with synthetic fixture and stub expiry/notifications; not full financial or live validation'}));
}finally{await db.close()}
