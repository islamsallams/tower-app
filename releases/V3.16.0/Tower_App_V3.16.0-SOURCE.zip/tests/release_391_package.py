from pathlib import Path
import zipfile,json,hashlib,re
root=Path.cwd();out=root/'releases/V3.9.1';results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
with zipfile.ZipFile(out/'Tower_App_V3.9.1.zip') as runtime,zipfile.ZipFile(out/'Tower_App_V3.9.1-SOURCE.zip') as source:
 check('Updater runtime contains exactly the five required files and both archives pass CRC',set(runtime.namelist())=={'app.js','styles.css','index.html','worker.js','wrangler.toml'} and runtime.testzip() is None and source.testzip() is None)
 check('runtime, full source and root files match exactly',all(runtime.read(n)==source.read(n)==(root/n).read_bytes() for n in runtime.namelist()))
 check('root/public assets agree inside delivered source',all(source.read(n)==source.read('public/'+n) for n in ['app.js','index.html','styles.css']))
 check('complete delivery preserves all baseline source paths',set(zipfile.ZipFile('releases/V3.9.0/Tower_App_V3.9.0-SOURCE.zip').namelist()).issubset(source.namelist()))
 check('source includes building asset, blueprint, combined SQL, native source and human test steps',all(n in source.namelist() for n in ['assets/building/facade-13-floors.webp','assets/building/blueprint.svg','deployment/SQL270_272_V3.9.1.sql','android/TowerAndroid/app/src/main/assets/native.js','USER_ONLINE_TEST_V3.9.1_AR.md']))
 check('no private signing files, real Google configuration, SDK paths or build caches are delivered',not any(n.endswith(('.p12','.jks','.keystore')) or n.split('/')[-1] in ['local.properties','google-services.json','signing.json'] or any(p in n.split('/') for p in ['.git','.aws','.codex','.gradle','build','shared','attachments']) for n in source.namelist()))
 sql=source.read('deployment/SQL270_272_V3.9.1.sql').decode()
 check('delivered SQL matches tested installer and wraps both migrations in one explicit transaction',sql==(out/'SQL270_272_V3.9.1.sql').read_text() and sql.count('\nBEGIN;\n')==1 and sql.count('\nCOMMIT;\n')==1)
 doc=source.read('USER_ONLINE_TEST_V3.9.1_AR.md').decode()
 check('user acceptance table explicitly renders RTL with right-aligned headers and cells','<table dir="rtl">' in doc and doc.count('align="right"')>=30)
meta=json.loads((out/'delivery-checks.json').read_text())
check('published file sizes and SHA256 hashes are accurate',all((out/name).stat().st_size==info['bytes'] and hashlib.sha256((out/name).read_bytes()).hexdigest()==info['sha256'] for name,info in meta['files'].items()))
(root/'qa/v3.9.1/package-results.json').write_text(json.dumps(results,indent=2))
