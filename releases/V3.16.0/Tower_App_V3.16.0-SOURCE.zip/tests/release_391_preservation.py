from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.9.0/Tower_App_V3.9.0-SOURCE.zip');results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 matches=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M))
 return {v[1]:s[v.start():matches[i+1].start() if i+1<len(matches) else len(s)].rstrip() for i,v in enumerate(matches)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text())
reports=[n for n in a if re.search('report|pdf',n,re.I)];trips=[n for n in a if re.search('trip|guard|settlement',n,re.I)]
check('all 86 existing report and PDF app blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('existing trip, guard and settlement app blocks unchanged',all(a[n]==b[n] for n in trips))
check('unit types, collection categories and unit-state policy editors unchanged',all(a[n]==b[n] for n in a if re.search('UnitType|UnitState|CollectionCategor',n)))
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all old SQL unchanged and only reset/monthly-service migrations added',all(z.read(n)==Path(n).read_bytes() for n in old) and new-old=={'sql/STAGING_116_Original_SQL270_OPERATIONAL_RESET.sql','sql/STAGING_117_Original_SQL272_RECURRING_SERVICES.sql'})
check('existing server bindings and five-minute cron schedule preserved',z.read('wrangler.toml')==Path('wrangler.toml').read_bytes())
old_worker=z.read('worker.js').decode();worker=Path('worker.js').read_text()
old_sw=old_worker.split('const PUSH_SW383=')[1].split('// Android transport:')[0];new_sw=worker.split('const PUSH_SW383=')[1].split('// Android transport:')[0]
check('browser push service worker unchanged',old_sw==new_sw)
check('root and public app assets identical',all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','index.html','styles.css']))
Path('qa/v3.9.1').mkdir(exist_ok=True);Path('qa/v3.9.1/preservation-results.json').write_text(json.dumps(results,indent=2))
