from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.9.1/Tower_App_V3.9.1-SOURCE.zip');results=[]
def check(n,ok):
 assert ok,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {x[1]:s[x.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,x in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text())
check('all existing app functions except the account-settings update card are unchanged',all(a[n]==b[n] for n in a if n!='renderSettings'))
check('all existing SQL and database contracts are unchanged and no migration is added',all(z.read(n)==Path(n).read_bytes() for n in z.namelist() if n.startswith('sql/')) and {n for n in z.namelist() if n.startswith('sql/')}=={p.as_posix() for p in Path('sql').glob('*')})
check('Android session storage, notification delivery and API authentication are unchanged',all(z.read('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n)==Path('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n).read_bytes() for n in ['SecureState.java','NativePush.java','TowerMessagingService.java','TowerApi.java']))
check('theme, images, server bindings and root/public assets remain consistent',z.read('styles.css')==Path('styles.css').read_bytes() and z.read('wrangler.toml')==Path('wrangler.toml').read_bytes() and all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.9.2/preservation-results.json').write_text(json.dumps(results,indent=2))
