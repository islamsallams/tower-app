from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.9.2/Tower_App_V3.9.2-SOURCE.zip');results=[]
def check(check,condition):
 assert condition,check
 results.append({'check':check,'status':'PASS'});print('PASS',check)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {x[1]:s[x.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,x in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text())
report=[n for n in a if re.search('report|pdf',n,re.I)];check('existing report/PDF function blocks remain byte-identical',all(a[n]==b[n] for n in report))
trip=[n for n in a if re.search('trip|guard|settlement',n,re.I) and n not in ['renderResidentTrips','renderGuardTripRows','residentTripDateLine','welcomeLoadTrip','welcomeSaveTrip']]
check('existing trip calculations, settlement, editing and authorization function blocks are unchanged',all(a[n]==b[n] for n in trip))
for old,new in [('renderResidentTrips','renderResidentTripCards393'),('renderGuardTripRows','renderGuardTripCards393')]:
 check('original '+old+' cards retained behind presentation wrapper',a[old].replace(old,new,1)==b[new])
check('original restore entry point remains unchanged',b['doRestoreBackup'].split('\n')[0]==a['doRestoreBackup'].split('\n')[0])
check('existing unit type/state and collection category policy blocks unchanged',all(a[n]==b[n] for n in a if re.search('UnitType|UnitState|CollectionCategor',n)))
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all old SQL byte-identical; only standalone SQL273 added',all(z.read(n)==Path(n).read_bytes() for n in old) and new-old=={'sql/STAGING_119_Original_SQL273_OPTIONAL_RESET_AND_WELCOME.sql'})
check('Android auth/session/notification Java unchanged from V3.9.2',all(z.read('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n)==Path('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n).read_bytes() for n in ['SecureState.java','NativePush.java','TowerMessagingService.java','TowerApi.java','NativePolicy.java']))
check('server bindings and schedule unchanged; root/public assets identical',z.read('wrangler.toml')==Path('wrangler.toml').read_bytes() and all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.9.3/preservation-results.json').write_text(json.dumps(results,indent=2))
