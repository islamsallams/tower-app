from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.9.4/Tower_App_V3.9.4-SOURCE.zip');results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return{x[1]:s[x.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,x in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text())
trips=[n for n in a if re.search('trip|guard|settlement',n,re.I)]
check('existing trip calculations, cards, filters, prices, settlement and role projection unchanged',all(a[n]==b[n] for n in trips))
check('task readiness, collection, receipt, installments and refund actions unchanged',all(a[n]==b[n] for n in ['towerTaskFinancialSnapshot','towerTaskReadiness','towerTaskInstallmentProjection','submitTaskCollection','openTaskCollectionForm','taskInlineFundAction','saveTaskControlsInline']))
reports=[n for n in a if re.search('report|pdf',n,re.I) and n not in ['renderReports','openReport','reportDocumentHtml']]
check('existing PDF generation, combined financial grouping and report formatting engines unchanged',all(a[n]==b[n] for n in reports))
check('backup, restore and operational reset function blocks unchanged',all(a[n]==b[n] for n in a if re.search('Restore|Backup|OperationalReset|resetSummary',n)))
check('unit types, states and collection policy editors unchanged',all(a[n]==b[n] for n in a if re.search('UnitType|UnitState|CollectionCategor',n)))
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all prior migrations byte-identical; only SQL276 added',all(z.read(n)==Path(n).read_bytes() for n in old) and new-old=={'sql/STAGING_121_Original_SQL276_FUNDING_AND_TELEGRAM.sql'})
check('Android session, authentication, push delivery and update allowlist unchanged',all(z.read('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n)==Path('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/'+n).read_bytes() for n in ['SecureState.java','TowerApi.java','NativePush.java','TowerMessagingService.java','NativePolicy.java']))
main=Path('android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/MainActivity.java').read_text();body=main[main.index('private void checkForUpdate('):main.index('\n',main.index('private void checkForUpdate('))]
check('Android update detection uses only metadata and never gates an available update on an APK Range request', 'TowerApi.request("/api/android/version",null)' in body and 'Range' not in body and 'openConnection' not in body and 'updateFailure394(e)' in body)
check('server bindings and schedules unchanged; root/public sources identical',z.read('wrangler.toml')==Path('wrangler.toml').read_bytes() and all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.9.5/preservation-results.json').write_text(json.dumps(results,indent=2))
