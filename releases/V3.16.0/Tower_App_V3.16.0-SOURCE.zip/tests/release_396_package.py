from pathlib import Path
import zipfile,json,hashlib
r=Path.cwd();out=r/'releases/V3.9.6';checks=[]
def check(n,ok):
 assert ok,n
 checks.append({'check':n,'status':'PASS'});print('PASS',n)
with zipfile.ZipFile(out/'Tower_App_V3.9.6.zip') as a,zipfile.ZipFile(out/'Tower_App_V3.9.6-SOURCE.zip') as b,zipfile.ZipFile('releases/V3.9.5/Tower_App_V3.9.5-SOURCE.zip') as old:
 check('runtime keeps five-file Updater contract and archives have valid CRC',set(a.namelist())=={'app.js','index.html','styles.css','worker.js','wrangler.toml'} and a.testzip() is None and b.testzip() is None)
 check('source preserves all baseline paths and runtime/root/public files match',set(old.namelist()).issubset(b.namelist()) and all(a.read(n)==b.read(n)==(r/n).read_bytes() for n in a.namelist()) and all(b.read(n)==b.read('public/'+n) for n in ['app.js','index.html','styles.css']))
 check('unified version and canonical APK metadata are in the actual delivery',b"APP_VERSION='3.9.6'" in a.read('app.js') and b"versionName:'3.9.6',versionCode:7" in a.read('worker.js') and b"https://raw.githubusercontent.com/islamsallams/tower-app/main/android-releases/V3.9.6/Tower_Android_V3.9.6.apk" in a.read('worker.js'))
 check('no private signing configuration or real Google configuration in source',not any(n.endswith(('.p12','.jks','.keystore')) or n.split('/')[-1] in ['google-services.json','signing.json','local.properties'] for n in b.namelist()))
 check('all SQL remains byte-identical to prior release',all(b.read(n)==old.read(n) for n in old.namelist() if n.startswith('sql/')))
for folder in [out,r/'android-releases/V3.9.6']:
 meta=json.loads((folder/'delivery-checks.json').read_text());check('hashes match published '+folder.name,all(hashlib.sha256((folder/n).read_bytes()).hexdigest()==info['sha256'] for n,info in meta['files'].items()))
(r/'qa/v3.9.6/package-results.json').write_text(json.dumps(checks,indent=2))
