from pathlib import Path
import zipfile,re,json
r=Path.cwd();results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return{x[1]:s[x.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,x in enumerate(m)}
with zipfile.ZipFile(r/'releases/V3.9.5/Tower_App_V3.9.5-SOURCE.zip') as z:
 old=functions(z.read('app.js').decode());new=functions((r/'app.js').read_text());allowed={'submitLogin','publicError','bootApp','consumeTelegramEntity395'}
 check('all existing application functions outside the four startup/diagnostic blocks remain unchanged',all(old[n]==new[n] for n in old if n not in allowed))
 check('Telegram hook changes only the constructor qualification',old['consumeTelegramEntity395'].replace('new URL(location.href)','new globalThis.URL(location.href)')==new['consumeTelegramEntity395'])
 check('every installed SQL file and stylesheet is byte-identical to395',all(z.read(n)==(r/n).read_bytes() for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')) and z.read('styles.css')==(r/'styles.css').read_bytes())
 check('Android authentication, device bridge, update code and notifications remain byte-identical',all(z.read(n)==(r/n).read_bytes() for n in z.namelist() if n.startswith('android/TowerAndroid/app/src/')))
 check('Worker differs only by version and APK metadata; authentication and Telegram remain unchanged',z.read('worker.js').decode().replace('3.9.5','3.9.6').replace('versionCode:6','versionCode:7')==(r/'worker.js').read_text())
 check('server bindings unchanged and root/public files identical',z.read('wrangler.toml')==(r/'wrangler.toml').read_bytes() and all((r/n).read_bytes()==(r/'public'/n).read_bytes() for n in ['app.js','index.html','styles.css']))
(r/'qa/v3.9.6/preservation-results.json').write_text(json.dumps(results,indent=2))
