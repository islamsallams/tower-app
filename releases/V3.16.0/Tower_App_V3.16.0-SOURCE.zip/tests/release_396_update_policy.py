from pathlib import Path
import tempfile,subprocess,json,os
r=Path.cwd();jdk=Path(os.environ.get('TOWER_JAVA_HOME',Path('/workspace/shared/android-tools/jdk-path.txt').read_text()))
p=r/'android/TowerAndroid/app/src/main/java/com/islamsallams/towerapp/NativePolicy.java';test=r/'android/TowerAndroid/tests/NativeUpdateChecks.java'
with tempfile.TemporaryDirectory(prefix='tower-native-policy-') as tmp:
 subprocess.run([str(jdk/'bin/javac'),'-encoding','UTF-8','-d',tmp,str(p),str(test)],check=True)
 result=subprocess.run([str(jdk/'bin/java'),'-cp',tmp,'com.islamsallams.towerapp.NativeUpdateChecks'],check=True,capture_output=True,text=True)
 checks=[{'check':s[5:],'status':'PASS','runtime':'host JVM; not Android device'} for s in result.stdout.splitlines() if s.startswith('PASS ')]
 assert len(checks)==3;print(result.stdout);(r/'qa/v3.9.6/update-policy-results.json').write_text(json.dumps(checks,indent=2))
