// Actual delegation predicate and receipt RPC in isolated PostgreSQL; no live accounts.
import fs from 'node:fs';import assert from 'node:assert/strict';const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE);const db=new PGlite(),results=[];const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const check=async(name,f)=>{await f();results.push({check:name,status:'PASS'});console.log('PASS',name)};
try{
await db.exec(`CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean);
INSERT INTO tower_users VALUES('${id(1)}','ADMIN','ACTIVE',false),('${id(2)}','UNION','ACTIVE',false),('${id(3)}','RESIDENT','ACTIVE',false),('${id(4)}','OPERATOR','ACTIVE',false),('${id(5)}','RESIDENT','ACTIVE',false);
CREATE FUNCTION tower_session_user(t text) RETURNS SETOF tower_users LANGUAGE sql AS $$SELECT * FROM tower_users WHERE user_id=t::uuid$$;
CREATE TABLE tower_services(service_id uuid PRIMARY KEY,service_kind text,pricing_mode text,status text);INSERT INTO tower_services VALUES('${id(11)}','ONE_TIME','SHARED_TOTAL','ACTIVE');
CREATE TABLE tower_finance_accounts(account_id uuid PRIMARY KEY,service_id uuid,beneficiary_user_id uuid,account_kind text,status text);
INSERT INTO tower_finance_accounts VALUES('${id(21)}','${id(11)}','${id(3)}','PERSONAL_SERVICE','ACTIVE');
CREATE TABLE tower_task_fund_contributions(service_id uuid PRIMARY KEY,amount numeric,fund_entry_id uuid);
INSERT INTO tower_task_fund_contributions VALUES('${id(11)}',200,'${id(31)}');
CREATE TABLE tower_task_fund_receipts(service_id uuid PRIMARY KEY,account_id uuid,amount numeric,confirmed_by uuid,confirmed_at timestamptz DEFAULT now());
CREATE TABLE tower_audit(actor_id uuid,action text,entity text,entity_id text);`);
const base=fs.readFileSync('sql/STAGING_89_Original_SQL236_TASK_RESPONSIBILITY_AND_INSTALLMENTS.sql','utf8');let start=base.indexOf('CREATE OR REPLACE FUNCTION public.tower_task_responsible_236');await db.exec(base.slice(start,base.indexOf('END $f$;',start)+9));await db.exec(fs.readFileSync('sql/STAGING_125_Original_SQL280_TASK_RECEIPT_RECIPIENT.sql','utf8').split('CREATE OR REPLACE FUNCTION public.tower_telegram_content_395')[0]+'COMMIT;');
const act=async(who,a='status')=>(await db.query('SELECT tower_task_fund_receipt_action_217($1,$2,$3) v',[id(who),id(11),a])).rows[0].v;
await check('admin and union can inspect status but cannot confirm on behalf of beneficiary',async()=>{for(const who of [1,2]){assert.equal((await act(who)).canConfirm,false);await assert.rejects(()=>act(who,'confirm'),/TASK_RECEIPT_RECIPIENT_ONLY/)}assert.equal((await db.query('SELECT count(*) n FROM tower_task_fund_receipts')).rows[0].n,0)});
await check('current resident account holder can confirm; unrelated resident cannot read or confirm',async()=>{assert.equal((await act(3)).canConfirm,true);await assert.rejects(()=>act(5),/FORBIDDEN/);await assert.rejects(()=>act(5,'confirm'),/TASK_RECEIPT_RECIPIENT_ONLY/);const out=await act(3,'confirm');assert.equal(out.confirmed,true);assert.equal(Number(out.confirmedAmount),200);const row=(await db.query('SELECT * FROM tower_task_fund_receipts')).rows[0];assert.equal(row.confirmed_by,id(3));assert.equal(row.account_id,id(21));});
await check('repeated confirmation does not duplicate receipt or financial movement',async()=>{assert((await act(3,'confirm')).confirmed);assert.equal((await db.query('SELECT count(*) n FROM tower_task_fund_receipts')).rows[0].n,1);assert.equal((await db.query('SELECT count(*) n FROM tower_audit')).rows[0].n,1);assert.equal((await db.query('SELECT count(*) n FROM tower_task_fund_contributions')).rows[0].n,1)});
await check('reassignment invalidates previous authority and admin role alone never supplies custody',async()=>{await db.query('UPDATE tower_finance_accounts SET beneficiary_user_id=$1 WHERE account_id=$2',[id(4),id(21)]);await assert.rejects(()=>act(3,'confirm'),/TASK_RECEIPT_RECIPIENT_ONLY/);assert.equal((await act(4)).canConfirm,true);await db.query('UPDATE tower_finance_accounts SET beneficiary_user_id=$1 WHERE account_id=$2',[id(1),id(21)]);assert.equal((await act(1)).canConfirm,true);assert.equal((await db.query('SELECT confirmed_by FROM tower_task_fund_receipts')).rows[0].confirmed_by,id(3));});
fs.mkdirSync('qa/v3.9.8',{recursive:true});fs.writeFileSync('qa/v3.9.8/receipt-sql-results.json',JSON.stringify(results,null,2));
}catch(e){console.error(e.message,e.where||'');process.exitCode=1;}finally{await db.close();}
