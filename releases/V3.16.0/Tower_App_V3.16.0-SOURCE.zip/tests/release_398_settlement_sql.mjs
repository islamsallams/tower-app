import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`;
const action=async(kind,p={},unit=10,who=1)=>(await db.query('SELECT tower_trip_settlement_action_244($1,$2,$3) v',[id(who),kind,{...p,unitId:id(unit)}])).rows[0].v;
const trip=async(amount,unit=10)=>{const r=await db.query("INSERT INTO tower_trips(unit_id,purchases_total,distance_fee,extra_fee,total_due,items) VALUES($1,$2,0,0,$2,'[{\"name\":\"fixture item\",\"price\":1}]') RETURNING trip_id",[id(unit),amount]);return r.rows[0].trip_id;};
const pay=async(amount,unit=10)=>(await db.query("INSERT INTO tower_trip_payments(unit_id,amount,source) VALUES($1,$2,'RESIDENT_PAYMENT') RETURNING payment_id",[id(unit),amount])).rows[0].payment_id;
let seq=0;const close=async(p={},unit=10,who=1)=>{const preview=await action('preview',{},unit,who);return action('close',{requestId:'fixture-request-'+(++seq).toString().padStart(5,'0'),expectedRevision:preview.revision,...p},unit,who);};
const fields=async(sid,who=1)=>(await db.query('SELECT tower_trip_settlement_fields_244($1,$2) v',[id(who),[sid]])).rows[0].v;
async function check(name,fn){await fn();results.push({check:name,status:'PASS'});console.log('PASS',name);}
try{
await db.exec(fs.readFileSync('tests/fixtures/trip_settlement_schema_244.sql','utf8'));
// Keep the genuine SQL237 undo branch untouched, and add its known delegate actions for this local fixture.
let old=fs.readFileSync('tests/fixtures/trip_undo_pre238.sql','utf8');old=old.slice(old.indexOf('CREATE FUNCTION tower_trip_account'));
old=old.replace('v_set public.tower_trip_settlements;', 'v_set public.tower_trip_settlements; v_id uuid;');
old=old.replace(" if p_action='undo' then",()=>` if p_action='addPayment' then
 if coalesce(p_payload->>'amount','') !~ '^([0-9]+)(\\.[0-9]{1,2})?$' or (p_payload->>'amount')::numeric<=0 or (p_payload->>'amount')::numeric>100000000 then raise exception 'INVALID_AMOUNT';end if;
 insert into tower_trip_payments(unit_id,amount,source,reference,created_by) values(uid,(p_payload->>'amount')::numeric,'RESIDENT_PAYMENT',coalesce(p_payload->>'reference',''),actor.user_id) returning payment_id into v_id;
 return jsonb_build_object('success',true,'paymentId',v_id);
 elsif p_action='summary' then
 return jsonb_build_object('unitId',uid,'canManageAccount',true,'grossTotal',coalesce((select sum(total_due) from tower_trips where unit_id=uid and status='OPEN'),0),'paymentsTotal',coalesce((select sum(amount) from tower_trip_payments where unit_id=uid and status='OPEN'),0),
 'settlements',coalesce((select jsonb_agg(jsonb_build_object('settlementId',settlement_id,'sequenceNo',sequence_no,'status',status,'priorPayments',prior_payments,'closingPayment',closing_payment,'grossTotal',gross_total,'feesTotal',fees_total,'creditAfter',credit_after) order by sequence_no desc) from (select * from tower_trip_settlements where unit_id=uid order by sequence_no desc limit 30) x),'[]'));
 elsif p_action='details' then
 select * into v_set from tower_trip_settlements where unit_id=uid and settlement_id=(p_payload->>'settlementId')::uuid;if not found then raise exception 'SETTLEMENT_NOT_FOUND';end if;
 return jsonb_build_object('settlement',jsonb_build_object('settlementId',v_set.settlement_id,'status',v_set.status,'grossTotal',v_set.gross_total,'feesTotal',v_set.fees_total,'priorPayments',v_set.prior_payments,'closingPayment',v_set.closing_payment,'creditAfter',v_set.credit_after),'details',coalesce((select jsonb_agg(to_jsonb(x)) from tower_trip_settlement_details x where settlement_id=v_set.settlement_id),'[]'));
 elsif p_action='undo' then`);
await db.exec(old);
await db.exec(`INSERT INTO tower_users(user_id,role,status,name) VALUES('${id(1)}','RESIDENT','ACTIVE','fixture resident'),('${id(2)}','RESIDENT','ACTIVE','fixture member'),('${id(3)}','UNION','ACTIVE','fixture union'),('${id(4)}','OPERATOR','ACTIVE','fixture guard');
INSERT INTO tower_units(unit_id) SELECT (lpad(g::text,8,'0')||'-1111-4111-8111-111111111111')::uuid FROM generate_series(10,30) g;
INSERT INTO tower_members(unit_id,user_id,member_role) SELECT unit_id,'${id(1)}','MANAGER' FROM tower_units;
INSERT INTO tower_members VALUES('${id(10)}','${id(2)}','MEMBER',null);`);
const before=(await db.query("SELECT pg_get_functiondef('tower_trip_account(text,text,jsonb)'::regprocedure) v")).rows[0].v;
const sql=fs.readFileSync('sql/STAGING_96_Original_SQL244_TRIP_SETTLEMENT_PAYMENTS_AND_UNDO.sql','utf8');await db.exec(sql);

await db.exec("ALTER TABLE tower_units ADD COLUMN unit_number text; UPDATE tower_units SET unit_number=split_part(unit_id::text,'-',1)::integer::text");
// Synthetic reproduction of repeated close/undo; no real names, IDs or user rows.
await db.query("INSERT INTO tower_trip_settlements(unit_id,sequence_no,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after) VALUES($1,1,0,0,0,0,0,0)",[id(26)]);
await db.query("INSERT INTO tower_trip_payments(unit_id,amount,source,reference) VALUES($1,225,'SETTLEMENT_CREDIT','fixture-legacy-origin')",[id(26)]);
await db.query("INSERT INTO tower_trips(unit_id,purchases_total,distance_fee,extra_fee,total_due,items) VALUES($1,270,5,0,275,'[]')",[id(26)]);
const historical2=await close({},26);await action('undo',{expectedSettlementId:historical2.settlementId},26);
const independent300=await pay(300,26);
const historical3=await close({additionalFees:'50',paidNow:'200'},26);await action('undo',{expectedSettlementId:historical3.settlementId},26);
const historical4=await close({additionalFees:'1000'},26);await action('undo',{expectedSettlementId:historical4.settlementId},26);
assert.equal((await action('preview',{},26)).paymentsTotal,725);
const historicalSnapshot=JSON.stringify((await db.query('SELECT * FROM tower_trip_settlements WHERE unit_id=$1 ORDER BY sequence_no',[id(26)])).rows);
const migration=fs.readFileSync('sql/STAGING_97_Original_SQL246_TRIP_APPROVAL_CASH_UNDO.sql','utf8');
await db.exec(migration);

await check('historical correction cancels only approval200 and leaves prior225 and independent300',async()=>{
 const p=await action('preview',{},26);assert.equal(p.paymentsTotal,525);assert.equal(p.grossTotal,275);assert.equal(p.creditBalance,250);
 assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[independent300])).rows[0].status,'OPEN');
 const opt=(await db.query('SELECT * FROM tower_trip_settlement_options_244 WHERE settlement_id=$1',[historical3.settlementId])).rows[0];assert(opt.cash_payment_id);
 const cash=(await db.query('SELECT * FROM tower_trip_payments WHERE payment_id=$1',[opt.cash_payment_id])).rows[0];assert.equal(cash.status,'CANCELED');assert.equal(cash.settlement_id,historical3.settlementId);assert.equal(Number(cash.amount),200);
 assert.equal(historicalSnapshot,JSON.stringify((await db.query('SELECT * FROM tower_trip_settlements WHERE unit_id=$1 ORDER BY sequence_no',[id(26)])).rows));
 assert.equal((await db.query("SELECT count(*) n FROM tower_audit WHERE action='REPAIR_SETTLEMENT_CASH_246'")).rows[0].n,1);
});
await check('rerun neither cancels twice nor creates a duplicate audit',async()=>{await db.exec(migration);assert.equal((await action('preview',{},26)).paymentsTotal,525);assert.equal((await db.query("SELECT count(*) n FROM tower_audit WHERE action='REPAIR_SETTLEMENT_CASH_246'")).rows[0].n,1);});
await check('future explicit cash is linked; undo preserves newer trip and advance and removes only linked cash',async()=>{
 await trip(180,22);const prior=await pay(220,22);const s=await close({additionalFees:'10',paidNow:'50'},22);
 const opt=(await db.query('SELECT cash_payment_id FROM tower_trip_settlement_options_244 WHERE settlement_id=$1',[s.settlementId])).rows[0];assert(opt.cash_payment_id);
 const newer=await trip(20,22),advance=await pay(50,22);await action('undo',{expectedSettlementId:s.settlementId},22);
 const p=await action('preview',{},22);assert.equal(p.grossTotal,200);assert.equal(p.paymentsTotal,270);assert.equal(p.creditBalance,70);
 assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[opt.cash_payment_id])).rows[0].status,'CANCELED');
 for(const pid of [prior,advance])assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[pid])).rows[0].status,'OPEN');
 assert.equal((await db.query('SELECT status FROM tower_trips WHERE trip_id=$1',[newer])).rows[0].status,'OPEN');
 assert.equal((await fields(s.settlementId))[0].closingPayment,50);assert.equal((await action('summary',{},22)).settlements[0].status,'CANCELED');
 assert(!(await action('paymentDetails',{paymentId:opt.cash_payment_id},22)).canCancel);
});
await check('explicit covered zero has no cash link and never cancels prior advance',async()=>{await trip(10,23);const p=await pay(20,23),s=await close({paidNow:'0'},23);await action('undo',{expectedSettlementId:s.settlementId},23);assert.equal((await action('preview',{},23)).paymentsTotal,20);assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[p])).rows[0].status,'OPEN');});
await check('implicit cash keeps legacy reversed closing behavior',async()=>{await trip(30,24);const s=await close({},24);await action('undo',{expectedSettlementId:s.settlementId},24);assert.equal((await action('preview',{},24)).paymentsTotal,0);assert.equal((await db.query("SELECT status FROM tower_trip_payments WHERE unit_id=$1 AND source='SETTLEMENT_CLOSING'",[id(24)])).rows[0].status,'REVERSED');});
await check('active pre246 explicit settlement without stored link resolves from original snapshot and request',async()=>{
 // Remove the new link to model an active SQL244-created settlement; snapshot/request are genuine.
 await trip(10,25);await pay(5,25);const s=await close({paidNow:'20'},25);
 await db.query('UPDATE tower_trip_settlement_options_244 SET cash_payment_id=NULL WHERE settlement_id=$1',[s.settlementId]);
 await action('undo',{expectedSettlementId:s.settlementId},25);assert.equal((await action('preview',{},25)).paymentsTotal,5);
});
await check('ambiguous historical candidates stop undo atomically instead of guessing',async()=>{
 await trip(10,27);const s=await close({paidNow:'20'},27);const cash=(await db.query('SELECT cash_payment_id FROM tower_trip_settlement_options_244 WHERE settlement_id=$1',[s.settlementId])).rows[0].cash_payment_id;
 await db.query('UPDATE tower_trip_settlement_options_244 SET cash_payment_id=NULL WHERE settlement_id=$1',[s.settlementId]);
 const duplicate=(await db.query("INSERT INTO tower_trip_payments(unit_id,amount,source,reference,created_by,created_at,status,settlement_id) SELECT unit_id,amount,source,reference,created_by,created_at,status,settlement_id FROM tower_trip_payments WHERE payment_id=$1 RETURNING payment_id",[cash])).rows[0].payment_id;
 await db.query("INSERT INTO tower_trip_settlement_details(settlement_id,unit_id,detail_type,entity_id,amount,snapshot) SELECT settlement_id,unit_id,'PAYMENT',$2::uuid,amount,jsonb_set(snapshot,'{paymentId}',to_jsonb(($2::uuid)::text)) FROM tower_trip_settlement_details WHERE settlement_id=$1 AND entity_id=$3",[s.settlementId,duplicate,cash]);
 await assert.rejects(()=>action('undo',{expectedSettlementId:s.settlementId},27),/SETTLEMENT_PAYMENT_LINK_UNCLEAR/);
 assert.equal((await action('summary',{},27)).settlements[0].status,'ACTIVE');assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[cash])).rows[0].status,'APPLIED');
});
await check('partial payment belongs to account and survives a later unrelated settlement undo',async()=>{
 await trip(180,28);const partial=await close({paidNow:'100',additionalFees:'10'},28);assert(partial.paymentOnly);
 const s=await close({paidNow:'100'},28);await action('undo',{expectedSettlementId:s.settlementId},28);
 assert.equal((await action('preview',{},28)).paymentsTotal,100);assert.equal((await db.query('SELECT status FROM tower_trip_payments WHERE payment_id=$1',[partial.paymentId])).rows[0].status,'OPEN');
});
await check('late undo failure rolls back linked cash cancellation and every other effect',async()=>{
 await trip(10,29);const s=await close({paidNow:'20'},29);await db.exec(`CREATE FUNCTION fail194() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN IF NEW.unit_id='${id(29)}' AND NEW.status='CANCELED' THEN RAISE EXCEPTION 'LATE194';END IF;RETURN NEW;END$$;CREATE TRIGGER fail194 BEFORE UPDATE ON tower_trip_settlements FOR EACH ROW EXECUTE FUNCTION fail194();`);
 await assert.rejects(()=>action('undo',{expectedSettlementId:s.settlementId},29),/LATE194/);
 assert.equal((await action('summary',{},29)).settlements[0].status,'ACTIVE');assert.equal((await db.query("SELECT status FROM tower_trip_payments WHERE unit_id=$1 AND source='RESIDENT_PAYMENT'",[id(29)])).rows[0].status,'APPLIED');
});
await check('internal resolver is not exposed even to service role; authenticated wrapper permissions preserved',async()=>{
 for(const role of ['anon','authenticated','service_role'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_trip_settlement_cash_246(uuid,uuid)','EXECUTE') v",[role])).rows[0].v,false);
 assert.equal((await db.query("SELECT has_function_privilege('service_role','tower_trip_settlement_action_244(text,text,jsonb)','EXECUTE') v")).rows[0].v,true);
 assert.equal((await db.query("SELECT pg_get_functiondef('tower_trip_account(text,text,jsonb)'::regprocedure) v")).rows[0].v,before);
});
await check('changed historical cash used by active settlement blocks entire migration without touching another unit',async()=>{
 await db.query("UPDATE tower_trip_payments SET status='OPEN',settlement_id=NULL,reversal_reason='' WHERE payment_id=(SELECT cash_payment_id FROM tower_trip_settlement_options_244 WHERE settlement_id=$1)",[historical3.settlementId]);
 const active=await close({},26);const snapshot=JSON.stringify((await db.query('SELECT to_jsonb(p) v FROM tower_trip_payments p ORDER BY payment_id')).rows);
 await assert.rejects(()=>db.exec(migration),/دفعة 200 جنيه مستخدمة/);await db.exec('ROLLBACK');
 assert.equal(snapshot,JSON.stringify((await db.query('SELECT to_jsonb(p) v FROM tower_trip_payments p ORDER BY payment_id')).rows));assert.equal((await action('summary',{},26)).settlements[0].status,'ACTIVE');
 await action('undo',{expectedSettlementId:active.settlementId},26);await db.exec(migration);assert.equal((await action('preview',{},26)).paymentsTotal,525);
});
await check('missing proof rejects historical correction and rolls back schema and function changes',async()=>{
 const opt=(await db.query('SELECT cash_payment_id FROM tower_trip_settlement_options_244 WHERE settlement_id=$1',[historical3.settlementId])).rows[0];
 await db.query("UPDATE tower_trip_payments SET status='OPEN',settlement_id=NULL,reversal_reason='' WHERE payment_id=$1",[opt.cash_payment_id]);
 await db.query("UPDATE tower_trip_close_requests_244 SET payload=payload-'paidNow' WHERE result->>'settlementId'=$1",[historical3.settlementId]);
 const snapshot=JSON.stringify((await db.query('SELECT to_jsonb(p) v FROM tower_trip_payments p ORDER BY payment_id')).rows);
 await assert.rejects(()=>db.exec(migration),/SETTLEMENT_PAYMENT_LINK_UNCLEAR/);await db.exec('ROLLBACK');assert.equal(snapshot,JSON.stringify((await db.query('SELECT to_jsonb(p) v FROM tower_trip_payments p ORDER BY payment_id')).rows));
});

await db.exec(fs.readFileSync('sql/STAGING_124_Original_SQL279_PRICED_SETTLEMENTS.sql','utf8'));
await check('zero is priced but null, missing and empty prices require a choice',async()=>{for(const [items,expected] of [[[{name:'zero',price:0}],false],[[{name:'missing',price:null}],true],[[{name:'missing'}],true],[[{name:'empty',price:''}],true]])assert.equal((await db.query('SELECT tower_trip_unpriced_279($1) v',[items])).rows[0].v,expected);});
await check('missing-price trips cannot be settled by old or direct clients',async()=>{const t=await trip(55,10);await db.query('UPDATE tower_trips SET items=$1 WHERE trip_id=$2',[[{name:'not priced',price:null}],t]);const p=await action('preview');assert.equal(p.unpricedTripCount,1);await assert.rejects(()=>action('close',{requestId:'missing-direct-001',expectedRevision:p.revision}),/UNPRICED_TRIPS_REQUIRE_CHOICE/);assert.equal((await db.query('SELECT status FROM tower_trips WHERE trip_id=$1',[t])).rows[0].status,'OPEN');});
await check('exclusion leaves the complete missing trip including its fees open; credit, retry and undo remain sound',async()=>{const a=await trip(40,22),b=await trip(25,22);await db.query('UPDATE tower_trips SET items=$1,distance_fee=10,total_due=35 WHERE trip_id=$2',[[{name:'missing',price:null}],b]);const p=await action('preview',{excludeUnpriced:true},22);assert(p.unpricedTripCount>0);const request={requestId:'exclude-request-001',expectedRevision:p.revision,excludeUnpriced:true,additionalFees:'0',paidNow:'0'};const out=await action('close',request,22);assert.equal((await db.query('SELECT status FROM tower_trips WHERE trip_id=$1',[b])).rows[0].status,'OPEN');assert.equal((await db.query('SELECT status FROM tower_trips WHERE trip_id=$1',[a])).rows[0].status,'SETTLED');assert.equal((await action('close',request,22)).settlementId,out.settlementId);assert.equal((await action('preview',{},22)).unpricedTripCount,p.unpricedTripCount);await action('undo',{expectedSettlementId:out.settlementId},22);assert.equal((await db.query('SELECT status FROM tower_trips WHERE trip_id=$1',[b])).rows[0].status,'OPEN');});
await check('an edit to an excluded trip invalidates the review; no rows are written',async()=>{const p=await action('preview',{excludeUnpriced:true},22);await db.query("UPDATE tower_trips SET notes='new price review' WHERE unit_id=$1 AND status='OPEN'",[id(22)]);await assert.rejects(()=>action('close',{requestId:'exclude-changed-001',expectedRevision:p.revision,excludeUnpriced:true},22),/SETTLEMENT_CHANGED_REFRESH/);});
await check('all missing cannot close an empty settlement and invalid selection is rejected',async()=>{const p=await action('preview',{excludeUnpriced:true});assert.equal(p.openTripCount,0);await assert.rejects(()=>action('close',{requestId:'empty-exclusion-001',expectedRevision:p.revision,excludeUnpriced:true}),/NO_PRICED_TRIPS/);await assert.rejects(()=>action('preview',{excludeUnpriced:'true'}),/INVALID_OPERATION/);});
fs.mkdirSync('qa/v3.9.8',{recursive:true});fs.writeFileSync('qa/v3.9.8/settlement-sql-results.json',JSON.stringify(results,null,2));console.log(`${results.length} SQL tests PASS`);
}catch(e){console.error('SQL398 FAILURE',e.message,e.detail||'',e.where||'');process.exitCode=1;}finally{await db.close();}
