// V3.9.9: server verified no-op must never reach the trip mutation RPC.
import assert from 'node:assert/strict';
import worker from '../worker.js';
const tripId='11111111-1111-4111-8111-111111111111';
async function runCase({role='OPERATOR',name='updateGuardTrip',payload,original}){
 const previous=globalThis.fetch,calls=[];
 globalThis.fetch=async(url,opts)=>{
  const rpc=new URL(url).pathname.split('/').pop();
  const body=JSON.parse(opts.body||'{}');calls.push({rpc,body});
  if(rpc==='tower_session_user')return Response.json([{user_id:'22222222-2222-4222-8222-222222222222',role,must_change_pin:false}]);
  if(rpc==='tower_guard_trip_context')return Response.json({trips:[original]});
  if(rpc==='tower_trip_action'){
   if(body.p_action==='list')return Response.json([original]);
   return Response.json({updated:true});
  }
  throw Error('unexpected '+rpc);
 };
 try {
  const res=await worker.fetch(new Request('https://tower.test/api/tower',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'apiCall',args:[{name,args:[payload],token:'fixture'}]})}),{SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'fixture'});
  return {body:await res.json(),calls};
 } finally {globalThis.fetch=previous;}
}
const original={tripId,items:[{name:'مياه',price:15},{name:'ملح',price:null}],distance:'NEAR',notes:'ملاحظة'};
let r=await runCase({payload:{tripId,items:[{name:' مياه ',price:'15.00'},{name:'ملح',price:''}]},original});
assert(r.body.ok,JSON.stringify(r.body));assert.equal(r.body.result.unchanged,true);assert.equal(r.calls.some(x=>x.rpc==='tower_trip_action'&&x.body.p_action==='update'),false);
console.log('PASS guard unchanged save does not invoke mutation');
r=await runCase({payload:{tripId,items:[{name:'مياه',price:'16'},{name:'ملح',price:''}]},original});
assert(r.body.ok,JSON.stringify(r.body));assert.equal(r.calls.filter(x=>x.rpc==='tower_trip_action'&&x.body.p_action==='update').length,1);
console.log('PASS guard changed items preserve existing mutation route');
r=await runCase({role:'RESIDENT',name:'updateMyTrip',payload:{tripId,items:[{name:'مياه',price:15},{name:'ملح',price:''}],distance:'NEAR',notes:'ملاحظة'},original});
assert(r.body.ok,JSON.stringify(r.body));assert.equal(r.body.result.unchanged,true);assert.equal(r.calls.filter(x=>x.rpc==='tower_trip_action'&&x.body.p_action==='update').length,0);
console.log('PASS resident unchanged save does not invoke mutation');
r=await runCase({role:'RESIDENT',name:'updateMyTrip',payload:{tripId,items:[{name:'مياه',price:15},{name:'ملح',price:''}],distance:'FAR',notes:'ملاحظة'},original});
assert(r.body.ok,JSON.stringify(r.body));assert.equal(r.calls.filter(x=>x.rpc==='tower_trip_action'&&x.body.p_action==='update').length,1);
console.log('PASS resident changed distance retains mutation route');
