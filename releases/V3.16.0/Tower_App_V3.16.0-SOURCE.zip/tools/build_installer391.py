from pathlib import Path
root=Path(__file__).resolve().parents[1]
parts=[]
for name in ['STAGING_116_Original_SQL270_OPERATIONAL_RESET.sql','STAGING_117_Original_SQL272_RECURRING_SERVICES.sql']:
    text=(root/'sql'/name).read_text()
    assert text.count('\nBEGIN;\n')==1 and text.count('\nCOMMIT;\n')==1
    parts.append(text.replace('\nBEGIN;\n','\n',1).replace("\nNOTIFY pgrst,'reload schema';\nCOMMIT;\n",'\n',1))
text='/*\nTower App V3.9.1 - SQL_272.\n___________________________\nCombined SQL270 and SQL272 installation in one transaction. No reset or billing runs on installation.\n*/\nBEGIN;\n'+'\n'.join(parts)+"\nNOTIFY pgrst,'reload schema';\nCOMMIT;\n/*\n___________________________\nTower App V3.9.1 - SQL_272.\nCode End\n*/\n"
for folder in ['deployment','releases/V3.9.1']:
    path=root/folder;path.mkdir(parents=True,exist_ok=True);(path/'SQL270_272_V3.9.1.sql').write_text(text)
