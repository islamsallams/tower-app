"""Fast local release gate: no browser, production database, deployment, or real notifications."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess, os, json, time, sys
root=Path(__file__).resolve().parents[1]
cases=[('syntax-app',['node','--check','app.js']),('syntax-worker',['node','--check','worker.js']),('funding-telegram-sql',['node','tests/release_395_sql.mjs']),('dialogs-title-model',['node','tests/release_395_ui_model.mjs']),('worker-telegram-errors',['node','tests/release_395_worker.mjs']),('core-preservation',['python3','tests/release_395_preservation.py']),('settlement-cash-undo',['node','tests/settlement_246_sql.mjs']),('recurring-services',['node','tests/release_391_services_sql.mjs']),('optional-operational-reset',['node','tests/release_393_reset_sql.mjs'])]
out=root/'qa/v3.9.5';out.mkdir(parents=True,exist_ok=True)
def run(case):
 name,cmd=case;start=time.monotonic();p=subprocess.run(cmd,cwd=root,env=os.environ.copy(),capture_output=True,text=True,timeout=180)
 # Private raw logs remain outside distributable SOURCE.
 log=Path(os.environ.get('TOWER_TEST_LOG_DIR','/tmp/tower-395-checks'));log.mkdir(parents=True,exist_ok=True);(log/(name+'.log')).write_text(p.stdout+p.stderr)
 return {'check':name,'status':'PASS' if p.returncode==0 else 'FAIL','seconds':round(time.monotonic()-start,2),'exitCode':p.returncode}
with ThreadPoolExecutor(max_workers=4) as pool:
 results=[]
 for f in as_completed([pool.submit(run,c) for c in cases]):
  item=f.result();results.append(item);print(item['status'],item['check'],item['seconds'],flush=True)
(out/'release-gate-results.json').write_text(json.dumps(results,indent=2))
sys.exit(0 if all(x['status']=='PASS' for x in results) else 1)
