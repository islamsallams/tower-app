"""Targeted parallel regression gate. No browser, deployment, live SQL or real messages."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,os,json,time,sys
root=Path(__file__).resolve().parents[1];out=root/'qa/v3.9.8';out.mkdir(parents=True,exist_ok=True)
cases=[('syntax-app',['node','--check','app.js']),('syntax-worker',['node','--check','worker.js']),('updater-config-startup',['node','tests/release_398_startup.mjs']),('workspace-wizard-prayer-model',['node','tests/release_398_models.mjs']),('worker-permissions-telegram',['node','tests/release_398_worker.mjs']),('source-function-preservation',['node','tests/release_398_preservation.mjs']),('receipt-recipient-sql',['node','tests/release_398_receipt_sql.mjs']),('prayer-admin-sql',['node','tests/release_397_prayers_sql.mjs']),('funding-and-telegram-sql',['node','tests/release_398_finance_sql.mjs']),('settlement-cash-undo',['node','tests/release_398_settlement_sql.mjs']),('recurring-services',['node','tests/release_391_services_sql.mjs']),('optional-operational-reset',['node','tests/release_393_reset_sql.mjs'])]
def run(case):
 name,cmd=case;start=time.monotonic();p=subprocess.run(cmd,cwd=root,env=os.environ.copy(),capture_output=True,text=True,timeout=180);log=Path(os.environ.get('TOWER_TEST_LOG_DIR','/tmp/tower-398-checks'));log.mkdir(parents=True,exist_ok=True);(log/(name+'.log')).write_text(p.stdout+p.stderr)
 return {'check':name,'status':'PASS' if p.returncode==0 else 'FAIL','seconds':round(time.monotonic()-start,2),'exitCode':p.returncode}
for key,relative in [('TOWER_PGLITE_MODULE','@electric-sql/pglite/dist/index.js'),('TOWER_DOM_MODULE','linkedom/esm/index.js'),('TOWER_ACORN_MODULE','acorn/dist/acorn.mjs')]:
 if not os.environ.get(key):os.environ[key]=str(root/'tools/regression/node_modules'/relative)
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(run,c) for c in cases]):
  item=future.result();results.append(item);print(item['status'],item['check'],item['seconds'],flush=True)
(out/'release-gate-results.json').write_text(json.dumps(results,indent=2));sys.exit(0 if all(x['status']=='PASS' for x in results) else 1)
