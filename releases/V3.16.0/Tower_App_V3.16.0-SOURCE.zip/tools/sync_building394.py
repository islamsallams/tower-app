"""Sync the canonical facade mask JSON to runtime copies and its editable SVG diagram.
No image pixels are changed. Run after editing assets/building/layout394.json.
"""
from pathlib import Path
import json,re,base64
root=Path(__file__).resolve().parents[1]
layout=json.loads((root/'assets/building/layout394.json').read_text())
assert layout['width']==937 and layout['height']==1678 and len(layout['slots'])==42
assert {s['floor'] for s in layout['slots'].values()}==set(range(14))
raw=json.dumps(layout,ensure_ascii=False,separators=(',',':'))
p=root/'app.js';s=p.read_text();s,n=re.subn(r'const BUILDING_LAYOUT394=.*?;(?=\nfunction buildingSlotOptions394)',lambda m:'const BUILDING_LAYOUT394='+raw+';',s,flags=re.S);assert n==1;p.write_text(s)
p=root/'worker.js';s=p.read_text()
for kind in ['on','off']:
 data=base64.b64encode((root/f'assets/building/facade-13-floors-{kind}394.webp').read_bytes()).decode()
 s,n=re.subn(r"const BUILDING_"+kind.upper()+r"394='[^']*';",lambda m:"const BUILDING_"+kind.upper()+"394='"+data+"';",s);assert n==1
s,n=re.subn(r'const BUILDING_MAP394=.*?;(?=\nconst BUILDING_OFF393)',lambda m:'const BUILDING_MAP394='+raw+';',s,flags=re.S);assert n==1;p.write_text(s)
backdrop=base64.b64encode((root/'assets/building/facade-13-floors-off394.webp').read_bytes()).decode()
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 937 1678" data-layout-version="3.9.4">','<rect width="937" height="1678" fill="#101820"/><image href="data:image/webp;base64,'+backdrop+'" width="937" height="1678"/>']
for key,slot in layout['slots'].items():
 svg.append(f'<g id="{key}" fill="#3f8cff" fill-opacity=".2" stroke="#64c8ff" stroke-width="2">')
 for rect in slot['rects']:svg.append('<rect '+' '.join(f'{k}="{v}"' for k,v in rect.items())+'/>')
 svg.append('</g>');rect=slot['rects'][0];svg.append(f'<text x="{rect["x"]+5}" y="{rect["y"]+18}" fill="white" font-family="Arial" font-size="16">{key}</text>')
for floor in range(13,0,-1):
 y=min(p['y'] for slot in layout['slots'].values() if slot['floor']==floor for p in slot['rects'])+30
 svg.append(f'<text id="floor_{floor}" x="20" y="{y}" fill="white" font-family="Arial" font-size="24">F{floor}</text>')
svg.append('<text x="10" y="1475" fill="white" font-family="Arial" font-size="24">G0</text></svg>')
(root/'assets/building/blueprint394.svg').write_text('\n'.join(svg))
(root/'public/app.js').write_bytes((root/'app.js').read_bytes())
print('Synced 13 residential floors, 38 apartments, 4 shops and a fixed entrance.')
