"""Render the existing page chime as PCM WAV. No audio playback or device test."""
from pathlib import Path
import ast,math,re,struct,wave,json,hashlib
root=Path(__file__).resolve().parent
source=(root/'app.js').read_text();line=next(x for x in source.splitlines() if x.startswith('function playNoticeTone350()'))
notes=ast.literal_eval(re.search(r'for\(const \[offset,freq\] of (\[\[.*?\]\])\)',line)[1]);partials=ast.literal_eval(re.search(r'for\(const \[ratio,level,decay\] of (\[\[.*?\]\])\)',line)[1]);master=float(re.search(r'master.gain.setValueAtTime\(([0-9.]+),at\)',line)[1]);assert 'start+.008' in line and 'start+decay+.03' in line
rate=48000;duration=max(offset+decay+.03 for offset,_ in notes for _,_,decay in partials)+.05;pcm=[];peak=0
for i in range(round(rate*duration)):
 t=i/rate;value=0
 for offset,freq in notes:
  tau=t-offset
  for ratio,level,decay in partials:
   if tau<0 or tau>=decay+.03:continue
   gain=.0001*(level/.0001)**(tau/.008) if tau<.008 else level*(.0001/level)**min(1,(tau-.008)/(decay-.008))
   value+=gain*math.sin(2*math.pi*freq*ratio*tau)
 value*=master;peak=max(peak,abs(value));assert abs(value)<1
 pcm.append(round(value*32767))
path=root/'assets/audio/Tower_Notification_Ding_Dong.wav';path.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(path),'wb') as output:
 output.setnchannels(1);output.setsampwidth(2);output.setframerate(rate);output.writeframes(struct.pack('<'+'h'*len(pcm),*pcm))
checks=[{'check':'exported WAV follows current page-chime frequencies, envelopes and master gain without clipping','status':'PASS','rate':rate,'channels':1,'bits':16,'seconds':len(pcm)/rate,'peak':peak,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'playedOrDeviceTested':False}]
qa=root/'qa/v3.8.7';qa.mkdir(parents=True,exist_ok=True);(qa/'audio-results.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks))
