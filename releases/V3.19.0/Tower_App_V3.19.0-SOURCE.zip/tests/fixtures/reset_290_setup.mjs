// Synthetic baseline fixture reused from release_393_reset_sql; no live credentials.
export async function setup(db){const admin='00000000-0000-4000-8000-000000000001',resident='00000000-0000-4000-8000-000000000002',staff='00000000-0000-4000-8000-000000000003';
await db.exec(`CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean);INSERT INTO tower_users VALUES('${admin}','ADMIN','ACTIVE',false),('${resident}','RESIDENT','ACTIVE',false),('${staff}','OPERATOR','ACTIVE',false);
CREATE FUNCTION tower_session_user(p text) RETURNS SETOF tower_users LANGUAGE sql AS $$ SELECT * FROM tower_users WHERE user_id=p::uuid $$;
CREATE TABLE tower_units(unit_id int PRIMARY KEY);INSERT INTO tower_units VALUES(1),(2);
CREATE TABLE tower_members(id int PRIMARY KEY,user_id uuid REFERENCES tower_users,unit_id int REFERENCES tower_units);INSERT INTO tower_members VALUES(1,'${resident}',1),(2,'${admin}',2);
CREATE TABLE tower_sessions(id int PRIMARY KEY,user_id uuid REFERENCES tower_users);INSERT INTO tower_sessions VALUES(1,'${resident}'),(2,'${admin}'),(3,'${staff}');
CREATE TABLE tower_services(service_id int PRIMARY KEY,pricing_mode text,enrollment_status text,updated_at timestamptz,status text DEFAULT 'ACTIVE');INSERT INTO tower_services(service_id,pricing_mode,enrollment_status,updated_at) VALUES(1,'SHARED_TOTAL','FINALIZED',now()),(2,'PER_SUBSCRIPTION','OPEN',now());
CREATE TABLE tower_task_projects(service_id int PRIMARY KEY REFERENCES tower_services,phase text,version bigint);INSERT INTO tower_task_projects VALUES(1,'EXECUTION',2);
CREATE TABLE tower_task_workflow(service_id int PRIMARY KEY REFERENCES tower_services,stage text,execution_percent int,revision bigint);INSERT INTO tower_task_workflow VALUES(1,'EXECUTION',70,2);
CREATE TABLE tower_finance_accounts(account_id int PRIMARY KEY,service_id int REFERENCES tower_services,beneficiary_user_id uuid REFERENCES tower_users);INSERT INTO tower_finance_accounts VALUES(1,2,'${resident}');
CREATE TABLE tower_service_subscriptions(subscription_id int PRIMARY KEY,service_id int REFERENCES tower_services);INSERT INTO tower_service_subscriptions VALUES(1,2);
CREATE TABLE tower_service_change_requests(request_id int PRIMARY KEY,subscription_id int REFERENCES tower_service_subscriptions);INSERT INTO tower_service_change_requests VALUES(1,1);
CREATE TABLE tower_building_charges(charge_id int PRIMARY KEY,subscription_id int REFERENCES tower_service_subscriptions,amount int);INSERT INTO tower_building_charges VALUES(1,1,100);
CREATE TABLE tower_audit(actor_id uuid REFERENCES tower_users,action text,entity text,entity_id text);INSERT INTO tower_audit VALUES('${resident}','fixture','fixture','1');
CREATE TABLE tower_welcome_progress(user_id uuid,completed_at timestamptz,step int,updated_at timestamptz);
CREATE FUNCTION tower_backup_fingerprint_263() RETURNS text LANGUAGE sql AS $$SELECT 'fixture-schema'$$;
CREATE FUNCTION tower_welcome_action(p text,a text,j jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$BEGIN INSERT INTO tower_welcome_progress VALUES(p::uuid,now(),4,now());RETURN '{}';END$$;
CREATE FUNCTION tower_change_pin(p text,o text,n text) RETURNS boolean LANGUAGE plpgsql AS $$BEGIN IF o<>'1234' THEN RAISE EXCEPTION 'BAD_PIN';END IF;RETURN true;END$$;`);
}
