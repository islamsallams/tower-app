from pathlib import Path
import json,os,tempfile,subprocess,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
root=Path(os.environ.get('TOWER_SOURCE_ROOT',Path(__file__).resolve().parents[1]));visual=Path(tempfile.mkdtemp(prefix='tower-visual319-'));env={**os.environ,'TOWER_SOURCE_ROOT':str(root),'TOWER_VISUAL_DIR':str(visual)};subprocess.run(['node',str(root/'tests/release_319_browser_fixture.mjs')],check=True,env=env);server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(SimpleHTTPRequestHandler,directory=str(visual)));threading.Thread(target=server.serve_forever,daemon=True).start();base='http://127.0.0.1:'+str(server.server_port)+'/';out=root/'qa/v3.19.0/screens';out.mkdir(parents=True,exist_ok=True)
checks=[];errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('TOWER_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(permissions=['clipboard-read','clipboard-write'])
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/*',lambda route:route.continue_() if route.request.url.startswith(base) else route.abort())
 for width,label in [(960,'desktop'),(390,'mobile'),(320,'narrow')]:
  page.set_viewport_size({'width':width,'height':900})
  for theme in ['light','dark']:
   page.goto(base,wait_until='networkidle')
   page.evaluate('(theme)=>document.documentElement.dataset.theme=theme',theme)
   for surface in ['guard','resident','reset-ready','reset-blocked']:
    page.evaluate('(surface)=>showFixture(surface)',surface)
    page.wait_for_timeout(60)
    overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not overflow,(label,theme,surface,'body overflow')
    if surface in ['guard','resident']:
     bad=page.locator('.trip-card318').evaluate_all('(nodes)=>nodes.some(n=>n.scrollWidth>n.clientWidth+1)')
     assert not bad,(label,theme,surface,'card overflow')
     page.screenshot(path=str(out/f'{label}-{theme}-{surface}.png'),full_page=True)
    else:
     next=page.locator('#resetReviewNext290');assert next.is_disabled()==(surface=='reset-blocked')
     if surface=='reset-ready':
      next.click();assert page.locator('#resetStepConfirm290').is_visible();assert page.locator('#resetExecute').is_disabled()
      page.screenshot(path=str(out/f'{label}-{theme}-reset-confirm.png'))
     else:
      page.locator('details.reset-technical311>summary').click()
      page.locator('button:has-text("نسخ التفاصيل")').click()
      copied=page.evaluate('navigator.clipboard.readText()');assert 'tower_trip_workflow_events_288' in copied;assert 'fixture-proof' not in copied
      page.locator('.needs-review318').last.scroll_into_view_if_needed()
      page.screenshot(path=str(out/f'{label}-{theme}-reset-blocked.png'))
    checks.append({'viewport':label,'theme':theme,'surface':surface,'overflow':False,'status':'PASS'})
    if surface=='guard':
     for tab in ['بانتظار التسوية','السجل']:
      page.locator('.guard-board315 .trip-tabs315 button').filter(has_text=tab).click()
      assert not page.locator('.trip-card318').evaluate_all('(nodes)=>nodes.some(n=>n.scrollWidth>n.clientWidth+1)')
      suffix='done' if tab=='بانتظار التسوية' else 'archive'
      page.screenshot(path=str(out/f'{label}-{theme}-guard-{suffix}.png'),full_page=True)
      checks.append({'viewport':label,'theme':theme,'surface':'guard-'+suffix,'status':'PASS'})
    elif surface=='resident':
     page.locator('.resident-board316 .trip-tabs315 button').filter(has_text='السجل').click()
     assert not page.locator('.trip-card318').evaluate_all('(nodes)=>nodes.some(n=>n.scrollWidth>n.clientWidth+1)')
     page.screenshot(path=str(out/f'{label}-{theme}-resident-archive.png'),full_page=True)
     checks.append({'viewport':label,'theme':theme,'surface':'resident-archive','status':'PASS'})
    elif surface=='reset-ready':
     page.evaluate('resetBack311();resetBack311()')
     page.screenshot(path=str(out/f'{label}-{theme}-reset-options.png'))
     page.locator('#reset-info-deleteServices button').click()
     tip=page.locator('#reset-info-text-deleteServices')
     assert tip.is_visible()
     rect=tip.bounding_box();assert rect['x']>=-1 and rect['x']+rect['width']<=width+1,('tooltip overflow',label,theme,rect)
     checks.append({'viewport':label,'theme':theme,'surface':'reset-choice-help','status':'PASS'})

 # Verify the rejected-clipboard path renders a real manual fallback, not a success toast.
 page.set_viewport_size({'width':390,'height':900});page.evaluate("showFixture('reset-blocked')");page.wait_for_timeout(60);page.locator('details.reset-technical311>summary').click()
 page.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw Error('fixture denied')}}});document.execCommand=()=>false")
 page.locator('button:has-text("نسخ التفاصيل")').click();assert page.locator('#resetCopyManual318').is_visible();assert 'tower_trip_workflow_288' in page.locator('#resetCopyText318').input_value();assert page.evaluate('window.lastToast')!='تم نسخ تفاصيل المعاينة.'
 page.locator('#resetCopyManual318').scroll_into_view_if_needed();page.screenshot(path=str(out/'mobile-dark-copy-fallback.png'))
 checks.append({'scenario':'clipboard rejected; visible manual fallback','status':'PASS'})
 # An increased text scale must still reflow instead of clipping controls.
 page.evaluate("showFixture('resident');document.documentElement.style.setProperty('--fs-body','18px');document.documentElement.style.setProperty('--fs-helper','15px');document.documentElement.style.setProperty('--fs-label','20px')")
 assert not page.evaluate('document.documentElement.scrollWidth>innerWidth');checks.append({'scenario':'increased text size reflow','status':'PASS'})
 browser.close()
assert not errors,errors
(root/'qa/v3.19.0').mkdir(parents=True,exist_ok=True)
(root/'qa/v3.19.0/browser.json').write_text(json.dumps({'checks':checks,'pageErrors':errors,'scope':'Real component renderers and CSS in headless Chromium with synthetic data; not a live account, Safari or iPhone test'},indent=2))
print('PASS',len(checks),'browser scenarios; no overflow or page errors; screenshots:',out)

server.shutdown()
