from pathlib import Path
import json,os,tempfile,subprocess,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];visual=Path(tempfile.mkdtemp(prefix='tower319-new-'));subprocess.run(['node',str(root/'tests/release_319_browser_fixture.mjs')],check=True,env={**os.environ,'TOWER_VISUAL_DIR':str(visual)});server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(SimpleHTTPRequestHandler,directory=str(visual)));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}/';out=root/'qa/v3.19.0/screens';out.mkdir(parents=True,exist_ok=True);checks=[];errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);context=browser.new_context();page=context.new_page();page.route('**/*',lambda r:r.continue_() if r.request.url.startswith(base) else r.abort());page.on('pageerror',lambda e:errors.append(str(e)))
 for width,label in [(960,'desktop'),(390,'mobile'),(320,'narrow')]:
  page.set_viewport_size({'width':width,'height':900})
  for theme in ['light','dark']:
   page.goto(base,wait_until='networkidle');page.evaluate('(v)=>document.documentElement.dataset.theme=v',theme)
   page.evaluate("showFixture('missing')");page.wait_for_selector('.trip-price-required319');assert page.locator('.trip-price-required319').count()==1;assert page.locator('#guardEditRows [data-price]').nth(0).input_value()=='50';assert page.locator('.trip-price-required319 [data-price]').input_value()==''
   assert not page.evaluate('document.documentElement.scrollWidth>innerWidth');page.screenshot(path=str(out/f'{label}-{theme}-missing.png'))
   missing=page.locator('.trip-price-required319 [data-price]');missing.fill('0');assert page.locator('.trip-price-required319').count()==0;assert 'احفظ' in page.locator('#tripPriceReview319').inner_text();checks.append({'viewport':label,'theme':theme,'scenario':'missing price focus, outline and explicit zero removes highlight','status':'PASS'})
   page.evaluate("showFixture('reset-ready')");page.wait_for_selector('.reset-audience319');page.locator('.reset-audience319 summary').click();assert page.locator('.reset-audience319 li').count()==4;assert 'غير مرتبط بتليجرام' in page.locator('.reset-audience319').inner_text();page.locator('.reset-audience319').scroll_into_view_if_needed();page.screenshot(path=str(out/f'{label}-{theme}-recipients.png'));assert not page.evaluate('document.documentElement.scrollWidth>innerWidth');checks.append({'viewport':label,'theme':theme,'scenario':'recipient counts and exclusion reasons','status':'PASS'})
   page.evaluate("showFixture('report-status')");page.wait_for_selector('.reset-deliveries319');assert 'نتيجة غير مؤكدة' in page.locator('.reset-deliveries319').inner_text();page.screenshot(path=str(out/f'{label}-{theme}-delivery-status.png'));checks.append({'viewport':label,'theme':theme,'scenario':'per-account confirmed, failed and uncertain status','status':'PASS'})
 page.emulate_media(reduced_motion='reduce');page.evaluate("showFixture('missing')");page.wait_for_selector('.trip-price-required319');assert page.locator('.trip-price-required319').evaluate('(el)=>getComputedStyle(el).animationName')=='none';checks.append({'scenario':'reduced motion disables pulse','status':'PASS'})
 browser.close()
assert not errors,errors
(root/'qa/v3.19.0/browser-new.json').write_text(json.dumps({'checks':checks,'pageErrors':errors},indent=2));server.shutdown();print('PASS',len(checks),'new flow browser checks')
