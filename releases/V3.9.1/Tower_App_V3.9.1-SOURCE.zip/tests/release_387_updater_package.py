from pathlib import Path
import ast,os,re,json,zipfile,tempfile,shutil,types
r=Path.cwd();p=Path(os.environ.get('TOWER_UPDATER_SOURCE','../updater-v2.3.1/Tower Supabase Updater/updater.py'));tree=ast.parse(p.read_text(encoding='utf-8-sig'))
selected=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef) and n.name in ['normalize_version','semver_tuple','inspect_zip']:selected.append(n)
 if isinstance(n,ast.ClassDef) and n.name=='App':
  for m in n.body:
   if isinstance(m,ast.FunctionDef) and m.name=='_prepare_cloudflare_assets':selected.append(m)
ns={'Path':Path,'re':re,'json':json,'os':os,'zipfile':zipfile,'tempfile':tempfile,'shutil':shutil}
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(p),'exec'),ns)
z=r/'releases/V3.8.7/Tower_App_V3.8.7.zip';info=ns['inspect_zip'](z);assert info['version']=='V3.8.7' or info['version']=='3.8.7'
fake=types.SimpleNamespace(selected_zip=z,worker_name_var=types.SimpleNamespace(get=lambda:'fixture-local-check'),_sync_public_supabase_config=lambda _:None)
root,version,copied=ns['_prepare_cloudflare_assets'](fake);checks=[]
def check(name,condition):
 assert condition,name;checks.append({'check':name,'status':'PASS'})
check('release inspection accepts root-only package',not info['root_parts'] and len(info['members'])==5)
check('generated public assets exactly match root sources',all((root/'public'/n).read_bytes()==(r/n).read_bytes() for n in ['app.js','index.html','styles.css']))
check('worker backend retained exactly',(root/'worker.js').read_bytes()==(r/'worker.js').read_bytes())
check('backend never exposed as public asset',not(root/'public'/'worker.js').exists())
cfg=json.loads((root/'wrangler.jsonc').read_text())
check('assets binding and API routing preserved',cfg['main']=='./worker.js' and cfg['assets']['binding']=='ASSETS' and cfg['assets']['run_worker_first'])
check('cron and existing variables preserved',cfg['keep_vars'] and cfg['triggers']['crons']==re.findall(r'"([^"]+)"',re.search(r'crons\s*=\s*\[([^]]*)\]',(r/'wrangler.toml').read_text()).group(1)))
check('all three startup assets generated',set(copied)=={'app.js','index.html','styles.css'})
(r/'qa/v3.8.7/updater-package-results.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks));shutil.rmtree(root)
