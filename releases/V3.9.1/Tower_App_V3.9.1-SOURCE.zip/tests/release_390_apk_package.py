from pathlib import Path
import os,subprocess,re,zipfile,json,xml.etree.ElementTree as ET
r=Path.cwd();tools=Path(os.environ.get('TOWER_ANDROID_TOOLS','/workspace/shared/android-tools'));apk=r/'android-releases/V1.0.0/Tower_Android_V1.0.0.apk';results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
env=dict(os.environ);env['JAVA_HOME']=(tools/'jdk-path.txt').read_text()
sig=subprocess.check_output([str(tools/'sdk/build-tools/35.0.0/apksigner'),'verify','--verbose','--print-certs',str(apk)],env=env,text=True)
check('actual release APK signature verifies with one signer and Android v2 signing','Verifies' in sig and 'v2): true' in sig and 'Number of signers: 1' in sig)
badging=subprocess.check_output([str(tools/'sdk/build-tools/35.0.0/aapt'),'dump','badging',str(apk)],text=True)
check('actual APK package/version/minimum/target match published initial app',"name='com.islamsallams.towerapp' versionCode='1' versionName='1.0.0'" in badging and "sdkVersion:'26'" in badging and "targetSdkVersion:'35'" in badging)
permissions=set(re.findall("uses-permission: name='([^']+)'",badging));allowed={'android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.POST_NOTIFICATIONS','android.permission.WAKE_LOCK','com.google.android.c2dm.permission.RECEIVE','com.islamsallams.towerapp.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION'}
check('APK has only expected network/notification permissions; no broad storage, contacts, SMS, location, camera or install permission',permissions<=allowed)
with zipfile.ZipFile(apk) as z:
 names=z.namelist();check('APK includes executable code, manifest, native bridge and notification sound',all(n in names for n in ['classes.dex','AndroidManifest.xml','assets/native.js']) and any(n.endswith('.wav') for n in names))
 check('packaged notification sound exactly matches existing page-tone export',any(z.read(n)==(r/'assets/audio/Tower_Notification_Ding_Dong.wav').read_bytes() for n in names if n.endswith('.wav')) and ':raw/tower_chime' in subprocess.check_output([str(tools/'sdk/build-tools/35.0.0/aapt'),'dump','resources',str(apk)],text=True))
 check('APK includes no server/private signing configuration files',not any(n.lower().endswith(('.p12','.jks','.keystore')) or n.split('/')[-1] in ['google-services.json','signing.json','local.properties'] for n in names))
lint=ET.parse(r/'android/TowerAndroid/app/build/reports/lint-results-release.xml').getroot();issues=[i for i in lint.findall('issue') if i.get('severity') in ['Error','Fatal','Warning']]
check('Android static lint completes with zero errors and zero warnings',len(issues)==0)
module=r/'android/TowerAndroid'
with zipfile.ZipFile(r/'android-releases/V1.0.0/Tower_Android_V1.0.0-SOURCE.zip') as z:
 check('published Android source matches current project and excludes build caches, SDK paths and private keys',all(z.read(n)==(module/n.removeprefix('TowerAndroid/')).read_bytes() for n in z.namelist()) and not any(any(p in n.split('/') for p in ['build','.gradle']) or n.endswith(('local.properties','.p12','.jks','.keystore')) for n in z.namelist()))
check('published APK exactly matches compiled release output',apk.read_bytes()==(module/'app/build/outputs/apk/release/app-release.apk').read_bytes())
(r/'qa/v3.9.0/apk-results.json').write_text(json.dumps(results,indent=2))
