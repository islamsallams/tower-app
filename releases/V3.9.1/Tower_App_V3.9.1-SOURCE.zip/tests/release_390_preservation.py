from pathlib import Path
import zipfile,re,json
r=Path.cwd();z=zipfile.ZipFile('releases/V3.8.7/Tower_App_V3.8.7-SOURCE.zip');results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v[1]:s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)];trips=[n for n in a if re.search('trip|guard|settlement',n,re.I)]
check('all 86 report/PDF app blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('all existing trip/guard/settlement blocks unchanged',all(a[n]==b[n] for n in trips))
check('only native card/status delegation added to existing app functions',all(a[n]==b[n] for n in a if n not in {'pushCardBody383','loadPushStatus383'}))
old=z.read('worker.js').decode();current=Path('worker.js').read_text();a,b=functions(old),functions(current)
allowed={'towerPdfFrequencyDue','enrichTaskProjects','dispatch','processPush383','shouldDrainPush383','recordReceipt'}
check('Worker existing business functions unchanged outside native integration and version boundaries',all(a[n]==b[n] for n in a if n not in allowed) and a['towerPdfFrequencyDue'].replace('3.8.7','3.9.0')==b['towerPdfFrequencyDue'])
dispatch=b['dispatch'];start=dispatch.index("  if(inner.name==='android390'){");end=dispatch.index("  if(inner.name==='push383'){",start)
check('all old role permissions and dispatch branches unchanged after removing native-only branch',dispatch[:start]+dispatch[end:]==a['dispatch'])
check('Web Push send function changes only explicit claim budget to four',a['processPush383'].replace("p_action:'claim',p_payload:{}","p_action:'claim',p_payload:{limit:4}")==b['processPush383'])
old_sw=old.split('const PUSH_SW383=')[1].split('\nexport default')[0].strip();new_sw=current.split('const PUSH_SW383=')[1].split('// Android transport:')[0].strip()
check('browser Service Worker and sound behavior unchanged',old_sw==new_sw)
old_sql={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new_sql={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all 34 old SQL files unchanged; SQL269 only new production SQL',len(old_sql)==34 and all(z.read(n)==Path(n).read_bytes() for n in old_sql) and new_sql-old_sql=={'sql/STAGING_115_Original_SQL269_ANDROID_NOTIFICATIONS.sql'})
check('CSS, bindings and cron unchanged; root/public assets identical',all(z.read(n)==Path(n).read_bytes() for n in ['styles.css','wrangler.toml']) and all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','index.html','styles.css']))
Path('qa/v3.9.0/preservation-results.json').write_text(json.dumps(results,indent=2))
