// Tower App V3.9.1 - SQL_272.
// ___________________________
function towerPdfFrequencyDue(frequency,year,month,day,monthlyDay=1){
 const mode=String(frequency||'MONTHLY').toUpperCase();
 if(mode==='DAILY')return true;
 if(mode==='MONTHLY'){
  const requested=Number(monthlyDay);
  if(!Number.isInteger(requested)||requested<1||requested>31)return false;
  const lastDay=new Date(Date.UTC(Number(year),Number(month),0)).getUTCDate();
  return Number(day)===Math.min(requested,lastDay);
 }
 if(mode==='WEEKLY')return new Date(Date.UTC(Number(year),Number(month)-1,Number(day))).getUTCDay()===0;
 return false;
}
const APP_VERSION='3.9.1';
// MIGRATION CATALOG: generated from supabase/*.sql; update via tools_build_migration_catalog.py, not by editing diagnostics.
const MIGRATION_CATALOG=[{"id":138,"filename":"138_pdf_claim_safe_release.sql"},{"id":139,"filename":"139_migration_registry.sql"},{"id":140,"filename":"140_operational_reset_test_pdf_jobs.sql"},{"id":141,"filename":"141_resident_trip_unpriced_items.sql"},{"id":142,"filename":"142_guard_open_trip_history.sql"}];
// Tower App clean Worker foundation. All sensitive Supabase requests originate server-side.
const JSON_HEADERS={'content-type':'application/json; charset=utf-8','cache-control':'no-store'};
function respond(body,status=200){return new Response(JSON.stringify(body),{status,headers:JSON_HEADERS});}
function fail(message,status=400,extra={}){return respond({error:message,...extra},status);}
async function db(env,path,{method='GET',body}={}){
  const root=String(env.SUPABASE_URL||'').replace(/\/+$/,'');
  const key=env.SUPABASE_SERVICE_ROLE_KEY;
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(root)||!key)throw Error('SUPABASE_SERVER_ENV_MISSING');
  const response=await fetch(root+'/rest/v1/'+path,{method,headers:{apikey:key,Authorization:'Bearer '+key,'content-type':'application/json',Accept:'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json().catch(()=>null);
  if(!response.ok){
    // Diagnostics never log request bodies, auth headers, session tokens or PINs.
    const rawCode=typeof data?.code==='string'?data.code:'';
    const code=/^[A-Z0-9]{4,8}$/.test(rawCode)?rawCode:'UNKNOWN';
    const resource=String(path).split('?')[0];
    const diagnostic={resource,httpStatus:response.status,dbCode:code};
    // A PostgreSQL 42883 can mean a missing RPC *or* an unresolved call inside an existing function.
    // Log only bounded, allowlisted SQL identifiers/signatures, never raw DB message/detail/hint.
    if(code==='42883'&&resource==='rpc/tower_service_shared_allocation_action'){
      const msg=String(data?.message||'');
      const m=/\b(function|procedure|operator)\s+([a-zA-Z_][a-zA-Z0-9_.]*(?:\s*\([^()\\'";\r\n]{0,200}\))?)\s+does not exist\b/i.exec(msg);
      if(m)diagnostic.missingSignature=(m[1]+' '+m[2]).slice(0,220);
      // Supabase PostgREST returns PGRST202 when its RPC signature is absent from schema cache.
      diagnostic.errorSource=msg.includes('schema cache')?'schema-cache':m?'postgres-function-resolution':'unknown';
    }
    console.error('SUPABASE_REQUEST_ERROR',JSON.stringify(diagnostic));
    const err=new Error(safeDbMessage(data,code));err.dbCode=code;err.httpStatus=response.status;throw err;
  }
  return data;
}
async function enrichTaskProjects(env,services,unitId=null){
 const tasks=(services||[]).filter(x=>x.serviceKind==='ONE_TIME'&&x.pricingMode==='SHARED_TOTAL');
 if(!tasks.length)return;
 try{
  const byId=new Map();
  for(let i=0;i<tasks.length;i+=80){
   const ids=tasks.slice(i,i+80).map(x=>String(x.serviceId)).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
   if(!ids.length)continue;
   const rows=await db(env,'tower_task_projects?select=service_id,phase,scope_text,deadline,distribution,target_units,agreed_amounts&service_id=in.('+ids.join(',')+')');
   if(!Array.isArray(rows))throw Error('INVALID_TASK_PROJECTS');
   for(const row of rows)byId.set(String(row.service_id),row);
  }
  for(const task of tasks){const p=byId.get(String(task.serviceId));if(p)task.project={phase:p.phase,scope:p.scope_text,deadline:p.deadline,distribution:p.distribution,eligible:!unitId||!p.target_units?.length||p.target_units.includes(unitId),...(!unitId?{agreedAmounts:p.agreed_amounts||[]}:{} )};}
 }catch(e){for(const task of tasks)task.taskProjectUnavailable=true;console.warn('TASK_PROJECTS_UNAVAILABLE');}
}
const DB_USER_ERRORS={
 INVALID_ANDROID_DEVICE:'بيانات التطبيق غير صالحة. أعد تفعيل إشعاراته.',
 INVALID_ANDROID_TOKEN:'تعذر تسجيل إشعارات التطبيق. جرّب التفعيل من جديد.',
 ANDROID_DEVICE_IN_USE:'بيانات الجهاز لا تطابق الاشتراك السابق.',
 ANDROID_SETUP_REQUIRED:'إشعارات التطبيق تحتاج تجهيز الخدمة المجانية أولًا.',
 PUSH_DEVICE_LIMIT:'الحد الأقصى 10 أجهزة للحساب؛ أوقف جهازًا قديمًا قبل إضافة آخر.',
 PUSH_DEVICE_IN_USE:'اشتراك الجهاز مرتبط بحساب آخر. أعد إنشاء الاشتراك من نفس المتصفح.',
 PUSH_SETUP_REQUIRED:'إشعارات الجهاز تحتاج تثبيت SQL266 بواسطة الأدمن.',
 INVALID_PUSH_SUBSCRIPTION:'بيانات اشتراك الجهاز غير صالحة. أعد تفعيل الإشعارات.',
 PUSH_DEVICE_REQUIRED:'فعّل إشعارات هذا الجهاز أولًا.',
 PUSH_TEST_COOLDOWN:'انتظر دقيقة قبل تجربة إشعار آخر.',
 RESTORE_PLAN_EXPIRED:'انتهت صلاحية المراجعة. افتح الملف وراجعه مرة أخرى.',
 RESTORE_DATA_CHANGED:'البيانات تغيّرت بعد المراجعة. راجع الملف من جديد وخد نسخة أمان حديثة.',
 RESTORE_FILE_CHANGED:'ملف الاستعادة مختلف عن الملف الذي تمت مراجعته. ابدأ مراجعة جديدة.',
 RESTORE_CONFIRMATION_REQUIRED:'نزّل نسخة الأمان وأكد حفظها واكتب كلمة استعادة.',
 RESTORE_ADMIN_MISSING:'حساب الأدمن الحالي غير موجود في النسخة. اختر نسخة تحتوي حسابك.',
 RESTORE_EXTERNAL_DEPENDENCY:'توجد علاقات من جداول خارج نطاق التطبيق. لم تتغير البيانات؛ تحتاج مراجعة تقنية.',
 RESTORE_UNSUPPORTED_SCHEMA:'بنية القاعدة تحتاج مراجعة تقنية قبل الاستعادة. لم تتغير البيانات.',
 RESTORE_UNSUPPORTED_SEQUENCE:'ترقيم أحد الجداول غير مدعوم للاستعادة. لم تتغير البيانات.',
 RESTORE_ROW_MISMATCH:'بعض قيم الملف لا تطابق نوعها أو القيم المحسوبة في القاعدة. لم تتغير البيانات.',
 RESTORE_PREVIEW_CHANGED_STATE:'تعذر تثبيت مراجعة الاستعادة. لم تُنفذ الاستعادة.',
 BACKUP_TOO_LARGE:'حجم النسخة أكبر من الحد المدعوم للتنزيل المحلي؛ لم تُنشأ نسخة جزئية.',
 UNIT_EXEMPT_NEW_DUE:'الوحدة معفاة من هذا الاستحقاق الجديد. راجع المشاركين والتوزيع؛ لم تُحفظ العملية.',
 UNIT_STATE_IN_USE:'الحالة مستخدمة في وحدات؛ غيّر حالتها أولًا قبل الحذف.',
 INVALID_UNIT_STATE:'راجع اسم الحالة واللون وقيم الإعفاء.',
 UNIT_STATE_NOT_FOUND:'الحالة غير موجودة؛ حدّث قائمة الحالات.',
 BUILTIN_OR_MISSING_STATE:'الحالة الأساسية لا يمكن حذفها، أو الحالة لم تعد موجودة.',
 INVALID_PERSON_NAME:'اكتب الاسم الأول وباقي الاسم بإجمالي لا يزيد عن 80 حرفًا.',
 DATA_EXECUTION_REQUIRES_REVIEWED_SCOPE:'التنفيذ متوقف لحين اعتماد النطاق وتجربة الاستعادة.',
 BACKUP_SCHEMA_OR_VERSION_MISMATCH:'نسخة البيانات تخص إصدارًا أو بنية مختلفة؛ لم تُنفذ أي استعادة.',
 BACKUP_TABLE_SET_MISMATCH:'جداول ملف النسخة لا تطابق قاعدة البيانات الحالية.',
 INVALID_BACKUP_COLUMNS:'أعمدة ملف النسخة لا تطابق قاعدة البيانات الحالية.',
 CURRENT_RELEASE_ARCHIVE_UNAVAILABLE:'ملف تشغيل الإصدار الحالي غير متاح للتنزيل الآن.',

 ACCOUNT_INACTIVE:'الحساب غير نشط حاليًا. تواصل مع الإدارة لتفعيل الحساب.',INVALID_BRAND_FOCUS:'موضع الصورة يجب أن يكون بين 0 و100.',SETTLEMENT_PAYMENT_LINK_UNCLEAR:'تعذر تحديد دفعة اعتماد التسوية بأمان؛ لم يتم التراجع أو تغيير الحساب. انسخ التفاصيل للمراجعة.',SETTLEMENT_PAYMENT_CHANGED:'حالة دفعة اعتماد التسوية تغيرت؛ حدّث الحساب وراجع تفاصيلها قبل التراجع.',SETTLEMENT_REFERENCE_REQUIRED:'افتح شاشة التسوية من جديد قبل الحفظ.',SETTLEMENT_REQUEST_CHANGED:'المحاولة دي اتسجلت ببيانات مختلفة؛ راجع الحساب قبل محاولة جديدة.',INVALID_SETTLEMENT_AMOUNT:'راجع المدفوع والأتعاب الإضافية: من صفر إلى 100 مليون جنيه وبحد أقصى رقمين بعد العلامة العشرية.',PAYMENT_NOT_FOUND:'الدفعة غير موجودة ضمن حساب الوحدة.',INVALID_UNIT_DUES_SUMMARY:'تعذر التحقق من إجمالي مستحقات الوحدة. حاول تحديث الحساب.',INVALID_TRIP_ALERT:'حد التنبيه لازم يكون مبلغ صحيح موجب أو عدد أيام من 1 إلى 3650. امسح القيمة لإيقاف التنبيه.',AUDIT_NOT_FOUND:'العملية غير موجودة في سجل النشاط.',INVALID_ACTIVITY_FILTER:'راجع البحث والفلاتر وتاريخ البداية والنهاية.',INVALID_REPORT_METADATA:'تعذر تحميل بيانات الوحدات والخدمات للتقرير.',CHARGE_ALREADY_CANCELED:'الاستحقاق اتلغى بالفعل؛ حدّث القائمة.',CHARGE_MANAGE_FROM_SERVICE:'عدّل أو ألغِ الاستحقاق من الخدمة أو المهمة المرتبطة به.',CHARGE_CHANGED_REFRESH:'الاستحقاق أو المدفوعات اتغيرت. اقفل التفاصيل وافتحها تاني قبل التعديل.',CHARGE_AMOUNT_BELOW_PAID:'نصيب الوحدة لا يمكن أن يقل عن المبلغ المدفوع منها.',INVALID_CHARGE_DETAILS:'راجع اسم الاستحقاق والتاريخ والملاحظات.',INVALID_CHARGE_ALLOCATION:'راجع مبالغ الوحدات؛ كل وحدة تظهر مرة واحدة.',INVALID_CHARGE_FILTER:'راجع البحث وحالة الاستحقاق.',CHARGE_REFERENCE_REQUIRED:'افتح نموذج استحقاق جديد وحاول مرة أخرى.',CHARGE_REFERENCE_CONFLICT:'المحاولة دي اتسجلت ببيانات مختلفة. راجع الاستحقاقات قبل إنشاء واحد جديد.',CHARGE_CREATE_NOT_CONFIRMED:'تعذر تأكيد إنشاء الاستحقاق. أعد المحاولة بنفس البيانات.',INVALID_TASK_DEADLINE:"موعد الاشتراك لازم يكون تاريخ صحيح من النهارده أو بعده.",INVALID_FUND_FILTER:"راجع البحث والفترة الزمنية المطلوبة.",UNIT_ACCOUNT_ACCESS_DENIED:"حساب الوحدة متاح لمديرها فقط؛ المشاوير ومالية العمارة العامة متاحين كالمعتاد.",LATER_ACCOUNT_ACTIVITY:"في مشاوير جديدة اتسجلت بعد التسوية؛ لا يمكن التراجع عنها مع وجود النشاط ده.",INVALID_FUND_CONTRIBUTION:"مساهمة الصندوق لازم تكون صفر أو مبلغ موجب بدقة قرشين.",TASK_WORKFLOW_CHANGED_REFRESH:"إعدادات المهمة اتغيرت؛ افتح المهمة تاني وراجع القيم قبل الحفظ.",INSTALLMENT_SETUP_CHANGED:"موعد أول قسط اتغير مع بداية الشهر؛ افتح مراجعة الأقساط تاني.",INSTALLMENT_PLAN_ALREADY_INSTALLED:"جدول الأقساط مثبت بالفعل؛ حدّث الأقساط لعرضه.",INSTALLMENTS_REQUIRE_UNPAID_DUES:"السداد بدأ بالفعل؛ لا يمكن تثبيت جدول أقساط جديد على المستحقات دي.",INSTALLMENTS_EXCEED_AMOUNT_CENTS:"عدد الأقساط أكبر من المبلغ القابل للتقسيم؛ قلّل عدد الأقساط.",INSTALLMENT_START_DATE_REQUIRED:"تاريخ أول قسط غير متاح؛ حدّث التطبيق لاستخدام الموعد التلقائي.",NO_APPROVED_DUES:"مفيش مستحقات معتمدة محتاجة جدول أقساط.",EXECUTION_DATE_REQUIRED:"حدد موعد التنفيذ للشرط اللي اخترته.",INVALID_TASK_CONTROLS:"راجع إعدادات المهمة؛ النسب وعدد الأقساط لازم تكون أعداد صحيحة.",SQL234_REQUIRED:"شغّل SQL234 ثم SQL235 قبل استخدام الإعدادات الجديدة.",INVALID_TASK_REQUEST:'راجع نوع الطلب وسببه والمبلغ المقترح.',INVALID_RELATION:'اختار صلة القرابة أو اكتبها في أخرى، بحد أقصى80 حرف.',MEMBERSHIP_CHANGED_REFRESH:'صلة القرابة اتغيرت بعد فتح التعديل؛ حدّث بيانات الوحدة وافتح التعديل تاني.',TRANSFER_NOT_COMPLETED:'نقل الإدارة لم يكتمل، ولم يتم حفظ أي جزء من العملية.',INVALID_COLLECTION_BATCH:'راجع بنود التحصيل؛ الحد الأقصى100 بند وكل مبلغ لازم يكون موجبًا وبدقة قرشين.',COLLECTION_BATCH_REFERENCE_CONFLICT:'مراجعة التحصيل اتغيرت؛ حدّث نتيجة العملية السابقة قبل تسجيل عملية جديدة.',COLLECTION_BATCH_DEPENDENCY_REQUIRED:'شغّل ملف تحديث التحصيل المطلوب أولًا.',TASK_START_DATE_NOT_REACHED:'موعد بدء التنفيذ لسه ماجاش؛ راجع تاريخ التنفيذ قبل تغيير المرحلة.',TASK_START_COLLECTION_NOT_REACHED:'التحصيل أقل من المطلوب لبدء التنفيذ؛ راجع النسبة أو المبلغ المحدد.',USE_TASK_WORKSPACE:'افتح المهمة من نافذة إدارة المهمات.',ALLOCATION_CHANGED_REFRESH:'المشتركون أو الأنصبة اتغيروا بعد المعاينة؛ افتح المعاينة وراجعها من جديد.',EDIT_REASON_REQUIRED:'اكتب سبب التعديل المالي قبل الحفظ.',COLLECTION_EXCEEDS_REMAINING:'المبلغ أكبر من المتبقي الحالي؛ حدّث المستحقات وراجع المبلغ.',
 CUSTOM_ZERO_BASE_REQUIRES_NEW_AGREEMENT:'أنصبة الاتفاق الأصلي كلها صفر؛ الزيادة تحتاج اتفاق أنصبة جديد بدل افتراض توزيع من عندنا.',PENDING_DONATION_RETURN:'لسه فيه رد تبرع محتاج تأكيد استلام أو إلغاء قبل قفل الحساب.',UNIQUE_CURRENT_UNIT_MANAGER_REQUIRED:'لازم يبقى فيه مدير واحد نشط للوحدة لتحديد مستلم الرد.',FUND_CONTRIBUTION_RECEIPT_PENDING:'مساهمة الصندوق مسجلة لكن استلامها في حساب المهمة لسه محتاج تأكيد.',UNION_CANCELLATION_REASON_REQUIRED:'سجّل سبب الإلغاء والاتفاق قبل إقفال حساب المهمة.',
 ONLY_RECORDED_HOLDER_CAN_CONFIRM_EXPENSE:'اللي سجل دفع المصروف من عهدته هو اللي يؤكد خروجه منها.',
 UNIT_OUTSIDE_TASK_SCOPE:'الوحدة دي مش ضمن نطاق المهمة المحدد.',EXISTING_PARTICIPANT_OUTSIDE_SCOPE:'فيه مشاركون خارج النطاق الجديد. راجع القائمة قبل تعديل النطاق.',TASK_PARTICIPATION_DEADLINE_PASSED:'موعد تأكيد المشاركة انتهى؛ الإدارة تراجع تمديد المهلة.',ONLY_DRAFT_CAN_BE_CANCELLED:'الإلغاء ده متاح للمسودات فقط؛ السجلات المعتمدة محفوظة.',UNSETTLED_ADVANCES:'لسه فيه مقدمات غير مستخدمة محتاجة تسوية قبل قفل الحساب.',
"TASK_NOT_OPEN_FOR_PARTICIPATION":"المهمة لم تفتح للمشاركة أو اتقفلت.","TASK_CHANGED_REFRESH":"بيانات المهمة اتغيرت. افتحها تاني قبل الحفظ.","TASK_CLOSED":"المهمة ملغاة أو حسابها مقفول.","TASK_TERMS_REQUIRED":"اكتب نطاق الشغل وشروط المشاركة الأول.","VALID_DEADLINE_REQUIRED":"حدد آخر موعد صحيح لتأكيد المشاركة.","TERMS_LOCKED":"الشروط اتثبتت بعد قفل الاشتراك.","ALLOCATION_SUM_MISMATCH":"مجموع أنصبة الوحدات لازم يساوي صافي تكلفة المهمة.","PARTICIPANTS_CHANGED":"قائمة المشاركين اتغيرت. راجع مبالغ الوحدات.","DEDICATED_TASK_ACCOUNT_REQUIRED":"العملية دي محتاجة حساب مهمة مستقل؛ الحسابات القديمة لا تتحول تلقائيًا.","CREDIT_EXCEEDS_APPROVED_DUES":"التخفيض أكبر من المستحق المعتمد المتبقي بعد التسويات.","INSUFFICIENT_HOLDER_BALANCE":"المبلغ أكبر من العهدة المتاحة عندك في حساب المهمة.","REFERENCE_CONFLICT":"مرجع العملية مستخدم ببيانات مختلفة.","UNSETTLED_UNIT_BALANCES":"لسه فيه مستحقات أو مبالغ واجبة الرد للسكان.","UNSETTLED_EXPENSES":"لسه فيه مصروفات أو مطالبات ما اتسوتش.","UNSETTLED_CUSTODY":"لسه فيه عهدة محتاجة تسوية قبل قفل الحساب.","EXECUTION_NOT_COMPLETED":"استلم الشغل وسجّل اكتمال التنفيذ الأول.","SETTLE_AUTHORIZED_REFUNDS_FIRST":"سوّي طلبات رد المبالغ المعتمدة قبل أي تسوية تكلفة جديدة.","TASK_NOT_ACCEPTING_FINANCIAL_POSTS":"المهمة لا تستقبل قيودًا مالية في حالتها الحالية.","REFUND_UNAVAILABLE_OR_ALREADY_AUTHORIZED":"مفيش مبلغ متاح للرد أو فيه اعتماد رد قائم بالفعل.","UNIT_ACCESS_DENIED":"حسابك مش مرتبط بعضوية نشطة في الوحدة المطلوبة.",

 INVALID_DIGEST_TIME:'اختَر موعدًا صحيحًا بفواصل 5 دقائق.',DIGEST_SCHEDULE_NOT_INSTALLED:'إعداد موعد الملخص غير مثبت. نفّذ ملف SQL 104 أولًا.',
 INVALID_IMAGE:'تعذر حفظ الصورة. استخدم JPG أو PNG أو WebP بحجم مناسب.',UNIT_MEMBERSHIP_REQUIRED:'حسابك غير مرتبط بعضوية نشطة في وحدة.',
 SESSION_REQUIRED:'انتهت جلسة الدخول. سجّل الدخول مرة أخرى.',PIN_CHANGE_REQUIRED:'يجب تغيير الرقم السري أولًا.',
 FORBIDDEN:'ليس لديك صلاحية لتنفيذ هذا الإجراء.',REQUEST_NOT_FOUND:'الطلب غير موجود أو لم يعد متاحًا.',
 REQUEST_ALREADY_REVIEWED:'لا يمكن تعديل طلب تمت الموافقة عليه أو رفضه.',
 INVALID_REQUEST_ID:'معرّف الطلب غير صالح.',INVALID_MEMBER_NAME:'اكتب اسم العضو (من 1 إلى 80 حرفًا).',
 INVALID_MEMBER_DETAILS:'راجع رقم الهاتف وكود الدولة وصلة القرابة.',INVALID_TITLE_ID:'اختيار اللقب غير صالح.',
 TITLE_NOT_FOUND:'اللقب المختار لم يعد متاحًا.',INVALID_CUSTOM_TITLE:'اكتب اللقب المخصص (من 1 إلى 40 حرفًا).',
 SETTLEMENT_CHANGED_REFRESH:'بيانات الحساب اتغيرت؛ افتح مراجعة التسوية من جديد وراجعها قبل المتابعة.',ONLY_LATEST_SETTLEMENT:'آخر تسوية اتلغت بالفعل أو مفيش تسوية قابلة للتراجع. مسموح الرجوع تسوية واحدة بس.',
 CREDIT_ALREADY_USED:'لا يمكن التراجع عن هذه التسوية لأن جزءًا من رصيدها المرحّل استُخدم في تسوية لاحقة.',
 SETTLEMENT_NOT_FOUND:'التسوية المطلوبة غير موجودة أو غير متاحة لهذه الوحدة.',
 PAYMENT_NOT_CANCELABLE:'لا يمكن إلغاء دفعة مستخدمة في تسوية أو سبق إلغاؤها.',
 INVALID_AMOUNT:'أدخل مبلغًا صحيحًا وأكبر من الصفر.',
 INVALID_TRIP_PRICE:'اكتب السعر بالأرقام، أو اتركه فارغًا لتحديده لاحقًا.',
 INVALID_TRIP_ITEMS:'راجع أسماء المشتريات وأسعارها ثم حاول مجددًا.',
 TRIP_ALREADY_SETTLED:'تمت تسوية المشوار، لذلك لا يمكن تعديل مشترياته.',
 TRIP_NOT_FOUND:'المشوار غير موجود أو غير متاح، حدّث القائمة.',
 NO_OPEN_TRIPS:'لا توجد مشاوير مفتوحة لإجراء تسوية.',
 NO_ACTIVE_UNIT:'حسابك غير مرتبط بوحدة نشطة. تواصل مع مدير النظام.',
 UNIT_NOT_FOUND:'لم يتم العثور على وحدة نشطة مرتبطة بهذا الحساب.',
 INVALID_OPERATION:'الإجراء المطلوب غير متاح.',
 INVALID_BRAND_GEOMETRY:'راجع حجم اللوجو والمسافة بين الاسم والشعار.',
 RESET_PREVIEW_CHANGED:'تغيرت البيانات منذ المعاينة. افتح المعاينة من جديد قبل التصفير.',RESET_SCOPE_REVIEW_REQUIRED:'فيه بيانات إضافية محتاجة مراجعة قبل التصفير.',ONLY_CURRENT_MONTH_DUE:'يمكن إلغاء استحقاق الشهر الحالي فقط؛ مستحقات الشهور السابقة محفوظة.',CURRENT_DUE_NOT_FOUND:'هذا المستحق غير متاح للإلغاء؛ حدّث حساب الخدمة.',PAID_DUE_REQUIRES_FINANCIAL_REVIEW:'هذا المستحق له سداد بالفعل؛ راجع السداد من إجراءاته المالية قبل الإلغاء.',SERVICE_CHANGE_ALREADY_SCHEDULED:'يوجد تعديل أو إلغاء مقرر لهذا الاشتراك؛ راجعه قبل طلب تعديل جديد.',RECURRING_SUBSCRIPTION_REQUIRED:'هذا الإجراء خاص باشتراك خدمة شهرية.',RESET_PREVIEW_STALE:'تغيرت البيانات منذ المعاينة. أعد المعاينة قبل التصفير.',
 RESET_SCHEMA_CHANGED:'تغير مخطط قاعدة البيانات. التصفير متوقف لحين مراجعة الأمان.',
 RESET_PROTECTED_DEPENDENCY:'هناك علاقة جديدة بجداول محمية تمنع التصفير.',
 RESET_CONFIRMATION_REQUIRED:'يجب كتابة عبارة التأكيد والموافقة على المتابعة بدون نسخة جديدة.',
 INVALID_FEE:'راجع قيم أتعاب المشاوير المدخلة.',
 INVALID_PAYMENT:'راجع بيانات الدفعة واختر وحدة وبند تحصيل صالحين.',
 INVALID_EXPENSE:'راجع بيانات المصروف والبند والمبلغ المدخل.',
 INVALID_PAYMENT_AMOUNT:'أدخل مبلغ دفعة أكبر من صفر.',
 INVALID_EXPENSE_AMOUNT:'أدخل مبلغ مصروف أكبر من صفر.',
 INSUFFICIENT_BALANCE:'الرصيد المتاح غير كافٍ لتنفيذ العملية.',
 DUPLICATE_PAYMENT:'هذه الدفعة مسجلة بالفعل. راجع سجل الدفعات قبل المحاولة مجددًا.',
 EXPENSE_NOT_FOUND:'المصروف المطلوب غير موجود أو لم يعد متاحًا.',
 CHARGE_NOT_FOUND:'بند التحصيل غير موجود أو غير نشط.',
 INVALID_UNIT_ID:'اختر وحدة صحيحة قبل الحفظ.',
 PHONE_REQUIRED_FOR_MANAGER:'لا يمكن تولي إدارة الوحدة بدون رقم موبايل؛ أضفه من الإعدادات أولًا.',
 INVALID_PHONE:'رقم الموبايل غير صحيح؛ راجع الرقم.',
 INVALID_EMAIL:'صيغة البريد الإلكتروني غير صحيحة.',
 INVALID_REGISTRATION:'راجع الاسم ورقم الموبايل الاختياري ثم أعد المحاولة.',
 REQUEST_NOT_PENDING:'الطلب تمت مراجعته بالفعل؛ حدّث القائمة.'
};
function safeDbMessage(data,code){
 const msg=typeof data?.message==='string'?data.message.trim():'';
 if(Object.hasOwn(DB_USER_ERRORS,msg))return DB_USER_ERRORS[msg];
 // Database exception text is untrusted: only a bounded, explicitly approved code prefix is exposed.
 const prefix=/^([A-Z][A-Z0-9_]{2,65})(?=[:\s]|$)/.exec(msg);
 if(prefix&&Object.hasOwn(DB_USER_ERRORS,prefix[1]))return DB_USER_ERRORS[prefix[1]];
 if(/^RESET_STAGE_[A-Z0-9_]+$/.test(msg))return 'تعذر التصفير في خطوة '+msg.slice(12)+'. تم إلغاء العملية بالكامل. انسخ رمز المرحلة للدعم.';
 if(code==='23505')return 'هذه البيانات مسجلة بالفعل. راجع السجل قبل المحاولة مجددًا.';
 if(code==='23502')return 'هناك حقل مطلوب لم يتم إدخاله. راجع بيانات النموذج.';
 if(code==='23513')return 'هناك قيمة غير مسموح بها في البيانات المدخلة.';
 if(code==='23503')return 'لا يمكن تنفيذ العملية بسبب بيانات مرتبطة بها.';
 if(code==='23514')return 'البيانات لا تستوفي الشروط المطلوبة.';
 if(code==='22003')return 'الرقم المدخل خارج الحدود المسموح بها.';
 if(code==='22P02'||code==='22001')return 'راجع صيغة البيانات المدخلة وطولها.';
 if(code==='22007'||code==='22008')return 'التاريخ أو الوقت المدخل غير صحيح؛ راجع البيانات.';
 if(code==='23502')return 'أكمل الحقول المطلوبة قبل الحفظ.';
 if(code==='PGRST202')return 'وظيفة مطلوبة غير متاحة على قاعدة البيانات. تواصل مع الإدارة.';
 if(code==='42501')return 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';
 return 'تعذر إتمام العملية. حاول مرة أخرى أو انسخ تفاصيل الخطأ للدعم.';
}
function strictName(v){return /^[a-zA-Z][a-zA-Z0-9_]{0,70}$/.test(String(v||''));}
// Exact current release only; trusted alternative endpoints bypass transient raw-CDN failures.
async function downloadPublishedRuntime381(){
 const path='releases/V'+APP_VERSION+'/Tower_App_V'+APP_VERSION+'.zip',stamp=encodeURIComponent(APP_VERSION+'-'+Date.now());
 const candidates=[
  ['https://raw.githubusercontent.com/islamsallams/tower-app/refs/heads/main/'+path+'?tower_release='+stamp,'application/octet-stream'],
  ['https://github.com/islamsallams/tower-app/raw/refs/heads/main/'+path+'?tower_release='+stamp,'application/octet-stream'],
  ['https://api.github.com/repos/islamsallams/tower-app/contents/'+path+'?ref=main','application/vnd.github.raw+json']
 ];
 for(const [url,accept] of candidates){try{
  const response=await fetch(url,{signal:AbortSignal.timeout(12000),cache:'no-store',headers:{Accept:accept,'User-Agent':'Tower-App-Runtime/'+APP_VERSION}});
  if(!response.ok){await response.body?.cancel();continue;}
  if(Number(response.headers.get('content-length'))>4194304){await response.body?.cancel();continue;}
  const reader=response.body?.getReader();if(!reader)continue;const chunks=[];let length=0;
  try{for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>4194304){await reader.cancel();throw Error('INVALID_RUNTIME_ARCHIVE');}chunks.push(value);}}finally{reader.releaseLock();}
  const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  if(bytes.length<22||bytes[0]!==80||bytes[1]!==75||bytes[2]!==3||bytes[3]!==4)continue;
  return bytes;
 }catch(_){/* A failed endpoint never changes the requested version or triggers deployment. */}}
 throw Error('CURRENT_RELEASE_ARCHIVE_UNAVAILABLE');
}
async function rpc(env,name,params){if(!strictName(name))throw Error('INVALID_OPERATION');return db(env,'rpc/'+name,{method:'POST',body:params});}
async function readPublicUi340(env){return rpc(env,'tower_public_ui_256',{});}
async function readUiPreferences(env,token){
 if(!token)return {fontFamily:'Cairo'};
 try{return await rpc(env,'tower_ui_preferences_action',{p_token:token,p_action:'get',p_payload:{}});}
 catch(e){ if(String(e.message||'').includes('DATABASE_REQUEST_FAILED 404'))return {fontFamily:'Cairo'};throw e;}
}
const PERSON_LABEL_KEYS=new Set(['actorDisplayName','actorName','actor_display_name','actor_name','approvedByName','approved_by_name','beneficiaryName','beneficiary_name','candidateName','candidate_name','collectorName','collector_name','confirmedByName','confirmed_by_name','counterpartyName','counterparty_name','createdByName','created_by_name','deliveredByName','delivered_by_name','displayName','display_name','managerDisplayName','managerName','manager_display_name','manager_name','memberName','memberNames','member_name','member_names','ownerName','owner_name','payerName','payer_name','receiverName','receiver_name','recipientName','recipient_name','recordedByName','recorded_by_name','requestedByName','requested_by_name','requesterName','requester_name','responsibleName','responsible_name','reviewedByName','reviewed_by_name','senderName','sender_name','userName','user_name']);
function hasPersonLabels(value){if(!value||typeof value!=='object')return false;if(Array.isArray(value))return value.some(hasPersonLabels);if(value.notificationId||value.notification_id||value.notificationType)return true;if(value.columns&&value.rows)return true;if(value.name&&(value.userId||value.user_id||value.loginId||value.login_id||value.title&&('phone'in value||'relation'in value||'memberRole'in value||'preferredTitle'in value)||['ADMIN','UNION','RESIDENT','OPERATOR'].includes(value.role)))return true;return Object.entries(value).some(([k,v])=>PERSON_LABEL_KEYS.has(k)&&Boolean(v)||hasPersonLabels(v));}
function personLabelsFallback(value){if(!value||typeof value!=='object')return value;if(Array.isArray(value))return value.map(personLabelsFallback);const out={};for(const [key,v]of Object.entries(value)){out[key]=PERSON_LABEL_KEYS.has(key)?(Array.isArray(v)?v.map(()=> 'اللقب غير متاح'):'اللقب غير متاح'):personLabelsFallback(v);}if(value.name&&(value.userId||value.user_id||value.loginId||value.login_id||value.title&&('phone'in value||'relation'in value||'memberRole'in value||'preferredTitle'in value)||['ADMIN','UNION','RESIDENT','OPERATOR'].includes(value.role)))out.displayName=workerPersonName({...value,title:value.preferredTitle||value.title,custom_title:value.customTitle||value.custom_title});if(value.notificationId||value.notification_id||value.notificationType){for(const key of ['title','body','message','text'])if(typeof value[key]==='string')out[key]='تعذر عرض أسماء الإشعار؛ حاول لاحقًا.';}if(Array.isArray(value.columns)&&Array.isArray(value.rows))out.rows=value.rows.map(row=>Array.isArray(row)?row.map((cell,i)=>/مدير الوحدة|اسم الشخص|اسم العضو|المسؤول|المحصّل|المحصل|المستلم|المستخدم|مدير الحساب/.test(String(value.columns[i]?.label||value.columns[i]||''))?'اللقب غير متاح':cell):personLabelsFallback(row));return out;}
async function presentPersonLabels(env,value){if(!hasPersonLabels(value))return value;try{return await db(env,'rpc/tower_present_names_231',{method:'POST',body:{p_value:value}});}catch(_){console.warn('PERSON_LABELS_UNAVAILABLE');return personLabelsFallback(value);}}
function workerPersonName(person){const name=String(person?.name||'').trim(),title=[person?.custom_title,person?.customTitle,person?.preferredTitle,person?.title].map(x=>String(x||'').trim()).find(Boolean)||'أ.';return !name?'غير محدد':title==='بدون لقب'?name:name===title||name.startsWith(title+' ')?name:title+' '+name;}
function canonicalUser(u){return {authenticated:true,userId:u.user_id,loginId:u.login_id,name:u.name,firstName:u.first_name_261||String(u.name||'').split(/\s+/)[0],restName:u.rest_name_261??String(u.name||'').trim().split(/\s+/).slice(1).join(' '),shortDisplayName:workerPersonName({...u,name:u.first_name_261||String(u.name||'').trim().split(/\s+/)[0]}),titleId:u.title_id||'',customTitle:u.custom_title||'',preferredTitle:[u.custom_title,u.title].map(x=>String(x||'').trim()).find(Boolean)||'أ.',displayName:workerPersonName(u),role:u.role,roleLabel:({ADMIN:'إدارة النظام',UNION:'رئيس اتحاد الشاغلين',RESIDENT:'ساكن',OPERATOR:'أمين'})[u.role],mustChangePin:u.must_change_pin,phone:u.phone||'',email:u.email||'',isUnitManager:Boolean(u.is_unit_manager)};}
async function sessionUser(env,token){if(!token)return null;const rows=await rpc(env,'tower_session_user',{p_token:token});return Array.isArray(rows)?rows[0]||null:rows;}

// Telegram integration: service-role only; chat binding requires a fresh, one-use random challenge.
const tgHex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
async function tgHash(value){return tgHex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));}
function tgChallenge(){return tgHex(crypto.getRandomValues(new Uint8Array(24)));}
async function telegramSend(env,chatId,message){
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 message=await db(env,'rpc/tower_present_text_231',{method:'POST',body:{p_message:message}});
 const r=await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/sendMessage',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({chat_id:chatId,text:message,disable_web_page_preview:true}),signal:AbortSignal.timeout(20000)});
 const result=await r.json().catch(()=>null);
 if(r.status===429){const sec=Number(result?.parameters?.retry_after||r.headers.get('retry-after')||600);const e=Error('TELEGRAM_RATE_LIMITED');e.retryAfterSeconds=Math.min(86400,Math.max(60,Number.isFinite(sec)?Math.ceil(sec):600));throw e;}
 if(r.status===403){throw Error('TELEGRAM_RECIPIENT_BLOCKED');}
 if(!r.ok||result?.ok!==true)throw Error('TELEGRAM_DELIVERY_FAILED');return result;
}
// Cron heartbeat is diagnostic-only: failure to record it must never stop delivery.
async function recordTelegramCron(env,fields){
 try{await db(env,'tower_telegram_cron_health?health_id=eq.1',{method:'PATCH',body:fields});}
 catch(e){console.error('TELEGRAM_CRON_HEALTH_UNAVAILABLE',String(e.message||e).slice(0,60));}
}
async function scheduledTelegramRun(env){
 const started=new Date().toISOString();
 await recordTelegramCron(env,{last_started_at:started,last_status:'RUNNING'});
 try{
  const result=await telegramProcessQueue(env);
  await recordTelegramCron(env,{last_finished_at:new Date().toISOString(),last_status:(result.digestEnqueueFailed||result.failed>0)?'DEGRADED':'SUCCESS',last_jobs_sent:result.sent,last_jobs_failed:result.failed,last_digest_error:result.digestEnqueueFailed});
 }catch(e){
  await recordTelegramCron(env,{last_finished_at:new Date().toISOString(),last_status:'ERROR',last_digest_error:false});
  throw e;
 }
}
// V2.5.12: role-limited daily digest data comes from current authoritative tables.
// Do not substitute zero when a database query fails: let the queue retry instead.
function digestAmount(value){
 const n=Number(value);
 if(!Number.isFinite(n))throw Error('DIGEST_AMOUNT_UNAVAILABLE');
 return Math.ceil(n).toLocaleString('en-US',{maximumFractionDigits:0})+' ج.م';
}
function digestCairoDay(){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Africa/Cairo',day:'2-digit',month:'2-digit',year:'numeric'}).formatToParts(new Date());
 const part=k=>parts.find(p=>p.type===k)?.value||'';
 return part('day')+'/'+part('month')+'/'+part('year');
}
function telegramRoleDigestText(m){
 if(!m||m.eligible!==true)throw Error('DIGEST_NOT_ELIGIBLE');
 const count=(v)=>{const n=Number(v);if(!Number.isInteger(n)||n<0)throw Error('DIGEST_COUNT_UNAVAILABLE');return String(n);};
 if(m.role==='UNION'){
  const out=['📊 Tower App — الملخص المالي لرئيس الاتحاد — '+digestCairoDay()];
  if(m.showAmounts===true)out.push('رصيد الصندوق: '+digestAmount(m.balance),
   'تحصيلات اليوم: '+digestAmount(m.collectedToday),
   'مصروفات اليوم: '+digestAmount(m.expensesToday),
   'المستحقات غير المسددة: '+digestAmount(m.outstandingDues));
  else out.push('التفاصيل المالية مخفية حسب إعداد حسابك.');
  out.push('تقارير التحصيل المعلقة: '+count(m.pendingCollectionReports));
  return out.join('\n');
 }
 if(m.role==='OPERATOR')return ['🛎️ Tower App — الملخص التشغيلي للأمين — '+digestCairoDay(),
  'المشاوير المفتوحة: '+count(m.openTrips),
  'المشاوير الجديدة اليوم: '+count(m.newTripsToday),
  'المشاوير التي تمت تسويتها اليوم: '+count(m.settledTripsToday),
  'وحدات لديها مشاوير مفتوحة: '+count(m.unitsWithOpenTrips),
  'دفعات ساكن لم تُطبّق بعد: '+count(m.openResidentPayments)].join('\n');
 throw Error('DIGEST_ROLE_FORBIDDEN');
}
function telegramDeepLink(env,role,type){
 // Default to this deployment's public app URL when the optional override is absent.
 const base=String(env.TOWER_APP_PUBLIC_URL||'https://tower-app.islamsallams.workers.dev').replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9.-]+(?::443)?(?:\/[a-z0-9_/-]*)?$/i.test(base))return '';
 const route={
  ADMIN:{COLLECTION:'collections',EXPENSE:'finance',INCOME:'finance',TRIP:'reports',SETTLEMENT:'reports',SERVICE:'home'},
  UNION:{COLLECTION:'collections',EXPENSE:'finance',INCOME:'finance',TRIP:'reports',SETTLEMENT:'reports',SERVICE:'services'},
  OPERATOR:{COLLECTION:'collections',TRIP:'trips',SETTLEMENT:'trips'},
  RESIDENT:{COLLECTION:'building-fund',EXPENSE:'building-fund',INCOME:'building-fund',TRIP:'trips',SETTLEMENT:'account',SERVICE:'building'}
 };
 const page=route[role]?.[type];
 return page?base+'/?view='+encodeURIComponent(page):'';
}
async function telegramDispatchMessage(env,job){
 const msg=String(job.message||'');
 const needsDigest=msg.includes('الملخص اليومي:');
 const needsLink=msg.includes('افتح التطبيق');
 if(!needsDigest&&!needsLink)return msg;
 const records=await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id)+'&select=user_id,event_key&limit=1');
 const log=records[0],key=String(log?.event_key||'');
 if(!log)throw Error('TELEGRAM_EVENT_NOT_FOUND');
 if(needsDigest){
  if(!/^digest:\d{4}-\d{2}-\d{2}$/.test(key))throw Error('DIGEST_EVENT_INVALID');
  const metrics=await rpc(env,'tower_telegram_digest_metrics',{p_user_id:log.user_id});
  return telegramRoleDigestText(metrics);
 }
 if(!/^notification:[0-9a-f-]{36}$/i.test(key))return msg;
 const notificationId=key.slice('notification:'.length);
 const [userRows,eventRows]=await Promise.all([
  db(env,'tower_users?user_id=eq.'+encodeURIComponent(log.user_id)+'&select=role&limit=1'),
  db(env,'tower_notifications?notification_id=eq.'+encodeURIComponent(notificationId)+'&select=type&limit=1')
 ]);
 const link=telegramDeepLink(env,String(userRows[0]?.role||''),String(eventRows[0]?.type||''));
 return link?msg+'\nافتح القسم المناسب: '+link:msg;
}
// Outbox processing is independent of financial actions. Daily digest requires explicit account consent at enqueue and dispatch. Cron is best-effort and
// delivery is at-least-once across process crashes; event keys prevent queue duplicates.
async function telegramProcessQueue(env){
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 let sent=0,failed=0,digestEnqueueFailed=false;
 // Daily summary enqueue is database-gated to 09:00 Africa/Cairo and
 // deduplicated per Tower account per local calendar day.
 try{await rpc(env,'tower_telegram_enqueue_daily_digest',{});}catch(e){
  digestEnqueueFailed=true;console.error('TELEGRAM_DIGEST_ENQUEUE_FAILED',String(e.message||e).slice(0,70));
 }
 const jobs=await rpc(env,'tower_telegram_claim',{p_limit:15});
 for(const job of Array.isArray(jobs)?jobs:[]){
  try{
   const message=await telegramDispatchMessage(env,job);
   await telegramSend(env,job.chat_id,message);
   await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),
    {method:'PATCH',body:{status:'SENT',sent_at:new Date().toISOString()}});
   sent++;
  }catch(error){
   // The SQL claim already scheduled a retry. Telegram's explicit 429 and 403
   // are classified without logging the chat ID, message or Telegram response body.
   failed++;
   const reason=String(error?.message||'TELEGRAM_DELIVERY_FAILED');
   if(reason==='TELEGRAM_RECIPIENT_BLOCKED'){
    try{await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),{method:'PATCH',body:{status:'CANCELLED'}});}catch{console.error('TELEGRAM_CANCEL_UPDATE_FAILED');}
   }else if(reason==='TELEGRAM_RATE_LIMITED'){
    const seconds=Math.min(86400,Math.max(60,Number(error.retryAfterSeconds)||600));
    try{await db(env,'tower_telegram_delivery_log?delivery_id=eq.'+encodeURIComponent(job.delivery_id),{method:'PATCH',body:{next_attempt_at:new Date(Date.now()+seconds*1000).toISOString()}});}catch{console.error('TELEGRAM_RETRY_UPDATE_FAILED');}
   }
   console.error('TELEGRAM_OUTBOX_DELIVERY_FAILED',/^(TELEGRAM_RATE_LIMITED|TELEGRAM_RECIPIENT_BLOCKED)$/.test(reason)?reason:'TELEGRAM_DELIVERY_FAILED');
  }
 }
 return {sent,failed,digestEnqueueFailed};
}
// Manual PDF export: the report was generated in the authenticated client's preview;
// the Worker verifies the Tower user's CURRENT reporting rights before forwarding it
// only to this same user's linked Telegram chat. The bot token never reaches the browser.
async function telegramSendPdf(env,chatId,pdfBytes,fileName,caption){
 caption=await db(env,'rpc/tower_present_text_231',{method:'POST',body:{p_message:caption||''}});
 if(!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 const form=new FormData();
 form.set('chat_id',String(chatId));
 form.set('caption',caption);
 form.set('document',new Blob([pdfBytes],{type:'application/pdf'}),fileName);
 const response=await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/sendDocument',{method:'POST',body:form,signal:AbortSignal.timeout(30000)});
 if(!response.ok)throw Error('TELEGRAM_PDF_FAILED');
 const result=await response.json().catch(()=>null);
 if(result?.ok!==true)throw Error('TELEGRAM_PDF_REJECTED');
 return {success:true};
}
async function telegramManualPdf(env,u,account,options){
 if(!account?.chat_id||!account.enabled)throw Error('TELEGRAM_NOT_LINKED');
 if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
 const reportId=String(options?.reportId||'');
 if(!/^[A-Z][A-Z0-9_]{1,55}$/.test(reportId))throw Error('INVALID_REPORT');
 // Report-specific access must be checked again, not trusted from a client-supplied ID.
 if(reportId==='COMBINED_OVERVIEW'){
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  // This report relies on the existing privileged snapshot API.
  await rpc(env,'tower_building_financial_snapshot',{p_token:u._tg_session_token});
 }else{
  const catalog=await rpc(env,'tower_report_action',{p_token:u._tg_session_token,p_action:'catalog',p_payload:{}});
  if(!Array.isArray(catalog)||!catalog.some(x=>x?.id===reportId))throw Error('FORBIDDEN');
 }
 const b64=String(options?.base64||'');
 if(b64.length<80||b64.length>8*1024*1024||!/^[A-Za-z0-9+/]+={0,2}$/.test(b64))throw Error('INVALID_PDF');
 let binary;try{binary=atob(b64);}catch{throw Error('INVALID_PDF');}
 if(binary.length<50||binary.length>6*1024*1024||binary.slice(0,5)!=='%PDF-')throw Error('INVALID_PDF');
 const rawName=String(options?.filename||'Tower_Report.pdf');
 const safeName=Array.from(rawName.normalize('NFC').replace(/[\\/\x00-\x1f<>:"|?*]/g,'_').replace(/\s+/g,' ').trim()).slice(0,95).join('');
 if(!safeName.toLowerCase().endsWith('.pdf'))throw Error('INVALID_PDF');
 const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 const role=({ADMIN:'إدارة النظام',UNION:'رئيس الاتحاد',OPERATOR:'الأمين',RESIDENT:'الساكن'})[u.role];
 return telegramSendPdf(env,account.chat_id,bytes,safeName,'📄 Tower App — '+role+'\nتم إرسال تقرير PDF يدويًا من حسابك.');
}
// The opening user's role does not select or authorize PDF recipients.
// Read-only preflight; database RPCs serialize claims per eligible recipient.
async function towerPdfDispatchTargets(env){
 const sched=(await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day'))[0];
 if(!sched)return {day:null,recipients:[]};
 const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
 const val=n=>parts.find(x=>x.type===n)?.value;
 const day=[val('year'),val('month'),val('day')].join('-');
 const [sh,sm]=String(sched.send_time).split(':').map(Number);
 if(Number(val('hour'))*60+Number(val('minute'))<sh*60+sm||!towerPdfFrequencyDue(sched.frequency,val('year'),val('month'),val('day'),sched.monthly_day))return {day,recipients:[]};
 const prefs=await db(env,'tower_telegram_pdf_preferences?enabled=eq.true&select=user_id');
 if(!prefs.length)return {day,recipients:[]};
 const ids=prefs.map(p=>p.user_id).filter(x=>/^[a-f0-9-]{36}$/i.test(x));
 if(!ids.length)return {day,recipients:[]};
 const users=await db(env,'tower_users?user_id=in.('+ids.join(',')+')&role=in.(ADMIN,UNION)&status=eq.ACTIVE&must_change_pin=eq.false&select=user_id');
 const valid=new Set(users.map(x=>x.user_id));
 const accts=await db(env,'tower_telegram_accounts?user_id=in.('+ids.join(',')+')&enabled=eq.true&chat_id=not.is.null&select=user_id,chat_id');
 const jobs=await db(env,'tower_telegram_pdf_jobs?report_day=eq.'+day+'&user_id=in.('+ids.join(',')+')&select=user_id,status,attempts,lease_until,updated_at');
 const now=Date.now(),byId=new Map(jobs.map(j=>[j.user_id,j]));
 const recipients=accts.filter(r=>valid.has(r.user_id)).filter(r=>{
  const j=byId.get(r.user_id);if(!j)return true;
  if(j.status==='SENT'||j.attempts>=5)return false;
  if(['CLAIMED','SENDING'].includes(j.status)&&j.lease_until&&Date.parse(j.lease_until)>now)return false;
  if(j.status==='FAILED'&&Date.parse(j.updated_at||0)+600000>now)return false;
  return true;
 });
 return {day,recipients};
}
async function towerPdfDispatch(env,opts){
 const info=await towerPdfDispatchTargets(env);
 if(!info.recipients.length)return {sent:0,failed:0};
 const b64=String(opts?.base64||'');
 if(b64.length<80||b64.length>8*1024*1024||!/^[A-Za-z0-9+/]+={0,2}$/.test(b64))throw Error('INVALID_PDF');
 let binary;try{binary=atob(b64);}catch{throw Error('INVALID_PDF');}
 if(binary.length<50||binary.length>6*1024*1024||binary.slice(0,5)!=='%PDF-')throw Error('INVALID_PDF');
 const bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 const filename='Tower_Periodic_Finance_'+info.day+'.pdf';
 let sent=0,failed=0,startRejected=0,claimRejected=0;
 for(const r of info.recipients){
  const nonce=crypto.randomUUID();
  const claimed=await rpc(env,'tower_telegram_pdf_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce});
  if(claimed!==true){claimRejected++;continue;}
  try{
   const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce});
   if(started!==true){startRejected++;console.warn('TELEGRAM_PDF_START_REJECTED');await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce}).catch(e=>console.warn('PDF_CLAIM_RELEASE_FAILED',String(e?.message||e).slice(0,100)));continue;}
   try{
    await telegramSendPdf(env,r.chat_id,bytes,filename,'📄 Tower App — التقرير المالي الدوري');
    await rpc(env,'tower_telegram_pdf_finish',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce,p_success:true});sent++;
   }catch(e){failed++;await rpc(env,'tower_telegram_pdf_finish',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce,p_success:false}).catch(()=>{});}
  }catch(e){failed++;console.error('TELEGRAM_PDF_JOB_ERROR',String(e?.message||e).slice(0,120));await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:r.user_id,p_day:info.day,p_nonce:nonce}).catch(()=>{});}
 }
 return {sent,failed,startRejected,claimRejected};
}
async function telegramUserAction(env,u,action,opts={}){
 if(!['ADMIN','UNION','OPERATOR','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
 if(!env.TELEGRAM_BOT_USERNAME||!env.TELEGRAM_BOT_TOKEN)throw Error('TELEGRAM_NOT_CONFIGURED');
 const userId=u.user_id;
 const rows=await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId)+'&select=user_id,chat_id,enabled,show_amounts,daily_digest_enabled,linked_at');
 const item=rows[0]||null;
 if(action==='status')return {linked:!!item?.chat_id,enabled:item?.enabled??false,showAmounts:item?.show_amounts??false,dailyDigestEnabled:['UNION','OPERATOR'].includes(u.role)&&(item?.daily_digest_enabled??false),linkedAt:item?.linked_at||null};
 if(action==='begin'){
  const code=tgChallenge(),hash=await tgHash(code);
  await db(env,'tower_telegram_links?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_links',{method:'POST',body:{user_id:userId,challenge_hash:hash,expires_at:new Date(Date.now()+10*60*1000).toISOString()}});
  return {url:'https://t.me/'+env.TELEGRAM_BOT_USERNAME.replace(/^@/,'')+'?start='+code,expiresMinutes:10};
 }
 if(action==='set'){
  if(!item?.chat_id)throw Error('TELEGRAM_NOT_LINKED');
  const body={};if(typeof opts.enabled==='boolean')body.enabled=opts.enabled;if(typeof opts.showAmounts==='boolean')body.show_amounts=opts.showAmounts;if(typeof opts.dailyDigestEnabled==='boolean'){if(!['UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');body.daily_digest_enabled=opts.dailyDigestEnabled;}
  if(!Object.keys(body).length)throw Error('INVALID_OPERATION');
  await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId),{method:'PATCH',body});return {success:true};
 }
 if(action==='getPdfSchedule'||action==='setPdfSchedule'){
  if(u.role!=='ADMIN')throw Error('FORBIDDEN');
  if(action==='setPdfSchedule'){
   const time=String(opts.time||''),frequency=String(opts.frequency||'MONTHLY'),monthlyDay=Number(opts.monthlyDay??1);
   if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('INVALID_PDF_TIME');
   if(!['DAILY','WEEKLY','MONTHLY'].includes(frequency))throw Error('INVALID_PDF_FREQUENCY');
   if(!Number.isInteger(monthlyDay)||monthlyDay<1||monthlyDay>31)throw Error('INVALID_PDF_MONTHLY_DAY');
   const changed=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true',{method:'PATCH',body:{send_time:time+':00',frequency,monthly_day:monthlyDay}});
   if(!changed.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
   return {time:String(changed[0].send_time).slice(0,5),frequency:changed[0].frequency,monthlyDay:changed[0].monthly_day};
  }
  const rows=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!rows.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
  return {time:String(rows[0].send_time).slice(0,5),frequency:rows[0].frequency||'MONTHLY',monthlyDay:rows[0].monthly_day||1};
 }
 if(action==='setDailyPdf'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.chat_id)throw Error('FORBIDDEN');
  if(typeof opts.enabled!=='boolean')throw Error('INVALID_OPERATION');
  await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_pdf_preferences',{method:'POST',body:{user_id:userId,enabled:opts.enabled}});
  return {success:true};
 }
 if(action==='dailyPdfStatus'){
  if(!['ADMIN','UNION'].includes(u.role))return {enabled:false,eligible:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&select=enabled');
  return {enabled:pref[0]?.enabled===true,eligible:!!item?.enabled&&!!item?.chat_id};
 }
 if(action==='dailyPdfHistory'){
  // Only the signed-in finance recipient can inspect their own delivery attempts.
  // Return operational metadata, never report content, balances or other users' jobs.
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  const rows=await db(env,'tower_telegram_pdf_jobs?user_id=eq.'+encodeURIComponent(userId)+'&select=report_day,status,attempts,updated_at,completed_at,lease_until&order=report_day.desc&limit=5');
  return {jobs:rows.map(j=>({day:j.report_day,status:j.status,attempts:j.attempts,updatedAt:j.updated_at,completedAt:j.completed_at,leaseUntil:j.lease_until}))};
 }
 if(action==='autoPdfDue'){
  const plan=await towerPdfDispatchTargets(env);
  return {due:plan.recipients.length>0};
 }
 if(action==='autoPdfDispatch')return towerPdfDispatch(env,opts);
 if(action==='dailyPdfDue'){
  // Pure eligibility preflight: NEVER reserve a job before browser rendering succeeds.
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)return {due:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pref.length)return {due:false};
  const schedules=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!schedules.length)return {due:false};
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
  const value=n=>parts.find(x=>x.type===n)?.value;
  const [hour,minute]=String(schedules[0].send_time).split(':').map(Number);
  if(Number(value('hour'))*60+Number(value('minute'))<hour*60+minute)return {due:false};
  if(!towerPdfFrequencyDue(schedules[0].frequency,value('year'),value('month'),value('day'),schedules[0].monthly_day))return {due:false};
  const day=[value('year'),value('month'),value('day')].join('-');
  const jobs=await db(env,'tower_telegram_pdf_jobs?user_id=eq.'+encodeURIComponent(userId)+'&report_day=eq.'+day+'&select=status,attempts,lease_until,updated_at');
  const job=jobs[0];
  if(job){
   if(job.status==='SENT'||job.attempts>=5)return {due:false};
   if(['CLAIMED','SENDING'].includes(job.status)&&job.lease_until&&Date.parse(job.lease_until)>Date.now())return {due:false};
   if(job.status==='FAILED'&&Date.parse(job.updated_at||0)+10*60*1000>Date.now())return {due:false};
  }
  return {due:true};
 }
 if(action==='dailyPdfClaim'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)return {claimed:false};
  const pref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pref.length)return {claimed:false};
  const cairo=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'}).formatToParts(new Date());
  const value=n=>cairo.find(x=>x.type===n)?.value;
  const schedules=await db(env,'tower_telegram_pdf_schedule?singleton=eq.true&select=send_time,frequency,monthly_day');
  if(!schedules.length)throw Error('PDF_SCHEDULE_NOT_INSTALLED');
  const [hour,minute]=String(schedules[0].send_time).split(':').map(Number);
  if(Number(value('hour'))*60+Number(value('minute'))<hour*60+minute)return {claimed:false};
  if(!towerPdfFrequencyDue(schedules[0].frequency,value('year'),value('month'),value('day'),schedules[0].monthly_day))return {claimed:false};
  const day=[value('year'),value('month'),value('day')].join('-');
  const nonce=crypto.randomUUID();
  const claimed=await rpc(env,'tower_telegram_pdf_claim',{p_user_id:userId,p_day:day,p_nonce:nonce});
  return {claimed:claimed===true,day,nonce};
 }
 if(action==='failDailyPdf'){
  // A browser-side render failure must not leave the scheduled job silently CLAIMED.
  // Both RPCs validate the signed-in user, current day and matching nonce.
  if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
  const nonce=String(opts.nonce||''),day=String(opts.day||'');
  if(!/^[a-f0-9-]{36}$/i.test(nonce)||!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('INVALID_OPERATION');
  const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:userId,p_day:day,p_nonce:nonce});
  if(started!==true){const released=await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:userId,p_day:day,p_nonce:nonce});return {updated:released===true};}
  const finished=await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:false});
  return {updated:finished===true};
 }
 if(action==='sendDailyPdf'){
  if(!['ADMIN','UNION'].includes(u.role)||!item?.enabled||!item?.chat_id)throw Error('FORBIDDEN');
  const nonce=String(opts.nonce||'');const day=String(opts.day||'');
  if(!/^[a-f0-9-]{36}$/i.test(nonce)||!/^\d{4}-\d{2}-\d{2}$/.test(day))throw Error('INVALID_OPERATION');
  const pdfPref=await db(env,'tower_telegram_pdf_preferences?user_id=eq.'+encodeURIComponent(userId)+'&enabled=eq.true&select=user_id');
  if(!pdfPref.length)throw Error('FORBIDDEN');
  // One database transaction owns the CLAIMED -> SENDING transition. Never
  // substitute a REST check followed by PATCH: concurrent requests can both send.
  const started=await rpc(env,'tower_telegram_pdf_start',{p_user_id:userId,p_day:day,p_nonce:nonce});
  if(started!==true){await rpc(env,'tower_telegram_pdf_release_claim',{p_user_id:userId,p_day:day,p_nonce:nonce}).catch(()=>{});throw Error('PDF_START_REJECTED');}
  try{
   const sent=await telegramManualPdf(env,u,item,{...opts,reportId:'COMBINED_OVERVIEW'});
   await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:true});
   return sent;
  }catch(e){await rpc(env,'tower_telegram_pdf_finish',{p_user_id:userId,p_day:day,p_nonce:nonce,p_success:false}).catch(()=>{});throw e;}
 }
 if(action==='unlink'){
  await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});
  await db(env,'tower_telegram_links?user_id=eq.'+encodeURIComponent(userId),{method:'DELETE'});return {success:true};
 }
 if(action==='sendPdf'){
  // Manual, opt-in transfer. Content rendered by the user's browser; the Worker
  // independently authorizes report access and sends only to this user's linked chat.
  return telegramManualPdf(env,u,item,opts);
 }
 if(action==='test'){
  if(!item?.chat_id||!item.enabled)throw Error('TELEGRAM_NOT_LINKED');
  await telegramSend(env,item.chat_id,'✅ Tower App — '+(({ADMIN:'إدارة النظام',UNION:'رئيس الاتحاد',OPERATOR:'الأمين',RESIDENT:'الساكن'})[u.role]||'الحساب')+'\nتم اختبار ربط حسابك بنجاح. لا تتضمن هذه الرسالة أي بيانات مالية.');
  return {success:true};
 }
 throw Error('INVALID_OPERATION');
}
async function telegramWebhook(env,request){
 if(!env.TELEGRAM_WEBHOOK_SECRET||request.headers.get('X-Telegram-Bot-Api-Secret-Token')!==env.TELEGRAM_WEBHOOK_SECRET)return fail('FORBIDDEN',403);
 if(Number(request.headers.get('content-length')||0)>16384)return fail('REQUEST_TOO_LARGE',413);
 let update;
 try{
  const reader=request.body?.getReader();
  if(!reader)return fail('INVALID_JSON');
  const chunks=[];let byteCount=0;
  while(true){
   const {done,value}=await reader.read();
   if(done)break;
   byteCount+=value.byteLength;
   if(byteCount>16384){await reader.cancel().catch(()=>{});return fail('REQUEST_TOO_LARGE',413);}
   chunks.push(value);
  }
  const bytes=new Uint8Array(byteCount);let at=0;
  for(const part of chunks){bytes.set(part,at);at+=part.byteLength;}
  const raw=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  update=JSON.parse(raw);
 }catch(_){return fail('INVALID_JSON');}
 const m=update?.message,chat=m?.chat;
 if(chat?.type!=='private'||typeof m?.text!=='string')return respond({ok:true});
 const match=/^\/start ([0-9a-f]{48})$/.exec(m.text.trim());
 if(!match)return respond({ok:true});
 const hash=await tgHash(match[1]);
 // SQL SECURITY DEFINER function atomically consumes the challenge and binds the private chat.
 const bound=await rpc(env,'tower_telegram_bind',{p_challenge_hash:hash,p_chat_id:String(chat.id)});
 if(bound===true||bound?.success===true)await telegramSend(env,String(chat.id),'✅ تم ربط حساب Tower App. يمكنك التحكم في التنبيهات والخصوصية من إعدادات حسابك.');
 return respond({ok:true});
}

async function readBrandingContext(env){
 try{const [settings,assets]=await Promise.all([db(env,'tower_system_settings?select=settings&singleton=eq.true&limit=1'),db(env,'tower_brand_assets?select=kind,updated_at')]);
  const branding=settings[0]?.settings?.branding||{};let focus={};try{const rows=await db(env,'tower_brand_presentation_251?singleton=eq.true&select=desktop_x,desktop_y,mobile_x,mobile_y,login_fade,logo_size,line_gap&limit=1');if(rows[0])focus={loginDesktopX:rows[0].desktop_x,loginDesktopY:rows[0].desktop_y,loginMobileX:rows[0].mobile_x,loginMobileY:rows[0].mobile_y,loginFade:rows[0].login_fade!==false,logoSize:rows[0].logo_size??34,lineGap:rows[0].line_gap??2};}catch(_){console.warn('BRAND_PRESENTATION_UNAVAILABLE');}
  return {...branding,...focus,logoUrl:assets.some(x=>x.kind==='logo')?'/api/brand/logo':null,mainImageUrl:assets.some(x=>x.kind==='main')?'/api/brand/main':null};
 }catch(e){console.warn('BRAND_ASSETS_UNAVAILABLE');return {};}
}
async function serveBrandImage(env,kind){
 try{const rows=await db(env,'tower_brand_assets?select=mime,encoded&kind=eq.'+kind+'&limit=1');if(!rows.length)return new Response('',{status:404,headers:{'cache-control':'no-store'}});
  const x=rows[0],bytes=Uint8Array.from(atob(x.encoded),c=>c.charCodeAt(0));
  return new Response(bytes,{headers:{'content-type':x.mime,'cache-control':'no-cache, max-age=0','x-content-type-options':'nosniff'}});
 }catch(e){return new Response('',{status:404});}
}
async function dispatch(env,p,requestOrigin=""){const method=p.method||p.name;const args=Array.isArray(p.args)?p.args:[];const token=String(p.token||'');
 if(method==='getBootstrapContext'){
  const authToken=String(args[0]||token);const u=await sessionUser(env,authToken);
  const uiPreferences=u?await readUiPreferences(env,authToken):await readPublicUi340(env);
  const branding=await readBrandingContext(env);
  return {version:APP_VERSION,configured:true,building:{name:branding.systemName||'Tower App'},branding,uiPreferences,personalUiPreferences:u?await readPersonalUi199(env,authToken):{},titles:[],user:u?canonicalUser(u):{authenticated:false}};
 }
 if(method==='loginWithCredentials'){
  const [login,pin]=args;if(!/^[a-z0-9_-]{1,32}$/i.test(String(login||''))||!/^[0-9]{4,8}$/.test(String(pin||'')))throw Error('بيانات الدخول غير صحيحة.');
  const result=await loginWithStatus300(env,String(login).toLowerCase(),String(pin));
  const item=Array.isArray(result)?result[0]:result;if(!item||!item.token)throw Error('بيانات الدخول غير صحيحة.');
  const user=await sessionUser(env,item.token);
  const uiPreferences=await readUiPreferences(env,item.token);
  const branding=await readBrandingContext(env);
  return {token:item.token,context:{version:APP_VERSION,configured:true,building:{name:branding.systemName||'Tower App'},branding,uiPreferences,personalUiPreferences:await readPersonalUi199(env,item.token),titles:[],user:canonicalUser(user)}};
 }
 if(['getPublicRegistrationContext','submitRegistrationRequest','activateRegistration','submitPinResetRequest','completePinReset'].includes(method)){
  const actions={getPublicRegistrationContext:'registrationContext',submitRegistrationRequest:'registrationSubmit',activateRegistration:'registrationActivate',submitPinResetRequest:'resetSubmit',completePinReset:'resetComplete'};
  const payload=method==='activateRegistration'||method==='completePinReset'?{loginId:args[0],code:args[1],newPin:args[2]}:method==='submitPinResetRequest'?{loginId:args[0]}:args[0]||{};
  return rpc(env,'tower_person_action_261',{p_engine:'onboarding',p_action:actions[method],p_token:'',p_payload:payload});
 }
 if(method==='logoutCurrentSession'){await rpc(env,'tower_logout',{p_token:String(args[0]||token)});return {success:true};}
 if(method==='apiCall'){const inner=args[0]||{};if(!strictName(inner.name))throw Error('INVALID_OPERATION');const u=await sessionUser(env,inner.token);if(!u)throw Error('SESSION_REQUIRED');
  if(u.must_change_pin&&inner.name!=='changeMyPin')throw Error('PIN_CHANGE_REQUIRED');
  // Explicit allowlist only. Missing workflows must never fall through to unsafe DB CRUD.
  if(inner.name==='telegramSettings')return telegramUserAction(env,{...u,_tg_session_token:inner.token},String(inner.args?.[0]||''),inner.args?.[1]||{});
  if(inner.name==='changeMyPin'){const out=await rpc(env,'tower_change_pin',{p_token:inner.token,p_old:String(inner.args?.[0]||''),p_new:String(inner.args?.[1]||'')});if(out!==true)throw Error('تعذر تغيير PIN');return {success:true};}
  if(inner.name==='getResidentUnitDuesSummary'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const unitId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_resident_unit_dues_summary_243',{p_token:inner.token,p_unit_id:unitId});
  }
  if(inner.name==='getResidentDuesPage'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   const mode=String(payload.mode||'page'),group=String(payload.group||'current'),status=String(payload.status||''),search=String(payload.search||'');
   const offset=Number(payload.offset??0),limit=Number(payload.limit??10);
   if(!['page','summary'].includes(mode)||!['current','archive'].includes(group)||
      !['','OPEN','PARTIAL','OVERDUE','PAID'].includes(status)||search.length>100||
      !Number.isSafeInteger(offset)||offset<0||offset>1000000||!Number.isSafeInteger(limit)||limit<1||limit>20)
     throw Error('INVALID_OPERATION');
   const target=String(payload.unitId||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(target))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_resident_dues_page_for_unit',{p_token:inner.token,p_unit_id:target,p_mode:mode,p_group:group,
    p_search:search,p_status:status,p_offset:offset,p_limit:limit});
  }
  if(['getUnitFundVisibility','setUnitFundVisibility','getResidentBuildingFundSummary'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const unitId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   if(inner.name==='getResidentBuildingFundSummary')
    return rpc(env,'tower_resident_fund_overview_for_unit',{p_token:inner.token,p_unit_id:unitId});
   if(inner.name==='setUnitFundVisibility'&&typeof inner.args?.[1]!=='boolean')throw Error('INVALID_OPERATION');
   return rpc(env,'tower_unit_fund_visibility_action',{
    p_token:inner.token,p_unit_id:unitId,
    p_action:inner.name==='getUnitFundVisibility'?'get':'set',
    p_allow:inner.name==='setUnitFundVisibility'?inner.args[1]:null
   });
  }
  if(['getBuildingFinancialSnapshot','getPdfAutomationSnapshot'].includes(inner.name)){
   if(inner.name==='getBuildingFinancialSnapshot'&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='getPdfAutomationSnapshot'){const plan=await towerPdfDispatchTargets(env);if(!plan.recipients.length)throw Error('PDF_NOT_DUE');}
   const snapshot=await rpc(env,inner.name==='getPdfAutomationSnapshot'?'tower_pdf_automation_snapshot':'tower_building_financial_snapshot',{p_token:inner.token});
   // Presentation metadata is supplementary/current; authoritative snapshot amounts are never overwritten.
   const dueRows=snapshot?.buildingDues?.rows,subRows=snapshot?.subscriptions?.rows,payRows=snapshot?.buildingPayments?.rows;
   if(Array.isArray(dueRows)&&Array.isArray(subRows)){
    try{
     const all=[...dueRows,...subRows,...(payRows||[])],unitIds=[...new Set(all.map(r=>String(r?.unitId||'')).filter(Boolean))];
     const meta=await rpc(env,'tower_report_metadata_241',{p_token:inner.token,p_payload:{unitIds,subscriptions:subRows.map(r=>({unitId:r.unitId,subscriptionId:r.subscriptionId,serviceId:r.serviceId,serviceName:r.serviceName}))}});
     if(meta?.scope!=='REPORT_LABELS_ONLY')throw Error('INVALID_REPORT_METADATA');
     const units=new Map((meta.units||[]).map(u=>[String(u.unitId),u]));
     for(const row of all){const unit=units.get(String(row.unitId));if(unit){for(const key of ['floor','managerName','unitTypeName'])if(unit[key]!=null)row[key]=unit[key];}}
     for(const item of meta.subscriptions||[]){const row=subRows[item.index];if(row){row.serviceKind=item.serviceKind;row.pricingMode=item.pricingMode;}}
     snapshot.presentationMetadata='CURRENT_LABELS';
    }catch(_){snapshot.presentationMetadata='UNAVAILABLE';console.warn('REPORT_LABELS_UNAVAILABLE');}
   }

   return snapshot;
  }
  if(['getReportCatalog','getReportData'].includes(inner.name)){
   if(u.role==='RESIDENT')throw Error('FORBIDDEN');
   const action=inner.name==='getReportCatalog'?'catalog':'data';
   const payload=action==='catalog'?{}:{reportId:inner.args?.[0]};
   return rpc(env,'tower_report_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['getNotificationCenter340','readTripNotice340','readNotificationSource350','readAllNotifications350'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='readTripNotice340'){
    if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
    return rpc(env,'tower_notice_history_259',{p_token:inner.token,p_action:'read',p_payload:{noticeKey:'trip:'+String(inner.args?.[0]||''),revision:String(inner.args?.[1]||'')}});
   }
   const action=({getNotificationCenter340:'list',readNotificationSource350:'readSource',readAllNotifications350:'readAll'})[inner.name];
   return rpc(env,'tower_notifications_259',{p_token:inner.token,p_action:action,p_payload:action==='readSource'?(inner.args?.[0]||{}):{}});
  }
  if(['listMyNotifications','markNotificationRead'].includes(inner.name)){
   const action=inner.name==='listMyNotifications'?'list':'read';
   const payload=action==='list'?{limit:inner.args?.[0]}:{notificationId:inner.args?.[0]};
   const result=await rpc(env,'tower_notifications_259',{p_token:inner.token,p_action:action,p_payload:payload});return action==='list'?result.notifications:result;
  }
  if(['getMyUiPreferences','saveMyUiPreferences'].includes(inner.name)){return rpc(env,'tower_personal_ui_preferences_248',{p_token:inner.token,p_action:inner.name==='getMyUiPreferences'?'get':'save',p_payload:inner.name==='getMyUiPreferences'?{}:(inner.args?.[0]||{})});}
  if(inner.name==='getPendingActions300')return readPendingActions300(env,inner.token,u);
  if(['getUiPreferences','adminUpdateUiPreferences'].includes(inner.name)){
   if(inner.name==='adminUpdateUiPreferences'&&u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_ui_preferences_action',{p_token:inner.token,p_action:inner.name==='getUiPreferences'?'get':'update',p_payload:inner.name==='getUiPreferences'?{}:(inner.args?.[0]||{})});
  }
  if(inner.name==='getMyCoreProfile'){
   const membership=u.role==='RESIDENT'?await db(env,'tower_members?select=unit_id,member_role,relation&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null&limit=1'):[];
   return {userId:u.user_id,displayName:workerPersonName(u),preferredTitle:u.title,name:u.name,role:u.role,roleLabel:canonicalUser(u).roleLabel,loginId:u.login_id,membership:membership[0]||null};
  }
  if(inner.name==='adminListRegistrationRequests'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const records=await rpc(env,'tower_person_action_261',{p_engine:'onboarding',p_action:'registrationList',p_token:inner.token,p_payload:{}});
   const opinions=await db(env,'tower_registration_requests?select=request_id,manager_opinion,manager_opinion_at,manager_opinion_note,manager_opinion_by');
   const index=new Map(opinions.map(x=>[x.request_id,x]));
   return (Array.isArray(records)?records:[]).map(x=>({...x,managerOpinion:index.get(x.requestId)?.manager_opinion||null,managerOpinionAt:index.get(x.requestId)?.manager_opinion_at||null,managerOpinionNote:index.get(x.requestId)?.manager_opinion_note||'',managerOpinionBy:index.get(x.requestId)?.manager_opinion_by||null}));
  }
  if(['adminListRegistrationRequests','adminApproveRegistrationRequest','adminRejectRegistrationRequest','adminListPinResetRequests','adminIssuePinResetCode'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const actions={adminListRegistrationRequests:'registrationList',adminApproveRegistrationRequest:'registrationApprove',adminRejectRegistrationRequest:'registrationReject',adminListPinResetRequests:'resetList',adminIssuePinResetCode:'resetIssue'};
   const payload=inner.name==='adminRejectRegistrationRequest'?{requestId:inner.args?.[0],notes:inner.args?.[1]}:inner.name.includes('List')?{}:{requestId:inner.args?.[0]};
   return rpc(env,'tower_person_action_261',{p_engine:'onboarding',p_action:actions[inner.name],p_token:inner.token,p_payload:payload});
  }
  if(['createResidentTrip','createGuardTrip','updateMyTrip','updateGuardTrip','updateMyTripDistance','deleteMyTrip','cancelGuardTrip','listTrips'].includes(inner.name)){
   if(inner.name==='listTrips'&&!['RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const action=({createResidentTrip:'create',createGuardTrip:'create',updateMyTrip:'update',updateGuardTrip:'update',updateMyTripDistance:'distance',deleteMyTrip:'cancel',cancelGuardTrip:'cancel',listTrips:'list'})[inner.name];
   if(inner.name==='createResidentTrip'&&u.role!=='RESIDENT'||inner.name==='createGuardTrip'&&u.role!=='OPERATOR'||inner.name==='updateMyTrip'&&u.role!=='RESIDENT'||inner.name==='updateGuardTrip'&&u.role!=='OPERATOR'||inner.name==='updateMyTripDistance'&&u.role!=='RESIDENT'||inner.name==='deleteMyTrip'&&u.role!=='RESIDENT'||inner.name==='cancelGuardTrip'&&u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const payload=inner.name==='updateMyTripDistance'?{tripId:inner.args?.[0],distance:inner.args?.[1]}:
    ['deleteMyTrip','cancelGuardTrip'].includes(inner.name)?{tripId:inner.args?.[0]}:
    inner.name==='listTrips'?{unitId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_trip_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='getOpenTripChangeHistory'){
   if(!['RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const fn=u.role==='OPERATOR'?'tower_guard_open_trip_change_history':'tower_open_trip_change_history';
   return rpc(env,fn,{p_token:inner.token,p_trip_id:inner.args?.[0]});
  }
  if(['getResidentAccountData','addResidentPayment','cancelResidentPayment','closeMyAccount','undoMyLastSettlement','getSettlementDetails','getSettlementPreview','getResidentPaymentDetails'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const actions={getResidentAccountData:'summary',addResidentPayment:'addPayment',cancelResidentPayment:'cancelPayment',closeMyAccount:'close',undoMyLastSettlement:'undo',getSettlementDetails:'details',getSettlementPreview:'preview',getResidentPaymentDetails:'paymentDetails'};
   const payload=inner.name==='addResidentPayment'?{amount:inner.args?.[0],reference:inner.args?.[1]}:
    inner.name==='cancelResidentPayment'?{paymentId:inner.args?.[0],reason:inner.args?.[1]}:
    inner.name==='undoMyLastSettlement'?{reason:inner.args?.[0],expectedSettlementId:typeof inner.args?.[1]==='string'?inner.args[1]:null}:
    inner.name==='getSettlementDetails'?{settlementId:inner.args?.[0]}:
    inner.name==='getResidentPaymentDetails'?{paymentId:inner.args?.[0]}:
    inner.name==='closeMyAccount'?(inner.args?.[0]||{}):{};
   const unitId=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   if(inner.name==='getResidentAccountData'){
    const [account,tripPreferences]=await Promise.all([
     rpc(env,'tower_trip_settlement_action_244',{p_token:inner.token,p_action:'summary',p_payload:{unitId}}),
     rpc(env,'tower_resident_trip_preferences_242',{p_token:inner.token,p_action:'get',p_payload:{unitId}})
    ]);
    return {...account,tripPreferences};
   }
   const fn=['addResidentPayment','cancelResidentPayment'].includes(inner.name)?'tower_trip_account':'tower_trip_settlement_action_244';
   return rpc(env,fn,{p_token:inner.token,p_action:actions[inner.name],p_payload:{...payload,unitId}});
  }
  if(['addPaymentAttachment','getPaymentAttachments','readPaymentAttachment'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action={addPaymentAttachment:'add',getPaymentAttachments:'list',readPaymentAttachment:'read'}[inner.name];
   const payload=action==='add'?{paymentId:inner.args?.[0],...(inner.args?.[1]||{})}:
     action==='list'?{paymentId:inner.args?.[0]}:{attachmentId:inner.args?.[0]};
   if(action==='add'&&JSON.stringify(payload).length>1500000)throw Error('ATTACHMENT_TOO_LARGE');
   return rpc(env,'tower_payment_attachment_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='setCollectionCategoryStatus'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const categoryId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,36}$/i.test(categoryId))throw Error('INVALID_CATEGORY_ID');
   const status=String(inner.args?.[1]||'').toUpperCase()==='INACTIVE'?'INACTIVE':'ACTIVE';
   return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:'categoryStatus',p_payload:{categoryId,status}});
  }
  if(['getUnifiedActivityPage','getUnifiedActivityDetails','getFundEntryDetails'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='getFundEntryDetails')return rpc(env,'tower_fund_entry_read_241',{p_token:inner.token,p_id:inner.args?.[0]});
   return rpc(env,'tower_activity_read_241',{p_token:inner.token,p_action:inner.name==='getUnifiedActivityPage'?'page':'details',p_payload:inner.name==='getUnifiedActivityPage'?(inner.args?.[0]||{}):{auditId:inner.args?.[0]}});
  }
  if(inner.name==='getFinancialAudit'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const n=Number(inner.args?.[0]);
   const limit=Number.isFinite(n)&&n>0?Math.max(10,Math.min(300,Math.trunc(n))):150;
   // Matches the legacy finance audit filters without exposing unrelated audit records.
   const financialActions=['CREATE_BUILDING_CHARGE','RECORD_BUILDING_PAYMENT','CREATE_FINANCE_ENTRY','CANCEL_FINANCE_ENTRY','APPROVE_COLLECTION_REPORT','ADD_PAYMENT_ATTACHMENT'];
   const filters='or=('+financialActions.map(a=>'action.eq.'+a).join(',')+',entity.like.BUILDING_*,entity.like.FINANCE_*,entity.like.COLLECTION_*,entity.like.SERVICE_*)';
   const rows=await db(env,'tower_audit?select=audit_id,actor_id,action,entity,entity_id,at&'+filters+'&order=at.desc&limit='+limit);
   return rows.map(a=>({auditId:a.audit_id,timestamp:a.at,actorUserId:a.actor_id||'',role:'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',unitId:'',before:'',after:'',notes:''}));
  }
  if(['saveCollectionCategory','deactivateCollectionCategory','reactivateCollectionCategory','recordBuildingPayment','getUnitBuildingStatement'].includes(inner.name)){
   if(inner.name==='getUnitBuildingStatement'){
    if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
    if(u.role==='RESIDENT'){const visibility=await rpc(env,'tower_unit_fund_visibility_action',{p_token:inner.token,p_unit_id:inner.args?.[0],p_action:'get',p_allow:null});if(visibility?.canViewAccount!==true){const error=new Error(DB_USER_ERRORS.UNIT_ACCOUNT_ACCESS_DENIED);error.dbCode='UNIT_ACCOUNT_ACCESS_DENIED';throw error;}}
    return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:'statement',p_payload:{unitId:inner.args?.[0]}});
   }
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=inner.name==='saveCollectionCategory'?'saveCategory':inner.name==='recordBuildingPayment'?'recordPayment':'categoryStatus';
   const payload=action==='categoryStatus'?{categoryId:inner.args?.[0],status:inner.name==='deactivateCollectionCategory'?'INACTIVE':'ACTIVE'}:(inner.args?.[0]||{});
   return rpc(env,'tower_finance_extensions',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['cancelMyServiceSubscription','updatePendingServiceSubscription','requestServiceChange','listServiceChangeRequests','reviewServiceChangeRequest'].includes(inner.name)){
   const action={cancelMyServiceSubscription:'cancelPending',updatePendingServiceSubscription:'updatePending',requestServiceChange:'requestChange',listServiceChangeRequests:'list',reviewServiceChangeRequest:'review'}[inner.name];
   if(['cancelPending','updatePending','requestChange'].includes(action)&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(u.role==='RESIDENT'&&['cancelPending','updatePending','requestChange'].includes(action)){const chosen=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(chosen))throw Error('UNIT_REQUIRED');}
   if(['list','review'].includes(action)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=action==='cancelPending'?{subscriptionId:inner.args?.[0]}:action==='updatePending'?{subscriptionId:inner.args?.[0],quantity:inner.args?.[1]}:
    action==='requestChange'?{subscriptionId:inner.args?.[0],type:inner.args?.[1],quantity:inner.args?.[2]}:
    action==='review'?{requestId:inner.args?.[0],decision:inner.args?.[1],notes:inner.args?.[2]}:{};
   if(u.role==='RESIDENT'&&['cancelPending','updatePending','requestChange'].includes(action))payload.unitId=String(inner.args?.at(-1)?.__activeUnitId||'');
   return rpc(env,'tower_service_change_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='adminArchiveResident'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const residentId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(residentId))throw Error('INVALID_RESIDENT_ID');
   return rpc(env,'tower_admin_archive_resident',{p_token:inner.token,p_user_id:residentId});
  }
  if(inner.name==='addServiceSubscribers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||!Array.isArray(payload.unitIds)||payload.unitIds.length<1||payload.unitIds.length>500)throw Error('INVALID_UNIT_IDS');
   if(payload.agreementSource)return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:'enroll',p_service:payload.serviceId,p_payload:{unitIds:payload.unitIds,source:payload.agreementSource,note:payload.agreementNote||''}});
   return rpc(env,'tower_add_service_subscribers',{p_token:inner.token,p_payload:{serviceId:payload.serviceId,unitIds:payload.unitIds,quantity:payload.quantity}});
  }
  if(inner.name==='getServiceWorkspace'){
   const admin=['ADMIN','UNION'].includes(u.role),resident=u.role==='RESIDENT';
   if(!admin&&!resident)throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||''),unit=resident?String(inner.args?.at(-1)?.__activeUnitId||''):null;
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(resident&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unit))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_service_workspace_read_232',{p_token:inner.token,p_service:serviceId,p_unit:unit});
  }
  if(inner.name==='getServiceManagerContext'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   // Use the same authorized service read model as listServices. The old partial
   // table projection silently dropped task classification and finance metadata.
   const services=await rpc(env,'tower_service_finance_action',{p_token:inner.token,p_action:'list',p_payload:{}});
   if(!Array.isArray(services))throw Error('INVALID_SERVICE_CONTEXT');
   const service=services.find(row=>String(row.serviceId)===serviceId);
   if(!service)throw Error('SERVICE_NOT_FOUND');
   const [unitRows,memberships,subRows]=await Promise.all([
    db(env,'tower_units?select=unit_id,unit_number,floor&order=unit_number.asc'),
    db(env,'tower_members?select=unit_id,member_role,tower_users(name,title)&ended_at=is.null'),
    db(env,'tower_service_subscriptions?select=subscription_id,service_id,unit_id,requested_by,status,quantity,unit_price_snapshot,amount_snapshot,billing_timing,auto_renew,requested_at,reviewed_at,started_at,ended_at,next_renewal_at&service_id=eq.'+encodeURIComponent(serviceId)+'&order=requested_at.desc')
   ]);
   if(!Array.isArray(unitRows)||!Array.isArray(memberships)||!Array.isArray(subRows))throw Error('INVALID_SERVICE_CONTEXT');
   const perUnit=new Map();
   for(const m of memberships){
    const entry=perUnit.get(String(m.unit_id))||{managerName:'',memberNames:[]};
    const name=workerPersonName(m.tower_users);
    if(name){entry.memberNames.push(name);if(m.member_role==='MANAGER')entry.managerName=name;}
    perUnit.set(String(m.unit_id),entry);
   }
   const units=unitRows.map(x=>({unitId:x.unit_id,unitNumber:x.unit_number,floor:x.floor||'',managerName:perUnit.get(String(x.unit_id))?.managerName||'',memberNames:perUnit.get(String(x.unit_id))?.memberNames||[]}));
   const unitMap=new Map(units.map(x=>[String(x.unitId),x]));
   const subscriptions=subRows.map(x=>({subscriptionId:x.subscription_id,serviceId:x.service_id,unitId:x.unit_id,requestedByUserId:x.requested_by,status:x.status,quantity:x.quantity,unitPriceSnapshot:Number(x.unit_price_snapshot),amountSnapshot:Number(x.amount_snapshot),billingTiming:x.billing_timing,autoRenew:x.auto_renew,requestedAt:x.requested_at,reviewedAt:x.reviewed_at,startedAt:x.started_at,endedAt:x.ended_at,nextRenewalAt:x.next_renewal_at,unitNumber:unitMap.get(String(x.unit_id))?.unitNumber||'—',floor:unitMap.get(String(x.unit_id))?.floor||'',managerName:unitMap.get(String(x.unit_id))?.managerName||''}));
   await enrichTaskProjects(env,[service]);
   return {service,units,subscriptions};
  }
  if(inner.name==='listServiceBeneficiaries'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const rows=await db(env,'tower_users?select=user_id,name,title,custom_title,role&status=eq.ACTIVE&order=name.asc&limit=300');
   return (rows||[]).map(x=>({userId:x.user_id,name:x.name,firstName:x.first_name_261||String(x.name||'').split(/\s+/)[0],restName:x.rest_name_261??String(x.name||'').split(/\s+/).slice(1).join(' '),title:x.title,customTitle:x.custom_title,displayName:workerPersonName(x),role:x.role}));
  }
  if(['listServices','getMyServices','saveService','setServiceStatus','requestServiceSubscription','listServiceSubscriptionRequests','reviewServiceSubscription'].includes(inner.name)){
   const action=({listServices:'list',getMyServices:'mine',saveService:'save',setServiceStatus:'status',requestServiceSubscription:'request',listServiceSubscriptionRequests:'requests',reviewServiceSubscription:'review'})[inner.name];
   if(['save','status','requests','review'].includes(action)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(['mine','request'].includes(action)&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(action==='mine'){
    const unitId=String(inner.args?.[0]?.__activeUnitId||'');
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
    const result=await rpc(env,'tower_unit_services_read_for_unit',{p_token:inner.token,p_unit_id:unitId});
   const visibility=await rpc(env,'tower_unit_fund_visibility_action',{p_token:inner.token,p_unit_id:unitId,p_action:'get',p_allow:null});
   const accountVisible=visibility?.canViewAccount===true;result.unitAccountVisible=accountVisible;

   // Public ACTIVE services only; financial allocation amounts remain server-authoritative.
   if(Array.isArray(result?.services)&&result.services.length){
    const ids=result.services.map(x=>String(x.serviceId||'')).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
    for(let z=0;z<ids.length;z+=80){
     const rows=await db(env,'tower_services?select=service_id,service_kind,pricing_mode,total_budget,enrollment_status&status=eq.ACTIVE&service_id=in.('+ids.slice(z,z+80).map(encodeURIComponent).join(',')+')');
     const byId=new Map((rows||[]).map(x=>[String(x.service_id),x]));
     for(const svc of result.services){const row=byId.get(String(svc.serviceId));if(!row)continue;svc.serviceKind=row.service_kind;svc.pricingMode=row.pricing_mode;svc.totalBudget=row.total_budget;svc.enrollmentStatus=row.enrollment_status;}
    }
   }
   // Snapshot scope is enforced by SQL membership. Enrich only identities tied to subscriptions in that snapshot.
   const subscriptions=Array.isArray(result?.subscriptions)?result.subscriptions:[];
   const subIds=[...new Set(subscriptions.map(x=>String(x.subscriptionId||'')).filter(x=>/^[0-9a-f-]{36}$/i.test(x)))];
   if(subIds.length){
    const byId=new Map();
    for(let i=0;i<subIds.length;i+=80){
     const chunk=subIds.slice(i,i+80);
     const rows=await db(env,'tower_service_subscriptions?select=subscription_id,unit_id,requested_by&unit_id=eq.'+encodeURIComponent(unitId)+'&subscription_id=in.('+chunk.map(encodeURIComponent).join(',')+')');
     for(const row of rows||[])if(String(row.unit_id)===unitId)byId.set(String(row.subscription_id),String(row.requested_by||''));
    }
    const userIds=[...new Set([...byId.values()].filter(x=>/^[0-9a-f-]{36}$/i.test(x)))];
    const users=new Map();
    for(let i=0;i<userIds.length;i+=80){
     const rows=await db(env,'tower_users?select=user_id,name,title,role&user_id=in.('+userIds.slice(i,i+80).map(encodeURIComponent).join(',')+')');
     for(const x of rows||[])users.set(String(x.user_id),x);
    }
    for(const sub of subscriptions){
     const id=byId.get(String(sub.subscriptionId));const person=users.get(id);
     if(person){sub.requestedByName=[person.title,person.name].filter(Boolean).join(' ');sub.requestedByRole=person.role==='RESIDENT'?'ساكن':person.role==='ADMIN'?'إدارة النظام':person.role==='UNION'?'الاتحاد':person.role==='OPERATOR'?'أمين':'';}
    }
   }
   await enrichTaskProjects(env,result.services,unitId);
   for(const svc of result.services||[]){if(!accountVisible||svc.pricingMode!=='SHARED_TOTAL')continue;try{const detail=await rpc(env,'tower_task_project_read_230',{p_token:inner.token,p_service:svc.serviceId,p_unit:unitId});svc.totalBudget=detail.totalBudget;svc.activeSubscriberCount=detail.activeCount;svc.responsibleName=detail.responsibleName;if(svc.project)svc.project.ownEstimatedShare=detail.estimatedShare;const own=(detail.project?.agreed_amounts||[])[0];if(own&&svc.project)svc.project.ownAgreedAmount=own.amount;}catch(_){svc.taskProjectUnavailable=true;}}

   for(const svc of result.services||[]){svc.unitAccountVisible=accountVisible;if(!accountVisible){delete svc.unitTaskFinance;if(svc.project){delete svc.project.ownEstimatedShare;delete svc.project.ownAgreedAmount;}}}
   if(!accountVisible){for(const sub of result.subscriptions||[]){delete sub.amountSnapshot;delete sub.unitPriceSnapshot;delete sub.balance;}return result;}
   // Read balances only after the existing unit-scoped RPC authorizes membership.
   const tasks=(result.services||[]).filter(s=>s.serviceKind==='ONE_TIME'&&s.pricingMode==='SHARED_TOTAL'&&s.enrollmentStatus==='FINALIZED');
   if(tasks.length){
    for(const task of tasks)task.unitTaskFinance={state:'UNAVAILABLE'};
    try{
     const ledger=await rpc(env,'tower_unit_task_balances_read_for_unit',{p_token:inner.token,p_unit_id:unitId});
     if(ledger?.unitId!==unitId||ledger.scope!=='UNIT_TASK_DUES'||ledger.readOnly!==true||!Array.isArray(ledger.rows))throw Error('INVALID_UNIT_TASK_LEDGER');
     const balances=new Map();
     for(const row of ledger.rows){
      const cents=value=>{if(value===null||value===''||typeof value==='boolean')throw Error('INVALID_TASK_AMOUNT');const n=Number(value),c=Math.round(n*100);if(!Number.isFinite(n)||!Number.isSafeInteger(c)||Math.abs(n*100-c)>0.001)throw Error('INVALID_TASK_AMOUNT');return c;};
      const due=cents(row.due),paid=cents(row.paid),remaining=cents(row.remaining),credit=cents(row.credit??0),refunded=cents(row.refunded??0);
      if(!/^[0-9a-f-]{36}$/i.test(String(row.serviceId))||balances.has(row.serviceId)||due<0||paid<0||remaining<0||credit<0||refunded<0||due-paid!==remaining-credit||!Number.isSafeInteger(Number(row.dueCount))||(Number(row.dueCount)<0||(Number(row.dueCount)===0&&(due!==0||paid!==0))))throw Error('INVALID_UNIT_TASK_LEDGER');
      balances.set(row.serviceId,{state:'RECORDED',due:due/100,paid:paid/100,remaining:remaining/100,...(credit?{credit:credit/100}:{}),...(refunded?{refunded:refunded/100}:{})});
     }
     for(const task of tasks)task.unitTaskFinance=balances.get(task.serviceId)||{state:'NOT_RECORDED'};
    }catch(e){console.warn('UNIT_TASK_BALANCES_UNAVAILABLE');}
   }
   return result;
   }
   if(u.role==='RESIDENT'&&action==='request'&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(inner.args?.at(-1)?.__activeUnitId||'')))throw Error('UNIT_REQUIRED');
   const payload=action==='request'?{serviceId:inner.args?.[0],quantity:inner.args?.[2]}:
    action==='status'?{serviceId:inner.args?.[0],status:inner.args?.[1]}:
    action==='review'?{subscriptionId:inner.args?.[0],decision:inner.args?.[1],notes:inner.args?.[2]}:
    action==='save'?(inner.args?.[0]||{}):{};
   if(u.role==='RESIDENT'&&action==='request')payload.unitId=String(inner.args?.at(-1)?.__activeUnitId||'');
   if(action==='requests')return rpc(env,'tower_service_requests_230',{p_token:inner.token});
   const output=await rpc(env,(['save','list'].includes(action)?'tower_service_finance_action':'tower_services_action'),{p_token:inner.token,p_action:action,p_payload:payload});
   if(action==='list'&&Array.isArray(output)){await enrichTaskProjects(env,output);for(const svc of output){if(!svc.project)continue;try{const detail=await rpc(env,'tower_service_edit_context_230',{p_token:inner.token,p_service:svc.serviceId});svc.totalBudget=detail.totalBudget;}catch(_){svc.taskProjectUnavailable=true;}}}
   return output;
  }
  if(['getServiceEditContext','editManagedService','previewManagedServiceEdit','getPersonalCollectionDues','collectPersonalDue'].includes(inner.name)){
   const edit=['getServiceEditContext','editManagedService','previewManagedServiceEdit'].includes(inner.name);
   if(edit&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(!edit&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='getServiceEditContext')return rpc(env,'tower_service_edit_context_230',{p_token:inner.token,p_service:inner.args[0]});
   if(inner.name==='previewManagedServiceEdit')return rpc(env,'tower_service_edit_preview_230',{p_token:inner.token,p_payload:inner.args[0]});
   if(inner.name==='editManagedService')return rpc(env,'tower_service_edit_230',{p_token:inner.token,p_payload:inner.args[0]});
   return rpc(env,'tower_personal_collections_230',{p_token:inner.token,p_action:inner.name==='collectPersonalDue'?'collect':'read',p_payload:inner.args?.[0]||{}});
  }
  if(['getTaskProject','createTaskProject','taskProjectAction'].includes(inner.name)){
   const admin=['ADMIN','UNION'].includes(u.role),resident=u.role==='RESIDENT';
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const create=inner.name==='createTaskProject',read=inner.name==='getTaskProject';
   if(create&&!admin)throw Error('FORBIDDEN');
   const id=create?null:String(inner.args?.[0]||'');
   if(!create&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(id))throw Error('INVALID_SERVICE_ID');
   const scope=String(inner.args?.at(-1)?.__activeUnitId||'');
   if(resident&&!read&&['interest','confirm_refund','confirm_donation_return'].includes(String(inner.args?.[1]||''))&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(scope))throw Error('UNIT_REQUIRED');
   if(read)return rpc(env,'tower_task_workspace_read_231',{p_token:inner.token,p_service:id,p_unit:resident?(scope||null):null});
   const action=create?'create':String(inner.args?.[1]||'');
   const allowed=['close_finalize','create','interest','terms','publish','cancel','agreement','enroll','preview','finalize','expense_draft','expense_approve','expense_pay','expense_cancel','adjustment_cancel','donation','collect','confirm_refund','confirm_donation_return','donation_return','cancel_donation_return','cancel_refund','revoke_refund','adjustment_draft','adjustment_approve','refund_authorize','refund_request','close_financial','cancel_settled'];
   if(!allowed.includes(action)||(!admin&&!['interest','confirm_refund','confirm_donation_return','preview','expense_draft','expense_cancel','expense_pay','adjustment_draft','adjustment_cancel','collect'].includes(action)))throw Error('FORBIDDEN');
   if(['donation','donation_return','cancel_donation_return','refund_authorize','refund_request','cancel_refund','revoke_refund','cancel_settled'].includes(action)&&!admin)throw Error('UNION_ONLY');
   const payload=create?{...(inner.args?.[0]||{})}:{...(inner.args?.[2]||{})};
   if(resident&&['interest','confirm_refund','confirm_donation_return'].includes(action))payload.unitId=scope;
   if(create)return rpc(env,'tower_task_create_239',{p_token:inner.token,p_payload:payload});
   return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:action,p_service:id,p_payload:payload});
  }
  if(['listTaskNotices','markTaskNoticeRead'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const isRead=inner.name==='markTaskNoticeRead';
   const id=isRead?String(inner.args?.[0]||''):null;
   if(isRead&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(id))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_notice_action',{p_token:inner.token,p_action:isRead?'read':'list',p_service_id:id});
  }
  if(['listManagedTasks','taskManagementAction','getTaskManagementRequests','saveTaskSchedule'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='saveTaskSchedule'){
    if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
    if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(inner.args?.[0]||'')))throw Error('INVALID_SERVICE_ID');
    return rpc(env,'tower_task_schedule_save_236',{p_token:inner.token,p_service:inner.args?.[0],p_payload:inner.args?.[1]||{}});
   }
   const assigned=inner.name==='listManagedTasks',action=assigned?'assigned':inner.name==='getTaskManagementRequests'?'requests':String(inner.args?.[1]||'');
   if(!['assigned','requests','request','review_request','member_enroll','member_review','member_remove'].includes(action))throw Error('INVALID_ACTION');
   return rpc(env,'tower_task_management_236',{p_token:inner.token,p_action:action,p_service:assigned?null:inner.args?.[0],p_payload:inner.name==='taskManagementAction'?(inner.args?.[2]||{}):{}});
  }
  if(['getTaskControls','saveTaskControls','getTaskInstallmentSetup'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_controls_235',{p_token:inner.token,p_service:serviceId,p_action:({getTaskControls:'read',saveTaskControls:'save',getTaskInstallmentSetup:'preview'})[inner.name],p_payload:inner.name==='saveTaskControls'?(inner.args?.[1]||{}):{}});
  }
  if(['listTaskInstallments','installTaskInstallments'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const install=inner.name==='installTaskInstallments';
   if(install&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(!install){const unit=u.role==='RESIDENT'?String(inner.args?.at(-1)?.__activeUnitId||''):null;if(u.role==='RESIDENT'&&!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(unit))throw Error('UNIT_REQUIRED');return rpc(env,'tower_task_workspace_installments_231',{p_token:inner.token,p_service:serviceId,p_unit:unit});}
   return rpc(env,'tower_task_controls_235',{p_token:inner.token,p_service:serviceId,p_action:'install',p_payload:inner.args?.[1]||{}});
  }
  if(inner.name==='postTaskFundContribution'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_fund_contribute_216',{p_token:inner.token,p_service_id:serviceId});
  }
  if(['confirmTaskFundReceipt','getTaskFundReceiptStatus'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   return rpc(env,'tower_task_fund_receipt_action_217',{p_token:inner.token,p_service_id:serviceId,p_action:inner.name==='confirmTaskFundReceipt'?'confirm':'status'});
  }
  if(['listTaskWorkflows','saveTaskWorkflow'].includes(inner.name)){
   const isSave=inner.name==='saveTaskWorkflow';
   if(isSave&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_task_workflow_action',{p_token:inner.token,p_action:isSave?'save':'list',p_payload:isSave?(inner.args?.[0]||{}):{}});
  }
  if(['previewSharedServiceAllocation','finalizeSharedServiceAllocation','closeSharedServiceEnrollment'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(['finalizeSharedServiceAllocation','previewSharedServiceAllocation'].includes(inner.name)){
    const projects=await db(env,'tower_task_projects?select=service_id&service_id=eq.'+encodeURIComponent(serviceId));
    if(projects?.length)return rpc(env,'tower_task_project_action_229',{p_token:inner.token,p_action:inner.name==='previewSharedServiceAllocation'?'preview':'finalize',p_service:serviceId,p_payload:{}});
   }
   if(inner.name==='closeSharedServiceEnrollment')return rpc(env,'tower_service_shared_enrollment_close',{p_token:inner.token,p_service_id:serviceId});
   return rpc(env,'tower_service_shared_allocation_action',{p_token:inner.token,p_action:inner.name==='previewSharedServiceAllocation'?'preview':'finalize',p_service_id:serviceId});
  }
  if(['reopenSharedServiceEnrollment','removeSharedServiceSubscriber'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const serviceId=String(inner.args?.[0]||'');
   const subscriptionId=inner.name==='removeSharedServiceSubscriber'?String(inner.args?.[1]||''):null;
   const validId=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
   if(!validId.test(serviceId))throw Error('INVALID_SERVICE_ID');
   if(subscriptionId&&!validId.test(subscriptionId))throw Error('INVALID_SUBSCRIPTION_ID');
   return rpc(env,'tower_shared_subscriber_admin_action',{p_token:inner.token,p_action:inner.name==='reopenSharedServiceEnrollment'?'reopen':'remove',p_service_id:serviceId,p_subscription_id:subscriptionId});
  }
  if(inner.name==='generateServiceDues'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_generate_service_dues',{p_token:inner.token,p_as_of:null});
  }
  // V2.5.96 staged personal-service finance integration. Fail closed until a
  // reviewed token-bound database API is installed and tested. Never call the
  // draft *_internal functions with user identifiers supplied by clients.
  if(inner.name==='getPersonalFinanceIntegrationStatus'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   // Read-only API can be tested independently; never infer write readiness.
   try {
    const overview=await rpc(env,'tower_finance_personal_overview',{p_token:inner.token});
    if(!overview||overview.readOnly!==true||overview.scope!=='PERSONAL_SERVICE')throw Error('PERSONAL_FINANCE_INVALID_OVERVIEW');
    const receiptTestEnabled=['ADMIN','UNION'].includes(u.role)&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'
     &&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'
     &&String(env.PERSONAL_FINANCE_RECEIPT_TEST_ENABLED||'')==='true';
    return {available:true,mode:'READ_ONLY_TEST',canRead:true,canMutate:false,canPostPersonalReceipt:receiptTestEnabled,canPostMixedCollection:u.role==='UNION'&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'&&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'&&String(env.PERSONAL_FINANCE_MIXED_COLLECTION_TEST_ENABLED||'')==='true',canRequestPersonalHandover:['ADMIN','UNION'].includes(u.role)&&String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'&&String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE'&&String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')==='true',
     components:{schema:'TEST_DEPLOYED',trustedApi:'SESSION_BOUND_READ',worker:'READ_ONLY',ui:'READ_ONLY',postgresTests:'NOT_VERIFIED'},
     message:'كشف الخدمات الشخصية متاح للقراءة فقط؛ المعاملات المالية غير مفعّلة.'};
   } catch(error) {
    // Do not swallow an actual credential error, only absence of the optional API.
    const code=String(error?.message||error||'');
    if(/SESSION_REQUIRED|FORBIDDEN|INVALID_TOKEN/.test(code))throw error;
    return {available:false,mode:'NOT_DEPLOYED',canRead:false,canMutate:false,
     components:{schema:'DRAFT',trustedApi:'NOT_READY',worker:'GUARDED',ui:'READ_ONLY',postgresTests:'NOT_RUN'},
     message:'الحسابات الشخصية للخدمات قيد التجهيز ولم تُفعّل على قاعدة البيانات.'};
   }
  }
  if(inner.name==='getPersonalFinanceLedger'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const overview=await rpc(env,'tower_finance_personal_overview',{p_token:inner.token});
   if(overview?.scope!=='PERSONAL_SERVICE'||overview?.readOnly!==true||!Array.isArray(overview.accounts))throw Error('PERSONAL_FINANCE_INVALID_OVERVIEW');
   return overview;
  }
  // Read-only, session-bound pending handovers: the database filters rows to the
  // actual sender or recipient. No user/account selection supplied by client.
  if(inner.name==='listMyPersonalPendingHandovers'){
   if(!['ADMIN','UNION','OPERATOR','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   if(String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()!=='staging'
      ||String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')!=='ISOLATED_TEST_DATABASE'
      ||String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   return rpc(env,'tower_finance_my_pending_handovers',{p_token:inner.token});
  }
  // Staging read API for pending UNIT_REFUND movements. PostgreSQL enforces
  // designated recipient + sole current unit manager; never accept unitId.
  if(inner.name==='listMyPendingPersonalRefunds'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()!=='staging'
      ||String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')!=='ISOLATED_TEST_DATABASE'
      ||String(env.PERSONAL_FINANCE_REFUND_RESOLUTION_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   return rpc(env,'tower_finance_my_pending_refunds',{p_token:inner.token});
  }
  // A single finance feature flag is NEVER enough to enable money movement.
  // Require an explicit isolated staging deployment declaration as well.
  const financeStaging=String(env.TOWER_DEPLOYMENT_ENV||'').toLowerCase()==='staging'
    && String(env.PERSONAL_FINANCE_STAGING_CONFIRM||'')==='ISOLATED_TEST_DATABASE';
  // Stage 1 trusted handover RPC: explicitly opt-in ONLY on isolated test deployments.
  // Both Worker and database check roles; session identity is resolved in PostgreSQL.
  if(['requestPersonalCashHandover','confirmPersonalCashHandover','cancelPersonalCashHandover'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_HANDOVER_TEST_ENABLED||'')==='true'){
   const action={requestPersonalCashHandover:'request',confirmPersonalCashHandover:'confirm',cancelPersonalCashHandover:'cancel'}[inner.name];
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
   if(action==='request'&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   // Strict staging request contract; the database remains the authority for balances,
   // identity, account ownership and concurrent movement locks.
   const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
   if(action==='request'){
    if(Object.keys(payload).some(k=>!['accountId','recipientId','amount','kind'].includes(k))
      ||!uuid.test(payload.accountId||'')||!uuid.test(payload.recipientId||'')
      ||typeof payload.amount!=='string'||!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(payload.amount)
      ||Number(payload.amount)<=0||!Number.isFinite(Number(payload.amount))
      ||!['BENEFICIARY_DELIVERY','BENEFICIARY_HANDOVER'].includes(payload.kind))throw Error('INVALID_HANDOVER_FIELDS');
   }else{
    if(Object.keys(payload).some(k=>k!=='movementId')||!uuid.test(payload.movementId||''))throw Error('INVALID_MOVEMENT_ID');
   }
   return rpc(env,'tower_finance_handover_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  // Session-bound personal receipt posting, test deployment only. NEVER enabled by default.
  if(inner.name==='postPersonalServiceReceipt'
      && financeStaging && String(env.PERSONAL_FINANCE_RECEIPT_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_PAYLOAD');
   if(Object.keys(payload).some(k=>!['unitId','amount','portions','externalReference'].includes(k)))throw Error('INVALID_RECEIPT_FIELDS');
   // Reject malformed money instructions BEFORE the database RPC. PostgreSQL
   // remains authoritative for account ownership, concurrency and ledger writes.
   const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
   const cents=v=>{
    if(typeof v!=='string'||!/^\d+(?:\.\d{1,2})?$/.test(v))return null;
    const parts=v.split('.');const n=Number(parts[0])*100+Number((parts[1]||'').padEnd(2,'0'));
    return Number.isSafeInteger(n)&&n>0?n:null;
   };
   if(typeof payload.unitId!=='string'||!uuid.test(payload.unitId))throw Error('INVALID_RECEIPT_FIELDS');
   const total=cents(payload.amount);
   if(total===null||!Array.isArray(payload.portions)||!payload.portions.length||payload.portions.length>100)
    throw Error('INVALID_RECEIPT_FIELDS');
   const ids=new Set();let allocated=0;
   for(const portion of payload.portions){
    if(!portion||typeof portion!=='object'||Array.isArray(portion)||
       Object.keys(portion).some(k=>!['account_id','amount'].includes(k))||
       !uuid.test(String(portion.account_id||'')))throw Error('INVALID_PORTION');
    const amount=cents(portion.amount);
    if(amount===null)throw Error('INVALID_PORTION');
    const id=portion.account_id.toLowerCase();
    if(ids.has(id))throw Error('DUPLICATE_ACCOUNT');
    ids.add(id);allocated+=amount;
    if(!Number.isSafeInteger(allocated))throw Error('INVALID_RECEIPT_AMOUNT');
   }
   if(allocated!==total)throw Error('RECEIPT_SUM_MISMATCH');
   if(typeof payload.externalReference!=='string'||payload.externalReference.trim().length<16||payload.externalReference.trim().length>128)
    throw Error('RECEIPT_REFERENCE_REQUIRED');
   return rpc(env,'tower_finance_personal_receipt_action',{p_token:inner.token,p_payload:payload});
  }
  // Staging-only UNION approval. Never enabled for production by default.
  if(['listPersonalRefundApprovals','approvePersonalUnitRefund'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_APPROVAL_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   if(inner.name==='listPersonalRefundApprovals')
    return rpc(env,'tower_finance_refund_approval_action',{p_token:inner.token,p_action:'list',p_payload:{}});
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(String(payload.subscriptionId||''))
      ||!/^\d+(\.\d{1,2})?$/.test(String(payload.amount||''))
      ||!/^\d{4}-\d{2}-\d{2}$/.test(String(payload.effectiveDate||'')))throw Error('INVALID_APPROVAL_FIELDS');
   return rpc(env,'tower_finance_refund_approval_action',{p_token:inner.token,p_action:'approve',
    p_payload:{subscriptionId:payload.subscriptionId,amount:String(payload.amount),effectiveDate:payload.effectiveDate}});
  }
  // STAGING ONLY: exact advance-attributed refund request. Authorization is not minted here.
  if(inner.name==='requestPersonalUnitRefund'
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_REQUEST_TEST_ENABLED||'')==='true'){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||typeof payload.authorizationId!=='string'
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(payload.authorizationId)
      ||!/^([0-9]+)(\.[0-9]{1,2})?$/.test(String(payload.amount??'')))throw Error('INVALID_REFUND_FIELDS');
   return rpc(env,'tower_finance_request_unit_refund_action',{p_token:inner.token,p_payload:{authorizationId:payload.authorizationId,amount:String(payload.amount)}});
  }
  // Staging-only refund resolution. Creation/approval remain blocked until exact
  // unused subscription prepayment and UNION-approved eligibility are proven.
  if(['confirmPersonalUnitRefund','cancelPersonalUnitRefund'].includes(inner.name)
      && financeStaging && String(env.PERSONAL_FINANCE_REFUND_RESOLUTION_TEST_ENABLED||'')==='true'){
   const action=inner.name==='confirmPersonalUnitRefund'?'confirm':'cancel';
   if(action==='confirm'&&u.role!=='RESIDENT')throw Error('FORBIDDEN');
   if(action==='cancel'&&!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||typeof payload.movementId!=='string'
      ||!/^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(payload.movementId))throw Error('INVALID_MOVEMENT_ID');
   return rpc(env,'tower_finance_refund_action',{p_token:inner.token,p_action:action,p_payload:{movementId:payload.movementId}});
  }
  if(['listPersonalRefundApprovals','approvePersonalUnitRefund',
      'postPersonalServiceReceipt',
      'requestPersonalCashHandover','confirmPersonalCashHandover',
      'cancelPersonalCashHandover','requestPersonalUnitRefund',
      'confirmPersonalUnitRefund','cancelPersonalUnitRefund'].includes(inner.name)){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
  }
  if(inner.name==='getFundPage'){if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');return rpc(env,'tower_fund_page_239',{p_token:inner.token,p_payload:inner.args?.[0]||{}});}
  if(inner.name==='getFinanceContext'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   // State table has no direct SELECT grant. Use the existing session-authorized definer RPC.
   const [context,units,states]=await Promise.all([rpc(env,'tower_finance_context',{p_token:inner.token}),db(env,'tower_units?select=unit_id,status,state_id_262,tower_unit_types(color_264)'),rpc(env,'tower_unit_states_262',{p_token:inner.token,p_action:'list',p_payload:{}})]);
   if(!Array.isArray(states))throw Error('UNIT_METADATA_UNAVAILABLE');
   const meta=new Map(units.map(x=>[String(x.unit_id),x])),stateMap=new Map(states.map(x=>[String(x.stateId),x]));
   return {...context,units:(context.units||[]).map(unit=>{const m=meta.get(String(unit.unitId)),state=m&&stateMap.get(String(m.state_id_262));if(!m||!state||typeof state.exemptBuilding!=='boolean')throw Error('UNIT_METADATA_UNAVAILABLE');return {...unit,status:m.status,stateId:m.state_id_262,stateName:state.name,stateColor:state.color,exemptBuilding:state.exemptBuilding,unitTypeColor:m.tower_unit_types?.color_264||'#2f80ed'};})};
  }
  if(inner.name==='listCollectionCategories'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_collection_categories_list',{p_token:inner.token,p_include_inactive:inner.args?.[0]===true});
  }
  if(['createBuildingCharge','listManagedCharges','getBuildingChargeDetails','editBuildingCharge','cancelBuildingCharge'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action={createBuildingCharge:'create',listManagedCharges:'list',getBuildingChargeDetails:'details',editBuildingCharge:'edit',cancelBuildingCharge:'cancel'}[inner.name];
   return rpc(env,'tower_charge_manage_240',{p_token:inner.token,p_action:action,p_payload:inner.args?.[0]||{}});
  }
  if(['previewBuildingCharge','listBuildingCharges'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action={previewBuildingCharge:'preview',createBuildingCharge:'create',listBuildingCharges:'list'}[inner.name];
   return rpc(env,'tower_charges_action',{p_token:inner.token,p_action:action,p_payload:inner.args?.[0]||{}});
  }
  if(['getFinanceDashboard','addFinanceEntry','cancelFinanceEntry'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=inner.name==='getFinanceDashboard'?'dashboard':inner.name==='addFinanceEntry'?'entry':'cancel';
   const payload=action==='entry'?(inner.args?.[0]||{}):action==='cancel'?{entryId:inner.args?.[0],reason:inner.args?.[1]}:{};
   return rpc(env,'tower_finance_action',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  // Atomic mixed collection: no client-side two-RPC fallback and no production enablement.
  if(inner.name==='createAndApproveMixedCollection'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   if(!financeStaging||String(env.PERSONAL_FINANCE_MIXED_COLLECTION_TEST_ENABLED||'')!=='true')
    throw Error('PERSONAL_FINANCE_NOT_DEPLOYED');
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
    ||Object.keys(payload).sort().join(',')!=='externalReference,fund,personal'
    ||typeof payload.externalReference!=='string'||payload.externalReference.trim().length<16
    ||payload.externalReference.trim().length>128
    ||!payload.fund||typeof payload.fund!=='object'||Array.isArray(payload.fund)
    ||Object.keys(payload.fund).some(k=>!['lines','notes'].includes(k))
    ||!Array.isArray(payload.fund.lines)||!payload.fund.lines.length||payload.fund.lines.length>100
    ||payload.fund.lines.some(x=>!x||typeof x!=='object'||Array.isArray(x)
       ||Object.keys(x).some(k=>!['unitId','amount','method','note'].includes(k)))
    ||!payload.personal||typeof payload.personal!=='object'||Array.isArray(payload.personal)
    ||Object.keys(payload.personal).some(k=>!['unitId','amount','portions'].includes(k)))
    throw Error('INVALID_MIXED_FIELDS');
   return rpc(env,'tower_finance_mixed_collect_action',{p_token:inner.token,p_payload:payload});
  }
  if(['submitCollectionBatch','getCollectionBatchStatus','listCollectionBatches'].includes(inner.name)){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role)||inner.name==='submitCollectionBatch'&&u.role==='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='submitCollectionBatch'?'post':inner.name==='getCollectionBatchStatus'?'status':'list';
   const payload=action==='list'?(inner.args?.[0]||{}):inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('INVALID_COLLECTION_BATCH');
   if(action!=='list'&&(!/^[A-Za-z0-9_-]{16,64}$/.test(String(payload.reference||''))))throw Error('INVALID_COLLECTION_BATCH');
   if(action==='post'&&(!Array.isArray(payload.lines)||!payload.lines.length||payload.lines.length>100))throw Error('INVALID_COLLECTION_BATCH');
   return rpc(env,'tower_collection_batch_233',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='createAndApproveUnionCollection'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   // FUND collection and PERSONAL services are separate ledgers. Never silently
   // accept a mixed payment through the FUND-only RPC; an atomic mixed RPC
   // must be implemented and audited before enabling such transactions.
   const payload=inner.args?.[0];
   if(!payload||typeof payload!=='object'||Array.isArray(payload)
      ||Object.keys(payload).some(k=>!['lines','notes'].includes(k))
      ||!Array.isArray(payload.lines)||!payload.lines.length
      ||(payload.notes!==undefined&&typeof payload.notes!=='string')
      ||payload.lines.some(line=>!line||typeof line!=='object'||Array.isArray(line)
        ||Object.keys(line).some(k=>!['unitId','amount','method'].includes(k))))
    throw Error('FUND_COLLECTION_ONLY');
   return rpc(env,'tower_union_collect_approve',{p_token:inner.token,p_payload:payload});
  }
  if(['getCollectionContext','getCollectionReport','createCollectionReport','updateCollectionReport','submitCollectionReport','returnCollectionReport','approveCollectionReport'].includes(inner.name)){
   if(!['ADMIN','UNION','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   if(['createCollectionReport','updateCollectionReport','submitCollectionReport'].includes(inner.name)&&u.role==='ADMIN')throw Error('FORBIDDEN');
   if(['returnCollectionReport','approveCollectionReport'].includes(inner.name)&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const actions={getCollectionContext:'context',getCollectionReport:'details',createCollectionReport:'create',updateCollectionReport:'update',submitCollectionReport:'submit',returnCollectionReport:'return',approveCollectionReport:'approve'};
   const payload=inner.name==='getCollectionContext'?{}:
    inner.name==='getCollectionReport'||inner.name==='submitCollectionReport'?{reportId:inner.args?.[0]}:
    inner.name==='createCollectionReport'?(inner.args?.[0]||{}):
    inner.name==='updateCollectionReport'?{reportId:inner.args?.[0],...(inner.args?.[1]||{})}:
    inner.name==='returnCollectionReport'?{reportId:inner.args?.[0],notes:inner.args?.[1]}:
    {reportId:inner.args?.[0],...(inner.args?.[1]||{})};
   const result=await rpc(env,'tower_collection_action',{p_token:inner.token,p_action:actions[inner.name],p_payload:payload});
   return inner.name==='getCollectionContext'?{...result,isUnionCollector:u.role==='UNION'}:result;
  }
  if(inner.name==='getGuardAccounts'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   // Derive current balances from the existing role-checked RPC rather than
   // trusting a unit id from the client or duplicating database permissions.
   const ctx=await rpc(env,'tower_guard_trip_context',{p_token:inner.token});
   const units=new Map((Array.isArray(ctx?.units)?ctx.units:[]).map(unit=>[String(unit.unitId),unit]));
   const accounts=new Map();
   for(const trip of (Array.isArray(ctx?.trips)?ctx.trips:[])){
    const id=String(trip.unitId||'');
    if(!id)continue;
    const unit=units.get(id)||{};
    const existing=accounts.get(id)||{
      unitId:id,unitNumber:unit.unitNumber||trip.unitNumber||'—',
      managerName:unit.managerName||trip.managerName||'—',
      openTripCount:0,purchasesTotal:0
    };
    existing.openTripCount++;
    const amount=Number(trip.purchasesTotal);
    if(!Number.isFinite(amount)||amount<0)throw Error('INVALID_TRIP_AMOUNT');
    existing.purchasesTotal=Math.round((existing.purchasesTotal+amount)*100)/100;
    accounts.set(id,existing);
   }
   return [...accounts.values()].sort((a,b)=>String(a.unitNumber).localeCompare(String(b.unitNumber),'ar',{numeric:true}));
  }
  if(inner.name==='getGuardSettlements'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   // Read-only summary of the latest 30 settlements. Keep the original guard
   // permission; never expose resident-only distance calculations here.
   const records=await db(env,'tower_trip_settlements?select=settlement_id,unit_id,sequence_no,status,settled_by,manager_display_name,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after,settled_at,canceled_at,canceled_by,cancel_reason&order=settled_at.desc&limit=30');
   if(!Array.isArray(records))throw Error('INVALID_SETTLEMENT_RESPONSE');
   const unitIds=[...new Set(records.map(r=>String(r.unit_id||'')).filter(Boolean))];
   const units=unitIds.length?await db(env,'tower_units?select=unit_id,unit_number&unit_id=in.('+unitIds.map(encodeURIComponent).join(',')+')'):[];
   const unitNumbers=new Map((Array.isArray(units)?units:[]).map(x=>[String(x.unit_id),x.unit_number]));
   const num=(v)=>v===null||v===undefined?null:Number(v);
   const mapped=records.map(s=>({
    settlementId:s.settlement_id,unitId:s.unit_id,sequenceNo:s.sequence_no,status:s.status,
    settledAt:s.settled_at,settledByUserId:s.settled_by,
    purchasesTotal:num(s.purchases_total),feesTotal:num(s.fees_total),grossTotal:num(s.gross_total),
    priorPayments:num(s.prior_payments),closingPayment:num(s.closing_payment),
    creditAfter:num(s.credit_after),
    managerDisplayName:s.manager_display_name,managerName:s.manager_display_name||'—',
    unitNumber:unitNumbers.get(String(s.unit_id))||'—',
    canceledAt:s.canceled_at,canceledByUserId:s.canceled_by,cancelReason:s.cancel_reason
   }));
   return decorateTripSettlements244(env,inner.token,mapped);
  }
  if(inner.name==='getGuardSettlementDetails'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const settlementId=String(inner.args?.[0]||'');
   if(!/^[a-f0-9-]{36}$/i.test(settlementId))throw Error('INVALID_SETTLEMENT_ID');
   const result=await db(env,'tower_trip_settlements?select=settlement_id,unit_id,sequence_no,status,manager_display_name,purchases_total,fees_total,gross_total,prior_payments,closing_payment,credit_after,settled_at&settlement_id=eq.'+encodeURIComponent(settlementId)+'&limit=1');
   if(!Array.isArray(result)||!result.length)throw Error('SETTLEMENT_NOT_FOUND');
   const s=result[0];
   const [details,units]=await Promise.all([
    db(env,'tower_trip_settlement_details?select=detail_type,snapshot,amount&settlement_id=eq.'+encodeURIComponent(settlementId)+'&detail_type=eq.TRIP'),
    db(env,'tower_units?select=unit_number&unit_id=eq.'+encodeURIComponent(s.unit_id)+'&limit=1')
   ]);
   const safeDetails=(Array.isArray(details)?details:[]).map(d=>{
    const snapshot=d.snapshot||{};
    const items=Array.isArray(snapshot.items)?snapshot.items.map(it=>({name:String(it.name||''),price:Number(it.price||0)})):[];
    return {type:'TRIP',snapshot:{items,createdAt:snapshot.createdAt,purchasesTotal:Number(snapshot.purchasesTotal||0)},amount:Number(d.amount||0)};
   });
   const output={settlement:{settlementId:s.settlement_id,status:s.status,sequenceNo:s.sequence_no,unitNumber:(Array.isArray(units)&&units[0]?.unit_number)||'—',settledAt:s.settled_at,managerDisplayName:s.manager_display_name,purchasesTotal:Number(s.purchases_total||0),feesTotal:Number(s.fees_total||0),grossTotal:Number(s.gross_total||0),priorPayments:Number(s.prior_payments||0),closingPayment:Number(s.closing_payment||0),creditAfter:Number(s.credit_after||0)},details:safeDetails};
   output.settlement=(await decorateTripSettlements244(env,inner.token,[output.settlement]))[0];return output;
  }
  if(inner.name==='getGuardTripSummary'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   return rpc(env,'tower_guard_trip_summary_247',{p_token:inner.token});
  }
  if(inner.name==='getGuardTripContext'){
   if(u.role!=='OPERATOR')throw Error('FORBIDDEN');
   const context=await rpc(env,'tower_guard_trip_context',{p_token:inner.token});
   if(!Array.isArray(context?.trips)||!context.trips.length)return context;
   // The existing authorized trip read includes notes; enrich only current open
   // trip IDs, without exposing its resident-only distance/fee/account fields.
   try{
    const rows=await rpc(env,'tower_trip_action',{p_token:inner.token,p_action:'list',p_payload:{}});
    if(!Array.isArray(rows))throw Error('INVALID_TRIP_NOTES_RESPONSE');
    const byId=new Map(rows.map(row=>[String(row.tripId),row]));
    return {...context,trips:context.trips.map(trip=>{
     const row=byId.get(String(trip.tripId));
     return {...trip,notes:typeof row?.notes==='string'?row.notes:'',notesUnavailable:!row};
    })};
   }catch(e){
    console.warn('GUARD_TRIP_NOTES_UNAVAILABLE',String(e.dbCode||'UNAVAILABLE').slice(0,16));
    return {...context,trips:context.trips.map(trip=>({...trip,notes:'',notesUnavailable:true}))};
   }
  }
  if(['getMyTripSettings','updateMyTripSettings'].includes(inner.name)){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const unitId=String(inner.args?.at(-1)?.__activeUnitId||'');if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(unitId))throw Error('UNIT_REQUIRED');
   return rpc(env,'tower_resident_trip_preferences_242',{p_token:inner.token,p_action:inner.name==='getMyTripSettings'?'get':'update',p_payload:{...(inner.name==='updateMyTripSettings'?(inner.args?.[0]||{}):{}),unitId}});
  }
  if(inner.name==='adminCreateUser'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_person_action_261',{p_token:inner.token,p_engine:'createUser',p_action:'create',p_payload:inner.args?.[0]||{}});
  }
  // UNION needs unit-member names for the units screen, not the admin account directory.
  if(inner.name==='listUnitPeople'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const users=await db(env,'tower_users?select=user_id,name,title,role,status&order=name.asc');
   const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null');
   const memberships=new Map();for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,name:x.name,firstName:x.first_name_261||String(x.name||'').split(/\s+/)[0],restName:x.rest_name_261??String(x.name||'').split(/\s+/).slice(1).join(' '),title:x.title,titleId:x.title_id||'',customTitle:x.custom_title||'',phone:x.phone||'',email:x.email||'',displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,status:x.status,membership:(memberships.get(x.user_id)||[])[0]||null,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='adminBrandAsset'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};const kind=String(payload.kind||'');
   if(!['logo','main'].includes(kind))throw Error('INVALID_OPERATION');
   if(payload.remove===true){await db(env,'tower_brand_assets?kind=eq.'+kind,{method:'DELETE'});return {success:true};}
   const data=String(payload.data||'');const match=/^data:(image\/(?:webp|jpeg|png));base64,([A-Za-z0-9+/]+={0,2})$/.exec(data);
   if(!match||match[2].length>650000||match[2].length<16)throw Error('INVALID_IMAGE');
   const head=atob(match[2].slice(0,32));const mime=match[1];
   if(!((mime==='image/png'&&head.startsWith('\x89PNG\r\n\x1a\n'))||(mime==='image/jpeg'&&head.startsWith('\xff\xd8\xff'))||(mime==='image/webp'&&head.slice(0,4)==='RIFF'&&head.slice(8,12)==='WEBP')))throw Error('INVALID_IMAGE');
   const prev=await db(env,'tower_brand_assets?select=kind&kind=eq.'+kind+'&limit=1');
   if(prev.length)await db(env,'tower_brand_assets?kind=eq.'+kind,{method:'PATCH',body:{mime,encoded:match[2],updated_at:new Date().toISOString()}});
   else await db(env,'tower_brand_assets',{method:'POST',body:{kind,mime,encoded:match[2]}});
   return {success:true};
  }
  if(inner.name==='welcomeProgress'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const action=String(inner.args?.[0]||'get');
   if(!['get','save'].includes(action))throw Error('INVALID_OPERATION');
   return rpc(env,'tower_welcome_action',{p_token:inner.token,p_action:action,p_payload:inner.args?.[1]||{}});
  }
  if(inner.name==='managerRegistrationOpinion'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_registration_manager_advisory',{p_token:inner.token,p_request_id:payload.requestId,p_opinion:payload.opinion,p_note:payload.note||''});
  }
  if(inner.name==='managerMemberOpinion'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_member_advisory',{p_token:inner.token,p_request_id:payload.requestId,p_opinion:payload.opinion,p_note:payload.note||''});
  }
  if(['adminGetHealthAlertSettings','adminSaveHealthAlertSettings'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   return inner.name==='adminGetHealthAlertSettings'?{settings:await readHealthPrefs(env),monitorEnabled:healthBool(env.HEALTH_MONITOR_ENABLED,false),hasRecipient:!!env.HEALTH_TELEGRAM_CHAT_ID,hasBot:!!env.TELEGRAM_BOT_TOKEN}: {settings:await saveHealthPrefs(env,inner.args?.[0])};
  }
  if(inner.name==='adminSetResidentUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_admin_set_resident_units',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(['adminGetSystemSettings','adminSaveSystemSettings'].includes(inner.name)){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='adminGetSystemSettings'?'get':'save';
   const payload=action==='get'?{}:(inner.args?.[0]||{});
   return rpc(env,'tower_brand_settings_256',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(['adminGetDigestSchedule','adminSaveDigestSchedule'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   if(inner.name==='adminSaveDigestSchedule'){
    const v=String(inner.args?.[0]?.time||'');
    if(!/^(?:[01]\d|2[0-3]):(?:[0-5][05])$/.test(v))throw Error('INVALID_DIGEST_TIME');
    const changed=await db(env,'tower_daily_digest_schedule?singleton=eq.true',{method:'PATCH',body:{send_time:v+':00'}});
    if(!changed.length)throw Error('DIGEST_SCHEDULE_NOT_INSTALLED');
    return {time:String(changed[0].send_time).slice(0,5)};
   }
   const rows=await db(env,'tower_daily_digest_schedule?singleton=eq.true&select=send_time&limit=1');
   if(!rows.length)throw Error('DIGEST_SCHEDULE_NOT_INSTALLED');
   return {time:String(rows[0].send_time).slice(0,5)};
  }
  if(inner.name==='adminRepairMissingManagers'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_admin_repair_missing_managers',{p_token:inner.token});
  }
  if(['adminOperationalResetPreview','adminOperationalReset'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const execute=inner.name==='adminOperationalReset';
   return rpc(env,'tower_operational_reset_391',{p_token:inner.token,p_action:execute?'execute':'preview',p_payload:execute?(inner.args?.[0]||{}):{}});
  }
  if(inner.name==='recurringService391'){
   if(!['ADMIN','UNION'].includes(u.role)||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   return rpc(env,'tower_recurring_admin_391',{p_token:inner.token,p_action:inner.args?.[0],p_payload:inner.args?.[1]||{}});
  }
  if(inner.name==='android390'){
   if(u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   const action=inner.args?.[0],payload=inner.args?.[1]||{};
   if(!['status','subscribe','unsubscribe','test'].includes(action))throw Error('INVALID_ACTION');
   if(['subscribe','test'].includes(action)&&!androidConfig390(env))throw Error('ANDROID_SETUP_REQUIRED');
   return rpc(env,'tower_android_device_390',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='push383'){
   try{if(u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');const action=inner.args?.[0],payload=inner.args?.[1]||{};
   if(action==='prepare'){const c=await pushPrepare383(env,requestOrigin||env.TOWER_APP_PUBLIC_URL||'https://tower-app.islamsallams.workers.dev');return {publicKey:c.publicKey};}
   if(!['status','subscribe','unsubscribe','test'].includes(action))throw Error('INVALID_ACTION');
   if(action==='subscribe'){payload.subscription=validatePushSubscription383(payload.subscription);try{await crypto.subtle.importKey('raw',pushBytes383(payload.subscription.keys.p256dh),{name:'ECDH',namedCurve:'P-256'},false,[]);}catch(_){throw Error('INVALID_PUSH_SUBSCRIPTION');}}
   return await rpc(env,'tower_push_device_383',{p_token:inner.token,p_action:action,p_payload:payload});
   }catch(e){const code=['PGRST202','42883'].includes(e.dbCode)?'PUSH_SETUP_REQUIRED':String(e.message||'');if(Object.hasOwn(DB_USER_ERRORS,code)){const out=Error(DB_USER_ERRORS[code]);out.dbCode=code;throw out;}throw e;}
  }
  if(['adminRestorePlan380','adminRestoreSafety380','adminRestoreExecute380','adminRestoreStatus380'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   const action=({adminRestorePlan380:'preview',adminRestoreSafety380:'safety',adminRestoreExecute380:'execute',adminRestoreStatus380:'status'})[inner.name];
   return rpc(env,'tower_admin_restore_265',{p_token:inner.token,p_action:action,p_payload:inner.args?.[0]||{}});
  }
  if(['adminBackupReadiness','adminCreateEncryptedBackup350','adminRestorePreview350','adminResetScope350','adminDownloadRuntime350'].includes(inner.name)){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   if(inner.name==='adminBackupReadiness')return {ready:true,backupCreated:false,mode:'ENCRYPTED_LOCAL_DOWNLOAD',restoreExecutionEnabled:true,message:'النسخ المشفّر والاستعادة بمعاينة ونسخة أمان متاحان بعد تثبيت SQL265. التصفير في دفعة منفصلة.'};
   if(inner.name==='adminDownloadRuntime350'){
    const filename='Tower_App_V'+APP_VERSION+'.zip',bytes=await downloadPublishedRuntime381();
    let encoded='';for(let i=0;i<bytes.length;i+=16384)encoded+=String.fromCharCode(...bytes.subarray(i,i+16384));
    return {filename,version:APP_VERSION,base64:btoa(encoded),scope:'PUBLISHED_RUNTIME_RELEASE',includesDatabase:false,includesCloudflareSecrets:false};
   }
   const action=({adminCreateEncryptedBackup350:'backup',adminRestorePreview350:'restorePreview',adminResetScope350:'resetPreview'})[inner.name];
   return rpc(env,'tower_admin_data_263',{p_token:inner.token,p_action:action,p_payload:action==='restorePreview'?{backup:inner.args?.[0]}:{}});
  }
  if(inner.name==='adminTelegramQueueProbe'){
   // Creates ONLY a personal INFO notification for the authenticated admin.
   // A real notification trigger and the scheduled queue must deliver it.
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   const linked=await db(env,'tower_telegram_accounts?user_id=eq.'+encodeURIComponent(u.user_id)+'&enabled=eq.true&select=user_id&limit=1');
   if(!linked.length)throw Error('TELEGRAM_NOT_LINKED');
   // Keep a short cooldown, but do not duplicate a still-pending test delivery.
   const recent=await db(env,'tower_notifications?user_id=eq.'+encodeURIComponent(u.user_id)+'&type=eq.SYSTEM_TELEGRAM_PROBE&created_at=gte.'+encodeURIComponent(new Date(Date.now()-60*1000).toISOString())+'&select=notification_id,created_at&order=created_at.desc&limit=1');
   if(recent.length){
    const remaining=Math.max(1,Math.ceil((new Date(recent[0].created_at).getTime()+60*1000-Date.now())/1000));
    return {success:false,blocked:true,reason:'COOLDOWN',retryAfterSeconds:remaining,message:'تم تنفيذ الاختبار مؤخرًا. انتظر قليلًا ثم حاول مجددًا.'};
   }
   const outstanding=await db(env,'tower_telegram_delivery_log?user_id=eq.'+encodeURIComponent(u.user_id)+'&status=in.(PENDING,FAILED)&event_key=like.notification:*&select=event_key,status&order=created_at.desc&limit=30');
   if(outstanding.length){
    const ids=outstanding.map(x=>String(x.event_key||'').split(':')[1]).filter(x=>/^[0-9a-f-]{16,}$/i.test(x));
    if(ids.length){
     const probes=await db(env,'tower_notifications?user_id=eq.'+encodeURIComponent(u.user_id)+'&type=eq.SYSTEM_TELEGRAM_PROBE&notification_id=in.('+ids.map(encodeURIComponent).join(',')+')&select=notification_id&limit=1');
     if(probes.length)return {success:false,blocked:true,reason:'PENDING',message:'يوجد اختبار سابق قيد المعالجة. راجع الطابور قبل إعادة الإرسال.'};
    }
   }
   const inserted=await db(env,'tower_notifications',{method:'POST',body:{user_id:u.user_id,type:'SYSTEM_TELEGRAM_PROBE',title:'اختبار إرسال Telegram التلقائي',body:'هذا إشعار فحص إداري، دون عمليات مالية أو بيانات خاصة.',entity:'',entity_id:''}});
   return {success:true,notificationId:inserted?.[0]?.notification_id||null,message:'تم إنشاء الإشعار. انتظر دورة Cron ثم أعد فحص الطابور.'};
  }
  if(inner.name==='adminTelegramDiagnostics'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   // Read-only aggregate operational health. No Telegram chat ID, token or personal content.
   // Return a sampling warning if the queue exceeds the safe PostgREST page cap.
   const [accounts,jobs]=await Promise.all([
    db(env,'tower_telegram_accounts?select=user_id,enabled&limit=1001'),
    db(env,'tower_telegram_delivery_log?select=status,attempts,created_at,sent_at,next_attempt_at&order=created_at.desc&limit=1001')
   ]);
   // The health record is optional during staged SQL rollout; absence is explicitly shown.
   let cronHealth=null;
   try{const r=await db(env,'tower_telegram_cron_health?health_id=eq.1&select=last_started_at,last_finished_at,last_status,last_jobs_sent,last_jobs_failed,last_digest_error&limit=1');cronHealth=r[0]||null;}
   catch(e){console.error('TELEGRAM_CRON_HEALTH_READ_UNAVAILABLE');}
   const counts={PENDING:0,FAILED:0,SENT:0,CANCELLED:0};
   for(const job of jobs)if(Object.hasOwn(counts,job.status))counts[job.status]++;
   const nowMs=Date.now();
   const overdue=jobs.filter(x=>['PENDING','FAILED'].includes(x.status)&&Number.isFinite(Date.parse(x.next_attempt_at))&&Date.parse(x.next_attempt_at)<nowMs-15*60*1000).length;
   const retriesExhausted=jobs.filter(x=>x.status==='FAILED'&&Number(x.attempts)>=6).length;
   const latestSent=jobs.filter(x=>x.status==='SENT'&&x.sent_at).map(x=>x.sent_at).sort().at(-1)||null;
   return {checkedAt:new Date().toISOString(),linkedAccounts:accounts.length,enabledAccounts:accounts.filter(x=>x.enabled).length,
    totalJobs:jobs.length,counts,latestSent,overdueJobs:overdue,retriesExhausted,
    truncated:accounts.length>=1000||jobs.length>=1000,
    cronConfiguredInSource:true,cronLastRan:cronHealth?.last_started_at||null,cronLastFinished:cronHealth?.last_finished_at||null,cronLastStatus:cronHealth?.last_status||null,cronLastJobsSent:cronHealth?.last_jobs_sent??null,cronLastJobsFailed:cronHealth?.last_jobs_failed??null,cronDigestError:cronHealth?.last_digest_error??null,
    cronNote:cronHealth?'توقيت التنفيذ مسجل من مهمة Cloudflare المجدولة، ولا يثبت بمفرده نجاح تسليم Telegram.':'لا يوجد سجل تشغيل Cron قابل للقراءة. راجع Cloudflare Triggers/Logs.'};
  }
  if(inner.name==='adminMigrationRegistry'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE'||u.must_change_pin)throw Error('FORBIDDEN');
   // Generic migration coverage from the generated source catalog and Supabase's append-only execution ledger.
   // The registry's presence never proves arbitrary legacy SQL was run; missing table is NOT_TESTED, not PASS.
   let rows;
   try{rows=await rpc(env,'tower_migration_registry_read',{});}
   catch(e){return {status:'NOT_TESTED',registryAvailable:false,reason:'REGISTRY_UNAVAILABLE',catalog:MIGRATION_CATALOG,rows:[]};}
   if(!Array.isArray(rows))return {status:'NOT_TESTED',registryAvailable:false,reason:'REGISTRY_BAD_RESPONSE',catalog:MIGRATION_CATALOG,rows:[]};
   const installed=new Map(rows.map(x=>[Number(x.migration_id),x]));
   const checks=MIGRATION_CATALOG.map(x=>{
    const r=installed.get(x.id);
    if(!r)return {...x,status:'NOT_RECORDED',reason:'No execution record; this does not prove it is missing'};
    if(r.filename!==x.filename)return {...x,status:'WARN',reason:'Recorded filename differs',recordedFilename:r.filename};
    return {...x,status:r.verification_state==='APPLIED'?'APPLIED':'DETECTED_UNVERIFIED',appliedAt:r.applied_at||null};
   });
   return {registryAvailable:true,status:checks.some(x=>x.status!=='APPLIED')?'WARN':'PASS',catalogCount:checks.length,checks,recordCount:rows.length,unknownHistorical:'SQL before the registry is not automatically certified; no historical backfill was assumed. SQL 138 needs independent read-only evidence (AUDIT_138_READ_ONLY.sql).'};
  }
  if(inner.name==='adminSystemHealthCheck'){
   if(u.role!=='ADMIN'||u.status!=='ACTIVE')throw Error('FORBIDDEN');
   const mode=String(inner.args?.[0]||'read_only');
   if(!['read_only','rollback_probe'].includes(mode))throw Error('INVALID_OPERATION');
   return rpc(env,'tower_system_diagnostics',{p_token:inner.token,p_mode:mode});
  }
  if(inner.name==='adminRunDiagnostics'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const [users,units,members]=await Promise.all([
    db(env,'tower_users?select=user_id,login_id,role,status&order=user_id.asc&limit=10001'),
    db(env,'tower_units?select=unit_id,unit_number,floor,status&order=unit_id.asc&limit=10001'),
    db(env,'tower_members?select=unit_id,user_id,member_role,ended_at&order=member_id.asc&limit=10001')
   ]);
   if(!Array.isArray(users)||!Array.isArray(units)||!Array.isArray(members))throw Error('DIAGNOSTICS_DATA_ERROR');
   // Never report a clean result from a possibly truncated PostgREST result set.
   if(users.length>=10000||units.length>=10000||members.length>=10000)throw Error('DIAGNOSTICS_TOO_MANY_ROWS');
   const issues=[],logins=new Set(),activeByUser=new Set(),membersByUnit=new Map(),unitKeys=new Set();
   for(const m of members){
    if(m.ended_at!=null)continue;
    activeByUser.add(String(m.user_id));
    const key=String(m.unit_id),a=membersByUnit.get(key)||[];a.push(m);membersByUnit.set(key,a);
   }
   for(const x of users){
    const login=String(x.login_id||'').trim().toLowerCase();
    if(login){
     if(logins.has(login))issues.push({type:'DUPLICATE_LOGIN',severity:'HIGH',label:'معرف دخول مكرر: '+login,entityId:x.user_id});
     logins.add(login);
    }
    if(x.role==='RESIDENT'&&x.status==='ACTIVE'&&!activeByUser.has(String(x.user_id)))
     issues.push({type:'RESIDENT_WITHOUT_UNIT',severity:'HIGH',label:'ساكن نشط بدون عضوية وحدة',entityId:x.user_id});
   }
   for(const x of units){
    if(x.status!=='ACTIVE')continue;
    const key=String(x.floor||'').trim()+'|'+String(x.unit_number||'').trim();
    if(unitKeys.has(key))issues.push({type:'DUPLICATE_UNIT',severity:'HIGH',label:'وحدة مكررة: '+key.replace('|',' / '),entityId:x.unit_id});
    unitKeys.add(key);
    const activeMembers=membersByUnit.get(String(x.unit_id))||[];
    if(activeMembers.length&&!activeMembers.some(m=>m.member_role==='MANAGER'))
     issues.push({type:'MISSING_MANAGER',severity:'MEDIUM',label:'وحدة بها أعضاء بدون مدير',entityId:x.unit_id});
   }
   return {checkedAt:new Date().toISOString(),issueCount:issues.length,issues};
  }
  if(inner.name==='adminPreviewResidentLoginId'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const unitId=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(unitId))throw Error('INVALID_UNIT_ID');
   const units=await db(env,'tower_units?select=unit_id,floor,unit_number,status&unit_id=eq.'+encodeURIComponent(unitId)+'&limit=1');
   const unit=Array.isArray(units)?units[0]:null;
   if(!unit)throw Error('اختر وحدة صحيحة للساكن.');
   const floor=String(unit.floor??'').trim(),number=String(unit.unit_number??'').trim();
   if(!/^[0-9]{1,2}$/.test(floor)||!/^[0-9]{1,2}$/.test(number)||Number(number)<1)throw Error('INVALID_RESIDENT_UNIT_NUMBERING');
   const prefix=floor.padStart(2,'0')+number.padStart(2,'0');
   const users=await db(env,'tower_users?select=login_id&login_id=like.'+prefix+'*&order=login_id.desc&limit=100');
   if(!Array.isArray(users))throw Error('INVALID_LOGIN_CONTEXT');
   let max=0;
   for(const row of users){const login=String(row.login_id||'');if(new RegExp('^'+prefix+'[0-9]{2}$').test(login))max=Math.max(max,Number(login.slice(-2)));}
   if(max>=99)throw Error('RESIDENT_IDS_EXHAUSTED');
   // Preview is advisory: account creation calculates its own ID under a database lock.
   return {loginId:prefix+String(max+1).padStart(2,'0')};
  }
  // Read-only user directory for UNION. Mutating user accounts still requires
  // separately reviewed DB-side authorization, and is NOT enabled here.
  if(inner.name==='unionListUsers'){
   if(u.role!=='UNION')throw Error('FORBIDDEN');
   const [users,members]=await Promise.all([
    db(env,'tower_users?select=user_id,login_id,name,first_name_261,rest_name_261,title,role,status&order=name.asc'),
    db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null')
   ]);
   const memberships=new Map();
   for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,loginId:x.login_id,name:x.name,firstName:x.first_name_261||String(x.name||'').split(/\s+/)[0],restName:x.rest_name_261??String(x.name||'').split(/\s+/).slice(1).join(' '),title:x.title,displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,roleLabel:canonicalUser(x).roleLabel,status:x.status,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='adminListUsers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   let users;
   try{users=await db(env,'tower_users?select=user_id,login_id,name,first_name_261,rest_name_261,title,title_id,custom_title,phone,email,role,status,created_at&order=created_at.desc');}
   catch(e){
    if(!String(e.message||'').includes('[42703]'))throw e;
    // Optional contact columns may be absent until migration 038 is installed.
    try{users=await db(env,'tower_users?select=user_id,login_id,name,first_name_261,rest_name_261,title,title_id,custom_title,role,status,created_at&order=created_at.desc');}
    catch(e2){if(!String(e2.message||'').includes('[42703]'))throw e2;users=await db(env,'tower_users?select=user_id,login_id,name,first_name_261,rest_name_261,title,role,status,created_at&order=created_at.desc');}
   }
   const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null');
   const memberships=new Map();for(const m of members){if(!memberships.has(m.user_id))memberships.set(m.user_id,[]);memberships.get(m.user_id).push({unitId:m.unit_id,memberRole:m.member_role});}
   return users.map(x=>({userId:x.user_id,loginId:x.login_id,name:x.name,firstName:x.first_name_261||String(x.name||'').split(/\s+/)[0],restName:x.rest_name_261??String(x.name||'').split(/\s+/).slice(1).join(' '),title:x.title,titleId:x.title_id||'',customTitle:x.custom_title||'',phone:x.phone||'',email:x.email||'',displayName:[x.title,x.name].filter(Boolean).join(' '),role:x.role,roleLabel:canonicalUser(x).roleLabel,status:x.status,membership:(memberships.get(x.user_id)||[])[0]||null,memberships:memberships.get(x.user_id)||[]}));
  }
  if(inner.name==='updateMyContacts')return rpc(env,'tower_update_my_contacts',{p_token:inner.token,p_phone:inner.args?.[0]?.phone??'',p_email:inner.args?.[0]?.email??''});
  if(['adminUpdateUser','adminResetUserPin','updateMyProfile'].includes(inner.name)){
   const action=({adminUpdateUser:'update',adminResetUserPin:'resetPin',updateMyProfile:'profile'})[inner.name];
   if(action!=='profile'&&!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=action==='resetPin'?{userId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_person_action_261',{p_engine:'account',p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='listTitles'){
   const includeInactive=Boolean(inner.args?.[0]);
   const rows=await db(env,'tower_titles?select=title_id,label,status&order=label.asc'+(includeInactive?'':'&status=eq.ACTIVE'));
   return rows.map(t=>({titleId:t.title_id,label:t.label,normalized:t.label||'',status:t.status,sortOrder:0}));
  }
  if(['adminCreateTitle','adminUpdateTitle','adminSetTitleStatus'].includes(inner.name)){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const action=inner.name==='adminCreateTitle'?'create':inner.name==='adminUpdateTitle'?'update':'status';
   const payload=action==='status'?{titleId:inner.args?.[0],status:inner.args?.[1]}:(inner.args?.[0]||{});
   return rpc(env,'tower_title_mutate',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='listUnitTypes'){
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const inactive=Boolean(inner.args?.[0]);
   const path='tower_unit_types?select=unit_type_id,name,collection_weight,status,sort_order,color_264&order=sort_order.asc,name.asc'+(inactive?'':'&status=eq.ACTIVE');
   let rows;
   try{rows=await db(env,path);}
   catch(e){if(!String(e.message||'').includes('[42703]'))throw e;
    rows=await db(env,'tower_unit_types?select=unit_type_id,name,collection_weight,status,color_264&order=name.asc'+(inactive?'':'&status=eq.ACTIVE'));
   }
   return rows.map(t=>({unitTypeId:t.unit_type_id,name:t.name,collectionWeight:Number(t.collection_weight),color:t.color_264||'#2f80ed',status:t.status,sortOrder:t.sort_order??0}));
  }
  if(['adminCreateUnitType','adminUpdateUnitType','adminDeactivateUnitType','adminReactivateUnitType'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=({adminCreateUnitType:'create',adminUpdateUnitType:'update',adminDeactivateUnitType:'deactivate',adminReactivateUnitType:'reactivate'})[inner.name];
   const payload=(action==='deactivate')?{unitTypeId:inner.args?.[0],replacementUnitTypeId:inner.args?.[1]}:(action==='reactivate')?{unitTypeId:inner.args?.[0]}:(inner.args?.[0]||{});
   return rpc(env,'tower_unit_type_mutate_264',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='adminBulkUpdateResidents'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   return rpc(env,'tower_bulk_update_residents',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='adminBulkUpdateUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_bulk_update_units',{p_token:inner.token,p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='adminBulkCreateResidents'){
   if(u.role!=='ADMIN')throw Error('FORBIDDEN');
   const items=inner.args?.[0];
   if(!Array.isArray(items)||items.length<1||items.length>50)throw Error('INVALID_BULK_RESIDENTS');
   return rpc(env,'tower_bulk_create_residents',{p_token:inner.token,p_items:items});
  }
  if(inner.name==='adminBulkCreateUnits'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const items=inner.args?.[0];
   if(!Array.isArray(items)||items.length<1||items.length>200)throw Error('INVALID_BULK_UNITS');
   return rpc(env,'tower_bulk_create_units',{p_token:inner.token,p_items:items});
  }
  if(['adminCreateUnit','adminUpdateUnit','adminAssignUnitManager','adminAddExistingMember'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const action=({adminCreateUnit:'create',adminUpdateUnit:'update',adminAssignUnitManager:'assignManager',adminAddExistingMember:'addMember'})[inner.name];
   const payload=action==='assignManager'?{unitId:inner.args?.[0],userId:inner.args?.[1]}:action==='addMember'?{unitId:inner.args?.[0],userId:inner.args?.[1],relation:inner.args?.[2]}:(inner.args?.[0]||{});
   return rpc(env,'tower_unit_mutate_262',{p_token:inner.token,p_action:action,p_payload:payload});
  }
  if(inner.name==='requestUnitMember'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload={...(inner.args?.[0]||{})};
   const titleId=String(payload.titleId||'').trim();
   if(titleId==='__OTHER__'){
    const custom=String(payload.customTitle||'').trim();
    if(!custom||custom.length>40)throw Error('اكتب اللقب المخصص (بحد أقصى 40 حرفًا).');
    payload.titleId='';
    payload.customTitle=custom;
    payload.title=custom;
   }else if(titleId){
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(titleId))throw Error('اللقب المختار غير صالح.');
    const rows=await db(env,'tower_titles?select=label&title_id=eq.'+encodeURIComponent(titleId)+'&status=eq.ACTIVE&limit=1');
    if(!rows.length)throw Error('اللقب المختار غير متاح.');
    payload.title=rows[0].label;
    payload.customTitle='';
   }else{
    payload.title=String(payload.title||'').trim();
    payload.customTitle='';
   }
   return rpc(env,'tower_person_action_261',{p_engine:'memberRequest',p_token:inner.token,p_action:'request',p_payload:payload});
  }
  if(inner.name==='updatePendingMemberRequest'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   const payload={...(inner.args?.[0]||{})};
   const titleId=String(payload.titleId||'').trim();
   if(titleId==='__OTHER__'){
    const custom=String(payload.customTitle||'').trim();
    if(!custom||custom.length>40)throw Error('اكتب اللقب المخصص (بحد أقصى 40 حرفًا).');
    payload.titleId='';payload.title=custom;payload.customTitle=custom;
   }else if(titleId){
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(titleId))throw Error('اللقب المختار غير صالح.');
    const rows=await db(env,'tower_titles?select=label&title_id=eq.'+encodeURIComponent(titleId)+'&status=eq.ACTIVE&limit=1');
    if(!rows.length)throw Error('اللقب المختار غير متاح.');
    payload.title=rows[0].label;payload.customTitle='';
   }else throw Error('اختر لقبًا صالحًا.');
   return rpc(env,'tower_person_action_261',{p_engine:'memberUpdate',p_action:'update',p_token:inner.token,p_payload:payload});
  }
  if(inner.name==='adminApproveMemberRequest'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const payload=inner.args?.[0]||{};
   return rpc(env,'tower_person_action_261',{p_engine:'memberApprove',p_action:'approve',p_token:inner.token,p_payload:payload});
  }
  if(inner.name==='adminRejectMemberRequest'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_person_action_261',{p_engine:'memberRequest',p_token:inner.token,p_action:'reject',p_payload:{requestId:inner.args?.[0],notes:inner.args?.[1]||''}});
  }
  if(inner.name==='listUnitMembersForEdit'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'list',p_payload:{unitId:inner.args?.[0]}});
  }
  if(inner.name==='updateUnitMemberRelation'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'relation',p_payload:inner.args?.[0]||{}});
  }
  if(inner.name==='transferUnitManager'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_membership_234',{p_token:inner.token,p_action:'transfer',p_payload:{unitId:inner.args?.[0],userId:inner.args?.[1]}});
  }
  if(inner.name==='listMemberRequests'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   let scope='';
   if(u.role==='RESIDENT'){
     const managed=await db(env,'tower_members?select=unit_id&user_id=eq.'+encodeURIComponent(u.user_id)+'&member_role=eq.MANAGER&ended_at=is.null');
     if(!managed.length)throw Error('FORBIDDEN');
     scope='&unit_id=in.('+managed.map(x=>x.unit_id).join(',')+')';
   }
   const rows=await db(env,'tower_member_requests?select=request_id,unit_id,requested_by,first_name_261,rest_name_261,candidate_name,candidate_title,phone,phone_country,relation,status,created_at,reviewed_at,resulting_user_id,manager_opinion,manager_opinion_at,manager_opinion_note,manager_opinion_by&order=created_at.desc'+scope);
   return rows.map(r=>({requestId:r.request_id,unitId:r.unit_id,requestedByUserId:r.requested_by,firstName:r.first_name_261,restName:r.rest_name_261,name:r.candidate_name,title:r.candidate_title,phone:r.phone,phoneCountry:r.phone_country,relation:r.relation,status:r.status,createdAt:r.created_at,reviewedAt:r.reviewed_at,resultingUserId:r.resulting_user_id,managerOpinion:r.manager_opinion||null,managerOpinionAt:r.manager_opinion_at||null,managerOpinionNote:r.manager_opinion_note||"",managerOpinionBy:r.manager_opinion_by||null}));
  }
  if(inner.name==='listFormerUnitMembers'){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const rows=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at,ended_at,tower_users(name,title),tower_units(unit_number,floor)&ended_at=not.is.null&order=ended_at.desc');
   return rows.map(m=>({
    unitMemberId:m.member_id,userId:m.user_id,unitId:m.unit_id,
    unitNumber:m.tower_units?.unit_number||String(m.unit_id),floor:m.tower_units?.floor||'',
    displayName:workerPersonName(m.tower_users),
    memberRole:m.member_role,relation:m.relation||'',status:'INACTIVE',
    joinedAt:m.joined_at||'',endedAt:m.ended_at||''
   }));
  }
  if(['getActivityFeed','getActivityDetails','searchActivityFeed'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   const select='audit_id,actor_id,action,entity,entity_id,at';
   const base='tower_audit?select='+select;
   // Actor display labels are supplementary: an unavailable profile never blocks the audit feed.
   async function enrichActivityActors(rows){
    const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const ids=[...new Set(rows.map(a=>String(a.actor_id||'')).filter(x=>uuid.test(x)))];
    const unitIds=[...new Set(rows.filter(a=>String(a.entity||'').toUpperCase()==='UNIT').map(a=>String(a.entity_id||'')).filter(x=>uuid.test(x)))];
    let profiles=new Map(),memberships=new Map(),units=new Map();
    if(ids.length){
     try{const users=await db(env,'tower_users?select=user_id,name,title,role&user_id=in.('+ids.join(',')+')');profiles=new Map(users.map(x=>[String(x.user_id),x]));}catch(_ignored){}
     try{const members=await db(env,'tower_members?select=user_id,unit_id,member_role&ended_at=is.null&user_id=in.('+ids.join(',')+')');for(const m of members){const id=String(m.user_id);if(!memberships.has(id))memberships.set(id,[]);memberships.get(id).push(m);}}catch(_ignored){}
    }
    if(unitIds.length){try{const found=await db(env,'tower_units?select=unit_id,unit_number&unit_id=in.('+unitIds.join(',')+')');units=new Map(found.map(x=>[String(x.unit_id),String(x.unit_number||'')]));}catch(_ignored){}}
    return rows.map(a=>{
     const actor=profiles.get(String(a.actor_id))||{};
     const actorUnits=memberships.get(String(a.actor_id))||[];
     const explicit=String(a.entity||'').toUpperCase()==='UNIT'&&units.has(String(a.entity_id));
     // A member's unit is not automatically the unit of this action. Only show context
     // for events whose entity explicitly identifies a unit.
     return {...a,actorDisplayName:workerPersonName(actor),actorRole:actor.role||'',unitId:explicit?String(a.entity_id):'',unitNumber:explicit?units.get(String(a.entity_id)):'',actorMembershipCount:actorUnits.length};
    });
   }
   if(inner.name==='searchActivityFeed'){
    const input=inner.args?.[0]||{};
    const term=String(input.term||'').trim().slice(0,80);
    const limit=50;
    const page=Math.min(200,Math.max(0,Math.trunc(Number(input.page)||0)));
    const escapeValue=v=>encodeURIComponent(v);
    let filter='';
    if(term){
     // PostgREST logical filters must not accept arbitrary syntax from the client.
     const safe=term.replace(/[*,().\\]/g,' ').trim();
     if(safe){
      let actors=[];
      try{
       const matches=await db(env,'tower_users?select=user_id&or=(name.ilike.*'+escapeValue(safe)+'*,title.ilike.*'+escapeValue(safe)+'*)&limit=100');
       actors=matches.map(x=>x.user_id).filter(x=>/^[0-9a-f-]{36}$/i.test(x));
      }catch(_ignored){}
      const conditions=['action.ilike.*'+safe+'*','entity.ilike.*'+safe+'*'];
      if(actors.length)conditions.push('actor_id.in.('+actors.join(',')+')');
      filter='&or=('+escapeValue(conditions.join(','))+')';
     }
    }
    const rows=await db(env,base+filter+'&order=at.desc,audit_id.desc&limit='+(limit+1)+'&offset='+(page*limit));
    const hasMore=rows.length>limit;
    const enriched=await enrichActivityActors(rows.slice(0,limit));
    return {rows:enriched.map(a=>({auditId:a.audit_id,timestamp:a.at,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',actorDisplayName:a.actorDisplayName,unitId:a.unitId||'',unitNumber:a.unitNumber||''})),hasMore,page};
   }
   if(inner.name==='getActivityFeed'){
    const raw=Number(inner.args?.[0]);
    const limit=Number.isFinite(raw)?Math.min(200,Math.max(1,Math.trunc(raw))):100;
    const rows=await db(env,base+'&order=at.desc&limit='+limit);
    const enriched=await enrichActivityActors(rows);
    return enriched.map(a=>({auditId:a.audit_id,timestamp:a.at,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',actorDisplayName:a.actorDisplayName,unitId:a.unitId||'',unitNumber:a.unitNumber||''}));
   }
   const id=String(inner.args?.[0]||'');
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))throw Error('INVALID_AUDIT_ID');
   const rows=await db(env,base+'&audit_id=eq.'+encodeURIComponent(id)+'&limit=1');
   if(!rows.length)throw Error('AUDIT_NOT_FOUND');
   const a=(await enrichActivityActors(rows))[0];
   return {auditId:a.audit_id,timestamp:a.at,actorDisplayName:a.actorDisplayName,role:a.actorRole||'',action:a.action,entity:a.entity||'',entityId:a.entity_id||'',notes:'',actorUserId:a.actor_id||'',unitId:a.unitId||'',unitNumber:a.unitNumber||'',before:'',after:''};
  }
  if(inner.name==='getCoreHomeData'){
   // Core home intentionally reads only migrated core tables; no fictitious finance figures.
   if(!['ADMIN','UNION','RESIDENT','OPERATOR'].includes(u.role))throw Error('FORBIDDEN');
   const result={notifications:[]};
   if(['ADMIN','UNION','OPERATOR'].includes(u.role)){
    const units=await db(env,'tower_units?select=unit_id&status=eq.ACTIVE');
    result.unitCount=units.length;
   }
   if(u.role==='ADMIN'){
    const users=await db(env,'tower_users?select=user_id&status=eq.ACTIVE');
    result.userCount=users.length;
    // Member request migration isn't installed yet, so do not claim zero pending requests.
    result.pendingMemberRequests=null;
   }
   if(u.role==='RESIDENT'){
    const memberships=await db(env,'tower_members?select=unit_id,member_role&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null');
    const m=memberships[0];
    result.membership=m?{unitId:m.unit_id,memberRole:m.member_role}:null;
    // No account balances until the ledger migration is installed.
    result.account=null;
   }
   return result;
  }
  if(inner.name==='getMyUnitGovernance'){
   if(u.role!=='RESIDENT')throw Error('FORBIDDEN');
   // Never accept a unit ID supplied by the browser; derive scope from the authenticated user.
   const memberships=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null&order=joined_at.asc');
   if(!memberships.length)return {hasUnit:false,units:[],members:[],requests:[]};
   const ids=[...new Set(memberships.map(m=>m.unit_id))];
   const units=await db(env,'tower_units?select=unit_id,unit_number,floor,unit_type_id,status,tower_unit_types(name,status)&unit_id=in.('+ids.join(',')+')');
   const allMembers=await db(env,'tower_members?select=member_id,user_id,unit_id,member_role,relation,joined_at,tower_users(name,title,title_id,custom_title)&ended_at=is.null&unit_id=in.('+ids.join(',')+')');
   const managedIds=memberships.filter(m=>m.member_role==='MANAGER').map(m=>m.unit_id);
   const reqs=ids.length?await db(env,'tower_member_requests?select=request_id,unit_id,requested_by,first_name_261,rest_name_261,candidate_name,candidate_title,candidate_title_id,candidate_custom_title,phone,phone_country,relation,status,created_at,manager_opinion,manager_opinion_at,manager_opinion_note&unit_id=in.('+ids.join(',')+')&order=created_at.desc'):[];
   const joinRequests=managedIds.length?await db(env,'tower_registration_requests?select=request_id,unit_id,name,first_name_261,rest_name_261,title,phone,relation,status,created_at,manager_opinion,manager_opinion_at,manager_opinion_note&status=eq.PENDING&unit_id=in.('+[...new Set(managedIds)].join(',')+')&order=created_at.desc'):[];
   const membershipsByUnit=new Map(memberships.map(m=>[m.unit_id,m]));
   const results=units.map(unit=>{
    const m=membershipsByUnit.get(unit.unit_id);
    const members=allMembers.filter(row=>row.unit_id===unit.unit_id).map(row=>({unitMemberId:row.member_id,userId:row.user_id,unitId:row.unit_id,memberRole:row.member_role,relation:row.relation||'',name:row.tower_users?.name||'',title:row.tower_users?.title||'',customTitle:row.tower_users?.custom_title||'',displayName:workerPersonName(row.tower_users)}));
    return {unit:{unitId:unit.unit_id,unitNumber:unit.unit_number,floor:unit.floor,unitTypeId:unit.unit_type_id,unitTypeName:unit.tower_unit_types?.name||'',status:unit.status},membership:{unitId:m.unit_id,memberRole:m.member_role,relation:m.relation||''},members,registrationRequests:m.member_role==='MANAGER'?joinRequests.filter(x=>x.unit_id===unit.unit_id).map(x=>({requestId:x.request_id,unitId:x.unit_id,name:x.name,firstName:x.first_name_261||String(x.name||'').split(/\s+/)[0],restName:x.rest_name_261??String(x.name||'').split(/\s+/).slice(1).join(' '),title:x.title,phone:x.phone,relation:x.relation,createdAt:x.created_at,managerOpinion:x.manager_opinion||null,managerOpinionAt:x.manager_opinion_at||null,managerOpinionNote:x.manager_opinion_note||''})):[],requests:reqs.filter(r=>r.unit_id===unit.unit_id).map(r=>({requestId:r.request_id,unitId:r.unit_id,firstName:r.first_name_261,restName:r.rest_name_261,name:r.candidate_name,title:r.candidate_title,titleId:r.candidate_title_id||'',customTitle:r.candidate_custom_title||'',phone:r.phone||'',phoneCountry:r.phone_country||'',relation:r.relation||'',status:r.status,createdAt:r.created_at,managerOpinion:r.manager_opinion||null,managerOpinionAt:r.manager_opinion_at||null,managerOpinionNote:r.manager_opinion_note||""}))};
   });
   // Preserve V1.13.0 screen contract, and include all linked units for future multi-unit UI.
   const requested=String(inner.args?.[0]||'');const first=results.find(x=>x.unit.unitId===requested&&x.unit.status==='ACTIVE')||results.find(x=>x.unit.status==='ACTIVE'&&x.membership.memberRole==='MANAGER')||results.find(x=>x.unit.status==='ACTIVE')||results[0];return {hasUnit:true,...first,units:results};
  }
  if(['unitStates350','bulkUnitState350'].includes(inner.name)){
   if(!['ADMIN','UNION'].includes(u.role))throw Error('FORBIDDEN');
   return rpc(env,'tower_unit_states_262',{p_token:inner.token,p_action:inner.name==='bulkUnitState350'?'assign':inner.args?.[0],p_payload:inner.name==='bulkUnitState350'?(inner.args?.[0]||{}):(inner.args?.[1]||{})});
  }
  if(inner.name==='listUnits'){
   if(!['ADMIN','UNION','RESIDENT'].includes(u.role))throw Error('FORBIDDEN');
   const unitIds=u.role==='RESIDENT'?await db(env,'tower_members?select=unit_id&user_id=eq.'+encodeURIComponent(u.user_id)+'&ended_at=is.null'):null;
   if(unitIds&&!unitIds.length)return [];
   const restriction=unitIds?'&unit_id=in.('+unitIds.map(x=>x.unit_id).join(',')+')':'';
   // Active membership only: embedded tower_members without ended_at filtering can select a former manager.
   const [base,types,members]=await Promise.all([
    db(env,'tower_units?select=unit_id,unit_number,floor,unit_type_id,status,state_id_262&order=unit_number.asc'+restriction),
    db(env,'tower_unit_types?select=unit_type_id,name,status,color_264'),
    db(env,'tower_members?select=unit_id,user_id,member_role&ended_at=is.null&member_role=eq.MANAGER')
   ]);
   const typeMap=new Map(types.map(t=>[String(t.unit_type_id),t]));
   const baseIds=new Set(base.map(x=>String(x.unit_id)));
   const managers=members.filter(m=>baseIds.has(String(m.unit_id)));
   const userIds=[...new Set(managers.map(m=>m.user_id))];
   const names=[];
   for(let i=0;i<userIds.length;i+=80){
    const chunk=await db(env,'tower_users?select=user_id,name,title&user_id=in.('+userIds.slice(i,i+80).map(encodeURIComponent).join(',')+')');
    names.push(...chunk);
   }
   const userMap=new Map(names.map(n=>[String(n.user_id),n]));
   const rows=base.map(x=>({...x,tower_unit_types:typeMap.get(String(x.unit_type_id))||null,tower_members:managers.filter(m=>String(m.unit_id)===String(x.unit_id)).map(m=>({...m,tower_users:userMap.get(String(m.user_id))||null}))}));
   return rows.map(x=>{const manager=x.tower_members?.find(m=>m.member_role==='MANAGER');return {stateId:x.state_id_262||'',unitId:x.unit_id,unitNumber:x.unit_number,floor:x.floor,unitTypeId:x.unit_type_id,unitTypeName:x.tower_unit_types?.name||'—',unitTypeStatus:x.tower_unit_types?.status||'',unitTypeColor:x.tower_unit_types?.color_264||'#2f80ed',status:x.status,managerUserId:manager?.user_id||'',managerName:manager?[manager.tower_users?.title,manager.tower_users?.name].filter(Boolean).join(' '):'غير معين'};});
  }
  throw Error('OPERATION_NOT_MIGRATED: '+inner.name);
 }
 throw Error('UNKNOWN_METHOD');
}

// Admin-only Cloudflare KV preferences; no access to stored Telegram chat IDs.
const HEALTH_PREF_KEY='health:preferences:v1';
const healthPrefDefaults=env=>({alertsEnabled:healthBool(env.HEALTH_TELEGRAM_ENABLED,true),failure:healthBool(env.HEALTH_ALERT_FAILURE,true),recovery:healthBool(env.HEALTH_ALERT_RECOVERY,true),reminder:healthBool(env.HEALTH_ALERT_REMINDER,true),dailyOk:healthBool(env.HEALTH_TELEGRAM_DAILY_OK,false),reminderHours:Math.max(6,Math.min(48,Number(env.HEALTH_REMINDER_HOURS)||24))});
async function readHealthPrefs(env){const defaults=healthPrefDefaults(env);if(!env.HEALTH_MONITOR_KV)return defaults;try{const data=JSON.parse(await env.HEALTH_MONITOR_KV.get(HEALTH_PREF_KEY)||'{}');return {...defaults,...Object.fromEntries(Object.keys(defaults).filter(k=>typeof data[k]===typeof defaults[k]).map(k=>[k,data[k]]))};}catch(_){return defaults;}}
async function saveHealthPrefs(env,input){if(!env.HEALTH_MONITOR_KV)throw Error('HEALTH_MONITOR_KV_NOT_BOUND');if(!input||typeof input!=='object'||Array.isArray(input))throw Error('INVALID_HEALTH_SETTINGS');const keys=['alertsEnabled','failure','recovery','reminder','dailyOk'];if(keys.some(k=>typeof input[k]!=='boolean')||![6,12,24,48].includes(Number(input.reminderHours)))throw Error('INVALID_HEALTH_SETTINGS');const value={...Object.fromEntries(keys.map(k=>[k,input[k]])),reminderHours:Number(input.reminderHours)};await env.HEALTH_MONITOR_KV.put(HEALTH_PREF_KEY,JSON.stringify(value));return value;}
// Independent health monitor: cloud-side check, no DB write, no financial data.
// Requires HEALTH_MONITOR_KV (Cloudflare KV) for durable throttle and outage recovery alerts.
const healthBool=(v,defaultValue=false)=>v==null?defaultValue:['true','1','yes','on'].includes(String(v).toLowerCase());
async function towerHealthProbe(env){
 const root=String(env.SUPABASE_URL||'').replace(/\/+$/,'');
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(root)||!env.SUPABASE_SERVICE_ROLE_KEY)return {ok:false,reason:'CONFIG_MISSING'};
 try{
  const r=await fetch(root+'/rest/v1/tower_units?select=unit_id&limit=1',{
   headers:{apikey:env.SUPABASE_SERVICE_ROLE_KEY,Authorization:'Bearer '+env.SUPABASE_SERVICE_ROLE_KEY,Accept:'application/json'},
   signal:AbortSignal.timeout(8000),cache:'no-store'});
  return {ok:r.ok,reason:r.ok?'OK':'HTTP_'+r.status};
 }catch(_){return {ok:false,reason:'UNREACHABLE'};}
}
async function towerHealthMonitorRun(env){
 if(!healthBool(env.HEALTH_MONITOR_ENABLED,false))return;
 const kv=env.HEALTH_MONITOR_KV;
 if(!kv){console.warn('HEALTH_MONITOR_KV_NOT_BOUND');return;}
 const now=Date.now(),interval=Math.max(15,Math.min(1440,Number(env.HEALTH_CHECK_MINUTES)||60))*60000;
 const last=Number(await kv.get('health:last_probe_ms')||0);
 if(now-last<interval)return;
 // A brief lease avoids overlapping Cloudflare cron executions.
 await kv.put('health:last_probe_ms',String(now),{expirationTtl:86400});
 const prior=JSON.parse(await kv.get('health:state')||'{}');
 const p=await towerHealthProbe(env);
 const count=p.ok?0:(Number(prior.failures||0)+1);
 const threshold=Math.max(1,Math.min(10,Number(env.HEALTH_FAILURE_THRESHOLD)||2));
 const outage=!p.ok&&count>=threshold;
 const recovery=p.ok&&prior.down===true;
 const firstFailure=outage&&!prior.down;
 const prefsForReminder=await readHealthPrefs(env);
 const reminderHours=prefsForReminder.reminderHours;
 const reminder=outage&&prior.down&&(now-Number(prior.lastAlertAt||0)>=reminderHours*3600000);
 const dailyOk=p.ok&&prefsForReminder.dailyOk&&now-Number(prior.lastDailyOkAt||0)>=86400000;
 const prefs=await readHealthPrefs(env);
 const send=prefs.alertsEnabled&&!!env.HEALTH_TELEGRAM_CHAT_ID&&!!env.TELEGRAM_BOT_TOKEN;
 let lastAlertAt=Number(prior.lastAlertAt||0),lastDailyOkAt=Number(prior.lastDailyOkAt||0);
 const events=[];
 if(firstFailure&&prefs.failure)events.push('🚨 Tower App — تعذر الاتصال بقاعدة Supabase بعد '+count+' فحوصات متتالية. افحص Supabase Dashboard. السبب التقني: '+p.reason);
 else if(reminder&&prefs.reminder)events.push('⚠️ Tower App — مشكلة اتصال Supabase مستمرة. افحص لوحة Supabase.');
 if(recovery&&prefs.recovery)events.push('✅ Tower App — عاد اتصال Supabase للعمل بنجاح.');
 if(dailyOk)events.push('✅ Tower App — الفحص الدوري لاتصال Supabase ناجح.');
 if(send){for(const message of events){try{await telegramSend(env,env.HEALTH_TELEGRAM_CHAT_ID,message);if(message.includes('الفحص الدوري'))lastDailyOkAt=now;else lastAlertAt=now;}catch(e){console.warn('HEALTH_TELEGRAM_SEND_FAILED',String(e.message||e).slice(0,60));}}}
 await kv.put('health:state',JSON.stringify({down:outage,failures:count,lastCheckAt:new Date(now).toISOString(),lastResult:p.ok?'OK':p.reason,lastAlertAt,lastDailyOkAt}),{expirationTtl:31536000});
}

// V3.8.3: standards-based Web Push, private runtime queue; no browser/session token in payload.
const pushBytes383=value=>Uint8Array.from(atob(String(value).replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
function pushB64383(bytes){let s='';for(let i=0;i<bytes.length;i+=16384)s+=String.fromCharCode(...bytes.subarray(i,i+16384));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function pushConcat383(...chunks){const out=new Uint8Array(chunks.reduce((n,c)=>n+c.length,0));let at=0;for(const c of chunks){out.set(c,at);at+=c.length;}return out;}
async function pushHmac383(key,bytes){const k=await crypto.subtle.importKey('raw',key,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',k,bytes));}
async function pushExpand383(key,info,size){return (await pushHmac383(key,pushConcat383(new TextEncoder().encode(info),new Uint8Array([1])))).slice(0,size);}
function validatePushSubscription383(s){
 const endpoint=new URL(String(s?.endpoint||''));const h=endpoint.hostname;
 if(endpoint.protocol!=='https:'||endpoint.username||endpoint.password||endpoint.hash||endpoint.port&&endpoint.port!=='443'||s.endpoint.length>4096||!(h==='fcm.googleapis.com'||h==='updates.push.services.mozilla.com'||h==='web.push.apple.com'||h.endsWith('.notify.windows.com')))throw Error('INVALID_PUSH_SUBSCRIPTION');
 const key=pushBytes383(s?.keys?.p256dh||''),auth=pushBytes383(s?.keys?.auth||'');if(key.length!==65||key[0]!==4||auth.length!==16)throw Error('INVALID_PUSH_SUBSCRIPTION');
 return {endpoint:endpoint.href,keys:{p256dh:pushB64383(key),auth:pushB64383(auth)}};
}
async function encryptPush383(subscription,payload){
 const client=pushBytes383(subscription.p256dh),auth=pushBytes383(subscription.auth),pair=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const server=new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey)),clientKey=await crypto.subtle.importKey('raw',client,{name:'ECDH',namedCurve:'P-256'},false,[]),secret=new Uint8Array(await crypto.subtle.deriveBits({name:'ECDH',public:clientKey},pair.privateKey,256));
 const prk=await pushHmac383(auth,secret),info=pushConcat383(new TextEncoder().encode('WebPush: info\0'),client,server),ikm=(await pushHmac383(prk,pushConcat383(info,new Uint8Array([1])))).slice(0,32);
 const salt=crypto.getRandomValues(new Uint8Array(16)),extract=await pushHmac383(salt,ikm),cek=await pushExpand383(extract,'Content-Encoding: aes128gcm\0',16),nonce=await pushExpand383(extract,'Content-Encoding: nonce\0',12);
 const plain=pushConcat383(new TextEncoder().encode(JSON.stringify(payload)),new Uint8Array([2]));if(plain.length>3800)throw Error('PUSH_PAYLOAD_TOO_LARGE');
 const key=await crypto.subtle.importKey('raw',cek,'AES-GCM',false,['encrypt']),cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce},key,plain));
 return pushConcat383(salt,new Uint8Array([0,0,16,0,65]),server,cipher);
}
async function pushVapid383(config,endpoint){
 const enc=o=>pushB64383(new TextEncoder().encode(JSON.stringify(o))),unsigned=enc({typ:'JWT',alg:'ES256'})+'.'+enc({aud:new URL(endpoint).origin,exp:Math.floor(Date.now()/1000)+12*3600,sub:config.origin});
 const key=await crypto.subtle.importKey('jwk',config.privateJwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']),sig=new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,new TextEncoder().encode(unsigned)));
 return 'vapid t='+unsigned+'.'+pushB64383(sig)+', k='+config.publicKey;
}
async function pushPrepare383(env,origin){
 let config=await rpc(env,'tower_push_keys_383',{p_config:null});if(config)return config;
 const url=new URL(origin);if(url.protocol!=='https:')throw Error('INVALID_PUSH_ORIGIN');
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']),publicKey=pushB64383(new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey))),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey);
 return rpc(env,'tower_push_keys_383',{p_config:{publicKey,privateJwk,origin:url.origin}});
}
async function processPush383(env){
 const jobs=await rpc(env,'tower_push_queue_386',{p_action:'claim',p_payload:{limit:4}});if(!Array.isArray(jobs)||!jobs.length)return;
 const config=await rpc(env,'tower_push_keys_383',{p_config:null});if(!config||config.paused)return;
 await Promise.allSettled(jobs.map(async job=>{
  let outcome='retry',code=0,stage='access';
  try{
   if(await rpc(env,'tower_push_queue_383',{p_action:'validate',p_payload:{jobId:job.jobId,nonce:job.nonce}})!==true){outcome='failed';return;}
   stage='subscription';validatePushSubscription383({endpoint:job.endpoint,keys:{p256dh:job.p256dh,auth:job.auth}});
   stage='payload';const payload={v:1,ownerId:job.userId,jobId:job.jobId,title:String(job.title||'Tower App').slice(0,120),body:String(job.body||'عندك تنبيه جديد. افتح التطبيق للتفاصيل.').slice(0,500),url:'/?view=home'};
   if(job.source==='trip'&&job.target?.entity==='trip'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(job.target.entityId||''))payload.target={entity:'trip',entityId:job.target.entityId};
   stage='encryption';const encrypted=await encryptPush383(job,payload);stage='signing';const authorization=await pushVapid383(config,job.endpoint);
   stage='transport';
   const response=await fetch(job.endpoint,{method:'POST',headers:{Authorization:authorization,'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',TTL:'86400',Urgency:'high',Topic:job.jobId.replace(/-/g,'').slice(0,32)},body:encrypted,signal:AbortSignal.timeout(8000),redirect:'manual'});code=response.status;await response.body?.cancel();
   outcome=response.ok?'sent':[404,410].includes(code)?'expired':code===429||code>=500?'retry':'failed';
  }catch(e){outcome='retry';if(!code)code=stage==='transport'&&['TimeoutError','AbortError'].includes(e?.name)?-17:({access:-11,subscription:-12,payload:-13,encryption:-14,signing:-15,transport:-16})[stage]||-10;const dbCode=/^[A-Z0-9]{4,8}$/.test(e?.dbCode||'')?e.dbCode:null;console.warn('PUSH_ATTEMPT_FAILED',JSON.stringify({stage,code,...(dbCode?{dbCode}:{})}));}
  finally{try{await rpc(env,'tower_push_queue_383',{p_action:'finish',p_payload:{jobId:job.jobId,nonce:job.nonce,outcome,code}});}catch(_){console.warn('PUSH_ACK_FAILED');}}
 }));
}
function shouldDrainPush383(p){const inner=p?.args?.[0];return p?.method==='apiCall'&&(['push383','android390'].includes(inner?.name)?inner.args?.[0]==='test':/^(admin|save|set|create|update|delete|cancel|close|undo|add|record|submit|return|approve|reject|review|request|transfer|change|generate|finalize|install|task.*Action|.*WorkflowAction)/i.test(inner?.name||''));}
const PUSH_SW383=String.raw`'use strict';
const DB='tower-push-383';
function owner(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('state');r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,t=db.transaction('state'),q=t.objectStore('state').get('owner');q.onsuccess=()=>resolve(q.result||'');q.onerror=()=>reject(q.error);t.oncomplete=()=>db.close();};});}
function tripTarget(target){return target?.entity==='trip'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(target.entityId||'')?{entity:'trip',entityId:target.entityId}:null;}
function recordReceipt(receipt){return new Promise((resolve,reject)=>{const request=indexedDB.open(DB,1);request.onupgradeneeded=()=>request.result.createObjectStore('state');request.onerror=()=>reject(request.error);request.onsuccess=()=>{const db=request.result,t=db.transaction('state','readwrite'),store=t.objectStore('state'),q=store.get('owner');q.onsuccess=()=>{if(q.result===receipt.ownerId)store.put(receipt,'receipt');};t.oncomplete=()=>{db.close();resolve();};t.onerror=()=>{db.close();reject(t.error);};};});}
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>event.waitUntil((async()=>{let p;try{p=event.data.json();}catch(_){return;}if(p?.v!==1||typeof p.ownerId!=='string'||await owner()!==p.ownerId)return;
const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});const answers=await Promise.all(windows.filter(c=>c.visibilityState==='visible').map(c=>new Promise(resolve=>{const channel=new MessageChannel(),timer=setTimeout(()=>{channel.port1.close();resolve(false);},300);channel.port1.onmessage=e=>{clearTimeout(timer);channel.port1.close();resolve(e.data?.visible===true);};c.postMessage({type:'PUSH_QUERY_383',ownerId:p.ownerId},[channel.port2]);})));const visible=answers.some(Boolean);for(const c of windows)c.postMessage({type:'PUSH_REFRESH_383',ownerId:p.ownerId});
const receipt={ownerId:p.ownerId,receivedAt:new Date().toISOString(),silentRequested:visible,reason:visible?'VISIBLE_ACCOUNT':'BACKGROUND',shown:false};
try{await self.registration.showNotification(String(p.title||'Tower App').slice(0,120),{body:String(p.body||'').slice(0,500),icon:'/api/brand/logo',tag:'tower-'+p.jobId,renotify:false,silent:visible,data:{ownerId:p.ownerId,target:tripTarget(p.target),url:'/?view=home'}});receipt.shown=true;}catch(e){receipt.error=['NotAllowedError','InvalidStateError','TypeError'].includes(e?.name)?e.name:'OtherError';throw e;}finally{try{await recordReceipt(receipt);}catch(_){}for(const client of windows)client.postMessage({type:'PUSH_RECEIPT_387',ownerId:p.ownerId});}

})()));
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil((async()=>{const current=await owner();if(!current||current!==event.notification.data?.ownerId)return;const source=tripTarget(event.notification.data?.target),target=new URL(source?'/?view=trips':'/?view=home',self.location.origin);if(source){target.searchParams.set('pushTrip',source.entityId);target.searchParams.set('pushOwner',current);}const windows=(await self.clients.matchAll({type:'window',includeUncontrolled:true})).filter(c=>new URL(c.url).origin===self.location.origin);const matches=await Promise.all(windows.map(c=>new Promise(resolve=>{const channel=new MessageChannel(),timer=setTimeout(()=>{channel.port1.close();resolve(null);},300);channel.port1.onmessage=e=>{clearTimeout(timer);channel.port1.close();resolve(e.data?.matches===true||e.data?.visible===true?c:null);};c.postMessage({type:'PUSH_QUERY_383',ownerId:current},[channel.port2]);})));const client=matches.find(Boolean);if(client){await client.focus();client.postMessage({type:'PUSH_OPEN_383',ownerId:current,target:source});return;}await self.clients.openWindow(target.href);})());});
`;

// Android transport: FCM is free; no Firebase paid products or Cloud Functions used.
let ANDROID_OAUTH390=null;
function androidConfig390(env){try{const p=JSON.parse(env.TOWER_ANDROID_PUBLIC_CONFIG||'{}'),s=JSON.parse(env.TOWER_ANDROID_SERVICE_ACCOUNT||'{}');if(!/^[a-z][a-z0-9-]{4,29}$/.test(p.projectId||'')||!/^1:[0-9]+:android:[a-f0-9]+$/i.test(p.appId||'')||!/^\d{5,20}$/.test(String(p.senderId||''))||!/^[A-Za-z0-9_-]{30,100}$/.test(p.apiKey||'')||s.project_id!==p.projectId||!s.client_email?.endsWith('.iam.gserviceaccount.com')||!s.private_key?.includes('-----BEGIN PRIVATE KEY-----'))return null;return {public:p,service:s};}catch(_){return null;}}
async function androidOauth390(config){const service=config.service,cacheKey=service.client_email+'|'+String(service.private_key_id||'');if(ANDROID_OAUTH390?.key===cacheKey&&ANDROID_OAUTH390.until>Date.now()+60000)return ANDROID_OAUTH390.token;
 const encode=x=>pushB64383(new TextEncoder().encode(JSON.stringify(x))),iat=Math.floor(Date.now()/1000),unsigned=encode({alg:'RS256',typ:'JWT',kid:service.private_key_id})+'.'+encode({iss:service.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat,exp:iat+3600});
 const pem=service.private_key.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g,''),key=await crypto.subtle.importKey('pkcs8',pushBytes383(pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
 const signature=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(unsigned))),assertion=unsigned+'.'+pushB64383(signature);
 const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion}),redirect:'manual',signal:AbortSignal.timeout(10000)});
 const data=await response.json().catch(()=>null);if(!response.ok||typeof data?.access_token!=='string'||!data.access_token||data.access_token.length>8192)throw Error('ANDROID_OAUTH_FAILED');
 ANDROID_OAUTH390={key:cacheKey,token:data.access_token,until:Date.now()+Math.min(3600,Math.max(60,Number(data.expires_in)||3000))*1000};return data.access_token;
}
async function processAndroid390(env){const config=androidConfig390(env);if(!config)return;const jobs=await rpc(env,'tower_android_queue_390',{p_action:'claim',p_payload:{}});if(!Array.isArray(jobs)||!jobs.length)return;
 let access;try{access=await androidOauth390(config);}catch(_){for(const job of jobs)try{await rpc(env,'tower_android_queue_390',{p_action:'finish',p_payload:{jobId:job.jobId,nonce:job.nonce,outcome:'retry',code:-21}});}catch(_){}console.warn('ANDROID_OAUTH_FAILED');return;}
 await Promise.allSettled(jobs.map(async job=>{let outcome='retry',code=0;try{
  if(await rpc(env,'tower_android_queue_390',{p_action:'validate',p_payload:{jobId:job.jobId,nonce:job.nonce}})!==true){outcome='failed';return;}
  const data={ownerId:String(job.userId),jobId:String(job.jobId),title:String(job.title||'برج العائلة').slice(0,120),body:String(job.body||'عندك إشعار جديد.').slice(0,500)};
  if(job.target?.entity==='trip'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(job.target.entityId||''))data.tripId=job.target.entityId;
  const response=await fetch('https://fcm.googleapis.com/v1/projects/'+config.public.projectId+'/messages:send',{method:'POST',headers:{Authorization:'Bearer '+access,'content-type':'application/json'},body:JSON.stringify({message:{token:job.fcmToken,data,android:{priority:'high',ttl:'86400s'}}}),redirect:'manual',signal:AbortSignal.timeout(10000)});code=response.status;
  const result=await response.json().catch(()=>null),expired=result?.error?.details?.some(x=>x?.errorCode==='UNREGISTERED');
  if(response.status===401)ANDROID_OAUTH390=null;
  outcome=response.ok?'sent':expired?'expired':[401,429].includes(code)||code>=500?'retry':'failed';
 }catch(_){code=code||-16;outcome='retry';}finally{try{await rpc(env,'tower_android_queue_390',{p_action:'finish',p_payload:{jobId:job.jobId,nonce:job.nonce,outcome,code}});}catch(_){console.warn('ANDROID_ACK_FAILED');}}}));
}

const BUILDING_FACADE391='UklGRihbAgBXRUJQVlA4IBxbAgDw0QidASqpA44GPnk2l0ikoqeoJRJscQAPCU3BV+ud7Ti2fgc2HbPQLjD7u/5/Q48v7NLhR53fkH/0PQ1/1o6N9DxJEPe279LjfFr5t/d/An+o/8/i++p/43/u+4B/Nf6b/uvW+xgPfP+J7A/9L/wv/l+53qd6Cn/j9Fz9l/43o1+oz/c/b/1CfaGEhbv+/qtZX+Z/3/9d+S/vj8q+NX2P8l8/334/2+7z5v/s+ZD7v/T/qf2x/879tP9l8VP8R/s/YY/x/+c/aP17v3l9/P9y/9H5rfCP+uf7b9wP+d8OH/V/cL/rfD7+1/8b9z/gH/uX/D///tT//H////b4fv69/5f///3fg4/nH/S///+796v/6+1F/lf/j7NX+j/8X/////uAf//25eEz/8fmr+b/2v/i/3X7cf3b1D/L/vX+Z+Zn+O/cL70/6j/l8v/yP+5/8f2d9qf63+wf4f+R/d34zfej/nv9R/6/W39p/r/+b/m/3a/0XyNfoP9V/1X98/eD/FfL93o/2HmT7//0v/P/sfYa9lfrv/R/wX5gfDD+3/2P9X/p//h7y/ZT/mf438t/sC/mX9a/53999o//h5tX1f/sf+//W/Ab/NP79/6P8r/r/3e+pf/T/+f+y/4H7yfE/6z/9n+n/1/yKf0T+//+b/N9tL0nzipL+tR8gjWwuL2kv61ICWjLbVJRn4c3sl/WpAS0ZbapKM/Dm9kv6x6HEo1FfOkvublOLve9tacrfyRGHn25tq0Z9/oSIUpFa63GuAu46HBGLa7f1NhUHlSevbUuCn78ib9YXHewAVsLgz0OaqggQBkdw7cCr8T3vsjgyw5MwS/aEY8DSjP7XKjRfiRD+dpL+u2UOf2HrKXggtol9e4dmlWVAib7Wkv67YTPAvAz+a4BtlrjyGJWjf2x6ir4rBh6pKM9PopbFcBeBpa+Fd6pPv9CFEcugf90lDAP5LGJnXuVyWzjI1Y2ot1z/K9tJ0JO9I2FQuuu86bKiwJpX1C9/8evKWs2Gyi49qJRzrHoMzQ+G+xqZmyAsEwPm2wh1MS0YEBWG9Tsi5dpTceftGgUE3NPBbDCiV1YLQLyLM1wrUDGxiOtMm+i83+b5aetl5UZv3bntkg/f4FqFZscn1tRbV5sIfYrPPxoWiLKhDMAMsUmSYkOK+zy1PbwJp0MODXbkSNC3OP/OyWmdb/P36e8qFob0rElgYnpG2MdXwXXs+wsKRzDJ0kep7qulBvQdWQwZcPWGrL/jkbFc3B+YB872g4pBqsGEYo7umjlo8YXfTICXTfjGAZ8Y5xfHkfHmbPDk5xTZKC8B/xzin86gf7lxsuqWPUKN1rpgMKNxIV0yz+78LuOKNS6nvIu6O1AFT4KuEA77iug5/rzQ12JtYNLSwzACKXK1QiYIj0F88JqjqYahcp9aeCEKfvt6jjIKFDmfLzr914JhC2VF2d6fpJYquBSqL08hGpjQYJPTgHUKyVFHSwJRrBdz6yeD+eVR+vogI+FTJQ347f69S6wiTzyne+xwmBaMmlLtMxbE6eHjiBbfw6g67g6KCLg3GvKCn/6cM9Ul7iwSk3WWQ2WeZ7PszhwkvVCIcioH13cksvTj/EjVkmFifkVpwprv5KnA5TY0hPC8XEyxs3LrvTTZtmPOWar+gTzYqbiRxE0jzb21/BIY0UZqssG3/KSmLZXAvw3OSxJzj84kdDDPcgRu0bkdUtE3zalEk7ovbXpsyTBRSX0m6SRREc66ESV+uX63xj4ePY2q+NrFfTzy9bC28en7lqZytFOIvJuJxh0NOvpCCNqNAhgU0W57CxZE6rkLXp5iFD6HWSG1U2yTP8x5awEugttXGMLG1DKvqUQtXRF2OmalSJIRSiW9Z4v78kuxYKvpki4lAcsFkRhpfXK0CnU4Yl5BggvpVuz/FwQN0iH+zNRYdsLgwwTcgp0raVy6ldCzZ10J7xOuYShV85Boz0/gmCr2gZhgXi8KR+3oLt9JdgiTUWKeJHRIfAVmgS3ZYRnQHX1gz30XtcorrE5EtT8ppGUy2Syek8naMs13/NhsWJ2OqYXd5QT9Ectf8xalfWXzRJ/9ZbgaUsHeUrqV+hO0x7lBSqmbtlWHJaK7c54Y2la1gKy61KMJhz55eKiy8DJkwJM0IrK7U5PNNwelWr03sk2D9xgqYh/jbQr6IbcuU50Jg3UjXgBWmN2rI9h3EDXIrsXtQB9Dnj9p0XOJcQBSQogxEmH3Q7mIUsllwvhcoqsk7aTn7hJ45CZmNfNGTo3Mk2v1YQfCX5rLkuufQrlfGliTdFi8vHkV1KArHPel4ulnNjFZ4m8kJmXsD52hhOHOpriyQ4LY9pj497v1ebHGQ7IRBVOtO+LjENeuHZCcIjKY5JnMUdkuxCKrNagqTv6/tRMxi5Sg7xEJb1fV0xgEbwqZevOjdCdl5vPUl327FC4q1e900ctUS4MyOFde/+Rhgh2YduqPD3C94pKM/DRO/vQP4crVSOCWszebVCnrW6ypTci7ZKuaDcBRFiVSos1SkOnPvqdIrc60ngP0ek/fcrLTMB6HnD7J4Dzzx10UtziDN27TZG2RRXW9bxBe+fQVuOFt2RXmISz/mNiUId5KJQ/a74HxL0qwdIx2DI6irpOVWuez72AQK6zTwgM2FH4uOFm4ouSAddJ3tQIdwtrKW9N/g16tXCenBMI7maKNRkEmz8SD12MUxnXu0q2gj/m9knckXS1ji7GmiQ4W1n4OHv+Fb+rHw4Q+Fkfgk+IWrbA42iYm43gwhTPwRBxTH2hgwkyJNKd955V8YT52+tmhu7dL37I11WUTNm8c3d4GvDCvmbsBOCGVF/oHwa9Oj8CyFIIve6HsCRjyhOS8D5Gobjlj/+gCZMNKJzxdSMcYUTDXhTnd/gaXHfDFUXmnwl9amtKqbvoqFdCM+WFuJgo/uu37Hv+UhOUaYsREDdhTpEhT5Ir2P5o1VNNFtqq2IHVc0ZlVLIL101kDQqKQzST9XDfRHduh/+Br49fBjaMIZpTFRXH2yE27xttkDvZu3uRIqtIEYYEphrfachc7nlDOyqlIF5I8AQyg65Vf416Miw4kYtGY/PdgJbUWg32G9zJk8/IxsRIcp2yZ3iiLMSgsPekLDUwGcbankv63H+YErNgHJUNr+Okha3ImngFiD6oloXAIlfZ/yHgXfRZ7EJzCwxMkV4FqVyB9kQqTUEtGmHB+eXUon6sx2rRAynVaRTn12P/F4KVbUYViVE1aGJHXNjMSoH0IsNpqm8GnwRzpw6T1Q/nW1liIanWYHfsoSA56VZlA+EiMTl5tIiB9SQ76/xaC8z2VbxOYNSy4orlAn8BxSKWS1ICZL9yhY58Jcqk65PKjNqlE6E26byJxE6pUit9v+lMhXEYdwrk8kW8+ux+tWCy2CmogQTVifSh3/3WTQDE3njZ+dw/xUCvde4P0y5njLyc8ASp99fhfUqn3XNx911VRopmNyaQEtOI4RhV9CQqVFj1pyjNJnV8+Y5RUplHUT0yjyzsDPQyLBxJGwPKCw8qxL/OWtYX4oCyRXUvL57G9eh28Hq34FNaoGNOCuTfQQnD/XVghuXrKZ0fwGG9iomZ/9vpZYSYAjZrsYXkXObIy5U21WlJjawSJxXSgJpaDdZ8ffVdJdvH+r3GUTE1b/Xw9FIXR+RwQ/f7Qd/ZvodUeoYOeswUsLysh3ZhfYjbDrjRHmUHrRv7Rvn0EwNRl3B89cjNogu//1Xrmrq/D0P0zEZ366wzg8drh/LB2ZGVbyKFnnYLlYGdGLpqdjYMjKyLvpY/Ygu1P8s1m6FTDqLJN06eCsgQ8OCmsLdpuXjAkcpFMZQZC0+4Woyog/4IAqHSfZ77cZSCZBtRDjNSSQgbxOvvyI73hyLWzeyFsLacb3ptmWO12okb9z8fHksJySyU2wVwLIO/sIJxXb5Bp6PZxXW7oFpZqCpvtvBeUHh7IP75VANUC0EphOZo9sOM3uGRZY0BzTIxhxuH0cQ+XhFAE6KT7sOynPsEquNe91i8WxLhMeIOtQGw5TyzyH3xw8PgPCCzZ9bwjGLJ26X8s0D+zl+gqnLWOqtLO9A7gfzl09sEST4j4smC17OGOtEcIHyoJUZ+HMTcbChYKDoeb/1vQkf1pXE/Qj+miBcj+5c3mUAHFbWPJFE1nV3S9DPq6S0kGN96CxRy+nKBzdIsMi399pw39VxQpKsrryBdaqclP9sd1EusePHUdeu8w8dVUCrL4snrKQ7ixI4bupwEenoHXF0BWTjeHj5omv7gMf8/hT7KAe7kZ0OyMVIoqBQfCYuzq7UCjNc3h0tNWY9sVwGw3f3IbqNFv9vYYVN75pbRvXR+22QjBKIlRw8RVzwec4QkkuBqrsp3tdRcHS8huKj9Bicu3fO6aCJroFueJmdRDAG+rKyCI85NOyF6U67//WePreca4FZ3kAf/xoQm9svZWoNVUE40SYWst1Km5qmpyImHuun0j0wU8O9xWjLMWp1JeU3+RP+Uyr8iEf04mjzICYdQ9Ruwo6NXxjZAUno1pqw2Eoz6bLcIMi24oEgJij9UyCH/24tqW7aaRRRT/sqD0uIoZH7FpxMbf8XbkuhJRL7cajyEvJVGF0PVxBaPQ+BQVpIrNYOnY2/Y3iBMUOXXVQd7bVJ1scyc4oJNGeNn1h47m5v/DGJrjWbZEZUse8WHITKfPywi4nqE0Fx9e45oGtKHpJRcNw3wqOFD2P2xgj6BPEigaTH/BncDqU+UnHmWowLUT5unUFzAMOXwWNIMDnIZ4sI8+a+PgztuY7WaKLwQ6qyJQlmBy7ClkGUckfQAwjUXDaINMTJNw1fZga1WsR9g2WrDE0ZzyeapPoeLenpvsEurM7UNNh6RjxI/hXmEXTr+tijvQw56gxYME74uxAyhK1o/0qkTd8tXSYVbM5VoYrchWJ96fV3bs509KK9BxipJnvDVHrM78d2MOHYotCyfEGB+KSEijojVGDZ2vyhjt4C3fIh4u4vpe/LOvaPF9Z57QSZ6/soSaWy1+xEFJYCc7ct5v3r/L6mPBbzQSQgkDmSZDzVxhozJULuyye/WURxRE2XudYeMllZp5ur554ueKxhRnpuI5YvVr0wpOiTlQGMAbWMEb49njOk9BFOduTfiKlQjEAyXTXgmZSKHjJL4OqhSLicQsQyQPXaxlxU3yoWY7wD2qSE4kPTVbZQ36WHvufuCDhFrn/UWoxgIgae51674pIRZiNECMkT/QoySZUC7nyl+A6dYxTXYl6HuhBh1s4DslaBDucT/JR6GU7f8daJuUOXe15e/24E0GXmuAvBwsJOIL3bGRuU5m3T9O3nvQ9InjkVpe83VuU4D02Win5A9+E3ML8W0cCta55/y25WghE6oDBPC677dMmIdUSLyYyunJwe0/Owdl8aAz768Q6on775OZP2s/4QehBeKY5JCzFnZdNMif42zyzdlN0WTCfs1ZbaEdFUw7UPU9aO4eQtH5LLF5nWaEpoIBxkfr2ntTetQE1vyw3yIJy6O27W+lcmrOzmurF5rgt1zxHUhWah30JaVezKkAYrQ60WW/Bx2Qw4t0t8AschMfRJEbZIrNxEFnRNjWM2jpyS8b+2nZaIQaDuDJXrEycd42WDhvcGDl0F3p2oDCXwESjQcmlUzF1EDIHI+c+k5lKy9rKMKFC1JttHpGu+H0Yrz4Ip9L1Rsw1K16F5Xjqqnxe0naEBEFrY1085x2fwtbocle+7HD4yGAkTV75A4otBYnUeFkUtRsSs7sqfyB3yYf5psrF9wIRuwKbDtLfBg3XcgHpuOKOTPuuxmX4CvXSRRYPTia7HEVQdxGmmzC9jdMHL+s3/qivCVvbGTKy3/0h/ldnbFnbPGTGo7yH1XrFuzz4gpsoLykVdx9rwI9DG1cuor3xKFMSkqdq1XioBWP3f/L5/mU7tReeRCEdmwJiikwJifUHOyn8b5guTGJaqT79UUO41ikKyJpHEvLqdmlBgAM/V2fELFOorkSSRhc4TLXwTBmZyXAgfdr4NJXFBFTAXK62Oi4urW5lyyeq9lL3mMM1gdzkUF6PLlPjd4e9b0I5kqPEOVhjXYAVYDSH1o7PtjJ4YtxCa4d1u09bm8RHH/I6vEAMbxYin1EuDuTA3purzWc++ohyC5boBFzk/wbBFlwd2lx3HmQJ73W/+SyYBjQm8k2H6O6OI6Nvu2Tz9qjU1CNo41rXWytXoPqQLk3JPVYVjr2UmLhhcRYRnXKyCFEfmE5tG04ZW+lsP2BodTP9+y93ly2edlsZPS0i3xVkzYtVUzzK4SMLD5yxfxqldwOjTozrz/I1qgAwrxd3cmM3TbBC4qg3QcH2mB+LcZ7n9tlQ8WLB7+ZnpoY5FhYGxBQnuAuab8D4XdZNcnaRCuwqturThW8Kdwju/lMJhg/7fn9oj/6Ez9LJ3lQJRve4Gx6niZ8eKXcLD96KPpquRm6rPDiA2yei2CACrM7WQ8i4g+YUgpYqYamtq7AuLAZXtPWg9YlfYv/uw6zKBBMck8LFfJ2J08kZUAnsBLfPAoM6mBThvEbF/EHPv5/1RvrPLzGTOWIwQm+QDUEVLJC703z/hSQmgD7SDKv45QEuvKX+JXU+PHAFfsdQ5j6NIlsWoSk23CCcOV45J5zditOOZwYdFGnm6oAVoc8k+Wqu9u42b3PmeVFvmu5V5ae6yrBzDMONGcgOmk17EEtxUhhtXqtx6fqb+lwcQXf3awyj6HMIyH7D1c1LMWMdC1TuL9XXAPPB4jXwMpFqipfSoEXypfHjlvn5AcIMZ2RY9ew3+ciuS8CbZWS27OEQxoHxOknrKSFayVs3d9WDdb4YwHXVPh8sToT7h0nbTD78pFS3DyDFQJAO7YSbLyq0mMdxTNoncotuGSzudM22pZSP3ku7dPJsuz1EardGJeoFLFGh+FW78AHALL9TOKgLE+v+8ni6R/jrQ4yB5Ur+5sFVrk13sk8xjx8XhGJim1m4BNaVxIHhsubFFwuxGVHfyoxivBFswKFBzVBSZKdKVO+F0LeeVdPmBzoa/jzlrtlG/3gEAfawN5FO46X4OBdcVBSam/Q9cMAU8qTM0F3xWwk5IWJdPGkNVksbKOrJlpTpKGwiAXMNioSLJDi+nuNFEac4OHaYY5CdWLBdm9g0V6vWqE9q784vaS/rPD9EsrEgqx/pPJe6p4adddkw65sEuCw5VGHrSc/ZI0uGiAC19BtrLeiamZtMEWdf4+3dE+CV7lgif8u0+nuR4n7K07HMsS95epWl8UgkAjAQob86BS0H9HoIZjrLituHQkFnuFdsAJKc4fvFrRbDflFioZw6rp2LUo/Lo0P4f1U22Ozft9YccR71iRKnNUde1CGwb5nW9OqqH8FOnHCazb0I/g8l+vU1ICYHHmcXoh7wyVB8L4W4pDjI42yA+w655+0VTxdIaC1VoGXSFxtwoBoy5/KdXuWH236Z48bGbtPw/gyf3LVT8Niaf3x4PJrMW7VmgVIiaDOl1X/YzLXjDkLP158KKrIb5NSldrcrflnkB1ZpRXcBLOQdgsa/WJSI2kz5BVRM/EAoQLGWNlz7212CCtR9byGINfQXMjJviEzpIxmGS2XIhGSmOY5xfXC43sjnY6s7//1KBf6V56PxY21ZL7azVkB5OrkX+IyQD9fwAEzlb5+Q7m2RgNr0qbTvWiHlMke+WsBQMS/P1x8by+ep6PCBtHPVdOBG93scWJIpQpXFt91W3M0Ln2HaUDMXJ56l9BMKVMOA/mTxlgPZYBMw7HKcFrXKdSL+05tZl/P/3cn+2ry9mgn+/idF8RtqwiQmfxwDMvr+QhwuWfuDq957ADngtI0i8NI9QwJtXLQtcYfuEcIswMj9xLtYSh+VAsN7dKxawq1ee3yK2iAN1i3c58oAQ02IG2s73a0l/WoaPE/CAjuB4dQzdJO1CwkWjxLPkofAY3J9D56In/U8EwuXoTuph+E3mWGaSXS+aN3N9cmyIVWiLunbt6XFmdxEeV3wo24Ww/yYfwkL9iVP+uMJGPY2Tt4jq03pbq5afhYC9lJhWRzr5vVLivrtqa7GUnBZMst723TX41Th0LwmiJtgbegpD1CvO5ld2DOm70zS/xqhhNbcXY6ZsrOID1ELcLr56Omc0QeMZRaDSYsmodcnSqC8TDq6CD/+H6+bXfn+2a4C8DTbQBEBa0BmO/6Z72GryEASki4Jo7dnWPNGnkvJAKeDDmvfuBywOkmoA+KrYEeYFrLeaOSWKnR39dVoSX6EXzZm7O7SON8zOq9m0gCv5Movc9X0KCsMDbq8bC086OuYIxPZuvI/FjbWAlt+LF647vi7FRdtaA9x0GibELDEAP7Ia9NpgLFmPkvxUD7JVf8+6fHvGc41A8ehGBgVtWg/IjctLTsLi9ozDDRCtJTlxaFwL8mo5T3NKTBSseAi0r0B+skMt1S7uTUFJkYdAbhzwQpJGd7TC5kKQiEJ8Xlg3J2kvzc9WGcXlC7GpydA8e9vPl//hJETvAwyDMrZJfyKNeAVE9lhdR/Fjd/M8p/M0J93lkYGovIFsMSIsMeL5uzBCPEms4mQ0ZfqDhngRAvtRZsDRMHTtNCW+c8ChGdrmEWq8mexHSk3U7Y7Locv0eacHwK+EBd+i6pfB98CvG0gnrw85c4KzIDPMwwGHfkLunjZ6ulivaWwchGXaUVp8jKaFM5jooaNomfNRROffvSzejZzd0x0HN0Qbx7XizG/aS9Zo79yUVsKunC25jRwRR+iKmIePkaAn/0IxC+uxmmxiWuQeSoiq6Fq4RONy529NtbwhQha3OZXaWSHym/Y9pUdh88ua5J4xpxouqKSf7c87UoayzFyk82YcJ/kvtIsCVGk9evDNMZU50Z/sQFfwgNHrhDs2xQdMg7pkigV9ZS7FcywLbkWko1P1suJdyKN5jpzjyuU6JxO0VVbLm+U96zTI1ExxfZaWzPy7W4i3MTypc22AoSQz3869MAILPFQ51FyIzouYPTu4DIrNXhQSkXo4j647tJgixQO0RD9SepI96hiHxhSRt+mCA03A2rTNBeSjB2AWgJ+9R/gq+mPMbaBqoEBSJ5chx+WsgDoLv6mTLpH1qg+aH73gJkKxfThSAaJBPu/yp3QnqSMxFoLYKiMn/23pKDsguQV6stw2Xr6eCBN9+eMZUibW/3q9lfMQAg7BBAZslaygZEHz80qmO+z5IygbFwMrVp8pCr9MjHHig99mbTluYuUg1d0+MVIYhXtyPpcwkziVCNaWpDAUEcqube00BQeHMU/y3iMFqM34cmtSm3POmJxBJFXXEuy0yOLQSypBJT7eHzYuS46Wtfd3zzd55Cfy3NWtwxYkaKQlCZktPrfRGOMRGi0XrBYTP/tYsgtoGYjhJe90I2vYnLT2GRziagJ5AbRy8oNy7dl0ycjqSQBeTAh3f6MmeqwBrXkT7nHRnP4hD+uP1dXifOrmVsA9ShyrVWhAPUaJHS8G9s7R3LqMYWxbpn5BY+p0jNa5+pldZoF90U1PC2+IjXB6+xswsnUixbpaaOwdobPYHG0IygmwKiYR/OT2lhKGWM7m/PYW0uI+eltbcxD7iFK0HA41mRb+ZQxOBvIJhDV3KgVNNuebob0Am2oEF9LIjrb8s0rDgoP5BtaLZxu3IHGupAz9JYnwjXAedpRoHbezVdRc7pRiX0nfbd3xvj5jHw0PDICkDmurPuCE/dzXaydleawEtzFN1KL1jJ+Z8QEXpNY/++d9Lg6LKHYBvsB3+6dcLmjCWLoHIkcpW8F0mjrQbyoHtKsC+7lMWYFdqyCMEs4v/rwGlf/2agycDJF2EJhLhaW0+Rmmv+Od3TPdm2kHT49/CHVBkRGHCh9D1l/ixzr5C/gHLWv9/4uuch0odrfKFMnxEcNW4ctrWkwqI/x+f2Z1Z6VvHrZT08/nbLEEYGWjKShhud8KGfx//2m/5bGzf0YopM5jdISfbdoVTj6kSeQaLvBkK2PTPFe066oRgaoJCf5RDq1ShBFl+ILF3lnzV63W+3m7eF8S9CCQYE6JcFoj3RVk8FIq1FPgIKV0iMA0Ygq26eTF9GtneHvoYGlUsqj8O2MO8oj49plRK3Wd4kBhT0kUgKPgsoSjZcglPoWJAIH1i3el9YMOGWu+V+pgaKKD13/rgbjbSEcnqRuBTShaW6EXU2BRUyZ7XFnAvifSeVufggxnh2dZwjAszNXueMyK4LQ+Gbdqw4/Bkqq374N/SKEsyUfcTEic7/Ubw+ryqkLv0c71RDXFuhIcqu06ya1D1GrP9XgSrNo8pBhmtdJ6WGBbT+LfC7mfGTuHgXAclWqPtKs2mvP01SB2ZX7n+aSEqM0aaMoodNaIeMen2AKkfvpioRgKvHmn0gpj2NJL3YMnvIHrA7QNLoOESWN3lC1l1BJhD7VrLP9j6gH6EukU9ntUBUxKSbAzR4SEuXZSbq86YFASmAJoTjdLZORA3CQp014UJBZ4y+XgvJaN4g3oFs5QQnjM/BsgdE0z8o2MrgPC+PVG74YnaRi4dQtFa8xXBytKKxfTPiwE2lgk/9tGjM/BE0sMZZjPw3gYP4rBzUfHI6FZmjJVn5lrIuY8jb0wFgDOyBlHCA13NZ8jIgIRKTNp2xUtTExjRX7OnPlkSm465IH8K3OoJywkvEe1jQfLJmIvQxxbvYgARJ9MZv1O3yzvROTa0WhGeUC/tiYFbU2axDw8NqOSyvBGPw9UJDmkEjJsu6zmbJtzfH5JzRjPT3U+l+esNGCktNIBkkh6mNdf6PJsZNlca9crmJ221U9wDNamw8h48fD1qp2/XYGfg6IBhApIQLM/zygoAyp607dcsRYxXr10+KdzkOdCGWmArxQn1sb+jBEZVP4KFJDESM1VEGm5vq6sPVm3QsCJ19GvV5Hl8TKoMQ+L4v4M+bZq4u6c7NPv5txamhoGF/AtKFaLXoTW8kuORMIPoU5K8pVBwBJ3ALk0UOiTQoLxdBe6IJfV+wjTi5bOZ305Se/ZPp39ZeigAfl+Dw7abagD/2ibMqAQmzGI0Oi4zfGTqlvmLO0h1LwUvlqBmn/e8/idZFEO8JN9uKoqomN/sPI0hmEHZiZJWCVrssokCWG7vrZ89aFdhdET1xe0oYag6f+gZNELSy5Bf0wf74t3iv0JNjJvxgg3S4dyq82LBAaHqvViESg2QDHuGTga1SHrrKDUS4rAa5/v9HOmTV7fG2z67L4zwPCV1dvVj3g+B/O+0r1qhbdn4IKTFN2pENLAIuBhgLPqUHvKO0WAXfuhAvx4hlPmX8oY1gUola1ZwyG5YXze8levU1WBLmg2gglx32mwwd5hmJ/9FD1Gy+umFf+pgA/cQwV4K/B653tuKwMDgksc3+O+nlya/gYfKCEIWK2safGsGOLOQHeEiWH0pRAVAnHCvC7rV8sUqeqMfcpP1oRyXlRM51stE3tIBPkH02X7viTeZWKdWQuN5ZD3yLylygnyexEUZAZPAywste0M3Ql8ZjMMsj5HtWGz6fsEbabvcQbL8WDyBUSXoAwRDOBlFSu44QgvdRIR2CIV/MYXHKlHzKV4WnxmsWRLYQcS52RjzY+Plej7gxMahUnau6D1NAk/+9KPpI2SayUyLDuP+TbhtoEf1VVvCMstfOAJ0azHzchAN9jNIboqc4/Hi0fUKVYLAq4mms1HcK8Q0tDTsxCjz0o+1a1rQVBhbg7K4OpgsRH8xyG8Wn39lOzQMEIffXsQHSXGEo2NCgckwyS/rSNLfaDHepJtTDRV+zOYF22HV2YzY/m6Dqf/rRJ3bCP78oO/sQCFkh+aMb3h0Ts/JpyfnGGrE+hFpOquCo5IjoKvXimRfYUT0xiRvh3g+buLnovKpR0PTo41GlPM0V6R6Qw09e3z/INMF+LFEb9dCppaocErB7yKxClzlddoTOVoL9hzx0yU0Dgi2ZFQvNNnf7dJkg401/K/eC1vmAIxd0p9bWW27Sax6z9SjJ4vn1S32BzBGzyX5mgn4gOntDN9tdAzYFqhPpdVECTSDbWpuebM3dIBu8i3mJB89IluVAkXQYnMWmZWAD7t1dyPFGxeiKxbUb8V5dPbdHtRC9hw/tOKkHVNMqRGFT0FBiJZ12hreYE3ap/L5WnrEFBaCtef5yy0d2PU5H3yHqGEhytLScT0donArAGUlVx3D/dG7AhodyNCTlIbzIKozJJP0+awGaPe3FXtsPY8sl1WJ9aPh0/Q6Mr+4SOplklzExUyXDhG4UKFn730VixoPiTaDu0PZdHxMGYS/ZaSiXWE2e4zV4bqf27WE70XavRhv3c0oVBCqca/aNwgATor4HGNzr5UlXHQMgXyxLUAlQgOb+rHJ7TEB3mLT0Mw4W6CBtW7u/qdiQ3gNQ/eHbrwqFBytzF3zLWDqpILKr09VYNcBIzjmXI4h1r+fRGvYQvf+3jUlD0ByOnAmy8KRLhGjjV65Ijz3b//Op2fKCJM2Ljdu2HiJDbx6iOliPiBRYmXrw/HIk9xZgo8P5QmTCTBe+36bFAd2WKZUJSGqkn4LwkisL56buuNTAl03K8Da280RosltFQ1aHKfBmrY7dvHj1LPpNcrfMrd6pmYiidsmJWed8DiFxRcfcwQ0uputr2rmjHarG869OgGj5Eg3BifbPrQUNaPr93AJw9UD9k2gfXlriqWh6Ck/3OP4IgTlSskQiOVKBL8nPBePa+ClAsFQIF8C0whCdXmyiq+5CyDRWKXDf5IOWy7uMAE5A9PmQq6zOSYr3SOveYA4vaS/rjSClCRg13dx7X3AH9S5sVARvuuq1QV+Zi5JRfxbyETB034yChWOpk5TNyddJfF9KQ9C4a60vM9yOeV4ZiEQ5MjY4/EXWe/9gTpn3MOSAwDnhakHb5kR4gDyjLxiSBTexILQ+coBA+vnxkrLPBEsZQkp/AxJ7ReRpcYAORXlUQNG6pgG2MhxfWvtRB3YojTMw1/VOw5rUDSQLZ1mEyCY+E25p2WjqMFuyX0qMkEQklA1YrCMOw5Rj2xwd1PXVXtWe2A/Jt5uiCIcXleiJpt239nD5t05gSnVZ+8YVzsNeFX8VEn8Hdb4Zy0NaPkvSjirxCxIRnoGpB5LaG1dR11CcvY3P/dcHl/WspToDZM6oQPWVde+LI+Rc7GkOUI6ntR/b2J8qom4wiSM23JN39+dYJVBG3Yaa7cUDGCq4s4yb7nmsqhBE4AiWyGgaiePwiO94zv5qAg1SbFNoz+31Sbivykslm/XHa5mTyjfBwQF3AGG688cKvUhOZ0UhExY/wPE17Fi6bvgWY4TbZ5vbQ+wFrkU+pIEt0p2Mp3x5+y38AEEdUq0xrbFBCbVaZJ9tKNnDy0D0wh9ofsByn9R5iXogNMH9xwQEXI7RN+ZooBbCSKCd151KFy+0J+BjWBCoGh8U1ynkGKjuWT7XmK/oyhtGuLuKRRcXU4XVyuGVvJGLh7JakBL6zu9U/x2ENFCHvPJFMtlAI+k5XkV3ARJ6PlGcjkj1XKacS6ha9OhwXOkLUOL5u7muHdXGy4c+m4TMbNZIh4XWUPpjQu8nc9I0ys5sA85804t4fw8eQ68b4Jh9AW8biyxIK6b7HEhpAtE8WcYgmFqNq8FyInEFRq2rSPhAroTCzv/QA4sRhU+55gD7leOx1fNsCK6WQCOBTpLhJfBW5/a6U7FVuKFobt7UGGpTr+0MigjnERO2Z/nvey84o5JpNavJ4H1FBc06Wke8v61QWK3MdOR1LdGoLI4mvmUbyobJQkUW90G63Vrnju+STwimbIgqf93Z9hL0t2+/UFT2QKGw2/T7p5psuFl7M0qiR1ZLYgdPsXBuTShUobmVGW0Z/bEWrKUjKuoKMJq0fq4uGmXGY+tyXFqWJfaJTdpzh/dDPvAhmeEhahNfUPCBIfCXxWbz2skvQ7yPdBy2JxYJHGuiJTpaDopuDbKxe0G5V92R/RwNOYUfxc0P7aMjNHEjI4MoEJJPAM8Lkbcuho44TblCOan7SWS/9uq2x5T4Rlsny5Xyrwbl1qFaTEMv6gH2DZiwQcRMRc5P6XWRP1O6Ifc3ZRl9d3Jk2KveR6lq7fxoZlK2Q1bIa4vv7aWBKdiolXGCofo/UiQEe6r00PSZVSfywj/vJ5+6eLSFluSo/7dhEvndIHKLIPxOMXNvxsCMdgd7F0+EMz2duLtB1A6qYxJrxR3LVKdpb0rlESpKxabgpeuAFppkfwHjLFH0iHgaYh4z/g4ulIl6JV8tOEXEez6Uk9TJLg3H/dntBhBQ6vvDbqz18DXVpDGtdCAT0zivU3L1K1tHnP/u5wT02sPd4BVtMiKX6O5ulIAqSRNI57LPyvRIZJ01Mq8Pd2BiGkXFDfZqgkiX/+qlV4xzi9pMA2AntI81MZP4/VD/BXkmI9Z2G5NlsVCETzEupnZxECVnRxvb8Zzsxu/is2hDC3T8K0dnvamIhf1u9f/XGvjO7xU6UjXWXoOjxfSJ1ytmFOs0dfGuuYQLQ9tt9QGY9s6fdP5yK6QyhhvBLVVxVFq+dq6CJpe1u6btxf0YQHCE534tlZ3QLg7As29+eSW1YV7MgeD65G4N/eBt7hxFGTTQprudQmjTue/7M//qvdS9sKkT1FklmrmtiGJrF62bKwcuT3s9sWrPe5AGkGFyP+YL88pfW9Zx/jv63u74oBpdMOz5VkvgVm6RFZpYxXw/xch0ybpy7GGA4Sbe1P00y6D58RI1+0AhBORbh2dYx+bFnG+Doj1OZgb8U828SfalWBhlKu7lgWkqUDjIEI+ngq0eQa1B+fISlsXseb8UfK6qDz2LWup8qVGBH1VU2ZWN2urvzsB34JuyRgHtN/+Jgrh3onYYA7VJRfO3ZTd/FQRyY76ZKaFFqIzVZOeUdF+XIM7JkRaSpv+19FJ8ch4ZnRxi3nZV0dIxTBCxRKVJT7FyyoBekVPjMefuBcB5Wa6j/TPju6ggh+6LNMDC1KOxov70FqV6mokzviIbrig3CruJpze61Gax78CTIyUmOrcSfQglfrxc7K/GiZQptXH2Ftpw61aTgDHAlbOJvpOnAyTPuSnaFYOQ/q2p7Bkfx1qSG7wFc1izoLBHqVnkeujuMQMSHcGq4q4Jfj+TAAf599+KRAMnkN5wNWSmCHSj2Jx/PTAsgj6W4apWn9YBtM4kAtY2KlxFlGGBuWFgdnIw0oSUbclZGbxuANKhOSYqEwFKsytbNT9yhmnnfvjuvOAYgfR6k8tf63Wt8EsFuf8M542aN/45r1BN//iPyFFiv6ywagaVa+ov7UDEhmmHXNLYct239S+1WqRdqLtKC5FZUII0kIZIia1vLn8uIEg5Dpgz5tOwO2bl+GxEsPOclWhaVC2khf7pIpiEHWuJhzhn/OL2kv6zsnDbbWwkaBGYjNxUs8w4hAI6olHLRvDuBut6j4vy2whZb4ERN4NaHtFULpr10kNbMRoxZGgNTur4FaOvb1+1iDBzjSKOGpyjgxjBkzeb7KH3QoOP6CuljPC0Fgrwjl6C2CiEVjQAkSv+jqJVtgPc1qEIK3ns18klBLzRxZQnkzeHqRtqioc3nWVw733IA4vT7SNd9JKbTMnsAxfbNKkFLZy8/UjTkg4I8SSM9Wu87M0m80Ja391PBb8IwnQLsjVg2ioFt6u0YInfZQHHi2XSkwuAQw3XsKLQVqXgImCIu/xui1n+iQbY0RvU5lZkvaRSUBRp8GED6Oz1sdFs/VimAD86lhqgiYJHw31cLlsZU3D/oriqnNO/lpH+ERRfBj5qz6yxzpVQ4F+iisCdx668Uu8x39yoLrMCJvDHuemLibLyqF4wGAfb8/jSOC81Rd8QjpbfXVAoLEpxEIrdD2234QzecsMEOm5sBCyHJIdIkcx+dMUs1FuzT3wdDG5vdFsyu1fRBmX5UZcqXjQkyVO8MurdfME+OzvPcBq198Qd3UjWG5/4fv4cUAGCUZWQFLOGITmzwHc3p12g7uEpfnRN+IoTM4/507gksjF01NETmxYuI4EmHCeVPwu4w+sngXgZk2TdffYzKPc0hpsKGswUxV7HHrOgTJptS74567s1tGIoTg5BOIoqP0EAHsNVLVveSHjrNNkCeXduDFw/0XPEmCoVOveVzs1Q7iApZzRw3XiZT7CScE2mHws9m/TKcePSDGExQCh1+NuwL8axlvl+e1G6LFO0WGG7tE3paC284dsRJqajYYdV7427hxES48IrAjeoxkZCO/HuaLN5BMdNRyngskG4XGlFOua+J+sXftJf8zCr9/vnw3XnhyDFgomYvghz2c3F7qRtPVXTHqrpyrm8U/yHWM1YB7IeSTT2xfMmv5fuLuMysB7cl8h4bku//6z/COXiv5fph5D1ZYAPHxAPTXRW+6y0MRHK/hmtqCc2T7LMG1TkEgIu+mafNm2D5N4wsX05mu7mfvIQZI89ENALlPKPfIWrXdHytR9D5V5fAs2372yx/FfVMDoqpqaImvJ98J7+3krdx55zSFfItKedx3X9thnSeJ5SUo9CerzFrhWM1NapwgWNSAl5YM/AdEfeEQ9yFWRAl44ewNkQzPVHXD/6uS/1dvBvRF/jWC7lUiQ4fZAwHaU/uoSUREy456SinwwanRlM1JVYv+fwFiKeSzhuXcyyBBWmR85n4PxDqKusJbbdue2aQo+puWwnK/jlRrPiLz5vzUQT1tmit3O+6UAikQS2gbo1qvcGsn7ZTBIoR20K3oW0oPKY2bxIoZmUOg9xvJmOYN0WGSqcx86WnjzRCiQ6l7CjE5jD34x1y5rFytZF9B3kUQOpbV080UUFLVih0TBhXEibyJ6yzzrnq2KN/132pa29kzfgc6nUReaYOnDHvg92mCEg9fU6trgxzfN4RWXSWBF2LJn5LH00rsvYqWmtS4rXC9EI693sGVpYh63ORMRxr4f56TZRHL8aRZDXFfI5ExJ7e24DKgMChfp5kt0848p23PAKbwj1CyJ1ASHrUByzVXjzqoyYZePDcsoRnff1kNr4rq/rB9QKSEQj6mpATKkYMslhSPvVCapPGo7IMk/5pT805ntdDEs8AyyQedHn8bJl9DxI4zJspzghO3szVp5+ca7YdENBF1qRxIzlIqWf6FKljc+9WdIpKv5qRbz01byxuSuZhOZCjn/LEzZ82vrz3wkn8Szjt8vnVovqnqf6NIkIdCQscV6PNfY4g15GYIY+L91QQkBL6DGyiouKZ/VOPRXjbVOF+h2UHbO7yRaDr1LljRFwK/EMPgtFg+0qCNos14I8INXKD4nFbZNI2mwHDbTs2sT6JNF5wQRYXM1qMNXY+GkRVynB6/2NGQC7oDavJK7pJhtJ9NHj2LT/zuHqzclrAYjcl9v5D0ETNOaIdvV8NLF07Hhdk6pG5cwP8CLhWwXze7+uyr8oXlqfGY4mZbUAVUuLyBjxjEC8NYoTaiVvUVEL61ICilAFdKAeZu/NyaJZ6LwHaldr9Lzb+p3KMpcYiRtd9aqqfkssSZGK4Ns79mfBk8wHVTlcYx1bAFY1d0ozmaygsWDwJIGvUpKKh5PiXz6LrzwnxAGl7IW/XDjnzRS/wrk+gqGopM3/0LdgRJSRQSSdOW9Btn4O1iWOP3iOM33tZp2SWwzajzWf+K8BydrgsSQudVFau0HKtFwtai1b2zb/LHPq8m56YZV9zuUMLgsbORtpKaHwJ6Jpy1qaLNJt0eVes8YDWVk9XJNohGqO29Gvzy5r2rKh1+t7vKapRNYDzMvMrsUIuja/2PNx+Nw1hRXL/oKnQhHn093J4EcZdWnGNetSwNDQRbkd6qCGaFUQhM6sXnse4HJ71K2RA0qsUDBhXEYXA2464yr1s/THWcpwKM/IX+mKWukeYnusr/ag68d+8gG5zJU7xwRfu+Ym4EzRS99AHT0IgU5nT1w/bPg8Rr7ntiDGci2T/3A6i+5p366B9iEC3+ebXOF3jklUZSPfNi+C7I3tZbXauuR85kvpLcAJmU32lzdaMsjkNqhOlkc+EY1H8QvKeuJmkCPL2NbMJmkOVDY7tnvS5niSJ8XsaW7M6Kejfnc9z3ONrl8ARHaXLWm8ramPIMskdQsYX+Of5QuzATiFCugdA5oqyLB85Ktb35szbN5Q73JZQ8hk8TfDky/9DlFZNkrT3ZATFaMtz4fVz6q3KQz0uvgYtn0p1NNBiJ6UqjRukkYAT0g9d+BLzabqzAvZ+0FgDT0uiu+5t8IP2nS/M4ArUY5+ulF2dl097utwZjPRkDQ5Cm2WupYNSA3/RqBjXrspUPHr+SwidrznPXK7sIhHSAf5AgR8/GbQGw9wfYhxXhroO7xlf2xHGkWkYjdZOhXURrAsJ39pQRgS1CIcMEHfY3DV31YNPK1rQ40seaOTZSD2vqGSKSj5r47NEAjlt6QvP3KAmigQsd1WMeO+58GAxrUHw7RL14OLC+1kRIXrHXFkhIaMZnygL0Pgp3RTMZVXoS3eVZiEP9BjwMjbe0P5vHdlpBUznXGCTqprbzi6FNpFmVHoW07/RBDLrvjovz5/R04vKsrNFmrR66A3xUHNaQFr6uw/tzcmzR3218Z08JZs8/Setl0YCrd7OWv0H/5+Qefs0PBleFLCkfI8kGXPTSD24ViClOnrKMXWZd9h8TgIroVa0R8IcuJXWZNMMfg5HNBh2aEVUXD8bqkn54uMCwGN2zgRUirXVJzpvK4oU9bWdi0MzRhfbbDLnazJS2JGDHWOiCLU1nHqiyUy44BygGUnJairidWiFnSOv5JmlWFW3uTLl67CgI2QiyIg52pZRfxXBGAuswtrwVvUfo/jdvQUN2chWTgnnyo+/1Ixly9maVfMcFoinsYc75QemkPjWdwQSOB4npBuFf1ec5q8ah4slPzH+DMLPkZ3LbMXjYhDcdy+BQy8AHg1ozOHN6b/aM99vtBiXN9ejOPwQSMqYP558Q/AhokX17MPiOA/lMk6fxUaatJ/A59lsH4oOHrrVHzTciq+qSFVDU1mxdp+RNRNSBa2eqrukRbD09uk0YcOTi7Hom8+5L+15Eb2llooiGnByKeJ+MN9tb6qgJUMwrI6KbmT0VRmkstnD5cvw+eohYzJfGTKfcp9rPxLMdJ7SjnqJgnwNzfU8GGimkwUJVj50CEWNGobJTAb0JttMO2HvdjaIHe+RsauILvaLjOjCZNJ0lyW6rqYAcJVp3h2XIxq1aRuc95q+exeojNPwo5IumL/JlP7P4RSY21wtop+A8b6CH7ik9RGRkrETmFaW3H63lPX3PviusAvb/U4EnzGJvnF7TkBiXqI3eWlFkWDGityupVF12DqXt9N8gCRGuSOQn4RHDAj8AG92zI0M8D2l4yTzP5XRhY0dFaOv6bMt+IRGb3OQLyebl9RPZqIZZ5CcXOM/vLwATgzClXZLjBwdDpL5SNywCASgovVM7098gqraA2L2lB7xxSAllUpg3ngymeFtff+LkHFyF4wY+b0UeAh7m7/KEzGQ1rxoBPOdqp1VDzwohiIfFHyJeIFMxM1uRNucEM/2MZdYiH7sMkFt8P1usYnBleDhbI+UiVnrjvn7UZtZY+0BOe/y6RIsjF0oiHUijL+X2ChHwssXrumk0jTkotqlkH0X551hFLC3N/njd1PcAVetNKuWr/duvQamOnhQ5riTrQxZzOI7xK23kXHID8/q6LCSo4yR2sQPT+d+cGWvGRUzyjQHH0iQ6kUZJhFOLUcfFtL9DXEfobgogGMEK5XgroNUNjYXIrC99klUpr6Q9j/FhtLRCcuD58oCtt5SLI9fsYzsZYLDduvZZQUFBIYKaxcDzDYZINKpV+4CPfymsm+A5Ys/AGSzHSu8x3uq1HdymHhlTbdHzGMPOSUBjHODizjyOv5GyOi1I8FtHuIpp+3cem3fWyFnLE1wi/qRld/sGrAp6R5N0m68vkgkd5WkmQC+5kQg79oxjx5IY9SjnrAbYgrJqwNAF/8peQ9KKPOFBHY5XpFYgNs7U7G7LtRzfRoE3F0n6LYtqoyIMnduqsyqlPMEINO05PE9VcZUoYkK4oOpaz8i9rv1MYDaAG0cffkokkRJR/tI11l+ghGf78jN23W1k5RVobKrSAv43BqdrFNGkEP22eJAS6b/VTzPherpMqqP/44jedIn0CLvrmqY5+vq6QDUTJ/Jj9sdbYe+zJUY0Vs5drRjKx4ltAfP2uu82lyc6FlGsBo262MCCLRoDpabu9OaDPt2Q7KBWqhc58KII0XfUyfAQ0KbJNioPhq+BmLj5UzGkUbuxouD86gQL9kUShEhjoECU4UfO8jesmc7zLb15jluVki5sz48f81DMJ8KoBFEDnUKkv6zpvU4PrJRrRONoThr0al1wjLA3qM+mspkEW4mi2P34nZTrGkEotsGyZWXUMilggd32sKAXNmSlYN8US3sjiNBD6cooD4+opYG4LN0ylapJ1GqCCjQ3kcNBDJJR/YcuE/LSaUjK8R4fNdJ5hsQ6k1A37RF9NcgPk1TNontLoW4DLzc8s0O9O47PjlYlZ73TPxl3/iZ2eGV4HRmguOVc4qiGJVKx7XqpOWGJXg/XHk3Th/Ae9zbUT0baWmO942BODbWm6QGmHWSvLmlbWUF/QdDkDICQEiWeG8JyJHa2mdsJDk9rUc4wzwXTLcOjhi/lbIwz6/4I51NTD4QIoq2LVjMvYi5fTd6GSCJxOnYChn6whHoSk5XkFIqG/5oQOOh1N6Je5Jn+sP8hOwNvSaC6F6vP1sfuwahPVi024CZHGEhDVwgiJ7ImZSwlQG0yFNSQ72fb70kvWbYS0zy6Z1aPJkAU34SmrhtXl021MCohIvvJOovUA6T+FrBiK6RO1PKRQl1xLTIYXtS7yukSQvTQ/fC6d8VuD0eS0OGfvvd9bbyH3fP/VJbsrKeCA2T1wH94UrazERyCL0Xi9qvlS0msqGgZNTHxrTNAybP/2l9ScE0wIx+aff8LtqhjM9nL93FlOTZGs3wiHVK8UsIUyP0uiQ80B1zKVnSHbqXcGEJRmxIxLaBPRsSN+xJwVBn49V1nlIoU3ueu+5tZcNOaer+WEQ0SuE6wxqKFvUHQm8f3HBqqjmx6WxFWP4MsmDllBM4HO6qYc2vBBTeuDtbheQKGv5ASDlfmEq2PPnAWWhv12ceNIUi0Sha6pxcFl3vxbJnrDTqyUiOR6DnORpBE285Qsxm44+ofLzYRPQIJOELHQx4rwKkfcIg1kfjBx8825O1VJcGDTbxU6k8ttGsO06wGG36HWlSAPbfPk62Pit+dcrtRKGP/wBmTVEEnmOIXZkzZ8+lGN8DQ8gfS2aMrAf5k0O1jBoh8B4SDEOm5z85f8attwNUsbzWCXl/1dCocwxfyafk+ENcP/Jzbjncd8enS2/73PkmDfU9n+xc9QLzanl85MBBMSa2esUvNf2J5AkzUOBEsZgTEDUTKUnchcTFKw7vRw3aj3bNLeZd1dFnYV4/+M5zzwj6UIzDsVq0BG3ygYjksT87rgcxe5Juujs9k/e8sj/uZ5V9IVIjhZMP00Ogv0K4LPXaHuwUOFRdxReZrN5Sc8MBIFa8Dx6J14s0b3W4XX7Hs5EqdH4zzGCqZ6gSPCJ3lGzBhB1cxAiEpesI33w9ow58oywCLvQJTpsaryHL0lRIkIkg8WMMHYoh6C/+h+3rNjMGtYwDS8W00LuEOLm4KPwc2DAg6ZfYV641R2LAVjy0UnUcL9XYo36omsrQLfx9KSp7UCQVNe36oErAHF68z2lSRJVwCVpQUD/8IByTTBpaaKv+eopAtkWwdXrgtm607O4dk6LW+1jo49kmqBQihi4fv5Yn8H6rFzgOtxqtVkUQxE/BDunNLDuCH3c6Nbt3byWFi82stFxsc9q/mytvU8+7ZWsHBrCvC9zluNqlRl72k3VpjKOMBELC73eUnHNjhCBG9vdtclGS7BCjL2S9Vo6SBeaR6OXFjUf9w2M4XxsmAL6Fl3/CP2zf/s5o6O6PehYgE8MTHhdNQO77RrL5oUVOB81kJWTsXw7e3YHqp3se5vzRKQD72eO0HObItuUqXI033sfq2q1LNMU9t8gPBmELBh067QdxWX/VXulqnkL6J3o5Ep2WuyHrzux62x7TKQ1NEvsxtEKL1hYf1QTb0KHzebYaWNUrfMn4G1c1c15us2zU5zaN1mgqsLTIZqe895ZCw2Dzo6SRUsoREiDyXFQ+8IN2Xb3mz7Habpxp9B8QFfBQ/WY7JttuZ2R4l86+bMJKR3ldJ4q4oExMyYaOtiqKZ75uDQtG7zY0yst+uRAUwK/6Okq09AQSBZfl1pkbdpFnhTaqFrsP1rfRp7+EKkyKYsPaGWrSmaKqBUiCUTC4BBDZHgCbTiL4l9G8INzEXBoBTHORoPE9L+3r5FFM+YyHbjj2mw4daSLRv/tJ618SaeftuPqLuUp6nB41vyFuq6Ic+d3nXo33/Mb3Gv6V+r59N8w7qkgksyNCo1TImTzW2nL6PnL8i5656O/85yN+fFIEnBub9yZ6SEXsSKFogroauhF/FmD4mUkQ17PKsuQgQrybtZ769g/pSasFz3VQW4i4IFHZxww1Yq5+MuVHIdKhEL3h7Kxk5jw0y+UJ/0ZT3Es8sdNhJfQcWPGuzgenB6qRb7bzvNXKqv+zoOpYnAI/10m1g10ruvBIWW0NyuC3l+kQimbVz/fkkY7V1Op01bAMgRyOY/whs0t+MCYYVpTlzBsbWMGpEWNu6JECf0WAL299y3TlVwX66S6GIIAz9TLkwtM/r08VN8kjNCn3nh0SkUFKWiqypNZueA9phKyBuY3nEaqwn47jSZjgNfiiF58JNqfZAQGf4btE9GjFic1+7fXzQUW8BP42Ci0s3noORTuHjzdnjHQZ1P5ld50hS+uBT9BhE7Hg4RD43RS2k2PDiYJWJy1tjGJUqEn+mlwg2IEfaBBGpOFUIoW1MGyeRF1GQSR8V3Cq0DqWb0MvzcGDPccEVmmmUUYvPrsh6jbUlOx9irT5X/0bw12+JLnrgey7qxQqzs+HSCs3F8iwtpgzoxjJQp6i5BmQOxUQdWRLbJqnhRdodyQVkIwgPTctifsaVG6M0Di/e8GNJ4kF58CHi+l53rYGevl30GH3P6c11zb/89/xtwPrUkcntusQ14ys89CgCHej3sqKchmX7ulgakiJLOvdDXQzjQpUR4Hz2Ir0aSqaX1qCMA8L67lmUAoOCJpe6yvHh6ckvozZvEhUmTxffiwJgQbETDBOzEojOPu7/Sjnl7EzCIVhshjVDtYMyQqag1mXvV/NYJmB1ASffbxFvP7WQlvH98R81MN0RzYR8gs9iiU1HfvDEUjV9pXu+ppQO4pI7ceQbmYB8G/XpWaSe7qr3efKMmF+8RdOH+XOGZHPyboPMMrg/wi0zT2j9t2gyRgywfed12QntsOKPqIDWbdmMRK/9RfBSQNXViWDAHiq5BdllxbSjeD3lkEXCU4XrbfHK9XL5V9675FKzHijM35ZuAeGzKD5RSNbbPHZl1rmE8jVzBs8EpH3TIezCXqXbIT5g/Xk5qhzuAtJCXsvn15K4Cd6i0Su5n2QLlpJsAVlqSmNXawxjO210Y/wBAcrqekhHbyhYUBUjdVTPs7WI/+Lv3/SqsKqBlXAyfLexVTzlrMp4rz5JUMac9ZHRfs5ADxu9hq8Y+XKsdyGvZG8fwcqST0NqptOPBgjP06qVx1v3/4Zw1JSKH2QUEFBfgKYxkHxQrUv/I3Ykn0mv2l7MZB2IhBzwAHUt3E4x6yO3BUZnEpZI3IVOZwFUQ9jnURmZlfovTpOGxgvCtuNGFrLIXopGWtxFln5JfiJN3zJdgh7VP0/bxCw5mAExaHOMwow7Ql2LdKMDJz0GuUFttJlerWKnY7veygFLTrSsRLYSkplzUJSjtdq404623A9tfPZ6Hl5i/E4hYKiWLhVTlvx+qDXEfy/3bEQJw5S1DCcyWdqH/1dwTFAAVdE3NHjJYHF0A8lDovIO2Sz5jHw9baXkO1/Tv3umcPcShVj7GGkGZL6u9FkmlfTjtvtK5m3EbWo5twHPkIIymFoTW6q+dwVpcf9huVuqoD++QNXnbghiTXi+KOoKOx/gc5fqeHZfbDabHgafk7Rg5WqpTdZR4ZNc/e/BzbOTQN6ZX/djixxbTlQAA/vwaPaApG3uo4kqRpW0pPgADNJQn6DchtGLFow3YZBFAE/wA4jMMukMzHAE7UGA0nwAAQfABRwAAAAyoN9cA+MA6MkAbf7AAAmz88bKGE84BgEgABIwAAAAAEWpg6iAA9LAAuBP+hYABsFaxjMBJwAQXAEu66AAAAAAAGEYAAAVYfJKYAAAABfoABNwAAyAXACrxr26AFwKANuFbt7AAAKy7iJAp0+cABeVYAG855xgAAAAAALuJWgJZEAG6yKmAUfZPKeGBmAK6v76WEvY48oABEynOdhkguDs1wKcEUv/wUHSaLqzj5cP65iLBzkcYAkGdKYAOo2ED9cggGVApmBxKVpQoYhw+tGOAAAABOdmSxllYqO8oxcjvQx34WzMkst0zIiKbA/VgLTzkSqd/07I3dYxe7oZlGF2+zbA7jf4IcpE7O4PLvBOkC/C+oI/XQrvW5xcSsS7fUpKhEhX6XuwUlU3YNHkHOQEfiZZHNgLPM+gKRTzHDfMDWVOgzC7G5SOtiS04Nn6YBYm9LfmoUCDpG9CUDUT7bw5UKzNoZELn+8UHcUrY+cWG0KbZCeGSdEnwBUhnmBfxS+53nY7uH5TvjRspJlMgfj+bxJSzmNoxtM0OmONyba5XpGA6b2K1T2HbQuJ8rYZCWZYDsoVw1fE6wnp/nO2hHRBCGoskQDEVSziwsN5w/AKpeKsEMPb9NKcmWCX8wtcfR+wAwWBTZoykLa4ItXUUeIElshyhjTDXjojCs0bnbLBl1aC2/fUW9w56AHgEWzSNpIc/ckSztmS8XH+eO1ZTeMRgGu70WolVD8Hh2UR1/z+wU4lnzcf17I8v8H3Dk/Fph0pe9kltceRNl/nb36ZDyWlq5ollnDaES9Xy1cYc4QYGZWIuzy5ack8sdjzOuoZfy8ZCzQ7hU29syvyG1HPy2dnsxWDdH7nQkhhx/HicHLloAz6piwxdKzJEr7tGacZML5ZjOatQgN+qIopO7oH+FXDxrphJVEQ/mkVIxtx0QdPbKPfpuSEgl+J/Lg8cBEO0kSqn7YiMxsnmRtbo/XCcZ3Xxgd2AdBG0KwOcgvKhwf1WSlLOzatYaD63BMRaOHuRZVIhjvtGlDndgB0yjPuCAMGGVKzFThNFaE2DQqkuDTvwnAXyfJ9ih0NrtwQUfNEOIOUdiPg3aRbO520pDsiXBKYOiJrC+dcm+ShANmappxYK3c2OUmxo4trRTF3kZRuwzrrGt95Fzi3lBmtz+Pi1VKWgc2OGvAvzUwGaEMx/sB7N6RQ64OXvCNbnLnXwvhW0ZFdilnhUYzQGBe1mXucYls+8SBy8LKM6CxuBWktAvaBbRNIROWqO4feYPhBdlGCy3QDgJVHDBpFGER2l7izX26YhKJC4ebzpjDRDmKktTP7KEonKiyf6nAj6jIk3M/lELgVSE0B8v5Izogi199GWw8NFtdhszOKLB1oMQ69Xoe+IwZQC+oskN2Skm+tMXy/JKqKRnxWvx0xFaR8VPZDJMp/2eFV6Re4i9/sZiCCoF5zfxf5NYyAWvqsQAJXLm2r/JXMrYI9UNzFIf4L99Ptx/Sk67xqDNAP0L4W1WbVhtFJUMmUbKyHbiKx2bi12d7WuuPfDYBfjrQc4Z+6owLNnUeReTcJvmhONyTvaxrG5KxP8gut76kdiBojG4TL6mTfwWkvLXrYGih9xb4uD3ZoPIFn8N/sERDbt/gtLR6md07iKTiTTDHTToCb6Q1ltmckHbhMNokJsBwYq+G+w3YCs6PBGYqMyNpQtZlu70Iz1+niethBffIv8HHakq3daLUkU2s/zKlQZF/itwIkLKzhget5Kri+3IIDBNcq21hr+YZ3DEQvbFkVCwdaX/yYP59pW2vEDeRDKsklFoTKeonlOnSlihLKvR0oWJjan1BMWDm5Ozhpgs0aAiqlRq8ndm9ITrjJ/c+s0AhKtQKqVQEcsvr9Ye7BaML3NNC51qB4xzoVSwTOBoX+617oTDBqJim+fpBunZSooUAC+VviZdzlIqe/Iu7pmmwoD8shjfVsaIt7KXPfZox4kAWaFTtHAuBBrnKKNT+ucwf+b38uZbDm1WqrtyUwBahdgAKW16E0owzvn3IBFrZxJLN7KMbB3pasWjStTSaEb+Zu43zhYXbbS61/S4hU/qQ650YtwUaLh+QnRoU8GVMB270aBp7vgxK3MUe1pdet0i3ZHgfO8w7twZ1pImtSe/2VN70ooOGR0ccb+ik2eph2oFAA+rVaGWIj9Kend2ESCAa1caClYYYYvLQpn2/rT1vJiAbu/dZeGMhQzO1kUX33rG65D1X//C5Nhik07KzNRmfJtQ8Vj55Ciy92SKqqrJohqIgcBH4BJ2b1jsUh58CnWGak2TwV08Pnw2IT65GOTlnUeeqe0W/uRMykHWUbuvmfdAh/DM5pvNK828galjYxwfyN7fh8CX6amrbJ1Te4qCBEAefVr4NMeiinsLVj4QzqKydtzq5HNjkGyRUCMJl/ERNm0mPnzB7q3jp7scN1k7wgn94/FZlJaoH1SNHTc1lyi3G9VR2sVA4Qykt8wwLP2E7prJdKU/GCYAj6FKsMYt2ncA/SxjM/AU/jHh1C3JeaBZ++Eyivnrg3W+HjcNZFw+R+HmbdyxrlnopV7FwLzgcmsTOI3qGE1uC3Q0EVDx0Fxe83oE3OiXGIX3EmLvPBB9RG9LfOC0/6REFe5di1JNQa49rORTpR4OE225mpTXiuHUkrGnw/FEaBjz6Hxerw8wkw9eKuuXjcProUJS0e8AicoexTwCgUsOmZsBPBfP/cpi0Be+yRb3I4RcYjcORmQSidijLluj+zH37DA/Kn5BOnNcsgvcoxy2Kf10hSfET3fnyUaO7n1mOfvKX3zcSjUzy4DWEwhWd4pOiYVZRimrXuiYEp+FgP88jL0+kwjQVZF7+2MTLZZwtcvsvnETyxw1QKKh4gszzHGFZHr2SZwIVwog1+Jo748UpXd2aKBVwXMJ3zIT60D07AIwHBKmVV/W2Oko64AJUNEOJ89eBqjRGKiNMvI9M43sd8kGI0l9vtAoRlpGuJJzeoMRAR64GTiXSK3PTk2UKM3B+ViVAGMqAZT51yHbJAhMbhnRzo3m/rF3fo1/fHZz1h7d3GgX+0cdPA5qEn60q5ug1HKpNbaLg2E2C0R13vywGFItCSrjH+v6ReMkyLP0tBVXeJWkozUJgsjyOo1HVr/mZeyeE6HdDLxw+eWBiM8eNGaCP7D7TMJtOvk89AnAxyIjO2KNDsgbBT7mldBOBhkJOvR92vK4Yw0pslAqVUOCbk+8hpUowIWOr7X/8ynP55FyUELgL47BGCp1qimQXSKbGS/djpL3wd0eT/ZSsv6OVQBE7Ys4DMEzYEguJ1RM+C92+i6U9U0uBZhv7TpeSalyBSxZ+bvEVMkvgtKCNPDNqv1HsBFjOJCHDc/KgvNKnhWdoigvSsJiGFJEt3oO5KEEVSskBMJihAkDoemoTkZ8uh7gTmgLLOU4UMH5HEnpfkUAgByv5BktK20IdAHTTuCKssXKI6NGudEaf5mzj49xlD1xk7X6C8J8NXb6JR3DnGZBkfYJDz8OaSc8O4+qZwXvPsFMwn95Zn8JF4p4QFboNe2c1VsgAAAAABxu9wF3oHK9P09/QEWcz7xN/Itp4dZIzOFaKgcwcpK0ntaQL6k5gAYZInBkGeFv+AOilaM8pO99pFQ3EPhYMCKhZNk/smtC7lO53Sdw03K1L3hxTOr5udND53HAhiDbvy/t85m2OiDgJjr97WpMZu8OvYdBy/Ng968mbtv1YFdQj2GZxMrT6UNvd07oh9EVZnLdieHlw/8ylfKLH3y57MEIduGaxMKhjQ56Eov5a9fzFRlnrl5Y/6hRTmzrmqe8fTBqFfvITgLbiRCakIbtsRPI91shVipyQ47sXjzKI30Rrf/SShfHcGjiXu9YMFUuBBHNnEDqPbj4Dzz9JaFqLQnNq6bzikV44jixWC29fPFbF3s0fh8Nx+NItLVMMJ+VFZNyP32Bzhp0+KDTCxx0ROFeihNkiXMFROhXfA62jRtk7NAou51HfPDKgyc6gGuQiJL+1uuD4R+bayTs6QXpi2ISR6upHPZC3mcF6OcjFq/Gnk37HsFzy6aGzo3IhJoeQsfa+kn2v2muLM3MwpZuXRVrnicK7N60ILKbNk+HDe0pyov01Z7YZBKRkB2m6NeHNEXn/nSSKLyluHWWDcClL4OqctCiOspyTo/sj1PZvlxl7387r8iTuKgi/VRdskl+4nh+uCRI4CBo3OAVz3MiSrrlp0wBKYA45LNhB+CrdaI6GWRAco7PJrsRNfqou+6xPxX8hDqx4Q6RXGikfOSqpghRLegsUkfLHHgoHXqjaAJXbetskkllG939qy01B1s1WPVgNiHuqQ+CyM49eom+ks6KIPLfr2f5MVi2IP+qMB27PgAIxfnYhgDY3d92vWCNVApKB+aKePbaXNtnrH9v/OxgFoBqgnEjBOX1kBttFOcBKQN/uyifAI6Yt+j+59XDw7vUsgfLQM6EO+XvwdZ291+jkZjLUmoUcVDminE0WKt2RxtUJkZDrTy4B8GBF/kvnum/pbcKeASHI7LHyosMca1aDU/dftD3lJQjxAfM6EpafFd3k6DAJaBlbiNU4VDiVzDh60a4TdOw789Ou9vddw5NGZkLvQJ2Yp5FUekCDNrfJHpJcaW3pIrGGT6tuIf/UedNPdn+O7oZigxorMYYzecmHdyK0EkwqRYut8jdmm8W0e7rYrrUJbJhf/Xu7SnUef6Qet0N94kx6xX+4+iso8JZCGTzItE21v3U+dhaPJSdu3sf37UX6k2cHIgIAupoczCHAS83CacWnUtY53SR+5MTumfZxjm1NZZJXdtZ3BpGGFIRcY93VhgW9uscvKXXVZ8Bmro17Xn3oIZ/pGE16ag30xbCWIonT3IqxXmHFkTVgoaFog9hzuUnc4fUyckxiqEcA85XQmyU80WY51yyDFRbHUA6YcZ6W26xPdbBc9KdOX4/V/gYVMn2owZGy6SAjC9epKdtQk34LxW33D8xJYMv2PdyTYqH41tA+578eOpY0Vp6d8X78coXv40VBRd4eKLMQA6lgAvlIw0YTtur+mSH/fMhY3KYd4JknKGSsl8DM841Gd+w7ePoxYMs5H7WgxH2211c/X3KF9u2WPEITJoWbD1fk3aK8RfwCnrXQsnQWJYtmMFW6i10kTbXVtqq3TOooTX2PGkD+b0TmjxvYsNDIuF4sraki4D7jFWwnn/+ZX3Wepm00Qvy6LhYxWxFMuLWGTVOUjbI1j2Up5wARpgiPgPxFupHevMZ91UymYcpBeT/dvmrpS+NWWP/WDdFJ5mmnjcyM6bra6Pk3CNzcv71YAkXdGB2KIyvuu3hLCoKMxaWOAPBkT6W5BlpXP5Fr08EOU6VaI4vvo+zO8NKRgnWvRdC5rzYP6vqHSkvQX0W4Gb0nsHLqh9SUPeJYawnEBf5aGHsK5iWu7m8r+NYF8Ph98xKe2WbTyk90ajf5hPmTEqYzTu4UTMVgMkcuX3w+7LDrGmulMCFctLJBfrZpd+TfsSgEOH/Wp3kJ13fyXj7EbQBqChk6eGsRHvGzvh3UyEH1/J5Otg3Oh/HFAQ1ku6XzffV1P/dWuXTRD5z1DbsYr0GSrifD0RFPrEj8eiXgWEaQqkjmC2Px2El4G7/SO8bUANMgSdy1KCYP2bbNCysjtePCwiugKTKzQZT3yISVDwbwmtdJycn6rJtqRKRdhw1sKqVhFU07JpWbyH7TsUeiXtIiSJd6FEV/B/McjAUkn3qgXSrHqo+PpyYJYlqz2YVfoyxQXCojpwK3NhJGMgid3rkrIfC58Lq1uu3fkcIwwnSAybaqTbjSpMMZ1XcGCL6CMTRUMi0IUi51/JIlxX6XbfiFYW5rFY2cZjaFx9OKQJSA63PoJBM0lC1Ugpmy/QM0wnnUchScSyBZOEQDTuUA+ROJlobgSXLJicqVd1YmupJhSQiraURT6s2mFo5DgHHo9jfZsRBX4SuS1DUvqPsgUZHrMYvwRdl/ED6SA3bn6SW1pZWLbALkhM/K3DACvdp13MEFemKRBCYC8Gg5haLl2lWA1xozaxsudeVyz2lfQRNL0bskN3YQ6oWmbmK1uhdd6k+lfL4TprrpWm2LrlPdtZTZFnYvssTbW/xEpv4AKafqsXblzFaH0T3/XtpJgrVHd/N9CwMCTq8qLw4VPVwYmZg1fRVrjYMmmZxzLRRwkj+xZNWiYbGgSLiX5fNCrDo+10CxFWqjOPxuF+pr66IpJLWIXzEYF/Z/7dtVBRHsfDNJ+mfN7eRl/d0pPqfHerhXteGPa2/T3RSDZVXXNTRQjXUTBjogiifKtr7aKCLc1RPqOQAvErk6aWKxX//vG/UJC5nEK1X2dCdz0LXg0brvZpWXjQkI4lFfnj+bpmrJHyQ8iZbIAC8ugAAiSAA2Uipa8xyDPTLoW4/rc1MbNIOaeCKAFNKN/vtFEiy1QiE123PbQa4sKhRZ73DrC0+M9n4uC/DGxQ5XO09nt01BqTh3ZyRJwEDbC82LPXGVg/5v79UZMgZIagx8YQyScgudQJDtp3zQa3AWchlbVHNHyD1suC+NjGjVyD4/EocU5QuIdAqSfTshxGZOIWlHksx0bU2KZmq4XGH+zemCWxOgKHSSXtnDTVIdyTzX+8o8fsnuNK3hGOGW/vVSyqTglJJmISOZ5L7Oy7x/UC+7lX45Vq2ODx2Gb1+Nz8RTYBi1w7ba14PQYk5DK92wvZ321aPrE4Gbiqop4RpX/4iiSH3AjOlUXbsnRWigzD2W4QRYEnQ13E5IOMobmtcwWZ1uDGy3ljnuoRDGZXkhY2x5PkVgOVlq2r+qyrcORzv3yRhDJDphoQxUxi5BlEI3jS8j/7hqvGOfTE4nOF6Kxbx5pG15DVYg1wOMltweBsTl1NCEa2TyrGoYm906yTpVx7OwoBY59s7AhdBKDX5QofZ4hX+KlYjPxIfIm4PzGPKMk41PQ8Ye05dqTq+6RTWON+efA5LnEXIFQZOs2gxSgzRMDt2hIJfEXpLXmYmemcbY1F1ys7lXzZ/kuORkrt64mip+72ge8MKZpwhn+H9IND3kcWMBdeMvXTbKK/YKcIiB5dRKEpogMKhegZquCchB2r+2Ho1AaLdEMgUrJXsaCzVlZZQjMu9fsx6DxQarGUKI07G7bmQUO6rBMvSKWJg9ukX7YVDqS1u2lsHFSVhNlSV1ennVPgQdhe0aI/+aNMoUnBzyouxXupUm2FBrojvuniZhdSUIet9Yyo+c2m2CR8sg+7cgpXIB49AO9Ysox7E2qmv5cdqyTFtEBS4o46Qo71sr6miq0hJ5Ay2Hlv2JzAFnA4MN5t8wV4VRVBlllarJeHkXMJn1iaNFo1JQzGCNKJrfI14atEhJVhZFQZYc2RBR4wbWbrVIOd1yP+svLDuwraM3vWwD1p9/V2FasNArilmxdewEEvJAqPO7UzEVGN663243ikSsvNmhYbmTH9sFMuFEnMNeETP7i9QSwmw4P7LTkVxWw9ulkvgc2PIRiqomzbl90HAzxTm96V1b/3l6JC7VLd8rnHTNfqIIGlzdyMFe7LYno5l9wlj0WRQNky9VJc0tztzbogNa9NlZXJEdJYWZS48HYe47kYlasFuXUaPkHnsIl8DlsofxwCp9f2ZRsDDpaTOHg+vy9o67enXOqhQbuzTu2sXhoFpMFgUVum/VJdsdFsN5YHcT7Z0usTIQQ+MKYRlpoJhncYFMdF4ZVwNpQe0NirG+5wU5RAG1K1ldDF4AfYVeyRrsFzJeTeaoGpfCM443aKT2r7uYjS+WpJRf5JhZFd8FD0NcZkwxS40OSLV76g09HUrfu/uMpZbQQ6wcc9XlOLtefifOrLRUMa2LedZ6SXfLEX/rhWZ6ko5Idb+WPgy2/DWCGldch8YOcfj67oOMZLiz/JLAQfkvpybpJuyW473Q9gbpysDsnZ/cNSPwtHK6nXJ18Kfq2bybVP8GyX6N4+BvanDKVKIDzmjntmhOO7MHFchY1dt8rC0RI6HEiBNCuJBeiM2wkcRuJFvjQYH119UZHTmGqIXvu62SCHvKhzNEc4jbD97QPiAMi5dTgk6CtYR4OJENrGzS5FAS03jpxWI1Z2/gHMRA5zjF78FKwvi1UKmQSD/Le8+DHc7BlhzgtwIIK1bpcHpVQwaRfJRcrmC+y3zxBxJmVG3ADsogjH52WuACnLa7+y1+6Svdh3hSEqb+G/BH0f1Z4+WojGl+bQ68zZfrrVFPw8fnqc9JPXeOeoWiRlwRPvgEaR8ddT9RphkVtf4dbQEJD+b8ScW4xG8h1uIUa4ikYxjBu6nVqkuDrA7punHMaedePalY9y4pR0LIe0L1QekITx46TkzC5iGupBl2K5bER9p1/TpeezAQj1Lq2RnzMGbWfnyfkF+8FV/WuQE1NyT1FR+LD2gE3dJzfIHptIZUC0IfCq+Sbsq8LmG9GYY97Wehbl9jCUeQKwjgB9ObTKoQo3OgNg70Lt+fXV3ahgQAeLu72QIx5N4zme7wLh6ilTpk31OzYf9OvhxRdJuQpgk0mo+5f9AY3nPmNK3vpOLBaPnPmd5v4ENFbfbPQ0c534f5Bt9RuPZGvHrWGiygX5sfE/mgh1YBS9uda2sPGZVX4YIiaDyTzOmEAMFUcU4xYgh/APbQaLEw63Rkft1xCExZWRQcBghZnug7ZLDVSaBnbPUvccSL0daGfr1Jtx851Df/0mFSWGinhQ02jv87r8VjS2C1DhD2vlMvUsnUiIvDP6LZGTcfHcYUi+aj7FD/XWktXij24RyCZBz3lb0WnXp+163P4e2FgmqsFP2bA0trTgZANUzfSo+wqD7CJxAf0oS+RnutVBfCvgOu5dTe1r/syvUZLKwTmow/EMeTe+YBmHTdhz/liCb2CGflgAQokZGFIesYFQLmpnaxrSVVZfPoD9D7Rxdz5a9kYxkEiY7Z6ZBR9mgV3h1V9Yt0YILzgWDfuWQF207OCRoR83FKwJXIUSBp0Mtn+mMjEanWcN32tVCF55S5iQ48CTL2vv4jdknoHzzQxrmISG7m4nmFLL+naIWCGGGtYweg9UIsv+UDjrg9arUU/goLg85eLArmPRdCXrG9rw9uy6zd8yRV3mY+zWOXmVAd6tAHdCJW+H/qsIGkAk1E42TXkQAy8EFDqelkVnKFthmtuqN1Bg1bJLaij9WdTLD0krmgckpzpBjnRoQPXa/lwQA1ctpIK6S1P7kK4BCA1QxzrYj6YwAWBB9k5D8/wORj3QNJScq4biu4ddpWsvmziFU8SrXLEOWAJ/53mKa5vpC483GN7k5We0+jIo+bJRrNTijhhLMkxfFShQPeFrvKe57swFjACwouCp1/MMzeVp19sRmcezsyJSktwv36J6NXpzRY2BS2OARNOQiKwpLGWu1GZ0o4YkkEe5c9Z11Ezxk9uDUWobWic3eY3Ia1ty3RCJgd9sbIuBnfsF4uz+9L1206U18kBy8kx9RlJqKql4QocsvH0Ujy+usytwmLCszuc6JTr0wSh7bHkW1FeL5AUP1Im7+Wje+qbJeny4/OLUJFcdQ9w8XBTCMTZ2TMKjxWbG69BWWiTLVLoEnOh/1rUXTeiV5zSvYThmluwht3mIiHOMDg4jcvtgxSMpraW8UXnOG/g6Rd06ZHwnDg1w+pKw5Qk4UW/h+u53H/xUNxMFOMHJsUskRwH0liWTXHXCcH8B4qWyHl4dfA0hUqeAOqAAABzEHoI10kC8si+9QIdx80ICl4/TaAN5tEnbBWeZYJnzp/dSXOroi2/xFgZOtLbwgtvR6gJGgKKcpRkMZhLTgYxW4V0qGQyzkvNpBhIf/I3JbhprLA1U7W+3MKwe1PiYbQ20nf3jZvYd8jCeJ3Qi/MDhkj5GafstywcDq7V6dlGcaC444caqVFEn+sAvAEKHpsJdq8DUFSti6JcqG4PIvL5yP7rIZUWT2EQrmU2fX0C2JlUpxX+d0w3b92BDwcEtmJoxcMNn7eIXXaX6hOanWaBJ+XW+oXQhuplpABHfr20N4VFH2apPoPpSoxyTiZzp8+p+6+Xyy4sY4RxWVpHZCKIVThKqd95cB5pFNiHGQ3iYVBLvFzIIN230WrqmqDedBBObJxc+yhVHgRNl+h5XT4cV6sveA7arRKtPvnWmo6Ggq0ANvfwKUBmOO17GqSnOv4pGr6ZHlRVujit+mCVMKOOdQ6y/KCpwhlrsipa2cvQ2ohDuTwRMu/xRBYwQrAw9m23XFhyfjVbyJGgjrTGDsefgFPNQQMFvT9IcZ+45meVfnE14xypBgNzqZnbpLSAfko+BTR4cJOVgSa43ogCt8vzlxI6v8hkjjPtedYQ+Y5S7/FI0qbqmqoD/v7BcvPDavaMxsUCutbT8WuBIUqj+vCwkPRTjlMu74My/yu21CHTdba6wswn+PkU1cIiz8o84/uV53KDDaDkhNam4SaQiCipl5jCyZ7ZGjLTCovYdm/9P7WqEImaDQUPvAChXNDWrCW5p4nMZsustiSABmRkfvHKjMUVADRN7C8SZQjd7ZsuoXf1nlCJWcZSZWHugL5CeC05ankI7nbQX/WEKIq7Kn/aMIt1wLXzAHc6r7fROkqLQH9Ih4BkPIAtH7nSoneOIv5+WnB5LlnlV1RQELbxNUwtpjXvB/iI3H6REfPYNaaVyIdGXOkhVOTjIf1vzdwQsyUtX6yM89kvthhtH5GAmzY0MNLZtMYr/73v990F09L8+WfmEbzCa+XV5EIPkfkDzvSdwzxSwxWDxZ3u2cflGu8VtU4aUZhTrmVm0UNrDSoW45sRQxXSWBaj+FoDx2LHOmUXAsd6kOtjrFM+gbDE81t4FIAznUnn170vJyb8wthd3kfcrUNv90q5qfYMPDfw6Ae1MxSG1vJ8mhTSE2eRed6tA8KT/S8IewezgQK+rWP3SpDRxXJQ6cNrcXJooe+LXWZhjGp4K4p7Dtuk3z8GS9465A21Ebw94HIWPuwqTz//ZYBmimye3OGmbsuQFdaviqeWY7lDLJn9wcxa9X5HGNaFP7LqCSNQuqz51tYp+EVxcJqaVDciS0mLVvq0Rkx06NRM03VCwZh06BZIOe3jybdayirBp32G801AJmL6vfZNNPqzRKXn8a0uno/Jpe+wpbEA2srxMybqNI0HH4EFt1VATxiUb96i7o5VJSO4ZBang666BAs6IlxrzX72OXdIlXe/Wt/z7qjKau7J4DOrcKnwLi/o98XDl7+01UHZv8PRhJUGlJR7Q846nM1dikNluDKAoJ8dhw9+7IR7NmROyU12Om1MBY7NGrxnz7QnTQu1PK4QCJDpaJMre1KTACZFQD1HQCaxSwBj0FmdoeKsifIzBKqulpvL1AAujfkySz44Rp9zVXFlgpzpFYvPQwJbCYUXDVbHKSfXHv8I1/MX4b96ZS3qichRydmeyHdyFqsJam6CwTUw2n711rnwjg0/lPGNjyB4PDlmEJLP0+ccHTFmuXE+5XmGt9nqSrgNBRkF0TiHvHlfBTpQ6W8Bq6lvvQpB+NPlGGWmov6KoXNn7+VpmKV6KkfFYSv6ut1JqIpuk93Jr8zRzKHugee91neLQj1Tv6d/XAJGrBYCO75mXRAcsxBjyqB0BgYdaVWnCLUMrJqRTPLZJu1FNGYpayszlpmmU7n+P2R+dOd9+PbXynqbKuaTQhGAnJ1GJN4c/4kck4fiOi48yWbHu06ZlDWleXnVMkWsg+qHdEAAsihPJ1KO9wOrhipIHWBU/ZaAGrfE1M6PpPSc9z5B4huu4lkJ/iO+2Vzi36ha0cH4GiWO7aHIzqMxKIpcPjpTgeuVXSsAEjJJvJENZNaMHCmIIfHCk9KvPA5ng534dujRxv8OgsWVNESwHM1EufdvCKMl7uI3DZAyHuVXoInZMBKXUvbmYWXtwRXiu90mLiRSQ28tFaf5IQGWkwrbRXDuWGq0fZd64IPVgRB4j5wi+8SUI6uREwEzu9LHpg10BuJt4OSDEbtpgDaoonKj0u42BPCMbFBZhiKpgq+LMbWVUu0ZppUD8KWKv8GIcDmV7PDFjuxm36nI8rth1d6ubVLff8peesJe3iV8q+2IDNNn7NmuzVN3BnX8vCjyNUjz7pYIMkXzHv0ierVv+pO9KG3EpaEQHF8kTwiBO58KAYDEgtPQLkToThNjCxxjSdl9br0NCq1x21ciXKwHScSclwDElxwa/oUfYPRPpZ2capnKgro7L1dih1BtOQNH3prsWOzoC0JbVSApkJEIuET5HbrykHWm2ClCEbc9SmIAE75cL3YI3QtB66hTDkGXQPFO0sp2M8SJr1b+xdcoGBESWgHljVz8L8lVttIe2ZqDRkJQCp6Ur4CT/iQqjytU2w0elP2UQS1kXo+k25Pnt+73n10c0w/3HEOb8Hl+lVNoJF0mflcvX77dQpIlJaUkcftJ07lyICPMFG6Q3HCsMOevinAX2rx5tzxkimc69j20OdkQQn1etiFAOCWZVJlP51LOK+aZqOVFFZLTqC/mWJkLlzyJi1miXJ4Mfg2ADE8+WUt1k/c/FEtmmx60lfS04I+bVyNePRVImKy4C30a6P3XeM4VLKTiMhyrU0OEOlmMw2yh25qWW36Wd0hgRzuiQ56PRmVa8SG9EfxFFMZAUwMMTlt4ocl8uuwvqJwdAE52/cr66tCsbMQ01Pk7EvsdE+CDHneP9DH/xVyTwAvwr+T4e0BLqX2gtRCTzKjcwZZlKeRsIPhlGtszWMd557t79obIJu4xFBQHEiO2/RvejLZMEd4wdlLAJXuoeBJvIo9aViABgeKa9jCZRh2xPZj67+GPOLzNi741n4rtTVMBkhvOX6s+GuzaFTR2IQU+Ub4QGWw2E9QRRCMpFiqjD5pE3ArBF3TO8DUiRJODH9YyiZVPCEM15LqV8bKK1xpb4XpA4p11RZBVxuYrFyrdNAz2462pymVAQGUNilvS5fV1w1DjGPheWIh3S7uLPDoEFUp9sHXk0IYHh/EieNrico7LdLy2FG3OVcGCOBwaWxO63i3G4vImmYZai2JvwjNqA9v7T9ulyBdYrRbcAJrL5HZN5bhK0e11nVGd/1jdmkJV736HM5nY0Q79APjgGFbxku6YzOZiJB2D3tfChI1LlvkwVQHjIo8EOnS7Aq3KqBMtmolUI5o/4RNARI3v1mNCJZpOQAAAAC4AAZe8WVDnVBnZfqtD0W8msRszl4pRRCOoMH7iGPCKmz67Aoaw6Gcyq/m6Kx1v3Cjs3OpcK50Hd7eXiPHriCVzTlwHbaYvraVdP0xnXClgNQzZPXvWgtdW1IXVo+YE9Ds+I5Gk4fKJVHP0qO96YPxdHipaizxV99E/0qxTTDDDrWfdym/FZzm2pxQovb+oSV1jhqeDOF1Sbf4SpHPqctBAvFxcdq8w44ghSRoiG+uK0jq3DXB19EieHlnOG8MIkYXpfTeZlGWkJyh1rkQ9cE0SOph0/nqtpeyqKDOG6nHIYEpKnrFdSHyEcByptLeXu+fg/fQNkku+5cNH45JTH2TQ/rreNwu+N5jDtKq254jV5ydCv9ob0cnh8LbumN18s0Cz5RsfhiNuF6rkHj2IhGjrGdx/VV1llZiQeyErBcn+404DWh+0zx1rGplnz2f+IBRb48eBWU9zewYe1A2Gskbk41DTo7jj8wq1wBzfawTdoNXn54st3sw+hjf9S6+dA0GaSJ9UiTBB3bA3UTArjVvHn0NWYmn3mDSwcXYPQMQzo7a3e8WQrgRdNAb00XKKkCxTEToloYBnmawuNzZScd4SXt8DzL4KbmYOLhQ0MfmAXoI7dSzhH+JbAVi6lvGCA6RkU0AvQkxPz6LFypOPn19Wzn9keO0XaVx7tgORc8wTxaMaD4dl1wafQABQQMB7f5an48kPbrHqw6vs7cHA4NTjD7w1aBNhZx37ry0zDfulKXitgHY65GgGlAuBbqGeW0M1oiRUHWkMO35R5toTE/UOcXLGv/ElD5K703AVYbJBtThWIFbHk55Gv3OyU7PHUvfqZzC6HkBh5npeQyNV+U6t15YGUcZsjerfpAih/nGh7uUSbYqB8hOWbNpQFQdG4/brhqjSlHT/gYZQhLIM9zmPnA9hQEpQsTukYbu4akvmSzLZ1IKHaQXoOK6X8v51xQq+0c8ZXNIXAEYrxs4alo+ECVNhWbrteqlX5Xf1knrTokdnh0KgW9ute3+DCHFnDECwIL49QAcKlhg4MkBrykz/spUUu8ueaUabK0teku4pG1bsKHUMkGPgVJaKRzw+l9Ec+K6YLdUwjBwfcvUuefwz7GX+0RusUn/LVMmpKZhBoX5Z/hTG+U46yiXnjXydOOf8DzQ+1OOBVaYrsKccj4S23tvXiPSkbHFU1PSYvu7SSy8jTE73vPAV1hP/loQOj/sHkc+xvv61nBD4gbAAAVTrADScMHrdYYkzfrUuV+H49I6yoxyVxQJbvk2hvsWpxzsoTgm2UBR274gCxwFNkB6UvJ7kIP39SjbJxuahf6Ub8rPbbCX4PPcrnJUDDwNrevJD4aGR4iTxCg/15jxOJ75VZICC94n+0m2ySr7KAhjDGktbzE3xf0Zp3xkOPhKoVhrSCpkA+WRULjNlStyEe3XQkunslbDtYQz0sRrb1kuk7ypGlLkxExNkJXBR2VsMt4f7ARjP0BI6P0l3CW5PFf/TOy646a+aRxemuYDik4SD03lvdcV2mSZ4/fmGWKpRwo5AhBQHxh/xJTJL84Y/w+VmreiTNeQp7X7Y/Jbl8gj96bN49isKwm8iRV3KOILnfPnwHI6wf5EctWBJbQLGVHaRjFCCB2c7tVk4+UPbTqRWJKBsXzC5gcJ4HM3bPmsQn1JInCrT2nHOI3pWE9f6J64yOZ5NKFpt/TL4grEninrzni6w2LeMeLXZ2BING3BnyhvLpgpPZlDiXuSbVqxgHWJ9HPLTDZuIf3WixKD+8x0uF1lASTi3WGu/5wraFWd8olVG0eQlEpP95knZ4ILRqGVhTocjrVwL2y5GJEj8gYOWo5O+C76iFZCwBEvuJEAQ4TUsP5bKJq0Q3MgDfZltHLOLLAOjJSaAQZdwCMDZw9/EGjHuHfn95/pdFRSRAfLoRDPpLmMkorrRleNJ8RdrXiDDLtbivzQ8Nxj/CaFQR+N1GdnI3CgJJqaLtcuTbF7k4t+8gljwuh8nGB2vXw2C1DOurVI51Mf0PiT4s5EQnIIc+c0lcVS3Rvs2py/ZBomeJsnI4d/Xjd519/FL96dE2fO5InNvrF6F+F9OTGtXLoSd7YWlU+wfb0VD4hebBZARhiBOBghatHZmHhSK3PIpp9O1Id1rLhRXTCjU7nl+YI1UtYViQc3OcIylmOQelU9yF4+t4uayEU3P7FWcUjwTZ3K0ht+zaNWn9Fk7NjPQ3iLPz14VyhwP9uSzrtkb8oYEzVUT5hy9G0V95YzxKysGifAaDt0c1Hxg7aDKCxzx6p8WEKmsQ5HoKY7fxOkMbI0k7arESIbm5icIFZRyzmCmwz2s5/64RN+20+8itw1l1gWnrt5nyupkfuYODtd3o+94tiUyq89mpfzH4LH0dRMirQHCMNbMqT+8e5boLhUZSSNhUiiguyVfeVUU7RCS6iRvWIT7p49K7RSHCBcFki9+pg+af8ujkwbZIP1+8I3gkPqFDtQ1hyICNtGKsPAh3bVG/PMKFLc8QWvqErMtM/aMkw9/IZR+mUOwxMlvbfc1LPJaa9M9MeN3UzMutT1MkWLh2K+ZBKCwQfj8hC7frSz5AQZvPN2SV2vszKktTXg/WXzUH2kX5n7GGn07LjgrCGSFO5eJL4o7dAmfGtzjnzay+/CxPy97/pKssjWXRwqG6+0bQ/BtI1zc91DqQXkDMjxThHgyNlgiuBgHLuO8IPCiF37PZq7Nc3VLEtv3AK5UWEe//KW08qO4khZaDLlFJDWt0t64fQ3LvbRUkNthtpa7D+gb50KrQaH/MoBWJ7Ik23/LLrWG8Oy3HvgEhBkaJLWfyduCFIxg4YAijX7zXDlcwn2EU+OijHigYxSw+iK5UQW3H8s6qI3txwmRhNpecCP2wwjyvV1wEWABxQBWrK0h87lYZa/8AJa0R5Kd32GGRkqYVdWRgMRlxkf1Eg4ZKxnaxiidHv0c5x4oQoXD0FCOVRzbT90I84+iTEQiJqEkxWz7dvScOQvxINX74W2kch8uVAlx8Xo9LwDgI5soXosKiS10beNJa6srwHm74ZkE6Q7A+DORe309P9HD6lv/KH25uyOVUOjHu3USvLMRsNxdNq+Kd+f+92bRJzCdLmvqUYWDOcf/11/KSR5GuiaF4gnG8rEOxM2/x8X8LpRGacYYcC7yCM60eb70njQYk7YMiQGoVF4l4aW2tSzxERcIY/qbsoKynpzJ4UTRoVn2aZbwlwlE84TrFQ52AZp+lZU+h94f+LIKxFg8jiMgEIliVG2ztZqIB0vhq+6wZfrnqMcRQnYSmnHozLWrenlUtCx+aiWNpAMrKepSacpsdc3v+QegxMtgPZ4CZYqvD+pvrO55GjBJSwgnHn8+oFcN/83tyLamMS4m3NJEGJINRfWNcresVglj9+7KRHCdgFJDQPEZ1qYWy3qvA46VuYUDX5vFRU7OoqX477Au5BkShmaNDwpfH17bH9+AN3mGvR1kh1iEqoP3J76uHUyfUDUeXdMrzctPkmzEbUsQYQqDrpas3JNLqy9hF/vstYJnYjCSrKp0kC12l7J6cW3K0kVZcjn4bNX/E/m9X0uuDySCJvdRfjz3zTKh+8/Yi3QEFlZlYknsFIl+E6bfHoTt8yqnvBS3NeQpfY5dK7VWVd7NjXb61qPu5KY6rL2WDnK2UK379EJ3NVpooBP7SGzhn1ivb2LiGV6+FLgZrpOeGROmAYb3Sp5eYekwP9v7D88lpFVuoD6XUcawQQM7EhKThAzJe3kiA2uy/aJboVUid7XvzwDsN4KpWjEDUfCuCxWrCEaL5v810neOj1mLb/ECCMmvCFWjd+ZznAz6Mzi0I0y/3/juCi1e2tu4NiD/R7szdoMumpvvXRlQ/BGEOBXxwTNoM9wik8VkV8FGeRR/Y++kGCV7ExYW9c0+8bo2XCiiso+QWFZ8TS1M3KwkOzhu6Qj/yuFI7M4Dvz7WwZ9Q+JkCGGKkuwAH2FNRV0mbWOhiJxSm5AJd4T1B7bNhsYEME7J+em4l8ytSVoblMGbx/qzff9Y7iNtx7l/p6wwHUciY/XO/oVL3qjU9qSimGqmeyMpqzRwt3t0y+R4aaBcMpxaBoCRCkJJxd2RBsU1SVwwDHPEb6gM22qsCLQLOQRreHwjVvd20Et4iWscDDtaxa151sxLcNqCBNDQKrmD4bscFuT+WsR8IKIrPUKZSuz7IA6qXIhtEQvJFhxAACobA+dxjSkPPrQbwtMHs1ua5Mtru95TjufCAGNSGnd0CwpPqI++f70kNiC22jYBCnlP0Z2FkW6PuRjO+Zdd5q6PII1zXn136VE4ca8YXxNmNJh2Pl74n0ayQNY/M9ccE7p9sHXNB63+yJEfrSoL/xQ6EYFeW4/rvnlaz6fHdP7B1KVZcMRDsFqZwIm4uLZVCzIgmxkTFZjT8vZXRZ3M5df+HHYDa2XBqC1BsoQg5vozR8Fnn3NkUWItzVaenDxif4n4mTD1lOqg1mdvyNZmg6xsNoVRRixDuPvUolZ59vBdUuMVK7KcXTZtRa0Z/+ycHeUCYvAfRIahFRCgI2IxtyCevqcwRK68oaftk4mYrDIWiXtT9pJjyUyxecfAAO+To6vK5IgpLfIZRiEyczdHVSwpZYZdAdyKEWl4ttmnFIn0Z5FBUGwNU4bFBi4ob2XQKEAP20zbRE5gFbLh6PYYhxBUpiS8SzBJZ14eOUNikke6k60sXIygF4dHiwS8+YqPwrlyf1ZT8Ng3WffTO6w+r0QLkurYC2HAafF5OMFS4D/o/BjseIlUyjywHsovLuavkvGxfCD/37iq2rs6o0ZttLQPwAzKg52RQWuxUSlWKOAWL5k+/Ww1q0aqiWdkRJ3vyVxC2Y8+xt8+m1IUwwUDA8E0YZVQ94mGGWBY4gRSjF4PFCtrxeEYWGU/0EMFqbv+wNSna4hqd31CY7N63hrrCwooX6LEjX+EMYNIeQNlxJNqzj0PjvbzoZSAWQlWN5RtlHC8VSuR0MqnWvpyU4W+K/fHYFY9uJqibMK6bP+gjpIUkH9mLDODRE/eC68DQnlP2AG+th473cv5Q6BM6ElVwnu96wK836ECF//St1o9m+CdDs6cgcEX8S2FQ3/FXb70uO2ECQY9ad/yu4A0xjcSwYnNBKmf/Hqi6mgNBKqWPvLE67vheZJqwiiqbQGEHiHu1y1mntVcvZXGw0g7fuk1ex9z9m+c+9ATJVka802q9wXfZdQWyrrPtze8Hv//a+nDlQPHnBa1GYPFRIvAgpJcoFZTeAqIybU8NvH7+LvoOrpqgZznkdw/1ECaSjtaNMWZwB6fJclTBILnK5YRoJEVg900/jIs582YS0uRI1UqZ70EVKGHgK+5BhOxHewRT84ycxLWLKfTTxS0Wc/Q7wgeClkUw0d62JFw8m63MbVabH7hv9+luRddq2c8ouLfo4dMFkxupIaJfEHWqCtQgIFxMs3ggpdVicTnhd6Z84+4e5qjpc6yIAQWoFbBG/MkQy1uofXphrAIA/PYbN6HaK49E++omsSy5QE8uW1J+1ZM0wQ00OAL0AkvQhNLE12yKiKPKXlsMfn67LdzKOgZxV7YLeFtLuQhqHYL90W2l8PD+mcg2pHk+L+VSCkPwCs6z/9vfIng/adUptA8zLxucWHtoe03r4cSqZhUNDhJOwCl1FERrLqz5TQVbIWnKDfsIPm2VrroiK2RtV3Z22XkmYIWjU52XNltkhhuQ8OlLtk2q33rNlwpQI3G6oRDGYyEzoKflaSyT0ENDtlJhrXswjD3JTnLCYSvRcrHcWqjs4/6Q1zZMZEKRFuKcveR1GqfdMqw85pJaJJdrkCQyUxs0a5Zg1Fh/BF+NOmlj0TyphM8E2q18Hn8ZcDNeksOrjhugNYrRCH98Qe2UFbun2UrhH5MEAN4/hauJH7TvQ+Mkg7Ey9UEgiuHP9/r1WYjoLA8/brEzcX1Y+/Aqu+j8BXZO6g2qkTo9mtAJAC54M3o5WvUcIoyz+WuGbWqgInDTaU7pgof0ZJp/9y11iV3NXxXuKNssVUGzINNRMNq9iEDyzW94JFA2yR4u+Og2AdNWZepxI5qI7eo+Dw6rc9b2O7FGvp1+wgQPXR6wh4HmpMMNPhXB9VP1y/cISPjcR/QUzfWMPFZCWoOCY5JgtVIaVgnM6Ld2Yh7oGWaDU6cfDH9v57hNZtM0RqcYo+qYrDw0J8+b7WZywDwP1g264B1XWhWx+NvVWXY5eDmaf0m18wUCJpLbXcafZacYiNb+qJTUtKBt/8DxcLvGFSXZaV4O9upJtAx7EO4EE8W+RiqMJpRXLauvSJpzziJImIpin+2cSgoHOXggWQmlVlEDxG2JKN5ncuTCMD36ru5WirtPOVeDREZ0UO4qq/Y6P1gfUVnlwAuYvXNdw2vIbj+UHGL+kGSbvsXjZyHJ52sxrUXlgeYHNXRmCHdywXz53RdPOJWd3Zs7xL9H6uwZWLnMFqowU0oHdIFGhnuHviB1vbImGjaBXUUz9DtGSHSRUowXWmU0DZWp1oh2q+slXIKCTwK8c5BOwxYvthpqYVHNc+xfGp2acyHpkNgTYB3mE7fGLs6uzeU89Yw+dMRewY+svGVDXWVrMwVIgC/uhXwENPQYOSfIxL5ahL81GpoSRElX91nCMDihYk6CJsucklCa4PEo4oIZ+Hv0d5tVfarj9gqIP54VJXVuGWrOv4+xM4XMCx6w/ko5UhVe48tV7eMdhVcInFBMfail2TtNbBBuBn8jieLL2pIyfF+iKykzfg4ADJUcOKSvG9EA5uo7gbw5z+7B4opcJVFaE8wasPoO1W7hLjCKrcZ7PrU4B48X7HbtKukc0qCwwbg+mKLHYGKXM2IS20boifHmgJl6FNBUB4+0kSd5kW+ndQFUvcv2YvuECYmXhLWyInzePCgLs9uGVGW6pryzZqZPVw4a9s1PS0dtO2MGZjyR0Q2izjzN+0hcX6lQiUvDZ03VF0SNt5nGdjtP0x3/pndmBc5GgzPQhS53DWHUVz2TaMZOJGWk0m5r3Du/UcL19p/sYugo0kePebnmigLVW3Vsv/+bPUtBA+XwMXryejM8rb0HBvFbaCcoVoR5bDb310m5kO93RkrksNds39F6cweclQNa1lI0Mm80J5mGrEfKz1mfPbLyIfvxFdJP6ufH/gjZSav5XxRk1ctFq59Fj66M7kuYqOf+UAlrk+G/WZ+dleJb5GwiNQv3iS1G2VuGAd/aZ5ooXBzk4xDQ+3gI/ZStg98L1wpM/NJ+8Dhg2y0AZXiZ+++sF9cbGCzOhZ7ScaSX0XjC6FX/vCKNTXCUMqJAOFXHgiQ43JnFpw9J85xE1sncZtlqm+f57BktP4BisL6ywPC0zAAT8nIABnOHSh+ujKe3jd0vWE6j89bLfXiFLu1Wwa7Av824R1b/oi0/zyensBIonTZKM7er/DUkhriZxh50eR0Y0f+34TBCjfBBMDJ1uC/8ipXN5uE+/xDqggnjkA9/u2sq9TZO+CQT/cuBwojmcz9vJ0iXOU7hkLRzQ6QLnopYgTnEnxBeH/925+qG2RqicXwrfXCYw8lWWpOSjPq4L8jDzfDULc7I+W9MC+g7kKjs0F6WEUlonXjolTYzUfcm1BeKVXgwohsw7oCjxsRmUN8hBuBdm4pVY3u4lTaWBF5+QMwZjfo/9GJqnYQ8Yq3l+ZhjNYX6KMtJCYrxsXkjzIXiFg5Ot8+jwzMOUmU32JW7vxwedyK+ol5Is3OwLa4iHjKn16G+yRewh4quh9tNrqyaewZf1pwPmtnQbtyvjnupoocVZUPi65q32MWCF+2pxpPYP4Tla35/sL+Nyez1PfQKrTAllB3csRD0d11r5CtLb2qx2tKrqu84lDvmCyJ126lS5Abaluqb9oh98TjtkBnr66KA+5z/EqBN+xQzaxIyueTX6xLgfEepK4XbnrF0NKTAGI2uOwygef1+N2TJtXLavElslaiELVsQSmrQ9OL4RcpoQlVc5opByM+rEpckZDIH64G7FIimOgsT8hjj2SNrcsbu58IMjY092z0DzbIoinXVMqfLGY8fR2BQo3sK97I9HjuSdB7bGWQLOLLLuR6F8/aBpG92K0OP8rk4AXxBtBsSv0q7jid1biSTJ6Es6U7UjFzyCyO3j1g5XEDYUzN/hYguE7O0ob7+xH+zE0xr60Q6qe8hW4kKJ1+kr5aJ4jNEUxPmsjaOGShAn1x0RtPOAQp5I6PcyJ9tHyCRShLbHrkYTPpAhtLPNM1p0++13d+bkVrBoJVP+t//8GYfQDY8hSUb8y08Y772L3QMZ/IZwVQyh5djgtWaPRvKt/1xtdtA5gTrRv/ROp9XkLwKWRS29SpXYTMISkLAKX/hpTBP66qWS0poP0i4+BtdBNynuYx8eHXIVA4KbdljE3epfAqSjsdAvT7+4gwd6Di9wPw+q7LeByxX2DVM2ixN5DYFl229DznhwOwOjAl8ang0d6Lt3efUxjoa+em97KEiav8jKiZPxNXMXBU2SROGQ+qrSCZ1PdAnkS07QWFuVPGnNCd6+Ut0JpuGgZnsDDLmjPlspXDBwV6ZGjym1y8CC72L2R4i3ReSxtRH6CW0Qs4m3Y0ncLgSrMpX4Ye7L8fyE46r4BxhhHgc/cfRMt9uycFWObK8zWgKBjgUnJQqhKMfvudw2/qqOadwsnH1xFXgT2KqjhmzAAeKewjWsVBP3/2ski99PyL5X4d6biHtGjioaAXo4HKF3Wez9N08U6TiKRneJPeHswO3OYnvORLtAV5wRvLkHyRYN1odOoMfMJufIU0md3BuNQR4o6ndBz812nXdf+kGr60qnNSbaLR7ryUkPu0JvrVVCEVHccTeTM9nnRkh7DXNNJFG6ivj9O4Z/5wCiOFDLk/gwfSaXiSJHFz6R59jW1bWsnO0Ari1MoDGaof611B49QFk3jdkbPI+lMEkxspV8/DYllzKjQyh07KapqwDasuwiZBRjsnvjOoWtdVykrLi4w37CJzXEysHH62nVgrIU72WfyQ4efutfZubYVCizZuVZyr/sebs+W/fU59RV0EvINS+pW1PYyKu9WLBaXg142h7XciXH+1QPXwChkHfqWoe7wlA0XbTCSQ0zsvgKSertX9wlxnYW9vfk7j9ChxgvnVx2AWp06xoYwt5tW390M3rv5928p629UEYMK5YTcReuGqe1mcHyBz7q58RlLFl4n7Yv3tosX9yzqY/VeSmE+uQ10iKx0Ka9VRYUbDavlJwX12n6z+21uyM+9rIVIUXn2igb8GXmgVrv7g9bcNoT3+MT95W2EtWmbUch0gwU3wMlGiNJTw7wEknR78/x566lFz9u9zUebTkc9UR90EYPb3WjwCFFVaDRNx8xSC9F0T50nTnyrm0mFOLL/m5cxQSPtDXlBM15bJ5AnW1gtJXq75Wc3PYgtI19nqwWnLU/PlHjcjR1E5l8cvvgsemM5SzseSdDDNPxu609lTyjE5+nNHiUE+UvcakLnP6Elc8OcCUll3aC96vXp00x39jLEx7dgi+wMrVHidpTFyc2gT7iKq3iFHHQbG2aP4rF6DiWSUT+cbhnMqjjFJlq6EnpC2wFM2azwT9R3A3hciCBd5QR0zNsuSqFkdQzjYF5zj75A+ehfYgnq3MpnfgKrJxJYUcLdjbhvX0M0LReTtHjKqMPTfkz/SkLWiLkPZN/UMXYzfeXjtEe3A0ivKMn99aXm6n5lakLw8erj9ADrIkqfzx+xEc1cqZsL8x/TPvuMhVaBoufxLTSkko0mkBy4cf0vUbEBBl9tR4WhtF4TwQ5QJd3wHP9KguuZRDaz4iDbR9GkJeF5HH5a9hko4ZEBkqi8oPsyQqz0WyF1hFwpq8jvr7Gi9mSdC9zr8cFsPusBq8OgfqXHbQP52C8L+dShbOQdSoDo6L4GGFtzUaqdDNlzXhgitMlu3gHOe86dGjutcS8GR5Yk7D7aNrakGz8jSzLdFNb4c0y+QQ4h8FgQkebhN4Fp6s8bu/cVlTndzwlKwK2HAAHpxLkKHPuhRLLZezyVBPUF7Z7KLYQRJg/QRk7io1UsPEb8QQpLNS4+mILRNf1WL2Uxdaz/HHYait1UdXUGMYGmhFVu2QD1+8MvQJu17RPiMvfY5xeSHDOJh9FS83+j6Kr9JS0lZEraMdSEhy9k2Q+6bKuFDu6DYTw0C2JCY2g/1Z+dnNpKZQZ+nOP7ovHaPF+of5y43TcIzKm6c6wotgv5Y5KB3Ik7Rw4YW1Fd2IAvkrgyhxm/0Wzth+xxI+NQbHJOQmOqwVHqbLuGZvtudcW755ApmVntDhWlvUF3TYNwQR5aDdrd70iKNfIK925Rta9vGb4mHnooHEYztbrnqNgfjFd72e+xZsvo3AnOx+We62BsJRFaWM0qOcxrltdyAeC0fW1hO9He9zxux0FnGfi+1EZLph4yiNQY+Dy8q0tj5rFBXBDMdPJLQi6B0gfMPVuioaujngIS0T5YKaD/wuBDtHlJD9fbt3/uSkuhIc0ew8RGMQ2lU7jktSHdDfvDfI/WTfwJKKVOC38KmIJMOp/Ezo3W4eaaVzkZBT0rWosfws++dKLZqf8/79OnrIc/kKL0y/xOgdHia4QOCxT2nHct+BzRLdHTclCR5IUycSJgDHiNcdsRWtInsfQpq7pLf7kTH2lkm5saCzinRAwDUKeQWT7YdLMGEe3WN0Ir2K0qoCfag2g0yR8Hcn3t7I3GYRu9YfJ1iifGMPhhPgfVrmwBK/psGlglys4Sm2dEMEchAKPf8Adub5BBgUtXYkZ182TKY8YHd4D7N04wA+tEX9RWKrmo7kkeCvY6Snol//tMwgS2+gtexQFWLUttP1QkgbWPUAgs4yvin8nFHxncqHuZEOK9mPXsFmegM3CmUw68OXgmElXJgRBYMXK0NbUrN28Zp7XgG1qv5wHG5nf20ItJssFZRzXyc3rbH/d9MwiUAKYnrNIZugSVei/1tAizejiTsdWTTYFyMxEsFjXq73EswuNxhL1giP/ZtMe+EO0UZc6j14RdPDE+s5G4q5KsIDjAFgPvlqFY8QkS4kgGoakNMfX+Z6/bFcu3YPDmF37LDEOmad0EYSyLduxpzqd1xbFshBtUaUTe4LtTcAw72ca12P61u415YWVGVUfJ6vU6JpkNHX9nhp8Ovuok4xidRz0PqRDzB0S60iHuBB9mV/TGaaq37PVNyns1CFnmfp6Yyq4xp/KCkD3MqARbmoO7cCX0V58nitk+agXPiMlAhQ/R5Ji3DSDL7P+ijiT50nY+TGn2PF453npFINFPmlALHtL7e05Sje/0y1CjRmFjSDxTvVAl/4wiMGgGnIl3lgSNmvJ+zGdFXhUrff0z9CAag96feRDGTsGblvIwk9oPIOh7hmlCXtGeAkn0gAGKhzvVgAAHsBev17xr92tvQbCqIuHXAkKvaQXZniw0s9iDbBOJhOm1KknDrrFtvLt8fmqXiGY0It9Fc7lZ/96POqMtyOi0cKGw8iuOtclkzO3c6oZAo1a7NMULnjStX3WTr3VUkYojZmhG3d7v5fxmz5fmARR+uglVWflHjzvAiqM2h30T45Jp0siimYCOTwTkbyx8CJadjFO2OvxXCV8F3rGEtC7R42+Zh6bTkKv8yqsUR87PEo+dZljQOYaNippUJtuPswFIFBw/U4+ZV2nmpa96s9OPe5FkROAUfv+qWoChoZYqQFSEa0sRCMjjf13OKm9gLeEWGn/rm7Uzq+aYklOc1wDyqYy+5CSuujiUtNq9MGNmJ162mpv4630h0c9ZnK2pPELAtphYdF7+XVUP4V7xge5zl530wlX70s+xc6OIzpmAjJkwl6sQEVsAJ760Ifu+aA3NoNEgf9a+JWI+Fscs/GyEFg3YLBZC4HIQZbGgu+WBS7NR0vH0eTLAbFpEeXHMPKQ7WioMAg5BMT5vutGB7m/bwYMHZ7SykH/2xpt1PfXQFBiI764VS2/IAKuXRaGahja6EAYdZeGyM3LkyHHXjz7BDjW6lzAn3eqN8sH3JYVNhO5OG3jgAqxyIjdu6KB22xfilMqZTi960VcLLeTIuihF5noqtiWVzrQGBWTOCIXaEca5tCiVfN6c6ow9JSlprnOj2D6G7IJk0vmb07w+pvhGvm06Bj8nxGiT3XzJFwG1T4rclnL3utze2iUv7zu3V6J8ziS2bTBHLwBqKMberbndlisrEGjExrrYsgIlGlRVTXv0X2bwNDGItxSsXPR2rwJnnd/AHfVUR8Tfpkstv3gqTqWEFcii71TmantcCIfwtcbJn3iiUP5Q5OulYFVsh6fJzkor/Mwtoprz4PWgmv24JhP27Gd3n/acMCNkV+poSgaQT9sb2AWTl38J9aLLpMdjxvlEgPhIGigQWVw8nZkKxD2UeXed2usSZPH9+avCWeNKByY3dkP/c7SMqHM0q9tSpv4jck25LXlKD3vDHDxKOvnqebp0SMw97s9whoH0GiHAhocb43LkKM+2VwOaP7K6jh2+3LRuS5YHib6OWWKGJFg9kDLEDBvvx2fiIaWhzvvHRasSF2/pmIYnscrzHDgB8glN44pi6ikF5VrfG5DcnbCgCu27o8BJUb70Lqm1TrDrSAWzKODLTlfj5BaMolZ0PmoqMjT9tTs5g1igw8iI8pDXLoyolH4fGJfSuyJwWFHH0uLVgn2CdPsEtGckn0G7vJTHNddg0Hiw7GI5FowBcBpnuO3PcqbVakoGJKo0omgYrdZOEjCbNewc4AM4FuRftREfp8Iyf4xKpEG6JxjpqgST3Vumjkf8sxou7LjfaCmqiB0Wk3VPasuT7PIB+6BC6azfJVcxBey3KoZpk9HW6v7r5j+LDY6Lt3BKGq0I7915OkAG6p5KZqoD6b+Fhq8VchO9K/Z8IAriOgdHOOclur4I3+Pj3F+Snj+HAjFM5/cMP+HetNg1eIBM/dAOf/+4D5TW6s2zzE1AVOe51m+0v8pSgsdRNc4h2ZYn7q5Tj35n2bI7PGJnB1AwbIFRGGbBdyn989bywc88hkGBo5hzg+l4WjNn9WrYx+b87W+AnOgQ+UURTaWbbqVkBVpi74ZPnRVumRYtQZ1l43ZbU1ZZiCG45mm+ytE81MOep9ByKXmY6W5+zOejXvruBShih79xf5V7XwyY/StEoc6x76Fl4WMmfsDCfsxwDH3THZHNMDblRNbuP+mM8up73BJBji79LM3hU0Sj4qTSWkZeEZqaUHvmAX516ShNmBiBGLNyRNBsXWPFNR4qxsdKjqyu5+Xf28vAbW7bRnER7mj8ljiJ15Z9JrcsV1JL1GrQS3nbrONCQooN4YTfYtFdFpDuzbT3zJDt1PnhQbcqBpq2T6/d8wNqWphGYQ9qdlYoeM7hEDG4IqGjQDFkWoNJYUo0GP46ivigMmra5ZvuVN4+PIka7YdXCsCi0PB3swqrVyZil+RfXS63qLirEHv4JDeyQD0Jf14z4qyl8shnGHG45OpU2QBzzS6UhRX3TaqDD1dMDobnb/InuE68FXrAGXdAbtbNZuPayOv19gmT0vUwK3tTsv74vjAPfPTmdlKD7Q4xuE5URHkh3vRljK4+BzvH82vvzJUY798IvfO9vIR9PyBOBCroFzqyzmDIIKZz+RJTWKZV7gBcRlgS4/ZQ9MnA5Va0vnx87vuq464U1o4PS7sJ64JS04kgRjG1RqCv/Q+MIqCssKbKU2AveR9Yd35hVCZfY3VlPe5cgNRwA8WMeMhYiAfWhKXTeePyFD6EiooeG9LC2mO4b3IymGOu5DO0Vw4NhCyXgcxx669gNTQwD3h+NCuKPo4eG7sYT3PCufGkhmjMe0NRfMtfMpiEeKBK0VhR7XVO49MWGy3Bom+bFrG5E7bgwAP1JZf5lC8Srl6zPpZbzmYVBSAT69/GqtblnIg4N3ons0iIoJ8w8sglYZp2s8fFCP5lFUzlfcbStuKaqZax+cPLR1F/efGZMuOnM6Rp4EX2VlIzGbvI9YpgiJYoKkimekMt2BgawVwwgdGHr+HXMzooyclwRvcymPX9b4PN+CxYEtVd+YVwmfb/GJ9Xq7fsuS/ua5ZL2hLpQMfymLBLuJe2cFLWukij3UaFpg7RAWVpqZIggYSYUOEG7LbQnfH9+zljISp7/8uNWV3FjR7V7uCWTdXRGs7v9NlVgV1ZYPZCffBF4z5VC0RG0voEpcQRA1Vi03N3qEdUj/2p2YJQy2jHDG4b0AEJzxsruLdNSJDBTFmRE07qiS1L4P8exqopMcEGdkDnzLAF5c6mUo/XpFw6o3AUfwT5FaaWSSKLkle26OSCaDX04rEPjVMV8Pwf7q7JGi6L+jhgf20TUFWu33YEahBOlqzWnWQBPVfT0ExATRfhEZNteOKMD9QCIQkaTzQSn308aKbpW9Y4jOd9hhQBFBtqM8AzwyTleMxD1RdIPPrqBk3GR+PJzPs4EO1HsLFvy1fL6YmkeAYLwvZgMyMOUM+d4LNdHtmkunf4vinyGSi+1FsVH9PA8JcpXNiIXPcUmU5u+Mt28dAa73tAB4ACOkhjHPSIMzFlcn5wGrlw44uDBFfW85xrpdXOfOVh2sl373E6PoxYq+NJhPCH+tsDcWDTN3XA/xysB7NxdfyRip402NpviGS1MOjAZS5XqZTRhrLR0meGrqAG6nDjSHAuDMbRuMIYqW75ebiR8kSiMegoOvBchi1utGRaK7DZDqO21oOZixlMyqTS0Y3u5HcfBKpIghuZt6rUueHbeQ3X51JOpY62Eu/nzuAyGNO+uggIiTI8/jC5Sktb0G25tAsc8cMiwxC2DUqszYJ889lbsxO5GengP57aqrTb7DNjB/fzKUQ1eb/xD3UGiC+to01+O50VYPeDfdU4zjmMOGXINGlYdflgmSOsxcBXoUxwUtUQEy5CY6NS1BRviMsuSTC0zzcihu6ytzyD1yEoGu6XNkOH5Yq4ALKAF6915QZLXCgE22C21uxJKHY0YtzTUTxZZxkFptlp+WLUxJVeTD+zARglEkfM12R9BHz1uiSaWgFxKEfw4gAe6dxVqGk3mRqBgahej5dEj4EhWzah+KXRTDS0Y8urCSjeFVakyDR2pXA8wvd/6rjX5LTjAeOXzThnuKdErEU7M4lSDOhQqKNpi9sEnhU8ARcRW4fH5MBevjisq6yDM1BvV7T0CHl9T4FckLKCgJ8jTC2qQwrOzAxT/32vrjqmSGkwOws6wBhUrARUQMBMIHxN+uzSNw0j61Mc+6LV6swEP0w7frqhQYsWz+1eroxca+5IIGY4KxyKgfteRwksFNLhEWbgSHHG1BXp+HeWY0uilBaxvPF00tyWI7GnmCgYX4mTr6OZIXLRQrNhR1a0hxJKd9k/YPYrHJQQAwJ8UPj3J9be/iVEEAJrat0v7lztJVlkpn/mXMhROAvZz5D8s6a5gBsOUavBnG5OcY6KBgK4alQ0ezqZRKPjo8nxQ1Ysaoe/WbvgUiEOBSLigw+GxLQ45JFsOAXz2ebUQnMjrCfrwvWzEGWqTZg6FEorBg5KPArkFnwIJ2kXMlLz8Aw8+2aXcSahMK430BrMn8rTeQlRc/Qj7v2ME07nhOKxCS6ffdy9gzadYwBe1lgT4AHMeuyydVV7HKKMRf6ZGzETwJ8epB5/KX1UqDr4AU276UUqnZMfPSpyKbSSvJ2opz47UA8ncyROrUhO9SXA7VbhlWKO70DJNcOmzjQH7NywYh18xgFvBiTwp0OMdhMf1z43h+SMIx3U0RZUlUtAumPIrAx4zP91ilnjxoDfnyjGM5FH4Nmoailz/09lcff/dJnbI+MQqOVNBfVa6LKUtht4HF7HYPcnj21FB7gx571Lc37zegOj16BicVJkRlpEZiR7h3jKv5AClwkyHxQTqHFKheKjTaUil04292W2S8+iHHejhJO+giznbTRCBB/f/XFQPC5MOjpC41Z1f4xmIqKakEiiZ8JOJhYumJKUC95meGtCifYvmFWemhgMvif5kVg/BwWayCC407qL1+rTCtYbRyVd/mwqf2EBpsOK3DI25lpmM2uE/0vIj8OsZ5G7ebN2rycfUdRddC3vmeQSzLj/7VotpiHxn7GbSPfZ88kiseB6DRFGpsdLQYAbk3fE/tgE5pEdprR9gLpFJYFZQKsOUr8q6hpAdnM8QIdA92EdfIRHlJV+21vAPj8MrcQUBHgBbBwCKtjXZAYT2XGUiVFlGzyyYnvqFmadvapumg/bWHhgP3NMhmD+/l+Eqkos4DblvvujeBh+4S98zN8TY4eTVGfAElH8PKFBnUCGxRR6vnqsAKs45umYaOO7xwdLJ2MGSt2cEyHzX1GbfVul56vAXUZdXiOca/3YpWjc0ln95uO54+ktWloWXhE9uZYa7aKD0Y3n3iCrPBMnCOAZ7rlB7W+X5JtyYh/U36uHeiaKFT0aJHnjwsAVxqoYxkSumVMC9QfKFC0Hh28lJjuSLjM6WELFNIrWdVDZy/WfDAL9xDA/AjMEzMtRPAIrYuLVTy5NxQH7ehLqSUFGLl7WMKVaugrmkRA2uSRNVoblMPRoVA+7xqYlZoJ+hb+ln++zfXurVnhB6vCFVOMTmmN+Cs32Uhbc11mxm840gRGWG9P709/9Il9uilOWlQomTeEzEYzwiUfouyQFqyfT6/2SZb7TdJvW5kllx+xBa0ieB5pjDuneUOXDqBZe87fPUdlfWsBlPStQUhDcITe/O6au6tWeq0VR22L+rra5vJPQGhtwjB3sIj8CJEE/F0oQCBw+x+g18umHo/DExYeZK9PD9PUPD3prC+vF69n/rpIek8b6p/wbTa0kN1thCRISl8kKO/Z2PHBmYY/cws2yzb2rJg263WAhWTX2GznIIVDseyeejgKoBDVsh8KIOVP0ufcBLM6SNxl9gqMMeOQKHH7HvPa/xjgvjRvjcBs2lhneC0LDQl0kkJTPvaNJrm9WYNxHpcePIrZLmfNgUu/uUhovBHg6/aaRIkw+fhW0Jno5iY6XbnQ/DQkytadJfaXryiGKUpx1G7eBZuLAREgRYlorG+C2l3MDCd0znzwqOYLFiF3yOeb72QBTOMCzl82dzz3tfKyXSqCqqqyzHgXZ+4n4eXLs/kpXBxQu2mbWBvLOfaSCooL8TNmNbITupFt9EbohZrBU99ZwZ1v9TGIyWB5FFZpGAaeD7lY1f9OVrIpg2+1t3+Ld9qxOjLdCqe+P38Pbn8sOHSjtMWOIfw4shBXxHad8/2GMDhMvdhA5Y1kHsw39ZJEYwRYxnuGZM/WtHtspP0Mn2Cboeqfqc+9x4NccpwcEWo0Fhj+1S3KndYNjMVzFm9jCAsIKceCAbWm+PcVDIbXOhBA9qLlhWkXOmTpwWELP2vwt5W2qKkIOzS6pvUFwzmjYO/aLjPrYR+ceRQI1yqd8y9Mdm2emytnZbk29itsFzioQS5sUwKU/agJX3JAi7qXuamUXDhWQDPtcHaZy8q7VZFI/Z+EhdQTqxcQxRnP/acjn+Mvhe3DgGUc6zC//kr5+vDKlO75NllM5/AyxUKzLwpiyJT5zvMe8Euwsh/ucRQg9l8uJ9MXvZdHvbt0rU5XsDn8aE13xS28HVbWAaDwT7q4j6QXgg8W/sqGGTBkQoUoijgReaVGSYIF3Pp59l84U/5Wp2916rD6JwFIXmRpTjeSqQ233IModqSR4SvG+Sm189OYW+eTo7W8ZpvPdPrrzAZxP0XFKlz67BG/dqUZdRRPY84iuFiJjDHNuKWQ17cHXXZOs7lDAgonOHvb3DN48UjLSbKOASbhcsvyLqJ3SaLsINm68vQ018VUrawo6qqLW//birOTEyG6D15YZ/FK2bsa65Eei42F2pZJy3Xh6yQtgUJNoTTh6O+e48qvmAhptothpHHTRITS/Zm6XqJgbfZR13lhBUAMoMwXM4E3A7WHa+EkN4diRA5UvG7/BMBN3q6YomzKub+tK3XzWpFq5VRfnPK1avCQXHKWFOJzWhb4XD5ZF3WEfDaXGBVSiT5lcBO2ILuqMN9ZJQBQwNXbmjJTkN1VA20h0C7BrddEqrcF/Zqc/ERPe/zgn8XqkTXHpc/OA2xRU2Cl83zFPPoWey8szYC/kZWM4ro/P2S9siHSIV9onEcDv9UxHhbB5ih94c3WBSmQ8jicxbVoKt0g2x7y/G6SwNmWy7Qvem8tbzfj3dh7dRLPZVgTHlKGW54hIM94wLwvhlf9Lyx2Ufz/4egKrHBaPauBfI9JgKEYs0lRkx1yo24kydVHIy08V2qf+iqFaYSxbd8kLO6mB2rwh5EyLEhyw9IxmIVJ5OJkx61DkW9ty2eyT3Dl53J2hWN+w4z2Az2WZmErAThEnNbTc4pBFPvvEv1d+0ZGBDny8KRsGvaFs/wcBgJt/AzzmsF7Y/EVx6DOA00hCJV2OJ651GpIpJzF945pQNHoTefbYp8URzP9rVNRcnVEiWj82rKHnhfvH73BR6m2xLh0758sFN4VuLKAT5cgj7IXHs8+Um6uNYMyd6ROzThJGB5j2lJrW+5J/px7RR3eIVJPj1NYKwfFm/4wR2U1gpofdge1SKA3NELrIQm8G5q71Il6OHKh/6nmEzt7jFWD+Kt2XlPFh9BRyiOeO/aXG+Mc+oEapD5hnXz3kT6AUhihPub6Mzcr+QkLoCpuU8zhMJfQxRbL8gyEWF339B+QU2LnfDxjiWrMjkp4n9m7eO8LujrXmEWkYfcgmv7Hok63fx7xYVnFOk2d+fZQtftfgo3cADy/kSYLpnMaN+db5MO6kxeq76a1fqF7zgLBS6O1MJQgBTqZcw271X7QenXwi/GaxggI2IBO2H7KEUjc8sZ47TD9NCspcdX408PZDQUs9yPaVZ287tUybaXq+mPjyE9gqkX231Izdy5UFzUoQ+EHOJoYzP9v7gUTfB7oDXIj4RILlTFom+Gi7Ds2EgvwheyH/CrjgJAtibifFcHPooHaWdfgBLuUIkU6vDwNFfHyTxm5weBnCks47OKeK8gM4kmtAoNsMbZckviGASciOzWrh5cHxeyjZ4mO6eGURp1ceTjHLnyQ7Iiam2sSujotbDJAwEEIVFP4cW3cR2Z7gI5arASCmPEPvcaltu1OmMBFjHeFO3IacqzGo5hi7MMkZ7H2J9ItOZbew/UIW8Lz0pLfVd8bwf9CCZH04JsZBpghC6xcEePnArgdAnnlF0uku4/H4FOHp+W+sAnCADGCCRasVlYwBKPnUeTyQupC3wCOSpqoqqt6MAtdELemO6dVdOOmeLVb1nr7rAGDThim6DmCb9yz4e5I9XCO0wLUaR1eIFokP88G4ItQBBr5XQZYzMS/1lGqbP5THtWdCpFBdPMbySjjmABGvKhpfEYBkmRwY9D3FWZ+hQFc6BKiviSnx9QILN7GSpgEqItJUr+cfku+/dexxgn099aUlv630f5rZyEQKjR0QByJSzc/qmQtbV56VKfFJyDIG6Fwae0qkpL+xfCwQ95W2nQhG8an1f5u1oQyZyorTbee8GYsO7k+8+oRtdonhyWz2dPLjOvLIDY7eNBuYGgjWvA/huPgJ2y+SrhmHHB2Qp+zgiD6iYyssu4SHw8Pqdu3pqrVC2C+vxnx4jaNnBxENPAVpNfYT8m+qTCAHj731n1P9I+nySd9F2vbw8UeLtZtTemyZM5SuELGApShvumRILEEs6/BLM2Ys0AGiqKUMHBtHqp88B3LKmAX/jaItySMWFZdLt9aD6W1apcrYWGq74Qvc3xzMf9l5HElYZsBT7NbjirinAF530QU9sbUaaHrvBbaEEEUgOvzzBYbWnGsQbe3sWia8ST0fJeBYRSK4h0Oi+VVyEVCYobKw4m5s1mzQmDnfHaXzLpv5llb4lJuJZj6tcfA4/N3U0tq+DKg89gCGzYbhIA8CW4aT3WVpq3TP3J2l7xDG4XhUVwyfXPdUfPyWPyUS9YzBrBhnqdeGIcUup8Uz4fkb5m4+XWDocU3707aI9prklqP7tFaghIHhNcR/SPUukaCrEXwPLYyYAA1JSv90gSwqyGID4dOOOkX9+qvpWefvbK5SbVQDuGNGY03zhKYNC42VT8pyHt7xYVRaWx+JimI9wlKl/bo4HD26enIokGeHcqA0Matc1y5PmiIBSVziwusFcGPewbDE64DKdze2UHEYHCn/KOsZ5a2BrE9JD9ZS0lf/Nj15B9qEv/j6z52nQ/UVvL4JVXpjVfFcbgDRzwNQIPwhle9nj+93JPAdbFs3Uvhlf06agSf+dxDcD7uRYVqHlbPO5yBp5y16rgc35mAQuTVdUungZxOzjChrgz7pUxuCB2r8CwbD5Jn1jwo/UGIGos0kMn/IgS6t4oRRjfqt8xRS5m36DHZsUh62VGb5WOBHk5T2uDyEndzyPvNekUIligpVbbbhzsprc/EjMvImk9qQnPfjyU3lnbLDaf6oqMho+IBUoaC9v2MWzTgzoV6cb0QVLJiig/7Hn7t5IfJ/K2YYl1Gn1/RnTHU6iRcS+EPfUhWrxWTgflN2QQh9bp4v9HTdAuw00G1lHPj/EG+jn9TIPCNaMi1bQwEh92ZezgMfTLZFJQP6Sa0tLO/mtJ3hIE9zoXMSSAAHoEKDErkYfiu2HEp9POZ1FFdlaJYWLAo4DVsuJU6xXuyboceL4vq7d6HlG9qr3+g02Ai9mhvLcNKkTwEcpv/2ET1pjSxxKQPihyFH7sHO3PDwT/d7c4D4ekAoQSin7Z11WLwKJQCTbuXDZzL0kw/1ZQMgifJ2EbSIjwUe4WlLfRI31PiOeyfjeuT9j0q3jPW5kLKlKSSBJMsSLEBKtRrbbEMPcM7OKC52QnBCumbl/cZf/UKcs5Ba76LQmJDZblRkggS8fvTyLDjfxfTAyC9agAXLRMu+QX2qRkPF6f4p6aw7qCDL2v6LE8p5Tmv223QgHECKxKCSmj8wFSjeI1UwvrYzwcHYjRkesUFvWtX0jLJ/4hvgVfPSkCEiF7vI5H9aZQRppv0F+w9CtKBZ5SDggIw3Zz7Mj/6C78AAabl5W9i9hMffGNbl3mgwsY31dwP5hkVjoaK+E6uxmmto4SKypyMDS5E26/MHhp1kXmmk0M4QTlws2nXJHglFnQLEYW/oqReXs3A2FS95/BRgBjzp0bLxoY5KDgf2F9kYr8bDfvU9pAOxr5GCw4Keei464GsVdkfOk2gHVO1y4qkQ1dh2PnTPdB1L3cjG/sGRpvKQT4bNGaCNYA8cnwkb+C4oPBMDI2h3ZMApBOz5un9AKL6Pd2JBC7Uaf02C2VCIpEuuLgM1tifC7utLbybeKFbs5GRkh0aUG+sUwXAhdoc0+4e2vLy2eP4nfDaZmFg8BgBBwv0Y6shzjVUlK9FtL2FV8wujsjvmRUTKmN0WhCBspsNjmBCcrxfT6Xx2HU8OWkRa6d/Fo28TMkw0No4gcCa6N3tifBs1zb28pRRC3ENr+Sf0g9oX2rM+rX1bC7CpbZpiVEu9PgPzm4vKsbu3F7WoZYH5DY/flrA8AHLtTqdZOnIG+g5yvUZPPSckkVcJWozOrrALHBu7+TE+TIEpcK2wdZ+ZK68XdUAaERt31JN0suoAsh8gq3HcpyODRcu3zKfg9f8Xv+2IBuRPHc47w3zQzfmjS1eBmdWo9suDVEiToN+9XhknA9Q1eSqDYQsQ9wXUESU4iZ1axnATu2kPNhrf9I2hhHouNo+cQORM3iMQgDnHQxtCFTPxfhr095HrX09MLmDpr5J4pZ9xJoasggR9OIkLVfUOz3CwW0rbzoFpI9egNp/Fs0N6H6BRs8VAaZj2Ux4nj3r74yKZ3gkA0rQ6FSyC7ARpEjBQf7jGJAMObpeH1SjUpBdJsW365UA6WEkQ5Aroj9WJ96RyXRtZ4O14TWmXndg+dzljIaJSH/Q7UeKCsBGpjuVHwk2+104F7PSOgMeWv1ELJBitng5F+q8C9KtLNWOkthL+HX0nE6NRjeEHD60QYxT/dvVOD/zzDLTwveuJLM/czMb8KNwCkOxDZOIlPF2mw4Ns4IeQZc6o2NKJf2hnBCOejEKVRNu/sEiUm227D/MyPQc55JYLXVx+Ru8MO0QOt182qlQe2j69U+lkS9NxHgGNVkAPY812pdXZbV2bIlStnhrXdttgIPv/eRh9z+sgEPF0lxLmb+P+IvYdimz8FKkLJ7/1K9Pid7JBTQ+nZg70JynWvpAXAZzTr3l5CuLnVuW0fEQ7YBDSTrADXD3qcee03aHmcYsyUyjFj7uE5fjWxyGTGQYbuiGNlCuvQh7zzAZDkwqAwFjDNq+Ymfc1pED08FhDWujYc8MIr5VpdGCHXBvOMP7eG7IzGc3Rg3DMq5egJwjJmOSNo+9MYLjTGjN7uo33ZWXdlWqUXy2YU6bE8Mj2WB4KQ+AH9h1C5pk66eZ4bUckbvhCduUAEvgHCAhRRiIpDJLyYVALajeKIvHzIYvGojsdAiKgB0ZzIZzhMATkh3qYvQ2LBITmOeCqScaCElJBth/hY8wI4eyBvkZziJoeDiHd7Gt2AwTVeUImyOvxS4lcbRBvq3w6xbjr3qge0zzBuyCE9D3mOr8J7qCDhz5ikAnBnumxF6hmwvHLQEPPpEIXD0MzFEb6md0hR65E9C7za9sMcCVmqC44apHE5IIH0R0krF7jRZK4hxVJ70rY6x2hU/6bnTS/bkRItjn3Y4Dekr38YDvFuDP5tIWUpijUmBaNVTdpGVeCOizoyYaPU8zvwSIvT7NZMfZfktl4JbvpZGFmvsvuut7ir94Ak+wBXy+lavn1sPQ7JDhzPcQPXvTSKFZC3iDGBWW3/CDepgNhUQ3kQhRFBZf8skxnINvVhfu7pvOkbkPQg4+cmd16sdUsEn0bE3ZJuoJXpO/ulGJfTAg++5okGm+6LAofVPiJB0L0+J3uZcq856RJqWsmztTUSG/l74XoI2rThaVrCaou6dhw4hlIs+V5QkNxOuBN0EEQeUBno8Rdxdx0XAZV6HFqwL+nXk+d51v2clZFl2MeoaqnZ1t3ZPdW4OTOE62ca22hzAXYecr99VYevnic44P4dc5znh0+L6AiblaBPT1lvoPkSBaKLZlFk2GAXCHpoGWphMAIIyv5Gi1rMHGiIplvnD0pAEDlOin1oJy5QUA7/6tdk0Wn2S+TgrvjYEGD6LPJGCI8Yo7yb8AxBj8qT5dc1jvtKKhTpaR30zfzmi8JX26mkn/MgVucoXkZe0KFfpCnlj30DBU70VXlJQ5CgxMNp5HJ7k0kaWXWZ1s4mOZX68imsM0G6yIJPHDV5F88tU2r2VRewyU2BI2QrLsZQDmFucJIr+ik6BHZaTutabIYvBz1jQm5Wc7nq12CYC114kVTpBNdvu0CNogBVagdBimCQ/CXWTzyOpIVR0tokObqHh8Bxe7HJYfXGpGKMF+hkT6HR61NKnciwpn55e9tgrFcUlYVUW0M8f9P9/VDcWqgl6VvMibURgp0EFlRE8hMxEidRQpmG8POQjee9LFtcjqwLEzCrYcJN2LrSeiCk2dCcB6nRpplLCDK9D+YCXS17oZ3jDLFRgB74Ag+r+/C5AYRDQd41MUnzNYrYU6AsgkVSKBFv1zDnFki6tUwCLQuOFAEIZWEruGiPY1l1gFkfgQ+ju9q1m2/l2ARJ+h02M4USXj1GhBn4Ka0L8HONAkdEzMwiLFyUHNp9NVFIFfXKM8CzNOEFmT8HCNzTbRpFzkN+om4rdD5Y2BYRPDU5DlVfwqf67XHHTOFEYc9TYFejrW19jJ3kRe0wHShneYZKFg/iVBc9IuBP0QB9dpIxNwPgeWi0etSv+2EKcfDgMQwpKJ79UMlBv6oeYoDnIwCXq/pp/1Ji9kAAd60ybo1yisdN5+qVN9rIw+Tnxu/GoT71IRber8oNz40yKso06+a82ipZoTcasBD/j5WG+7vzK3vZ44lFL5gDHNGl9vFnL00H6usho4lHBu5HmgoD4ZEBTkwEQjJeF49JiC2ff+ROoQrzIR9KaKAfN4jMTSlVEbxdIsUmku/qEL2iWXJRIvNCUO3WNO9ugcpiFc6FZ5xHM74eLNxBp9cVK8EJe/TDKhW7ki398Y0MVAB+iyrF/A7QSFemiwEnZczEAnmnk/w+2vfOPo5C2/VLtvTQmNsLUgGjFDPGuUYwL/MLHwD/PMg5OCMT+AyOvUCzDPng3MHhRFCcsbeuZU+4l74aQJBgc7B7IuTO6nrNqcPb2kX33rSP/TzoH45I+JUazbixqXr2JFcwbJIPn4HYGyPVWTnlM94HpJxK+hEKGdUX7Pi3fhgaateZGONcCHC5mMzGThXbgVdbMdkg7oFJgYNOJiof6q7ClJIPnvwyjfeKsctPGDoO/ypzhFY4Awdig+tnJIR5SueXi6/4N40iA5cY98Pub3n03aoXuzDssxP1Y1ID3HPieL1pkmzD/i6p+doQdD8aoT9lv2fvzUm/ZZ+kpb0sGZSiGZ6Kfli2yKEfxZG3SV/ocKSnI5r51WzL3OuQ3YMmr83vl5IbeA4uHRYRpG/tdCS+OqF19YebbzWVwc3484fxauY4JleIOBYgIhr6bh29eNh+lT943F0ZgsPU2zX1e11RS17rNt5NQCz6D8xtxHs2gyNtIgRYEJatNMlGIpwVlLH199RvhG+82ehgih+O98u6/Luhsm3XyEVnrqEla9DuhFMi2TZdumEJnRoRd27TI/CvV9SvIDS1O0/RgE+Er8wzZv1dwmOG7plqyWOZFItGzR+hP74wE9mkcse0g1pMKTdsaN14YKuLzWq0U19QgadLT3RUq8vc+B61DUdlMyYdjfV+UmvDTfycdcjKxF1I0JMyEtH6QnXTRj8lpelS0yMlS0y+IpLo06f9YSFj9yhnCm3t0Qyb4p/NXHQeuiJ25Yy9lOAKqG+vT22B2G1DIqv9lTgg1QF0QocsjL2hydnze9EqQeaXjA/Gm2q9raFmkVa+KyvnyUrKFho0GxQlMT3B93z7941GpRT049mBAxUmYbKB4yArzHBWureYncVssaMEMFOkaevnPfww07mA/UGqVTTXEAJapR3p50d8TYPbnILA9NSq2u4UTYMvkL9rrNx6IZzSxp6vqlW2hvuzumCPBC8dEU9Oi0Niydj97pZdZmzt8GamxMLepYk873rhBL3S10K6IWRn+YWc7O4CEQJL6OLMGwa5i3zkupj7QPS+R2VqGR0E7efdqsVkQxZpkhwPvfL1aOYSRmCyZ1fte+5h0HGYHmPCFRtYxhCEkakQOiTEaWZlybASb5tLa8W2MU261aukO4C+I6i5oe9CfeMkMuvKh050Vi26b4OIFptf+Zpr8zWdxK3XT4emOn1ZOwFKeihIL5i6zsg69akgPq7YoDMmAloLJK3UF9lBwxeOX4eZL9eAoQnN+Sk6KFOwgIIho/1ero9EPrgO0DU+UudftSndURY040O/II+CBE/JbP9BXj4lQR44MOFJlBnawYzhFDfTplI150swVazZBsbdgTenYMkuI5gc50vV5LN3wCkg4pMKNghZsxoJa/DyAjPBs/Z9i1bxQzANLFAwQs7kTWt/uYRy1vakHUt9tugESmU5xhFzQogvo0iH4InMuEr5SbDJiFFM3GcUtoAZuwzPEv9vrnRbzFLySyGK9K/Wf68lj7TmB1qZ52l27iDQQaf1LO+rFFa8QyaEZRoHmr4DG4ONYe43NEpqcSuqq5QY5fs57TgcaNs+189s4eg8L2bkCfMAvchnW1sHrQvFrMrY+8m1Ct9y/3cl4pPldve0p4qQ6j6TwH50BRioxjhweWkAjc78FlsYPxJCmX8vNrd67ZA3SI54UTfLlq2rUAbPFnqOvzxRfunYkm6PwymY8JyZwPkk8T4WUNwOgTKFCgXWzQcXk2ppa1BcLV0navibGej9Udi+ZFlANMTlydjYpa4lRAiyUIG3P2FjIuF0Ox1+ympw9l/cXhCk90LVac4gmtyXuWJPzuCt5iNjNXIcQ2iooGlX8mtQlWQ8pGco5IRS5U+6HjIp5oTROPBW5/ZB1qCnvAQJwP+C8sDubiZ/Quy8Gkj4d4d4ZtyOIyqQEMssQ/GqgHjVPokfqEMDBSbSgH2KBd7Q24ommnOJvVUJ+K/SkgiiZ0UG9Y2g+7iSbQSmU4nF1Caq/HHcD78KiKr8f1b1JHyakpohe1dwrqNK2XWuiE/j2VUSm3mjGbokyFQ2Rqq/gwvDlR9vCvjEkF3qwkh0AMu71rRjRkN0vqj1fru5mqYQ6et/WGuZRUVojkdtQCqvzSvDF+q2uhVYq6R/w6RYT1gDjDcHmN252fMTZBnoOkN+ex3bQOSgXskqOzjh/4K64ax/3Ne6okZIXzRIXNtzOxZbF7PDrNoQRiCm+rMR1USQf+Ij6QXODSlURw8a5C3CIMzTdPq+NB8cEuHoUnhhxvFCrWlncG/qwh7V/J3HFWcDDcUqyBIJdxbbTPIJDf90WuSClWaD54q3lbw5Tqh049EhfObzxMw4m8wR0vezcgFfG4oSNhNsFcS2z6WFY0MJkYc4OreCzfGfPmESprcMGEwoqzCeWpPEb/dXjBbca5jd/RP/5MpppUVwWpOoFPaHWVMlJiNN2OgnZBIpaMnBP8a3j61qDXjankRJTneEpcV1HWAfAjBnBXEHUK7b5M+NAisKD8C4Q/j94Sk9SRSyaCWe/P53JOOrUNluplG1AaEz+e+T//mMBc+rZp/Z/yhe7WpI96xr29sbNs/Y4wC85utQCebw5xlRuQqmv74FYFvERx+hfP5JtYsXe7ge8+LwpiZuXLGUW6SsGic9vvBbGIyCRu8+8YJFe7HiQkpCoNBJc1TGwWOwYdCUabXozsiAPC9GyS58MiFkRWfbGJKdw7UV6eXi0Z0C0siCmCA2WKIJhVeGsj1x5iBPuxgo8ZoD7u9CRVqxmZStuM0dqPeqkUrVMufkrgAlXxssglK8F+jk2dlNStZM8s/Lp2blEXgsk1Ya3IHFuYWdjbcng7TE4WhOFgehp5MWu4lZYW6/8+6aCMlHXHKG5TJyhPhTGEpNONM2WyjsibkcKgFgZ8iuhY34BuSbZOFPwx+mr8IUY8jrz2g1DMizgSKroj5lh/vjfTCnpqau8wdrr7qvP7sEJcO9nQjm1eNMgJOH0Tp0NsTDRoDIVHRCCphpv9mFozgk4U18aWpRnZ7d3fujbFMR8gPKob8w3hLEIKEem1ADJc7tpwvnPPUTP7uqPDb9wcsz5VzMLRheiHXbAxPEMAwcWRcZME44b7l1/fD1TI21JpciK8X6m9MHs0o6j/pDHojUvNBY5RT2a7nK5WiGjI7lpDfcy+SStY1WEdSqhEQZ+fYgHwFmw9Uz3fuSA55oLuiBOP5EVMtoOXLeInqZ99o5JBpin7wJzW9E9/Fef8uRSbzgjlcLpUcBWkHF0nT06Pvz/tEmeLolzzNS30sBinQGZMXYOmEr3kLiqaIHGL8cGwXFToLMZrdVgZiLGi50dIaoRF4OG8ybaj7emgCIRJulwA3aaYahsqQGfCX50Rb6FeGA4iuYI5K7kvKiLbNiSQMHf/ST4gXAEnRZzQuTlDn/pDGwUSNFQ2V4xKPiQS+W23syFeY1P+959hn9tN/H+5J47L/SeFHp2Wjqp5a4mV2PRT75t0O9qoOidOm1ZwLJEarw9tifJ/jpeE7MAZe5rfeU420FXdstfoi47xHzQ8DpeDg7QSRtTX6tks267RqWH8Rxz5fjOCjvu3AuYJXRedquBTwdNcEL78E8lQe6XOtJmiedvP/AOKEmUsnIJIm9vtLKlx4jQyKXCErDgdh0f7K5y7YaZjyYEBbbWk/mgunZeUbQr2Ep9BAXOqz7ViFz2rKgC62ZRK6k8cPAaofotTiZs60xThKwjQlcwVux7hgRPtP6RQuyor37BKAdJg+og4DFrgV1vPIgIl1QrT8KBwh4jZZnp2zCi+78/TS3ZTq0z4S4O35alQLIXDOwyIwnrjHY5gTvb4cwlFFEbHr4+8BkLcUBYeJAiW9NP7v86mZs54hZ6XuXQy4kag0ENwcNfQkvBqofenOwn2pzmk4aHS9nCCFJfI9BJf0mT5LyCmELrzy0RMI9m+Z871mGksFM69m+kEj+WzWy/t85D3+knG8ZWrF37LBv6UdGNNDqcHp+L4uTByywLPkGFljpgQsefOLXbOboeXSiRiESqvR1ddM+euzChDItDMxkaU5WVp+6eLeOwk0fDbKJv4a7QnEZEpc5Dc1EF4VUZ6FMnchZ5KxevNJIsy5Z4fmN8zwwmcp3nFvvUmK5+Wmev0fdt5CsM7ryUKEvzY909IlsapHK+4hklFVU/FAwrWqg2B8WKN4bB7yTswOqAsVR6L3jPW5JxKffT2hK24y3as85Ih2ob8RQtdqreC7SfmUvKGkTeKs4OCg9mWae/Y50/LCa8yanCoTvdjPpSrCTwcJcyx8WFonf1Y5lYWhCkcqArS2mGYWKCA0ueZ3DWUpcqYXB7Grwu9sYBsB+LeQSdQLbJ7V3/LO7djVAKQE1wTwjnqoyNHKlycCbRKANf6UAHnc4OgTmuQcmUmzYByp5HwUKLFtGOCsziYROf08PJAkxx0QhagQtdWCg75D4awGQ5OIH/wPEB/HCNJ8/Pc/aej4rKKaTkdaJclrT2CQO5C7RfSGotUwl61sCXy5yR1hUfSK5Fi7zbHo0z3c1d5XSPJFl9NyUZYrIo0jMHPxYJYrlwMHHc8fTQKEBO3CF1bIGmqjjbdC3TcC90vaq19I1BmCh4pfTo3eUFw/KFAuWNvJ/kwN5Y7SWLbrr3HEkje3iKsXOdoMnk+uP0Git9WeXbXGKYZPEj4QVQe62dpsUZzUmGGTiw/EjSZ+sL0UJ3WymZ2ED9m7K/hBKsJ+q7ryJIToTinjREiGUMsoA7d3MpWsopddJE76kgYMsWG35zTGHjk7ZvfaFnJzFRd9HSf8kRyErPn3iTSKfYjyO5jbTnM+d6rnYUH3bnte+9uRC2aXGaoHRJp7TLWfcZeVECNEiBO9ZfZiiwELgzWggNLe3dZrwqcGEqU4/h/u6ibNT0TR2vkb9elPQXt/dyyXhI6drYgfTLBmcuXvo3KnXgL+2oHqXIVLPHWCt/VbCXLZZ3MmZcdEtsS/b9o1A7U+LX2pBNW3ZB18FJuFvAm1QpRZ06XZM7T+c72BpSTVEHeXxpT6Iye6qOVqachgXOxV+IZfjqoMPFrWTRGNCsbyO6IZgIU8oilOtazQIKBGX7HhJKpjtaWF1ARyAepPIZyDnqyZZvsV4/HxE630B0I4yB1cy6NcDzhT07DEUJNBid/kSX3SoGejaOfRhoM3HiZQXM+lNEBQ10llPMoh16AnrxPjEv35PNlwmimm7jPbalFxh7zDlfQGVxo0ar3b4enkXG29QyBReLvA7riM1T6Nmwi69awSc9hvCaIK/KADJbcC3y3d7pUs27m1yU63zC+CSa2pmTMHQovifU6aRcAZQnKb8SYIVDR0CU6orWAnDWQAiHqz1n6t69SRXhzrE5vFJ3yu8+2FpS7m997Jj3Ehwaj5v3Qesx9pHVHDumPNXppq37mbVodGt3JIVHI1M2h/aVdsrJ4UmtzGTbikDG9/pN0z8N+RHRlsdogfxq82WCk9L/ZQPGjTrpc44KACj6uIPI7Wv6XfxMBiAD4H613Kc+zpeHIEUdujqj+sLGOlm1P35supJOzXfbWbgubxf1J8upOxZfVk+oN9Xq2J/lmkZF/rx5BliR5t8xKc3dBXSK3ZE4uP7HT4ZkNyYYZMUx0vl/ud1Q4BK992+k7N1tPhimf8jylGsLLcC8B5C0ukZqPUWoNzr7rZoCy13jVMCtYXCNKzTjTOzv42m5B9VhA+nx68YAiCoUAvN8yVkmIG1SL4Kw644+kBL/iiWsG/0H8XKv/ELHnQ6rDSlBDdhz+T+4tvZqi6sBZ+d5DKHQuPi6YmMeKb5z7rJWZrFp/D0aE9sms9IAAEKh37CccWxHXeiSxzZrhG21eYmiaePo8fBFM68eBlJYdxUmuV6KvITj4bA4OBlBbEqAsoQ2PMpf9fbM4iXMLTRUlT2pHsWeywpM0q+8JBOD6QxCKp+jqi6+4DUOmIlmgfOvrVTyOlMfH7BYpP0O88tjCSU8bD+zvoknZCWc5yiw97Q0rYUW9OYcow5+bCXJQkXnv3fWgZXzOjNtsukXZHmiTNiVGXSFCqPF+aThlUF2lfjYsh8b/78lef16K/3/kTWyJ0KuM8jOj22Un4dycvhW7AtEahfUIPti+QfEgCbf++HrUNxvc/CmqLd8GyYHsLX8kBf7KXvZGxDoI4orm5dYdq0zw4d3yDnAZxI+mcVMBhLaeGkYNGmQliC/8S49Of0qEYEHVbCU0KGtkMEx0GBAQ7JK7X3nQ//g3bkHHvkmYutzwpv5QueN0hjVoPteJtEKstnwYu5NWAs18q+0f8ybJ2rVUrFXbKt6oIVpP8FqfBT0BABiIkK4RtxeqkSqV4wRYFtYbIIJ19/PEYmBLUsW44LRM+cF2GXdwftk2XPDWsxZwNRtt3GrkDNYcVyq7I9tNVfPWAjrduzZwQK3JVikAWjGEFNcoMXWQXiSURZoBTTfqfDRFrxPZIzYYT5Iry2k9XjKf2OTVP29h9yza3IbS2hEUlVi4zzU+gq8dXIOqOzI3tRmp+Jj/HCRh9v2EAAnYdHfwh8CbHKITPl8OaojH98gST/TRNJPBUaI4IQkTdN+JLoJSOhXuTZA4uhLvcU00SeWRZglRVOHEM4qbHVpevnoH2UXvwhIFn0Ylyw9Xt151SNFicCRDwC5zNeUNa2B8z62GGCzBZvLz+mdmTtUhOjyxS4/mRzkuwFgKGH9800LLDxvM70j16k8vXgyIkoUc95yMH45Yqk8Km7I/enCoVTdUT3KHgm9DVP84utf+Qkl3Gxf023kj1/qiG8e/UAl8U/4PpRlivuzjBfqDMWohfFMajAzS0ehPDISGda8G5b84H5o7q+59GsGS71CqKm/eBonGlbQzDCIm/uuCJ4u3mKmzRA9trzZ1PSkn0rw875p8AR1hGexUL8+75lL6Zz9rFwi9u33CBZBNeH42A/k36g2ba9SHVGQLVAp4LKM8Uzb8YevHW4xXVDrMc8S83uHBHNZyGqvrl2WvvBb9nuLx2yqxM8OyoOmkDTkDFZHdiTuEVjLxTr7wah7/brLhg2h0h7C74lNJpoMlxYbwj3Mcoddl0Zev4zqVFAWGUH6u/2nZuFM0moW8eB5ocdl9sjjTSbEuZpLdyqL8LIE/u4d0D2H59vWVrey9seiVIfT9fVxbmfMEeowFmpNuFtvhLW4PEh5wOX4rVYZuFPzwgxZwHlbgey7kDyHfxkYherUdznpGQyO2XMKj4ByiEbwIOFymymp/FbWmx0HdCLmD6AkYhPJdMsz05x7GBwWLl7qtUJoI6n2uvl6vMOjFakjEe4+HyqNMIORNZqXxET4vi1mtOlj2eya1lLWwEQgtcEvkce9iAQFKFe3hdA+JJsaUgq/GY+Q5SAPUQBiIymPgbztdH7qRu69h5mK7sn9meWh7RBHQoAzOIPovpj+DMe4MhwZDYw3lFzlIEg0HyCi6pn1QMZBUll9KEUvvfKjWOSD1/1lnD//Gw9l/zAtiem8Uf8Q1cTAgVJuMlNXbD4VlJ0zBHs38o/lwR0mh95bzp2eBvGGh9Atx692C4hOuizIJytY81qOJYeuaPteptXxEi9ffm+2VFat/pwhc4zuzEuAXVopVzS/piabbKYaA1si7Fgw1yWOQwhUcPuOeGws5wl8ItIihWu9DzeU57cub/geO2AVRwk//g6FwzCrKS+enJERepraFekXjALuqDcvmnYYVMPx0nGRgT2VKl76FPQEXi/JB5C8FlOG6kNz2LfoEN6gCAHn9k6v/DG99OvYhYD6hlFKuLCBC3sG26bVtOEMXkh9u41AbOGvwhYkAgNNbTKDH/spmfvrqEEDIulrr8SlVOUTuETtWFGEOQykp39EDepO8aZ8DGl134bvhrvpG0uqt4SS+dsOYvgOgYoUPScy3tBvmP3hBNtWac9sDWOocjEcNdgVW7Q78qOAQ+WJB/09xtzEeWQH1mP5FHuqLhWqWYVQfunhTzDyAhSCSGEIv7+WLkQ4xOW6yCm778oJ5BydUC10B+nt4/5pMzAZqMwgpHRUmBIfDlHQd3DXwZ/bDRfNQ4Vt4h1eEvwuS2i4pXZNFjrfgnwO43VIZO1LoF3rqdj37ugM2BgV0iJENGj49deiaHiEnfrivB4ntpW/KmNKa3XaAgMmeVH+tiKEOFtK1HTduL43n6iK6NKbjqsHkcdNkw6EFOaEECB4PNykOMDJL35bATVDlDOO1jfxaUdJL6B+j6p0dXW4T2HdcOvzV6+YNOMJlQebMtCTH+yqzqzQnHOhmfPm1+KhdsvY+U+gSqSa0ysVuIl+X/0ZwdTJph4oQAuzA13l72oypOy30mJeY/MsxGEWMd++5XGMIC0SrYonGS9uADiZaCFpxZ0+K35h9IhYij4zNKMrUkilnoG+JNaYBgrxDi/PtH66+FsVzxZu3jld+bKOkAorgNFww4/MAAGLaxMtzLpS/g3Xyt2XvAt23SRyeJkPv7gW5tuUiDLsRnBxwKokzLFoTU6EZdLRnEhmu9hCFA0kvaZx6t1+91MIFIeWDZ//BGDEbkQYq005/jhSy6eyT5RsBkLmY6sydLKVp1t/Si1FALJ752h1foauD7SILjdW8eOY0IbNdzGajPo1OiudkE7Nhl21NgRO13XmJnM4glUZS8W3FwWIhA91cu6QTeP1N52vzLyXOlOpFhTRCrx70hbb9lJW6+BkY7HIjuMSX9AAlrHRvcbZLXiFzf6NRFYdXmmsHh6roKHMp3Iu1CuN/86Cc7xjMsgkr+pfu5YVXquYi/AbysjoPivJg4fJTOxOHbUGImlfWAI+0fl9zCUQA4RB5tfpZgLx9gN1nSV91UfXgnGOigOgggQceh0jZkL+2SyDnWGCyXVBGAY3S/1PvSmhoC6JAw1GyAirUWnPI98IgBJZy9OIO5oehEriuVgW+IMaEPHcKL0ztF1IA6y5lweCj2j8+/y1xIdl0ajTvjSyCzDHZwggO4vg0WZ07nZdLIQx9L3VXWKEur9SVPYVWB8p5+wjCy4G3sravyKSjWrtb5FyYBYYNbsT6rRDWmbXQyFPWhV1ucyMFFh11OdOOL46GJ+IHSXRA8hZTDyTLf+RYA5XZyw66H5Mr5s5r5YMNpcP9DQtrrDl9SwuLJTZLafKOCM5yeGRXfTKiZrNswhbN/gCg6Quxe4eLivGFYOOhgGX9C0DPJeUhMb4FE14Z9BdbbUIgNu+UAEeg3pgv6/kxeoLNdH+WidD9CZl9FJR1T1OUA58yEZRZidpOf8/933cWaZ53MsaPOn5xvmoEzlpwBYEEsvIdpVcChA2yLl3LWHB8fmDf5pO0WgJV4KxoB5m6Gbl+Ay0VKIJ9LIfajH6Yg0ExxSYsj0b5GsG9CXQvL+Cqfl+H6yEmTgvSpPPjxkdTR5fMBe29JLiEDsatyumMMmBCBAxLfSnugAxogWAvrKqr1Qthh8Dz7VyvPlqS54YS1cApTzLtD77u24A7UMg7IDCKf1NG5fewKri++DIMN5W9SqV4HTwNdXH4osG7woKv5WgQj5i8AS6MgjsOCr+0rKBag0KlJedivwAegbh8DtIUCOi3Bl6Ae5y3o449iFgBxNMOXUXET/7jKGNs57D3ruEtlZ604VHB/kWiabGfMDsLYl/APwacak48YpcBC72YbPwzzvaQWbVgTkgDZFkpjbvNpQF9EV5aTYAVTIFbQBxcfnJaImQcwMkt26wzKVadr9be1l8kM9IX5g1Tj/oQ9/zdKFWdequ5k8FRxYttdkQsU14qjBoRo+LXY86S23zPK6ELmj2sArl3CwzORSNvuCj+bSHPJ28r12dQfrBo8Wq5RUJU4LOIf2MbAe94wSnRAmR9xC0AlicKsFz0WribnpkVLgUhjUiRJMBCHc8on9s/QkQGiOiGMxjlgTyn/Ko8bs1qsc85M3nXrgFFEacQk4d2EaDJFpID7fvs0ANaT72XTs3uSX0rYNh/d6240g2+q3JlNU+bR2hIikuMkIQVy7/zM34Vf1lPqFmKLgi2H0PtHSwRIR5rjPSoOPX1yv04A6xNofUbZLmjfTabasABTrHrc9W9X0WGjGJ1DiE1R5xMh70VJXtNEI3SwO8w+WbYWLVE2r+uz+ykPpr3InAzmJqG173ddudIFAQKdXnMsf8G5VBX87QtUDzUxDeFSFsSNM85UYh61Rcla1Jd2S1w31Vgl9zXlblrRXRpZELN0/jiadrabkC5uvBqFxzNpYKhjmbacg2vAAhOGrsQB51gQ1pw4fclqL3fe+tlL2SFJj0JwSA5YTlxLC2tEF9y4n6odkcqld6H+1LFVK9IUMALAey0LnpGDjQwGmrony7+4s8ZvlgzW7tdE75tHBC3iEMP5XYIyEHWx0kPDtnJR6rqFJHXSWDPo/C1Fpg6NWeenBwiZj3NEQL+FU3e42xGdp3EVIhFvR5ylgbcVkyUzuJu0m9fbFcaZXrhGTXL+FTGMX04pkhnDxWs2nErSuQmzoaCcc/2a5AvfmCkGs3lxe8Ng/SxbegpsZ/6OxjlaAlubM5xHl8O4GR3oL3wLsCo0ILL7YIeNsMpvfKBcDpIKZNUbE5GcYbxiw3suaSqlTL5AoBgFA4O4V0XN+cEjZ3HMx+ALEcz9vEnzb9s6LqEruqFM9Cw9Q9GEKp6ooRt0XYAdd842aoJB6RYz3RIGxmRYcYGZIt3PbNHyfsXP6kalyVNqIKoEGnF4CO7dZA1nk39eFtlTBO4WEzKnCLBwSt739ZjvinSae3HrwCj7jP+q8csSy8Cd6ttXdf/YrPPnVKvaqPOv5AEKXLq/mU6iufVXOt7S9EZvzPWSnG5sesA+7b9ujVbgdwe6jYb9CPwfCPLLcTrNfVj3S4WOpr9TkftSdEUqQGMLi1Q0dGNEfp5gd+MW8VF4XFeC43z+kIZqFtcJh+I8Ez8dcvftATcOWuYKsEgqJ5hKI7mru0N+qz4eAgPofcU7GfunaBWfeOl9GX06tI8dfcOrsSOhfcqHl99pZqQDjm0SlmmB9XxyIGHGKE29iXu67c6UdCPr1/G7j0i0qGs/EglSPV6ZvrpsxTzQurLBmuFr9yeCuVxhGyQ6EWoQyIZk1RnukvXHFQAQYADDRsxagBGc4tx0VjMXKgxagKhPVYwn9X61srQuA59FyTxzMdTEgu1cPGeS0uqYbk4BIv9CR/0BUx06khBv/MA9wXWU4iKOhyd72ecx40hVsZsToJwBzaQR7crOJT+IrmBCb2XpeYILOLJOoiTeor3CD79W7qjyvK3V52qhTlj/Tk8OJCVhalA+E/d7tAe6JQupvL4hFVy08OGQWeltyqQkrJEuw7Zz2UFThtzCXhCnIrDUaGzVlCwN8LGhgUfnxZ8PWw6Xa95TDRFEHSnnBHDwIlYJ7P4bnpylQTPmYnJsuq5nYn+ZQOtd4k2YFdNTlu08IFmFN0HXZHE0McjnVmLupeR5prkaZ8lDTy/TnBgY06qvA2fnACHtdBeUTO2ssobFuvb5LwzDsMGIiQ7CMRHaI9LKcBMtsmL5JnyRVugSyLJoTCU+cqdkvyq7SjOn0moOW1atuSCvqwboseZpPHmi37EdXxGVtPY8f67XuDWezsONfSblMCDN2ZWMnkaHgQr8APSPr8aZgMx3o1suB7KwEwNdSyZY3SDu2DACge/f757ufPQv6Z4rI1BmC1qboery0R107uthezPNHekRbNDq2DOC8BQ/uv6HMguNW63UsXfIZQFswRozohvbd5cl3MvuMuH7Hqo/iHrr+IJT7WYcmz96mcGBW73Sn9RyaC+e1I+uz0fEN9J2h72JT3GxntvURrFUdT+IYnIK4NHUZEZRBVam1dlMdW+NZXipmN28v5xY3rV5BBxCumX3rS3AKPKk/GxG/+U3c153Kh+RWbUkvx7gIzsDd10m1Dt9TUxFSMwwjpVhJ1Yb7Sj0vDf/hvhxkPabjY20BvliiMUyC1ARHM99rI5wU/ZQRY9RxcCfwasna9NjrmTtsI2VLN/Yiy4Peeny8Szzl2aBGUCFT3iTd95BTkWaKRYhaucZqGeY3fzst800h8rvHYMiCw61O34WP0yZkmg/zg1WVLwZ4oe2bKBWp5fXm126424qfEnR1+YlV8aAAAm/JFXll8Zrr/We17slKoy4awkJvDwhP4FlvEDzixfVRkIm1OVO90wHWoR/fL4dUxhRqaovqj7dKWsglhlRD+sc7HmbsDLW3nqq6EoDI1NwySKlh1BD3E/HhaC9giitSaC/RhNl4RYW2rOD3RXO85qbChBaZhAxmXoHBTTudqj7k4wk7K9+kdIkGQuiZTEnl5/clzmCJK2hb4iD2H8ITe6XnpQYBV1iFPzRjxuWlWTJWHLWcxguuzjRi7FAMyJWOUFVuCuLYrmwjnyIccPsNNFnLXUkFNCr9b124MNKx/Nsocc9fIdZZlO91RmnI0c0s/Qat+AVT0nW0JYQuAaxzN3ztuqVCJC4RHRilCG/AeADZ04fW2Xf0dT3zf8k9VijQEZwQWrUUx1mS6v1vTM5KYsa6Q6hQGMleKz76ZEiafQvFH8IT4hUEMMoAmvSvpU/Rb1eC3eQayTJEcg1YOpuL5Ayr6sCUSq6Gbc7TH5dsI21lxGADip+0FTNxzZyLNfd41APjl0heLvUKkKFbpAjyNwGTNjLXCQAADlHjKaqt74PulrX1wwse2Jvz33JjytYATSRPn6iCkBcxiwby5YNAw9WjYnzkfO7tdVzATX0oCNRMYsrojbq9l7mmE+uObTREKDe6zqrgPl2i+6C1yorPi+3TZHLaETtsd7IlKOvIcNYJ1eUD+V0k6XYLuJIiAqs3yqeMF0uVPZfywOj+q9Dvni3gUOxhEoBUGua3dmWpjHnOom/VQCgixgn1AJZebKKa5W1pUz7FS/bYe81mruGeKfcWmW6Kn4hu/yyjx4p9XabcXtKShvhjLkFp+OfbI8H+jMREbEaPvPKbu+islvOhmp1mgP9DGBbUqGbNahzncnZlC7y5OTSWkFZkJwxxyWl1U8GGMvca86yONYDZ0mald3DB9mtxTWjpW/CqQR9GLgh/BNn5VA2zSq+iV+ntFfwtCLOyKXrol0mdS88+2+Fnxa7RmEd1DVq8fjljeCVt8fOnMiDa4JAA0UweQGgu2iECPrhhF6SpyevK2RJqq0tBJrkeza+CoNZPH6mnZ2Cw6p6eIzyBINa+oJb3IRRQIUMi/ma3ZIl3tkek5T3iTVdMJjpQsHnTKU/w7wm7wEsDRF7+E22LrxSdeqN0ozwr/vkMPl3vW4ycj7S3PVr+RvYP6UnV2zbjTNn2+qi/4Y6MyU7gTPDGfSv8o97xXC2HI0f7YQE1loz5MWneihnKPRwEUThIonYUx2cANBIePER55yYjhObRqhilkTbVrxWvvx/H/u3S2mHiCtCIaTud/j+Cl6/MsueU0SWuAaYmwFwS6ynlFjv5AROnPsNFk3UcqC/hwPp2vMZSZRxo71f+Z9lDky6/xVGOHLwQJUjmNCSwVO/7/oDyTeZ0smZgTZmiIH6IuHOKus8e5CrZfX4NJ9oQHNxei1sjdT+iI2IJgb0De5YHX1zrC6z5VwzY5omaI3wL+pFm1+Vk0cdUEa9/HsBX6+SSQ22+Nmemx6yG9XfWluNw5+SoccSjp/SPUrLm7VLK12aJtIl0SreQDAdHNtbHf6EgumVZYZSnkzPThBzSgBb3f/2YG21vgBE7NGJof2VQIP+/7mzwFb9d0NASMoQAvoe4h31pICDiuAwIEPlAiGOr0Or1MIPJkY+HvQC03SIL1IrFfe844JLdwKK5S04gbLZrI5b0IyXXBhqo+Oc+11NW1igP0E16hpp+v2/TkeEsCSS8U10nJWifdfp9E83HrWo+0br+JhV1CQc8txsAcwfA+l4rWv7DWiwIwTv6oSWf+1JWlbvMFl1FOFO5fpPc4RhX8nd0S/MHIfxpQwf5kc+lncMnAO2p+P7v6Q8PNen2FkXUVlbacSqB9/5cB4LBqudxeYM8RSm7PnmmXK24ssYN5c4W/mshyz6yteHFnfo2X9Mj2ylNIaGvet/2c+DXcbP++MDmV6ZmImUblpG2hm+nwdiYmgXV5/++z4toOm6DcmFUeohxEINoeCPCdWVtAA4wAIGzrv/QMPc6dzdS3X/AAHNLkrl0og7y6RqMcUbfWx7CvtLUGm86OdESuAkcL5UGTYQugxVLIBl66ZBcXvaWy2oPA7/l4b+HQrF7/s4GW+dVTevVAupsZjNx2IO+DHicnK6T1R5NK/gwqnrAUtNNSZ6AAU3hJsjJKKDeDKVDIFlmTTKrRGMv3jemxkjtmbmbdI1YF3so068XngTUBUo341x/S6uMe2XltrnYaeXF7stxdcYhIV+lfO3Vkm6B0OjqBJW0Zi6vz5apV4cCwO1y+zdI5LC/XXTV20e84z8DDH3qO2rA3fmrWwb4Fa3J2TKyt9X+lt/bl+9CpJp2mFdqhQNXQD7sqqf10hF4+ZXSzB7dAhI/44hsweWN4NHvZ9YbOBaSiMeth9oOB0uqBNbZD8YxkQ6aO4YwNZ06HRUM9Xq/J+jNSv2XIzQNUI1ztxRQb7l8sCrMK4CLx0lAdEJUwCH6Ni7G1Av9iKbeGVIbJ6qDqssmxRh3Hg3UWVKU4Zi7ur92/fbw317GWLlRsStOGNK3NXsPeBxDK+ZF+Nu3KErb7AzfZfvZcJH9zh06FpKKnUNWk3kZAGhkePl/BoHz0QcmuGlom2xEpq2Y+KHwnQ78tPrNFT6gPeFsRGgZgY+WSB8Gmjrb6QeWlGjm/QHa1VSIJv8pwPgyCicp3RuDPq/twIMJy9tb80cX0YdCBLfIHo6U/DkOzqv83hck7R7XlzSy9MoILgTZFra8LQbwvBgSedO5tUCu/1OYCWgV3Z63xPQu4VJ4Pz9gjzA4tery93X79K9YnakX6Z3IvSrq8QXZNZ8v0owBsRXoyr89XrLUfQiFiOHvQKI22Gl6td6GfaSOAEE1P2nOwPO3DozAnWcrvwjNliKA1mTdG1EdAaH3oCNGJsLVwQBnG7vayahdDUkyx0u+T8RfENwBZRmIfraZSQzcIbIXInfRXbBvjP9S7qsIBOuaVY2ybL3P75Kti+jMSrq9ndWti55RSMq/+Yb9PV/KqW0Y00itnYSZZiEmqsyGtRyuY/SxNmio/A71KN1WrlNAU5JHhHwxJ31BtgoFwMZsWs0jiE/s+u/3PTr/IcMkiC73pIvFv/VbR33nG3hf6DTNrls3g+xDxnKyKV9IOqJq8XbDzFNyW9Te5OrP06nm1FJYL7dDsD52D3dIMV98xNVjMtGUKmsdbTw/hvsttSowQWPRUEB24ALAvh3V8c5ZuUANMUGWNkrNyknRoBRjq9zwU+SdTWmmDSc69XvLjNmq8pcBcxPFQf3pddfQvwg8alK5BSY7nbgmS+I1jjyAM/b5Ph4VJcYvJ2QD89K5JMHi6Je/UPU/o910tY9O2wxqTRYTR3Jt9+fZaTEcPWoAlBZg7I3UPp2mwR7mbhkpSSoB2tg0NHeh9PphXjrrpoxRxNSxewLCkvGZzVVXxkGeS5Ybx8rOAbcR2fPsOG3iY4Ccj7yfn4GAl+O7VsPa983oI5DXpXN72S9iLHI+sKxrF7M9HieFrl0EfLWk3TaRtZWFiQFNBKgLyuVGwxOyn1W+kB4CWZkU3n/0ZwA+Fb8ymOKpLxuag5ERyY9W11V6Un2/KLQrxpmSI/FTDgNRFTqaQpLHtM8sa6sPjhrVd8b5xSl/bbafRP5U1lXtqCKcDantQifPb+7DDQpbjDFwu4T0e84S4uWCnD5OW4lU/yTH6iupMFQYhm206ouV1tKGS58urozZoQowrOg44AOU45JussTsQWIauRsM/tkmoxyjzhL4TO8shKyaAI/YtDRd2pkpd2dX5/Zu2QcwBVzfEHYHbRCV9preUIzVmReDnBn7Pgax5pDBI3bsDmXRILa7AD/DI88X2AV9W3hbtenSnvj5nXZ7/8tq2a326yzwG6drN94toCD9WRW0JDKxuljhLO2yZZPqE2+DbiS1Ysb08rll7OL9H/HdbYVqMqIS7nIhjW8pqFyHPXLsGBRJHRV019G1LpXnD9+kOXQLGe9acTk5FuU1KWJ1P7u1uOmh8/qiNxqkukVO38Y8Wk9ccJdIEP7Q5FGbmV34Vn1XgMQdb155QylWI6GpkX5W/8vz67aR50k++PPjg2wKLZVAbkcUH/lMr+I8dM+Hk//rjSyJxLmVjt5tnNW2qgksNVlJwe19l0iHCQ1zOF3HvnP0Cbdo8bsHjZwXyt2TPL4MMIzskKVYExb1SODwgJlTxNYLj2vNIiofttdEJJ4hAy1ZciykFK0GTboTxATBaTE42AYybNz9hGjZsxZvKcX1Ls264raRHpf8Lp3HoMP79Etp2gln7JEqft+1GGwNfxLv8hHiuTwclENbPbEZ75UzOCjv8QfkooEU8UJisEGjhNw/RO7uofpkpIsabU58O9AKLjIfraWkptBim258D4cbZpGc/YBY1QjAAN+eKAD9v7QraNLMjOnn7B00k6+kHSC8lsKrsPho7ZcSxE6PlhmfHyFgkfFxurNXPkpG0kllETYDEnUc9p4DFf7uQXYATC3l1DZYM6182JhyD4o9P+ydzut6pEoJF1WPoqlDOMiQoTlvqX6d9qpjNpRkQKWfK5t/v8lCFLjWm75yC0uO7eG1j8vKsKCAF6nori2sw87ZbHIo89ekGpjGJmFUrvMFL1eH5NlITkLIupn3Bo7qgd5D/1C6bmYX0rZiXPSsNO75YXzVR9EKdqhO4e5PFToO5xJrrTMaiCnM0YOwx45EkalnsrSipQjWXslWpopry0l0elmjbY/bCTfY6auxuBdjN15gGbyT5kUwnQi5K5eDPNYQpZDwhwc6fIYqZ2x0VRSu/T34K5Tg59piU7+aFHs3Xf54O3eQEeP8QKXcwdvyc9U3UPkCukwCKem4TFmXtoU8rFAZX7NKbGVfmR6bEJzykBlwO3fc5jcjYIdChJnPPKr3fZLu8wisFo8IUJoLqRWOfLhmo1LDA72xSC49PgNj6LLHYASgjpxaKFFF6WQO9/JwpFkiQG6Zuzqdps2W4Z5XjPNvc7n7icxY6iCcxtd5UbRPJTuGmsRchkjcEAlVUBlKnwwG3oKci3EcM5OCsFzkSeX3DEynsiSWXceCf9hCMFdY8+1oRQRsSEYOsO/0yT1D3m25cJIGsLrOEZYfrnvKcV4DEeX/N/ZXOmZ+RzX3VTd44Eg12Y/pje4HVqXryAYUsk3DMO9lmV6JFtrgr6Uk+u5w/Ko3e8JD0iNOCu7NSsMEpuk4PprdWkJaY5mqpgU22mqeFStilCkh67ZEyJQ1Cy3gGa4wlFUQcl9eBIwj9RAk2kMDMOA/BFw0YD5U+FVqIaUqVpxXW/5kYQMwIqs7WPfpJR/9y21SmQIP7iYBCMdriq+h6QfDNT3jx4xZX1gPg31v25D/C2rHTnQyl36R/uZWJCmepPoIjbtG8fdrJrUIY/meOpsJJ/AMU05oNqRIheAAAAlC/PhisPHARO28Ol5CPmo5fWoO/GnlaIENfNfRId/HMBb2lzvV13Yj6yFkDq3ohxOIb89QIaPn88W+EHu+6Ag2qhQw5bQJZejGT1ZL5HadekcTjIGbIjadlnDgpPTTheWol9VvOCTXMrX7dwYBQZrCeeCEL6/oYOkJL5AeFY6r7jGHb+CgtUuhojCxEYs5VY0gQ4IaXNqOvgMT/okkqXn4BEk4Coe/TfoOWvCFiSKZkKlAomdMxEhmho16gzyxGFKewhPJLRAabCg2cS4GoN6RkMeLXULTE1nKG8zgTK/6txkfBzDoO4V0xF63JPuyjpFDt5HM1f9s8vTwVEvLAmSQ/gUo5E9lUSP6T/9UbQnFGphkque642bS8C5kuIAjzTuVwupqe8fXw5Zs7oDFrC1Djq9z/EZuKV4AO39UwXiPTQwIsZ/59S5LhvPyXm5WxPHW/Qt4gD3dXREheMD/ANHjfD+EtmSfoPHcX9VSiZEdL9zYYcwLqH8VENBHqi1esdxXcXemPSqdJxckp4beYFU81iXOJu5mVtYGMJmzO5Lsox7DI5xyajq5kNUvcBVpdkrk8aIeAf3yiATEeSS4s6/YKfZ57kQ/TWtCbWzlITNRkonu1FpG2XIMNhaPbaIJ+35I4ZEp1PTh6LGIrlGrYoLGCqwNLl8kHN3JOwwW66l2qkuJE0mRxWTiMKdNQBEx98sP+vHRZ6KBWVurSEaIYT/+eSeZeHlJK6RLRrjZIHIhpsLyb0ZlMG8j08tosWrnNpVVxjQgAn4+2AtNN2JO9KhgAV5TV1movxxogDHYGMjouW4sAG21uS7swHu5DIlpIj4XLx7a3VusocUQtdKhCLgmWF3JZHeBTwh4enuucf+9SvE97uPllR7fnQ56wdsIhAHAsbkvhUpGGhkNYSyhFoTfm5l3Rt9u/Jof+eMRI/Zqkt3f1tcf0QJjuOuoUBcyDPGQxgA2b1nyfnnDNJi7sGBjyD+cSa6cvhPYmNRCA4cGfy2Hl6Ugxe2Sv6jLzgPg3aTPWJ56zi/Ik1XAy1K4dC2/MMUW7FG4+3tz84xgWVBpn8Pi90wtCC4ZueH3sl/oIOITulVXOa9wB62qTpzf4raVoXNsI9DQw6EQE79dtcLrlqQpMOZ171tSMlG6Pk4/rp4YWzDtjDvpNLBQStLmsCiXar1buHi4FXjy/pHmSQcFLEoDsYJRa7rVTW4olvWdGvPLDA8yKHz1bvMgkNapTZ5I42iMIVp9Xf+Z3Le5rAF0Do9pCG6EZq3xQ7J/tI+CH8Gl/xE5OmbdS9vKw05+Ch7rd/gcEkB6bh82skNR9YbVVRfl+BlHBRmxZ1/y7GJ4vrZpxR3PWN8+a6PXhiq/Y8P1z8k7hatoLD6a3OgWVqBKF7559sX95in3O1mh9xvoKEKRvYbMictSZW178HZ+KpCioH6I9CPIYgjHMlRfusz4euRBn8xzvliPGI9YDI67yI1Xkycrl03e9a0GQ+YUtieMttJdeWCiaj1fFP4DK+wwL4NlbG9uxC2SoqXeSAK+HAIFRTr+/lO1fZ2EI9GBTp7UwyZE0dja8fpJFFsE9MHEvqfF/m/anlDsVc/SRCIUXZ7hBlSq8ZnXWhv4hAlrZVJhxuLBGisXyoJZcTYqB+jyqjlmRUEFg7chuEYsKHUGNsxmHn10XMLJSN5C1NgYE/SClCm7RejpmBfQjooxPMhOTfcAI9/zhLvDBhhaJckRobtdC57N2xKfQELWx7jR7liBXaWSXrUv5xpKS1Oyzcb5BXelUhMEXCJP6ALKsSVqnjqovt4p3Urv30GFowmTIPeaDeYr40m/VknM/yGghkPDVJ4QBLD1KoQzxh5n4r/Uaw06RjOh0O26HWyGJcD/Olpu8d6y0Cbm9qJVb9WSbe+/SzcqzXm0k573VLIiGy6WOagAEfgbMD183xVus4O99dgXfTd8SxC7iKSMhzUYmcqKiSf2/2DsqgpyziO57+2XLS8P2EokrmCgzKQ9K4IcN/kvOTbt6IJDdNo/2u8CjBHQO/aEa8wdsvCPwtUh7eefOt8ZEk8WtJt7lkqufd1YW7JvC+XzbXajcxPu+Z4btvX3MLnY8c2LsYIUMrcHq+mLV176ivmGOGK/Voqv8Vh+XX4Md+tevENHhLdL9cuFD83GXo2fqjUgMM7URB2BfxViGy8XO/gobeKiYyFyyU1U32fuTP9J4V8obHU1jqhNDJEZDfK2X266cTJtzO38uxjbs+BnHJpZubrbIYbDcbWbIkYjWf/jdUdG4VPAWn5LWiWFTAo3XShIRglB0GeKIcaV9VXYIJiiAUYUMVaojMoorhsTn0FJoyi13Fq2sTQGYNxXtmLTs/CAHgnKErJnoiJ78ZNOWWxELrcIOjHmtNoZVBseXJTLvjGXz6ED/+Op+k8mzWt6frhDnSxmnzr5U3yNKevQwBAsbFHAj5KV+F3P0dU+VU0R2QcCYTUouC6dS+6f5hXst61v+iMwdyC2Cv0eurOlGLJK/AlRgAKKiEVu4ZB2ha90KzlVNYuuRtHjXEdrkuT5yd8Fr22Y1x+6rE+xpfxVRYtxMIoXKjAW37OSbj83QNx0z6qJ6vhL1Ql3paU9+XMgl5NHgp5LJcx2Nkn9MSjsuNYEihhY7og5+J0pwzB9U5uTJEwibVoLS3s7mqtbg9MEWeIKt+dXFD4gyEH2SxflOmNIMhNckKwqLV8fsvoBtYFDA7I4vg62tn+sgAaQRMYk1w6BfqsTIvEt0CqKTEJ4UDQCTWaIa3cZbQHKYZQp1zA5B5IWTiDPS1xHuUy0QnZuri6nH8uD5tNBke1HaAa5fp11XD0UADcNRlxkz8SYcN7Sl/7Bxpl6InPYPy6T7w1LLHLa1RnVkpygF0uL3/Rsn8kaBpuPXJEDYQwHulT8Tg5FLf4w/soOluHenPYMO8V5+9Wx3ued/szst4OTi7KN5BntfQdoBR+XSKvsONuktN/eR1NH5N0UOq68MnaGZsa+73EavOZDKVQTQ5y/sa7BUi8YDcGuqoNfoGKlKxrKsT9ob/NaAWjn/KwoRtLNhZ/XprgZeWvSKycUWBciyW8TfU5b5rT7iJPgJ7XJ5wka4eFob1Q/Fl75rCE6iIKcCjFWtuhrukkQJcKrLfS1ZX8A2iQiikj5b4SZOZsW7g471McirhesHHwaGwZCCztvWHWB4ydisLbANjnCQ8mNPGphCmu+zkdyINHuUwfhF5dDypr6H2TTHlbo6WK9Qq2AZWyNmUVnw4c1l1lzgPAGs7PRQ0n58qgY3N39LhH7FQYdEPCQaoiq0LNTUFMOzZXUB3xmoE4tHxcM0tpRmEz5pgxv79cY+HsyA4/5zKmJLJY8oXXOE701eYDCO62dw+Sz2RypWgzlpffiLrgbEU5aTq6Y8UckAJdldEkzHzn56c7CIhyLZlozb1c9+sz5fPEKz9Q/t5Zt11L8cuMh7nYKas0CEjEwg3ANiPU8yRUl/cHgc+yLQURTcF6k8RRsVlgKZWvotyLnlLobtKAMA+6Q6VOkBzstGgIWlXip5oVhvF+EdUn1EGa1lUbEzQz9AoH1ZbvQyopws0dKFlXHVmBWen5UMLKqb4uFOqncPqJD5bl0/KdWp2JMnbhmjjL6yc2xPbWJrMTPTdOExOE64kLz5FpCd+4SQih+reOs1dtG+dRwvSFbIlbRTGkUuR3YlOgkKh4VHfKwrwdFfjo6QiXj/WPluISqpm2cTQxZdwW37biLMp8aBdWS+nUqRLyvu4Jqrs9neEo/pjagii1QT6JKSOetlh5XP2tOdmOKxtq+jHDOYkcSJmhi6N0lGX3v49uLK0OrCMw6LwgssXMG/e7M0X7xdHJEmKucBPG3lgrQiJef0h3HxL9AX9ZeYwyIOt/yV9YF5+jgDhmvg7Fn4ZwfAmXCCX12wFoxMk/DI8vGi/t3nlk1yW7yaL2lBTTeHvctuIbQlr6MyvXI2bk04QKeenjUyRMibxK0cVJKy/g0r3BnJewRm5gaGmglb+F1GHLuNri4XCjTkqWU9ruOd3Pi+keqiwzvBKbQ4UEoJ2UjDjRy5sehm8kgpeDNtZFPghiS0vY9a0cWjP6E0z/uverkwChQpJNn7owe2lFa1ra3ZweI1O8gXvtxE/x9Gk/cw1IBUZm6IgQLeis+J4ZZQCJdYc5CUSy8i+U4iGQiMjtGUJVyCShVWP7uwMQXC0FiSneaa7xQ5VwGAryFxuxfPXowAZbldbN2uzEWIa50364WxEYg1TVJZ0b4QrF6AFHMI5ozy+qYvPUQMF16By6rNiT+NiMIEI1LCdOyXNdwyLwae0BzQPzGLPXOoXI/4bK2GIzg/vxdj9boDnss/D91C3LryIkHrhJVAia5dOpN023NhYEqFp5WNeanmMVe63KZLUfCe1ZjHQOMSAJZUN/CbZZpo/ibIMWUquZxvF9Us2YXe+UQncCHbyZoDacesVn6HN4omfON7nNOmAEKneNhRFcldDBiDz6m4qH7EMh3uQyhEnKYWByMjAgZGzo7TkbG5zfWCfUuYGoVVsOnVqn94gpvjPtZLPiAVJobvucviIUAuQCi9oiZ432Ee9qgseQn4hPSEkUIIThYyK4cKkLBgf3TOXajn1vTYheWj8lLWTCYXHf7Q2uwOrf+AWOXAtNknoPOQcQvocgMbsHyjTcCdXCUlbz3dLTtq4IB1HwVCJjUAKziWKcvMU1VlqJHqyGX/SEqQBrCHPBWQ3JGYK2T/T3W1EIV0w+LZuICDDSAqPI+x3VnwEbhUg64xI7gFmqSuUBX3ZXMVv8pPUs70GbW2YUfAMmbTOmVgcvl7WuoBdWXiS4+MAC1iPSy6T0p8Bydq05rs8pOG8ySMWkM35rPtt2Mko+QV+LGikhWO+XUc9EQO0EonhmwahX0PEyvQU/9PiqU5J77qA7r3BQ+J6GQ/GGs92lqfVGVIZOldLF/EfVgbLz/hCujyJDezpWmH44WqCWuv8TajOdPc3ihk+JNxtJBFqP1stI+BZOO3Pbch/NFMrf4Dvx/WCmGIJ4XWfGdsXVZMb2Jy24DK7yvTvHWQOXDM59C6PDcy/Zx4QzBC42uH+NmWA0NfHfbLub3BMOmLtCMkSAAgdx8+8QBM/kHVuoMPgl6kr9YkTs7OoiPz4SqKwycjo3DV0nKRnidCaztrK+Zn69kB+7EakdOP5bVusTUUJQuGl7csfXklrY/rqBJWfNo68wm5ZzcBim+41K2RBUbW2egm1GmjR00TJUCbZZXQjR/dvZ5xMM3dh1Vgv7QYt/7JgXXRMho8H/vECfAPY5qIzoax59IgqfbW0K2HyJXrv8rfdcT95saY0G66gG7ATzKmD6zsVQ+bA1R54sqDdG4HfwU0V41L8uvUBnnGTIW6d6HIcDLPdyJ4B+AuAACWb8DAwPKHnlLhufy9igxbgvR9F6DKpX7s/FC7g2cIwi2bQhkSD7fycL2jHsBqwbHcEjrhwifMHIdDLc6tyYy6+3YIqgHuG6TCXRrXKw1WWNq3PAYymjOEGH+ZxRk8PvAjJKOnehnfD8MmRqh3lg9VRyez06Fhq/MTViQcr6+WbaWws7PP3An8rqeBrJNHny51YUUlakUPy5vgPMeEoWLTYYhAwRLpe5oM9tVQZvgMTfcm97QYKqUhmsh8N7Qss6zQEwlYivU1CoA2pytBqApxC/kgYQo2W75GfOCk4oDhpq41H/lOHwfx/9WGi3hbvraZWJsYARo4mWXRfc1ZTITGZRGPK3vdK8DVeKdfaAB0hBoJCr5VNsvb6+aSGf0rpD6j01iL2RsgKiAK9lz1KreQm0BGG4aG3Ob8RI0u2q9e6/MDdFUBnYwdfPOK828tKjIDVdKdzBZ1My2ovs4VpPZOrEOrgL6Ja5QWy3OhOVpaul524Jn5zAIxPmBv7kibaA5QFHgOKcO88d4QvEuCg0R5ZGj8p0f1eiqQ3PUS2MpTvePTsRzGAmYJFLMMs1wOuI66GWacB7ymyoPB+dWoc4i7+XBTTXkvjY9XvfUZZxT6yHu5FJcVwJ4woqqoZ0FlnGcQpOfC93U/OAH4N9DsGlyKFSf4HEd6F8atXXwAmvi+PE7gXuINPzeSlxQBTjVXIi6B9db7z6917xx0Z+/hQrDdsFfiDCfNDMqWHn9VpnAizQHhL5LaZ4JFpVq/LPcGfD6noWpo0qn3L3qVyuFP2WTOriRQXgL6QdrOY/lNqsmE5eg03H6oCOvaSkrSR+tjE8kxorR79hO/JXQAwsXlb/ug2c6VlDqmoI0P561RCuAy6lomio3Clb4dz8O5V10rvihfBPyAefzH/C1dmfxvWm7pYTfoM/6nqr00mkLdgT69EgZamdMGv/ng9Pq3kaHlC8UL/NZJGweSaCgV+WsCcsUmy4DsdomY6fjYSkl/HrbnjQWGVRCCyUQGUeiw70eHbJRsKyfWmCSpZ0D8SZ30NuobhbP68G+Q7Ec8YS80XPK89YC4//O3i/I9t2BR0vO5G7RsvVbsSTeOzkb/fMe30bCbVKtQIwAAuwAkSR3OSKDtKI1B1YxxaTqYwhHoBOvFbOtuqwaMmslRhj3vxVxSrokb1YUzzP3g7FrbdRwicIJP2Xg1B5SLqqZHbzg82ZJY+2jXBOX7HYnsgfzBpfehj15u2xZf+m4yjqCruBbLHLk4+0xEVGf31M6MsSrrHl7CmXj8wD3BwytYmKwypyevoJZWGSE7iDA6yjC6lmCA5esfuDQol7yUJnjU4f3PdA124Iq8N5RlJ3umWJE2x+7SUnEjwUcRVWnibG/hCLcM+yjymHwprA3QrvJ+OldT8zyebcsb0xyKd+I3g6waoRdWdKGwJx0hVV12/yQGc8uzAU6u6x9flz6yVqSZs70qojKOHw6wlIp0zfQCbYKEipthqVm+5WSQMmVHFqKCQgvOzvLOvYm7+vWRdU3Uuwm+v9ojXCu3j4ueaPfsRhGBPU976PlkApFDoYZVlYmhyLQCbZT9hqf0+MRhLeiXOViWzz5tuVqcekAZw+pp51sxAG0KlkMRK2atzQ1UyYr8jO0SPoC3/T92xXMu3UUOB6Z0PAyLrqIof/TvftHdbWhWBFDjp9Dv8tbK0yVXExq20RxxVnfhuDx403rVzOYCWOi0Z37+DdFIUHynKSQynZ6MK9NhBn22fLygay1gLdpdCLMIwiHIX50xb0/2kbnk2wwfXIf8k2b8GjozOPVT0EOBZSEOe9z0s5h0s7PBMJmXANkAzC5CANi09D5SDnsj37TDmb6rUfN7tJgcnS6zuPL6QBKp8GXSdI3FDsyiPAI2Y742cKXqv+CwRsZiBZLC7bvAIw2b16SNnZTbhkfHvtwhQKvRYvkV7g/htrLYFZGJgZWsY8G1vhlPVJgOFo6YNiue5lKcMVdW58dJtBX2yWiKVOglrJnQxlYsHx8cb0Mlsdho+85G2kdqGslORraTywtSb0rODmKLqL/Lr+YIpfavNilA+uZayf0pDmqgC36iVmEWcoXJK9mwH+Ri7q+ttnCX1UBGgmXo44It904hxDxO1pJ3c9kdNm8OZfpgsp5RajCOyQ6viqKm9TftPf+vjMqbgLUyWzifMYMkcMCuP/uU8js59Ma/GD7TnZeCo+tf55082kchs3/ckQOaWQr5C/OzGf7rfS44tJLO1aVQiURhcw2JswbCfvldcGB8dTRub9DmGkoHznWTBIfWa4FF+JEZGffO4hure1xwIwkG14QCshE7vAmKnE4S2O4fWWw0S8ApGAdoVzOL3At10gfuIaVRXUc8Kujp7B5BQCgHvQNwf4FGBx1SHgJwJLX6CJrZ80ucUFT/nc7MSz0OMjVZEedRVTbLvSlU4zCurdGwYZuR92Gg91ZSJVsVH+grHCoqJuXbDoxXFvb7Gb5xZ59vz4MGJCwk+UXOh/taLzzlrq3O90UvHnc9ORudp/dp3NikGD62F1MWzqx8S3m+clWL9C0pN8g7HnlWriPt5lsRTbnbgP55pEtCKthga+n4+QZa/ILFmqMR5zC/napQQnxGdV/YKUgKIp9aOBxOWMPBPLmiDqPgZFapDxqlDwzMYWf6AFpfw6yzu6HwYOl5sttw5a3EcNk3j7wcOUzQUAyKALGLMynVwRVYIHgBrbXCpoKZPPolUCoLSSkDHpsDGF15eIueV00kILyumyZXztN9K2/P5mr5xHQ4VyCKaSkfncVOLkr1PjZ/C/v2WDMbu4qPhOXj+d+sfOzPDkAqs2jyOjjtwvOFJ2OfNx+CMKRAHPVjEZVPKiyUWSIr4pw+shzOhfwm0rsxmwi+B1BMDjzd50xz2mZtmy6NDyPuf8BCQp4SA3CsJKvpv6MDdA9jlTdaBFBqGFXbZUwCXoNepJY4UM3XLpbgCBgu6pLXSS4zWR7NslwS1masnE2YvHAvNNXQxrSCqDygsbIUxMzDstFiYa8mAFgD6zzqK8j5mTExAvfb6LK/n5QCJjtO2XKV46oJ7YTW2Zg2O6DU7m6Nuzi1E2hpHDr4ccSQZqLiWEn+SqYl0tAHkJ61nKl/MqCPLZGH3HXgFMyHoLsJwkBy08NciQetyWjbqJa5OpyTuVeIUJN3aNJw/9TtcPyfO5/fJttiyOWr4JautZ7lna3ngYqNIydJYHnWelNUOpcMBSZjS43Fp1ZMOAruI5Bv/KzGpwwwpRk6r9649dL87GFXEKyHaed/BFTypGZJCL2WSSH1qz1uLQMhAdkKxOlfa6ji4AxYYcsbVSXzzZQzHlZjLJ1xkEgtDVfVqezgzsCjQdj8Fc91nrX/WnviKeQglLWYIVDaTJF/sDW2DsIgzzu15p856//C4mRcpxDR47kPmxowf7bnTORc0uWMSnKGGbSQGnDf8xO5w5zfyTIDQP0NQA5KAIveHE1984nOZhokLKr/ReUCLQhvQEsmA/RCHjqMmQ8fNDRL2uUPsLV/qerA8p+/+TgV/F17zmb7P2QiqdYhCJesXR+Z5Qngf8jfnJT0P8oc3NeE11FSzI7PlsYdPNjl4AgMXpa451JnznqKTYLwbRYDYGbeXLbkqEkjlVaFHrD/s5qttqoQTkuxPmta5eRRMkr0eb2wX+gDrA9eHALIdNupD5hlcLPvEjAB+1iGU+i0c7BTNC5UgEyCds6Y/FLvDdvJv+rHsK2miMrCyPxV06lLuxhbCpBaNI8kk+SLrpE/QI25rQiE/o02wOb8EbdLeWdZpBhPEHRc6rPTOr3WHQguPDMS4XjCrK7N2/hB4FoiCazMgSjV0scXG1qQuMs8ytsvDrmxrqNq/j429dJbXE2eptxXsJoJzhZAjAWl9M4DgaHu0V7IB82ZFn4Ew2gLaP8ZQ5p4tnfba3glIruaX0ErEky3ezYVHfyW6GLgw3S17/A7bPLnsHyQNU52MSXoi+32TABtwqBaZVz3Kc1iWdsNSP0rJWVDbp1zZ7TcsK5ICCIY3siPx5fPJEVBDkc4Xx+c8YIXKvdaYTU5Zde2wEzBxi9dSn+wOrmV7ydE738wtawkjZnucG96DvALGPyE32HzwyfkSsRb+7Y+nfhCbEFCf1qz/yLrArSLLk7Y3YzwwVeDzck/O/FUEnAUUDQsedCjqofb8uXV9d6i+y+FCKmWddSSYF6eh0H0yzeMd7u08vO8f0oAMNO/0VCzywHCjH+53fVseCFTCV5u8N7hkc6UyOJV3uBWOBJSYHezuGQCn7IjrA7TAExzawRYKI+IYYhkP3+h2k7dH2DwD/AKhRZ0QF7S56rSvhBAhBzgaggnCsMF8PCWA4NLNdXQgvvK+EUxb3KxdNFSN8+XLBGNNHZof25qq/R881JPg20o0ISnLv/HFPK7l0oq7fz9Q0o8zQooaHra24rdHWsLM3Q6pq/T+i/crndl6XtsLU1SwCzhGhpbNbEr5Lq8THcugWEvLdltTUry4vqkqWVXWSfXKE3jd5YtF1fBZjdXxp2VJhaGE2nfBEpaTfT91d5dV6KjZvaLgAsU6MxIrSS3MEUcRetmvPSgQFZcDX5OmYw76oaqw/ucxs5SU0smkZx1vWdOKLYyHhl3VDvcc9AI/YGGPPexKN95ff36Klu6JRpTaAQwj5AQ/kS//g5ZlT+YTf3DNDUI/I5z3Nvh7HCXJiyhrA7RvZVfjLEj4+Oygh4sphuoznXYqPY3aeQ5FQn3xN1AVsTGdpf0W4pJDqxtvtRBwTs7qrpjviiluB0OkgEGY1pdzEMJYeWF1wKAS3/SkbcDHjQCC8fNoEQOfkmMZiO+hEColKTCZlHY11+w3RPUaEBTLXzARaJW8lB0n6TboomVomS7cSOxVlyWidT9Ho3RDBMIq9Or2ZaHbyAOKhv4Fpkd/RPOSevPOXFwmw0u2RgQdM1BgEz8bMlS+CC7eNjHt5IHACjC66lvQ91GFUqJaVqfwTfYpYtGBdSX5ml32PnwRjYqzD5ztu8fkhH5pzCVv8v2bQV08WUk6/jeqt4VhU2ji8FglYsKZlGhE+jBqh/MESRFQBwbYyEDBT/Z2NLtrsbv+BuKmiQJUif2gTSqWQyulh6JRdIIHPqOmzc1DkkXoN60jDRA5sgTQQTz2gAApfN/kX2IfaH06xv+dYQvNZJaEnwC+Gy+FyT3abl1CWj9TylUEO2jOEu7nOXxyKnD15idHuicAC0z44M6Mn7OvCYvPdTdG+2kjqNPVpePjFkNzPL4RfXVCCJE8AAWyR/MtPmYJRHfYJUkz+22tpOjG557XgInfv08TM3zqFBU3CWy35BPqaGGL1XOLUJpYkXpbE+tkRvL0EZ5YfLOy1QpwOQJBLZwv7X+vYrfjZy97y64clCTlH2VoPEADfA6lmQnG+JjRy24eetU/jfPjT8yMD8Jw7aOpTjAWPSQ5ZT1wAJcNE5D5uOUYI0IXghTvFQnYKbXDIdw/OC129MNTdcLYoW5tuHFTv1lckBXvmq1sY1CWPbjS3ZAU1x+lsKmv8ht77CNFMtUWlu5k8pMhZR/EIJmM1yzm52n2XZRuExdcKEwg2xHd8fyliJfSwh69naEEr13i9RaSDunr1ykfqY0vv97HoryfU0k5kLf0JGkMmA8Duks2S1ZtFAMj8KmQ53snU/9ZYXnRVnkzRyPmGzORwMq7vVI6Aiw6VawUs/rGzuiL72pRJSwGTwLtJLCwDlTeL/IpQKPsEt2tchPBZ5Zi9Pyeqyc9vugnLkZqFOTFAD6sySD03DXEqjY8Ky5MSILCArxgg1Pc2XmYfkaKe4/L2dLQU3NEzjnVxzWGiDGY972xSUbsnCb4beoIgokVx2GflW2Tl+73K3tWR+HD1tOXxkXsQs8JbzwDZl/TfRteaEp9Z0YariO+4HW4N7U1+xc/Ethi9Vl+ludYqO3Vl4sHu0V4dA3od9z1oF5tyoTTVEKu9asmb49wmPWie2mHOx6KySFLAf0+eVO1JYeHHMTb3e63BXCZGOQmHEHtEpuFAocqMpTZtqUZz85n3bEO9fs8iWMp9KQ4AFbMYUcQLWaRCjoVmRI7VAI6Ln7OVa/TO/zR+bAvnMr/Xzw8wlp416nU5IbC7yDeRG2tpo1UZSwuhIv3re/gxIGM9lxEcQn5CQ89FkwjVvS6Z9aUV7dJsuSsfzPdflqxZ4vcX5QQ4rSQbOB03FZpgADohzneCHFX+SJMfi/B4OxcfpbxTDi3uTEX4alUuUP6WXdMybk8ShcUKdc7hiAS9usS7ydYVzfn7e2Zw3INqyS2hgXovvNLxTzbJz+Jxv0ufTatr1uSaEIn+1Dxov8ZWLO5vuD1M7NGkFzD6FhOr1uWaU/YPlAXCMs8U/h+rxSiU86dNKB1asbHzL7ADxHd45j/VYh7wXFIQYPUfj0cqei4vurGHhAEuNWClGS5kmhMEZX8zvI/eiPanxrmnPXkE+km3ixq8g/0Wjmn7zEhGNExiY+Ux+ZFaNYBx2wbWDZFWyZNbhy91HhQJe8uwutkVMoCuHAZXEdsUPAVpYUru4PJg6/3uy3CF9ESA7xzns6Kg639iIMQlLw2RwQY3sFB8wugS+6rEcyTPjek/UiJSvp+NyaOFNz8vV1aDdNbKwnxMivjycj64pumowJ2hFTosNRT4YKOoylLCelKWz/ej2Fk4ZbVqXVpzy87HNP3KJ/3sc+bT5bFZeUFWigBYAsF9xZ3kn90OSvVJBmSpC95m1SmN07AZ8ZJ+fJNU6KUi3fItuNlg4nLDDBpvmJlnrkP6l5sFPo/+Q10xq6hut0swOqRvAbT7QTEPsGWxtQHKB9BIaNiq2xTQgR1Pc6eb5fRqY8mo0YvVHy/JSfZblWZGaCc0uq0MFDVb3ljR/0r7IN7KDSyPkfGgOSQuXh537bQKCeConVSoTYEzUed/Ar2RvrOOHOqtGL1C8wbFKpr6RF91lMZ2MKZv4a8W22jgxrbd4khzUfQ38+mtvJQZue7xI/FT0cxc6vS9e0QVGL+gU66L38sqMA2ENq/DYICjBLceawaVlg/56i9GXB4wpu9xzZMBEdmY93HkEZsFK45Nyw8093mEcGj4KUesBebyIn/2rzcvZ/NA0uLnQ/exHDaegwQW2l7wGmPDecl7F4ELvXiUrfsKJ7kMg0uw8vknGBjZm/Xps4FbZbjD6PfVMOUYsA9qyrGjW5tzbhG/jLP9ZypQSKeti7XH9vZ6QKq+93GzWJTy1ag95xl/+BaoupZZlpWGUlTqyUenYtbvHihCBh6wLc7/A6FW+h/jzopyaTgJCl/jjz5DdAwRk+uoGdXdTSgVvn7Fd2p8vI24mlK4itzf91V6bAIGxxwyJ+QFVpDjt+2Z7p9IFB/487pUdZokJJKngPbP1q4HBlWW7zUvN8c4FE81P4wucQOpylz/WoX8w6XsdZ9+gElAkiP/2gz49ihXLfQE+3gxq+X+qoTcwEuBztXMRG7uiqCYrck6NtEXGDIrfNfvVMMHFulRA8ZOjyotAkkhk3F+pdSlc/bhziHVYrsUUnLBiRw8O4W/q+ouo+Cxy9miikPJmyxfejX/6fPEHOn4drgc4MgEh6Hld2Wdt54U9hoEuYPdC96ykTScoRHOOXKhERAcEaYPKL4QKvmrjPdfIYpGSunDgzEYdqfoCGZ0s3+7McVEDLnxzkErUMPu9DPMxv1aYK9JrgiPdXg+0tUUPtQwhoGSTFlQzQWiXu600M8G4O2vpEmg5x32YXiD2X9Y9Fdwz1pDAawto3ZzdpaKC+uqjd5JnjwqpTEGqdAAAR+A/VRH7ObCC9bMMDn4OxIT2FRn3XfIyuKd2nlRdM5ULiZPy0jf4+7GmJdRown27L4Rv21mXcr/d9t11R6HQXSdZ/mu5lVnGJH1SEdNJ/nRqR+iSMydi+m2YW0nh0oFn7Fq84aY5I93GQT+d1tzmWCk40Y4w8zPZguYzUZ1aMsr3CaC57XcrUvr9vB6XSwoM9mIH2Uh4QQIPTXay30lVPuP8UeMRgx45IxH2RLvy4Qzce3rZwQEp6Pl376XrzhnlGp1a75dhCiHvEFhTxpS2Vzs1XsC05uiCFpq7R6Pwp/5cfZ0yCQJRoux2M08mmrdulxcBP7vXHkOneMty3/LOVwPdtPmggDCfK9rSz0Zafa9GdNYZhEf7OZ9Pxl4oSHnXmm8I8juOwBle4GbGB57+ZIAvuFndPLNjHEDDM23/tncDwJfIeLj7exgoJPAOm9HDx3SdG/+hY8+Nfp/k5TLz/VXQ9iwtKWhwXfzFGACl60SzwrHyXeeW7/rqCHpbIyvPZ6YLdkKAow54ATvEpyN1Wgc3PGJiTd4ipeiTC9Uk8ei0ZHVk02uwVvT+sWk717jXZvdIR6jgKY8yV71FRsfly1mYCeZZjNhF3d7p4DbKpCBFQ5RIiP0x5nT0XCtSs4cuF+LEdQEZFmLIXPb0/t3kEG+kUIs+dGYSt4tLlGURtjrVgBuqUjhtDmdfQjcWo7/GTMnl6X78ZIwc4Eul5qkEGeKMy+7taeUkKJ4zWJCB2nfgvoV/mPx6bzPhDO+s6D33g1EVwE43QhCsiwbBIOMcAKt6+PHnlj5MOUkMX+DLxsM35IHhz2z3Y9kiZhPjPGqcc9CiWq5rGxBnG/O0d8beCaNo1JzzeGJw/ZJeFel7FUg4p84zlZTlBfNg4IKuC7Orbw/UjZ6Ig4CyZrfM2UkgeAACNYqHW/ROPI352dbByDj7a7dd0PXPYaj/IlBdvxueF4VbVqazlyN+ni8xi+I2CDF/ipoh5AkOXhw8JhdsILtJMDIzUv6a0hs1XuFSevxKGu3OEYk1OL5fgLEJt9uHBuSFKVjCzeZW64Ytt75ufW28I52/jtFNDkZ9QvzTpYd3FLZ8XUbhBA9/rSOQ3ERwe0iCnJC8mFxNJ8ItOhl0wuGtxhimOjgQg20gllcHkNVHprTLkji1B1jxg1LT6PxoU9JuHCvADxQ9I+x503Kav16CsF9MwcWlThujmO3XCEuhkFMXe1kRPpkPUgRUpuVK8Hc+x6ID9DP9YDkrHHh2mQXUciiUIBN1mF4x7qcx7AbFXExJJKkeijs5tl6y3u9M1Rx6HjjQNXEpkQEc5d7vLhkqNCMHmaqM53BymXJ2a9geitElqaabIqOyWo+Y4tDZoMdEXhgMiQZ1RkXH//tSIYPDnsHUE12Z70b6o1HGFqzlMYeAD9mo2Zhxx8v+gvrZ+ryt3Zv3Q1yUSKQDz0lFL5VNcyIQY3/efqCY59hWe+NLZu3P272eRuVB8jgqzZFcKObvpO/28gQPZXCnRGoi0LcfYT5Sy8gibbkXVLAdPDHTrSykQY/7QGWjfO5nHT+klYTXiDafxaYYn+5wrUX4hK3EA+obtTuEcDnEQyQmwrIxE2OCcMsD1FEYkgL2ckEDBvzj0QYck6hYl8dQTZNZJPyKIc4jFlYrsbGlgEDwbAtbr2MlSqXXbQ86It9RVppCVp85UTOz1F7RoK8Q0kaQCBnOVy06Y64QkHX5QM8mW3JV3jPUQekKHMKqMRPgix/CPFhpbtNrVM8NiFisFTqj3+3TJvdC3y+MhBYBp7em3YW85igscMuB6xE+7LqgvX34802Q8FB6vLLpWatkeQb67XlgdWgutib7vOtZXOamzahrDSitVeLQja6y6kRxS6YFrzhjwAIBXNxIi2hHl2fe0Rirx8m2jCduf6lbYsaGEFT+2w5ZEchNyVg4O64/vwiduY9F4g1sIKQeKegumw2w1X+3yykGZnIMcka/e9tM0FNmZ1elSylvtT5X66oa3UgvSLDkdKblWXw87kR3L59zFi/lQA6DwV3939xW7gkGFZmc4SVCerw8uOE6fcBNqyglCG2T8vJ0u40yaOhU49XhgfvoD4Ya4D76PGOtzCbV1cswk7pnPmde8WGOafkVGuNW2HsdKco8ycXBEfVULNPLqXHwWbxQA6Ay8zszTjTqFbKu86y+bVQZVZ7lTWVPoYtxMZZ60KT7ayPTUORCpJrm+PwI03qOIUAKdwD5zOpbAAQU9XtmR0AnmcysqRBUjqDIMivxS5adP54WZ31bzgInfC9DDGRU2L9Pt3I5ldUexGSDBY6tzMSBDFsTyoSX0MbLPUgDc95ayeEg5mGlRNao+3SkEjZeGcZ6Am3l07KjTSHMOvil7YvhK9A2YgjIYkIXtgg6pU/hQuI5E/mYVu9ROXzrQK2UXtJvI267ofbP8LEk0h4FXM9h4hsQlIA13oR/0PJ3BWlT3wGQ+EN3s++R0MPfkeKNpQA6vR7A+2WXlEOQ5MTj8RB+gIXmHGMiL1G1/uO5yfwcbtB48FOq1rz918WVBBNDtm7+SrqFovEYKUUMLuMUT0v4yCFVoYT4fULCnDtnX+ujhuishEnmfmSb7WhSOkZjLzMqHdIKgeztmmydM2lZHmxe+mUihooN8IIwq4Yb1U7YfLWKsj/eQATKdXJrv/CmO+Xew2fntr7+rk9Uo1Coqp0Wiq6wWYH94vzFurfFrj6efZ05zu8TZyqh1svm0QRVImP+4u1DdsjYj/OXWOawqmSaV8y/ewlztE0INrkNgYumIcpHvr6SP8doBz0ofJr1mc0jpsQlKmzYYQrohbJCu53dm3sG5Yv9iCUzv3obqIwNFnlmkHt4XEEa7PeuRIEtUmcZshcvnOmg9XULiKk+4Bz0ec6nutCJKvQVLpGQNzNN+nHPdc+4EbrW7OEWP4oWx4pm6vtcOJ1LZalQxZZ3t4IObtBsDDuRXX5wXodatswxhXIjt24ezWE220Aa4fGH4Fp6oNw7QZY0rNQpbdkzBb6/7jAyaeZxAJS2Bso8H5ojqY7MDz/j9FkPN6EV9754GELpDEWtREt5zyDHIAL+1b8CXzaVsSBlbz/Se7Ihu8U09htGs/CqxlwohEKGxNVr4P8X800xu1qG+lCe5dH2L2aYgTX3hHPwtH5sPxNKkhovyMsmvzINeuLu7b3eufW4N6k/tOidJSCP7mosuSjFsWeYHXvRQr/Rm6Y1B6eiPfCo3QJrjj9RmlZSsSWZO2bH+Fpi+tFCxQe21LCKbtqgyj6tBNeYZdbIcXQmxxoJdDXrlIRLSYPoRwDcfqCvNddBvllzwt1i2vcOetkEVIT4cNB625Yv8j74Xuu9YRqMSimBCmnBYIOYdB4NzSa+B3JFhNQ3QDvezwAjJm1ujdMgk7WZWh6P5C4XkXrsUwG6SOO450RmkI/ej22UH51+JrFa6krG0RRVqEbi3lkZsP6WXaXvcz6M3SSU/EwtFQDLal3WIGnZpN9J21X+t2vWhXcUgWeKkf3/Us+dt271/DS/84GXrVToyxfdkOmou3On5yKIE3s6rAT+Wwb0LpriLOTjMqqibWDfuL5ugeRETxFjkdiIjzgQ4Jhn7eT3hkkjmNJ5FMFsiw1IukCxsJKDpycD4iEqK6/oCZwOzrvwwnxQRdP3Vi8JknAi9zZRbi7DvkAAAKhswFTu7YXPhMdu9r6RRnVo9vrjOFMZ5PoYvZdFAD/XfIvtahoedk/Cs8MzZ/G77uoYmePfimo2qaqAMvlDtWzeuC+d6II7GW3XyO5AZ1RJtWk9IsEZ66Jrrd0SseYhLWrNYOT2zgFunqs89EdPEZ1dx1BSEun+1NdC0rV3uIQ6rCJiDkGs1gPV8TuOpXl14n0+Zzug2LKfcAVXQOBSyQWga+A1DztMWG8J9M589QDsbIha8NzY+JjDobY3ltvC5CrYE5b9L/34cMRkjAZ0zZ2RXMMKPluePjnzzHz/533hkxNm2FyU5mXCsQjAkr47R8I09QldnEzqvf6KJ2bY7tMpFb8gJQ0GVEvDGRmY/Qe2a1nHKb6+FhfUI0Ovy/P0ssmvFItRC2gbln0VS0ql2e1PWIsDPNeyVApEgETitHZUelyXxPtBkw9wdZy9oWETJZksibv/mMbcZEz7Ld8Zp/QSCoviM3y6j4JiNn4o9o3yPc1wyA3NC2fdEz0VCGpMlI57ZU76Usu7kBI3we15MOcbqIEx8GjcHdi3hrErtM40dfP4yQRUscY3DGoZn+kmR53JpChiCBLcOOIKJ4CXVzhTrmrPxKqBV23m5Lz+77U7lNJyIxkcABReGLNG/zss/eCM4EtNfTUNHbURqbPzvSkovyQ0EmXVd1ZBSXemXhKN3hMmGKc5Ym57Qe9wFH+ZBga5DG9YMXw4WZDM2MqISs6L9VL6Ym1O/+fMyKEycg3p+Cldv8GBTItmdtLqiXjJ6eAxp8eLOIDvcmIaMqR/Lnno8qVLO7g0sPHcwt8N9FmMAY3bjhhXk4G+vY1Yb4kyqAAyo/S9hP2B3zscijztf0oeCrz8D8LyQlZUG4HNzmpHcymtiYi9quuQ8gh/VHktvC93dgxWpv9YJ69Q43A/IbAEhROUhUC+ypDHL8LfQqJ+M6f19uct3xTQGMMTcXAOvihSW+ybRX+is8YfA6CiFTFxv4QY0mKoueZr/cF2qCRsZmqTEURg34xgajsN9rMd5WIMQUEcFQIbI6uyqzZE8liVMOYyDDeroa8oBsmUPAtrBOkIj9n3ktWs2kKsAagWJkCi9a00zJFOJ8UjqcQpV3KRrYvi7UImNpLIQmDhnLbeLTuA5SqrXvflcfU/D7oOyETI8rHmeEqzND6oN0q12w5yJ5VVdE1Jgvbtpc9CkpYtGpKsbx0rbyizPI0YWcFpjEB2pby4EkCp0ggyF8GjmOFN363Od/YUDzz4J2NH98wzWQHdHiwxmUmF0SUOzYZP9r4iNYhHzAqo2f09xhJUi1iy5NMlrsx+w2/9ROE6vSf0LhEartOEikFts/hL//cZf+N81Cx8zankgm4PwRqdm6vYYQOqrw7RJyVcN2ZOJ2181KtdcNclE2MB16wL0pqO1r17xKJp+9F08K154cqGVqH/qfQhSxePTPOAAAE4S8YfEgh+2zA98esM6xcyGDwKgNKqmAmU308t5Isvxt8Nbsq0m+1HqLqSR9VdUa/iKsHkFEF97e5xuOjbPChTNkxsxEyGFadPkZJWv+O00hUPMIJRRTDSwhnkLZqjeXQmAG6YPmlfV6URDNc1jG8tExM7UZ7vRFETzq14LsWxsKE7pgC4JA6K8yPYC/RMrO5ZGlOpPeo7AbHCzVTrTo0sUPA6k10B1NAwrVQP0Hc9t++LdWCDv3373tQa6Bn4RyVJllRuh3fwVKsYGpiBJdy6/FjSDp6wV4Snsx8VWyeqEfrdqlqXtHSFwU7MNS4xHaEY/EqdXsNLM00RaQMst0/VdWQxb436UFKm1DMqTzoTa5n+7ZxfDoYsjoppx8ucXdwSvtgxTpJ+Oejj1OOxKOS//1S8+MT53HP+xAtBdnC468T/k61clStbvz43+EZprJcMAPnAR/2PptjEsE30GH8c4z/gBUGo37p8gtzvIiXnEQpi6j6l1cWy4uPB0W5Ya2gWrm+poW4iQEUgvO44kor6tSUYS0H3iFOECZ+IuLQ7yRiohrApnTwkixdk+kpQpJsSmmlBGbUOZDSKkVekF8w1pkM2d5ECGJaY40MemPquLovtxYHak0Up+rXuEkFrro2CfK8GIYD632VzA4b5vHJ6W4gYmSTbQl6EbeWP2yG2jlHxPIAGxKw/FdOGOIKyQ8ZLuKkLE02yWF7MSj1pgo451fOMb2qQh23XceN+dG0roOExcBbBKgGvkI6o2ug3svJxQ5hFls5bvQ2d6DOpHZYuAvzazZtmaZNUjh/4ZXj3IU+SNBcJxJw74RVA+blyUEfA5OoOOfoADDWfstrR2/PEnzmLX29s9RoDyPQ/Y077LF9w23vg4lJVPlNyNkbJil1A23i0Yg47z8OyZ6m7I4L1Npll19kOM99XHwOUYN4emztFOiqx7ndR18Pys7NCwQ08ZY5TffmFwhieSG5PbhrU3zwRcz2GXfW0bajPIErLSi4BVC8cm4Ylj/HIcK7e3AmKh8X2M3+lEk1lSHzZxQqkQNBghT93VjgC7UXjU5B8QLy6eZ0Z1gUpVRuR5N5gTdyxbA57oM9/Q9nlO0T7LcJnZoERy8GXS2qZ7o0/YHMTipgV47M3alBxm1ewh/P++LtHon+4Lc/iPUbdIoDhFUbOurFff2uEmlv61E5EtSS8hrFOdHF1WB/ZsFBYf2rT8IZeWDBHj2A2fn43eEHHXyATbrzQ8rYN21Ky3JRUANLW+GVBJH6pe1ZFVe1BcZ5g/hp150CXQViUTPY4KdfLBphD5CK0ULXDT5gEQXGcaNGWlVrE+pALUfV5KTjTXslvI++9dJcggGOnhhyQGYnl/ziZWvNc2BUfam7xfFf+avURUnffbrKgVTgOUlKMsT6SuTr75/WuMk+odDTvX7w5YPgvZ3mN4Qn51IFPbjefBe7TYT7qcwhE8qBhOaFr80QgM659tKk9yWtOQAAMJ7WxnPE09msIW/8Xec5l73d+W+ZjiYh8ZAZ1IDAaaUOGAW4Px9R0HiC+BedhDWzDUDG2Jx2KJ0ZEyrJRyUPjBbaXB/iTnvkuqVdwnpsw5BbOkRlLRPHpX8GZg2uP6ZHshVg4ZItdpRRBMU0jCzXcKEZ4uGUaQucDdfI/aubukq8gfRvNAi9L0EGRciZ5g/+pBofJAmRD/4ItLrcP87qZ5InW0lOykHoEl325ryEP+B6GseTcK7d0ffZ9sSpSM5cFtZ6Vbs79cxzq+2rXRGK1tmElTOss8KgFNAmlo8uWPFak83qY7Ko6yeQXgmvVpgI43J6fHk8jy10Rx8QD8HelEAlE+6Ttm/SllckcvRdTaZ2GeNDlfkg98SM1HKPlc3hRXYaWbCoZHRX8u33mNJpFoOg694zehnjPpuY53O5AzwGa0TLuUYFFf4i6Rno5suzZiFqLBE0QDBahEGrCyVOF91e/KZpU9tCL30rRZ1MtqzFg9OAX1FvSBFNQdrIiTFsXJFRHgdGxbQIt1GL/ibV8fu30q2CGVmvWM/VfYU0dPHYvyuq4Yb7LjEyxmU4FVW8otmjVWvhh2jxhuGwNL7KQCPTsSxS++RgQ3fpdvKkpcagMRrv9wHrTp9MUOmlE8ZXlJMqXsdOIGKt0I/RyvL6l3uts1CUD2xzPKha4i3NWFd1KfP3jWZliVww9naVbDUCWPM6rRzE1cj3M0tS4rXorg8yzubjaTimnigK+U4kIPceISHLnqu2R9ffk4Ql44nvGiaqETeEhJtOQcwkZh18KxIAHmO1zFXptc/HniBLDz+rPL5NEssfXt98kXr6Vz19YDoU7FvVtZQ21h9idgEH+gtzERLmIni1Ra1+vyG1ldHHOF1/6pf/wiUxjq4E1DXUWbv/Yp9MO4PpPBC8vrscri2kz6QISu73UgGqpaxDofaNv6R8VCQs4EMz+Fsj6XI1S9tgRS3qmDZcjF8WuMzR87yqXQlPaC6Wg8ODyWcVaQBUZpaWMjTUI3v4c94iwaTDPkfiPi+lnIsbA2YiCvasmFE8xFPjq5cmvJJ4ce9i06hSGghMQv3l956EWuR4sU1xQZIQaCQaO60ztJXi25PRL1KBL+JEYG42+G28OPdN1tvYQEjLeN2Xdg9HUVo24RmDQW7uvhY1I4A4HS+qbEvTSHhAKBFPJXEG+01RUgBRDJhadFmYiBW98M+6ve+74KGuG8j3DaGXE3077q7VaqO8rAVmB++WSAIibglpix2+F0ocpPWALyl61qW/JZEJzs9t6MqKuUewLAcUGfN1rT2s7/fiZ0Y1f8Af8jjVfWNrAQ+9O+F2NJK/i9uxIKbtSvb/rufYl3hWLIzLrNWYETIvx9JblalPSFPhJJvY6QbSQOkqmsei8fum6TIbhtozLL0h/xKGMcdX6I9OWeQDTY8gNbyRLSBtV34UwZzbYQFJ8w7KdVszRvlk2rlrci1rB2Iz9ctXkRyk1AVXrPKOdk5mTUIqnh1Z6RU881mDptruM7VKIf/0i6GMOi1te0ebor9KJGGRKTbTyNMBkiiiPy4P12aS4NrvJTa1Rdg+HtWuTBd0P7G6OGUDGyHh5tnBpCN5vmIZeTvR5RZoDIw51vPAlSRl1xnF0vPhVjT2Re4RLXwAV1xECgAUTeuzZnoLbfE+n5ZXHaGuWJVQ+0flye82sy/oUJBItp0epAF8cw7J0jDis7GTsRgxTpeQgBTZtLQ8vZoULfb7CNt5UA4cx4w2h4GQ+D2W1BlarM1x7FKgP13sOBr7LI8wMp8ey1Tih/6EEFzblPP6hsG/lbJbUeMBC5oYdOuJmDGAAVi5O347qYLvEuhyOpHCeP2pT5DwxhWPNbXq5iO58LIQjM2XAl0D6PjxfBF2zi2BXz/imJDnMIjwzAar9W4lJwyIkjJNlSduHtzPnrmSb1e0QV7JGjkzlzetDiRnRLIDpPioNabsqRuYSf7piME6nhE9qujK+XmC0X/b6qA+ejM/aW4LvZ3ls9mLpmennCnjkgtta4igIZ6W05ox6t5uGtRVMYgkuXvX+C8quf7imDK5ZvmJDRNTQvgwstOsF7TNYOAqdtuIsHccnfZwsqxkM+KbYXhKg/6W9Ru8YDLb3dbM4uw5bdGaTDbLFPco3WtOG+5WORnToeW1CjiodbmeuBV60zn8INER4LEUsCAVqi/692cPtyA6eQkLd4mXQP5Xdh84tTbHiKSR/rsye2UFIjf75TZl8D9P0JDLA5fTr02k4IBT9Q1pGmDRcFFLBIAhij328O8yqCNH7LcengzoqumjU0KRzSp5vBBGui8W5ZM6JA06oiQI+B/J2YpnIw5cMZaTS36RU29guEsi7lH5XtpZDd3s4d5vWub96OCk08fEJ/yUtfLYUWakVjYPlONlXkr0LBmvlvKwvF9/PTn2m/1tU24vyFNFjZTGmmEtLSBTAW2xdMDjon2LURj0WEqMQwOcJ2Lh/Pr5SWaYWeDEnVEiaPONsHjmeWoW0FDGpvVzHZhqnXfZ0lUm5+r2Q2pzE+4zPBAdcW9R23hSm+dR/f9/rquk8dUnk2PK41v728wXfMK0L5Knvk+f7sy45UQpFkPUnilwF0Ekm3wn8rvrhwfYgimuyZIO2fX3vJbYxe4apmJa+bGM/gMIwRkY5ETBH5aur323A37PILBHOc6On8tD08Elk1NyswqsY4Jkme5KjcZ37hj3QlOffDFVivgIx3fQ7rXH5KGFQItGf0J+r7YrQqiQzZgKB/Zv4ZwZh65OoGKnLvHEHkV3fMa1qExgdD2rAy8VSenA+IAp12Q20y7qPTOXf/8xQEJrakzp1R1z4h5r1vSMa+nr+i0rCsz/MwxlImXQgYhyhovdTXDQX+1NpB7llmwQhUI4pE1J/jr9UoY9I01ZXtqUQ+r0B9mhXgg/+wBMrjX7/JxuvsaCuMdkiTAYGZ7e3iU/CM01rXbs+ZP585BUzMH8rYCI0pfAcVdgZxytenLw9GxehcsAZrino1o2uqdWkz01YWKikrzNtx1I2vhTh4o3Q3UNSHL0iEHWOsj2nITQ8DhC/Y6aI2xttuNsoe2ELAGzvE5TOEwimwattAh7LobFGncmlcpz6/HdzQfsKg9fU61bA2W967O7XOjf9giPbGH/4rsl+hGL1b+4dAR/Vp9V9c/6nQ4YvAc/MtxzO8AX3HbkQSJm/WmJ9ZsMUcijlMFrrYorF7gQRzUj+L32GjJhjT57I+SZ6bdgvHgABY7kziqIbwcFfGxes8bcI23WXijbAYy7ddiGh2erZ79azF+9zBcxDJntHoWrsA/Q/z4UJtKrTVzGB7ZIFnzy+L8ZSyT8BDVqszqUqJgBkADkzPlGfZaHOHEm2oG//yCIFX1+rXff+Tx+IS9zr5D3FDmU/UlMLKyud6zZajShbcCsaW3Dl0ZgGAhAD8P6GxPnxcHDTPoJFRjwrQylvNou1nCmCTcZxmVqwY8xiaNf7BsEc0lY4TBrtj1+/8jSM+CFkfdzKxAqTsboCkOzip0G2TyBMgS1KGlEINMtg2dX9F6r+aw4H+EdCdwaNToGB9WilBTvy5HU+9GaOPI4eSyM/oVjXUmFG8czVJVz1oJWPN/XHd3R2uNJk89HwLEhz167tguXRR8TOfqvr20uzO8ggmdWS0V0ZdJFjgI15z21cubAsSOHukK6JjnXykwYzEO3ai8vHWEt72kMNc4Q/GjXSyAE9Lqa2xCsv3ErxPeqM7G46lRHHG7rMrZCKyQQ1nuYjLhhDcNkUlDE35zpyiERpLWtwLeC6fTNAwtq1MjiIVYaG7VsR1W4vtjaBPf7kTq1PJSnf5yfQnXjXF4W6/pYEsHHDvDqxrwyF0BbKq2A2ULy2u//SCpYesM/jn2PGt62vB4EvJhziQCk123NCW2pkJXiNPZrFhYn099yIBTFsABu6tzcx+iC4zw473T1/dDqIiMVBYvOpggEumXlkIiLav5dqtQpqQ16InS3PzTqh3CHf+IoWaCaoAoX+z6hZMEhM4aTCK5Y1UP5q5o5/kWC6DizYfU7zIRZ9gc3KikiLVQGRUd7kKN9y06hJLLY9RZ4RMmgv67RjIkna1j5kYo7EwTOLJwWJ9yXYOEdVwsbEuDd4EM3Cknt4WKLS/ozGQp83rJrvSqNZ3EL7JDwJa22C4nGCyXsrdagOsdAC9rvIMnXp/HG11+/oVpfM2/JINYsvsB4rdTtm5R1VrQMt/gqwt2YGvNr4pA6w7UV3xTy4InvOeha2oNj3mdqMVPibLNOCNHVcIPRindwv2/94wbALfjLg67pfJra6UgtnDqR/+AtTg1jiYWFqbyQFM9JiKk6+r5x8uwJVN3kAZ+gOK4Kok5inN2Cq3rAIk5Kh/r+uvWZABhG5MhwLIoGDP6p/fqdeiDZfHI/Tcosh8LgcfqnUNDz2lh4nY0cyQPSNqgPC4edd4RfQ7FCDndlV0Y+wtoevT4wSlVdrPLVb43Tn8PpeXOUWiB85SDxUao1UMDOJ6IcmopI9XLCNEIaZcEIUE7rJEL/eRUEMbkXV9kcMq45wceYb9yBVskuvBzIVbdULLWZVJI7c15xHEOw48hNtBirDEeoKyPFZ5K0nWWW8fMynf+Gk5NqGK52GHyrrNxC5ORSdLMShGk1pmkyl9HgT9sPUAqOUJVj8LhQa7Tx9Yo6YNTt+8wY6pSN8uAIRBJgXPuV+cvxuv/XZynwpml/O7l4NS6AgvjFZ2WFBoujSwkztpQE40JBQV3SLAKu29dt+Gif9dSTFmIm0DniYTMUnr7QO5JPhC6DtNhI2Oxhn9HZxHHG0ldll9BGqwmfIFsWjEoJMWE4JVe7az862k0haS7DLNMbqadN85UvDPE0LqbPagGrZSwZaHSawTOtXkHcOJPPJtvclXKVlxnkbaWFkLb/IqkmivHM2yqd5nU8ok9dsVbk97S1cf0QQU7UtT5m+3+u1/mhju2baMV1y9dm4cruH1rNGs589GkjhDHZRPqrzfDsi+7/98NQE9294xcPJ7IvraNLV15qMvRhX1ueYFD5cOGz5u5SuTTtLnqHvf5DNQwvSQ+nhOcA08PAVvkDEe1GqmPhmRcUW3tq/4BlNREI1b1twwmtaNe4sUnSngKlQmzV/EbKvXc1By16v6An7yAf8EVgBsgIVmx6EprgKYVDrTbt4KG1vHGX6uHKHRtT9h3Lqx/ogJoixkUuFBIvWLVDXh2kLykxiVOf5SGyeJV7BwRFkXhg1rhRvsKRS3l6Jvavs/oLypURbfPi4yIU3rd1AINmmNnnlaEb4Zw8OVqEoEI7aiG9+gRDF5oAU2IpjIceceLI4AVc8YcIMjIE6CDAHUIvnx8gg9KCrXNSGQeLiUMy6FtoAlcR3VYVO/BTBOFal76rEvBUl/XqpcuGmWwS6TWQUSzP3bWA/J36c32PFklv6klvHjQc3Y2dGmoFsSRP1Oeijp7JyunZ2py5/1Z0S5CQ811LLsBK3Wrg3vXqSix/DRLawj05WhowEhLAw70l++KqIDHa6yuJESMt4DyqZ0U2VVUI2AY1UX+tAMd/azQK/kuolzSl0wXLPIpQT3UQpZlVOuzswYseYPAOUIt3KrvWozwIZXwmK96l7iuikNz5hVmHHNtG8friorqLPG/QSmJ2MbGwVkSe5jAxl7/kk0ZEK2nw1e6RGryp02cPtCCx8zcDHjfAlqYdxwALmY4CutiLD/WNMmRrVVeV5FyRkB7aYuxwddGBiuTvxapyvNEGF0rkhtI0rsrQAA1nZgWEADfKpM0L2cMpzM7hGxqwjZfClqDp0qQPAD1rJVddYDf2eYPaYQkNMMeaLRJbN36xHsas2Zai/9TV+8XLKJ302gzQ+mTocr+E2uEqNorv/EXm+089OgZfn3bwlHW3bDx2tCqkCLIf50P4tlN2kVn0WXqz1I4PY2qJLjg9ycLS/ozCVlPulsfZWkOelZFiLiadelNcQYqjvnowBAr/6EWPJHBVt84nRO2KCFHc+nXJjdTSUTDm8owYVtaIQnGJsijGo2yf1H5eEbsF52pRQ9UJ5r/pyCWOhWj56BjIj0370dJCX+R26dt4Q25cd77ByHuelMb8Lxl3KsZuMQxgDnxfPcA09XBOeXU8/VXEvTEzVjIK3WTJ/QQpeZaIEMQGT/MfXpP100CrE14R86YE1f+kKLmzsH5gC1tB2AjMBl0GrJ+1ORdyxPEGFkPcdA3P9804mnaykvEv+P72jttzYLsCK+R6B3mbBTbDfqiHCQtCg0xzXlZlfVhqVTSzhCMan+2sSJLNyV/iAPReDnJiQD/cUJo9jDM5SzC4hd+hgysrE6UPBO5NaEkFSn1f9bKc6odHOZKtwMyx4IFqply+CeW8/J+rFt6Dp+s4rL1Y07X2Pjcw9GNjIUpDAQE8EL22X+LPTNrRaKzePv1wGqz6oH7BBe7X4t+9H2pzZ37msC9ITZ11kOIRo4Nw9EkUN/g2C+W+gBbAPOLS5s3/AhH5rr8rXieavo9jtIs5rc7wl4/NkssJzYsGYGcEeXZXMt0VbHT9eJm7MT9f2jy8Y+4OfkT9uqYISIf8PueiIp7XGFPz0bSxsKRoZE1iyKRvj9RUyhLlT3RU8LKO7vMTrwvFtyXSPJ4HAezulNO4oZokN1Zqa4mGTwNLhD3xtnpq/ek0mPTe4JZ7TJlaskY7uqE17A730dIZjlJEnVST0SPTFHn1hJ1eDEkhDMfIe642eajXxuhGcRSlS6mtPGWzr8WKurrZf3xPN8hjn2L8hsu7J3PDRA3uEe1Pl+ukqFFci8at/TiSiX+tYgwY/tc0ivnD5ozEPDuE5R1hNQ+rxh6W4YeFSnrgrzIM8W4ajFmJ89yDGNFt0WhsV30HwoXXp16ay9bsQ+v7GpCMsrW7mn9uUQlTaIEsHBFVG5ZxVAX8EPmdQ5piS7CNGOTvArUIRZHBWV48ZVHJaBkOBnqrGDWZA1Bn5xsKc416HWBsn8CAt7dq/XzG9qlHrPYfmM+w+yawnRaKKzrdfNtrw2Tv1em9sNHmVs8doCSRJQFU4hS0vCwfYvVswcpSbj4J0ZOUAALyAAFm1f2Ag71o0cx/HYMp2vetJL8oqv/rgVPq/8+dTPOLTVT+Ebvi3DkemtiRaVYDa6U9kTh+w1LzHVWebTkPveLCdySwQaWUgRJ9fz9oJVgTS4EBErGc4SoxdfgGcM/gHjscwNobCAuztxx3gIOA9WTxyAfuB06Vv69/GucJW9hv8+nPEyic+uAgPaBs4KBiWNrlhxZ/lNDT5Qe4SGHmg+jsBWQH2Q9zphz33eDyZd7tDuwsI8lW3OhIVQ3j77fFmdQt0vJqxinys0/U7+/3Cfk67zvwfAxdIZuigYOvC5WAc+jsliIY/vlhYoTT5Mn+K71B71h6FkcqoCtysQTbKmoV8Oq4vHO70Qaz3Wj7p6y09oh7j50EsA8Ag3IUrnvpfCuxxKHCCf62vNZq0j22NHV7yrfUkmFHYjFD90Bte6+FgeVZsexmmiBsUI1fI+LmCX9CKTK7R2XpAW6L2ouRZ8mlCsyC58lwqiUiOH12NgXGUpLtXHyQGTw0vM4EzEzCM31Ph9rUbs/sAgsZ92AQcrQ6Bs7hMIHr7TxN3benTZd4X+cPh54KBW7wSyasw30eExDjt36EpdT7Q7BbjJsOrKZ74u7zsGwPBP/YiPl0mAqm+H3PEbsXVrTHg/FFeFslT4Sy2FbrhpIS/potWoVlSXvHGeem0S4X4YOvIqnPfheodpMP1TobWo8QAgvfGRr+cZua0Fflr8og9UhpP0LbsmhXVOPlsxR7ro1rn5kJO1zPhEq6nd9YcX+IPmoF0JAU+B8ST657U+hio2iPTcF5leOeXJ4w2HHcgjdWPTCHkqWVl2vwPZW26Tkj7V0fRkExaxw92iaBoZ3w9MwpBHx7eFy3RnLix2ZIHwZKV0a9dhK2idWXcBhlGlYYjuKRYduXomW4fMT8YoK8uYa5mORJRS1xjw3xi0siC0BaiVmTvKblwnmBoUpXHUTiINkQjfUicS2R4OYbj/camm97i/fSVDiRHSDXgKoDgpwQk4S1nHyPG2JlxNNcv84kptPCLNWYpfOebWWBLDFt62kvJA9GMmIGuZO/37T7qBpxsK9+qlf0RZtI8/zIpsBoJrdaY1XbEPH3Jih0875xpaNpb4gqY6lQZ8ZBHlgvdwvMIwJirpoepfGdAXelBc3jAhruJuGI2zqD+FoXBLI+vlCyTHgIUPSs2SzxJQpo/HHmj4q6qQFB8ytFdhfot9l4YZDPfYR4b9phUq2KTvuDEvEcqT65ksYqsp19pTi9iR7WgZGUDNAyN3WaU/3NWv9BPVg1yGxVJFKO+H+CEvr6jCH1BAcHCJE9wBQW/6n+r15VLB8nZ0qa0lRkGzl6iZEiQCNJfWdnhrLmPZx7GZAKqeh7FRDQ5r9esxIWITNxZyx5oD6AfgTswwlELLVZ4byuB0Q6QAoon+cs57X7aQpiyIhoKo9QPH9T/Rxw+15XcOn/6U3MrpAs8gadvIa1uqGHioLHNDrgguk7B+z4Xo0yU06SfQzqlE+xB4eW3jXpivMNxP9PJwj+L9Kc2/DrgH8q9AZHtrBOwwydoW6zrJLkowccsBrGi8eV/U+a5G7ttMZ3IZCqDivtrd22riuOVDCVDusaXHAmamil4jeLJnA46opBcPkM5YBg3VrBjtmwVqcYHpqOaA+Hx6eurrMtaItGO4gFIWZxCHyGRzU6LLHbhgL/m8s0YYGMYfNycqVgKsw8nZnoX5mcmajEhW8wC1+Rb+4l7FzFhXvLvnPyiE+yJLbAw61dr/Ti7yfihz1siHDor0a2fJEtUYi2xj6zyoOvgH/DfD4u8j+SlAZgqi10Hwo9N48gi4kLPh/05/GAqXC+OfAYiJnGK79D+zOAUcN2HO/D5zTZW1JCiQJoqArLntSZdPpL+MzK6US6wqJyLKfr7/h75rcqYahA5dOeDLfUT9V9uUuG4XlrTPklT2chx4QBPu1iiElJccj/FYHWKr3jYq0OH5QTaqwLDZSeI6RjwQTmZrDZK2eSfKUIiFI7sFV9c+uRblv3PfaciO+byu4+YKRtebSup2UntLjSEGB/gH+rtWUudk9qC7/ibvI1DUI5uEh5lK0LiZukHbxLYsPQezAd1CpJmVN6OzaP+TaCDsZ9D9JWuUOJbG957unCOQUvPOMsCMl7iGJyFG/5SKZEJa+MUawDbykmSd+o+wEpnVNuGSDk4N35X8CdKm9RDLBKaHMLQkfU7/3bB1LKZ3SLy/Tq6MhvE7Sraa3qS8aY9dn+SGV8etRo53qv4chXdbMSdj+6Q4zSy7M7nllNn6Wtyl6DlKPve/icbG71JYBJSPqdqwJAlU0DmyBtTg8nGUICB/AEK/rTZqulzzjLAjMLWe8n4KZduld7EBnJRuLOvVw5Tl++Jnv1ne+JQW3VQBvzDBVqDYWc7wczjILZvfFE1mahas6krMTGx5saZUPXNSGNn+O/vvKpTVTHi7M6v+sSp4ghFaZ2pmngl7uaAo2qw2V5+JpZhHTVj1lPyOBRn2khl4QkbL4hpjNy7PCmKRmhfI/Vs8QaOf+Yjz3ugG0fC5IUKiak8jAABcmlYhf/OekPlLR6J6aEGjZKFML93iLXd9PQ0a/IlZyhLdhK3/avoUHWwx8o2c7csVuTE5GrrMFecpbQUKZUD+w46gl7S902TXLfaSwLFfkQ3loch0qga4puvfqY/JtY6FCU82f2pC1abMm2UxjLXDxGSsXyZAbj3hOD6rt6tkqKl+0pkh2Jtbxf2N9RmpwdbgGiARLd7Mtig7GOrEuL5F68FRUBGljf3cC0d+8S1iaqhS5VWyTSt4pzXqEXObjQtHvysLfPqxx85qrgm+E3WICEVPrw249mU4inTUq4jBkv1DMwKqDO6ycaELx6wuoOJ6WI54HAEWCcpEsxS5oizFhHV4G+edqLPtpQqvUAWjg0/nKG1nGcNZFWa5AwZqWdACBD1B4mAaAZAAFRJFuC9LomPdwZkuu4GxQZ1958FgtvrGBKZ0sE+JS0e5RKZBouGj98tLPXeYk5bWg+GdCSnOgY1l10Ot7ZWmUNErVMbxZbXnVWZoX9tR68U0TZiJbHse7+iXueRYmBPbqb31DcVGL4BnKnOowy/R7lmplz/dcl4qjA1Z3hVi5oxxJp7G/DZKUXRgZaAJgufS7TOhB3CT/ij7qL9yvVmndIy5Ppfh5A9H8Ydas3MGZ3buXay5n5xZCIJwaXmV9S2NZCAUPBHi00eXUN3hluN2g1E11zlTZBcbcdh/cLaHLJ22uBKBqa4hgvWPzMdi5s39wirvDPfT1JLxrOVvOV37oQChVgdNFuPC5vdLYb9MkORTZYAMK+802FEC1GxGTso1NKRo1RtJpHgehIvJqz6bM2Ytwtruho39TnAcaZZt6A0qc4mLzNOjPXqntqbfvzHhX+QLayg0pqG/OwPSmB0v1mSS4FLnVthc8eiz7wHZVAnUG2dfDSS0MfIo9k5NBFx3L98SPW+xcmjMWHZiX8xuiCZUJhUlSuChs7Bfj2QUkDHkHF8kF2ZNtL8X/em6SRq3f/M3N/OQ7Iklu8G71lqckCEOzDr8hVKwyY89DYkakuFkSSv6r4DQsseYWRgfv5ZQDNrm2w7HDRxcktizPOq2JKHGHHNpQC4/MB8V+YrEyy4iGY2pZ+JjcApo8p7VxqHBhVKa11Khpv2ZirdLSgE+pChgYATZqsslBXGVUzvxuRrdqem2DFOeX4nCBFkYxunKucGI80fEiPeYJDfQulnzVhJ9+MLi86eSKok6+qPG3tVSgeruC5TeepbWpCj9izl1ozWmXt71KcV1zybUxr1+lqGrHTrhC9yDrKm8M4OyuVu3d96kCYicveTU5FFGPJ9Qf0bW8Qr1J26hNIGhgV5jreGaAZHpDPECxURsLugvitXKZWCRsJ3/1XfaunsFt1r+8Ra5W+fjp3x1xkYZvpug5Usx7wzdFw+xwZoo8GUIlrFxpJksAGLaOT1fPB5qpnaRj9/EtP5YSpdOSPBuT0zahdA2ybPrAAlB7lkDRLaJC2BPS4cvQmOc2TqURL0Xe07Zr4j0oqNep6i/LY4sOUP+8xO8XXOewgfQ3E5Ug3VqtGpJ8vo6iTWkv1Bxw3OuboausFNZcaTkC8seWO8wG3IUyBQCgO9PTLuavGxAkpP5fjCGsRrIU4ArRtcl/bkiaB5dzpPXAAVZw7hInsTCmWoPi6w8Uciony56/A4Xm7fkTOewlh3YP3oeVd9HGRUuxTaHsUv6H6ZVHN6HIPynBmarQdjWRDVyaQ4Hxbuh0BeZyzvgXBw2wVfu05L/h2Qfty1H5+Mr9NaX4T2WxjWER5MostbuUJbZaqm+Ue2zWmynK092O846dezBrykNweVxJ9qRkygmz3tO3lxDouVpx5K3RohGgegjH3kLTZv74cmpQhZmb30Auf3kvqT3kcL9Cg8LVGP2cAEd65DFzAWqomIzxARxWvhJSDpFUu4mofa3VZ8f+dywYUYSXR72674R6QixoOOSmpppYEfkyCsF4laNBuglwhgLhh1xmOcfJ5Az2PwSsgQMRBtgpfIZ88aQ9ooutYTDJs58TSvqtWkcy0f4q5sRZNThJqElkmnTF6fXOg70dkujqWdFjwUY0ijOxb9vneJgjwEL1KMQrAnEt5tvW8Xkv5kD7oQ/ba/DU5/IO+BFlcm0Dgyxv+ETQoV0/bhiyC6T/GBxCU04Yg6vAVIWXX/I0ZF1D6eK7i2vyNyB5gpGMXUBX9gIMMLgSIfvAYV6lDZ+fgJ8a+L64cOU6khTw+vu44EedUyepmPrXtujjwvpInrQeq081f9H536PNKVNpLLOp6Y7/6jz6juPGErxlgJyBdLSCvC2o/ztuGODE9ta4WKGk+2tY7WW6M4cCAcsKWGwLqm0uawutqWsxTBhzZyCjm7uu78PwcOKgy01BGleUaerlKXdMDjyjYTSrTGX68QzsdcMtzTq1SQzhYJcMqT0Ez0gebzleHUwaZ8F6TET8m/yUePXE1oLgX1CtKutSVghXaOVrK8oRvy3ol25Us1OYM+JYWuPNHzj7KaLhgOhjYxDPQjJ43LSG0bGu8osvlvRvS/uaJcRKVwaEjCMwFHPrd+oKLT2glTv79MKKYfNaR/lX4NDEfGQujB7pcMJ8yemW/FlUiktTH7UuZZWRWt1/elMMil3CYsxuWUVE8dOYuZVtPo5USR4dI3Z8iz+4c8zGojdgDCSHFTp8N9iqm9oybmS7JL4yIxp0/CqZCRjUIZH6lIOOdz5nSnGEhnGG48PdNceAOuTfVggre0PhJ80I/4pEwcc1zgMVBbSw1+yY40O1ueEBhPH8vqhocyyd+9yMq3+yaIw3hq0irg8bWf2qVdCce5hViJvlRz3vqdZTBkuHZ2ICKx3gHdQJpmxZ3dzTkNz9neZd382aa494Ds4rL/ZULfbcQFK8WpCp55otdEBLvsatCZVCjphurR4hZDIzj0MCMjg7Sjf7UCONgfyXGPgDV4QhSTOHlTHmLbTdqxhCXVChx0tScHm7touYFNVV2PIVzhkjb0Pdeko1H7BdfANbB6D5sJZ4rJVmhiTZbBlyKEvMjPHi5MoDNTlIbHB+mcMoeMD2A0jgVCPs5vkyc/oBqIoihATSJm8HAZZ46ZLJVx1sOVJZlgMc0tqoL4LwU770ux1j0rXhTV5pLBQzY3BU38EQFkv3rW4HFJLLfJsh8eE2ynQiTU2Gv61GicSbqVV5ZuARYmyiE56cMGanQ2LL9cWjP5sXcl9x+JPQe/CVuVX7G0NlKiUjB0dmBQowBarKyFlGCnF/PySRf/iEISdhE8KY7MGJrYVd+yZMleBonm+vEY1Ri9AvmIZEiE8GZvkwWEew0Ovu61+UZTucJQPgf7C+wF0HEB5mydLYoGxe0BKJM6jWsxkyM40iAi+2eBqOHUeLK07dsPqlm6zgQMwWjhWfg22i1VFEUhhxxDRKJlGfZXCYNqs4fbm7gU7bcjIwdqZaV/daQUB3WrGtKLsZzBhAnd3BrN8JCMz666BZLx15bDIX8Mol2fEVTNF0EOYdcJ7G6Rlefm4u4MNBg19+JlyRRnFO0CxrWpeckcT9ZSIGH1q1z6NQB82msXyPp5yxyNs4ARl/fDFcfdNMeps1v6M9h+afx4KFXu1Xoudl7GbvyAXBlc0dokwaqwfzcJjaoAZvGHcm7iqK9M0dh9/kB1jcicQTLOH+iSrK165lF3HZ6dp+jwG7kiAYQwVjfaiMNEbJ2nWEWyh+6hasE3VSdia27oQIojKFqPbtouQGBReDYTX6/NtqER1iC0sizLdgyhs5CdvqYpzL9Z4ojF2ywce/6Pphn2LjdH1nqon2A7/MmG7BA3tJXAUt+3NEDI0qm8U9VgLGZO7F6pzNM6Syzw2uGTqDWBBjABTII1PF32GRw2GoJTGAXHWRsKYKiv8yuSVCWopFok5+eTj5aiXDS2DMCnuejUME0QJZP4bCS4Qbkyr2fA+bp4gZIGCRlXfNpAINOf4K/G+x0ORlGbY1v6MQVXBGzVzv1ehmY/zk3Mx7lwwTOblCZhIZy6Gl+yJjc7l9tn2rd+hbOxu2jj0v2cSJy19x+XFQgf3eUA0fFaQ35XWz07iOXOJOiE4nGigJwQJyQReHnAq45iIZJHrGVNE2F/6BtIVdtjVA82ORACB87r2o+FvL/OaCut3KTSX/yE39LaMjAR4dUmkWB3HW8V9d445sM4lYeI65K+sF1W7vyCuQhSeQ5kCRRdZz8cB69VN/tAR5cYywWnsST3zoPwq8RLLbATkPFG67+P8vkmvREozv41k1FqdP7/HGOeI5YkNk7nCSea+7oMufEYJpsVcf3pH6D+V4ecZzyrw1BdlCAiQQGw6ZQwR7bx5pGB6bjT4Fd4trReFYoZDmI0x70XqOQc5PRjDKGD+5R9HP8Fu80EsAqCob71KYjEuKFD5xzJ2xDYzJ84cGuXw12fDvfu11zkOiwux34pZvVVv2wxTabueogF8Hc49/7XLm2MAP4V7q+4KBG/sMN51qmR2NAr5cx4wcehXO5maVPd+dGAuCBclxwLmrHRt1kxckMV1yrZlzBJLepsv6QhKt8A4LNWJeaQUcIt9HABmhRPawLt3qVteNkPRqlSbrp3CO+mPF9BAWrBB07e15bOw5oUtl2yLPb0eqdtEXqCW68DLfKUGy0VU39eLtHUnx2lMS2pPFHy9QRgzwRBrqnTELn9yeCTw6xrjxHaQRwiSm3lhdpQnh9Y+7ageECETD8+gtT6W42ctZnHzB09B5cCd+H7b896qFjEQnmDAfPvRRAmM33omlgsutoIQXD7VEw7fG6a5m77VoEX9Ak4Yl6LK9FranOLwuYTXvettDZT/7EjO7ThRSd0q1a2LZGl7gT191uksntDQbrQeRMdCVnvdSpDf65v8PwBtRWcnFBCX0TJIquvEqsECPcSpPWRUmkc7IGYnfmqsSkzidBqTj4OSP/oRizjU1YpYK6u16zIkctFKiFFeHstZMLPf0cKKbgsP9zznQyB1mGZ7AA/2IwOux1Kh6u96kfusFmh1bf+6iPaBpKD4g/Pmpo1dCeM+auIIhDQASuJGGXUB+jACj8fHtgeUXfnlaVL03BGnsaQhpGu5oE2xI/f7lFCDzMWWhbmiI6mOpwUEGx5JC3hAUzRCjvnZ3sd1RyIL2QpCSqmPN8CDM/FmQF6x5F8ZF/ldGH7yJa4do2DuNmtEjvN9LB2movqOMwUgBSb0atQ0UL5guLGQME/egtR9kWTSQNHTuV3HOjt/ab8OIzjDENVV4se6yDcTSov1Zbj85QXGOFVC0bo7qnzEYjEQ/JRakIU3IUVjwPvAPYdCRX09FO+iBEL7jDBM6ONP7ImFAstEQWc/rGaACUZWAXiFkxdVbtHpChRexcHftaKoE9B4zOm+93ypUd2VxQJecLEs9C8JrQBh1oNkw0RMy+oUZjnanAPXGbZXlUbZgvHfjNQX8ndvRcCeSUuRtj3cOAY9pQxXVTNz+HFzFrSi7wMW/CfKYYWPgefF3yzaR0dnejZaJe4CwiFUzAtnTPe4WQv4dsccSYMhaSRxr0cwgjwcSMteEQyVUxZ3aC63/xaQpiH6C1PfgW4oiZ8S2WVjBKXvZxXbeXwjGBqo9p+Nq64cNZOM1BxIy9+8cL6VJVwP6RPymeMZiY8BQdtN9wPXeLKWj2avPrg6OdNxxNNyzHjjGxpfoqb2U60Ur/o9xmVtCZJz45iegAUkleaAVyAymdc1yCIBGDy4ZxFmxiCPtuRQ3ePCXJwmq3z/XKaiHWXcv8PXrBVwu5fz1tycCGUOweZ+x7cZohZuNa1o0U1tFhDGgtO9xgkctWNS8mvzZNsPqdyRA0SRss8sjOLlqAdFniiXkINRb5doUm+PYAnry/hyUjRpSSyGSvDvvtkUnDVtN01r27XZHt3w6HuezRraIDbNfFLALmsVj2KsnAYyAQMPCZuWwYsKj8S47mSMnrIm9YwvoEeAUTD6cHpDgMrjRxCeJ590pRQhRkORIvz0EBgf7fbILLC3wbqK+Vai1mYnH6DYUFeQiMgnXR2ciYFYXHnYR0RGMtcAmyernFLsSbFlNun9mQF5y98kHLXfAThQCg2idIB+86CHMZYDMTUEZge6IPakHIw7fm3jQN1gPDy4OPlDpTFP32O3dEYRU6BNV3ZncTeiaJkmeKcskKQ1J6AqwdbsuVxWnOxrKy3uVZtePmkFPMBjy5jYFAo12hs594ySccaPMpld0rsVmP4io0wxnUYqi03fBofldjTNaeD3a56Ab01lEfkijHBHzcJN8+4kNw8LUnFNwbbSsQ4n7iRW8VnLcUschKKgdT3WIIMPgO9udniE3bsBJyg0HSSnRPSljgHxSV6ufrDfbZK52cbwlBjzXKIYXIHnYrDGPT0YKZQOJ4MnORETbMGGolv0fHadYc5s8qGRZY3g8ZwozqJ+L8NiSuiTMMz+LPJKvrLia53wE+FP6j3Q++mnSyQ8pz9X5jqFmxlRMqZAFAZ5ve3urDtnjqjCo0Yfl4C0eT1HUyhBugbj9ydyHDCpzaOWrXZEiIMegu7j9UEzvgZZHtUvJ12xmOyO2lJqEpHjRbZX67ARI3RyIaA/pn/vgH/HbmwXzSKxienIV+Yu49iP9HNgFXvrArsITN0XSUzFO2bcnFjXVS7382513STKlanfGtJPYZdQKFjT7g9BRprrlQU26LtB2bVizSQzohKA4X5ONQ13GhOjvOSqknw/ts6EURWqCgI26xyv1sEa/UHSwQOv9u0gvGWwmPmCqefT2z+pn3u+okzG6ZCfKAOBNelHZST4Z1efUMY8SrXiIAeZE329aJmDIRrXWpcn9PszbZBmC6rf/I8kgOF6qaAk7e8d5w+1ysdfn2PX7yaZ9jVGnz09D/dvC/ATu79jlTfTUMOk5DQPFaguT+iH49+u22SxS1rGXsEJ0R5kEPGFNLnfhzKgMbFY5Y4djSrNbh3POdnRzEZGTWpdzFcs6Mi3tvhFzG+cB8iTK/U2DxO++ZC0g/FhBB3qICeuNt9Tw9Lo271zYwQAE9KYKiGuqH26RBQ8dvb7GIc7tG0wOAtukwDwV0jUIlo5tI/LKPBsBVJtx/O7XMR7C2G6dfNsc2U4uYkinkVyGISwIlsrh6aqJqQJRZXPSDOzEIcX0tE40bp83z7QJTj0sJ4qf80JZhTv7C1AxUL2lfnwlaQCzFT9H1Mnr1LPJEKzNQcEng2ZAowA4YGqa11np5hLxVx3f6hvFpzzEAXta4CfqOzSL7pa8o21RJ/6/a6nZi1zaF1solLM5JfXjfoB4i/xKMDEalwkzIqJqj+u09pTLysf+Rp1tm6L8GfI8uLYn6wdVz0s81xOMrs/q+YzoTXFMs6WHWEt3UbZrIQehoqQYQM7vxrI9acDINFlf2NRRN2FflQMrLsQChvtIZ5T4eJIgCHQd/P6CQ17jdp5A1uX7fVnlGoIeBSjMNeXtf/eCT1BQd5+L3yj2JgnCU5ZuMBhFNzakvEp1YIejLFy02N4P/SyDXh+H0JRCVMTt/Gjn94A6BWPlVg65dkLtCjXm0BgFbiwU4bGmEUV0RcJ1/SwXhXWs2ddUDPDHQ/5omgUfWZafuq/ETYQ+BPRkMNWG6aVe8fJARV+OVgWaEifO1CC21+Gc6IoO8QJ6B8thmsmTTEiX8P3iJf2hRViYApLmzn9yu63weE7G33xo6JspNYTZCLo3HpRWMbGwP6xrzv6r+jwewJcRWDs9JKvJ0ciYW+cGLbOhp4Zf5QfaTLkHnQXnjJSP9wMS66dc0QT3fQNiasmLIUrk36DvGnIwqIt7FpdzpNiIhsSvEX9lsji5FjnBwkAGTDfJTJO5r5yHoTBWUdNa4esFTGd+QBWCPYvC86X3o0lqs18rLEehpz2UffPWAtr4hvh0dSGooxvNdmLszMkS44NY/ve1PJS6Jx903QW5Nf4WNvsVaZP9CARFtqUE2aQrpyITi5B1mI3bybhwwfeY1ASIznlFJs0eJ04UqY5+qmhX2whUBEBTaJtNJvBmu6mpKpgXpQ29+MKFmv8MUwOBmGyy9DwJAMGW5KHPio8Fm3dTJtAqryJio6fQWzFSR+Ou+oT6n/SWwcERlB9cC1shVGU7WOTG1bNulXfb+/qss9F7dsq1/QRMbfsoGLJXxUtlaAJx1KEyo9kTzuFeCKvViasokWNhJueFE9R9hVE32TA//J7R0Z/jztU6hTwktwo29shCg2qu7IcwpJwKK6fqvq9HDmI3mr2/dpOtMrGmnvZBweMS2FRcGt2yTtKfapHU1t2GblAycUAhPobTNQicgkYIazjjPCUguEQrbvBIwi3XsnqvNN4f1VqPN7VMpE1iIx4OKGXdBcicHhJJ2QrKeRJ1thRcdiS4Ax+ig3imefBmcpO27TnNhvqKJoqfz6SYfjmmCXw9qS+Cew2/nYjBULU8AeZLpZt+S6O+YLaFbsyyl9SEKSFn0mA92gxii9BFfX6Vlb/zHaUPV2g2zoLcCoAAEUJO4KRM4TAMPVRXZw/jKargpQpI2pEMrzC3S8BgMn5X+acJ4oly5Rh3mN32xOv9ShPMUdYbsG10XuUJghhUjm1S4/UOTxnvxcONCFzyEEjK09OqPNHQGT070J40pYcAtwUGV0zcvd5kK2Js3HgB394raMZhD9ZSI1dnybIOLg5pMP8Vijflu5MIZXiF7Db3KHt0d6fGjlqskoUBPzyI7xUF3Qh8cfa3FtGplX1OkMXlsFbIncUbVzs576z6Scc2W9+e6Qe3uSTc+CQCArRnHFL/Oaci7uPX0WEmyRgzxagN9zvFGvYlxNLKpU5yNyjspUM8UFsVHe9wks3Eu6228qb0FKedh9EHJnupxT20fXrhoc82m4lpiWhjJCjRcRZLWU3Hb6Sn8F5jQsfRMmlgIWbYRjlJW3F3mlHXit60bSnoeS7uAQ/n3CuFvXmIcahMxVy9WmwWh3hNQWSTsALquzjxtsKga+YBUV8J9B5J2+rXxpoL/WLIMDeGFoxRGzlCmFkr6fMetteIl7USIjBmSr66OBxByPi8AABrq3Cw3cADnISHQ94bkJNhwD7yLgSMoSrzH9Wj2nr4T2H7ZsWy1F5qC1GTv1aDjAQtfGpqU9kt3s35v63n4o+VC+xegpkxTICXEEzsNKGX8nwjVmcjYXyfRgJuvJChHbaF2fnLedLru/ZXwc4nRz3mb2U/3XRwdBskQbtufegrKTVzBk/DHTbFgceLat2RWLMhFUv+EbE4uW/28mmuEZVI7TDYXGUb6haAnaZtSy8VIsTJzJ2V59gu8osc+wwrt9Rvbzs+H8Kj34HvU6URBsnxca737dEWOQ50CyldI81kkWYC7H3dzf3rR/6Jw4+xXryU3/83P663gguXXn5YZ7xn8UwJ0bfkUUGmygaxY3XeW/vZCRmGmpQUfjViX+UCtkkBbMIriZmEyN8uqxXPBvu6PIkT+S038MKic/MHIiQF1dOfMOIEQkErl+tEqDMEc1fMVNxxkKdqjQYMov+koG7XkE8xHTVZywwUBq4CyLW4KAkxxLvrYs8wP/BoHZdBR8cd2h0zcA/TWqZnKrMPTuSmCZi1M8Ikv1yBihT6olKxD+InCWj7qe3ReXa3crnHDdKKm82YUIORveDjCC07ab7yvl5r/miA+WoHebP8HbhY/O8O5yyiJE7pGExSgWuopdAKbFkMjQ8tPhXaKXIu/Sh5l9n+AzzukiS+Szg5O2Fr4p4jqKzdjIw6I06q2yzdsNjeDBYhKhTtHlcq0usHisJnPgxowDJqafU2FTvlZlrdKXTRCsxUlbaWabzMCsT0RCZ5i+/hvb5fPp3/2Ifb2aqMFQjy6GTWCykML4CW7clczl95qZdRMo/2lpixGxP4G61G/0UYRW+5CMvZmU0O84C/xVcwoXYQEEVa50UcwGzqX86HAAW4Qq+wrRbAyb7IG1J+PUYmdOSvJDGs8ltNGm/V9xc8cqdb7vJflRrFlBeqeMUGDGi1j2XtBEGPIpdJhdqBcTmnMN9nd7MqG3gd0kKdQ7e/8AGbp+TGAS+XX9mFjI5+KFrceMEQp5wOaa8+kAf1TlcOsU9M263qaiL97l29qBfN5/CmczNf/NWfZoQqFawnd7bvAd3cb/j7HijjLlncAMgQvF3dDZN/uH5g4ei++Z/W2uFUzL2ILcfBU604mdy0B2mIpHemyhe+kcx8hsDOV/x1LbBIOSfZ+IFNCMvCVgfGVrha+/TKuXujbEKmFMiuDDW7Y3QPNZzt7YaWJ+DmpYbuuhwGnLaRGb3PeKcREnPn9kd/pKVTaPgo/q6fktJiOOQEi8GgLYjFm/9vh+akacf1+G6SffhuojOxDWZ+fOb5EL028x9JuHIRLCzzU3vHqXXE3ed7oa5rs97/osL7MYaIaGQUeqyiTggYlHvpBAmp59DyayOpug+LUNN9r4n4hPt+BtT7ke8QzPtvohv8sBHJueX7CardkqoND9ZY7zxRvsiKcHlTvC0V1kYHn0AegAAADlGdOupfeGQv07TxWq8Rd8BTx7IC3N8m1PWuCJA7pZ06bGxJQZJWXGURsunuFazl9u2P98ZTtmD5MRyyUad5EotcODJrLwN754/O08xuxXsPbgzsr+TimvvGD9a+L4lAH0KLjIQW/l1Wix8ue1FHIZLF4yJaRwV2ZidKcu6EWlFF70I1CGmbHR6C+Xmb5eorWVpiTrNwFM7U2g3rIcEGdzd0U5hbMg3XMmMispfSZ1P6/+f6Sjs73BQdzMehvQZlV5V6Fe7U/aBJ+4JTbw4MAelTI9iSZR2SSol1tK/qHS0YiGduA1Qr7CAgTbeOlvc6PeRhAbnbhfm4hSZ76epHt4vvWWfu+8UWRQm15zKoUeFD8dPFkubPgIa31gwU0ABsvuCcN6vbObteWy3rIIMmL+CaRssJbP19yDe3G4PmW3IPVQ2nFoZtOzb6oq9nLGgh1viYnG+twkhqGgm6EvAODcrulMnnV2NzjaHEEKjip5U4bzBxdB8AvTtswy0dK2dLd+YbxTsazOQDK0ttdTFc7n55bW4ribHgfqehg8Z/66KERZTdpIA5yTrXcnzXQAu9CC0JjJ9oQLgUDtYX1mjhGjHn1+ZcJZyqCMRX3nLlVQmfz1mE+XblZ2VTmmm4CKmNj+CSA8rh2BmwmKxJPG21YgpU7EsSxsN8X9STLkhdgCK/oIG3atMnnRkqa00JG6Zcty0F+m4eOJqkUX0iHDjMOroPy7oNvRkBkVvuwbxpJyKcjrd8fe3iO29AwLpuGL2EFPEmJkU8tCXms1UAsUMTWzF98V8KGNIHHZ1EJcRnNOV3QqG663jHyno7Hwnf/IaMOwu+Dy1GSMFtp0Xra1tcaekG1zcn6PdS3CNkDuhXSJFY9tG73KMnFy8rLdnKEN5xPNWcNwgK41Hf+XvZJgS8ts4fmOy6xfY/vyESnJhX9abJPnnnGD2Hcyl5GwW32boywRI6lwzrou0rh0+wOuJcXvPwWk0wwj2eDz5+gPB/InqNbGlv81/JRZi2UWxNmDRle8Y0jF7e7nOhIYn5TGzk67Z7R0wr6mWSUoSG8xUm1Q/L38ldwhKpZLeB8f3AkHrk/2g4rJpUARYDIBWXXVtBVoG3dzp8Iz8WBhdG/gBu/PHSC3PUp2KBmwGkqWn8JlnxNtb/GgCsC1FSqc3MDY6YqP+JExaVaHYv+IzYavBOq5FhRgX1r+GxO4c88OMqf5DPuhxU7ihAwElUro2NCdRajtW1WGKPKS15mO0wNJtsi9F8LK3ujakegZJm207rhnYy61vhWthD/CKetvx/CfjzfCEBeGnDfTGOYcZMyqOw0pZ1EtLJcZrw4xgFoCPPAVG7ogDgnC0qJ942kMqvxudmdakQWS0M1n0GYAG9s/ShyJzGLcxtaPVlECD9jf/+W9WBLjGDcoA2P/n9OyaWr8PTndWlcUap0hABYno/ad2T1OylOSPvOLZCMCHGCq4/BFATvAysPpSl80egpHNTjgMyxqyP/T7yNJaz0orR05AFF+ugt2hb59C6etTq47BEcHtuHBKnKucPyNEKAIzmYR1DrG9s5uQ1GGrlTHLD15wAAE6AAKMvY2d0u19f5N25VVmurDEcXXoHokZ657X7uLJDzlMgxW3Hr98JOtZqlO1UkIcni4hDpkDtg0LXGaLDz5bNAXbcWEoMwYx8WJamJYzOxPjcpYaZHAin3Q06NBHCno1fUkFl8Qpi1Zy+vSoBKp1E8Qf59xMKMedCYAVCq2lHuhRz5K3As9Ocku7yuUY9on1gjv4e8thrXc9ePMRduC9db1miYeru0Wo1geNMrDIxNxUN9kH+kOSUa8x+BMalAIBKC/24FLBt1hPOBGNZUE6+0B/f4VakonHkGhZhO7QStC4TjYFxzHrneLUtyc2H2oRAgi0JOmWdWfcOnwWhuihx/fPx54G5/mJER5N6o0/ibBEn86qhVlu8UzWnl+Yq9vfjVk1z1HN5U80dh1G0ikfJRnqQWmQ6RlCgVLwuVvDFw8X0r5LEgZYw9rpAyEJBsEK4LBelC9k2Jw4LNSlfoGF+K7ONOYihltqJSbyKC/D/dvYHeJO14yFP/uNhFXdbECgaCysjbmkcYeFOSDNLr+xFnkjDiivhrhlu3pGfS/8knrKLBL/uYnunkxu9vGRHrZKn9qe9gjQ4E6nFwOhUjL1F6qycmJRS1i2xtvNlr98e5hXfohr4bNb26BcmDjDPMRYkzn1zJKQFF07eB0YQsdFLtNYhXewtL4CO6Rpx5s6zj8C0ZNm1n6ANQksT/OUa7JT6cksWqBLNWwvT6k4grAuv+5NJsZlIrr5VDA8Gotn7ta6G6M6DMQfIplCi8ELCc7hIFI53Exm0jnZ2WhmHwy4GeLgCAXeLtDDVXI0KH9JdA1sDyduC8sSIR2rlV6RywoQYQhrYmlreDRFw+gyT05sQ12KHXMwJnVyKmpga5Y99uFjdNh6v3vjVb5g2kpFWkVrqFBqt9XbiRo1FehRqu21zFgZv5Jd0PYvW1b6wtkXbqBObhNM86/3OfELO7MV64jyNnQbNMa8MEcvLvQ4KnjJyLAJZs4LbN9W90Die8RmeyrwPMFVkXJswYbAeZ00zzYz+sm1D9Zx7JmTzp6RSgtbhZqJbbFg+igtsCW5DKgILMuRmectQAXaS7w0AD5ZBpoTvOE6cE1NiMSNb4/OF0NKS7uOF6/+iElYftFNL/9tRoy8rCQHLTXOlNNLtq0u/56U/sSMGUz8uDLE6269CLxIPXtfNcHYu3x34agY9XArRy+T4yBeOoLr/ZteAimESYNk+dlfX0kDnh7fd4qDHSFmysWr9P80+fjFYSfeEWeOKEDtxMNIaNEI7qKo80b8gdYXmHVyWKvLcEx1eTE8dqWvRPysXWlSBngvhbaTgQXBgzeONMaiAPMTXooNPbOH8wi/TTSnqzKSRWaMmc1zGlkFjRCcPhvlQSyMF5fn8JqCoLvX93J1DBZgfJuoo5RKzM33TuWzYmlUdc6cJfSR8aswNY6MXfNs0/R8CCFEZ87yRVmc9SLfRWOjokMDGeWdSNou0NH8na32TCtFM1rpxIwTq42/vxby503qcHgIQMAGelx+1pxQanXoRZ2UU4dwQpDl7TeWdWPlWexkHaBloL1KndXr47Aq3hezqiy9ecPbHig0K85n8UMSzL9WnzLifrmG2OrF2/gXb9hNkJg5Uqj0GfnfuVrkclNHniZEgO7G8Q9vBinmyOw2qPZYC+wQ3kTA8TQtr5HjBcsDf5TOtAICND8M1bDvWIwI93m1ZUxPFzo/rO5xaRRvuhostEAlLg0nzssBchRFnd3t2kzvLThjzI9wQbe6oYXxGV8BJ/66JcRodAXHK77KjzrPnRH2p8BTnndOgtGhv1CtrghxkpW9ieL1GxaeOZay4XOnpr6ul3uBXbieg3Sk8lGUzJE7yIHAjHuxskTcyvUbcQtZUnqMXsZD0CR++e6x0DDHo9osshYtTh+TqGgvS1yTAjfbY2ekGgjg4XvcdYPqGv/3+WNKSEK6NmhfT9INT557L6usCF7h4h7gQIapU750OeWpIJryczjThmsCgExXfQU0N/FTnBtMdmRkC6zsrwVHSg4tssp+f7ewiiteNVtR7AQLJmQ+XsOdcP6dv944gPamgq0adPX35r3jmlKot7xHPt2dUE371AAufWT/nzYRP+nApRuNUtwr+428M4df9vYxB5Ox1OV6Yl+FQIHuVCgDV09TsAQFeGloEFyuvuWwmdAtbfHB8YuGS2Foci53kWnrE+XKXEvMsMAXLKqSMBBjdyk3nPsGTxSiYwykSQSHeony+hk+Lru+8zm1U+Lvh/BCF74J/MW3v60jNwTMymCvuNrTfPzcFP0PDK/8O4XhDD9Ibai+LnKj90dxkflyTp7TZA8uXSFKAIen+ETvOeV4Ob0/pJGNOxvydH67Fx5ss5O5Y2aqf0TmznYHkw6VAAgOqdtYwM6hIHkRyA1DV5WXX/iipKQw2hG1x1y+qG5CcnC/Wsl/zFVSUMoojg+cOg3vol3V6Rzm5Ol//y9dW+7KR0WvqLuhuINFwOwfMpJ5PtU8u1dTlsi0EoO5rnj4Cdz91OuJmLtPi9JzVbIXRwsZ/82z7bkQBmBZpwl7QkqM7UpLBuYwZ85QrXZU5o67Dkhyt9Z0qGY4dMd+ZaJQM++xD1pENNymldI8JrCddBdqTqpdozCMVmKlTYUTF6JjmEqjwfWxK2WRZqjzxMQ1vR6TK/U1B8h3NXSVj1iSHnQMC5myR2jOw5xOh1oGk7w7+jYJwgGdyZWI3AjhMZpNcOiShRgW4BFtIS94izzrpQt8jkdVWwRdKJGgTSmOR4Bhw3N9ZIIdxkjxIDoOUJj2rTpkgOkMmGYrOzXiInwiQi4HET1uofORsb7PGGU5hLCCFtmKYoYIxa/qiErNGDbOjbbkHxohQTXN/OoO7BJX/Je0ix5Kfj6yhlz4GRrSDiNb0l8U7v1oYqfx+RBUT0lq8brKQJjPYS/kzn/1R97GEIZQmyDt8nBn0+wzelZe6oAUmGRcZkLM0lnr9h3y0wUf9YRl+AS6h1e5TzMNBcLFC06EcbjoJdwws9Lx4GWoLZDwb1E7Gbd1CjTXrS8ns5H9XcD7lt+/sDohVjtKeMKZnRjRc/zM7keUuIaE4+TiImMRtC8s4uku/Yy7YhKKhiD+Y2qBZaI9QH956oTtm/spYX2sMFwZCQqRxT9JxbwlQz/A0NMAGlMkynxwzBX879vZAAk97wQqOOpsCn3oWpSmtI4CJsKgP4ZHEDAJW3+/H/1Z6Krpp5xg7qyyKBk/WpdS754gs7o+lEGS8Zhofg85xz5TxpnJ4n2vDVSqNlK4Fqe94dAogUth1Q1pcBmuUlAyUXXyeDoBb2VBjQ1OMlRPA6zB2VMukMXMWt9+Ka3gG22WvD4de7+8sIQMIbqTbIpGreKuyIq/31oDCeSc/CejY9xWQQF3wTtCob+MAgFn3OM34Lvo713NAyX/ZEi5d2Mk0JRH8XxXsPKdyJcJ5n9mTUr9wMfsaqS/Uskyj1BsvF0md/950CEdCtDg9HiJXybjKsGLFuod+JCfmwPLOnI5Nl+GrD00csvNM221d9+wAi+u0JEuocSBG1l9rd8DwsQmKVtsY7nNyZFDp1luWnxFGsmwVn0gDDl+3X0VVkmVw88rd+L4S09SjEwSVFQHXztvY5RA517Dxrn39nTi3zRTykGC0LsC1TXEd6YNoAcyI6pOjjzwFLVDJ0ZDNx7H6MfkAKVqC5jA1WQVWeGqnVdWCRS4NvQJilTvLHier4V++qF835XCjCy5/794koVIIQSYICXDhyzdtXLX88cB6Pn9nJ9DTvuFt0hzL9NsaU5v/Sjr+zk7A/G6KVPqYVfU+Wv42HiCm211EF1LlcrWwLzWfJv1pCgXNkh2IalqoeA3A3qUULxqaOzfNWNy94pWC6yvWH7N6aDeytOmbrmMKY3s+QxfhF4vcp9NhZGclfWk+U6LC6d9CLSW5es265FN/Ua6v9eys1NDMdnFDGFgoTFGY0WUfuG7SThn0My0pT/0GtE5jwDMH7M8ytK9GuWlrq5JsuqvTxwmlFU9l+VesbDGrFmx/nnCZykxr/10aI5JyjtFQutuo6V8Ami3UF/G96LY01xjF4sghHQXrquHgke5p+Wmjq1CsDJLUHDMtmTJMwknbDLhVREhWM5eivP9uTNnR2NykSSmUu5BZiwGGl3ealIaWtssf0xIFR5NF+yaxYpX8D1gsnWSqfVXuJ2b4YQrZe8m7MQf/5oan5mFRVxGsO37VM1lec3qrobrG5c3qfqM+aQjbYNw+Pwjm6WMLga4eZW0Hsq/98iHx79ou4PZWo1fXNQB6RS9Hz4GjJR/E0p+hv/KszGXn8e8giuxoMZUObTtVs1DNKSOoVHgT8jFdYaIxiDsa69z2gfQo2U4+IcJtxy/PaBe7Ny0QInbTKYAX75ZcWXJ5h3bw4VRYFuCqmz6FMLIYnMForZLii9vp4nIqSfk7I+rY/M9blQN+4j9fSIb+s6mixlG7oaXQzMDhqz2TQ7kD6vzYUsuoQ+uK59odIC/8kTO0pivi7/OpmBdpGCGHaz0emW2tMFx6vswL7fUh0RSIlqcaJHKmHozdUnHXkHkG8G2REWbKl2ZWCjQZNOwNOVEcIJ9bUhsROqjmyRoiprHSDvMs3E4ZdYfC0meunOTDf0dvFAuvMQrfXTdUSNvBaTe/ryqYW2Gl8DljQHeqaK1yIL6vquy+DtEc70QP0BF5JHI0lhJ3eg/0r4l0FbhK0RoN7vFkB6Z0tJb7xltMEu6ZX9NSbmoddj8BscrqrbgAfheHw9AO2AHQNE0GT9Elv78usktKwG0fc8lkWRUmq6hTkEsWOhzOqVEz06Hjf/x5wXVNZDZMvwaNVxJ4gevQDQ9AVkLwKcH3mZ7ICKN56Snwfarv598XHKVt85v0n91+PNuibTcUmQlrmpIQtK+qIBBQfgq6xXqRIpJLky/SMM9rGgy5RddZvXjfFA57L2463GFdwOHsL4Gs2hUe7ZsS0BXCG31KlbnKLdOi6afHgtXMboW9urwlf3yvG/MdkraIuw+yoqOVAq35l18TrdVpEmtMlmFU7rGROhwc9l5XTSYFJ9M/CXOk/uXggEabAXKKGNix15UaPiTY75yY9T7tTJA3YDMVsACuQQKz0i/UZlMKE3cXxCp2R0E/g4gz/AO55S+5rDoW+oOEgZiNp7tk3nGnEiMsvRry8nQqZ8K9fJthLvipnGC5Sq5hBtPHsLDJwQXNp0nhhjmpEWNX9fqROBYlAjXkwlcZS/OrNJFHA1Y7JGobC+DCn4Vk8BdKaDksSPbHtRFo/VKJnF8rEPOPoTMY6kjW6D8DxxxG4waBHjwCHCX21G9hhyFaAfaRJu9yBQ5XJIzIDXupxBKOUtLIUtu8xmU23qs7AcSwzQ4QdbKOmySlexWjGlijzmAmkOBSXRctBISBPP3LguOZlAz0pNLYQgtsOEFZ4Sas1flpn92AAxP+JM7pbxS/piZa9Mp+QKiFhnSXEdOFquAJ5m2bdIZCtC6ZV9GTU6sRKD25z277yUZFJN7V438yoyhA9ZXVdMVGFXP3YT08TYZIPNgbIulX+MZcfOF4sB+cS3kso0OwLkWS7TwkzenaXyg6WtUqbr86k3ZZAKwc7xz8Ck6sDk3/ezmIExebQ/i9mMau0Hl3VIpGHb6th9yhAoUzEenOYt8u5d1ZjBX1cFj70OmAy13Dtcg2QtfBuZT7dX/ZMxw3JwjyjQyZ1ycuobhnHEZUyRwJ+hC0CygyNXF6eR+YCWFaD6Djv1Dz2DSyMa6Ruj1b9EDBBygFcf/E/MuIvqm4ME+8rCzY9ugZX9Mm5zegXtSrLg5WG1boaU6KmJW5DZKPXlzpmT6w/RR9oH6HTrrrA5wQUIrAfhdJxi7BAA5Qrf7A1zeBCzGWouPG2Wg9OgSAAjDs+NQa9n68OqIM7k49WN73nLtBMdc+iIE12ISzmkvkmo6Mtgt1ikxppfGFp2H2J2itWAmRympCNx1pK9pr401FaFoB3RILi82nYwoqZa38lAgtbQntEz2T4L18SIab8UNOfLlj3dfgULXvLQXjtCEJpz5sUo1eeBgU30yTYZi8+aScc7FZVh1OwI/YnnKKrkimbEL2YdFsoX0z4t2Q8yvNqURx36RXEKSJsa+Ib7HuebgvHT4LK1+VK1jP2lyt5KH2bnSkCJyHwJFE+SdAuZOnGL+yf4AqAyD6AqVnKDeQUd9ZQvhdHDVHT4EvVZYNjyXWaQedlvpelh5JOyh0+cbGLz16YORJ/ljJxBD4+l4D8QplDDJtUMNZEcMwUgPmp5E7GRr4jxDgVfwzeqpCC10ggCJeJ2yPagsZoZV6FZ43I0nj7x/fTZNVX+2P+VFzJ6GYBI2jwzyPrnIWPFRAKy8xALq3sJ7BGKGy+2VuH6xphoe4OLGjI4eZNqqtuJXWuSGEOs4pOB+sUFZrUpOeNl/ShXIyDktSl8x9k9NOJzM33c3EYbUVbqfENASY+ho1i14jGl45dsBor1At+Qy169bKf918XPlH6Z8SbXNpr8PkbNgYhZWkPBd8lcBZ3kR5xgv3r2y+Nt+sdLyAGKlTIk3EbFdIwoT97c7Qh8yQwK11LjfSvvGQFAvZh7NxzNZ2wJg3M+RloiOdnzuZvXiE3ffhBQj2HEBvCQTkvK5kLwDptIDv31J8NALk41Rdc2dg/qJCMJTmycGsdmRU7Avp+y4oxshfOQGvrl2SAyqCVidBZF7Hvdm8Mtfz0ixicPZcjKgL4umKqk/uh3FwAffNzzm6rG6NjeRbDTV+C8JzG6GFZrEI+OG+mbI9T9EDemLflLoFIVA53J2nB6i7YAoxgy4hGexBbPFti1rHbxYjB9j5aNX9IFNjb8N4R2gL1s0nLv9ONSvKrqnmB5znhwX/UAEOl0sifF6QT3eHJrmszylXW8zxg/xdQmsdKeUUxKJSQI0KblOYN3BZanuN9+WoBzBpdmtmWbDevzYzHQEsOYnllAoF82eP3Sw3IKHkOCCEt2E6aWh/DQl6HKAdhx42ibRVpLIPYsZAZDUCs0a/EleCpnklcC95N8UZ5stSUDs/YocxYVKOgZxGXWDj49VCcicwrEYwiGO9Kkxfw+No2ANLbUIfcQ8oVd0q9/qEBCycRHcBTBylivwQ9MslxjtZ/XZHsMv4ypyKPyD9WOjcUii1RQ4Sr033zD/lAamMXNBSBF6P+SbY6MfF62WwvLbe7a8wP53//v0UzvvucgZmNficQ8/rWLkBLGKByYcqHTmMxODNqU7Dc9+9HnEwf03Bn5EVcQxHuOIGksXzZ7xu0NyBMlVdnmuAe6x4DNrehc4Vzg5QZxL0xV0pYPAwIujBMYMf2JcHNLWD9CjyK7pYe6UkJ6Pku1Jt0NH/yieOhplBOvyCXawMou5f4H/z9XQB/V21RbEGWVcI03Q21He3XERkeuQNLsoauVfdR7mzhrqu5WdKlUBxlfvO9qx7pdgB3I9CIvFPDwAAAHWXDKALEt2T2UOLwlAA8LJQYkW7aUrq9fgafUxJn0hnA4YXz6OzkxGQ1la8m0bWZ3HW3O9bhvT3A3OmZ21OoNHZ6yk+df6gqYNu4gB+dtNPW8VQIiroSV7Xm9ZkTGFqqpRzKcOgW63X63ew14Y2YXJbVoS//ojFSg42vHk9oA0wUWYpLCBZDWo1P0hG8eUA48yxzhn4oQwr4MGW05FbPqC5z/J1lbeEQSpEzseq1RO/hMDEmqheb5OJ1MCducpxT6AOMeSF94guuG/EtpFBEb60ymSjAumiuaJrAaQNiO0OE+jdXZBDVhK92HpDEr1FFLfgYTsCm+9JafxvQTFjhkgvs9PfmzPD6VSrN83QS/Azc7uZhzvV/8iNzbZQnUTzIYFiuEwwOxlJb56Gf33VD/OLveyRviAjtpbpsVO79zzc5989jZPJWxWm58/Jd9rx+Z/SWddXEoSGC0n67g2TOHS0PZZuwlfLIhUkUARIPU+CyeU+wYrztsgI1xbyQeEhX0jIHvFhDHGpx7P6Ci3L9JHOJwnmZV8e1QDOuOYd0oax+v8H8kdIKqy2SN2gsJAmsyJRbWzchMa/Ljhy2K7XE+baXJSoo38Fct8SpNOHV1BFUZuPIesIQzEpgU7fMlqfYwaThLXRx5rg/3XcETvpq44oB7m8Gj0vZ9pD27tpelv4AwjHJJrvt/vEvw++SFF82uEiLnt78pHjNODsWdkjDRs9P8JVJEQ3lUD+Tt4KJogyn4CFgTxQbk2jJSc2mmPVpFU0eOEx5J5yFqj4JTJa10+yLLQFj/usWPsav8M1H2SDx2Inm/a3apmH7fNmE7fUQd12LNZMMGajZJ+dGLzK4zzaXLvSOc4V3xB10q09lbvyWOFUxt3kNAPpkNd36oVGCOuoHUgNT2EURZ8eSv0R8cm1fRXrrzB+KGxXB//WJyn+GehyZ8QpjrDJtbYIq9C7jPbaHt42JSl+zTf73ht1cx0MCS1zrfDs1Zzgr6R7fPc4KZo4oU7LfusFpZhArZPlJgA8pZBlO1ZuHgX1m7na51vAOKNz0H63IJvvoe0DqIxzF2YvQPdHsQGdcmvoNBmVn246J3N+QpM3a+18p1lRbDSMEdwizQJ8alQkzrQ4doeEigexSxPRa1/cL9pA/TNPPfO8MWOmFi/hXJ/yQ/9K6XSofXZbCrMxRWMxRU2u0LitstDIQvyit5tcLHnt/1OTU4exNtsfEjl4gjGZGvAipwZMFPM+TZm67LgECdbn2OUg5QfQKwhZX91ztDHfIW9nI4/vaOHHFqKJX8lCeR2QPqiiTMdOIe2WTo26l3v0fJUmgEJS3WDLgZXMhQ3E4Ktk3fZQUK17vJfljATAHxETgBegMrfZGexOsuLagk0vg/KzIYYqWzIkPCOFRLnDFcf1EPCbe3YyIDWhB9Z0tC4OxcJu+YRZUdlP49EKly529Tpfk3/FxWYtnYDd6R9UAAZ+OKLNkb7IzHAwmsGgsCbzz3YNqxELyIMvH2hJIfv6Aqw9uWuU5fDXlM1Py2BwfnX12M07qdyiFuZB4Q4KF2JxahHIraK0sJzUSI2T+5pW1+1mo8pgQn56aaR77LaYUdbXqg33v5p/dfGwgKEwKtebR9m6z2VQeLZfCQ0hRJiXRbKNDmUlEtWWvYo/4w502phDtsFTwJBeeDsUjwBxSYkJ1bR+DGZqC68106Pc79KDFzhrOeVHt7PLiVOu+bxFNHn5bItLICcfmJ6SasFhUJ1GzjFOFpnrhNelSi4HYIHg2zI/90mYSYk62w9bGMc9Ta1A6LcPOYs7GECDdCFQuuEwAKwA9LHcj8R0XBqXv8yKqrnXRcCx2F+mVBUx7Y2ryo3SDmy7Xr/1lcNj+Ss2ynluS01Kh9b1eaNeicQqmaequ2D2Unzl8WbtU9TteGfOrXp4Uko/pJoCaY7McTzvazNX4yMcE45e87wsjmTdT+DL3C9yWUX6vUiWJibIrFBtJgTuscuQ/3xv6+FivRmBtzBmjocMrnnfT4YC8iQntZUtkMtAJyimeKRVqTfFSaBEIJcDCreeQNRutPjIz7mERM2lhEpswTFw+F4tKp/igtrdkyYJOJtUNeWW4imnPWTldJkh+8UC4T5kW7eB1dXref17dDezmo7mTTFVrFCFiwgokMpv0WCa/LIbR7fN15zkKlrX3QcR6tI6rOAJYHNO+CbuhPFGZTFcz9s5y7QjY71utyn+sv7AWW6ddnb6TTtcNHiWQ5sX9ZYFkTxn2mMrOEHxxY2ij9xsxnQ6xdnbmg15+HoBj9Z1q3n0SuK+Dm4KUxsPs0+Vm8Eor70v0WVJebPJTzyq4DTCgm2DRIUVlTj1s/nCZbYxJc4OtGvoAS8zHXqrXlFFjFqCFQGx/G8wj+KYFyPA/c7inEe5c8bpTz2zojyq7++PNifUulQqwSiQ7Sjju6xzxYtYOfN5i6BvIsckIV5qA5UOintZdp/c1U52oiUNkTda051rn83AGCPsSc6ni2CTuXqZdYRKXbOMsII2PbNqOmjtkJXcw/Pw07eMKLyJdfekjKi3llurFh5sXUj9ldmKF9z50O87JHeDyO6TCKjels15T6P3Ef1nUA7+q7kseTCUzdbXOtOnMdv9ZtKLyZ7gw20F6VeedW949yiXh1lnXVfhVyFIw43kVVpbHZveW3leZIuUu5WCAxuWe8E/IjUgltpFhsKyCeVXT4UGqSsoto6P0DCJs74t1dpC9/i3v5NKYdn6GiJUhrQACJIw31H+hjQKRozvvu7WoKHBHmQsThN2c8o9msz+5DWRjaTEhOT+wTMoS2YIqbWsdcXKJPZ3Gq4mdJlQ9zaoIOod/rBh8lv11GH0kcRf8dg6NioMA97LnheGNguacbEFFDNe3a06F8c53Txa5uEdK/JMxqAHTQM1/0CmID5kKpkrWNytdc/1FspO1rr4SIKWdPxBOXBqgaU5ndWCJ2ikZB3QRGSRsvW6KVdYrGVl9zI5BkPcwhyV995KGLTAF6KkZktzjSte3wOhxmIdURLe8ceeo/Gpll/w0mUApU2/TdBXXsPVfkch+om+4NCMWKoWmX2Wu7ycSk3X9SlGpbWbt2GwwENG/dmaDu/JYTq2HNldUnMaPPULX6F7MZKSnZXMAZ9V/n585OueZ6A3+64e8JGmUk8BxeP5o4N6/tgAik5kc3GXuJyuXBu8tnjfHbNUU6McKZCXgdAoU8oET6pdEvFpzTTh44Lnvym5+F/2CxABPLhQNeUR8bcfJJD7qKIxUfMgVYcPhBnHbdU72XeLPki+xFTwuNsVgei2wDRfD/yxvdA4sX8/vzI/o6tqXbsZgV0b4V1hiZMRKy7vm8KdyA7p3/J6vLR/qhmJ7yzUC5Dkplna9Hmj2qYcW5a6xe+YeEa6Gd+c0ZMQCR6Hw07zF9wLlTvpaVeOHR0tm7bUzECJ5i/TtB0lSKvaiFT5mlwPWvsGd1eT14sbTRbjkwHPiVMzxWr0eCKzK2nMWER9dJYYLNDIeDlVyH7oxr+vyxs//Zi9h89OwudW7WZraK7peQ2FqzX2DOBW8fTHhpNvnjW0Q4pvY7738LpRGzKIW/IlkSvmqdibLHgwOhykMlMflmj9FwwFGLtep5ciFjY7tixkw05j2LtQMEIFnRhCPvl9a/Li1uDBR6Dz0nVqzGZTSr8+0r0VfwiAE+YpFSdlfgZc4y6rrYiytiHB8cgtUIuJM75EC3ktMIlJxGylYzROhQa6IuE6Sc78ZXCH87QSnR8Y9BBb2RZxfrMACdoYBO2LPBerWa0AlFzTHxLgm/irbFm2xWKUsxTxvYKj4ilGusF4OFCg2Shy4USa8Tne8fMVEwZzxox7hC93QVNcbvBk/LDqA+zch88u9desCqe+thh11/0xJAoieQlEeiGLO/xHAATs1mHdPdZ8xi5y0M+ff8pAphIzEJ6jqk3Rj282Cane75h/cEIlLWs4SVf9RBJyKNNFx/Jy1Z5O7wUyMcHS1mFHaB1h2Zgqja3qIAFO4lnJES1E4XD3yrAxZDyJLPf+usSE3gZVxKRaMg4HVI+E2LC9Ri3HNdYBFKcGHPZKdkWLwLiEzYweUbMebCIFTRa9n3/QUVbE4HOYzkdzNyGmpa/wB7XY5OWE2z6cJUdb9wKYdYeQCcbW+9IsAKIZIxZtKELHAoS0vB3Vq0RW8tW9ItvWn+naXSbRz8sMgiwlux2N27/NBraSVf0AwQC9gRcwiQGnBDVzgIpgDu4qrddTluR5bQUpF40QbpZEVc6qxROUmPJjnqyrYGRw6ndYxg8+Qu0aw7bX55gaFVt4OsZjebwn1Bh9MIQ3WG7zi36pDEYL+P5u5oB9HSLvRXOxL1NdgP+nhlgZH7QhohjupUyyUIEZFtgPwRe8qcoGIy38AYhIpkpFk5U7TwIt83gGfd9jEzE5kX/WOr7EcHRHHA/X7qGHaZsZkfFiEvtcOSYdvUUCfnATe7cx7+NpQtIsOH/QtMr+47C9/MlidmKztHFGnx9A7W3+wdsDJtXoGkSsBrzybJnnZFNUyb/QZMAPV4OKOuPdlEfs7YnyugBBYcLbl8igvRACJVLdyZF6UybzAgnw5XqYiUZ/K/O+NpUqv+5ECeMm9NqTf1Oh3lnaOdbJKNc8qdeswow8sp0GRN9asDw6Kd7swdczYKhbtMKrehMRFTncmSwfWVI+siHsvxSfh7/Mt4PA1YV4YRzhZP4+Xuieu1jw2ns0tkWPC60EC0hYpIybVO/YQuDnCzy6GyDDklJlcAyOrIAmnbh9L5F1gDLbpkPT66nKi+UaGjgLn7q4HSUADcPg+u54hPM6Eyv5eY62e3bV4nTwqvrCoyyCDjxHihhWH1eirxEVc8RKuuKNjWaKtGtM04l2QwPrU9blLZOvgxZ74OQauM/7L1WXY2rbhCfiKSODzTpzSEnYl4hX2KsiwgkVoDhpUFUPFgcsiAcEJeWkZaBTx2thFKdpusWpkK/UjXh/ah+bDO4WjqDUHp4YE+vkqel479BdyZ9C47xmWcKOarAXadnzCiMSjnlNCzX9JMtpDqnHhJQfa/BcjRarD/fPMrP2X/eSoqSvGn4KFviK1A3PL86uBgt+i+OmYHJX6H3ObqwIX1LRm3WFBjBFe8Li+KbcB+S+nOpxRad0Eeyrd3a5q5UuKPWapBh2JUkdpqEn47uOlAyGmp09nGsh7dPO3EwLXyYB1iJMBxY0uaeUmwNnOWpY/2I3gpzuGE+xIZTEhvqQz2/F/AXNGU1cNoEMtEfe3ZnGikYtEmy5+q84Uw+iCtDdR5HydY52L/Moaal0HAKLG/N6TJSk8KeaaUpVV7rthMxjRm7HwxQE2bT3eIqlgr2U31qavBvNbslkET16CRXV3Zr2JmmgnS3PGoTqqNqgrhnCvR7EY425JCP6SQU3ALKDFBANzWPR0I3U3u22ZmpV+kieAv6ceAqu0hoeqwNo7OIla+Z+Mbh2IZiHFiFtkry43CBjsELZP2CxYsxyeFotViyp6vusWLDJ4cI6+oZJBZGAH5XRlctlrfHr8LvS7Dlx1abDr+KVjsaBzMzB3e5/d/ULhgpTQYBGkZlTbpo8yG60nsxlUh3oYZOyvL4TDjbI7/UDhCfNHtcQXYbcZ4bMnFSYGSMDcxkluRISn6quxDPVNh8WmfZ+Qmuf3LTWZP7JYVRBP3aEDBlpP4NMKzciaRnIzb+Sfio4jpiYs+30zJhJNd+s7EOSfN4hlqYvDLhDGw76hWcQurZXz1MXerJWtG/XZWz5IEdoKPVJEb/r1MB9Qh52OobX/3bEex2RHA5qUdNHNrpn7957ShgJWRqJ1E9kNNqpVgCk4+1qrKM3g8ykxJg/z7VIlppxcBJgsVdSt1dP0LMWjWC/Largc2zfOaL0XeEGazqPKKMpmlcKIIXuMXuHN2SUuvxtpCcQY8ABJH0AAArLwAlk/+j/bwNOb7djhqMuTPzvZuSFUAottE6SzfPsrONZiEqOzanERoNU7/psW5qtBgblDyDZjinNuVsp+8TvgxjZwUOhg3zIm/e/azSTVTbKKeSXJOmiYW9ol9lugoNCfEOrDVSUlZfrqnIOTgcyYvRueB5UkiHO/q/f2GIiCmjxkNCTxjQpny0hFgqkBOciK+VMw4rDgnccN3aG+V1vfsZz2T722ZGhudwOD0IJyVoT+VH7Nkn28YV1ID7FlJ6lal9Crl+stw0gstw68h1wObURQFKnM0aQlxq5m4QS9GBW4tgf0VQ9DX5ViZwU2J7v6RJ3PbjuJETXjHKZYcigFaEOj+epyUalze1PWGl8xMqRUt16mH5bvdI0lpRrsNMuOEA9Hz4WIu1/RfHoUwiq3PaqAF032WYn9HRVG2Xr58eKor1yTn4hNd7LTD2pIkExPZmNQ9iAuCmlHDjUD+0XRKLpelPUzq1Oij3BlHWpTc7OAjJnIOGTvX5CmrweccOAfGl5ALxKgT5uSwnLsc879kLkS8Oqx/91aai7DYwdP4za1qbsLPI/MQrfDndOz/nBig3M81qw3263NPQHEfCvSeajzF6VySGETKQZW01xWQ/pPA7LhKflsBLhxKwuqTcK7aypxRF8NTauStloDh+ljmDbl1AMl4nuvr22X9y+dfPYtkhlkiipPjHvuuIaLNMBkw4ai4LXpis/UxBOnS1o8qZr1puZ1vL7QUOWhorrIs6okXWdkXyh6IveocVfAjAjKIIwVDH441OPL5CJnBDfLt1nqiQBVl1qckDe0GMo8iEwhR6/dXZbN6WzDeJQhIjejyAfJ2SMyYj8AYDJcvGuSJeA6vd5f0TevV3ErKWFg8DM4Sv+plS6sEnO239WJWhBE/FlXCfpXAutxWyqTukKL7ZTJX5CtgS33MQV+cDqmisfFqZ4tVADEM3PMhijMJb9a0FnBrDomzPzek2VqIfFgI/XrgP30jZHvtxruC0NX4pMBhZSoSihCkur1CTbb6dw9h9d6ioYaunx7Vwr4QZ/Ujo0tLHi29/r1FE6T4ZDv30lqU64DLIeMg+AH4mDqEitOjsqEGpxqRhOnIJyVtqak2C2rIxeym6Io3k5I8k7ckn3fgAW/9suFzzGKqxVEEjggstXodYQuQ8Bi8fHYGqSEwF5ZDTLgedR0ehelQ2oLiATrdhnCfwRm6tqNgPCP882a92+67D9SwUJix8AmpKD5rJ1SUx4sV7QWaJrTwDPggyH87zio8Tel38F1HGNXAGJNma07y8Az46hEldYTT1Z5NUKaJSLspoFs9jy+lryCvwmXt9GmNJHwWidKK7tC3+oTbCKqF/cOeRZDdmG1mkju8JIlqa8Am8MmiwXVzRykQMrfFR/5OYfa/Nj6JRvPKTL7V8310Ra24dN0wNXmJObrDnDmjU/TBJiCtIHefvlz2GRbjC/amArXqNefl3qNwfbd1Ce9eA//iNzLf0bflmkQAOaB4gViGu6LCnJ6rXmt76dp8Wrb+jzDVuP7LOeMje4vEGBgGq+WH3iKXlVcdmEV0FMYMV51tpUU0oFs7qdrKBscpjl6s6jiSf0L6Pkp9sAFRAmCPqbLxY1J2ZKBhPB7mtOHdxY9XQ+vSljN6KN+1C/3rxtGL+NIbfr3ymUOKzub9y0ZxTsq4Kw4forW2pHj1c1mIRwBamsKRiIqffxF+Guw1SfMlST9EPfAWwZYcO+YO2vTS6LXWG2oT54MBN9Eq4vJA440purw9Fdkpl29PXH4Bn/ZU7NjVnny+g27tn2tbN6GQ1fFxe0/CnUB3QkqAOrinZVrsnQSMpEXLHw1MPboKqXbRbdFpxSSWtKmQCqYvFuZ4t5DuVAt3NvF86Y7aSNtniTu+Zx1pYsVyGzYCl+tzeXfe9SKh38s3um4ej5vGdQzsw4cLbKrbsh1SOZ4F+Vab5bteP3y/gcRnNfFa12jlnQxIE2GmAlwyuKaBnMsuwHOo1Obq5cvM5IVG5nX1IsSEW7yr1jE95r9oisoP1d7fTZ5olR6sitVoBbZKE8TgvDWe/JjZkuVW/yeUYUvyiYYBiBoT7BmNWlcwLP4iOZypk0eicqc+iw2UkXQ32Bq3FmRQ6ztbLg7/hvebLytmpKw0mC1L2SxzUUOgKSPQWSmLQXshZf7Cet9W+E5Ya2gupGhjpQybryz+aMG45wNvx7Pa104L7XdH7fo2p/l1pNXHZAKLGG3NffH5oLR/febkpndFW9lVs5QG3FJGq/Kr6gC14Mjts+qtoZPr0Z0FGS7YtxQgFJsd430Yl7GRfstticQn1uwFNgXo6dfqt8uv3UwBZ91BY37RvoMJN7kvAZYIcW+OL/orn9VrtJgjneUh62bBnAYjkLnQxZK3m/l0+oDlUOVTzrpf9q+W5shayjpxL+NtxgaQb6hbBqyveEsy+Ue9mxGVxlIwXDC6kESTsJWvfxQJ973PBGzyUSTCclemhymPnqH+u2xfWdDj1Y3z6F832f0t9J4ePJehl+W7HQ1krCl5T+J8n6y+8iOvWfPMXki7Sj4DHTPEvqnuKKMreXx6FcJi2hyQnewmoQdUuf9t0Ihg5v4idyyVitN+e7y2fMjI+2J3DcHi0uPgcRLeDtOV2DHAWN0tGH4t4FJ9H1eg4OBnEYoa1D38XYiPwnykq2nE609H+Y/4pv5q7HBj5CNJRY37M37oZOHy3tfpfowch5LpOAHbTXpmynKtQjibsPDTULQY5hcwW1pzVGJnC/H/H32N3+4KT9DRIrVxqRGiSHlwnP6piggPVWtXTC8+fEjJl0DxEJ7ysEFWoaXSVJCZlurp0KezTln9hFXObiG1nc5eqWp0jzqAFj9uz8nfUq+1XRWChXMfacKOw58EekC++2/DeqNWFTQGyOg3q28Vo1V7g6FVpv2IFKExBqmI5coiQHjvWRRjMTYygfQzcv4N4r/IugaSzodUqZK1XoI+PROMWPV0/leHjaPnF44ytP2/66/jZ+uqeLZir1QULaRkMBbOoGij8gX/VGFkwhn5UZLkskKjPw1ONCrqZMb1Z9ZRHWmtZeOIItIRkBQfNGK6cUkJqsyzlMqY56QZmHDTqWoLpzU/gFmpGsLXyDmLZBB+v7fN7AX825zAge4bl1Ez3y6s0Uqzvu8dKl5V0dRK6q2NWiEhijgBN0FQAHucoJ5/oxNMd6YNr6zPVitwYQkkDRjcPpubaSGa8ImNHoUOpHwg5tufdggVVlWV1GOnN7zX9zeYJKcR9AUo034Jjqmx4UazKiZ9LiCrGzH/kgxMZm9wgOkcojqyM8J4yFEE3PULj6lV561HSJrKBG8oz9f8lJW8tMq7aroMDa5PaxYpDZMQWojxMaYc1PCXJucTYZvfcnYddtE/GB1W1vJ3ZERM4jm9ZuNnVlE4tlRrSFTmMLEtYkO1hBiCCxKN6YoCd29+SUo6ZMrWzyKf9GtJ1Is6rVXynCmlDNRzHBDheRWwYdoRUcTxhmSVuGBnFt6eoaQVRs8+tYwdR8PV7Xt1oghVvZRoJ/kbbQa4latgn/vk1wk7QSov5rZfTQwfVCv6ywB5razz71QVBJjGB7btKpUDln36MqPveSD6xNZrcUq+g+JNPlesP2EG6a7MQUbguE99sx8yhGPKR9PFwzhUw6oM9zwkImNCcspOt9Ib2fugLltjXAvsnMknUl9E+b02OSLsF6SWPmZzH/iOhQ9bHv5Q4KWR1Z417NMcPm6aBnND3lcvfpTRCD3BGUro6gPOfElNX+a/lT7BgNVSXUq1h0sPk6Oq3iD9aOft9hbvJuN3xBKk5PWEfQGOp5uia6d1kQF24IaD6YUuxVQhU/v9Ets7aYUJPJcCJR7WhGsDPUnMMy+bTwevA2h8rgzQ0iD3vsJQY3Z6GYRMrucwH645CpkVNVGkeo11YC2sqk8gojxRHist4kzF4rB3AQGqwL4yDxdyIcyrrgTFUEU6nZbOOZ0pJPvLgimr7zc8bDM4PNQISMmFJ3vvUZLgUGhAs2s/s/M1Mwj1Ruo5KXVgMK4ukbDIaevibUSQygXQMrZIW9OqerC5wvddzlhJ5ZCipBuKaAclmTw5jH0NpEK6cF+ApYpaAR55v4g/T2gXg8D6ZZgd0LQrHMvVT94hlHFLYqO/UEHu58ScLit/Kf5BOGsOgfcK3pm+QUBLlJaCf8fAF5WOGz2rTw/sXtOvy7dGjUTSiTvSeRnt6z+z4+k5gUiTKW+lZWWduA8fKRCDg1+/U0TpwNFccC/u9FzMqoWuFz/vKNaJc7CHN5WyFJq9cyn3UnTk6OogKuJnZ5Uv+Av162pniFsMtR5KlToa9pqDhJ0B4kqDqJLm2FrDkWotZ5LgCLPL9e26pwwy30CSg8V2f0nApw3f9hf4W85PPRO0EZcYxytnJK800EWEjzPjqOem709RZcFaBdH6ClOIDDzNl3YNM9wXPJCbOrssfVNgj7TMxaoZzSNg09NnXyOpUdqxvt3e0OYxF/6hq0XSDnttpG2O7+L31flKVs4UfGBfsvZqEMBnTWTa0Vn0iUtmyBiVs4Gcg7GW7ndL+HRUYr/GwjokMrAfgzyXDKMlf0Az5MLOarrNCWY8469/1VHmOEMnj6ZBAV47nu13KfLPH4dMPAR+WnfENbVgMYvLGI8iA9Wg6RfYWdYWh1vRAKewzbAiyTy3Txb/4nyoig845rHUuThoVNzVdTYQ7h30cOeNmfYdKk7mOyWO424qdSdCyRbNh+1aQtK4JI2B8Uisa6QvfxtPs86VOZpVj1j39S3iEMLhDuw0H6+UeBhz4pI9ad3TUyqtFBylojYH8qsH0dp28eo2dBDbJNgowxRpWpt4aSmvkWRRz+ruaI+XSI6FeJ0/mlPQ0NyTTqZ9annS/AsdvsLzzfzZM4RkWIU/R/ksAAnVf5JWqxyWUN/jw2VaE+SHMAlyb0+UYqjGgV/Xs7Q0UsX4s2Kipxa1aRMxjuRC4oySKyY5in+KCsnXskAJoQpambpjy1cfYoy0mE6R1568rKn9iDHO9dZp2ACRirBkyXZf9Ya02ErzAzN+9Jd7jAiZdF4ZK3M/R2qB5uUHge3/E19M439cYYasxdbAcA8s+LuCLdahb7Uf3/5s2ATWPN8Wdj/GMqHV84XI8aMjB/rJ1hhdQUsMGsZAOwOYc56Z8vd1Gs2bAn66s7mvY3l/TaAyWGErItBzszPjCnVaYMAeSsn5bCSp5L8GzM1sk5hfnXYF1Ue+QpLDF3skP177DED3ROdHcQs3TcJMMSXItp2dfxy7uxB40HbK7qHw7eJGuPALriBj0YPVHOn1lR67SHJdl/TbQLkfHwCfJa20HXZm1pQdzo+TAqPciDLx9aHDxVKmjShYWgokX0FOH2weYBloeMyVzgYPpkIozpqkncc66qpDHrCaMR3QPFf5C7DzEgTA8QpjlNinLyJoPOL85EhUPBtEyjKu/nQVWxJgiJNlCcvdp76d4YYyHdPq2VPtHZU652nHjDTMiz+janS6EkEt5rcVMw1JDgR6MV4APG/jwqGQNVjloCrfUrVfXCXK8Ug7P0irLovdlDFVaDM4Q6NrYd4yYiUawJgn6EE4lYFQTXpizImb/AhP0Fd2WEmlJRLAFZnJk7EjXk1HsqVqW1kgXKPJ1pbUPgEwVf+IlfFec0g8L6joNrTmqLOKahE5q7WPjIB5KzU57AUnS+fuL5JiWZWSBAh8lZTkL9QSj+TofRaHFGexnpnRRjHztgaIH+ekAABETrb3nUj38z75fyns0dk3M79+/6Z7r2yYHZuqAGU/ik4OrHC584+qGPXBkJmUYd0gOMy9hxjwQh9dfR8oqGSCYoiDWxL66T2FjcJZwzd18fE8tDJbGJJyW1tSoBMMOi5zTCQYOsbvAabYVkPhnny8bidDZGlbIcpTcCwosvas7ICHAa4w2l6vu78a0QaauXYq35USB7Y2WeLLvWyHHNQD4B/TKfj3L8NwHBWaOgNivFw6lMmuX08MwrRjxNYpMnNLCDUHIRIrQcZnSY5FWYvQZJqHYmVNXlTdEyNjxteQlsqZZkePlUufGtVoux7VV8yUkI88hPimGLarZ7LcobxWzefRDPnd9Pw60uvsBYzado0VQLdkhlKszU0upQlpeICoK18EDdEvYlwkYW4cRHaa/msrEpxrC0k+UxfrUYhX5Hqcfpgm0PKm7yJElKigslP6WFrkrUpvrfjgqhK+bUOQvXy9EOcNAC4pwNUjm5OFWuRvpWKtVwc2vrzq/TvlVC69yECWISpQWmORt92qL9bZtVJf/u/V//Su2ivio76VXnzW/FWyTT0q4QNHpLj4hbfxzxeEEAY3X47ktcfDqZbFi/ciq0F9hcDuL4Nu8bf9oCyPPy8rf+tHV5nZh7EG3htfpZtwRVTBUT95YCA7zubNNa+DG4oBNBXEqMmR/S8bpyyrnCXfUyy/b7DfhgoquDkXd4O2FoaB+yllkfhzNKVrCTyOTEKCimKcRUg0RKrfSquLiiH6MT8vdAoVE5xm37k57D1/CyFGbJmc8h7fRKhAnSwkvBnDQeJ2cSpppUI+JQhGgJYAIQ1JbubCHcOJJD1CWgHbExyySFVoCZ9jbsyIuFVW/UT/QJBgm/fB2VKy/TD7WV1+57aSDZcCYIx11qLhMUM7VL9XwihRsn4G5SbxY9NSw9LBloOQq8cHC+UUiXR9JG3cC8JsS/KwfONnjHoFCOLtzdvVVUazX0I5idfacV+AZh/6zG/GFHY5fXx/9Z6ehz/8rcYETN1Te/hwR8JaGvCkkB0gCFsPLj9iQ6UFMzunYVK7RfhtYAF6Icn9h4FYGcpVpDih0DZTDCSDonPRQB+kHKNgJ3ynzIM98aWX4jBJjtTzEF5FTVwB6THWh1hZsw1iWMMe9Y39sWxcTR2ZCI8eHtO6NY1H4GfmhauwPTLTEjE4bHON9Of/eEskkW22yw+chovXQM0P0OVklkurbSa+TCpxwoKWIfQXP88raS62FX9ZDtTBGIIUHyb5z8KqtRinhy01M7q6g/nj1wauFRS6Sg8x+tnn054ioaFioYlLU4Hq5fX1hrQqH52+WQI35ul7N0Wx6UEVSMFhWWEjQ5Wy+HzI+qpb3eRodBVpeeHLQxP0KFHaKJ6dWPKVLFqNpRJCMAAF5guwAjWGKODDA02M0u4kKvd+kCU80+e0l2iDlDa3Oj/bSYYec63vPHyz3bdw+5QapO2svUkBAVNuCgWSyWdA73sYrZFUSDMn5NaL2cjaGiPc+Xpe6fFF6u6TR3s06KmufE2hPKwyft3TVCiIMZbdLq0jnDTJ6ckiUog3jgd3m294QpQqyabVMPEPdRJrWTSSukFxjgtO6Flw/gKpdunuAUE6i4ygq5rByhCXFRfhjOaGsVjYJXgPKMDgz3AN9vG7QHQX3c1RVhIIEWXCPa4HkR1drsR8zcMx9rK1EExgfh9XpEZCtMAegjrNbVbHQrzMRklN9DxVFoLZmPoNoD0zu2KKJVHzNvgPKfldAZQIztWrZEyYr29PmsYKT3yO1K0b36WpobSIQE7aXMc3wUZMJxeRhm2zvjIPMfyO8mfAQ4OvTPbAKLqjeTc3CJPWrwtqHJaz2bJSJ3rBnGWhj/b0h2KY5FP29UjWOY+sRyIiHM9PNGkgSSY8s2g5LN5sl9nhX60ZM6dbPigXwOJU3b5CUM09fAbTkqTOF7yPQCkQER0CyfNyZWwX3ZCvFuKfN9oBrfmoSjmxRZO09+p6qEiAAknrTJ7yzi02x9iPFia6UxFhp19IViKLfpaFdlFU3V4tdTl9LArdlCYUitmEAVoI4WUDf9wZcDsFf9LC9al2DBhjr3jZu+7eyfXSJg8LqRQza4KopgCgiNTss1lBpTYUq3eRdB3h5GCpF3GYa8EZdRyYD3cg0kPTLEKZ5kl3mQKorqxvXNARIKR5sjjB+jOXUOj9CvCtuCJRLkWigv20EYqsdul/65FRZDGQn7SQlrgMXi+EGlStmxudAmJ394PH4VCw7e+bsZmCmT9jqi8JtEOcawnXlzvudCnRx8jrtXoplgSKbN9JOVDYxVXvKHWxqff7IikFgRS07/O5FWXi3oxsfXrpkR3jJNfn1vmhRex2EqkamhJi5CEtmS8wldYhLS7IYjWtqeTLuLrdGdieFUQvnTVYY3iDyNe536p/pR4dW/pWBf5kRTrrNE0ThaJLiqfUzxy/t5eKxqtbANzpF7S0o0o84/TE5d2elBunMxOYsRGNKGxwvJF3CBYoXJSqnVYjXTbghNcKlDcnEyXcQoOvxMC/hpMB4JatjO03p7f/DqDxfgZ1Fnz/U9LhzzOEGVk0rVkLwRvQcpJ8KkiSlDfe9+AZvrTapA8Put0Owqy8x61oBKU6mBf4y83YzaXB27PcZ/9URyYyajfPgnxGh/BV1MpmJtu4eIpD0YIvozYDqxYAoelE+lL9pIdZmaxXtA0lcLNLl5CfnkrOgYVKcvqvaPz0kdT4juRxtRx2GDixUh1IVdw21yde/wkyB3w44QIo5vgi401t0gk22b15qjoavREKOijjX3RuYgbqaUQh/lx68YDoJ8X48hrutqlTOG0I0hkyV3CbzMmCQJbr6EQKFDxv24j8ddloo+/8uokxt18SpK8DoKbye0gjbl4st2al6sJf5iqR/EKVDW+YKHrCnimLzEWPUFlhFBkUNVQ6H5Q8I6CLJeFQxFajGND8nmoTgNs/dUtVME/MFIEXb+QFK4/0H/a4382TPX8BNa7JpE5+ijx3JnDchfwrVdqXezc1rjvagXafpxNCHb2S7EJF6iuQ8J0dGycvpjHd4WHEHNR66Xs37XUL+utEHu8DR4lg+q1saggE78G/dVI8D8c4h6wKDRwlUeNi+f4fQ0OkryXY1gW0SnOHUsd5xM7x03owGyeIKg29qwfpAMTihOdAJfZ5VvDfUkgCYbl5oquiCXdCnL0KjFOIpfuu7lqM7Y5omn+3IVKBOL6KqcgQRzP3qwIRZJXL/fRB12Lxk3AwQzIaeZrZ9YgN+q1aaXDGsQPvxjeLukzsN6LCN4JJWrFAKH7zH+5+9r7ZN5A5+gjA7DHru8eaFF9oiGVBOPZJ4jC398oh1MmiGSiyimjK7/hKOHaRKLNRMFF2R0mW1VGJ+uPlDl4J0yvObc8pxdbT5947vX6lTenRfwniKJDjZGvC9yOyCca2Fj5yzNW4F0J2jHgwgQk1R7gU9VOGn0jd3UesyM1bx7wRDTYcWSm6yWU/7fvao56T87L45I1/XjC/ZL8k+d4fzuSq9Qei8W0Te5Y/Abk2FlemxHdgMKj1sWZtT2/9bH0RGnCHbXD1R9+AUtBkTwCqjL0oG8csrR5fCFbs4WmRJix027J8kw+/WZff1Ky+75JFinuy4HpcN+Gvfh19sXKb4vC1sH9nHufFHJHtv0KI7Euw807Il+297JB9WmJq5H/rJWwG+Sev+n4A9DYsP+Wx1tcxxJXq0x0ZZL/VNovGWcRVd95xsh8j5QYkxeexna1xAsREL7Qnoh5DfIfkNPKV+wkNqt6GigqX4suBr8jTZyzQGxq13BGzwR2EEYdWIawWFqGP97zsD1FfkLXvAV8HYATyxZxvK/D19DLbseZCwoPI6wv//Rniyc579YKQKcMDqtWjE9C7bMOjkt04bNmD+75uZaRhA78Ub8DuXW/Pd1BnZUCJWATQP2wmrByl5XI+6eJdWhh5K368VvzdMZPhx6E07nfjYOmzwu9zmJeMQll3+PPv50J6HKXz0YdCct5KWZoYkWBYNa1to2YLLRY5Gw4KXx7gb6m16mvBV17NApjrBEZpeqNdzz5b//6erD+znhY5FqWSqavRpsBbSHBdm5z94AV1NQBW+4oF7ZU1N5UmHn6NwtkMXjtjY0csAVVvQzt0GsbdGKaUd7s0hMF5OVUFjpnOTQb1E8faHc29NMjfGnW6aTjexStM6XANjKvP268LS1B2mCuhk6OrzqHKk053XkwN5JNC3G+goSGaRkPxrfNQG9AsrH5gUXZUf/CY6t6vxeAMLBHmCfHuKoqzFr63nklQdqut/fMd/yfxSOmRthF36B7Yu+sEMlUUbE6eluHxwPhwuXruUObQqkvUOKD7jC7bTUp28PrccQhgExXg7kYDnDw63hgFWaYAAN1R6+FQeihrj0+65lAx1MOYKF1mJkg4NmiswpXEoWN6YKSh6R3mLBI4ZdOIxhS/4bbvQdiM4iSjgUxsxwakH8Id4ZmdFx3chEAA8B2aR/kIINX7qSh+aZlUlmAPXzjteG4yCPAjVBwxYumLD9ot5E2+hS/L+BGqHA1JEowX+gwU/ScYTnEn6/VTSoEHzo54FrLe+WUUh40FBCZWZljO2J4Md+HDoSWfqx9ttvcXB9rkMhMeo562ga1ygNEFlPP83Cz4zGnA9NMY68nXINiire0W3r5T6yMlQ9PEg/YuPaNU4UbcuW/HQgwdnULamKOeesMLe9Fl6Nm2AUgwChYr3WUmvzMmXW3Et5JXDi4kJTTYN2dS/I1O4goWTxn8CkJ2o/xTiZMuP2x93LQj3bEAYV/TZvAtsVjc7Yu+j4s+HGcybUX01uUqmc4RcU000QNFc1ZfFfKnflIzMIIuciMD6vhGa9/V62dYAYLyvL/6Y3uULFqcL6+KT4p3Nql0VLv5SvDXyn5V2sAaAM41H+tXVQO7rqXA9Z790i9iyVzH9HZDeu5XV7SUVYrOUVqqqU0Fe9teRyOezYMhs/HpQbmo5S9l/ndl9z3X9qUIEPhsP0s92fo8rb7u2f7AU0z2R+iMczCk+15L/0LRJQidQnjDemT0VxbOykl9fnxs5RSHqNoixjIarTNfAxv5XWJJKTHY8fkIwoa69EQ7XM1IIrTWIW3Vxsa26Um8m8E6t/aEJgpQhDBZmo37NNE2rt9h2ScAbDXlHZrzgeANl9WwdchW60V+ozIsfeC7fxTCGppHEYWH9MEY55hNIFmc+GP17oyl0E+klaamGsGq/DuAdy7gQDhnZ6cyWbCZXv2r+h08NrXAo4+IC2SroCB2DzRexeoS2s3JiCXH7n8Ed8w2v+5AtV9RaP0foTqCld/LU3eL0HWR/Uw/jIUCJjYGUZkewORFEzrHbl/dons2Uum2BDbxJ5LioLRY6n9JmP+aJ9Gb3/mDf1HyyYlQHaLb2J+cuWDga4Y1jN3DUJwl/FllGsX7fAvqapf/cBSj6nsp7PpghHDWf7LcErToAAB5TuPWqSDZB5vXoHQRYSxJbZ3sl5e0LsNJl3fdFjNW0tE5fg9iWd74NsmhdxvHxG0jpOh+JlHxPct5akfsmPySpHCfh6k9qyIU8kPgWIQteHRjvQm8jOO/FLtjqk++2zCiM/1x5D868YBp3MwOU3CMmXWxl97/aIJSGdRmcGhTPGhmyB88EJuO0EoIIjL/s0y/2C0ZOf2hPoRqAt1ZhMIUckgVE5EVzxYyWDnt4m8VH3mdYA37jB53cSOI4uzdBeBB5DYvPLNRcMGYfWa7whxFSgZOveSeCHq8aUEPD4omNTUiZNN9DAUzcQ39RoXfEPlWHGK+OvTpuGsJu8zBCfAnF9Frxb8xi6RSiSyaj/uTsoDt+6/KKTA6LVJoPhOaTsjRMv8ST93YoYBUuOS5gAEswXcBIFkV9TZ2UEpFGyuaT1TCnIWC324/kyb+GCtazc0tfOrpQdRHHCYkKYbLZbcDkpPpRkkIv+XSYfDuBtA30hAJOJxDRTnptgod6agRw0c/BH1vmulmA80Z6R2gHE3pcejDyp9IQdWES2/XRV1V30kZs7CFEfiLZH4tYzYxpKRILLdrXhrYSmqwAWAZoiXDDNNHSyYxsYUKxvTLXRP1OY+h5whlneinyLaI8N5pDCnoz0G4earJPR9D6oXhyKCE1UCj5yQFbag3jGiCqrvkUyH51jKcxVt72e2vfhcZ9ac69IKVqhQkxtxoB/OLGPqY/iHNSlxCHxaoADq+BymdE7shh0zi1SOW97qReUy7MXlCToqKEi1LFkLAG6yxLck+1YfOutNwShHqG0VmtW1P2UnoGXtVDiDEd2C71iK2+CFaVFXFFAb3FyPTSQT5h8qOyaso2IF57yb8av6aztCr8jUnyKRKDG42ojvz+dvh/OMhw40Ic3cLbrKxOtm9ryzZUWpsu/N++7MNmhbtt04Lt9zwzRHypz9ET3CNXBmGQjDby2AQD57r/I1+nWbnVwkDRK0A6QBXarQ0Kjs/HOUXHJgUJsgmMmqUiI9/FVUcMS3jwIz2CXIw13/Gz0yXX7JftXUqcbBqmpaaTBNxKREQ7PjYcWv9bSL+tRybWchjMSIrI8SUvhSWQPkuMsqXjHnUIhrXURrmws9twSLApgP2z6v9Jp/fu6Vkp99XbzWYbfUpcYm7kgmDGCMEy/QV4HvuFfyvpzsnuJT7VmKqxbWgLtrxpnrl76dpbuDguXjM89btzHzO0PICetRJw5Wc75o7oba405oWAX8p34EVnHgn03ydLRUBGRVSDRG34eFLUceSL1zUFUjB1hM67kLw5eRjxLAZndGsG1xzu4pdwJaG6TAgBh/4UVPPXmfiI0O7vcgvQutavsEiIFFaJlmy2TaP5ymaXEjAW/VqtlBoO+n1aCtpAGD/r4Fc6eMIyIji7hfYuHXoBKTI7PJbTRUWN60WcF1R0I7Z++XUdS+guiD1F3LOEmTLsJh7rs3xFHnmQ2hvXb+7i2REAYRhlP9pdsSg7zIIw/1+vKAnU+9ilyTf5GrnDWEuyP/4d3Ob40Nti4zrZA6IPk0VCeg/FtkJGOP7R/j5pKF1S8kgPvWRLWthoVOXO40bOE63lly+O1EHpnAdICQyNWZqfSA78dBOASdY7IY8hZz8mpZc5/9wqCDjBHOUwW0EcfhA27WUB7mKQfeV3PpmTkL4pM4bEI3OruhP9OiSFSFWNeGiT2j56uvPXJ5C7QbehofMpKuJm6OyKeRu9oNXLexWYr4eJTFlh6NXuGycKAReVa25YBMVkh98kKYtcnCT3HsmtKtcK1bKAU4JZUqtmpnX5aWrcErWL6b9+9RqyjYssGLAS2lEQ23NegDNXtm78ZadcBpAIwwUqK+2by3Z+NU+xENFr9MeZEJNI1Jc4ok0s+zG67qPIsukCfrJ9BkTRb0KhdpJYIZpN6EOK8z0ptNULnGy+jl/LbjIM17BlBdDjowlCr+gu7MW/8PplJf/1+V9c9BXsRBmJBgwI9bwbCu2SlJox/t3+J6oFr1Lr98MZmn65qgV8iVBcaWzSZ7RgKcg+K30OIo3vw1J+2qZpcz1a/phx7HvX0zZBCsOUn0ZKnk66Xr0dfOH+CmFmbelAs9CWCGhHKQHhMe/cWnH6wovzqjiOAk740oGtH66gDGg2LlkabPoRIKFv/zgdzcz4jW9b/FZu0+IRjLCSnrzzmrgixSzRNk8/sONjZqso2hyYdF0YkGjGwNrWhZNgwwal1kJECBS5vw/Iqd99lWImKqVnFLwtGHoau8UOmqDN6KpA4CMt7VJKhtISGE1Gkw3MBC8rfzDVmZq2drFihoI4EmGNgrOTjf84Pu/AD+bA0PG8yqLFwASCAiphTtr2TKJvoAxnRgZm50yH3Aq376B/gLVphoKJhTpAUUZgmbLisgQRZsvMmwaj8SfNiFJcf7msoohUG9e8+mudGzeMakCtxjTk4R/W+EuHvwb31pAhtKO0kjWXeunpApDcQ0dbht7hn8VZzGxlQjhRijtLHCpsd38VcWYt6p4rnXwSHxl8w9Yd68t8cvvcTxORGQ9pPOgQdt9FPoG5ErVCd/sOeXnNecPPJ+hLIDLsIW9Ss63RjWeaOTGLBzFJye3BzE7TslX9pfix6AcVHUF2jpO0dxVcaess0WFb3wj510qHBcXB6JhYj+Nh7iOuM7gfdDMRn6MSZJvA1ET3o65+XPlfrN1tn0t/YzyNCp/QJcP4DADnl3ep+LVSgBIBk7nBH/UOTFfVw4VbHsUht+oNGpLUd/g8ht1VAZai6Dif1d0bLgKtk+9GAc9Bw+FiapWDsCOgfKN9BpA0auxvhFeEzOMvVC1MSknd+h8/N5h6OE1lGNLqjmYwsdtHpLqc5IldRL30w91AyAzpM1hM4/8u9uKhOXozLpfzRo6j8TMr3HrCOJsE5/wtY33kAlT+vMzk5oNKjKZUWwO19trYY2XRZBLAUvMzDa7mHV+Kxw3vfd3Co7Ts2vnp2rQda+RKeSakUGRXtvefdx2IWBWLpfsAkBIXhIBoQ5sLkn63oBRH8UCdbVWJb9yMlOLvxR7YaXGszZ0GxlCyuqnu9y/R52VG+VPEVatu2I3n1/HQR5I/QZ00RvYE4vl1IF6fDAmERUz7BDmTDyGMKAvMnHj1w9YxacdSKIzBzcvNs5cvjfNVY/zfE64sZRNsA6O1PjzXUrC5f0TmaXSKHURx0rBeYLDZed4MeU1pb8oGd2C0awHUieyodKHwHaiFCbewv+bSRgz+ZtG8sHpBTOQOv2izEX6a9Ne5pWd+mDVIRBczhTzZR6mm6zhrbJNM8fYpf92+qyxU5tl3gfUeqxC3ZS/eOQsNZ1BOEPiAIKbnlhBgAWEUOWf09GmgIDf0pFFaJHD1euDusu0COpz/XjTypXO1jxzWGWlC9InnT1EBN8g+kpZaefkkpAeUvGNYECato0NoTQAGu8G+mq4CnOF8ybUf0xMObZ2vT4MFwirPTQGZSqjhKTghBFWLWcFQMI8tNBzr/LUjssgKjtrTT/KM+9L/sGtdqUDhjNS7LKXPDxiBcr/hNnxHRBdKAJ6AOYCqI+wzH0w11rxuxaruHL2OCHMXbMy7fkdelFWlADGZn3Qv67UdLlYuqV5mobmemDcgY1lYevNekmTPbp4fxZ8GneSQrdwL3IiLvmxYkJRqX8FzKxNaipyX5T9J595z5JOlr9SNZ8n3TL9RLp8HnHyXRLYtdKZl7D03v5o27A9zYxmCV7wuHjts5rFuZmCH6HN4wJJnu+nGhxcrOTb188oIJYx5TfuX77NzZm/wnMVvpA6/XWgVNBcO4YsVZkDftTQv8yv8nIG/dcFvc1OcM7mAn8rAMhshAXhlF3r0AlUsLjGO0lzdYJonISWk8Ueuwjvon50Dt+rvvlY4GSZcrPMK8V1+fBSOUQ/1LtLVBHWy7/BVOp+8sOAVW+fUwct/jbQTQQ43bba0v0h7PLCLenx+jttHB4LURqJtVNskqvb/9Gl5hvjwWqbapP7bSxrYcHCa5UFMbIihTjLh5k0q+cb5+1vU95ZT+kCchfZGxz+xnlMc7RqlHZJrU4dhmiU7HiwIrpSFcl0jSxThp3O5Jat7sJ3Rpaa8Y9pbVuKIeERu/4mtKJUp8eY3l/I+/voCrb7WTuhQXpDNHMziZ/LKSV1L0/hQX8uwaUlPcOnK7PmbG4M3HL2rUXTKrqJwXJm3OiQ6pu4bS8xG+FeOdieFO2ENtQ60B4W3hpNp3uL2hBYqTm7SHBGccvz41VNoWSmjEqM1mfDmG9liezI1csAP2BuDBF6aaE1DvSJouQ89NCJ4QpvYsUYIIhpRgL4Z+pt4jxV2JB+/kdY9EiJm6S5pQ/x8bXPxIk4m2dkqxST/nk3h60adiywbQp8EOfmqQqBvaGnT9PtKFc474ufjeLeayC6W5OnJZLameB6CCZQeYEaYbUfeu79cGgRQ+K4BBNKyYvhBtJm7gTx+WFIg2K4SW9UgisI0iM1sd7gVxkucOLHGdcS/zURdHSOQyNLriWOHRtCk+vS8fQ/5+ctkalDyytDZWb0sITwGebHUIXuQG66T9km53In4KKQD2QPCdDjbTa6vwwoXNetoBmtobFuwR9kz2L9etMFzR20yjoMaaOra7v74p8SF8hvboCM4+KquFYVDvF32h5BxXucwlViNV59gXJLJmio1AeZY0NYM4IBfrnY2+Z9L+YZbTuEVNKFGYH/UcYJv7BZMROlWRsvE/u3YR4Wa4A480zJ/fAFjh2c+eUkh04RC83wSN9NScTsyUdH3QAFLY7EvDfXaodw9X3NzgLepV1CRsDgpnMjcDJVUXxqvNMRGTbSy25s+cY5L7Ga30uWp5ABt8iCIBczEkju+cy+oqTEcwKdpRsAsgyIBQndtl1ml7kcrnH6aJxnruY0tTvx6cnsVDQh3+t4+Mfc/CLc/tXh5OfyvMBM/YH/3dz/ZQ6VdZwfRWH+hIZ4yhmnLVjgI86ss6im0zitO4qhx4rf+C3I2xkeFvsHKNDFW7cz8NOlaI1Nlhl7KzxqHUcj1UK5IcxZ/gDANvm4rBNZ9hoVujcpQ0/pEoC/Dl1m++kUHGYeRsTEW44Eo7CCnug3VRE2rsQ5OOQgedo4B4OPrJvp8An3NGAbhrCpC0WssZpWAHlIikJ8JcRrdehxh+g5F/59EY1vxLjL0xsoDcp0Hg4mAbtwXQiN693suohPKPzbQyYO+Op8Pzbz18zl+vy+VWpU/NdMp8xRHbyo+Qdhsapc6yHMnB2BtHRXnC11gk+5dYF68Nq4RKtxyfcYaIU+5dLCP7LwOdQDE2daBeOC6wvSFZPszbSa6GTI5DND1dDuOc3CsU4p8eA7WyoNqM6ehPnaIGyuK6HRCIFRnA7kuxPx7uE0eHzZpFRd+YQuMVLcJcAt83niNc7hqIIx8IwSgCVNh+NmBRqvXuREAzJwAexXXAb7wf9QnwrwfH6AiEa5K+rDM4LBKlrRhlXxWx2zcNNEDCsXZ4n/kjcFxOdgTB7qmEZUZ+UF20mXbZWZ6xbezUN8ALUg2qCd0Vj1sS/tUryIlpuhqzSUjG0Qt/y14vo+lFMOIZIr4ybfWbW+zfnoFJq94YNpJesag8m/p3LTVniKY2IzHvIMc6Cjp043UjtptEKzFH+kCLX9KPMQ0BvrjkPRJ2t7dA0nvf/QsVgSuVyEvidTCSfllQ3m1GQeLxbCMNmeMUt+Nt+rBsyWIenuB8gSZI+RRlTbCkplexw/Naicg03i4l6cThzQo1R8rC8QGD1kymPkiZpAmx3p1bZa3k9L21wS1i3ZHcnGCatbt5KutJo61ZWfgSrlCfci23hsshuXI6Bgwok55As4/7mvOK07cK7yDtl/dkRYdfYIe006pT6d9buz8W8nIdJgx4i0c3OBL5hDECs2rXTUk+1ZDOqBeTNuiaGzLxlO71ZBax0QD4pFcYfBIsVLPqechEZTph6rYdIbhpUITy4mYEbdlRpMPOL3GrflQ+/WW7NFhqSQrRpwPIVBX/e8PPjOff6l5/xznTbEok77Xqqp/7YDKZdgR7DtP+1VPpFjvM2n9Sn9EMlkWB1VYLB1JOyoK3Ns4WZVLpQONk7DGW1n+ue4Zeb+O0uzoWVioEoE2KEG3yzxnsLsDcHqPMXHYLtB96RBvRlg7cU/tEyaFxoP/Dy30nphNIcJQ4IxrygCnV3n0EoMYxpfaPQpf3eUk1L/E2ZzylcK0vZ+vrmnWrZ2J6YzEy9i08OK+Y6ox7zhy2VJJxkF3MXn1XLpNh1uqDe2MITRgwrbXvptfTkf2HPhu8XC6Rj8M4t6703RmHTCSZjEgqIqb/Lrv7a0FSnyb0vp9LUbO+v1AMNMOinJAnf0qPVHOnT7zDYEhqQuiERdnC7WjBVKA63LieagSaI7rlHqRgOvrXk8TVSt8JjHQtU0lgqvrvaYFxSJ6B7XWK9rLTt+RLoYi0F7c/0vKEsZPbkD5QoFdySRYGlO8ikhUETGWreJOb06wB7UViICFRtUw+/MLokTInLqQBlLtMMFyGg26ZtUhtegEnt/gFa6QYoCUK8aj2TMcEPfFxrAZbaujaewXk2kCq3HFg9a8glBsDf1QsO64ztqlBQMoxhBT3KEk9TLzoHAlcuNSCHn77Z5WheimFEow8mA1bQQSCLwjK+1gXoT+G92Sk2dYujyfyhXErmUkGINhvs/ZFDNVeu6YI/Z3B/n/rqbM29EpFvX1Ckh6sF/DVovLH6RkM/ScbrXe/Meji3ASo3ZSRJTivJ4wyfkbu5G1uMABoXael4M3AuzISZpZ0HGiAhtsXd1bJOukl0KwGleiUhA/szw0/RUlff41YxAc+Uz+M4vRr5jFckmLJT6PYfBX+7Xatwwv04VbWfvTyzzRH/ebR7HHhUjqZo4pWab9Rf14BjWnnzjkp9vg/0+nGkcJTh2/RF+yc0QTVHZfTS2IuxFllge6mUomgnyPVHhi4Am4hzOQ3/xSwwaPH9WDN8TsTRQf5/Cl0LhuQb5gfuPG+nzHnl/ssMYySsVewx1ORli/TctsAZVk2ptxcWwCaKTs8UOObXju6HeosezcPAPEWSCwY3LZR+FwP0NAm74uL80VSXS8QF+dCU17eQg7ywmfbFW3SNv5tHRasezUrrzOCzdiOId825W8BPTq3gE/XhMtNzh74RguaVPmKLG5L9/SIjU27+H5/TpuNF4LF4VuJHawfrjt4T5ErD+KykzD1eXwoCd3+HThe5sn1r8505XcnkKoif07SkOIuy/Q7lwQqKJmXV/FXcq9r8reHHCus2dBzxhXZSq6gEmPVT2xR2aMPzRZGSawZBEpQJJeEs9BRqpmuhVdtG9ej9zuV3hieucBbTQRwLsIIgSR6mSOSnWm3yXk9I/Vvzn/lEn9IAnxqn6YHHLqQrkl8BLvIezjMp2xFeO9qZhhuT67uqq15xV4NLXhDHjj1PfMGDQBN4FnGblmd+Meu1kFEsCjxcqTP4NOMZyemhWE+yy6KDVLxzeY5AT1MTMKY+iHOBgbIAkCYc2tu32Sk+fgfkwJseRwG925uLaoKnbzx9WH4HJn5xodM6aiNc/zm3fpoN+uQ0yAjJZ+WD85esVtpbVgaHeh0i7kujCYLpq3AdLAyUa7ASy3uvUaJCoyKlhcVcxHmDEqJlHt4600iGlpsOnuoI43JfJFPOSNimyG2iLkyHJXUOJlhLYA6IHiYvejvt0CjA7idoIWbZOV7jQ0pipN+QKUlw5d/jxSrOBGpKfzqy5y1ZfkhpGWSYxwuXOvHQ77xR76Gb1uhQUexw09MTl7zBAusxGQGej8QdkHFd3RNsOSlWScHhwbl2VkNPg0KpvJMOZckAFVYzQr4lrsSiK2iK8Z/ydy00QLMj9AGBcDWvb97enGqwImSv8UWPop4Ekrao5D3WuAph8N5q0DYFIvAyZSBgygvP5ZvuDWzIBZ39boeDgFWagcCwreIlxRcKH/6GYfMeZJJStwcmOBVgG27F+oCLJ02P2vJChQ1Y4eG/i8NvzxZIqJIWeMDFgdPbWih6R9a+HbU1LMITAT4z0DnIzCQKWXhPG+jzaXF2ZvaV+Lx4j4olIfQIEgbXnNVY5F6EX7XDkOUj1NNxw9Qmw5vyZoXvppGBSVWMHVm4+9cEcFjIf9FMwE2HGydT3qhq37y2dXK7/TvyoSZhjxrnSApjCbd3Js7wT54Exq804KTnfdW7RnqZyS+qw41RMMQRtk2CfuCiBLzlcY6Ndv7Lya1d/jKr6r1RQqqwJ+O/L1wsf9HYKQ7DwORl9ov758rMrmk0rzPjn0UYOJinsLCFvY4449EihxJlFNU6TL5+hxc6+m0C/gmjGAMzbjL4S1wGIqivc+Izb4BWwPyVNCTbXNli8x6lhydxY/8dqk60dQPvew4jWAXe+xcullKI+3+7routboq+kkeM1/manPaAGrywAP6lMCCGdKGNQ/g1cUFiv613+YGopz2nuXQEAh/TiUGNTWNu1iaAZs7VA+DHh5WCoMJd+Aa6gR1jRgZUNs8ldBGDMrRPS/ZgKDaWGpq3fMshowfNW4bfd3zJfC/yJeLiAxgNWiBOcAPbDnnIGUwH7FHyXiBuGsJpv5FWnQRrI/mjKGIWL2k9D4RA4TP0ADNqW5ZYevP9cBqMp/tzvkcacKuacAASr+wibc6nq2poTXx7CxBqg2a4jlEj0OVvae92T2DqUqLVi6d3LgSrNNipQ0ZA1IpDbxTgTWPQaWxeCfW3l5agnERyOFpvbab8+dfCDWjojAg87TPx2mMdY506LZL+uhGgdpxKQIhBOYmUzlJiFB0AdamSONTXQZyj6J9p9EQtuVGexs+VLys3EExYC3U7SZavfpsTTtxQun6FFjsXP+X3xKFYtpJTfc+n2VFdPHgGqqaq52DcnR5qo/k2iu1SiP0m45bST0hz1mkKNtg7rRe2ayXhrFTeTPILPaq6LA2Up+9nmGQouw0TkovUCG9t7mR+j0bQ+TUHmVJkhhLWVSI4xKO3Umo7rXC18FtwNBCXk+qI6Q4fLHzHIq99kzo5+Xev7Y5MJR50GosrkiYQFtyDqy+RpLxaheGfEHKQcC1oMI+J6sdTGw/VfA0xSBgKZ1IQYtYk/qt+DbsMVLS9Yc0KTsSQOCE7a/C7T9fChILM/ZZU0R2XtE5j/wQbqCziV3ph+QgBwtZWNnT7BdUhD5YZ5SYwyDz66gPvtZmMx/NAm/qmcu/hdacXE5dq1z9pgHq65xQaoQm5CBCRs3Y0p4cXmE/bArt8Ymnkl8j3S4Ge0M7vrmt//67uJ3vc716PmhhXSpFpClG4/+Ly8SNeqOA6Hg6101EtLfgBFX1ac1tZOl6PJ6BiC2obqtSF9qJZUzRb3/3thVdnmSkYUUhdCDL/gGMFun1N8WOzmZijw/03nLM8pDSPYsEGMRCpwhUUSL2zyKZ3+Pbj0eMU7oMdGdL8BVG8SILS8zdPQ5cSZ8DJ2+EuB4TeBLzE6Vqtw+mapoesfzDA/6PqUl8ci36Km6NBL6OTvLCItPIv+UyfWWKtisaf3ofw1D8s3O+wXlx+w2dekhtqbvD+gaTmW9ltdd+PSXXEHUIsngxUL1OBhCBxMEzlhk+ZHbOLfSnidgfGBp2oP6gAAgXagHasp/HU8w8X773KdgT3SPGn6PIBaDjZjNvXD4t3YHQigIyW9jI3mzU1C0o9uS8dd2S5Ss6FCkZOtfxfROSZnfByeLgKZNDM8cNiRp6+ZWSI2n/XK0zlPasXoBfrZNAZYbG0xq9KW/kCEt39pXXcAXeK8ldWLjeW4PNjCabRvIIc6BQ7KP5nXtV3CEnC/LFwjQwSwhDLDhotXGLXY/kQ14R5mMm+T2UKvxWEMfK017zikScdUGvfAcCPh7yxrBBVGL4poWrAzCIDjrNYd6VbfLyGgdTfgJrw9tisUnBpXldWiQqaCA1HMu7BtcolB+x7O6x3h+dNRzrWAkdBbu0SFN5NdYzw5xw0Z/bpMVYrJ8TahRKkbk3dADQiRfMfXd99W1thrkhJ9/43taMaixKzpd5Q9sIZH0vqeNHVjwlE5m05w1mjAruuPxpuu1OOWLMfSFkG+2rKafRKfXDuH+AipZAZuGGA4x6AIzWVRHtozGDGynemzMxMPdYFRGfsjBG3DhbtAkVrdFLst+NzP59SbIl7LKJ8z0TJQBw13vLxPjO/U4Q4anHE46LVRnX5xC+hF2bvbp6hWpXUSRdYpklE9cMjj6Q43Qx1yfmqxOgOddMZJRJ8peA+6OmLWZxOSv6bPthPOWO9PvmVUjoXeT8INzyYEWKDv7fAKmMaG32mJq4It0TQgXknB20shg0dm2r+MiXhaSGdphpI8X55OhpVydJokm9gN29bix43ght+kb2SthL4a8y4e8EnQrKEPYZ3rbYVFE8DSkyp72oXh/tEKg1VC07HkFcjVbnfcIYhc5m2jNf4ciGBAXLlWewAr7Ade4fXV7lBcSyreWcKgX0hFLzWu3OAAINc8AAPLkDEsnHWqCXE9x0CYnTtTUcVC4RMFjxxGoBn0mS//JJYTy+qh7GqQLfYNxTNz6kMslWpBWC49V/qLEAG7TyOiZF/dPPkVrsOw8BVyL5Rah5tEQyhP1cQDXY1cCl3L+9B8mqjVMUGmLoxah/HM5Q3PRdFNyBFemudjS1cJYIlrtCcTbOhXWx9StV4B9MnFG+K3fdE1Qi2ZhuQOQ/GYR0nITK2cxlDxM2+9trMDoxWeEwNt21s13qtQEb+Vo5CG7aGPRK4O8qQCUiErKN9wJuHSRg5jgezkS/faqvId9MRIQ7FZ9avnkHZ5ubsakDOenD3vAPmgwUkLVloTZ5olgcp6URD54Xok7x5TJiqYhClUUfO8sI2ty0dblGR7Q/dC+hqbKOB73zshRd8CmcS6QyFtsiG1SItp3X8Ig+pnpXXx+BHaea9c52FPr/yMRcP5UG1bMkNVH1OMpFt4ZYlzinPT75D3WgUEbLf4NNOFLdciqrxzhq1FMuMSTAjVa2/2Bf0MigtA6DG4+3vyMYcmSx1L8P4gfsxTxxjc4fMB4FLvH/fyTUz63uuEw8+8ESVJ40xqlQDmeY0VRc91B8hhIe88H8wFb9WQ4xx1WKoepOgxqms9iIBz/B7fPTIeYg6u4JAR31nqdp6PXzMRrO/mccrFdHSaQwcn7BgLls5r91d+QtWQv0aCPO6SRqK44uoQbn1nDZgoJbY3v1TCAQKx46ZfMupYoKscj1CcFUprnBeExV3lZDUxhnPBOhWrEa1vYMiEqnvmDu440nSCJbsv9NJphJ1HFLAuH9p93uNHsIRAtGx99PU1YvE+DlTIGd2GEZyiBTR0uXngvqw/JrSwgn7sOOhZ5pa9mavn5qV93GiZAp2yTVih3f/hGfAg9/1iHeVyqPiixaogjLYP46zF0qvUZ5HwnB5eTdoufYQ80DcRfZLAebFLLTHj3ooum5YIxEcKdsOC35eyJFrUzUEqXmo6xqbJXbMhke6GDFq9G6Y35kBB3b7/HATZVskFRu+YuCh3xgpaQgfTtLGG0Ry2RHuaGc6psXBh4Z9aYFZdXE/O/FCbwrAWKr1wqis6vD3UDJc7rQGfurqm6uOfHiLrZ4IP5QxfatmTrPK0FiRkGI6fVYbzTmlPNylsD8MRxAFX27/08sK90KHZKyNEpbrtpTdgZgR6Rqml+rVr2mpg7frkdhul45IKjnGOHpU+VOVeCxM7z/gO5fImrw4rwnBzvK/w/vvp9tK/brU5wpcOB6CZnGjeX+fue15v9+GVQKJAKY11rxML2CjK46444xC2AVqyvwDCrQEUTmKWHpN7GccCuaJT3tYd2EBa4XeK1QoA8xPb8dnRuBkc85seDLUU5+nD4V/nu8qsKkoc9W9gWzOjaKNKaODtl5wLb8dFuZV6D6QjEcyf2mZHAn1lyWu/UKqhxccsH87UWWHUYs4WcaFIaBs+HPexcI+MqHYNC3moCQviDuPhfx7kCFNRnGisWgRdBuw4vcqg2srlmSF/nYcR+NzlR3PxkxOMDYK9faUgFqbvdOZBb6aFKQAGgTiLgjaHhRAHfwa/x0P+QhM4NhT9MDlLNbRniwGrpUS5PuG7YGNCWLLYIMAqgP/GQaEAutsbxN+ber0nQ8/Ya5/D+cWFAoSqdBh/Qs5W1wuMpL4xBsRlgs92ILPNLFsOpGC6sawdkeUQG96tEbpm6tTqGIKicevvxiubzc3vGFCx/l0VOl6jOKK1jAx4CjpUS9kwaCQSzWzvc3IBnjNorKfDSQmo8oeLKrLEcrDMTWklmVyfvK8Wf7RBMhyQq9k51cOVORQl1qy5yt0IJvdMp+Wlv3HXATj+MTQmfa5kT3s5Hvr/+xcE97GIsnDH4vI6DM/mCiGBXaEvmvA/3zRciBSNCmvcs49yNRk42SuXeG0M57bW3eotmuDRpPquVefgSLw8WC07nWjlNbVzYB98vF3IZI8rG4Rcfa77l98kwUj2rsJ588lF66c9ros2O8jbTx38pgvyQzq4MVm7ZTbwtTc3il5VR/aZL/7KL4AmeVgtQqP5DoRDiuQmI/N8RwQd9fQNc+cLvm2ysNBcbnANkccI9U9pOPiI2v1Q3zLhkLBYczJPWHZv4ye/+RYAZcoVjVp73w0lxK9dy2XtT1AANbQkgkO7WCclbeZYlKLlIA0yXc4vUwunes5GYuDXRS6nGZO8FmXHpoB4g2L09dK1NxsFeNQPdMDjZF4uu5wYRpJCiFgqjRx31VCrJ/R+D2S2/NK31lAXXbs7/gp7wWcxXD6T14Wp/B4qt8OJ98ZK7KKFr9IcZKjuvVWovLQ6898EzfPF3Lsi51xjgyv3z33e1PnOoIlvV1RWzL1+MGLcM5RmGe87WJw3m0HuvM4hy7wow5k2GXTfCaT8jK9TwmNs42DwGAJls+ePmVb+xRKMvpL8Oe80oRiT6Sn0MQldzi4w3moWCLqAE7NN7I64A3i+D39xGA02Y/fWm7p5EXh6l4l/Je7TmXKWAsk6Raw8VRgiwT/tXVcCiaidgPnCpz0mPMqFo7QfPWDSY9DQVGSBYTmaBAxQDi6Jmqr2dRT4t+vXLIJjrY469D5Y81vetdGTd+a98s3i485+r/6rxE8nvDf6ON81Sp/MtyXsGdWGDfkjnnx6qPB+AAqpD1lxDTaial8WscLDnqryKD3MK/9pnehLVkmnHh2+Gws9d3YQI+2T0gDTXcS8Nxur4jVoIfDRLMNY3sMe4RsDDRsr44svtolC4cLjcRMT0oFHxrtId5VBy0qCXzFprQkm1/6/Hz/f7qVl0T7+bIJDdacvhjG789UIF7vtMzwVqpgtfyz2VO2hK/ozF5dRKZgn2zi7QlmJPbuQ9IOVr9gHp/h37FKFCYfPkrZKDtUhHp/INaeO5XN4ppp58BjHcfbEPM225L5LzZelbaniy0UWdNo2Fvq+vTIhfIaULi1HYRRgYoQw5YCQcptox1+beXeL2fg+SfnvKpdVZPkujknzsjJl9zgP8We4MLS30CuZko4qspBfO0fzG9ja3LLcvFN/t9DC6PZVFopUvUoCfaJ9OIoNLpf6OQ/mm5+Fm+ZuVq25AWYGP5YJLP3qB/TURJNgAva6p4f8uvqW88C25zMi/Oc9xwRsHCfJTQ0nzq38I7w9vw/I2/6auleaV1eBL8dMHcbhCQgmX3Sps4qPdm246VYj1RLvaAP/Qpg8Qh4biPpHgsqrCLW/rXLB+Sf6tuT4FsSmEOgMyIlw/YIW18FZvwP/fklGqOPmiRrAaoiAWVKzWrBBLgRe82ewgjjJHxI6PC0Rx+eZTeDyXW/LZIdJ8ZykmN8Ao+imZpXLeaHiJT6M8nQAcPtYii4CXbt11L6ngdnKyfxwdKBdMkH3Jbv0lRt9X91lVi2vXmZyp61GTtb1P9HA45192uV7YPIBq98T31yI7QnCEHphrawPCwKGRReUsVPFArt9e3GFIAUpz7vPjrIPn9QbZFtsZNna/osO+PwnXim3T9fmqmY3fgny3bw0Jl2KlqvjXGYK2iEVhX8ieaL3nfwBYJfqNacTSYumyCARcS1JX888PvK45uOgwLE9TcHl93BOXz0bhlEDtVSBgtX68p2M5XZlnMg1ZRLqUtthk2kXaZGuolbUsbj+91REUNqQkFXZFW/VsPm+TV3NF5bBezw4RoH1lqtFY3zRdAi1B06RGfRj/eg9wOnHMn8idw80+kZ7IIM+rn2HwL56C1kwgZG15iPEMjfWfREF2cGdDLVXflUTPkiyhCBWdKr/I/HjXSDVHfVnYI7W/N5K5Y5c/kqLco6cyNzt9512xMLbH+SuAOCiVnbfRhlYboHatI39E3Uv4wn2SZ/fw5m5nSn1CTkQa8fJBSlYEBYfk3f0YadAGLEHDNK/8uc+29CLo58PBMsLL5jVQngaAsz9bHLxJ39TgOOEzRa5vTQtxzNldgLItMYTF6pzr3UAfzt1T872DhvRX+yM5tEfWEK6D/OSX0+wz22G1UmNkOf6VUzyofS89Y+Vckd0QFTfYnB9uy/YoM4IkENIJsS7O5P5JMiZiW4EpCS2sZbcXlS+wngoAhYuOn+xXYKrK8rTLgaDxMIlEjPubSfNLvhqgXqHR0jXxJNFXP0ZSJfKuaHTav9PjUkI4xS2O6KxXRJ2r5Ac1EO92Bem6b+E0b2zj8F92KqYb2Ip94PU3r4B13kW9I5u9EA1g2nnQ4C6r3bfsquLYq1TIER+Z1Tn2agiZQ4lrGJtElGGQpv0buwhm5FXQE2qNfyJ/cESnXFfQYWFB2nkpX4xW/mIxvnvgOC/gAAfcyAtwhbcDrc6qAlwbcNTnq5CCu4XHzsEzDvFpwePd3FnQpcF2BCTT5XAMUWbQBQ6u8TS2oRa3LedemYOyc+MY8hn2zFqU7P3B45Lzp61ixIjC6e65XNGbHwvyy4MxGIj+YnG/kN4CIOv8M2Oxk+PKNfdL2kS+5aIoZkJfwzfNP3pHQz6oR0BGNaT0uQiKpzeE/sJCqerY5Z6v0FnJTqFDACESu/SDAN3QnzQz9o9afY/Qb0jgy9iaFx12vh0nMM6DrLQWtw/ln8LRq7rvLmRCTMLijYy0rt9LZJyIET1n1Ss6omYCBFAsp7SQhzEqiKJZZhVi9EOt0qjzqOcvh9w5vNxluuIcG7qTcmo1+5FpuAXt/BUqDeN/BCgbxdfX3x1NxDmL6+FQnC1LJ5GqqngXZ4hbNSlKZ0y49eMK7JgUOZNTcOl2iLNvwqZKLjbZwU27m2DLKLlkA4gT5XeJHJMcpUAz6QXnQH1DxkkxWgGQczDjXkOzN7RGvGOi05+qHGqiVt91iPwz1n619WG9X77UYCovgOLM1EXmD0XggYb3dPCwLkTDjtXJYafdaGWfJOZmZbb21N6IRfa20TNf8gaQhO1JgozKriXlNMHXZHxqlEgY4ivtm24qt1ytpbQA3BRowC2CJ6N21j0G15fEnk+g56XE3ExMKt8g7uTcGWaASmLxJ2+9tZtIM1iw/3b3gBGcqGxhuCLn7rRQ4+w/IbcQXVvTW2FCljbmaU1+sSI+hMdBNgDyxyVQJsmkH0wJBMQ0htHtJXN86R0MckO2Tx1pLS+PT5VsYcP/sYff+7cwCIF+d3InT4yKePHUzebOteb8V0HVpBnDZO0JoiSuw+u1ytmASJCXo+7cOkZz9dFdvgyE3mgG9pDaGKmL9VdVSt2Wg5Xu5NNijHO48MfTUVLhpRW5a6XzjgvZAGzmtaSO6tsWZ/bldNJHjNXsbQXj4ZI6sCpqnyzCFUGOdSly0b8UcfqC+47fpyXYQFIhqoGDkme2wp6TqYMgj/Qmqh+/tHXicXsVpaBHOPOH5hdtqniEMbieoWC3TB+ia/ctOafw6Qf/RdAqLCLV2k90iLqssLCCj51f+15L3AN9TqkBDVMCrPqjl1vJYqSqvNnuboRDswbPVy9fVhhPykhpd9dhAtMpS8gJqNl35y3KY3+xpU6sspXE1AUvPnuqPj1j11TxXWCoNv7I/2ebXbNJ+CkiK9cCr0/kL9NOm1qLfw95HkGI7/ar5iTaHSeDaqGbJdnoAxBuySBxhfAWeE7BtoFlbCpdZSr6/lYOlFeEICbEGLlF4dYpHId/2ApkHDqbN3KD+vsNkzME0CVfsx+ubu0AVvoqkhTzkongwzyAhw8kA8WG49NSvm8lkuYfijDJa3DnvuiXFV77eZbOO5QQeeZDbPwRjqTZeZaKdPajOroDcztqgfbIanueZeZ00VcqhEuHuO2BxpF6bi2MzqinuJPb6wkyNVfl+vV2cmg6HTiMnqfikFljjrQPM1jehdtvUoQttvYxon6SBRxDgApSCaJnaA4qCmHLAyDnWGkjTvT2exrMOd5qiUuw8Zhd76t+iTBgdGu6tcZ6Q/dQBKdgskPjrxKIeDUv7FUyBjNT1dFuoYw7WIyoaDSE++dfm3mQoUSKt+oTJxvNuaZChTJuYHkDzT4gM9sXjXBkf6WSTSztnvs7XnokWary51btgS1EFL87uXhHkvQwV+HRlSYtX9feADXYXb0Kk5K3C0Evet5tCIc4kQYsoV2LCLVYTDUf4eLEziJ4aSJGRoTWVxWtgEWZPljLDMZu8U0afN9kNMubfUqo1K1ZYj76DdKK10Yt0xKGagp7TLB1/uzfU/nGaL+HidXJLO5Cr+E04VJB+7EgiKE3c0cmvSfSvVfudc5FWe166NQT54z+lxLOYgYPSxoJHb6+/88uxagjyAlDEyfpQ1d9Emaoamw7qvMwMdQ/aGVOULBCkmmVUemJLk8YvSIb/q0jyIx99mxi7O339pxs9/SqmoG+bOR1MZPqgVwt6/mZSIh/QggYO/f/IQ6KIWHuLoCO4wRWV9os1LSBu3+oBZbJBICFGLQQzd1srEzyP2ELE1LixN+Fmps0A5MksqM36IQBYxngTpM/h8f9Q+OlkLfippb+k3IDRHNpFM/lHpjT159B7+oOOxshDuWjCuaZsQtNCdkor1GNPyaOTpWolgx2+CHAJEhcCVzV6ZB1bKt2aLti5Cr9UP1bGN1ahqMa26rVqeEY3BhtG8dLb0PlglP5DpAt6A8ZYNxVsAxT9TFbnLpXVX4CME2/PzJkWbhldrRhXk8JcYstiGNiMIKzb7/Ske9R0Uw6HKsQFkFqzO/QwUUvSCdPEfyvLwD57/gz+eZPjwq1kC6STUPfnQ9u9Q/nWzkGcXyY1zoC0Y52W2sBdImEN8hh+TejGjEgQInNFflOQxa9xOUV7FPPM0jFRzB0nF87Rwe3i7p0GNVUEjv8YDx8FLBcVJJcBT5gzrJcbdv+4PO0ZsDXJAS9deTIg2IxBCPJK491MYP5qbQEdU9WxGKiwYUYsRXPw4gdOOc6HFJvu9eDqd1nltGEemDKVb5bh2q836j8G7+FETA8W6dHEkXsnKLCl6u4pRl3QmI3jzdbvHdbOmBUGOPFpNy7zPrAAJeIxB4QJxuIUaZNuNT230dPTz0/lfjTXeUVJZ4SxiBDJEtoinihddeACh6MOw6wayUXqhuuDhd1CPzdiwoD0u+HleBhULDrUscJ4w0mjV8dr1IxLdm5YGjVVlpglzmj6unUtRhJ7Jb3LqP2P6dYqb5fQ/rbQ53l4pYI9raTY6Dpnr28KiajKx+wYJEBhBpfeGV6z85ItDiA1P5v8rOTcfLrtRVG2PxBEj2QnYBUQnMazvysU5qdYztRDrKJ/C0LKg9t+QDplPTdes4hxpLmH8it4Xy6Ck5Cl8ACRV0OCr74P+s2Ku4sH4duCkLvhcE1L0n23kkcAA8hqYb5AQQ8wbc+Xb6pZZhmtrPzceR7KwcTfcijifggKugEeqwHPv1Vovf5EjCHC2XnmnD0vfGPnA2LEaWUVwK7kwGaAeADlJ6g5T1+R3jhlfi/+bqYzYbw3sK97J6obprMfAvflw+p+OPn+jU84N98OK7QvlHKwZ2gMxplR5Ae0N8hrss04xZAJwL8WsLKhsM4+aqKmNPm5Vc5KQ+/atkM/8wEDLbka9CI4fDZBIozVw/zPq3Y7511lai5Rx0zNmRWgSNmfcgvCLv0htehRZ+u5B/dGq/PmojyDUK6peZoIPqahA4i2zCehM21Bq1Mo4QPqmzIHq2olRs/ljR9GzOiFa78qTo9zxOQ4yE1lYB/t+5FvTJ3f6yz+b3t5IEg0wsHrtUNW/ezCEPFwKKFjNLpps57o8k5EvsOrf3P98eHrGq/39iNmSiBnNoYMi/ezWxCqqj8BwbWI4Ox13IGtOtnjNuyeyPERE868dxmEo7/3lhminZdRPV7fC7MwRMZWmQcWCk7uKPCIY31FQvYUveKlFc5PjY33ofLl9tDnWuAZ2XI4yt56b18R+KG/y//nPL64xOqvQwhHy8r3kCQ0PVjo3gW9CXkS7LI6Ur6CzI+1S9x3MmyxhzE79PW/0c84Q1HeHzUSDBHW61cJGYTx136J4ApiTIuPMZcf8p9Ai51kiSuemNFCps28Edq6lCiSq4vUtfWvi1/xeF/asSv8tJ4blv7VgD+/8Yn84P6z1siz2yuUUY113uGmpYs0cMm7C//nfLcSjiPQKfHmDL+FrmapofZozxJwxPpW/S7wf/4fmIQIvxfWaQmG49MjAEuEbaasON7BW8EiPjqU6W7MHEe5Jw87zbBK6xZ3SxFs8c1fyqO7A2w+wIVC0Fkc0IPY5FbFGoKSUUgsAgvIm+/XR6hyozcNlX8M9bntiYmbBDk7AijIZjmIWb37F7CC8YeBbrLobjESbflGw+0JcE/0sRq52lRcg5UCQiYjGLVxnwZeS4KIc1YlpQdbxsE99XRVixTADn8CrA14LUdu+KpC2A9IG2l8jZ1zpiHKEsEarQEcYTBFONdA0gfpvMZ3fmEQUjojBVDh2Py/B1EoMKfDO/ZfS0ToJwkSTUZOGF+TKsR4GOP6BkWiCag3P8deX9MjEyJ294uCtbwBND/5iPCG4/KiQcvvcV2i+VCXgLfNuIF/HxnyyhW0s6KtVNmrT5RyoMBGdKNNlujwlKI7k+NgQ1s6UnKz0k3P3ZR1eFlNfm/UIDDB4PTm9or77TYUoH4xujJge22iR6rmcR6+6AB/h8dtJdPXT3lI+IRkrU/HOpi9pRjN0ro1eRPFFGytRkNWviNm2nl1Y/E/2cIZMDrJSKn4s88RPDnk0pQS634SGcyeOeBKG9IxSM1DE3ssXC7MadhV+xpAN075Z8IbfBaO0VGnxleMWUE7HKEvxnZn0sbJ5+QlumqjYfbFV0LwKcmPVfYdf0Y1yyR5gZQoQK56GpYfWkrscndPIKLLRvBiCD021CttuHna+KSSOGMpslKed4bQHhmeRWS/57/IkBx/1djHpa18WWcP3y129I04MFjpUXjdkSQzOuSVGIRLQZ+i7ysW/26gu9/uO+uV57SX7aFEI6lLOhSRtcVCAZiFvsjcB4dYCG5qo63KLRTn3oHvvMPsi9DtZLTmnY/HckQLfyS41WDTvz8+tF6HKH6ZD6dFRwcmsnV/tpP6uXV244fz1PPtuUdHhrWU/qDFPtTYzVJllOrjWPCl2Z1EEuqCfm83lKfhppHla3G4Rjsj4BeRl5wWmGe6+Y6zGoBvHX6ZPfrIMo7jkXV2CTqH2WVHW4YXDy7kDoZowSNxMAu6N5tMlf1CFBV3iqKVa92pnSfbOiwJcNNmb1ABxnxGcHutydNqLXITnq+w62vS/XP06+UQ6G8inYUtCFKTMJXnXMG/hwLg0bZJ6nQ6jEQZ/d5Qcs2TGbE8kR/0XIe/vwrj1h1JJK2UZ/1PP6mbDzRsdiN1FpKc5gX+Cg/xIEEl2NfbAE6RWU+T5vcEi4q3FC2iJUV18lPFl68Emupxpy8kCsmWB8GdT9bkJU6YThl/3U6CtIV+6oXVpz0VaXuR2CnEw+HgWzyiKkSgOtPDaB7PI+qGXbpTSYOq2tWE1ERR7Qyxx0ZATYOHtFUSo9tFWeRqDAvuWxwxoRPMdYdZCjCdyyuf4EFVzzr0iS812v4aL4A1aHWWWErPTamkfYtFLLsbqSJBvHpzJgOVQlMOms/jo7NOL+MHU7Jv5EmyE7vFQdfnjvQd94eKrvCcoq67lU9wvNhf/rCCmCF6enWTid7oTd9x1E+wqj2SkjdJqiwkOR0gGGpqXIyi9e7cgAAp2wAAQnLrsaty7WlBg8X5xTGBqmcjM6wvUZwVMrcUInGf8Mtm+u7UvIhDdNcmSXD7tqe+Z56qjBNR+wls2GMx5g6+6S3nVf+SMBqI4QGx0jTzjSimvF9Abn5SALE686Joqy3XeUsGVVeZBTYSRaqrO3SNCuq715BiBraA7NWFQG0SS44lMjkVtw7XfX/QeKCSCTkwudrPEPB5PyDgRBbqaPLemtEno/pyWt61xR5TDdqJW6LV5MrpqbvlPbA4+aXUUOWlWz6+OC21w3PW9wjWAaYObF0/ZblEflc0a7qzdOEb6oK5ojIiOXxBofBSN49EcZ5X6w7mJ0kUu5AUrXC0a3V3J1vbfWoFPtNWODgr8b2pnmRvDOKkZF5BckuXNvLDUQtv7jUG7whCzmIWc9peWqFJO5jEPQ8oWfNfz4PKmYGG6u5KjIOIodeG1TC6DIDslRsnyh/wV1UmR4Nkt6sM7d2T/zLIuSKPcQPugsnIQhjEEKSThXtNFEp04DpWBRlSTSQAqY+IXd+VTYY9/aarONPwRSPqjbGeIEfKFgujUpg+W7JBLxENmS+fIEF0zsJ+yRPsiEDGWbUgErV9t8mukIiF+6ENH/q4nG+CUNUiyKSoeay7Xs+JKQJKyXZURzOvpsEk0n7aPwhGZZzvl04tlFX8oF3QHmYETJQJxyhrQaNNM6Rz8D55aB8cj3LDr+WgW8IyjKtv7IyxBtJpiJUCMvhcryE3xKklfA9eWuSUtL6QLXygZkDovBeVA+BDKne0CzFmRNF2lPAMdANYFiAChf3cFSWLV0AG5EcS9crPB2WeqDe4z1Mn3ywilOpfek/OW1ed4eMZT8xXRl48uY20UYOMRDwvZuJw5g5LOfeU7CzCv73anZRTwKwsi59VYjtcUV0RI0K7UvbxVhGTPYMQyZ7qRazYwOMRU1ugAvf2yfEWFyHC3qwjz3fSEdsR1FX0rRTyV9vw85oEyn/X6BQ3pwWcJs0x87djdd14quFpPHgbZASZStXBGojgLTq8MHrToQTP0QlSmSfXRync1SfM5LrC9A85uN1XceSjs2y4+ar9/UHbxNwn30OEUmhcloj0q8mgs6YkHm+8EElYF37h0WsuMG1OI1wERvo/Lr1K2ftzau2OKGyjy+QwTq0H8nNR6bbwviayBauC1s4kTcin8Mfux0uWVWzepDTpKYD9hAMPU4qDeFRN1cDaQld1TBm9aPMUkIMcV5csyJG/MKp2OYPe4CFGXE++csQedQ76WD1Nb+p/Bd/KE697Uql8CCkBBQovuRbQZZrBzUBUP4A3waacjIS7H1R9o9XQ/36gKGLozVCbGwJ75Xv5alm7KrltR3wWTEDQH3ssilaQcP3+BAGAmYciuTZK/YA+5Bawg+hKI5ePM8hbB7yAvz7gkP+vYeQTLYL3v1zqHOYeDFWClLuPxh0/+CGawTQp1KDBVV0jAhTypWijtAORNQB9zrV5r6VD4gcpDkXimKs4GoJNVRC59ja7CTyhe3RL3/3JkH/BFyDGnvbEj7T7wex8DgNAc0FaCHl/NPtfDDvR8Dl/a1Ql0dP9DPjXc4wfBP04KHjZMOMkRnbYOyodYACc0BX6XcHXvLLQTqeRjf85mDy4S1XFoKfkkcrJkd+11kthVrU9TO04wutCKI/eDfMeX6Rm5NiUXlvehuaY6+x9lHFZAmvtMngXCR4DIiXIPtBzDpn3hZ33VsEtkCAcw56l6FNMXp11tbSjvQaEE8wa+FYbYex8Uv/txNNLsKmHVLkjUWF+rxbObZ07ukn8/5kArAE9KZGpq3pEgDPMAXFoiHHafB72TWp1fvuBL/mebhdSyJHFu1ZlND0Eit3PUDm5p/jIeZ5SPep7Sc74zlUaHG2AzIZldtQ7uO+szzMNfN0ljBTdKWJJM2ggAACgaRtapguNn6NU4LsZsXX8+Ki+PLnJBcWLsCLLCJAuIk/G7CpsZduoMarfwVIVg3PukX8dz+/g3n7M4gNf4ZDj7yPNDqO7zU8nVznVhf+M0XodEWFd1lUrmEJ7GwCmvouic6u4rJ0mjFW+5smccM1rpuF7KPaT+NbejKvxGnF+WS40WRtfBMKzzMQuioKlU/UR83IayP8W+ziXfBUDtZLo0EftatmmMI3tiQC1l7ZKujMCqxT9tcvBhN9bdpvlsW2YYJApRkZ02WtFblDpUrMnTyKHpZ9TstQPwCBeSPvx3an9ARM1Qs7xIaMJRqRfrGT4qLWc0bo00nDyXPpch/ctFaM0PST6f7cq804w5Y2iYzGHOVPARHWli1+zbLD4e0Crj+tPoL1VNe/j0WtJHglDCV1/3cpTKneOM275qNp3pjnhclsZO76HJujP5JvI978nlabm9mmynXLjlyKcCduVtz/e5s5YUASA93JbS7m/4mdURDBg1Zg4trqeyCffwRsEP/jPVw7kCqr6xINr5KLLm29g39ORqItsgJXN5SWWHEr3t0PzkVBhn+ElT1yttWcplQcGWhU32CeIHI4jtxDd9pTFKpin8PPnYrNibcPQDiiLBKJEEIWm4w9/76a05AkU+LxC298YhvAdGRmw8C7jBR51BJepZ0ylKGj4SdxLcD3TFf0WgfwfkajwlYL9qAXeHjtTHaztzIjbh4nZYMX758gQrEdinJF5NphIZHGvf4/gHTZru1z9qYm/iKYw6/QVHnFT/pSplleyrN91AyX11Id7Gzi4BJmQI63LuWLHGYttc7da8q73JdPHZwCv0hkR2IK9o0j+VVOHrAdSV7wPLe3QFLVe9C++YYNYjtPba1QoOaZJsX8f5bHB+SLZfc0XPyclMCoB65pvh52ORGE8kzYwfDHix6WVpO9kVLRQVABvjrr2qZ/VAgsj8yNI2/Ou+h+F0ZXhM6SxHypuN6d1BCcZWvPNudz0G/wfaydB3Y2b+IIV36jl+UY7iwCO3fYKhIFOHSpnaC6frB30R9kUzB783hNxu7v2wl/P6bZUACbsiqPFIgQUImaOzInPMq0WFKIP4t0k8p3wwonIcEHACvksMjxq9MmGs40k705hzEL9a5OpLTT7+ioC1BzEwSBXMZlXanSvgrwg8+kxK1172JjJuh65C0KRN4qXcsFQl8VQjntpSgy0zAcSAtSGM7gVW0jvbGlki8wczF11T76IRTmstIpsRmw/oDwxGOVGtANcaKQNWVD1zabCxcETM6ybXrbzJZodqNQkQU/5M4Cj3lhyvXRjALCU06o6UyGJD4hBmnhvK4ps+ak2J61r8BCyRis/6D8Ecx9gAYBQcHWWUKntUXfExLnZqQoa65/UvLxyacChAl3nUsyVTOl7rtfym2qdX/Vx9U8VrO0oM0STjKWf8OyLYg6pggaliocwaqOSWdLJ853dBIQlMGShmBXPDgkk9j3Sh3nhICKPDPh4oINP8JNTyPNFc2m/YEm2ey+MEcglO+wSnyTCmvzKxQAZeKgjpB9eXU0jPrE69ejv5HTncTHp+fVLclTEnpxs9L5q0OBGai/AOFTmAqKdVKRDuVcAlmmpmTTToyGrJbK0eo2VgxCt7aVX0uh3wy+uRtfmpU4neHGt/raU4mXwZ0nikJegRUObe8ITh0DYXEvGM5ciaRRkkHefRbKRsTRHO2ShOXCKTq4QquR21NkPH4c1dk4Hil2o0pCmf99358oMamupNRotqUlFQqHpcilqWFjIuUI/zEj1c+SrPFYoUe40w9fzS+CQlwtpYRcC+gSgaBTl31cALOT7tqCy5keeaGcbgA+/YWjq4fvx31uZgOysw8tThoF0YfZ5kmdrc0CGtRA8Z4Ke6UlINWY/i/hDu+BN7RykJ5Os3vaoLAB5aEAM8ljecWZTd7khO0D7dSHEDJyi5QGTNUeAPKmPybxZxCYsftmH5NHZn88daG8rR8hcm64IhE5TP6h8M5+rodJIqcfRWkayNA8OoTHx9sAbkhARBz5O0jWhe5D7YVLZ8PJGySAhk0vErnfHdwG6X1tSbD9vaOf7XiUxvDBsmCt7s4TGiI7tiWkJYcoBxsnv5q2bfwRidrTAFSMOy/UR+WUwn4m57rsvC+sbp0vCXbALR0Sp//gIOe6dbh9lvbfrRT2p1NZ1N3FMgXF1m22fyL1nPzEYfpDaNoY9D5rYHJbel219tXSn44mb8U/t3CZNlA+G7sbl9N9yQYZJx6izWOueixA5JgzdlV13Akl8ZJDh+vqmCY5s7AbghfUj/oZB7IazHJqyjdMmx1k4VNyITn9YpnfxunFaUwVSJk3fTtrZdoeddSoNW6hKkATk8xSIFoIZpVxvBkMrzwAwdL+bsM+Ulchpc/Mmc06nPhmoKMfLy0vsZqXXcQUKu4tl6CRbmAVSK0ScoknPe+c4DdelCprxX5V4vDjpzWDZC6eUdZUC2OExIcOH+HosTQX4lnEB00t24NWsVhgR8/vP6BwJ8v705ngG4WQrSwAobVEz9pBkxqR5Y53SrFZkqJEHZFnL8MTmvKZ4lWQJ5T/12jdAk+LvaloCsfJYGWraUqZ/u5MjKlSjJ9+92sCaFxuGG+9l4cz1rl09tqyRKFBJZyHoZtRiBYHK4RK0gFvQTVfDWnGNySC2wJCNNin2cFIvUrfLIeW79LXyzzpmdif4uKyd/iQNpZxU/4DpKdEcDYTyhgaAcn7943piyes9rxOKDi/gl7CO8Dzw0eUhNRzn3AZtbZiLMwlYHRqqMyRz9KtPWwmhgEwzanGgzCjWn9lI3JhPy9XZ3+W85uuQjvX26v/xON/MqnEicAjVLlOb6jON0FZXZoy9at5dOKkFThdcpRPh8JPGKeGEIvPf/fQp9C+vqZIjO1ymh2tfW7gbqH+wBvEGqA+alKnUlJkrbcyk1lhEtorm98uj5Gll8DXvlb0lczmsrFHNv9XIKjm16kps8E9m49R+EJw5QTJskyK6NDeMaDI7fQtSDrzH1nAEtfcNW13bRr54roE+o8BvJfKLwwyF2bz/YWWWiuYgyRTJ/gaCwPDqFGIaNh2/1xz8IuC+E5XNfv3gGuA8KWCBMAtmbVJ9q1fni37T5oX9NBssG2CwW2JlBLbVjUxJCJIA1x89wOpPbnDNC/3MjLhcAHiy6cXEcobN/NGg/ADAvnQ3igyJXR//s6RROllh8MUhzFR+uAG70ZHplHf96Ve8qMLP/s5FJr/aCamqxRkCRuRzBxn68lQNsbuWJeDbKi96W6h6AL9xFK5ae30LPXcoxxKrFG3xrXpmk3A2Zf2bqK08hLKa585/dhO6k1wbbzy1H1jOKzkPJQ69bndw39EHTHeqNPc9oDbpOJyNHefSgqyfFCiQKE5EYcrhs1HnMGLX052c6zIWQ8xTQLbKNQrNcMjeFBoUw0sqx9Y945hpTCarq21b33u+VHTW/uEUAJLOAMzC1w6y14TKOcBauOl7xu+HZbuWPplRJpt3BZz09kdSRmCAm2Hw6eiXjJIlgxxjX+SwHJ1rEPy1II8xI9AiYUmA2NvOlOWcbCQt3Mk+WzZR/WhGXGq520EmC1dhExYo7n9UGe1/xbk5f2yeQobJtwxvPn2RQW0vafnCDyHOz3azXp26TRdA9l+OGqj+JWR1qGyDogw0PKM0Ev0dQBpWtbMMh3lZlVUIlNsAphOoof0dxNQSTmDt/R1qOPEduYkNr3VzZXbrtHy715OVYpN0lhPW0l1ofpO10SyVLo6WSuht73fmWCY/tEUB0PNkAVvnZT7MgCvmCY93j2xZRKli8kSSiUe/wveonysoa0vZjmDxuyXHItED5cxmd34BPv3NhRyD+6cQXYUajIwgSee7ugHZKMUWc4JeJUIbh8mBBlpLk+Y245/Dd1jsX8EqNndAm7AQgWMRFvCv1mrU2dG7fygZUFq3Ewd2LZwL8mwlYW83A+pTpTjupiE8cTGgFgGBy8IP8TDVo2okdv+Zh6hfvOCE0EVIYso/1tPSqvwh46V4926HiC8R2c3VmNzy/AwBMxfPGDHeRBybbTZY81imHKmLvnaIM0EOGA8tbJnFmXZFnteZZikZOthGI2zOp2kfg6e6SGpOl9CtxaW3Qb2hIWxUnekIlLHDFN9I4+OmIRNqtQ0OX1jcwGWcdPgMXKw7MrsV0fWkjzSWm+zJYTaLVLkeR+pfAKUN3AJ/K2sN/UyN38s9dDR3jCL0JBEyUKjwdxvSpxYri97GpwuPdPuSNIqiW2iqn3orzZERko3/HEoktnPGPp9yM7CJI+iwv/O5oTSMAsQOcTuloc19gRSZi/hH7txoPVbF+sFGKVPvu+P7TSrgjJHokyipfPT06SHe9oeIK9NQG9qAtfzkQ5DA861U3CrLv8iKnujvgUn0GE0XbvKqoaH2PFIHrmb7DHW7CwVRBtn2YtlbqtOEWCONq2rANs8dPxz/WYG4Q08ectFfgna/jVuKdp6PM8zJwANvgyI1ha4WDNcKA7Bl/Bhs4UKD55KHMNgIRxOoboeQ9rT//T89TxwymlyjaD8/Nbmcg51xh8cTK7h1RDPFwnTRQXMc2bfMrc1I8GAq3IFeO77D+piuoSFkzXs+2RdpUHbe4XMol9/+yQcYJsq1mmpzIz+3BYOwcw+6gSzt2KkmCVFRX/Foy4ulV9tz2EmgLGIDKnsHoOdnhM2kapOJvYmYajNIl75zcTg2Ok1+cRDbtDoaCYGRpHIXTlLy9deVuT+DyvqiIxd3HyUIjgjsFZ+hdbSrA1D0yHCRa2wnZZd69J909Mr529T6CzlFVgphcFXsarpJuUJUq5qwKcdgdTQqQVww0i3874Jq3fH/IFTGxqtHbbOyFc0SvnX0XSuplB7rzLfB18KMmT6/b6sL9kc+v4S2SnqdbEv2glonSLz42e2e36XMPrhX0qDAU9EnJXrbSvDUDAhtQFoklMwc/ddJ4NdXWolbgzezXBDswA2p5tCVk4RbbzirzRkXkwbktEgpfwLcl44jWqWh058FUS+vXK9lS3twuAHs5L0T8ymDT485WAOHptnVK9D97V0YMuEbbKjFsHBE8RlJWTkbV2wJI8BDFZxYHJcLEmmaN6YbtVn3Pynxbqty193j9FLIrVo73s4zIRyXitlEtD/0eUGY+70WuNjQP2B1sT5xEjA1QsSMuxqsP19j5IekZqh9H6vZAsiqG1DOSKFyZ4FHcyqM9r/nmaCM4oX+6GbnWJSVbkWpAFXBx12GEumnp8FhlAtPxKaLit7WDryJelK9gdxnpUnYPhmsa0KSY5KO+Fohlt6tRRrg+xPKmPFBI/FvhITUd3L6fPZimCoeqW6unj/AexeD9BunlPaafPs23ZmEqHh/JcKIyIAieWphpk1Kr4W6RIvcTZWNV5lSINbwXq1wHSgksirwOAj65Oceo1tL7B2FjKzK6fK3vhIXJrhcA84OFUK4bMPacEO1ZCsYvwo6k4f91DvRaXyBss+LGg2C7H45hZw+dRo0hZ0qJJe8lzycvmuYl/mAt0jlrxGidL5thc2hruVuBK33fRI93wSc4UzMRdE2X4NEwGDeAg9WnVzjChPwRHKHr9jbuM1HXRac2b1dd1L3iSKsw6iRr76oxmKbz5ZBrSg+N7WswPyzb7o9v0/HP4bM0eXCByreSP6kBWUDUbd8YoWZTmyqlzXlmXKHcBRw8LFXL+JzACS48/RW0280b5BzplFTL0TWtaPpF9tCav1gzbOzsqxRBIFMJLtF/54Vk5IPzLdQKSbVrGqHx6RaV5qGAHCh4omhmVr4t1F8UEUUMtk3QWndeBqBOAVKqCkT4I1+eJzNJbW+A3tYWqXQuslZEz3vNMIb+qQIZ0tBmcVg0SJ1rV2YesafbuSS/qSGAKIcpHAersYiWIUKrCOFTcaS5GYRFaOCHf3Z84n/0MJmZvQ6W7PXP66bAmPFDM7jZKEmB7Hqz+vZmatzyATIxp8wyBmEMd+Y9dc1qrm6CusEhHIOabekfAXo7njayB1FRn8s/nco76ym914fBTQdH/+Zdbiy2gCGimFT3f5qZzdPf49HpSvPc5j8dE8ZaRkOshgewAnQObAChVRNYUr8JixGZN7Ft5JWqtsCNj98Rej/hTgW7VjxUZ1uCu4Up4BmZXB0u//nE2/77jcvkTl4DTD1Hzh+HfGO7q1R4w5TFyN8cJTMC0Rz2zTVC6PTRzuPeyFPlZeQEWoAVbpbJzqw0BvhF4wQqV5lrm4R5O9qdzoSQDQTolwSSxxM5PcksLc7uPFJQVWY6tCN6oRTZsmE03w56NR/p66iiuAQGhTv3Z9W9PGxOmfQfIH6laXuLSwn1fQlZoNaicanDaToC0cp1hxmcK7w+RhHzeKvO/D8457FxMRqulJPmOGVJGxk2TH0TyXRexWbn+yFpTUpIm2rTwR6Z7ym+fwgqygyuYd0E3Dv1InZe/KqraQ1Hhd7zqZqDRWL7VE8yfJPjvvnohBXRE2qJmmknCQibfr3y2S+bFMWQgFp/oniGBUsApG2koKXY5d4eAm7UnB5s+dYVVjVKpnfYylCcuokhjYvUvwWPoV0NWfdpfyqa228QSRLmeuVcIJMXok/pLfrr1/H6vsCXATWKCfhcJ1nRez6LlnFnRdav9Yxeppua9s5daTFqTRYzn9W9co8cxPFV3FWilqeqyScNAmINod+jpZsxYClRInePMO3x8PJJ9cKJ6Mg1its4QB8uyqBIKktMAMuADjo1YMpxEd1QiarjmtfSIW7ZnS2OHgP3OqF4yoNeLKMLz8CwivumM/YiR6iBgu12lNH5pK1yd+7g1gq9yCOJLVndSe7ZZa6P89CI+Z/FI30MIkqAQP7G1cdTkSj5QNzUjZ0dC59ZL9TdU/4rHtQy8FPOJulAEU5GZ6Mok1Z9l1Ws4wOi5I9BLLEEdTwtYr8ecrvEKCDukJlFtOCJdNt/hJoRKcO5AWWgXxYtBUVGseSi3uvZL4VnkKDoiE65FmnFiUKdVthpIrtBX9T2xfthcQfC/pr7NraTLJBQa630/UZtm69JNvacdTgAF03yBxW13YzTCk8DyXdcyfQzDa87avIwRMmQE3uYcqpAaLNF6h/HLjzsS5feR0SzGDmeYxCxfh0tDZLXibtA2d8hmTAd6xBxr1s/nlbJL2MzRM/JXRyhxGeulSDqlABuAkOjhBf5a5tQ90S1qvo+NrEiUQiGn2uciEgd3evnh48xE2Rm61N5BlbywBf1i904LxlGZYdg/Zxrv7gwlJT2kQQ3MPHlTHcb1J5q8ZjXHhNWzpTiWlmvBn+kwuIqQV2UAwzUv3vD0eWh0rD2hvNhu4YY+Z2t9T5nVdwFZlK6EkDCixNSFKgoc5v8Xp0hpin5dSXC3uoBdtQhybqX0sxYs+eXNCMUelsmTkirHztaH2nKphE97sy8MzyyOF7Lbu/iDyLECAWRXex8C6Vd83dAdn5FDL8WZLLmq0ma4Eroft320IF4AVJg+5nej6EaKg6D2p/+cXeVdelwMpaGXDH0eIQDme7DWXNBp/i7nEIIWnLdrLG9VZRmFdW58g6JzIRuQtCKERHyY5SaSZroV+9MOIFbsJVJN6NoFFUrlgtbOG67V/iulnTO/He87oDYow3JDf58nlIrkqGYEFk9Cco4cupugeLPgo5lBPQmJiAePkPB62RpRNZZ8//e01ZUfWy3yZtcVPr6rNxRHpEvJZWoV9QWDabHlQ0yiJGAN9JaHxbuygPm+QmXdc+69zXAWqC4N2wp0fHrNpa1qxNfYZ2AtckONxbobhxl4f9obyJ0aOVmDuV1PyhrAWl0NW55FRh7/HBfgIPjPX2JY9glrv5eoAmCanZnKKTilg6SbE31kbWHjKXmtvWfjBUKhEnMCID3QGQ7p3s7sCdgY4jERJAmG0npbABJoxpN4LMqe4aruhZ7P5HYn5vfujLYEts9rytW1DQFuG8WbUeSVpBMbs1MZ5ZJA/gvpatXYFmyfSAErckjBIM/dqw0Toj7UgGh4HSaXbmDGHVKuRLCjbLOSg2uR78beGsnjUZTA87oavr7RUrbv6BYHQiSscxrA3deH59DtGaAj9uKa9UIfJC9kcpncTQCW2ls2ZKd2DmiWNn1gIifciJh7q0ODorPGcEO+cUetGOUIUvek5CxOlMYWMs5Ga0tMTIM/rfjpCob4tMU9400m81RWg1/r18BywO+hOZJwL2fa800UAZ309/EVsJEDoK6MJxfdtXXEo4kDd/LV5sClI7RSpdlB4BpJAvItrIlrIZPtzmgtZT2LozOfBKMNqOS1wwS1f+rF7O+C/kzOhvAPWUdYMlqtEW6FxhSkdEDfLERS+HZfPRkAhtsYk87xbe3gvwaaj+WnWB/H5WdC0Mnf4wa5aQ6DNfH3S2JSi5OtWHJ7/G/42r3+HjHaAFUDIJBXyGmLvnpzq2KndrDU4bGOhD8o8xUuAa2Fi/81FFjxL1Py/MVK4HsoESqaKnl7PeJ55YW8tgPjymFZ095a2a2bEZcM769RUCpv6e4tNnC0B6i3c126C6o+GAjJdHfUsGpN8uiS1xCmvEWg4kUxCrTS5tBDYR7j3oSkC6BhMpFRJWJgn8ZC5ACKagIbwascK5dC11oI1Cyz9Kc+GFdudIf6oevLm9nfgXWpEqCEfjLeh7WAmshopzITD55HakQoeBVWU7pswlb8HPilKYUkaiqg8uVYnH18qgyOGa6lt0HGGZxo3sq19mI+eKTPjD6CKiIFkB5OaeFOxnqhDkhbQJG0rsfJ0iqokxnP3qLrTGXzPvi5YMYuAqvg07/5ZQHZoK+KYyhGInzfnKIXf/zLeewWQAD+gzlf2KDpfA36FhBBbsst5Y0UZYEnQ1gm2ABUUWaFcXd4sy8vjQ22wcTncv7eeB4PZaVD+88ENg5g5oy/H2RMLH4GigD+Iyv2kI6Gd8xzZwZ+k8c8CmghUmQqkHfbZP2O4zGBOAG96RldaxGVdN/DaEy2/G631cT6hZ7PICeTzXqrwLzprxEPn+qP7mSpkQ8jMC6i0KhxiG9Tb23PAtKcyPk7qtfOFV7ql3hWKX4VFYvwG0ZsJ1geQx97JMV7IiKtwAZjL+yBZYNXTXTP5C0uB8gHhnf7km805qQkY4RGZlytfM/oDRFCJTXNmQ7ZZ/rjVUeRHr27DHEN0FkAV8RHFuSsVIqByIsUrXeJgRR1X5srvLSTWzFdTRT4CW5nj1JQAEXSiyTV/jZRAFOiQ8utpXDfvJIt9nuD1KIF8PX8zFDC47Bw4ibpoJDZp7BzBWjGCxT08wqTn0swT61tRRiuq7Cswds3R5DAFrwDbWJiTIKwJNNfDf0NpWfntutBZxzCBjvk8XBQK41zb7wjeLYb2JRuMRSpFYit4IOwIYA+uglU5ECApeTom4DMEyfGc/k53cFMvOTf7tC6xVLy+eOzOXv/M7JuOrkJoTU0W1lOIZdNTzmpr3Rf/akbObnfJmDOufel7s1xrG/Saz7RLOCfxT2O4HCX316jHRBr3onxZ5Qpzhw9bZ220J/cWak/ZkxmGJYYjoaFigJ27aBN0SlnE/4udWanGvLO+oZCTJsfmF7w4LR71gzO8rjWHlfBucVsSllOCYxtL/imer8AKZIpA49gqr96R432p+KXpcSnoBAR4+VHcz+E5fPnCak4gxC0fteGKkR93Jmv2Q9GknDXM7xjW4NGC136xB0/TCwt+bwjci/TQJVx4Hxp62XiEEQxs/cMAnhlY9QoLZyCjKmzCFdValpX9arnJ/LPhjYmR+lqBV4mD3zKv3Vb262NXrqXpsTVajmzCnFO4JhINTfhw6kYcDaNf6xZNWnPqTSsKq5OQSvJ6CXGxRxZuHqvifHmNr9yH4ymiJIwo1we2+orLRRPm0JgTpFVLbju2d8pQQ70OQm63jDjNEjJ7XBfs91k2Te+oItwwOMR7jhlqUfLvnZS8m1ye9Gw4RGY9N6R2RMi/7AK0jYJxPijfVEiCPrb4851TnyUWgb/0V8Lw5aL2cqfrr1yG6CWdabpHsNH4Y6eZ++BUyEZe0R+zigFaxIrwfEiDaW4HRiaJDAh8BpBMr2rndS8iwXI5C4XCDCMYay626Lp+BMPg+0h6C/TI+63hhJ0gSXZGW1eSMmJ9/pNAD+R5o66U8bsI8cv5MKBr79S4EsrAE8sfmue7ziUl/q9Df9jcAJUoUMLemhpnLFRytz92kV2CWmX3BuXNBfP7mkUO2eG8Zr7298O9LGapDH8HM6D3a1qC9ERP1H6zwZr5Isy10VTBy0DGBddinLKL/d57UD3PV+uilf3BuD4aDqNx9WOh/qIu3Sswj4LExLjMLxe+x6NP0SmNr5CFYCIpKY6K9ieBc3tLguU+3cIX4jQ4q1u5c0tcvSSWyHPimcNTS96Ynr/HQ8Vm5/aGUnLK2BkvHyBGaGk9GOSRuX8Y/K+yGUTOsJr7hVfraINcY++jWZrb6uKTZ6iNxmQ9Af8HdR3AdNDxVzVnqZv6qtcaGWZsUl1cRGhe590ffplE2PtzGDnXqHyO7kIbGvunTPagmD3Es381OXz5Uohwj/E4pazzmsbrgPTBkr2GNAuD74AITkRJJwAOP45xVeqx3fJUPwqNsU7q/ZyI+1qkxj+Jf++XLmeixMIF+lwiPYoQkntHj9lLfPkhvPht57PPQLvLDJOl8XqgmQpYeWKmXMdrQuOGNvpZofM1No4B+Tq+gKP0YfADojHmpb6vJ3jlEbApDnLofSQuJZmYmTjNQFUz0CBpSxQM2EUxh7O1oC7rAPRWFGC1g79C6DvRpQ/FNbdRoZSXvorMffIr5fqroJjslDTrZ3YyOPHnKxoAhipaKRxY3sg3lXL79GR4qYJr3zy504VSc/qjzU6Fk4tV+sp1n20eHl0Gl5BAQP9n7ALb96P9iZrulK7TE7/v+UgwLZI+JCrjmcCb5RXUdQ9U2s2XLGta84g7199xX7R2k3AHJeCm5IbOs/Q6IowI11shPV6vAZvScJlZSbcvcB0oek/70nw6Q8lKuSsY5sZhkP98K9YyHd99olMIQae6BQhKE2bnawCLmNwE1Vvb2jGTJBWbkMINYMyDervFWwX+L/sy3lDliT3EhmeSMX5g6IbCiYYEd+evrjnbz8ljrvebfXNBPc8bNeewRtjN5Krop/Vuvl0tzczeAXw1F0HoLzBHXkiMnMEsLfH5WcNv73DB1JqWv34RQ1UNMETzpip7iBWNgT0xYpAkIIYkV840n7+guj3pSZ5awig1dhTdQYlZdyrgO3KgG675lXoSwIrv7qRRl77dEgamyjBB8P40hD/b8WmTPfg1DXkiLW9tP6QiKeQfuw0A/B/DWrWmfojTJhCVx/6stXnXezHd7eiVYJfHx1xN61hjGBVrFbSzH84Uhk9pchx1hGNuSjHVSe86FKV3lorO5QEF39APhDdogEeMUE5qutOwUxzD4EGS2tXnk1iedhVVQH5KM3/yS0EikcGHXX8lU6me9KnODGNrwAsGs6yK5NPHbMGdTdUfcrRg7twrFqItMrEkeQAnEl6pswbO0jBaDMtQVxU/AbwJJ/Gu6hrZMQcmFfNuyFMyXtGVOFcT0luGfM36BTK/t5vBF73OjCDwBry36b//D3ZG7FcgsS5Cf0KX67xDYftkJVEE/cpYmohDGtNG6EFvENPYvfMU2CKWSHPjpfJ/ssY2LnpXMoQj0bnJ6v1iQtDXCa7nlXvbRkGiv+NKwax+5e4b4+/qgcgnkvkoDBtAyXXv5uCKjpik3Drvn5+5Pe98MiyT5UCSQXmOI54Hutb2V9WCORbfZlPlx7lbz8O5awxBySBOQpxcvA3V+aYOrntPV7o4130Np92iYzoaKNJBntYflLpMku4LghIrhcFg/9DThxsk0wYgH88V+vzNr5k2fgDnxFl9cGOR8HxPbCjTyNN4cYaa3RWK3FUeI9X57hTKjMQdyn5L8S1y3feEFTbKet32m7lFMfYR9Z6fZdtkmIHrndsFOPaWPinMtXofdh4QewlLtuiMG3ADdUjjtZj3/z/CKD4Eqs+sJGZVkAqMrySDVxllnNlImXrTGkKwn3vx8z4FEHQDX9w8bN6/lMXs2XjS4Tq+Kvbhzcdn3cqVgg+L9AEeZXmNFroEWyqaJY7PMcPRRg+DMnKIYozKnWIC0U/jbdX3hhXXkhF0hdblTW/XnDvj1CWUM0bUxB1WL9EFcs8AmqTDzbuchRmSesqyluqjPZxNF1Kw1B+56i4HREWdlC13wrsT+DGL69qH66lefkR2sSkl7m2W/4PjZ1s2qYNypNmi7eYCHUPsxrHRzytUeOV58UnkPbdB0hGnHCMrrIipLlUstiIp8hK1eM9zH3/9dMStIsHRpP7r0VRwcNL2u7InX4y0uTfpNqrnQ+l1go79T/jI+Ag0oJO6VNAAjtZkE8XQcuQqcmcheztITlBUiGQQEXxoQAWANpnV5v5+Ol4xl/y2UARrljjz+YByMzAOxCgZY5PptA1tQuJPA7l71RdZ7Qqo6Tz5Z/iG++usYeBcdQR/KZ7apzIYboDbhU8ZTv1JxY9R6yu4G8dKJZY+5vWOldxMA0RI53qGYNnOWNaxIYCB/4GuMfus0kLXjOO9wj0VvKrZILXf41OfETrEsfINbfYiLYruGfeb/dK7+eoHAPhXXCcbxa2+PGJRO7OGMV2MTbBRWWKc+1mzN6bMdpDV5adGlssRpCxys39AsNyzg47u+v2eouvA1X33++tQNgaHHS6S7YTtGmp9UKiEb3dFqbeTaR/0w5SKWEFcLixhzd8smeyrbfVXPYMhdGVn/ITML9zRRdXYs65BhewsGAES1cgTtC8fcuR2BNlv81JRCjGVI7I3yN6xmkTInQ1iZ+KgArEha0NWhAQf1ZR/zpB9F3HouP9I7arCT5aoQUSptqW8Pb2iYQX0ZMOr56bQFR7g0CyOU/uo/UKwe8RWsGT7lKRgPQMU2aSEqKPTysnI2xb+sS5yF1+1zMA7UEuFvqY/ANuAP3VqXEcxqSrj1odXGw10QD4TpwxvE94Q+0UIPqcz71l0vqz3SynQUIbGERMOwGYoGsZp1Uo+FmYHjTCk0lZyvuvHeOzWKAka/+MTy31prXaCuHTsSOmtlS+6ajQLZ3v7UUqJt70kPgF+hArhSTkGEIsHaZ/TJaVQWHg9Lka0qxex2yTxbISwND4TIGLOwhzV0YKfKnLNVHVvv5BCyQ2WRzwjV2k8hz1b8L5BmELd7+l/qn43bTOwiWztF3P9Enqk/+12uTvLn47SoT23Q2okbYCJpRZhfesUGooDoqGS8USzU6QpzTirmXgdl+ZH5tMzYsrM1vuTXF8XXiqQzUNa+D0YqM2MqKCyqSpQx9YNDAgY6ijA/PqP/Rukn0Hy26j3knrgk3/R3nkLEd0jaHlkhj28doCrih5H8FJj/zfG69Ddk45FT3NsT99fTHeO4MxCzJrl3tZ4Brvq5RbINk6hU8VNJzhiLz9YhO589H8B2EN7TGHF/jNoYBUkjOdQo5kpBnTNXje37roN3E+kZREPp6HRIql1t5FO1o/LGz55UsG3i4l5gnuEzo24FpTWef+DRaeYwtJQTBWuC91hW8epUfvHZnBPvlabyxu3tcVg5Q4qfsMypXlTOXg/jbSGiNDf5/FStQVFA13X96QLfeHA75k1y6mpPyymI+ccgRCzH2N2TWgimxIZBNa7AUoDQnJ6e1xxMMo0LlkETpzD5X/DDecFlQWikzYWeP6Tg6G5KNzFfprL4gFRr0lnuK1X58RprALbEu0XadnXCn6v7AE9+Rwk2TwTHG0R9CMQQt6ZwTZUFgOYNUt1EiX9Y9yOti3Hz5tfWG6Jo1X59kVkU1U1G2FgL3CtNsj/EqhVgqmBpF26soqjyUhE/CEcVSc2IVpawMyOs6w6W5LHrxrWDmhF8OuYRCpmH408RlQsN3bLYo/SZLNWSyxNG+FHOqvF717uQIf2uup7JloW/Rbb5sNDRI5WGIC3QHZ8ke8+j4aCrSmsauM1oiOeW++oNMM/rqNF2Dst+lghZo0ARseR91Mw9v2CTjWfsjh+ymlrDQGrtR9fl4y0mT6qc8v3T0l6TB8Jvx5awWivZcuV84AbVGPUTDMBU+T/VrSmm3LCP3usEzgjKCebMJeByeJpzhdXmOh6ZF4CvWxn73g9WAVCq0CWveFJ55+lHgH86BC4F1PT/M/TOA+qc8ZWbmfHAEIjZFOx0NHOPmOONEGL5ZK2bzg7MIavlD1xD+yT2uULs79gW2Vr94+FKjUH059A2tFppVDlgYSGi29s8T2c6SOeujvCAFULy5tFuvpN9ZN0RtsoUnLqTXhJzhBDfyfKU8wR0z9DgNeYj/gh0UD7fo9puCPRuLlHOlJZGmKdfZhe82TobrTQ2XzDtSDu8biM0AhKTn4UA/hIVc2FdKjubozLwiNJFZX0QeUtYYXfCkjL2vGr6gwYuQN1FusaF7mOjI3/OaUAHH8w5F/AbsyrnVjOQN9g88PwnCoKTcS47gj3cV5xiqA3qytZtflJMXkClW3NhBGUhwGJ12WbLTftGVpnQcnO/RgXkVJhaHT+jBEjB6jP2ePtSq23LAfO/J7CuhVv6OzOUu4U+tzRmuaLX71YANLLZDkP6/FvJCpRXhjFGigqefpqrAzxoL2aeVuUdNKGi3eq6uQkgrIpi3DyoQZUV+//G9e4dXlSe+9r4Uf7+GI3OOEM64dxPv0OXIlpxnrnoJC99ZuVUviA6cqzTrYi53eWS/AHqFlodAoK20fiSAFPIKgC52dQjKjCKUSiQEdeVllwsbVVAk41wpMPCv4x92Hboy/VNcOCaY76mVlowG1TVGHSnNU2ZLCKpe6jvYqNLE+M68QFi3kqlIu6lExtNyDd9quc9xs4D2emTGOvqKUNNjFzHEVm2jTTWDUP+XoA/n0/Bb4pMuOGU6nN0NO9aBb5CTwLNwAWHx+iZk7CDn5mruojQ+nSTwfsVG0Glnfx7jd2TveC6tVyvAHZ/7be20PUe7SReB0oIKhs8kgTiUUE5hYM2qsl5E6J7Vo6amV/74JnRnU8j6201YGXt0eNpuBYHKZhnpOkb5KISDc6mFlPkZ6qC8MceOen5bTi6EsxsI8bczOfpftEoKrIVj+pb0bF4jcC2DPTIPBBFVdMI4VbWEknPj1Gr/BPiWixeoWDbQkKJ580+NYw3pjCO5ViStUX9duX528VMLFnW9xqYT7FYZnaWO5aawm69HWMn3T8stZXO4cHkEVK5aeJqDEH2GHvHJzEqR31T9TQ1Bi9oZ0zaUXcAI/fdjAhayMDvsnh1gvsRRfdpCj7a0iLSPVPHZWeroSFFg5u4W3teSDcMbBHaNJKWgZwjzTg6zN++cOXnp2ZqindplxdMNVZlTHmTb/WxWoNuTXi2hJZH8K+5goMBS9+1spmUTIknlwIFu8rVzmiRxKITYR+LImTsnCU/SICB7KB1VRZh1yopg13/q/avqtoWJyu0YzGhOjIEOI5047JKpkObdnB3L5tT24ZGRnZ4UmClyB/gpR9wRr1Cug9NF9lSgy5/QBh8RdQqK0wzKgSntAZc4QJpbsQVpLyIMmqLZRhtZvMrutg04HRVU/pTsvscZ/ZJwh4BxSh74ICmWP8W5+S7yWXX/Of9xbXF7MYkJwW3+ZRPRpzlYbbjmL3+ln9pwdP2iM75u3Wcr9NeeoW8f7aSKJD9kDoLtynMBOz4aGN2dgEUfExss9juWYt8RiIix5B5+KaSKq50yoa1lNnIMpxWus4VfAq86T75frIUEzzNbFsPflaX9CWNQ+QwOEuKq4nxVAwbfVPDcOQTcXM0UEcmsb2BPnIWa8hghU5e+pGflzZKNXNSfZx+6XrgAzEm6QZC5Uo5nVmRTDH1PZa3c/2m67Le7BwpiYsf74dCnWpowUkNjgghHNoUJDYYDXtbkFOObL3sHoiU16TFv6tcPUdIsgkUYxIy15OhgZcOG1MrijauAlXRXjDjLDfFHUTajdvXhZ7Xg7vB/z9NiPLxvbRsrAnt01uYufTblB38CxCUU50I6G81t0DAoNdLky8RcNeNFOG2KS2VGMoXtNmNtFZG4FyN/NbFreaH1yK5vf+7lv+FEe3385nK/+LTMhqbhh6vA1Tp0JB5ZI5wkm0hSvQe+rU3AOzVAEW8ISPgGmsrjEWX6CFJJWMVf6C3RKiwnscWtyEPw2AypeAquKEm7w/SV5Gk+t069pp8IahPnaLCYHQGLGPlz41rhKCg9YVXhqDmhZYivJ5RKaKVnzSAs6IQG0TQYAiDszSK4Kwwt4vvlXsUGy6MikgDLACrglfj0l60pSYub5nJg56Ij4drUFV9RdI/Sduuu9MD9ShxdxKm/EwWG9GzHagdhyAfF0Y2ZKZW4EXjHybb5gcn32y5C3if7HQs8hVUBS5wBOrzjBFB9MR8gsRlyXo3GNZPXThkhkUCMN3nlrtqVlkKOlRUxT0g/Zx3LaLCEl/J8RdC0WGxEm/biWGNEGxfEUgSJOkTCy+vepCk1vUE/KFCnJyVRaqJtUwRTJcNHOOMuBZLEAAA2XvJT9wAB3Xntym46idIvrc/ONH6hUOgKLSKxLpU+p/ZQXHkMc2b8IcDwxT7y5WRcTh7Pkac+GGrHVKJFo5ElZHr1LigBALZtL9GN0DBrhLswuheWsUWRPIrq4vbUsE+wiguhXIRJ6qK+74gDzWhQcpqzP/lka3/DKqweoBRtFINWEDNVz5jXmisQ0t1q6zASiW4YJuLhBTCpXYNZr1ylErIVqEC7ApFZfDiK8ijQwT2xjoKrPWEfelotNj4dqbRPJqNwsjUT7drSSNtaP8ZApo5XHfkIlR9fDbfSaAuH2vSXKcW6dskOTmNz4mDEUZU/Oppym1h0X1p64UQTi/3omwsdpK82qaP3g2+HJ9F9IOkvygC+GEMfSC9nI7I7dBmq5vdzQOiAo0oW6ulTirMS9wWuJFEbCaCQMByjWXZise746RR7cHVZ4MviZSkQ44nxka+2bsLKvHmkKU0PTZE8CeDJxzAJ011ouha75WA0ElbOsbgYTVY7j1ONlhNmAN2FXS/JRJBwJ/UKWja5jorDla9qDnWWEoNcuvqaNgwjr/oyJVj8S9+2GC0AMU6vWqbPJEK2v27wXouyRyXVLl+Lj4qTEYks92tJFGnOu0Rf1VFlwrTv13euPIKDpMJzkyyrqBI0ANK/wU1p5w75viu5TNEjGO0zqmW0mptJxFzzFlgL5jsdV7MYZXJjv5GS4WSYBMyM5XKTwHjveaYuuP6YXiNwkTyJFDIGqVSBsh9Mj2Lny4XU6GymaKT29a23ERUcu2cdSI3+0UWCp87QXIyCORfl+N++Y7f5wcB7O/G6oSIBNE36+uk/s94YF7hxSpqrlbBZZHnCJAfBUEoFSptYs5F4/1rINxiDoOtWSAW61VWLaxj3/Z46Fz1YnCSTS18AJIbHKzHSGvhd0qkKLa7NApLkq2FzCU9RsnNcNwSmXVo112ghY2B8I527khd8JEhy025M5nAawMIJber1tyv/Giwx3nMSedunoGC0CYDgzIP51w9sxcGcTvXsc77cJdqRdSaJv0VaEM4hCl/5mToIz6yADqc4kxrDDCFvvanMGs8rF/zWwbe6+GwSO7L+ii4n8CWmqf8EjJr5peEh81aGSBJStV/JUMoi//eIpnyxrjkSU4jP6A1aGif9pIjyCWU+j7DvmMH419va/LKAx4imuQ7pONIRB1Fg8IQo5yNej7QKopdScuqmvw0oo+ApGeVSDQgxhTkWSETAqfEhgXBP9fLF1iRS4TFP255avdvGe/hjWxUcm7PS+KuVx3EP0dR136YLZiNV3TpafCp+EggXKUH70dA7c06fs8TWvrRqC8XduJHjnf48j7EARcWCi1uRATXkBgqS51rqLnssZJ3qFt5eaYIqkHMMIAlodRFdTot0ChhmjQN9J1VIxFV1WU3mm5KtJvZCaFzIeYdmB3Ha9e38KN4Ua7Eujjo1mqnBvgOQpflQz2dFtlfUTrz+18XLHCZPrvRGzh7oP/NUHAxF/JLbJrjrav0aTrD9EGzqFx9NlBu14k0/0x6u5OUJ3bU8UNtzy8fAD4zTu2bJnUoC/hQLHdJuPHdfjNaLVaIkfovpyoWr6gxBDY6o+nnS07uhWVwOgJON9Sh+rRlxKdwhUN6lNia/CbkKw8OCjA6f4JrSadygiTpg61qM4JQEdMWvPDa+Dkk852/mS/lI+1ziTawtsT0veHKHrCbxYVGuGH5tRpEpl7v9g9xulAzbJXxZpPlw1Rj0h7hXOCFgciIZNQoefSnGzn1Nl3AW6KOp4WlCEkbAn6lzowJcg5I7MHWXsOBxYkvq/lTdXkG5WZbsDIQ58OgTJIRlAK0MBtvGJJdp8Ues7nIdZmbbTW3dXBmtQ0l8vavMtddY2YFZOOMIIUXxLuvZvX9EokSflsaJr9+YPGD1JRCn8n2sYUadmF53WZxJBFmFfVl2LJchzGup9WreSmsqBKUnDKtcGQyZGRbVy5hVTC+D0G8QPw551lijvJQZOdS2uGHGoAnU1/LtbFfTg+JWcu3mz/3JbIMWjuXjXl79+pZp8v00GA6bZstYkQW4ipLarlN4VGpBYqLQu+0t3QzBDOBnCckuQU7Kw2H2qJc7CgpL/QJ/Zdp89RLAUoUDlTtM+7Z61WtFnme0ZLa0o/SGypVRYhGAOFz4YVoYRtAjYCjKs1lrEVWgMW9u8G5gmPXE0CMDDgceElB8MWriZXnbvc34DQXjtIrjVorY2dlmFc3o9MFgxo/oWmkz8ON1AVfqTNEB7jjDS50qN4gKU23kukRCmfqMlLqGTpp6LdLBZX6bqVRDeO72PXjbm+iONa/iC9SSSP4JI7thVa6IobXj9j+1pFfrkVPtZr8h8vwk5I+R68zYlpHRdQNhDDjhoJOU4HvVa208b3CQ8gr9qgL1m0vlSnV3U3YZXPtqBTO4qoc+y3t+qnhZETsRuOoYcRqsGcuuwXRYDnjxZYsJUHuROl2UwagMt4zOU8u0gfDB5WAjUs2nt23wjy85ypKIrXz5oh0wNXIYVY12vFSe4KQnOuVk/jYudTH+rkjHg7n9V5/WsFn+FFNciV0Wjk7BlTclNgld7GgiH/n8KuMyNStedY1PS4mn0sUo6wYegXQjjNpSAoV0wUiEWzZ19Et75ya1Hf9o8/Fz0LVhMpf85pd2dw7rZuGBKC/9q/3COoxzh9BD6XHJKFrL3l9M/rJQNjvTmWebDa0U4oSJzu3QUn/VNBexLBYNJzRvjtERMXjaanrPMcTUgXHu8lYA4ZAyRs+1fzykuSWnJ6c/am6VppX2ZkAESMnOB/wvlinrkAdnbe7UIpUfQZ5+FaBMnCDSFjd0KmPQzjtCtsUvKlgs6qo/VVO+rZE6NrYupvR3bMI2WFp5i0+GLzlVr5RbqC3czeVV1ShZnt8MIgIkFeO7Zg7i2qX/ot6fQerT3XXss1MVSeawS17vRvEYnGNtxBpeqbsjgQB7Qd7KLveHaSp0N/1m+xdeg7cjU/jmwIeUhrFITLEPPNuYr+YCUPhcd19fOxUicpZJ3WlzNC1o6aTak2HO5HfEpY5JIk7371R8Lewwyxvnr9dadvD/l0gj6NjgupgstUswDTQYjvWDBFlnMhIelrZi5HHTWvVHI3PhQADSI30E9LGd8Cq0XXhAZAxVkJBFF17qy2iszcKmN/7PrY9fk75z+Qda5a5Q8tYXZAqhsmB4QOh1ptPQFyqdHnl8r++RXg9ypQ/phItkl45awqX+tENw8L/OSoQ+w0fhRsOWMFIARt+l+UN79ukPH5B84CWRfSD62dlZx0MrZxO8LDrU5ssGhEuCLlH8eJ3+nKy/BKrKExNq2nuDh6bN2xl1WsZY604cLBSYEUZp/adfd8uCSd9DFd/dWByZ0SIwW/bvG5no0nTsCooZRAzDUBqogPsIn+Ei2JFjYAmyMhTyVKveayf0UkJtNuPtR8oeBdwXTu1ehgDo5FFwMwsICC52pnnzTJDEqy+107KUIfHaB/iF08rbvPdbvYpxg6iwBi/JV8av+G3j9jrdGdPDM/IaW81bpBItNnjN2DQZhhm0UDfMu7A8JzMPOie0bvbDukvvlV32CNsv0liAAABkvH3+e+g3lAuywIsYKegfp1TvSXk/QpZhM2R+Nh8sQWzJCVkuTiHKofYuXMTcfwYiV1WcaZ/7oqTMPzZJ74RxokkzrkqeqHuwhpELBXsuZJehTc3Z/VjvR0hG/NCcCQdYs9UeAE4oeO53ZiVYGegiqAUXSrDzRGhQcfR3BE/55zNDHes68+1li0WZHGNVhFsIH0NQJdrUQ2W1DH52/pWIWYxWtB3U2XdOMgyzKj0xmvjk+/EI1syTTCLk94A+k3WnSJ5KIjGy20ZsFTsohX922OQpVUw52cJVsb9PKfNjYxTKtuu5OPPydaKt2CI5/+ed31tpTGnk/jM20Ei30IJ96H4YGsmmYXxWpG+Cy+6gbrKWjTj7PdN+IzuOhhYOabUvxrEymJYsOzne+2IW5uBJgKeGJRS9IIIV73CdQdcTbzlC7BVhx8i/5yrb2l4GcdWJO0ho/hv8mz7J8yJdt3ax2K9EWFbgO7AE1ShOT/ZAB9IEeuw8FIxABCY///qV2qVu+rQx8N/d7B9SHcdp4fy87egSqQYeBHKR0EuUjUuN5d4bQHmecY2EAnHuPKfC7DAq5XMURRwTdFAeCWCK3Q8U8Wyo1YWcqm7xrVHMzuCtPQ3pe6k8cFN/rW8SjCe7YZ44u9lBw4vsMY3m/NWwG4DH31AdZXNSEeGeiBHuB0WO+GBJFhJCteK4SQWWuQ3U6xhqfCSNALMBBcDY+In0Ke8PHF35aOqYjDxiuu6vkoG8/t2FrNH/BAMVPlZGWnP8LyFxrWMOXuseaui03vfu9UgM/32+KRBq1YqjpP3/cCBhvC1CnqypfBPkHmXhknQlgi2FwHsWF+qAm65dlkumkPPHxYK/QruU61qPJxTsgQOvik2wHYSjebxGRu6+pv/4/o2fb8T9HtXZCWKiTrFDZZ0yswHkL47+QMU5ZvYMdtuRTim8+3Iw8A0PTk2sdjxYlH7QmrUT9UZiKWLuyeH41boAvbHf1+OocW0Ttz+tevi4wqaTA5SEEWfQtXc7gQ7Ua5NtxF20u5tPekNo+JQIp4gRSJ86n95E+9uTOPuIHI2HHQIoNA0hGivWYIaWlMcZHGOYZijppsSKnax6H7oHvHIdTnyvbFZOV9Kf4NuZlzZFpA5efRk7gsyq1R49V/piW7VMolKz7wWhp0PM6cUDI6+j63//CixlgMOvxxML/UB7bdIAAfkJ5Y4ot5TffYjqXWz7ot3z1TK8TaUwAeUq16k2ujEfHkXvbKUDLu5Pkd/HehLeTLU+A4SIvQcJ/IrV4zCJlMbRazt5FezgQhyi/5cgJDNJ+WfIln8iHRKC+Va1KcKzwa9zbxA7sVeVXmBoG4b/TN5vRdEYFMe5LKySmj2+M8/whsw+6C8mk3iRm/OdgTFM7FIK9WpJg4VSmPpTXl4+T4r+As/ef212hJSNt9lwMq6aqlVh3ogzO4BFYfaQQ8OwzwTrbnD2u56MK1QV1bI83tIGjIcnPmfwC+08dEVB+JYWsqNm44cW7LoA3+pxYGrLR+bGGJaeeJxcFUuDhWTvo9M63YqDE2IB4zlkJl0kHMdd/pHRPMB+4zx9UqjUEnOn1dVPGyCBPEIHXScgb+MAUVjHtZI2TJaDOJmouiUfQquwnl9DZZ7JbLJlYjYXfpUcuHYeCtP87ldwziY+HZw9i5haM1INkFq1dRCFbLMIFTtMgHBmumyebl/yVW9rTpOp7cJIpFA91JJuJ53l0qODE1m7poH3kTLG4udzjKhVola4D9XvxVbYszBPfWiZ5tGLjDXSfc1UXCV4a+9EdKGZdzdGRZ97XYjQ/0IjB8ysElM/f3GFnP5Y+BCOPmx+HU0lC+DwXKiuYxZd6V4pr0xrob9C2z64KYMapa6/PFydlHcF7WDZBkFfO4WhbHqwk1cAEu1CxZbytJcGbuR/2vxowsYF3JQovqMc7qdHPj8Hm8GjrRo/EmzlkCX7ddyUnpZP4xMucPhBMwa0HZYT2UYFVfiLFdRDKYFo/1OGIY4T1U56OUZG8lQV0fMBjFblvs1op/s5mWXzudaoUH6jgPU92ZjYGOsYsY9eF1k+gj0tvHJw2Vm8zt4C6R/wAqO3ygXdtCeYelVKAt/4ZC/7BpSMfqusweGuiJgIVhwQYtnzPr8Uu6Nt0Ye1x/fsARINITMBHLDanT08StY1/FOTtK0PTgBGk4lnr+ZzykCCX7tOnN8C2bHImhhV6Q/Zp6jMIO31zoTtOyjLEvxu0GgSRgznK1vwfBgHkQicu1bOcEvB0uBIlzk2tk48dyXvgUU0g2JGWJmrc2pIlLRUDUl1ucv9RsU/ZgZ8WvyUiTgvvht2jlQeULvQ7wFM6LSaGJsmlphIHjjWppe/o0jH5gKPAP6zDXyIWhM7Ma478bhyf0nXEsgYEgFTOyVnu269mEAiJQAQixncrW7l1uiOb3yp6AfhVdW4v1Tab/26qc0mHxRJevEjZDLCsrY7l9KDhzHweQieBmE8vKhLrqHboJzLsPAX/r8vPxKsALbHWRfXnR6YlRCIgb73B7phZ8/0iYFCeS9KOjGBw+jADwE4tPzJpeP879izxoYjwNwQyR2cuaWIXi/B4CR0mV+FKAsTU3k5XRqZ/cpbcEkw73V/abYakwWaY8HdmJZIupVoJToKqNNYOgd5Pfof5lU6twPgkYupJjn5tBdnC6ARdyAIOsh8FhOU8IdpDdoW37EbDiHInUpz1bxbBVHli4wQaYJSZSjzr2G7PfMh+lCfZ6LOowsiLpJ7BVyXXwgdaSA6OV+8UL31kWOkX4reU7W6IWQFVvxTx3J0RQCvUhTPmyy+OrguOxct1hBhlcaCAeSXeUP5i0WMveoGPAIXn9i2DjhLxnZKXOGHvON3uWqvtts36djO4AVePZ1jqCQ2yNN//pbcGK4m4di6Yg7G1nkm51ZCFYY3AIYSH4KEhP7SYlaGWSw3Ti5iywT3CSwIKY4hgGxSb4Dff3tU2P1gnsP9IBHagKSh94hau1VfXo4ZyE4LX9VWQQq3x99ZEJ4nt4Td5BARGYJtlR0hLLv+aWPDl1emkgEQkkB1sATGfH+DDLW6JriMVwseR86+EpFF3ia2VcmUHmiVWZ2V6SO/Il8Pevkwuz1BhzcS8XKqGaAILidmnHO6qBrfHs9zYwcKTAhC4Cxva2XSgTd1iLdrK/aSmIfO4dmaIcndIznmG8y8q946cZ7iz8yij6PkL2ZHK9ajTGbatHagK8FsITv3BisqXLZ06V0yg9cHDBC2JU7AGkzwfaF3nBut/5kV3pS7a83XF/UHc8eJYk3m0d/vlANI3X6soj61sihpVXpj1Uulinunf4W2SHcIZ94FjiwdGI7CTOWJLEZzeMkFpixFqF/mTpYnDqcxQT+qZzYe7r7FRGNiGQgo81MkBoFNeFbfHgmRxcLn3bGKFTM8wSGjulVF0F4N6W9BzSrRUN5IDttb+ExamIIBSpYJZFTPZ87x1ZUDDNiDJaREYlyEl8i0Xczy7WMbR+1pIe9DFlcGsF5oWfyLUtoHdJ/DexJB2w//hdxK8pxbbVT6Bv8CVLfSUvaQczg+2Q22Vn3FVNHYOatG8lHHIibgwAKoRDIvU/K7L7EQ0PWWwpDjUx+syGMrnzzkBlvqkr7+6IHXVqW6gXSDUd1yt3MJfDlCApEhNQamBOJV4Qm3zB40uF62UmLnDlpjhGu48yjYL/JjoApnt5YMlpSgjVvjMac5S1SFI6suOoWC/adwGdwdHDjPNZSQpswkVOK72cNcSNRotEPXDqWND2JhmFSx6qGwgWYK6C9lzljzbBF1QkPqksh0dNcLvQYVMhqhIdW/BCnoDbW0OlvYfGc+V/HQQuScw07QiK95bBE2fae3pRy1jxg84v4V3zXsjdDPScCXBJM5US+k3D40GK0vtyoMc0ne6nlpyff+WYHnYKln9YVPe/g7axsEjgUagdYTIDtpIivrvK5iC7V/RrXyMeyMm8Bln20EJblfZSmTG9qTpUyFomirwNWKmi26BPWLzmG6B+y9av7unv3aBnM9dCAu7abYIJPIKRZp0GWK32VJ4kxwUcRjVQAgl+AZlWEkf10qkLtChFRqYhiEfnyZDf30i/U6CirqKWbrZcD7V3f2+YcZtl/BmsHGukfyS5U3kktYvH7XrsUl0LDpmo9SJmMVoVw1A6IwwYbPrzUX+bo9KF4NCycOEiKozjxeM3VuIkeWIOeMRxl3RvBqFfmING6JAiKYrmuDNQtzrgkpK7Ld0MAjmLnH0FnsSQLdhpevh0CoCly+T1qS8u1iLSRwxLZPJKBnWFSyS8bTdchlErg+Eca9Fj8cVzxVIbgkef50Iqh83KfpfOnSg8hMcwFE3sbqRu7fazBwHGp5nj6xXQCsw4gWBmQbYTaoDe5by++Lek7fcw4q4AZOBoAX4/XXQVnxPX0fNVMT4QkKi/8kKzORi6FFrib46I6xYvi0/uSKBGJw7zvO89kbgJe2grEfyN6TKtZPf40BK5t4CP3fHVC4DE3Xdm7cZ9B5DgtUhi1KKSxug5vh/W50mrMhH1RzMY8Px+zqmRQTRyRHswB2gSwVRRwQrBW9zK+5dBRdSPLq7IBljJy92jLpvyjeWWG4ehuUTBSGut2wb51uXF0Jb9jOzNKxiGPWkH3LJhkGvv3I4OBOQdWTLrwe/xr+xRHX/jW6COiBpG4nHXkAoBAmsvV8Zh451H+M0DUgTbv69PC4OLwXA50uQPqrcGkbwHlgcL37Ka2nr1kFU6HIcRz/v0Xj/pACmiuQXQJnG6Pt22asZl1WRCzTKAOVdSwJ1L+U7sQU1d1NXuN/W/sbG3LTh4npHVugOOXgtJa2WdZc0VwDXi1KiMx+7mktOFm/qrQZUorGMb15UwO/0yF63Y/E5u8S0BBPlLbuINi9ttO0daLCnSiO7rff6Rd4DBobFWBMQC9aF0Ka8cLjF9+6eNMUK2K91qdmlPWWsZUEvtyybxZYsI1WXH7YRCXuccUqpXbYnyBaaDVKWwNb2Pq2el7hyTmTAX+w/X9W4LG0LUf+IJ5iCGu6F3RLCt6JQeWenvaaez/fKGIFZBLt90vHH6LxzF/bM+efrl5tvZAUz28WcgogBC0oLBn6qmfH/iRVaAD0GNDJUQfgU3MxXYVvPcr+OVtFfdw+otR/NMnZbxV8RNORdBJcV6nTu2H8I2V51k+pHMaJYgnOkumHNTWvfPeOEDCuKSvLncK5tsftFFFx9G+99fGfzXb/jD5NqaCiKmg4sNjaz9hmWHigD8ULRu2o7iNJqGdZt1nMhqb3ODi29RFAjWAcu/K8kTa8EOCtnHlgeyX8sV2/jkgVdJtiuJCMm2JgGusgUhRpk1guveIIlV8AFEwdwPcm94GkzeGI49YKJ96TT9dNwXnYeMFoeZJcgJGqqiKqZaQm1Ip3TVjFSWnVn/0LofJpE55Zd/a2tSVHi7JQXOxY/HyaxrQ3av449DzXPx2qvD5T6xrFQTaTqP6S4kxNn7mYczCuUSDj+6crSWtUiig1XtAYUMOQ+bfaXNVWQGipU5DKEonLB8j5XyGgzwWN1wmwSGwCAN9H1FH/0ymVT1X6IaL1vSAc+pUHCPn8mCN06NHzTgQoEZwjaxPh9atWCyalvqCLvDDhqiIir1PebVeDliokKFwdQy/gxzRxo0EoHmGiWQszCJCGX30zXGRkGHBa423fhhKiJaVdoLG2Y0Tncesmux0dk5/ApK+ZUwlWp+ltod6B9F29wC4fCsW+oTQOYTuRuWUtHX6ZO/nZAXe3Jd76qYp4DV6QMGSy06KOseGqoy+yU0EaP0tTfLEAcWSGA2FFc3DqSU2dlJhvjeRzVCt/ZwUUmU6vGbaAMetiugL+emq12HJnuNkqglEATU5Q3D2WDUtHf6ekmVf8ae6m8mc+/w0jISS5WxPQRmkfgrQmL9YWbLtOfayhd/7KtnElEdFgBam04SqEqOomeavO4WL8TyI649bMPm/gtKlrYlDOjJPA7C459EanHWtWc6ylUDcI2NMJUmAh7D9bZ7xy1t0yu73SeXVebK/lI/sVPilMyS30dm+wgkjch51h9ouNmNwC22CWrIAAEJzLttoRd2I4qhnOGHKT4PvGZEWLx8bWycfHI2MZKXm+LfrI0NCoD9XcxAYd55T5KsukUl4QHW1xN5tk8f4tq4HBpASYbsKel148jw1pgEOpbBmLMcQhUElREeAuT6/5bW9SMGDQsibsO4nHqylrcIiDdamET/EJxiY7tuGdzhXpdLTkSHjp8hdZRP16peRSQZEdWF0r+1cFXx15fHlXhlcgwsZpPuyuDhc+JkChphYcDy6P+mqZI5yGaODCiA3bICq2UyIlNncdOysqoYnjIjdSjwuG5LUFfdzdDwsDZB9HX60QU7zkynRPo5XMZGMZknKZxwqN0XhgTPA+dO1SvcuTwkPJbfoST97CczR3sD2Ddrki5siFoAEB3z+OuRgCKqp8RGHrVPfsTFuqPYXM73sJIiTBH+54kHT4DtdYFt0qdBbl6bl5StAL2VTJnJRL46v5dyRvQ2tD4OsxOVBOa/mBmsgJ08mdH/hGfViZ68CBNvtFzochYOYLX0y8+PhF8syF8g25bWbQnBdGJ6H/9Iy8G9hxfbD45I7TwyrulPXF8dTuFhALOCw3RO5Bnlk5m1MDZCoWGrwsGT1cNkjs5HnscX4V7eORfpBC4b1R+9wXnJK5WAJiN42nSCRhnGgDtoskzKf8k5lVyGxS1abIn1G5DYzjPItmPcdmQLQ9yeDKamqP5Epgq+HObbAgLZ+/xZu+3wRYMWKH6V8B+P+vSc2p97MPeE0yf793sFP7jHjEM9jSeNg35CBEgYjOZVofUT3Mk2UTYVKlREbNC3nv6K3Dn2nvLBstXnGRThstIO200gxaGOWDkRvEd4krN+Ko1i8YD72t9qOk/Vw9rGU0tytdMq4N7v3thUc4yHw17MIu65KnUuVwHcT4R83DhyugbROThrEYUFjoNXsfYJ22hKM6hSPQ+vJV7ukv6NryhhmAmIf59f+cZP3CQy2Kn3JwjQXJe6ug5SVyw4w+OmFB4SaL85M1R/Yovm+0MivDdlj4hbBZ5SS9xgslXKxttJeYOOlte3EDgiI90V+eRY4sPqZHifTX+6HR/S2UpPPdPYxleCoWYD7GxVjY0YuxOaxqiY5VLqN95NxJFd597Xp9xwvVK0t+JAO7Af0f9SoIW7sVdI+ZPuIpn6r7cM8neW7UWX1SANsmlI9JI3G8cu5fxop2/2eepflPABSK+J3M1UvnhG1cr8QdtN0NR5yuUNCXuSgn1OAlcpS8hGsml+zZ8nprdnwXFjX6J2RjL2F3kDNJMTTehBdtSCxRZ9qtpNj7xqeygY6J6MgqEfcWcLKeM28oh+4UmlKpbhXEddVhZh6SWrKYdWZHR1O6H2UaLpiO90dL3DLwPmIb0lla2h6kgYyrboH1W9lgso7dXvBSp9Qjc+/Eocas03/hJj1zWdCvQLzpq99iNpjT3IhpUWGJmsmOWd/3DTkjo2TlMIpKmGcJTB1S1I8phcTN0qASoLWnzkcxqdfKaqKtkf8YrcC+lFE6AYR/yWkyYedYXe1xQ3igOMadNmyBJsh4LtiSU8MKNZHiM3w4EnQqTNiCDFTof2QsEegRnZcdB7ZL2qXglJqPci/uOhF8uAVlBpRZb8qMIpxH8qzZ4mxkt9WyO13MVbinVFUQkdE/eg0KJAZNN242xC1NZ2v/Zzwv66AWpWx+9s88k3kc19iCW2oD2YhYecjUBv57hqkQOYyj+WWb3rDCErGF2S4A7Ju4rM2HyS/QzrWUHnilqRtNW3Oa+n9zADujmPC4uJz6oWQbcmXEBwWvWbs3x4V5oysFiVtoSeNPMgsJe+RRoyM668LvMUUDezYDd+jGEGFnbonFo1gZwKgMpZpnYkKU6WizRtlMaW7PTaD9G6leGAym/idszREP8/BDVu5CurhtSbCTMW+2HwkN9EZ/9psGPRQy4CN2ERi/v/4sDglSPaik74oGxsTrBiWDLb48qCZrm3a/0SAPqFMnPfBlt7zF8zy6ax0JokPeA3dnZUjcR4A5Ctadd0RvRq/XK6aNr8XvUdJ6W4Torn+bBLvgWXCejavc5ceZbB9KTr+Sr+V1sNSonLayB7CbLE0OJrkVo0XveuNxx8sP0b7/h8GV5w6WagTUtPcP3Ol30qQzWajN4qeCj2bIHpJJyyj9ZNqveJJz6xxjcDfi4LYh3DLcJCHF4pSJK0RSlZ/PUEGkg9O3wjZjaTwcqAgxx83/NkuH1O6K8fbvQ5V2EnL0MkPmj1kfd2kSphUrWwCgQEM4f0SR6p0DZl9xtfXoZjzB2DXR3OVuNyTzGecIr65VU7mA8lPo3ie2IuTT9e89bX++gXakrI4QGNh/ZNTpB8IOiqc5wnuWSAIPBwLMZhCUhHaaPr6vgmyQPuISa4593+QGPNubVPXfM+zrCKemwckaQy8nMTa9pxNagdQ0TSJcruQm6Vh3G9XbQw9WhFwUYrA1BP48nP2tF6sRCJs3UjTwbjk4dery0aVRfqu5oKrdhhojoTs06BuMdibwjEeDPlD1+L9F+Yu7WC9ll33M6Zr/bTAJAf39RTqPXUlwehmcNTEyfcxjiUDCrDaRJnCdN5WyYe1bcR4lLxEMixJyeiI0Oh42ptWMGjzx6aYWlQKg/UOk9sa1OtlYbMDOm1EpnGMHhUMd6GtY+oUHdJ/l8jRm8KMmvltKJo5Y051H+s+sEQ8/ZCucjXD0Ub4dfnIRjHUX5a+/kwnPE9RjSN9IsRpAaEAw0Z06nBYAhiu7zlQmNV4IQ7TX84FTD/qIHMUrN9M7L1QKjjxQ5qwd7uK7CT1AhWWPrQQICd8q66OjAyKEXEqbRKTy8hq2H+s0Fq9bhhVr9Je675zxRa+XCL1dKEfDCeB4qLZcwjCYhpaHp2mqt2mrrYrwK7ysmt2xnqCQAcYXsNBvRci28z7ajMrfGBb+WcQQfG0q4NfupfsWH0NvgTkIDV6LF8aKVJBQ13ARo39a4TmS7a8TKKClvJonHEDrUx2SLhzEAXa5ut1ewqtDs4bGGHMS6kvKDzg0sLYbqXo1qMW+6To5nc9n8jD1wd3CElr04A0WaP6Q+EI7K9cDIbZSN0urjMGu0VL2pQRxjYIHQFnYc6S4CppH4kVrWlTrqmdKLLzAuuOim0LepZ/2f43wOCbcZdbgtN2hiJKtwGPPLKtYlfZ8JqLDSUmpHaNdxYZkov8SlzHkmdfz2HkHgJelSjrlo9HqU7C73pvcO8zWDX+biV55cOaCixtMWtraDARza9Cf7uGIwkqXUjyzD88fdul28WGswlnKi22i/euijCDKDlvPMGIU7JZis0C2JDmBqfh+pWlxmhT74oNOcNfKCkykxAB66Dw31SsXqP+Ps1K5bHZXbPvoH01WZuYKfu/Bkn6PIDOSWmpr3VbQARNvREd7BiqSujD5P39oKCB3bex35Z3yZYTOQZAVHL3gD505gvS1S8TOM7paBVjGAVbuCk5Vh1hdkeipq1pHHbmyUi/Bs26MH4cN88RlSzT0X1/5xq6KhGICwFQk0aECSoRy8M83vK4xbLco+dIf6elT3gNOHkwmtoPC0vgKXxqIAEkywBh7h+uERdHBh9O7EyI6cgBi6JwrLkkgkPFueYSmbczjJ7rlPowTcVlNxtpLbys7Ad2ejz1k7Fa8gPS+L9X0acXnefx33kZdiCSHs5UVXIuJ8wNngvCwUMelbjPlMoq81fP3BgA5o+kSG++cspU58CstHBWohh1rDMz/IPkz5vfwu5Yc5X1hbBmphmZf2qsdBnqFWRtEt0WCJquJpzfCA/qtgv4JpDxcCK0dEl2oQjZPCOrz0XVC2Dluw0B3awC1gsT6MhO7HRAlSnZQc2W9UN6GsV3Z7Tq8XDfEKSw0KbHjFeojoyBCYGfijCb5Kvj+qWqQj0miqd2yACz4iQ97Pw18kdKCeOK3dA2U0tPQ+MPmD+BMz3QU6csW0sT8fA/JIiHi2guP9S6YAMbycNTyyhEQM6O2g/H5S2ZGUy1nYq1g9AL0rdbgHFqDJopTJ5vjwb8DijAIGWOIw+rfqca2BDghvgsj/8ocZsfMQwBa+tjzKAAnFZplfRWyRyeGNZBq7i6TgPKIAkXKqY7pHeaW0PfKaUqR5Kdu97S7FlskEGrXNL6a6adgZ7+pp4IyPKKTpBrammhpDc/koxRlMqMmbN3xyNhNqsKXGN28AxEUVcE5ypUz9YASflpAurRAfAlhJsnXv2TsbwyfjozLt05gRmfLmzk67vGXK9O/Wp/V1S5EtBVS5jvFB2Koc/flZVEJaF6X1y2m7yemvqxCHedG6b8b5e4QXeKZhQ6gwCiAm2Vmh6cC4e6wzYimB0zK8+Joe8DGIzoGCzZVhcfjZ3eunD9WXDUTwJRbHsDIPgBIb4IUQiOlyFazX92pAE4M0zXMqU+vTjNH8jCXPAT2Rwp6NEEIqiuKUbJ3djC7TFnfWrCEZFO1KgIia3DgcHksLsmkGqMBwBSmwLbayAonWJan6Hi7G96TUxIc6E6EW1iR5kjf6PB4EhHB/faRQZ9WHRqxBXckjuGTlgyQPiw+vSvPmErcg1SfxIU4EIXAJEeOEv15y5x0TAZu4Mn05E6ZnkuEntoq4z1OaAOAYWtRTeOMW9YVgDx5otHLWPZ+x4hTjUziUuPw6MyO/D+O8mSoyAZkZERQHU9D7P3V+vOCogZgEqacxADFcem59/C04AzsO2ZCr+A1K07ZXPa4WoHivvJl4JZjdNps/0/MlOz6AH4M+ucy3WkwcZDPtxJZJknQRkdU0mPEy8mqo4dmOBkk9JTHCe6kgYdm9y+UJoGDdH3GmrIsDnUqxzYkeLQ5MY2Zb6xlj1f6hwvf1agtFVeYta53LrAAr74UW+AEjew67ryLKN0zpuktSA/36IQnVyyUovdOoldPU574VhZlSa/Z1UJ4X4VRPYOOwgOqyLIQr1hpkhgIEJSp1HpvFv5dVycgCBJZeoE7y6YVKjYI2WF+BKD/hiHRduOK7ggd03YJG04UFghhDY0WFn1HYKyqH8EpCEU8IGqZSZ/TtAQLJi1Iiy8Gx/g+qwGRuL+KISSX0BYV/8ZUJ9sc/QOXHmuj9J4dXHw/MquhkwsdhZLFB7WVxY95lmzF5Q64v4pK4/rWc7udaXd91ftmyFxnwMVrSy1259xwvxdNHC4PWEkuP4vF22HqqjMh/pLAJMFDNc0B3GTaSCDf8A/lGDr9YOpPiotOJj7E6tEdA49FUOe+uRFW0kWIxsCa/9roLY7p5fxvSOGkKzmUq6xmUz9JZmvi84V7o3DUUIQxK/hyqJyZhAR05956HNo3x8H5KwTNeWVky0RF/Wh2ruN9eCv5LT2aCdgTI5GrqOaw4pmn1PNkMjcKfpYSkhXEw77tg447Ga0SQDAYJLfH1LqqEH81gt603BVGgAcGta49PAEGUXUEjAYPGHzHWYD+RSvMKROMKcFyzBhfKP2k8HMptPAFHfJwG0CFJRKZKkgfhNgeMZOkUquJdFozAHBZwmAvhVJzDKE5TmufPd3sutVgClbGANArbqUc43HLb4L3vgRCFJZ8mhiSIe4nh1vNr/JSH4UGd1TtUWZCT4brP//EzPlXz9WsNH8XjL49pU+P9m3zn7kS8uqI7bBqLijqmg4vU4KGYog9fytsajamJLnf6g/WfiQeHoGE3oohf+OG8Lz7GpvtLCRmnPBiM9smjd9u5WS6aFFPbQRySNCLbqYMJZ9t/enXwZRc0cVyXQg2WczjSJuMTMP/kYQL5ZgOJ/UjSqkyYUg0mkOZFRrRxKE4VCa7saujtffM8P59qa6esC4SGiVE8WuaDJXfkZ1xZvhc6Vcb0MvB2VECCDiZ29Nj0xGsXAeSKMFN8k++kp2ZYTIpxT0fvnheE8VxlqTIUMuhZsg23/PO+cpwdGLSMgj5r5wEQetESXCy+jPMQiy46Ifm69c1x3wP3h2PP+gJ+7YmJYy8prQ0a9Yw+U0kTFSMSaSa1j9X2zbJKYlarAv2D7bzCIBPuFWFCzeu7CuOwJ/84IH3sEioU7AKdllTy4VUjQANGWcLuZSyuO9BD6PUnWFNmFHIo93556DE4YSljQVMMvRtDkopJJ55C4899SeDiaq9e7fg/zKJEEm78Mbl0fcde1EWDpU2KyVubdz0yfkIiaBjNMq+4ayUioQLxR9vTKy3lS3pO+niXe2RfRMKY8zOprTR893fSoHISvK8EYYDh00lpNgqYuCj/WGM9fvrxroh66NT7bCpisuiP8E+PgssvaLuxCwxgaF31Fi++BbZId5DsDJbCyxtC6uo+AcF22inypUJGCFecFUGuce8YS/zG+ALEzW5Uh9M3/oy9kAfgGzk3g3F+wac4BBGAt++9kF4DHANQ4SwE7pMSgU6EQsPRjVQcyllpCoTIT/hX7mD0H6nc3Ylkz1CiWtoDZ8tv/4wjcRlEQCRXP9K59XEe+xKOl9LzScnz8Wahaj+f5CC9a2utqXmbdEdAwQzpB8LsbmS41G9b4ql0SI+F1gviTNAnIp631dyMC3SL+43YEDAJoeI5QnsT5Hl55H+r2bVyehQTPLvss74qEyQcAHjcRFwe8laNrgjch2zvQSuWA9Dj2tyqXaXxZDuDw/XYXruRrqWiFb/cS7hxsbNbMZ/lIj43IaEt16KTnOZrO4Aiyvr2utHHstd56ewm+0uJNXEAFxnnhS+fxOWbrLtTCO3fwg/M/D6lVhzO8iqaYhkq4L3wuQCcPkYIZUcuo7iuanO2kRS+lq2k+b/a9EEpbffP/3E0SlVnbh2PhhFVfweLfPjprWPK+UQa9EbcRCTJNLDuGuIH79vTSu0uDTg8TTOb3/9gl9ByBIXB7VZcdenltlpFc2aAYecbZBQ3y18fFQKVPQz0SIC9NohY3aEwUrRvnZRDGOQXNwsLlQaijGjRPWYyF0qwy3Gk7OSl3gYg7PQSwmMcfD0TnART2rrsgbABRqQysKgxmUR+8BUowCTzrOwwuSuM0QzoWJiVdRtu1VQklUqK1IgBjI4t4YPPMgxexKqPjFuRnmtR+V8GTuvlp1gZrRnaZLx4E9HFI0cdnCHjn8z9mofLlGat7bNmM4DKNzHrhUHwHBk4TlZvknc8PQPgxPnlia+hJxIFga6zLSG2SMUHcuuzvEvOsnTUlTLx+jafbUGw3NND5OtjIw2ovCqjPq066oq9vVfGQVugxuwt0iTeNhUeUbKULB9LrdlFZuEoZQL4RXWeyPHic7jAsWWhlLoLuf532LOebmQkW6SGnTa90ghMMhMaLIidfR5r1TJHM6XFU7lfviYWGkHXbYkcxmU7e2w/A5geyHDXRaqNjC7YAlXwHOooCGGbvRRghjVQAEe/8OYMmidZiXYbyFu9yhyxTTNATpJUSCXMr3MT5AlLQ6JFH0j3jYhx3cU5x43c6L5MNzuFKjCEAxJ/shl2Ghxi9CaVNA1JzaTZxhAfcrnBQFCkYL165XvtWAXDpvSlTdQa6KAAvyAfRTaVSLzbUAm4phYv50phVhMHwrUOpD4LOrHc6R44AOBpHJ7Lnn07x2BjfL2CMOvX734NbLaFHUCwD/mYFBPsMJkczEhIhb2FLEyX7KybGcLkBXklKkBuKW3VIgPMK1RrvViPMQK+ffKomin7LaSnSkTK8v8dV92iu7wupgXW1RudqgRtflUgZOvQ6ueScFBAzBkD/R47JDFYFsdhvNg9ufFwMiCNF6DBbtIaoLEAzJNpy71pUSYTqnGpqV/j4jHpT5trIbZSWB3Io0rxQvTa1KCsRSe0rpkNBIuHqUK9ujZisic+1rGwmbCngTXNiEK7XCLSqzT6Cq0O8YoGUkMGWlfLJZAXbXZBOlLdHJtoajLHu1IVM50Mn+UDzhxHiOWf7trxZFgc2qCAC39tu4nM8xBxFL4ze7ZqKdEuUkqFavzF+24fbi/D3nSazmulLou23B5zdmyeMeeR6garVZS2TW5SbOyBa276rfL3rIjwUCxtVI8RZg3FTFnkyk8eveqKQ+5zua3JXeDbnrQ6rNIN9z0j8fSKtJpBxJU6iUQzVq9XiGnHPLhCecEqatChxzDyImu5KorHzw1uXQrszQMBILetOzBUWWkn9Ypzppz743ZrnwwP8wvvFWVEpAvQLVd8JpUkA2v81YM+ipISBErAOlGQS5j8BR2g2/jxdkg3EK1F/nhwruyLTihmkO+GZkllAIzmiS/qe2UTy8imvIMmWqIQ5DxbIa0kHRvQlAU3TnQ1dYN5mI27KID+yb0zuYn+jy8zUIWI1Xoz1mxrFVIavkHYkapIZJNOQownDUZt/NQ9MqBP/0xHOrK9nf2XFgrbBmdjUKC/rfd+g4oH0sH81N14qLKifDEtKoOdqdbzgv5DIjgL8E4+RC73fBWZUYesHN1ziQQBzGL5/ckLMcmxKPpBOsuxTiQrE6++YIr7K/1+3T2bseGnm9HnBBWiHPVYNwXZRIkLnrXJuPBXXPRv5/WHn25S00T3jPhSbIb9Mql16kDq3Ay+xdmmQB9GLbcqNBWHfBHo5q4ZQvOzPi5F2o/A6aApqdx1zwoSOctOhRbY/c45WN9MxhMKf/CQKomfg/t0tzHaIksOFYy7ogk9rXpbGLIvTYC/UvsPtVPJaGwVOQIWDSvQ5EvQ6qS6gQzVskd6tHvFNKunEBaTv4FauTlABwHahUcxfCW3eRGs7py5Ylit4D6u5Sf8tzkNRN0cFMnTjs2uqhvbhAZlCSplbVsy8Ue2CoI3endOFe0M51ef8sikuuiu2uwOZDuceJvLEVaUrb5q5dkfxLW0f64Zigfl3WDWIVDBGbtjzKKcFpUE7BSYw/cv85bDznX2czXVP6xSJLSaSa1o5c+bnXoiBHzEgarpAwnZMxY1FFhEzCfMzddWILerIdabdxv+oWy4Kyazs5UfyD7AxWlxZDpypONia6+lkyd8XZ2NAEc28ypcAaI08F2l7HZFl82n7856uu6xBWoOP7fiL5LWCxLO1Nt7wCoAm9XVq5LAT+2XHGozWGcIgnruNYx/wrauAgMSjzgRFZf2Qtdx/RjFWZh8KzPL4EZz9sUYRWTpNvvPk65eMJn9YoLl9iy0HdQUcseyLV2p2kUqAotvYMbwihJGAABcjFFUPLls9FNtDwXPzM0yEGhwayYUu7VL2675J0UR+mTwkLDocMQQAL+/C836A2yZ4Js0lY7rl5tEYykV8/50sRPnFRZcrcIsH7DpaxFA68tntE6bfSu8JOM7Ly9/YxJif8pwL0XhS8IkaA1+y9Aw/rh5Xig5wMyIlolPJHZ1Vk7/WKEJGq3b4fSxEnsfSJy+tWF22nOpKZIFA42YMZVOMbmM+lB0RLDDjyd2DnPhEbY0WUoIqLGp3XJ+o3GuMjadEejZ52SNhuAxRQ/c4aaXKUKMuKJIVhXZaQhXiUQPoiDiyDP6vlxCEW+7qSP2Q1Qna3g3SZWSMfo6z3Ccr3JI+gipbuXCXesQEFPtnu5qSFteT1TKWQpioSUB2NXpgjE5Z4hqaPrnObx13yOFlQ6i5/YREvWsoCHpcg+oWN/ckDvO7b5nblFVYogAfXFgasmFVUPz4npUdFSsP2rSFptfLj5NfrCrK6wULZ9AIMcPUg8MKb+ftgRDOFog7GBdYpIV0L7n4GOYCZzYw5/QpadOe5wN7O45KKXtR+FCdyMqz7ylYZnkikEkkC64ojNT0sjwWcP/GCkbfue8jAEzB+rUmES2FqgTkfmkiNlx2YlrCTY4P01NqI0VcPzd3blsgR4B1Wd+wfPXvDGvRw5wmPE7j5eEhcEa7AvfYCai+qAR01ioknsITBx9ZYq1sLp/JU//lsoOGBzAJkEYv1uzkBrgVCL1IkrIrnU0uAB8ZEZH1/rJ5STGrfxBvo05bVZhmKMkO2ss14rxUKwo+53hLqu+S2FQaBK+y6SPd31C2KDW0qgAGDnSeB5QR9YGwpIFv3gp+LS67poqjoWQpKbjaox3xlVr8o6j9D/v6YvDxgaxTdSHsq56i2mYYD7qFghsmTtijTdTlS72+3zHngIzIQEFl0GHH4pWnLDQJa5ADX1DCa2uyV593/wsaTDAFbz3VXp0Z/SQGGtdZ/XHxNlF5Ggj37QoJPp+0Kj5jxphDDlwOasTunAUnZuiOQrLuZhXm4Mb7YWJxBQTwo8v3ZJZawMBwUuJG7MxLpzFGpvWRpr+bQKASMvIJ45FcPzD/94p8Ft8P1VwFGZCNel7iQBXG4S8ijpukCI5knASl2pTr1VPkFXv8ClPxCXqFYhAKll4ljP/2Tda0Ef1refTHCYjWo8BZO0bUTlD/YHsi1TXqhievXUoC3d7mccdL+T3f2qUHd7c1o19mZ7N8M90IaRDLZNIAquRD7tMCjq6G12eYlQreA3yQ2OWLXLYqulQpZ7wtG5Dy8aCmWv42iOcVcMq+swmRMDD7OXXll531lJs/UdXUz/TjWnrp39ztxIWItMncKfeUbuzxoA0S6HNN8nrWI6AaVbCwKPBkK2/pjcvoFGxHiBHMCCq6ApZvF3ueFS4Jjqi8tauvo3lsCKQBpwjvZJe+EbFLo0lNvYVf5IYQHv2H+biKAYpzgRyCR6RgBbQ8LNwUy+e/rCLgwM2wIuhFfBDz3gD1HG3FCC0sNQhqPju4bLE5xKikhs0d2b95dUVzPUL7bY0zgqQ+kpO2+j+TzqSfjXFxXR+SY1ThKyGt0jEhiQSJEucmPm15zwHhORggABVv/HPAXeffSWaZnw4Xdzs5geQnR2sKAJxl5m8mFfoubv4BHF7ed8UNkPBCD2rLfwftnlV4Ree4hGsB2Lt4gEimbdeRTEzFEKzhJHNX87T4dzc2XDpxBupEAIYi//J1D07dsAbd6cU8ItG9YXsq3N4MjI82ubtVThxeWBsnSBFYa/WAOLKxdJICQOnXxZxQKhE8xeoLEQsTd5YRpH7jhFpbvhgySoKn9jVTdQMHCEDcUCyDpRoeeefzfQDmleo4b3D1rgXKg8gcOp3eQ5ZFdJyrU351/XKHbzrKGbzCrkQR2Y3Fg2sajIAIdZ2dDYAi+tyZKlySgiQEQhSClPMUDZKPZkQKYF39xTXgMhEq5CT7eeMMCNEWE55dHPv+qxYJK0knZ+bGx+3Cov3j1+Bs1G9a0IhqWBRizRjGXFwCdQp+1sjpvq0Uj+Ds1EZu7oWGQNEhKT8dWoW+2HcIRBvqhGUfrSjX2xw7WVdOjcrwX7iZbcwGTAJSeRVrNfXcaTeaiErwMNb+NU7Ta/UVeEVs+GEZERSdCQJwxM5i+5rAanG0CQ7Wq8WYwsIsuxK7PsxcQsfHQUMk2LFEVf+1D1qnYo8ukBNSOin0k9zgjkxit95mAUnC81Nui7MxfrLF0TWmYJ2sy8CvuZpRrS1TGxc0LHY0IXpkgbJivjxV/hC03ML5k4QJ95Wca1wlU2qdEyQ5AOsIPRLKhpB27ILLf51TPS//9OO9ixONIl/3Wun5es6Frt/8N3rOAaW6K5zHVj5npX4z8VlM3kDU1IYpUZXoE7qAf8OFAvnMeDzgn/dV2jfED420i1oWmmYoT26C2NT8ACmgJ/onGiqxC+zAKdcz2oEUQXXzepYv99hiFVoMAADIqGdefoEB8lSXvJoCcT0Z+mPc4Y2DXwnPRYPRfeAVePM20oSJJvf4XkDqAp4etJH6QE560t0PdEVJT9aMA99/iYsEWeuQ24Haeiov/6cGoxA0/IaorY/IRsQe7Z1uH8Q8XZ4qx5G9gBFH0AFMD7SARsPCjok9gHx4WwZEI3ensJgeUkppI/oiNQRwxQ/NgF2jmqO8rRaLb1+haMcmpE1fdeDq7U2rnVhbctZWmtZbwDb7oCvygBLzW3dnYiMVDQPlxWBsrI9avHByQDA+1HcYM9lIK+5bMxYjbhf1BX+q1MYuFK1tDJvS2/FM1GPWDww0m6YS7iVE0zwkuG+YFc11lEmNO5NLFOHyF9jS5nUVH8cuH79150Db/xU9Srm42nAysHXtWQASOyT3fFFxFvzF9Z4x8kSPj8QGRIYKrKjhEDRSJYRdlSYBDYUYk63FDvdRJ9Otlrwc57PA6LmO5ywOQytg/bN/r3L2+BO1LIJmkoy49tEaPvsJXldwqCXh2FpjzwuYdOg41ZE9uDWaoEBZWRzSoVej0/Xju0fDYKQKqx0q0wxJNGmqqzIu3NQAKFCdR0gvGSkPmt4lUtcXUhkaSlnbHaSedouWyOl9BJ9aI+2x150NUyUxW5EQv0UIL0UB+lNJMsc37qmiqqWQ6X5RwWyyXlyAXOqCLM0D4HoMKvWKuaMNgfnHNF/OePD2FA1/8wGtG2UZBTw6UpniXqtXAcnub4JKHUsGby1eOxEggiBSL320sgNLpQyMEvYgZlp9RNHiFHKlTNmgDm0USZgNYBZNBD2bYY0V5UZeLwLGyKwCrPi3yw8aMjYaDLxhhscEJe0iCDQc7KJ7Au8c4eSAAuswHaJBHgC89i13LCrtL5f9XVHJkR1SjQ/QDtD9lgzcjDpaTA5wPK3Cm+YvVayZw7O90K53zBG66xT5Rx3HNeSynpIANau1tlfAU4w5ztOdklBjJGph43adjXeOfy9p7P8G3UGSxo5wnenVlQGWSMzhMAwMYwM7/lR4Gb/SDHYaj5xlQSUcCMYt78J20DntpQgwBFkQxFRY/7NVYJqDWCsocB7YHcoP6gSnwlbNZ1uoWaRuFFIObvfN9lxOzzX1xk5YDNn7Q6+tpDJg80FoVEhVTq+ftkyhuhbphVMjvWwR6jNfZEghMRz1PMQRp6RyJKLAA';
export default {
 async scheduled(event,env,ctx){ctx.waitUntil(rpc(env,'tower_service_monthly_tick_391',{}).catch(()=>console.warn('SERVICE_MONTHLY_TICK_FAILED')));ctx.waitUntil(processAndroid390(env).catch(()=>console.warn('ANDROID_QUEUE_RUN_FAILED')));ctx.waitUntil(processPush383(env).catch(()=>console.warn('PUSH_QUEUE_RUN_FAILED')));ctx.waitUntil(scheduledTelegramRun(env).catch(e=>console.error('TELEGRAM_QUEUE_RUN_FAILED',String(e.message||e).slice(0,70))));ctx.waitUntil(towerHealthMonitorRun(env).catch(e=>console.error('HEALTH_MONITOR_RUN_FAILED',String(e.message||e).slice(0,70))));ctx.waitUntil(db(env,'rpc/tower_task_scheduled_ready_214',{method:'POST',body:{}}).catch(e=>console.error('TASK_SCHEDULED_READY_FAILED',String(e.dbCode||e.message||e).slice(0,80))));},
 async fetch(request,env,ctx){
 const u=new URL(request.url);
 if(request.method==='GET'&&u.pathname==='/api/building/facade391.webp')return new Response(Uint8Array.from(atob(BUILDING_FACADE391),c=>c.charCodeAt(0)),{headers:{'content-type':'image/webp','cache-control':'public,max-age=31536000,immutable','x-content-type-options':'nosniff'}});
 // Dashboard navigation uses only the public project reference; no database request or secret leaves the Worker.
 if(request.method==='GET'&&u.pathname==='/api/maintenance/supabase'){const match=/^https:\/\/([a-z0-9-]+)\.supabase\.co\/?$/.exec(String(env.SUPABASE_URL||''));return new Response(null,{status:302,headers:{Location:match?'https://supabase.com/dashboard/project/'+match[1]:'https://supabase.com/dashboard/projects','cache-control':'no-store'}});}
 if(request.method==='GET'&&u.pathname==='/api/android/version')return respond({versionName:'1.0.1',versionCode:2,minAndroid:26,apkUrl:'https://github.com/islamsallams/tower-app/raw/main/android-releases/V1.0.1/Tower_Android_V1.0.1.apk'});
 if(request.method==='GET'&&u.pathname==='/api/android/config'){const config=androidConfig390(env);return respond(config?{configured:true,appId:config.public.appId,apiKey:config.public.apiKey,projectId:config.public.projectId,senderId:String(config.public.senderId)}:{configured:false});}
 if(request.method==='GET'&&u.pathname==='/api/push/sw.js')return new Response(PUSH_SW383,{headers:{'content-type':'application/javascript; charset=utf-8','cache-control':'no-store','service-worker-allowed':'/','x-content-type-options':'nosniff'}});
 if(request.method==='GET'&&['/api/brand/logo','/api/brand/main'].includes(u.pathname))return serveBrandImage(env,u.pathname.endsWith('logo')?'logo':'main');
 if(u.pathname==='/api/telegram/webhook'&&request.method==='POST'){try{return await telegramWebhook(env,request);}catch(e){console.error('TELEGRAM_WEBHOOK_FAILED',String(e.message||e).slice(0,80));return fail('WEBHOOK_ERROR',500);}}
 if(u.pathname==='/api/tower'&&request.method==='POST'){
  // Bound the input stream before parsing. PDF uploads are larger because of Base64,
  // while ordinary API calls retain the previous request limits.
  const maxPdfRequestBytes=34*1024*1024;
  if(Number(request.headers.get('content-length')||0)>maxPdfRequestBytes)return fail('REQUEST_TOO_LARGE',413);
  let p, requestBytes=0;
  try{
   const reader=request.body?.getReader();if(!reader)return fail('INVALID_JSON');
   const parts=[];
   while(true){const {done,value}=await reader.read();if(done)break;
    requestBytes+=value.byteLength;
    if(requestBytes>maxPdfRequestBytes){await reader.cancel().catch(()=>{});return fail('REQUEST_TOO_LARGE',413);}
    parts.push(value);
   }
   const data=new Uint8Array(requestBytes);let offset=0;
   for(const part of parts){data.set(part,offset);offset+=part.byteLength;}
   p=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(data));
  }catch(_){return fail('INVALID_JSON');}
  const pdfUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='telegramSettings'&&['sendPdf','autoPdfDispatch'].includes(p?.args?.[0]?.args?.[0]);
  const attachmentUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='addPaymentAttachment';
  const brandUpload=p?.method==='apiCall'&&p?.args?.[0]?.name==='adminBrandAsset';
  if(pdfUpload&&requestBytes>9*1024*1024)return fail('REQUEST_TOO_LARGE',413);
  const restoreReviewUpload=p?.method==='apiCall'&&['adminRestorePreview350','adminRestorePlan380','adminRestoreExecute380'].includes(p?.args?.[0]?.name);
  if(restoreReviewUpload&&requestBytes>32*1024*1024)return fail('REQUEST_TOO_LARGE',413);
  if(!pdfUpload && !restoreReviewUpload && requestBytes>1500000)return fail('REQUEST_TOO_LARGE',413);
  if(!pdfUpload && !attachmentUpload && !brandUpload && !restoreReviewUpload && JSON.stringify(p).length>65536)return fail('REQUEST_TOO_LARGE',413);
  try{const result=await dispatch(env,p,u.origin);if(ctx?.waitUntil&&shouldDrainPush383(p)){ctx.waitUntil(processPush383(env).catch(()=>console.warn('PUSH_QUEUE_RUN_FAILED')));ctx.waitUntil(processAndroid390(env).catch(()=>console.warn('ANDROID_QUEUE_RUN_FAILED')));}const rawData=p?.method==='apiCall'&&['push383','android390','adminRestorePlan380','adminRestoreSafety380','adminRestoreExecute380','adminRestoreStatus380','adminCreateEncryptedBackup350','adminRestorePreview350','adminResetScope350','adminOperationalResetPreview','adminDownloadRuntime350'].includes(p?.args?.[0]?.name);return respond({ok:true,result:rawData?result:await presentPersonLabels(env,result)});}catch(e){
   const raw=String(e.message||e);const code=typeof e.dbCode==='string'?e.dbCode:(/^[A-Z][A-Z0-9_]{2,45}$/.test(raw)?raw:'UNKNOWN');
   // Only explicit server-known errors may be displayed directly; raw exceptions can contain sensitive data.
   const known=Object.hasOwn(DB_USER_ERRORS,raw)||(/^[A-Z][A-Z0-9_]{2,45}$/.test(raw)&&/^(FORBIDDEN|SESSION_REQUIRED|INVALID_[A-Z0-9_]+|TELEGRAM_[A-Z0-9_]+|OPERATION_NOT_MIGRATED)$/.test(raw));
   const isLogin=p?.method==='loginWithCredentials';const message=raw==='ACCOUNT_INACTIVE'?DB_USER_ERRORS.ACCOUNT_INACTIVE:e.dbCode?raw:(known?raw:isLogin?'تعذر تسجيل الدخول الآن. حاول لاحقًا أو انسخ تفاصيل الخطأ للدعم.':'حدث خطأ غير متوقع. تحقق من سجل العملية قبل إعادة المحاولة لتجنب التكرار.');
   const trace=crypto.randomUUID().slice(0,8).toUpperCase();
   console.error('TOWER_OPERATION_FAILED',JSON.stringify({ref:trace,operation:String(p?.method==='apiCall'?p?.args?.[0]?.name||'apiCall':p?.method||'unknown').slice(0,65),dbCode:code}));
   return fail(message,raw==='SUPABASE_SERVER_ENV_MISSING'?503:raw.includes('SESSION_REQUIRED')?401:raw.includes('NOT_MIGRATED')?501:400,{code,reference:trace});
  }
 }
 if(u.pathname==='/api/health')return respond({ok:true,version:APP_VERSION,scope:'auth foundation'});
 return env.ASSETS.fetch(request);
}};

// ___________________________
// Tower App V3.3.0 - SQL_253.
// Code End

async function decorateTripSettlements244(env,token,rows){
 if(!rows.length)return rows;const fields=await rpc(env,'tower_trip_settlement_fields_244',{p_token:token,p_ids:rows.map(s=>s.settlementId)});
 if(!Array.isArray(fields))throw Error('INVALID_SETTLEMENT_RESPONSE');const byId=new Map(fields.map(f=>[f.settlementId,f]));return rows.map(row=>({...row,...(byId.get(row.settlementId)||{})}));
}
// ___________________________
// Tower App V3.3.0 - SQL_253.
// Code End

async function readPersonalUi199(env,token){try{return await rpc(env,'tower_personal_ui_preferences_248',{p_token:token,p_action:'get',p_payload:{}});}catch(e){console.warn('PERSONAL_UI_PREFERENCES_UNAVAILABLE');return {};}}

async function loginWithStatus300(env,login,pin){
 let result,original;
 try{result=await rpc(env,'tower_login',{p_login:login,p_pin:pin});}catch(e){if(e.httpStatus===429)throw e;original=e;}
 const item=Array.isArray(result)?result[0]:result;if(item?.token)return result;
 // Keep installed credential validation/throttling first; no credential hash or token is created here.
 let inactive=false;try{const rows=await db(env,'tower_users?select=status&login_id=eq.'+encodeURIComponent(login)+'&limit=1');inactive=rows[0]?.status==='INACTIVE';}catch(_){}
 if(inactive)throw Error('ACCOUNT_INACTIVE');if(original)throw original;return result;
}

async function readPendingActions300(env,token,user){
 const result=await rpc(env,'tower_pending_actions_251',{p_token:token});
 const items=Array.isArray(result?.items)?[...result.items]:[];const unavailable=[];
 if(['ADMIN','UNION'].includes(user.role)){
  const extra=await Promise.allSettled([rpc(env,'tower_onboarding',{p_token:token,p_action:'resetList',p_payload:{}}),rpc(env,'tower_collection_action',{p_token:token,p_action:'context',p_payload:{}})]);
  if(extra[0].status==='fulfilled'&&Array.isArray(extra[0].value)){const count=extra[0].value.filter(r=>r.status==='PENDING').length;if(count)items.push({kind:'pin',count});}else unavailable.push('pin');
  if(extra[1].status==='fulfilled'&&Array.isArray(extra[1].value?.reports)){const count=extra[1].value.reports.filter(r=>r.status==='PENDING_APPROVAL').length;if(count)items.push({kind:'collections',count});}else unavailable.push('collections');
 }
 return {...result,items,unavailable};
}
