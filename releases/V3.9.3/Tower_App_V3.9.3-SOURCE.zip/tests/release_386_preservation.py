from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.8.5/Tower_App_V3.8.5-SOURCE.zip');results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def funcs(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v[1]:s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=funcs(z.read('app.js').decode()),funcs(Path('app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)];trip=[n for n in a if re.search('trip|guard|settlement',n,re.I)]
check('all 86 report/PDF app blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('all 124 old trip, guard and settlement app blocks unchanged',len(trip)==124 and all(a[n]==b[n] for n in trip))
check('other app changes limited to startup navigation, status note, existing SW update and listener block boundary',all(a[n]==b[n] for n in a if n not in {'enterApp','pushDelivery384','loadPushStatus383','clearPushSession383'}) and a['clearPushSession383'].splitlines()[0]==b['clearPushSession383'].splitlines()[0])
a,b=funcs(z.read('worker.js').decode()),funcs(Path('worker.js').read_text())
check('old Worker business functions preserved outside Push transport, embedded SW and version',all(a[n]==b[n] for n in a if n not in {'processPush383','owner','towerPdfFrequencyDue'}) and a['towerPdfFrequencyDue'].replace('3.8.5','3.8.6')==b['towerPdfFrequencyDue'])
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all 33 old SQL files unchanged and SQL268 sole production addition',len(old)==33 and all(z.read(n)==Path(n).read_bytes() for n in old) and new-old=={'sql/STAGING_114_Original_SQL268_TRIP_NOTIFICATION_CONTENT.sql'})
check('CSS, bindings and raw notification permission policy retained',all(z.read(n)==Path(n).read_bytes() for n in ['styles.css','wrangler.toml']) and "silent:visible" in Path('worker.js').read_text() and "renotify:false" in Path('worker.js').read_text())
check('root/public assets identical',all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.8.6/preservation-results.json').write_text(json.dumps(results,indent=2))
