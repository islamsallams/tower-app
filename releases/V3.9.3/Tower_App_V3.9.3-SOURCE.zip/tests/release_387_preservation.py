from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.8.6/Tower_App_V3.8.6-SOURCE.zip');results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def funcs(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v[1]:s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=funcs(z.read('app.js').decode()),funcs(Path('app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)];trip=[n for n in a if re.search('trip|guard|settlement',n,re.I)]
check('all 86 report/PDF app blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('all trip/guard/settlement function bodies unchanged; final block has receipt listener only',all(a[n]==b[n] for n in trip if n!='consumePushTrip386') and a['consumePushTrip386'].splitlines()[0]==b['consumePushTrip386'].splitlines()[0])
check('only existing card and status read change outside global listener block',all(a[n]==b[n] for n in a if n not in {'pushCardBody383','loadPushStatus383','consumePushTrip386'}))
check('page audio, collapsed controls and source navigation unchanged',all(a[n]==b[n] for n in ['playNoticeTone350','noticeSoundControls350','openPushTrip386','navigateNotice340']))
a,b=funcs(z.read('worker.js').decode()),funcs(Path('worker.js').read_text())
check('all Worker server business, queue and transport functions unchanged except version constant',all(a[n]==b[n] for n in a if n not in {'tripTarget','towerPdfFrequencyDue'}) and a['towerPdfFrequencyDue'].replace('3.8.6','3.8.7')==b['towerPdfFrequencyDue'] and a['tripTarget'].splitlines()[0]==b['tripTarget'].splitlines()[0])
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all 34 SQL files unchanged and none added',len(old)==34 and old==new and all(z.read(n)==Path(n).read_bytes() for n in old))
check('styles, bindings and requested sound policy unchanged',all(z.read(n)==Path(n).read_bytes() for n in ['styles.css','wrangler.toml']) and 'silent:visible' in Path('worker.js').read_text() and 'renotify:false' in Path('worker.js').read_text())
check('root/public assets identical',all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.8.7/preservation-results.json').write_text(json.dumps(results,indent=2))
