package com.islamsallams.towerapp;
import java.net.URI;
final class NativePolicy {
 static boolean trusted(String value){try{URI u=new URI(value);return "https".equalsIgnoreCase(u.getScheme())&&"tower-app.islamsallams.workers.dev".equalsIgnoreCase(u.getHost())&&(u.getPort()==-1||u.getPort()==443)&&u.getRawUserInfo()==null;}catch(Exception e){return false;}}
 static boolean uuid(String value){return value!=null&&value.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");}
 static boolean receive(boolean enabled,String session,String owner,String incoming){return enabled&&session!=null&&!session.isEmpty()&&owner!=null&&!owner.isEmpty()&&owner.equals(incoming);}
 static boolean bind(String session,String epoch,String currentSession,String currentEpoch){return session!=null&&!session.isEmpty()&&session.equals(currentSession)&&epoch!=null&&!epoch.isEmpty()&&epoch.equals(currentEpoch);}
 static String fileName(String value){String s=value==null?"":value.replaceAll("[\\\\/\\p{Cntrl}]","_");return s.isEmpty()?"Tower_Export.bin":s.length()>160?s.substring(s.length()-160):s;}
 static String updateUrl(String value){if(value==null)return null;String prefix="https://github.com/islamsallams/tower-app/raw/main/";String url=value.startsWith(prefix)?"https://raw.githubusercontent.com/islamsallams/tower-app/main/"+value.substring(prefix.length()):value;return url.matches("https://raw\\.githubusercontent\\.com/islamsallams/tower-app/main/android-releases/V([0-9]+\\.[0-9]+\\.[0-9]+)/Tower_Android_V\\1\\.apk")?url:null;}
 static boolean checkUpdate(boolean manual,boolean signedIn,boolean busy,long now,long previous){return !busy&&(manual||signedIn&&now-previous>=6L*60*60*1000);}
 static boolean showUpdate(boolean manual,int current,int available,int shown){return available>current&&(manual||available>shown);}
}
