package com.islamsallams.towerapp;
public class NativeUpdateChecks {
 private static void yes(boolean value){if(!value)throw new AssertionError();}
 private static void pass(String text){System.out.println("PASS "+text);}
 public static void main(String[] args){String direct="https://raw.githubusercontent.com/islamsallams/tower-app/main/android-releases/V3.9.2/Tower_Android_V3.9.2.apk",old="https://github.com/islamsallams/tower-app/raw/main/android-releases/V3.9.2/Tower_Android_V3.9.2.apk";
 yes(direct.equals(NativePolicy.updateUrl(direct)));yes(direct.equals(NativePolicy.updateUrl(old)));for(String bad:new String[]{"https://evil.invalid/x.apk",direct+"?redirect=evil",direct+"#x",direct.replace("V3.9.2.apk","V1.0.1.apk"),direct.replace("/main/","/other/"),direct.replace("raw.githubusercontent.com","raw.githubusercontent.com.evil.invalid"),null})yes(NativePolicy.updateUrl(bad)==null);pass("update URLs normalize legacy links and allow only the matching first-party APK path");
 long now=100_000_000L;yes(NativePolicy.checkUpdate(false,true,false,now,0));yes(!NativePolicy.checkUpdate(false,true,false,now,now-1000));yes(!NativePolicy.checkUpdate(false,false,false,now,0));yes(!NativePolicy.checkUpdate(true,true,true,now,0));yes(NativePolicy.checkUpdate(true,false,false,now,now));pass("automatic checks require a session, avoid concurrent requests and observe six-hour cooldown while manual checks remain available");
 yes(NativePolicy.showUpdate(false,3,4,0));yes(!NativePolicy.showUpdate(false,3,4,4));yes(!NativePolicy.showUpdate(false,3,3,0));yes(!NativePolicy.showUpdate(true,3,2,0));yes(NativePolicy.showUpdate(true,3,4,4));pass("only newer versions prompt automatically once and manual checking can show a dismissed update");
 }
}
