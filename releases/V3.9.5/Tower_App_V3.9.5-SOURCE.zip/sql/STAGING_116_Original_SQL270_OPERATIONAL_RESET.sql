/*
Tower App V3.9.1 - SQL_270.
___________________________
Explicit operational reset. Installation does not delete any application rows.
*/
BEGIN;
CREATE OR REPLACE FUNCTION public.tower_operational_reset_391(p_token text,p_action text,p_payload jsonb DEFAULT '{}')
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public AS $f$
DECLARE actor public.tower_users; t text; all_tables text[]; deletes text[]:=ARRAY[]::text[];
 remove_tables constant text[]:=ARRAY[
 'tower_payment_attachments','tower_building_payments','tower_building_allocations','tower_building_charges','tower_charge_history_240','tower_charge_requests_240',
 'tower_collection_lines','tower_collection_reports','tower_collection_batches_233','tower_fund_entries',
 'tower_finance_advance_subscription_links','tower_finance_advance_use_subscriptions','tower_finance_advance_uses','tower_finance_applications','tower_finance_cash_movements','tower_finance_dues','tower_finance_mixed_collections','tower_finance_receipt_portions','tower_finance_receipts','tower_finance_refund_authorizations','tower_finance_refund_movements',
 'tower_service_change_requests','tower_service_subscriptions',
 'tower_trip_change_history','tower_trip_settlement_details','tower_trip_payments','tower_trips','tower_trip_settlements','tower_trip_notice_reads_257',
 'tower_notifications','tower_notification_reads','tower_notice_history_259','tower_telegram_delivery_log','tower_telegram_pdf_jobs',
 'tower_task_adjustments','tower_task_adjustment_lines','tower_task_agreements','tower_task_allocation_snapshots','tower_task_advance_refund_allocations','tower_task_credit_refunds','tower_task_credit_reversals','tower_task_donations','tower_task_donation_returns','tower_task_due_credits','tower_task_due_installments','tower_task_event_reads','tower_task_events','tower_task_expense_disbursements','tower_task_expenses','tower_task_fund_contributions','tower_task_fund_receipts','tower_task_interests','tower_task_projects','tower_task_requests_236','tower_task_workflow','tower_trip_close_requests_244','tower_trip_settlement_options_244'];
 keep_tables constant text[]:=ARRAY[
 'tower_audit','tower_brand_assets','tower_brand_presentation_251','tower_collection_categories','tower_daily_digest_schedule','tower_login_attempts','tower_member_requests','tower_members','tower_pin_reset_requests','tower_registration_requests','tower_schema_baselines','tower_schema_migration_registry','tower_schema_migrations','tower_services','tower_service_edit_history_230','tower_sessions','tower_system_settings','tower_telegram_accounts','tower_telegram_cron_health','tower_telegram_links','tower_telegram_pdf_preferences','tower_telegram_pdf_schedule','tower_titles','tower_trip_settings','tower_ui_preferences','tower_unit_fund_visibility','tower_unit_types','tower_units','tower_users','tower_welcome_progress','tower_personal_ui_preferences_248','tower_unit_states_262','tower_trip_unit_preferences_242','tower_finance_accounts','tower_finance_service_beneficiaries','tower_trip_alert_preferences_242'];
 rows_json jsonb:='[]';kept jsonb:='[]';unknowns jsonb:='[]';n bigint;total bigint:=0;hashes text:='';row_hash text;proof text;blocked boolean:=false;report jsonb;project_templates jsonb:='[]';workflow_templates jsonb:='[]';
BEGIN
 SELECT * INTO actor FROM public.tower_session_user(p_token);
 IF NOT FOUND OR actor.status<>'ACTIVE' OR actor.must_change_pin OR actor.role<>'ADMIN' THEN RAISE EXCEPTION 'FORBIDDEN';END IF;
 IF p_action IS NULL OR p_action NOT IN ('preview','execute') THEN RAISE EXCEPTION 'INVALID_ACTION';END IF;
 PERFORM pg_advisory_xact_lock(73912023);
 PERFORM pg_advisory_xact_lock(hashtext('tower-operational-reset-391'));
 SELECT array_agg(c.relname ORDER BY c.relname) INTO all_tables FROM pg_class c JOIN pg_namespace ns ON ns.oid=c.relnamespace WHERE ns.nspname='public' AND c.relkind IN ('r','p') AND c.relname LIKE 'tower\_%' ESCAPE '\';
 -- Stable counts, full row fingerprints and FK checks in the same transaction as deletion.
 EXECUTE 'LOCK TABLE '||(SELECT string_agg(format('public.%I',x),',' ORDER BY x) FROM unnest(all_tables) x)||' IN SHARE ROW EXCLUSIVE MODE';
 FOREACH t IN ARRAY all_tables LOOP
  EXECUTE format('SELECT count(*) FROM public.%I',t) INTO n;
  IF t=ANY(remove_tables) THEN
   deletes:=array_append(deletes,t);total:=total+n;
   EXECUTE format('SELECT md5(coalesce(string_agg(to_jsonb(r)::text,E''\n'' ORDER BY to_jsonb(r)::text),'''')) FROM public.%I r',t) INTO row_hash;
   hashes:=hashes||t||':'||n||':'||row_hash||';';
   rows_json:=rows_json||jsonb_build_array(jsonb_build_object('table',t,'count',n));
  ELSIF t=ANY(keep_tables) THEN kept:=kept||jsonb_build_array(jsonb_build_object('table',t,'count',n));
  ELSE unknowns:=unknowns||jsonb_build_array(jsonb_build_object('table',t,'count',n));END IF;
 END LOOP;
 -- Never CASCADE into an unapproved table, including tables outside public.
 SELECT EXISTS(SELECT 1 FROM pg_constraint f WHERE f.contype='f' AND f.confrelid IN(SELECT to_regclass(format('public.%I',x)) FROM unnest(deletes)x) AND f.conrelid NOT IN(SELECT to_regclass(format('public.%I',x)) FROM unnest(deletes)x)) INTO blocked;
 proof:=md5(actor.user_id::text||':'||public.tower_backup_fingerprint_263()||':'||hashes);
 report:=jsonb_build_object('scope','OPERATIONAL_RESET_391','executionEnabled',jsonb_array_length(unknowns)=0 AND NOT blocked,'previewToken',proof,'totalRows',total,'tableCount',cardinality(deletes),'protectedCount',jsonb_array_length(kept),'tables',rows_json,'protectedTables',kept,'reviewTables',unknowns,'blockedRelations',blocked,'backupCreated',false);
 IF p_action='preview' THEN RETURN report;END IF;
 IF p_payload->>'confirmation' IS DISTINCT FROM 'RESET TOWER APP' OR p_payload->>'acknowledgeNoBackup' IS DISTINCT FROM 'true' THEN RAISE EXCEPTION 'RESET_CONFIRMATION_REQUIRED';END IF;
 IF p_payload->>'previewToken' IS DISTINCT FROM proof THEN RAISE EXCEPTION 'RESET_PREVIEW_CHANGED';END IF;
 IF jsonb_array_length(unknowns)>0 OR blocked OR cardinality(deletes)=0 THEN RAISE EXCEPTION 'RESET_SCOPE_REVIEW_REQUIRED';END IF;
 -- Preserve task definitions while resetting participation, deadlines and execution state.
 IF to_regclass('public.tower_task_projects') IS NOT NULL THEN
  SELECT coalesce(jsonb_agg(to_jsonb(p)||jsonb_build_object('phase','PARTICIPATION','closure_note','','deadline',NULL,'agreed_amounts','[]'::jsonb,'version',coalesce((to_jsonb(p)->>'version')::bigint,0)+1,'updated_by',actor.user_id,'updated_at',now())),'[]') INTO project_templates FROM public.tower_task_projects p;
 END IF;
 IF to_regclass('public.tower_task_workflow') IS NOT NULL THEN
  SELECT coalesce(jsonb_agg(to_jsonb(w)||jsonb_build_object('stage','COLLECT_SUBSCRIBERS','execution_date',NULL,'first_due_date',NULL,'execution_percent',0,'fund_contribution_proposed',0,'revision',coalesce((to_jsonb(w)->>'revision')::bigint,0)+1,'updated_by',actor.user_id,'updated_at',now())),'[]') INTO workflow_templates FROM public.tower_task_workflow w;
 END IF;
 IF to_regprocedure('tower_push383.pause_restore()') IS NOT NULL THEN EXECUTE 'SELECT tower_push383.pause_restore()';END IF;
 IF to_regprocedure('tower_android390.pause_restore()') IS NOT NULL THEN EXECUTE 'SELECT tower_android390.pause_restore()';END IF;
 EXECUTE 'TRUNCATE TABLE '||(SELECT string_agg(format('public.%I',x),',' ORDER BY x) FROM unnest(deletes)x)||' CONTINUE IDENTITY RESTRICT';
 IF to_regclass('public.tower_task_projects') IS NOT NULL THEN
  INSERT INTO public.tower_task_projects SELECT * FROM jsonb_populate_recordset(NULL::public.tower_task_projects,project_templates);
 END IF;
 IF to_regclass('public.tower_task_workflow') IS NOT NULL THEN
  INSERT INTO public.tower_task_workflow SELECT * FROM jsonb_populate_recordset(NULL::public.tower_task_workflow,workflow_templates);
 END IF;
 UPDATE public.tower_services SET enrollment_status='OPEN',updated_at=now() WHERE pricing_mode='SHARED_TOTAL';
 IF p_payload->>'resetWelcome'='true' AND to_regclass('public.tower_welcome_progress') IS NOT NULL THEN DELETE FROM public.tower_welcome_progress;END IF;
 INSERT INTO public.tower_audit(actor_id,action,entity,entity_id) VALUES(actor.user_id,'OPERATIONAL_RESET_391','SYSTEM','391');
 RETURN jsonb_build_object('success',true,'deletedRows',total,'backupCreated',false);
END $f$;
REVOKE ALL ON FUNCTION public.tower_operational_reset_391(text,text,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.tower_operational_reset_391(text,text,jsonb) TO service_role;
NOTIFY pgrst,'reload schema';
COMMIT;
/*
___________________________
Tower App V3.9.1 - SQL_270.
Code End
*/
