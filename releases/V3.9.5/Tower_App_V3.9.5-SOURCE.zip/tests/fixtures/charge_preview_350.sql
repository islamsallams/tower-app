/*
Tower App V3.5.0 - SQL_262.
___________________________
*/
-- Original definition supplied by user via read-only pg_get_functiondef, 2026-10-29.
-- Schema code only, no user rows. Preserved as the actual pre-policy allocator fixture.
CREATE OR REPLACE FUNCTION public.tower_charge_preview(p_payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare v_dist text:=upper(coalesce(p_payload->>'distribution','EQUAL_ALL'));
 v_total numeric(14,2); v_active_weight numeric; v_base_weight numeric; v_used numeric(14,2):=0;
 v_unit record; v_weight numeric; v_base numeric(14,2); v_amount numeric(14,2);
 v_deferred boolean; v_custom jsonb:=coalesce(p_payload->'customAmounts','{}'::jsonb);
 v_selected jsonb:=coalesce(p_payload->'unitIds','[]'::jsonb);
 v_delayed jsonb:=coalesce(p_payload->'deferredUnitIds','[]'::jsonb);
 v_category public.tower_collection_categories; v_rows jsonb:='[]'::jsonb;
 v_target_count int; v_active_count int; v_active_idx int:=0; v_sum numeric(14,2):=0;
begin
 if v_dist not in ('EQUAL_ALL','EQUAL_SELECTED','TYPE_POLICY','CATEGORY_POLICY','CUSTOM') then raise exception 'INVALID_DISTRIBUTION'; end if;
 if jsonb_typeof(v_selected)<>'array' or jsonb_typeof(v_delayed)<>'array' or jsonb_typeof(v_custom)<>'object' then raise exception 'INVALID_ALLOCATION_INPUT'; end if;
 if coalesce(p_payload->>'totalAmount','') !~ '^[0-9]{1,10}(\.[0-9]{1,2})?$' then raise exception 'INVALID_TOTAL'; end if;
 v_total:=(p_payload->>'totalAmount')::numeric;
 if v_total<=0 then raise exception 'INVALID_TOTAL'; end if;
 if v_dist='CATEGORY_POLICY' and nullif(p_payload->>'categoryId','') is not null then
   select * into v_category from public.tower_collection_categories where category_id=(p_payload->>'categoryId')::uuid and status='ACTIVE';
   if not found then raise exception 'CATEGORY_NOT_FOUND'; end if;
 end if;
 -- Serialize target and weight selection in one ordered set; previews cannot write data.
 with targets as (
 select u.unit_id,u.unit_number,u.floor,u.unit_type_id,t.name type_name,
 case when v_dist in ('TYPE_POLICY','CATEGORY_POLICY') then
   case when v_dist='CATEGORY_POLICY' and v_category.category_id is not null
        then greatest(0.01,coalesce(nullif((v_category.weights->>u.unit_type_id::text)::numeric,0),1))
        else greatest(0.01,coalesce(nullif(t.collection_weight,0),1)) end
 else 1::numeric end w,
 (v_delayed ? u.unit_id::text) defer,
 case when (v_custom->>u.unit_id::text) ~ '^[0-9]{1,10}(\.[0-9]{1,2})?$' then (v_custom->>u.unit_id::text)::numeric else 0::numeric end custom_amount
 from public.tower_units u join public.tower_unit_types t on t.unit_type_id=u.unit_type_id
 where u.status='ACTIVE' and (
 v_dist='EQUAL_ALL' or
 (v_dist in ('TYPE_POLICY','CATEGORY_POLICY') and jsonb_array_length(v_selected)=0) or
 (v_selected ? u.unit_id::text) or
 (v_dist='CUSTOM' and (v_delayed ? u.unit_id::text or coalesce((v_custom->>u.unit_id::text)::numeric,0)>0))
 )
 )
 select count(*), count(*) filter(where not defer),coalesce(sum(w),0),coalesce(sum(w) filter(where not defer),0),
 coalesce(sum(custom_amount) filter(where not defer),0)
 into v_target_count,v_active_count,v_base_weight,v_active_weight,v_sum from targets;
 if v_target_count=0 then raise exception 'UNITS_REQUIRED'; end if;
 if v_dist<>'CUSTOM' and v_active_count=0 then raise exception 'ALL_UNITS_DEFERRED'; end if;
 if v_dist='CUSTOM' and abs(v_sum-v_total)>0.01 then raise exception 'CUSTOM_TOTAL_MISMATCH'; end if;
 for v_unit in
  select u.unit_id,u.unit_number,u.floor,u.unit_type_id,t.name type_name,
  case when v_dist in ('TYPE_POLICY','CATEGORY_POLICY') then
   case when v_dist='CATEGORY_POLICY' and v_category.category_id is not null
       then greatest(0.01,coalesce(nullif((v_category.weights->>u.unit_type_id::text)::numeric,0),1))
       else greatest(0.01,coalesce(nullif(t.collection_weight,0),1)) end else 1::numeric end weight,
  (v_delayed ? u.unit_id::text) deferred,
  case when (v_custom->>u.unit_id::text) ~ '^[0-9]{1,10}(\.[0-9]{1,2})?$' then (v_custom->>u.unit_id::text)::numeric else 0::numeric end custom_amount
  from public.tower_units u join public.tower_unit_types t on t.unit_type_id=u.unit_type_id
  where u.status='ACTIVE' and (
   v_dist='EQUAL_ALL' or
   (v_dist in ('TYPE_POLICY','CATEGORY_POLICY') and jsonb_array_length(v_selected)=0) or
   (v_selected ? u.unit_id::text) or
   (v_dist='CUSTOM' and ((v_delayed ? u.unit_id::text) or coalesce((v_custom->>u.unit_id::text)::numeric,0)>0))
  ) order by u.unit_number,u.unit_id
 loop
  v_weight:=v_unit.weight;
  if v_dist='CUSTOM' then v_base:=v_unit.custom_amount;
  else v_base:=round(v_total*v_weight/v_base_weight,2); end if;
  if v_unit.deferred then v_amount:=0;
  elsif v_dist='CUSTOM' then v_amount:=v_unit.custom_amount;
  else
   v_active_idx:=v_active_idx+1;
   if v_active_idx=v_active_count then v_amount:=v_total-v_used;
   else v_amount:=round(v_total*v_weight/v_active_weight,2); end if;
   v_used:=v_used+v_amount;
  end if;
  v_rows:=v_rows || jsonb_build_array(jsonb_build_object('unitId',v_unit.unit_id,'unitNumber',v_unit.unit_number,
   'floor',v_unit.floor,'unitTypeId',v_unit.unit_type_id,'unitTypeName',v_unit.type_name,
   'weight',v_weight,'baseAmount',v_base,'amount',v_amount,'deferred',v_unit.deferred));
 end loop;
 return v_rows;
end $function$;

/*
___________________________
Tower App V3.5.0 - SQL_262.
Code End
*/
