// Frozen V3.0.0 code for reproducing the observer feedback bug; no user data.
function paintPendingActions300(){
 const current=window.PENDING_ACTIONS300;document.querySelectorAll('[data-pending-state300]').forEach(el=>{el.textContent=window.PENDING_ERROR300?'تعذر تحديث الطلبات؛ أعد المحاولة.':current&&pendingOrigin300(current.origin)?'طلبات تحتاج إجراء منك: '+current.items.reduce((n,item)=>n+item.count,0):'جاري تحميل حالة الطلبات…';});
 if(!current||!pendingOrigin300(current.origin))return;
 const mark=(element,count)=>{if(!element)return;element.classList.toggle('pending-target300',count>0);if(count>0)element.dataset.pendingCount=String(count);else delete element.dataset.pendingCount;};
 document.querySelectorAll('.nav-btn').forEach(el=>{const key=Object.keys(NAV_PENDING).find(k=>el.classList.contains('nav-'+k));el.classList.toggle('pending-alert',Boolean(key&&NAV_PENDING[key]>0)||el.classList.contains('nav-more')&&mobileMoreHasPending(APP.ctx.user.role));});
 mark(document.querySelector('#headerMenu199>summary'),NAV_PENDING.settings);
 const security=pendingCount300(['pin','registration']);
 document.querySelectorAll('[data-group="security"]').forEach(el=>mark(el,security));
 document.querySelectorAll('[onclick]').forEach(el=>{const action=el.getAttribute('onclick')||'';let count=null;
  if(/openActiveUnitPicker\(/.test(action))count=pendingCount300(['membership','registration']);
  else if(/headerAction199\(['"]settings['"]\)/.test(action))count=NAV_PENDING.settings;
  else if(/go\(['"]admin-pin['"]\)/.test(action))count=pendingCount300(['pin']);
  else if(/go\(['"]admin-registration['"]\)/.test(action))count=pendingCount300(['registration']);
  else if(/openPendingRequests300/.test(action))count=pendingItems300().reduce((n,x)=>n+x.count,0);
  else if(/openServiceSummary183\(['"]subscriptions['"]/.test(action))count=pendingCount300(['subscription']);
  else if(/openServiceSummary183\(['"]changes['"]/.test(action))count=pendingCount300(['serviceChange']);
  else if(/selectResidentUnitTab\(['"]requests['"]/.test(action))count=pendingCount300(['registration','membership'],null,APP.activeUnitId);
  else if(/selectCollectionWorkspaceTab\(['"]approvals['"]/.test(action))count=pendingCount300(['collections']);
  const unitAction=/switchActiveUnit\(['"]([a-f0-9-]{36})['"]/i.exec(action);if(unitAction)count=pendingCount300(['membership','registration'],null,unitAction[1]);
  const serviceAction=/(?:openTaskProject|openServiceWorkspace)\(['"]([a-f0-9-]{36})['"]/i.exec(action);if(serviceAction)count=pendingCount300(['subscription','serviceChange','taskManagement'],serviceAction[1]);
  if(count!==null){mark(el,count);const row=el.closest('.setting-row');if(row)mark(row,count);}
 });
 mark($('people-member-requests'),pendingCount300(['membership']));
 document.querySelectorAll('[data-service-id]').forEach(el=>mark(el,pendingCount300(['subscription','serviceChange','taskManagement'],el.getAttribute('data-service-id'))));
 const sw=typeof SERVICE_WORKSPACE!=='undefined'?SERVICE_WORKSPACE:null;if(sw&&typeof serviceWorkspaceOriginMatches==='function'&&serviceWorkspaceOriginMatches(sw))document.querySelectorAll('.task-workspace-tabs button').forEach(button=>{if((button.getAttribute('onclick')||'').includes("'members'"))mark(button,pendingCount300(['subscription','serviceChange'],sw.serviceId));});
 document.querySelectorAll('[data-task-project-id]').forEach(el=>{const id=el.getAttribute('data-task-project-id');el.querySelectorAll('.task-workspace-tabs button').forEach(button=>{const action=button.getAttribute('onclick')||'';if(action.includes("'members'"))mark(button,pendingCount300(['subscription'],id));else if(action.includes("'overview'"))mark(button,pendingCount300(['taskManagement'],id));});});
}
