CREATE OR REPLACE FUNCTION public.tower_service_change_action(p_token text, p_action text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare a public.tower_users; sub public.tower_service_subscriptions; svc public.tower_services;
 q public.tower_service_change_requests; v_sub uuid; v_request uuid; v_unit uuid;
 v_qty integer; v_new integer; v_type text; v_decision text;
begin
 select * into a from public.tower_session_user(p_token);
 if not found or a.status<>'ACTIVE' or a.must_change_pin then raise exception 'SESSION_REQUIRED'; end if;
 if p_action in ('updatePending','requestChange','cancelPending','mine') then
  if a.role<>'RESIDENT' then raise exception 'FORBIDDEN'; end if;
  select m.unit_id into v_unit from public.tower_members m
   WHERE m.user_id=a.user_id AND m.ended_at IS NULL AND m.unit_id=(p_payload->>'unitId')::uuid AND EXISTS (SELECT 1 FROM public.tower_units z WHERE z.unit_id=m.unit_id AND z.status='ACTIVE') /*TOWER_EXPLICIT_SERVICE_UNIT_121*/  limit 1;
  if v_unit is null then raise exception 'UNIT_MEMBERSHIP_REQUIRED'; end if;
  if p_action='mine' then
   return coalesce((select jsonb_agg(jsonb_build_object('requestId',r.request_id,
    'subscriptionId',r.subscription_id,'serviceId',r.service_id,'type',r.type,
    'quantityDelta',r.quantity_delta,'requestedQuantity',r.requested_quantity,
    'status',r.status,'requestedAt',r.requested_at))
    from public.tower_service_change_requests r where r.unit_id=v_unit),'[]'::jsonb);
  end if;
  begin v_sub := (p_payload->>'subscriptionId')::uuid;
  exception when invalid_text_representation or null_value_not_allowed then raise exception 'INVALID_SUBSCRIPTION_ID'; end;
  select * into sub from public.tower_service_subscriptions
   where subscription_id=v_sub and unit_id=v_unit for update;
  if not found then raise exception 'SUBSCRIPTION_NOT_FOUND'; end if;
  select * into svc from public.tower_services where service_id=sub.service_id;
  if not found then raise exception 'SERVICE_NOT_FOUND'; end if;
  if p_action='cancelPending' then
   if sub.status<>'PENDING' then raise exception 'REQUEST_NOT_PENDING'; end if;
   delete from public.tower_service_subscriptions where subscription_id=v_sub;
   insert into public.tower_audit(actor_id,action,entity,entity_id)
    values(a.user_id,'CANCEL_PENDING_SERVICE_REQUEST','SERVICE_SUBSCRIPTION',v_sub::text);
   return jsonb_build_object('success',true);
  end if;
  if coalesce(p_payload->>'quantity','') !~ '^[0-9]{1,2}$' then raise exception 'INVALID_QUANTITY'; end if;
  v_qty := (p_payload->>'quantity')::integer;
  if v_qty<1 or v_qty>99 then raise exception 'INVALID_QUANTITY'; end if;
  if not svc.allow_quantity then v_qty:=1; end if;
  if p_action='updatePending' then
   if sub.status<>'PENDING' then raise exception 'REQUEST_NOT_PENDING'; end if;
   update public.tower_service_subscriptions set quantity=v_qty,
    amount_snapshot=round(unit_price_snapshot*v_qty,2), updated_at=now()
    where subscription_id=v_sub;
   insert into public.tower_audit(actor_id,action,entity,entity_id)
    values(a.user_id,'UPDATE_PENDING_SERVICE_REQUEST','SERVICE_SUBSCRIPTION',v_sub::text);
   return jsonb_build_object('success',true,'quantity',v_qty);
  end if;
  if sub.status<>'ACTIVE' then raise exception 'SUBSCRIPTION_NOT_ACTIVE'; end if;
  v_type:=upper(coalesce(p_payload->>'type',''));
  if v_type not in ('ADD','REDUCE') then raise exception 'INVALID_CHANGE_TYPE'; end if;
  if v_type='REDUCE' and not svc.cancelable then raise exception 'SERVICE_NOT_CANCELABLE'; end if;
  if v_type='REDUCE' and v_qty>sub.quantity then raise exception 'REDUCE_EXCEEDS_QUANTITY'; end if;
  v_new:=sub.quantity + case when v_type='ADD' then v_qty else -v_qty end;
  if v_new>99 then raise exception 'QUANTITY_LIMIT'; end if;
  insert into public.tower_service_change_requests(subscription_id,service_id,unit_id,requested_by,
   type,quantity_delta,requested_quantity)
   values(v_sub,sub.service_id,v_unit,a.user_id,v_type,
    case when v_type='ADD' then v_qty else -v_qty end,v_new)
   returning request_id into v_request;
  insert into public.tower_audit(actor_id,action,entity,entity_id)
   values(a.user_id,'REQUEST_SERVICE_CHANGE','SERVICE_CHANGE_REQUEST',v_request::text);
  return jsonb_build_object('success',true,'requestId',v_request);
 end if;
 if a.role not in ('ADMIN','UNION') then raise exception 'FORBIDDEN'; end if;
 if p_action='list' then
  return coalesce((select jsonb_agg(jsonb_build_object(
   'requestId',r.request_id,'subscriptionId',r.subscription_id,'serviceId',r.service_id,
   'unitId',r.unit_id,'unitNumber',u.unit_number,'serviceName',s.name,'type',r.type,
   'quantityDelta',r.quantity_delta,'requestedQuantity',r.requested_quantity,
   'status',r.status,'requestedAt',r.requested_at,'requestedByUserId',r.requested_by,
   'reviewedAt',r.reviewed_at,'reviewedByUserId',r.reviewed_by,'notes',r.notes)
   order by r.requested_at desc) from public.tower_service_change_requests r
   join public.tower_units u on u.unit_id=r.unit_id
   join public.tower_services s on s.service_id=r.service_id),'[]'::jsonb);
 end if;
 if p_action='review' then
  begin v_request:=(p_payload->>'requestId')::uuid;
  exception when invalid_text_representation or null_value_not_allowed then raise exception 'INVALID_REQUEST_ID'; end;
  v_decision:=upper(coalesce(p_payload->>'decision',''));
  if v_decision not in ('APPROVE','REJECT') then raise exception 'INVALID_DECISION'; end if;
  select * into q from public.tower_service_change_requests where request_id=v_request for update;
  if not found or q.status<>'PENDING' then raise exception 'REQUEST_NOT_PENDING'; end if;
  select * into sub from public.tower_service_subscriptions where subscription_id=q.subscription_id for update;
  if not found or sub.status<>'ACTIVE' then raise exception 'SUBSCRIPTION_NOT_ACTIVE'; end if;
  if v_decision='APPROVE' then
   if sub.quantity + q.quantity_delta <> q.requested_quantity then raise exception 'SUBSCRIPTION_QUANTITY_CHANGED'; end if;
   update public.tower_service_subscriptions set quantity=q.requested_quantity,
    amount_snapshot=round(unit_price_snapshot*q.requested_quantity,2),
    status=case when q.requested_quantity=0 then 'ENDED' else status end,
    ended_at=case when q.requested_quantity=0 then now() else ended_at end,
    updated_at=now() where subscription_id=q.subscription_id;
  end if;
  update public.tower_service_change_requests set status=case when v_decision='APPROVE' then 'APPROVED' else 'REJECTED' end,
   reviewed_at=now(),reviewed_by=a.user_id,notes=left(coalesce(p_payload->>'notes',''),1000),updated_at=now()
   where request_id=v_request;
  insert into public.tower_audit(actor_id,action,entity,entity_id)
   values(a.user_id,'REVIEW_SERVICE_CHANGE','SERVICE_CHANGE_REQUEST',v_request::text);
  return jsonb_build_object('success',true,'status',case when v_decision='APPROVE' then 'APPROVED' else 'REJECTED' end);
 end if;
 raise exception 'UNKNOWN_ACTION';
end $function$
