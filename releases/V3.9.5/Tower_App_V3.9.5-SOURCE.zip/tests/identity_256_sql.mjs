import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const id=n=>`${String(n).padStart(8,'0')}-1111-4111-8111-111111111111`;
async function check(name,f){await f();results.push({check:name,status:'PASS'});console.log('PASS',name);}
const pending=async(n=1)=>(await db.query('SELECT tower_pending_actions_251($1) v',[id(n)])).rows[0].v;
const brand=async(n,action,payload={})=>(await db.query('SELECT tower_brand_settings_251($1,$2,$3) v',[id(n),action,payload])).rows[0].v;
try{
await db.exec(`CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY,role text,status text,must_change_pin boolean);
CREATE FUNCTION tower_session_user(p_token text) RETURNS SETOF tower_users LANGUAGE sql AS $$SELECT * FROM tower_users WHERE user_id=p_token::uuid$$;
CREATE TABLE tower_units(unit_id uuid PRIMARY KEY,unit_number text,status text);
CREATE TABLE tower_members(user_id uuid,unit_id uuid,member_role text,ended_at timestamptz);
CREATE TABLE tower_registration_requests(unit_id uuid,status text,manager_opinion text);
CREATE TABLE tower_member_requests(unit_id uuid,status text,manager_opinion text);
CREATE TABLE tower_services(service_id uuid PRIMARY KEY,name text,service_kind text,pricing_mode text,status text);
CREATE TABLE tower_finance_accounts(service_id uuid,beneficiary_user_id uuid,account_kind text,status text);
CREATE TABLE tower_task_projects(service_id uuid PRIMARY KEY,phase text);
CREATE TABLE tower_task_requests_236(service_id uuid,state text);
CREATE TABLE tower_service_subscriptions(unit_id uuid,service_id uuid,status text);
CREATE TABLE tower_service_change_requests(unit_id uuid,service_id uuid,status text);
CREATE TABLE fixture_settings(settings jsonb);INSERT INTO fixture_settings VALUES('{"branding":{"systemName":"fixture","heroFocusX":40,"heroFocusY":60}}');
CREATE TABLE fixture_ledger(amount numeric);INSERT INTO fixture_ledger VALUES(89.74);
CREATE FUNCTION tower_admin_system_settings(p_token text,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$DECLARE value jsonb;BEGIN IF p_action='save' THEN IF p_payload->'branding'->>'systemName'='FAIL' THEN RAISE EXCEPTION 'FIXTURE_SAVE_REJECTED';END IF;UPDATE fixture_settings SET settings=p_payload;END IF;SELECT settings INTO value FROM fixture_settings;RETURN value;END$$;`);
for(const [n,role] of [[1,'ADMIN'],[2,'UNION'],[3,'RESIDENT'],[4,'RESIDENT'],[5,'OPERATOR'],[6,'OPERATOR']])await db.query("INSERT INTO tower_users VALUES($1,$2,'ACTIVE',false)",[id(n),role]);
await db.exec(`INSERT INTO tower_units VALUES('${id(10)}','26','ACTIVE'),('${id(11)}','27','ACTIVE');
INSERT INTO tower_members VALUES('${id(3)}','${id(10)}','MANAGER',null),('${id(4)}','${id(10)}','MEMBER',null);
INSERT INTO tower_registration_requests VALUES('${id(10)}','PENDING',null),('${id(10)}','PENDING','SUPPORT'),('${id(11)}','PENDING',null),('${id(10)}','APPROVED',null);
INSERT INTO tower_member_requests VALUES('${id(10)}','PENDING',null),('${id(10)}','PENDING','OBJECT'),('${id(11)}','PENDING',null);
INSERT INTO tower_services VALUES('${id(20)}','fixture task','ONE_TIME','SHARED_TOTAL','ACTIVE'),('${id(21)}','fixture service','RECURRING','PER_SUBSCRIPTION','ACTIVE');
INSERT INTO tower_task_projects VALUES('${id(20)}','PARTICIPATION_OPEN');
INSERT INTO tower_finance_accounts VALUES('${id(20)}','${id(5)}','PERSONAL_SERVICE','ACTIVE');
INSERT INTO tower_service_subscriptions VALUES('${id(10)}','${id(20)}','PENDING'),('${id(11)}','${id(21)}','PENDING'),('${id(11)}','${id(21)}','ACTIVE');
INSERT INTO tower_service_change_requests VALUES('${id(11)}','${id(21)}','PENDING');
INSERT INTO tower_task_requests_236 VALUES('${id(20)}','PENDING'),('${id(20)}','REVIEWED');`);
const sql=fs.readFileSync('sql/STAGING_101_Original_SQL251_BRANDING_AND_PENDING_ACTIONS.sql','utf8');await db.exec(sql);

await db.exec(`CREATE TABLE tower_ui_preferences(font_family text,desktop_helper numeric,desktop_body numeric,mobile_body numeric,private_field text);INSERT INTO tower_ui_preferences VALUES('Tajawal',11,16,18,'DO_NOT_EXPOSE');
CREATE TABLE fixture_fonts(value jsonb);INSERT INTO fixture_fonts VALUES('{"fontFamily":"Cairo","desktopBody":13}');
CREATE FUNCTION tower_ui_preferences_action(p_token text,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$DECLARE value jsonb;BEGIN IF p_action='update' THEN IF p_payload->>'fontFamily'='INVALID' THEN RAISE EXCEPTION 'INVALID_UI_PREFERENCES';END IF;UPDATE fixture_fonts SET value=p_payload;END IF;SELECT f.value INTO value FROM fixture_fonts f;RETURN value;END$$;`);

await db.exec(fs.readFileSync('sql/STAGING_102_Original_SQL252_IDENTITY_WORKSPACE.sql','utf8'));
const migration=fs.readFileSync('sql/STAGING_103_Original_SQL253_IDENTITY_GEOMETRY.sql','utf8');await db.exec(migration);
const studio=async(n,action,payload={})=>(await db.query('SELECT tower_brand_settings_256($1,$2,$3) v',[id(n),action,payload])).rows[0].v;
await db.exec(fs.readFileSync('sql/STAGING_105_Original_SQL256_IDENTITY_SPACING.sql','utf8'));
await check('old installation inherits canonical geometry and existing font/focus defaults',async()=>{const r=await studio(1,'get');assert.equal(r.branding.logoSize,34);assert.equal(r.branding.lineGap,2);assert.equal(r.branding.loginDesktopX,40);assert.equal(r.uiPreferences.desktopBody,13);});
const p={branding:{systemName:'changed',logoSize:48,lineGap:0,loginDesktopX:0,loginFade:false},uiPreferences:{fontFamily:'Tajawal',desktopBody:16}};
await check('geometry joins identity and fonts transaction; reinstall retains zero gap and size',async()=>{let r=await studio(1,'save',p);assert.equal(r.branding.logoSize,48);assert.equal(r.branding.lineGap,0);assert.equal(r.branding.loginFade,false);assert.equal(r.uiPreferences.desktopBody,16);await db.exec(fs.readFileSync('sql/STAGING_105_Original_SQL256_IDENTITY_SPACING.sql','utf8'));r=await studio(1,'get');assert.equal(r.branding.lineGap,0);assert.equal(r.branding.logoSize,48);});
await check('font failure rolls back branding focus and geometry together',async()=>{await assert.rejects(()=>studio(1,'save',{branding:{systemName:'rollback',logoSize:80,lineGap:24,loginDesktopX:99},uiPreferences:{fontFamily:'INVALID'}}));const r=await studio(1,'get');assert.equal(r.branding.systemName,'changed');assert.equal(r.branding.logoSize,48);assert.equal(r.branding.lineGap,0);assert.equal(r.branding.loginDesktopX,0);});
await check('geometry rejects null strings booleans fractions and out of range values',async()=>{for(const v of [null,'48',true,{},23,81,34.5])await assert.rejects(()=>studio(1,'save',{branding:{systemName:'bad',logoSize:v}}));for(const v of [null,'0',true,-9,25,2.5])await assert.rejects(()=>studio(1,'save',{branding:{systemName:'bad',lineGap:v}}));assert.equal((await studio(1,'get')).branding.logoSize,48);});
await check('security-only settings updates preserve geometry and fonts',async()=>{await studio(1,'save',{branding:{systemName:'security'},activationDays:3});const r=await studio(1,'get');assert.equal(r.branding.logoSize,48);assert.equal(r.branding.lineGap,0);assert.equal(r.uiPreferences.fontFamily,'Tajawal');});
await check('tighter negative spacing saves and roundtrips without changing fonts or logo; public typography contains whitelist only',async()=>{const r=await studio(1,'save',{branding:{systemName:'tight',lineGap:-8}});assert.equal(r.branding.lineGap,-8);assert.equal(r.branding.logoSize,48);const fonts=(await db.query('SELECT tower_public_ui_256() v')).rows[0].v;assert.deepEqual(fonts,{fontFamily:'Tajawal',desktopHelper:11,desktopBody:16,mobileBody:18});assert(!JSON.stringify(fonts).includes('DO_NOT_EXPOSE'));for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_public_ui_256()','EXECUTE') v",[role])).rows[0].v,false);});
await check('non admin inactive PIN-change and missing sessions rejected; role privileges remain closed',async()=>{for(const n of [2,3,4,5,99])await assert.rejects(()=>studio(n,'get'),/FORBIDDEN/);await db.query("UPDATE tower_users SET must_change_pin=true WHERE user_id=$1",[id(1)]);await assert.rejects(()=>studio(1,'get'),/FORBIDDEN/);await db.query("UPDATE tower_users SET must_change_pin=false,status='INACTIVE' WHERE user_id=$1",[id(1)]);await assert.rejects(()=>studio(1,'get'),/FORBIDDEN/);for(const role of ['anon','authenticated'])assert.equal((await db.query("SELECT has_function_privilege($1,'tower_brand_settings_253(text,text,jsonb)','EXECUTE') v",[role])).rows[0].v,false);assert.equal(Number((await db.query('SELECT amount FROM fixture_ledger')).rows[0].amount),89.74);});
fs.mkdirSync('qa/v3.4.0',{recursive:true});fs.writeFileSync('qa/v3.4.0/identity-spacing-sql-results.json',JSON.stringify(results,null,2));
}finally{await db.close();}
