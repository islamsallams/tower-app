import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const check=async(name,f)=>{await f();results.push({check:name,status:'PASS'});console.log('PASS',name);};
const rpc=async(token,action,payload)=>(await db.query('SELECT tower_unit_type_mutate_264($1,$2,$3) v',[token,action,payload])).rows[0].v;
try{
await db.exec(`CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),role text,status text,must_change_pin boolean DEFAULT false);
CREATE FUNCTION tower_session_user(p_token text) RETURNS SETOF tower_users LANGUAGE sql AS $$ SELECT * FROM tower_users WHERE role=p_token $$;
CREATE TABLE tower_unit_types(unit_type_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),name text UNIQUE,collection_weight numeric,status text,sort_order int DEFAULT 10);
CREATE TABLE tower_building_allocations(unit_id uuid,amount numeric,paid numeric);
INSERT INTO tower_building_allocations VALUES(gen_random_uuid(),123.45,67.89);
INSERT INTO tower_users(role,status) VALUES('ADMIN','ACTIVE'),('UNION','ACTIVE'),('RESIDENT','ACTIVE'),('OPERATOR','ACTIVE');
INSERT INTO tower_unit_types(name,collection_weight,status) VALUES('سكني',1,'ACTIVE');
-- Legacy engine fixture: verifies forwarding/atomicity, not online acceptance of the installed engine.
CREATE FUNCTION tower_unit_type_mutate(p_token text,p_action text,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE id uuid;BEGIN
 IF p_action='create' THEN INSERT INTO tower_unit_types(name,collection_weight,status) VALUES(p_payload->>'name',(p_payload->>'collectionWeight')::numeric,'ACTIVE') RETURNING unit_type_id INTO id;
 ELSIF p_action='update' THEN id:=(p_payload->>'unitTypeId')::uuid;UPDATE tower_unit_types SET name=p_payload->>'name',collection_weight=(p_payload->>'collectionWeight')::numeric WHERE unit_type_id=id;
 ELSIF p_action='deactivate' THEN UPDATE tower_unit_types SET status='INACTIVE' WHERE unit_type_id=(p_payload->>'unitTypeId')::uuid;
 ELSIF p_action='reactivate' THEN UPDATE tower_unit_types SET status='ACTIVE' WHERE unit_type_id=(p_payload->>'unitTypeId')::uuid;END IF;
 IF p_payload->>'name'='missing return' THEN RETURN '{"success":true}';END IF;
 RETURN jsonb_build_object('success',true,'unitTypeId',id);END $$;`);
const sql=fs.readFileSync('sql/STAGING_111_Original_SQL264_UNIT_TYPE_COLORS.sql','utf8');await db.exec(sql);
let id;
await check('migration is repeatable; additive default color preserves legacy weights and balances',async()=>{await db.exec(sql);const t=(await db.query('SELECT * FROM tower_unit_types')).rows[0];assert.equal(t.color_264,'#2f80ed');assert.equal(Number(t.collection_weight),1);assert.deepEqual((await db.query('SELECT amount::text,paid::text FROM tower_building_allocations')).rows,[{amount:'123.45',paid:'67.89'}]);});
await check('admin create and union edit persist valid color together with legacy type fields',async()=>{id=(await rpc('ADMIN','create',{name:'محل',collectionWeight:2,color:'#FFAA00'})).unitTypeId;assert.equal((await db.query('SELECT color_264 FROM tower_unit_types WHERE unit_type_id=$1',[id])).rows[0].color_264,'#ffaa00');await rpc('UNION','update',{unitTypeId:id,name:'تجاري',collectionWeight:1.5,color:'#36c68a'});const t=(await db.query('SELECT * FROM tower_unit_types WHERE unit_type_id=$1',[id])).rows[0];assert.equal(t.name,'تجاري');assert.equal(Number(t.collection_weight),1.5);assert.equal(t.color_264,'#36c68a');});
await check('invalid colors reject before writes; legacy errors and missing identity roll back the whole operation',async()=>{for(const color of ['red','#fff','url(x)',null,0])await assert.rejects(()=>rpc('ADMIN','create',{name:'مرفوض',collectionWeight:1,color}),/INVALID_UNIT_TYPE_COLOR/);await assert.rejects(()=>rpc('ADMIN','create',{name:'سكني',collectionWeight:7,color:'#ff0000'}),/duplicate/);await assert.rejects(()=>rpc('ADMIN','create',{name:'missing return',collectionWeight:1,color:'#ff0000'}),/UNIT_TYPE_NOT_SAVED/);assert.equal((await db.query("SELECT count(*)::int n FROM tower_unit_types WHERE name IN ('missing return','مرفوض')")).rows[0].n,0);});
await check('resident/operator/invalid session/changed-PIN/inactive accounts cannot mutate type colors',async()=>{for(const role of ['RESIDENT','OPERATOR'])await assert.rejects(()=>rpc(role,'update',{unitTypeId:id,color:'#ff0000'}),/FORBIDDEN/);await assert.rejects(()=>rpc('absent','update',{}),/SESSION_REQUIRED/);await db.exec("UPDATE tower_users SET must_change_pin=true WHERE role='ADMIN'");await assert.rejects(()=>rpc('ADMIN','update',{}),/SESSION_REQUIRED/);await db.exec("UPDATE tower_users SET must_change_pin=false,status='INACTIVE' WHERE role='ADMIN'");await assert.rejects(()=>rpc('ADMIN','update',{}),/SESSION_REQUIRED/);await db.exec("UPDATE tower_users SET status='ACTIVE' WHERE role='ADMIN'");});
await check('legacy update without color retains saved color; activation flows keep color and weight',async()=>{await rpc('ADMIN','update',{unitTypeId:id,name:'تجاري',collectionWeight:1.5});await rpc('ADMIN','deactivate',{unitTypeId:id});await rpc('UNION','reactivate',{unitTypeId:id});const t=(await db.query('SELECT * FROM tower_unit_types WHERE unit_type_id=$1',[id])).rows[0];assert.equal(t.color_264,'#36c68a');assert.equal(t.status,'ACTIVE');assert.equal(Number(t.collection_weight),1.5);});
await check('only service role gets wrapper execution, direct color writes obey constraint',async()=>{assert.equal((await db.query("SELECT has_function_privilege('anon','tower_unit_type_mutate_264(text,text,jsonb)','EXECUTE') v")).rows[0].v,false);assert.equal((await db.query("SELECT has_function_privilege('service_role','tower_unit_type_mutate_264(text,text,jsonb)','EXECUTE') v")).rows[0].v,true);await assert.rejects(()=>db.exec("UPDATE tower_unit_types SET color_264='#fff'"),/tower_unit_type_color_264/);});
fs.mkdirSync('qa/v3.6.0',{recursive:true});fs.writeFileSync('qa/v3.6.0/sql-results.json',JSON.stringify(results,null,2));
}finally{await db.close();}
