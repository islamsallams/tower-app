// Isolated PostgreSQL ACL reproduction. No live database or production rows.
import fs from 'node:fs';import assert from 'node:assert/strict';
const {PGlite}=await import(process.env.TOWER_PGLITE_MODULE),db=new PGlite(),results=[];
const check=async(name,f)=>{await f();results.push({check:name,status:'PASS'});console.log('PASS',name);};
try{
await db.exec(`CREATE ROLE service_role BYPASSRLS;CREATE ROLE anon;CREATE ROLE authenticated;
CREATE TABLE tower_users(user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),role text,status text,must_change_pin boolean DEFAULT false);
INSERT INTO tower_users(role,status) VALUES('ADMIN','ACTIVE'),('UNION','ACTIVE'),('RESIDENT','ACTIVE');
CREATE FUNCTION tower_session_user(p_token text) RETURNS SETOF tower_users LANGUAGE sql AS $$SELECT * FROM tower_users WHERE role=p_token$$;
CREATE TABLE tower_units(unit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),status text,updated_at timestamptz DEFAULT now(),state_id_262 uuid);
CREATE TABLE tower_audit(actor_id uuid,action text,entity text,entity_id text);
`);
const sql=fs.readFileSync('sql/STAGING_109_Original_SQL262_UNIT_STATES.sql','utf8');
await db.exec(sql.slice(sql.indexOf('CREATE TABLE IF NOT EXISTS public.tower_unit_states_262('),sql.indexOf('ALTER TABLE public.tower_units ADD COLUMN')));
await db.exec(sql.slice(sql.indexOf('CREATE OR REPLACE FUNCTION public.tower_unit_states_262(p_token'),sql.indexOf('CREATE OR REPLACE FUNCTION public.tower_unit_mutate_262')));
await db.exec(`INSERT INTO tower_unit_states_262(name,color,enabled,exempt_building) VALUES('حالة تجريبية','#36c68a',true,true);
INSERT INTO tower_units(status,state_id_262) SELECT 'ACTIVE',state_id FROM tower_unit_states_262 LIMIT 1;
REVOKE ALL ON FUNCTION tower_unit_states_262(text,text,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION tower_unit_states_262(text,text,jsonb) TO service_role;
GRANT SELECT ON tower_units TO service_role;SET ROLE service_role;`);
await check('BYPASSRLS does not bypass missing SELECT grants; V3.6.0 state join fails with actual PostgreSQL 42501',async()=>{await assert.rejects(()=>db.query('SELECT u.unit_id,s.name FROM tower_units u LEFT JOIN tower_unit_states_262 s ON s.state_id=u.state_id_262'),e=>e.code==='42501');});
await check('unchanged installed SECURITY DEFINER list authorizes admin/union and retains exemption without new grants',async()=>{for(const token of ['ADMIN','UNION']){const r=(await db.query("SELECT tower_unit_states_262($1,'list','{}') v",[token])).rows[0].v;assert.equal(r.length,3);const state=r.find(s=>s.name==='حالة تجريبية');assert.equal(state.exemptBuilding,true);assert.equal(state.color,'#36c68a');}assert.equal((await db.query("SELECT has_table_privilege(current_user,'tower_unit_states_262','SELECT') v")).rows[0].v,false);});
await check('same protected list rejects resident and invalid session, without changing the table ACL',async()=>{await assert.rejects(()=>db.query("SELECT tower_unit_states_262('RESIDENT','list','{}')"),/FORBIDDEN/);await assert.rejects(()=>db.query("SELECT tower_unit_states_262('absent','list','{}')"),/SESSION_REQUIRED/);await assert.rejects(()=>db.query('SELECT * FROM tower_unit_states_262'),e=>e.code==='42501');});
fs.mkdirSync('qa/v3.6.1',{recursive:true});fs.writeFileSync('qa/v3.6.1/permissions-results.json',JSON.stringify(results,null,2));
}finally{await db.close();}
