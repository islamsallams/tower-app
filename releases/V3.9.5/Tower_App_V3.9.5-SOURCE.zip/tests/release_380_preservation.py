from pathlib import Path
import zipfile,re,json
r=Path('.');z=zipfile.ZipFile(r/'releases/V3.7.0/Tower_App_V3.7.0-SOURCE.zip');results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M))
 return {v.group(1):s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions((r/'app.js').read_text())
reports=[n for n in a if re.search('report|pdf',n,re.I)]
check('all 86 report/PDF function blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
allow={'clearSession','openModal','closeModal','adminDataTools350','openDataTools350','submitDataTools350','downloadRuntime350'}
check('all existing unrelated app function blocks retained',all(a[n]==b[n] for n in a if n not in allow))
check('all 31 previous SQL files unchanged',all(z.read(n)==(r/n).read_bytes() for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')))
check('CSS adds only scoped restore styles', (r/'styles.css').read_bytes().startswith(z.read('styles.css')))
check('root/public assets byte-identical',all((r/n).read_bytes()==(r/'public'/n).read_bytes() for n in ['app.js','index.html','styles.css']))
check('encryption helpers unchanged',all(a[n]==b[n] for n in ['dataBase64350','dataBytes350','dataKey350','encryptBackup350','decryptBackup350']))
check('deployment bindings unchanged and consistent version',z.read('wrangler.toml')==(r/'wrangler.toml').read_bytes() and all("const APP_VERSION='3.8.0'" in (r/n).read_text() for n in ['app.js','worker.js']))
(r/'qa/v3.8.0/preservation-results.json').write_text(json.dumps(results,indent=2))
