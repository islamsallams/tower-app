from pathlib import Path
import zipfile,re,json
r=Path.cwd();z=zipfile.ZipFile(r/'releases/V3.8.0/Tower_App_V3.8.0-SOURCE.zip');results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v.group(1):s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions((r/'app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)]
check('all 86 report/PDF blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
allow={'openBulkUnitsCreate','bulkUnitsRead','closeBulkUnitCreate','playNoticeTone350','runCompleteSystemDiagnostics','diagnosticsCopyWithFeedback'}
check('unrelated app blocks including restore, financial engines, sound opt-in and tab deduplication retained',all(a[n]==b[n] for n in a if n not in allow))
check('all previous SQL bytes preserved; no SQL added',set(n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql'))==set(p.as_posix() for p in Path('sql').glob('*.sql')) and all(z.read(n)==(r/n).read_bytes() for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')))
check('root/public and deployment bindings preserved',all((r/n).read_bytes()==(r/'public'/n).read_bytes() for n in ['app.js','index.html','styles.css']) and z.read('wrangler.toml')==(r/'wrangler.toml').read_bytes())
check('only scoped new CSS and shared identity classes for bulk form',(r/'styles.css').read_bytes().startswith(z.read('styles.css')) and 'task-workspace bulk-create-workspace381' in b['openBulkUnitsCreate'])
for version in ['3.8.0','3.8.1']:
 s=(r/f'USER_ONLINE_TEST_V{version}_AR.md').read_text();check('explicit RTL HTML table and right-aligned columns V'+version,'<table dir="rtl">' in s and '<th align="right">التجربة</th>' in s and '<td align="right">' in s and not re.search(r'^\|',s,re.M))
(r/'qa/v3.8.1/preservation-results.json').write_text(json.dumps(results,indent=2))
