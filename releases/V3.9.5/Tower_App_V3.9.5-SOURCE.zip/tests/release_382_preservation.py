from pathlib import Path
import zipfile,re,json
r=Path.cwd();z=zipfile.ZipFile(r/'releases/V3.8.1/Tower_App_V3.8.1-SOURCE.zip');results=[]
def check(name,ok):
 assert ok,name
 results.append({'check':name,'status':'PASS'});print('PASS',name)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v.group(1):s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions((r/'app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)]
check('all 86 report/PDF function blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('only two existing runtime-download app function blocks changed',all(a[n]==b[n] for n in a if n not in {'adminDataTools350','downloadRuntime350'}))
check('worker differs only in version, preserving API contracts and permissions',(r/'worker.js').read_text().replace('3.8.2','3.8.1')==z.read('worker.js').decode())
check('all 32 previous SQL files unchanged and none added',set(n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql'))==set(p.as_posix() for p in Path('sql').glob('*.sql')) and all(z.read(n)==(r/n).read_bytes() for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')))
check('root/public assets and bindings preserved',all((r/n).read_bytes()==(r/'public'/n).read_bytes() for n in ['app.js','index.html','styles.css']) and z.read('wrangler.toml')==(r/'wrangler.toml').read_bytes())
check('CSS preserves previous bytes and adds scoped native-link styling only',(r/'styles.css').read_bytes().startswith(z.read('styles.css')) and '.runtime-download382:focus-visible' in (r/'styles.css').read_text())
(r/'qa/v3.8.2/preservation-results.json').write_text(json.dumps(results,indent=2))
