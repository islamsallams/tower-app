import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const s=fs.readFileSync('app.js','utf8'),a=s.indexOf('function playNoticeTone350()'),b=s.indexOf('\n',a),fn=s.slice(a,b),osc=[],gains=[];
const param=()=>({sets:[],ramps:[],setValueAtTime(v,t){this.sets.push([v,t]);},exponentialRampToValueAtTime(v,t){this.ramps.push([v,t]);}});
const node=()=>({gain:param(),frequency:param(),connect(){},disconnect(){this.disconnected=true;},start(t){this.startTime=t;},stop(t){this.stopTime=t;}});
const audio={state:'running',currentTime:0,destination:{},createOscillator(){const n=node();osc.push(n);return n;},createGain(){const n=node();gains.push(n);return n;}};
const c={NOTICE_AUDIO350:audio};vm.createContext(c);vm.runInContext(fn,c);assert.equal(c.playNoticeTone350(),true);const master=gains[0].gain.sets[0][0];assert.equal(master,1.25);assert.equal(osc.length,6);let peak=0;
for(let t=0;t<1.65;t+=.0001){let total=0;for(let i=0;i<osc.length;i++){const start=osc[i].startTime,g=gains[i+1].gain;if(t<start||t>osc[i].stopTime)continue;const [level,attack]=g.ramps[0],last=g.ramps[1];const amp=t<attack?.0001*(level/.0001)**((t-start)/(attack-start)):level*(last[0]/level)**Math.min(1,(t-attack)/(last[1]-attack));total+=amp;}peak=Math.max(peak,total*master);}
assert(peak<1);osc.forEach(o=>o.onended());assert(gains.every(g=>g.disconnected));console.log(JSON.stringify({status:'PASS',oldMaster:.72,newMaster:master,amplitudeRatio:master/.72,changeDecibels:20*Math.log10(master/.72),singleChimeEnvelopePeak:peak,toneAndTimingsUnchanged:true,audibleDeviceTested:false}));

fs.writeFileSync("qa/v3.8.3/audio-results.json",JSON.stringify([{check:"louder two-note envelope remains below clipping with oscillator cleanup",status:"PASS",singleChimeEnvelopePeak:peak,changeDecibels:20*Math.log10(master/.72),audibleDeviceTested:false}],null,2));
