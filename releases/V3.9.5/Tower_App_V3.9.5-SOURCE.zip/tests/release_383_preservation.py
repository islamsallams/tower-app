from pathlib import Path
import zipfile,re,json
r=Path.cwd();z=zipfile.ZipFile('releases/V3.8.2/Tower_App_V3.8.2-SOURCE.zip');results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def functions(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v[1]:s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=functions(z.read('app.js').decode()),functions(Path('app.js').read_text());reports=[n for n in a if re.search('report|pdf',n,re.I)]
check('all 86 existing app report/PDF blocks unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
allowed={'clearSession','userFiltersHtml','openNewUserModal','renderSystemAdmin','runCompleteSystemDiagnostics','runSystemHealthCheck','mountPersonalAlerts330','renderNoticeCenter340','playNoticeTone350','noticeSoundControls350','downloadRuntime350','renderRestoreReview380','renderRestoreConfirm380','executeRestore380'}
check('all other existing app functions unchanged',all(a[n]==b[n] for n in a if n not in allowed))
check('native runtime download function itself unchanged',a['downloadRuntime350'].splitlines()[0]==b['downloadRuntime350'].splitlines()[0])
wa,wb=functions(z.read('worker.js').decode()),functions(Path('worker.js').read_text())
check('existing worker business functions unchanged outside Push dispatch and top-level block boundaries',all(wa[n]==wb[n] for n in wa if n not in {'towerPdfFrequencyDue','enrichTaskProjects','dispatch','towerHealthMonitorRun'}))
check('worker PDF frequency function changes only attached version constant',wa['towerPdfFrequencyDue'].replace('3.8.2','3.8.3')==wb['towerPdfFrequencyDue'])
check('worker task enrichment function unchanged before error-message constants',wa['enrichTaskProjects'].split('const DB_USER_ERRORS=')[0]==wb['enrichTaskProjects'].split('const DB_USER_ERRORS=')[0])
check('worker health function unchanged before new Push declarations',wa['towerHealthMonitorRun'].split('export default')[0].strip()==wb['towerHealthMonitorRun'].split('// V3.8.3: standards-based Web Push')[0].strip())
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all 32 old SQL files unchanged; SQL266 is sole addition',len(old)==32 and all(z.read(n)==Path(n).read_bytes() for n in old) and new-old=={'sql/STAGING_113_Original_SQL266_DEVICE_PUSH.sql'})
check('root/public assets identical and bindings unchanged',all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','index.html','styles.css']) and z.read('wrangler.toml')==Path('wrangler.toml').read_bytes())
check('CSS retains all baseline bytes',Path('styles.css').read_bytes().startswith(z.read('styles.css')))
Path('qa/v3.8.3/preservation-results.json').write_text(json.dumps(results,indent=2))
