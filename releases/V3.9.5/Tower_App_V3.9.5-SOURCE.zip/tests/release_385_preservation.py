from pathlib import Path
import zipfile,re,json
z=zipfile.ZipFile('releases/V3.8.4/Tower_App_V3.8.4-SOURCE.zip');results=[]
def check(n,v):
 assert v,n
 results.append({'check':n,'status':'PASS'});print('PASS',n)
def funcs(s):
 m=list(re.finditer(r'^(?:async )?function (\w+)\(',s,re.M));return {v[1]:s[v.start():m[i+1].start() if i+1<len(m) else len(s)].rstrip() for i,v in enumerate(m)}
a,b=funcs(z.read('app.js').decode()),funcs(Path('app.js').read_text())
reports=[n for n in a if re.search('report|pdf',n,re.I)]
check('all 86 report/PDF app functions unchanged',len(reports)==86 and all(a[n]==b[n] for n in reports))
check('all old app functions unchanged except collapsed settings wrapper',all(a[n]==b[n] for n in a if n!='noticeSoundControls350'))
a,b=funcs(z.read('worker.js').decode()),funcs(Path('worker.js').read_text())
check('Worker existing functions unchanged except redirect compatibility and version',all(a[n]==b[n] for n in a if n not in {'processPush383','towerPdfFrequencyDue'}) and a['towerPdfFrequencyDue'].replace('3.8.4','3.8.5')==b['towerPdfFrequencyDue'])
check('sole send-path change is redirect error to manual',a['processPush383'].replace("redirect:'error'","redirect:'manual'")==b['processPush383'])
old={n for n in z.namelist() if n.startswith('sql/') and n.endswith('.sql')};new={p.as_posix() for p in Path('sql').glob('*.sql')}
check('all 33 SQL files unchanged and none added',old==new and len(old)==33 and all(z.read(n)==Path(n).read_bytes() for n in old))
check('previous styles retained; bindings and browser worker script unchanged',z.read('wrangler.toml')==Path('wrangler.toml').read_bytes() and Path('styles.css').read_bytes().startswith(z.read('styles.css')) and Path('worker.js').read_text().split('const PUSH_SW383=')[1].split('export default')[0]==z.read('worker.js').decode().split('const PUSH_SW383=')[1].split('export default')[0])
check('root and public assets identical',all(Path(n).read_bytes()==Path('public',n).read_bytes() for n in ['app.js','styles.css','index.html']))
Path('qa/v3.8.5/preservation-results.json').write_text(json.dumps(results,indent=2))
